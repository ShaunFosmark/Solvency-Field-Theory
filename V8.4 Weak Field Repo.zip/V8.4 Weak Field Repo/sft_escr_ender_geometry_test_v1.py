# sft_escr_ender_geometry_test_v1.py
#
# Purpose:
#   Test Ender's idea inside E_scr = 2TS by introducing a
#   disk-like equatorial screen-participation factor.
#
#   The goal is NOT to force the full SPARC answer from geometry alone.
#   The goal is to see whether a modest equatorial participation model
#   can naturally soften the old lambda = 4/3 candidate down into the
#   current data-favored band near 1.19 to 1.20.
#
# Core idea:
#   lambda = 2 * < w(theta) * sin^2(theta) >_sphere
#
#   where:
#     - the raw mixed-channel coefficient is 2
#     - sin^2(theta) is the tangential/orbital-support readout
#     - w(theta) is the screen-participation factor
#
# Models tested:
#   1) isotropic sphere      w = 1
#   2) hard equatorial belt  w = 1 inside |theta-pi/2| <= Delta, else 0
#   3) soft Gaussian belt    w = exp[-(theta-pi/2)^2 / (2 sigma^2)]
#
# Outputs:
#   ./sft_escr_ender_geometry_test_v1/
#     - escr_ender_geometry_summary.txt
#     - escr_ender_geometry_scan.csv
#     - lambda_vs_belt_width.png
#
# Run:
#   python sft_escr_ender_geometry_test_v1.py

import os
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
# OUTPUT
# ============================================================
BASE_DIR = os.getcwd()
OUTDIR = os.path.join(BASE_DIR, "sft_escr_ender_geometry_test_v1")
os.makedirs(OUTDIR, exist_ok=True)

# ============================================================
# TARGETS
# ============================================================
TARGETS = [
    ("six_over_five", 6.0 / 5.0),
    ("one_point_19", 1.19),
    ("four_over_three", 4.0 / 3.0),
]

# Numerical grid for soft model
THETA = np.linspace(0.0, math.pi, 20001)

# ============================================================
# CORE FORMULAS
# ============================================================
def lambda_from_weight(theta, w):
    """
    lambda = 2 * (1/4pi) * ∫ w(theta) sin^2(theta) dOmega
           = ∫_0^pi w(theta) sin^3(theta) dtheta
    """
    return float(np.trapezoid(w * np.sin(theta) ** 3, theta))

def f_area_from_weight(theta, w):
    """
    Effective participating entropy fraction:
      f_area = (1/4pi) ∫ w dOmega = (1/2) ∫ w sin(theta) dtheta
    """
    return float(0.5 * np.trapezoid(w * np.sin(theta), theta))

def local_tangential_readout(theta, w):
    """
    Conditional tangential readout inside the participating region:
      f_tan_local = [ (1/4pi) ∫ w sin^2(theta) dOmega ] / [ (1/4pi) ∫ w dOmega ]
                  = [ (1/2) ∫ w sin^3(theta) dtheta ] / [ (1/2) ∫ w sin(theta) dtheta ]
    """
    num = 0.5 * np.trapezoid(w * np.sin(theta) ** 3, theta)
    den = 0.5 * np.trapezoid(w * np.sin(theta), theta)
    if den <= 0:
        return np.nan
    return float(num / den)

# ============================================================
# MODEL 1: ISOTROPIC
# ============================================================
def isotropic_summary():
    w = np.ones_like(THETA)
    lam = lambda_from_weight(THETA, w)
    f_area = f_area_from_weight(THETA, w)
    f_tan = local_tangential_readout(THETA, w)
    return {
        "model": "isotropic",
        "param_name": "none",
        "param_value": np.nan,
        "lambda_value": lam,
        "f_area": f_area,
        "f_tan_local": f_tan,
    }

# ============================================================
# MODEL 2: HARD EQUATORIAL BELT
# ============================================================
def hard_belt_weight(theta, delta):
    return (np.abs(theta - math.pi / 2.0) <= delta).astype(float)

def hard_belt_lambda_analytic(delta):
    # lambda = ∫_{pi/2-delta}^{pi/2+delta} sin^3(theta) dtheta
    #        = 2 s - (2/3) s^3,  where s = sin(delta)
    s = math.sin(delta)
    return 2.0 * s - (2.0 / 3.0) * s ** 3

def hard_belt_summary(delta):
    w = hard_belt_weight(THETA, delta)
    lam_num = lambda_from_weight(THETA, w)
    lam_ana = hard_belt_lambda_analytic(delta)
    f_area = f_area_from_weight(THETA, w)
    f_tan = local_tangential_readout(THETA, w)
    return {
        "model": "hard_belt",
        "param_name": "delta_deg",
        "param_value": math.degrees(delta),
        "lambda_value": lam_num,
        "lambda_analytic": lam_ana,
        "f_area": f_area,
        "f_tan_local": f_tan,
    }

# ============================================================
# MODEL 3: SOFT GAUSSIAN BELT
# ============================================================
def gaussian_belt_weight(theta, sigma):
    return np.exp(-0.5 * ((theta - math.pi / 2.0) / sigma) ** 2)

def gaussian_belt_summary(sigma):
    w = gaussian_belt_weight(THETA, sigma)
    lam = lambda_from_weight(THETA, w)
    f_area = f_area_from_weight(THETA, w)
    f_tan = local_tangential_readout(THETA, w)
    return {
        "model": "gaussian_belt",
        "param_name": "sigma_deg",
        "param_value": math.degrees(sigma),
        "lambda_value": lam,
        "f_area": f_area,
        "f_tan_local": f_tan,
    }

# ============================================================
# SCANS
# ============================================================
rows = []

# isotropic single point
rows.append(isotropic_summary())

# hard-belt scan
delta_grid = np.linspace(math.radians(5.0), math.radians(90.0), 500)
for delta in delta_grid:
    rows.append(hard_belt_summary(delta))

# gaussian-belt scan
sigma_grid = np.linspace(math.radians(3.0), math.radians(90.0), 500)
for sigma in sigma_grid:
    rows.append(gaussian_belt_summary(sigma))

scan_df = pd.DataFrame(rows)
scan_df.to_csv(os.path.join(OUTDIR, "escr_ender_geometry_scan.csv"), index=False)

# ============================================================
# SOLVE FOR TARGETS
# ============================================================
target_rows = []

for label, target in TARGETS:
    # hard belt nearest solution
    sub_h = scan_df[scan_df["model"] == "hard_belt"].copy()
    sub_h["abs_err"] = np.abs(sub_h["lambda_value"] - target)
    best_h = sub_h.loc[sub_h["abs_err"].idxmin()]

    # gaussian belt nearest solution
    sub_g = scan_df[scan_df["model"] == "gaussian_belt"].copy()
    sub_g["abs_err"] = np.abs(sub_g["lambda_value"] - target)
    best_g = sub_g.loc[sub_g["abs_err"].idxmin()]

    target_rows.append({
        "target_label": label,
        "target_lambda": target,

        "hard_delta_deg": float(best_h["param_value"]),
        "hard_lambda": float(best_h["lambda_value"]),
        "hard_f_area": float(best_h["f_area"]),
        "hard_f_tan_local": float(best_h["f_tan_local"]),

        "gauss_sigma_deg": float(best_g["param_value"]),
        "gauss_lambda": float(best_g["lambda_value"]),
        "gauss_f_area": float(best_g["f_area"]),
        "gauss_f_tan_local": float(best_g["f_tan_local"]),
    })

target_df = pd.DataFrame(target_rows)

# ============================================================
# PLOT
# ============================================================
plt.figure(figsize=(10, 6))

sub_h = scan_df[scan_df["model"] == "hard_belt"]
sub_g = scan_df[scan_df["model"] == "gaussian_belt"]

plt.plot(sub_h["param_value"], sub_h["lambda_value"], label="hard belt (delta)")
plt.plot(sub_g["param_value"], sub_g["lambda_value"], label="gaussian belt (sigma)")

for label, target in TARGETS:
    plt.axhline(target, linestyle="--", label=f"{label} = {target:.4f}")

plt.xlabel("Angular width [deg]")
plt.ylabel("Predicted lambda from 2TS participation model")
plt.title("E_scr = 2TS with equatorial screen participation")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUTDIR, "lambda_vs_belt_width.png"), dpi=160)
plt.close()

# ============================================================
# SUMMARY
# ============================================================
lines = []
lines.append("SFT E_scr = 2TS + Ender geometry test V1")
lines.append("=" * 80)
lines.append("")
lines.append("Model:")
lines.append("  lambda = 2 * < w(theta) * sin^2(theta) >_sphere")
lines.append("")
lines.append("Interpretation:")
lines.append("  - raw mixed-channel coefficient = 2")
lines.append("  - sin^2(theta) = tangential/orbital-support readout")
lines.append("  - w(theta) = screen participation factor")
lines.append("")
lines.append("Isotropic reference:")
iso = scan_df[scan_df['model'] == 'isotropic'].iloc[0]
lines.append(f"  lambda_iso = {iso['lambda_value']:.6f}")
lines.append(f"  f_area_iso = {iso['f_area']:.6f}")
lines.append(f"  f_tan_local_iso = {iso['f_tan_local']:.6f}")
lines.append("")
lines.append("[Target solutions]")
lines.append(target_df.to_string(index=False))
lines.append("")
lines.append("Interpretation guide:")
lines.append("  - If lambda = 6/5 is reached for a moderate belt width, Ender's idea has real legs.")
lines.append("  - If lambda = 6/5 requires extreme fine-tuning, the idea is weak.")
lines.append("  - If 6/5 and 1.19 arise from only modest suppression of isotropic participation,")
lines.append("    then E_scr = 2TS plus equatorial participation is a serious pre-publication derivation candidate.")
lines.append("")
lines.append("Analytic hard-belt formula:")
lines.append("  For half-opening angle Delta and s = sin(Delta),")
lines.append("    lambda_hard = 2 s - (2/3) s^3")
lines.append("  so isotropic sphere (Delta = 90 deg) gives lambda = 4/3 exactly.")

with open(os.path.join(OUTDIR, "escr_ender_geometry_summary.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("\n".join(lines))
print(f"\nSaved outputs to: {OUTDIR}")
