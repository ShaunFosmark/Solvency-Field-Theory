# sft_disk_geometry_wtheta_test_v1.py
#
# Purpose:
#   Derive w(theta) from an idealized thin-disk geometry on a spherical screen
#   and test what coefficient lambda it predicts in the weak-field screen law.
#
# Core formula:
#   lambda[w] = 2 * < w(theta) sin^2(theta) >_sphere
#             = ∫_0^pi w(theta) sin^3(theta) dtheta
#
# What is computed:
#   1) A uniform razor-thin disk in the equatorial plane
#   2) The Newtonian field of that disk on a spherical shell of radius r
#   3) Three candidate participation functions:
#        - w_mag(theta) = |g_disk(theta)| / g_sph
#        - w_rad(theta) = |g_disk · n_hat| / g_sph
#        - w_sin(theta) = sin(theta)     (kinematic/lever-arm candidate)
#
#   where g_sph = GM/r^2 is the spherical-source reference field.
#
# Outputs:
#   ./sft_disk_geometry_wtheta_test_v1/
#     - disk_geometry_wtheta_summary.txt
#     - disk_geometry_wtheta_profiles.csv
#     - disk_geometry_target_comparison.csv
#     - wtheta_profiles.png
#
# Notes:
#   - The disk is idealized as a uniform razor-thin disk whose outer radius
#     equals the spherical screen radius. That makes the geometry parameter-free
#     after normalization.
#   - We avoid evaluating exactly at theta = pi/2 to avoid the sheet boundary point.
#   - If the field-based w(theta) does NOT land near ~1.2, that is still valuable:
#     it means the missing suppression is not simply raw field-strength geometry.
#
# Run:
#   python sft_disk_geometry_wtheta_test_v1.py

import os
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
# USER SETTINGS
# ============================================================
# Numerical resolution. Raise if you want more accuracy.
N_THETA = 181      # uses midpoint grid, so theta = pi/2 is avoided automatically
N_RHO = 240
N_PHI = 480

# ============================================================
# OUTPUT
# ============================================================
BASE_DIR = os.getcwd()
OUTDIR = os.path.join(BASE_DIR, "sft_disk_geometry_wtheta_test_v1")
os.makedirs(OUTDIR, exist_ok=True)

# ============================================================
# THEORY TARGETS
# ============================================================
TARGETS = [
    ("six_over_five", 6.0 / 5.0),
    ("one_point_19", 1.19),
    ("four_over_three", 4.0 / 3.0),
    ("three_pi_over_eight", 3.0 * math.pi / 8.0),
]

# ============================================================
# DIMENSIONLESS SETUP
#
# Set screen radius r = 1 and G*Sigma = 1.
# For a uniform disk of radius r=1:
#   M = pi * Sigma * r^2
#   g_sph = G M / r^2 = pi * G Sigma
# so after setting G*Sigma = 1, the spherical reference field is g_sph = pi.
# ============================================================
G_SIGMA = 1.0
G_SPH_REF = math.pi * G_SIGMA

# Midpoint theta grid avoids exactly theta = pi/2
theta = (np.arange(N_THETA) + 0.5) * math.pi / N_THETA
sin_theta = np.sin(theta)
cos_theta = np.cos(theta)

# Disk integration grids
rho = (np.arange(N_RHO) + 0.5) / N_RHO       # 0..1 midpoint
drho = 1.0 / N_RHO
phi = np.linspace(0.0, 2.0 * math.pi, N_PHI, endpoint=False)
dphi = 2.0 * math.pi / N_PHI
cos_phi = np.cos(phi)

# ============================================================
# FIELD OF A UNIFORM RAZOR-THIN DISK ON A SPHERICAL SHELL
#
# Observation point:
#   x = (s, 0, z) with
#   s = sin(theta), z = cos(theta), and r_shell = 1
#
# Source point in disk plane z=0:
#   x' = (rho cos(phi), rho sin(phi), 0)
#
# Differential mass:
#   dm = Sigma * rho dphi drho
#
# Acceleration:
#   dg = G dm (x' - x) / |x' - x|^3
#
# By symmetry, only the cylindrical-radial (s-direction) and z components survive.
# ============================================================
def compute_disk_field_profiles():
    g_s = np.zeros_like(theta)   # cylindrical-radial component (along +s direction)
    g_z = np.zeros_like(theta)   # vertical component

    rr = rho[:, None]            # shape (N_RHO, 1)
    cphi = cos_phi[None, :]      # shape (1, N_PHI)

    for i, (s, z) in enumerate(zip(sin_theta, cos_theta)):
        # Distance from source point in disk to observation point on sphere
        D2 = s*s + rr*rr - 2.0*s*rr*cphi + z*z
        D32 = D2 ** 1.5

        # Components of source - observer
        # along s-direction: rho cos(phi) - s
        # along z-direction: 0 - z = -z
        dg_s = ((rr * cphi - s) / D32) * rr
        dg_z = ((-z) / D32) * rr

        g_s[i] = G_SIGMA * np.sum(dg_s) * drho * dphi
        g_z[i] = G_SIGMA * np.sum(dg_z) * drho * dphi

    # Magnitude
    g_mag = np.sqrt(g_s**2 + g_z**2)

    # Inward radial component on spherical screen
    # outward normal = (sin(theta), 0, cos(theta))
    # g dot n_hat is negative for inward pull, so define inward-positive radial coupling:
    g_rad_in = -(g_s * sin_theta + g_z * cos_theta)

    return g_s, g_z, g_mag, g_rad_in

g_s, g_z, g_mag, g_rad = compute_disk_field_profiles()

# ============================================================
# CANDIDATE PARTICIPATION FUNCTIONS
# ============================================================
w_mag = g_mag / G_SPH_REF
w_rad = g_rad / G_SPH_REF
w_sin = sin_theta.copy()   # kinematic/azimuthal lever-arm candidate

# ============================================================
# LAMBDA FUNCTIONAL
#   lambda[w] = ∫_0^pi w(theta) sin^3(theta) dtheta
# ============================================================
def lambda_from_w(w):
    return float(np.trapezoid(w * sin_theta**3, theta))

def area_average_w(w):
    # <w>_sphere = (1/2) ∫ w sin(theta) dtheta
    return float(0.5 * np.trapezoid(w * sin_theta, theta))

def tangential_conditional(w):
    # conditional tangential factor on participating region:
    # [ (1/2) ∫ w sin^3(theta) dtheta ] / [ (1/2) ∫ w sin(theta) dtheta ]
    den = 0.5 * np.trapezoid(w * sin_theta, theta)
    if den <= 0:
        return np.nan
    num = 0.5 * np.trapezoid(w * sin_theta**3, theta)
    return float(num / den)

lambda_mag = lambda_from_w(w_mag)
lambda_rad = lambda_from_w(w_rad)
lambda_sin = lambda_from_w(w_sin)

# ============================================================
# SAVE PROFILE TABLE
# ============================================================
profile_df = pd.DataFrame({
    "theta_deg": np.degrees(theta),
    "sin_theta": sin_theta,
    "cos_theta": cos_theta,
    "g_s": g_s,
    "g_z": g_z,
    "g_mag": g_mag,
    "g_rad_in": g_rad,
    "w_mag": w_mag,
    "w_rad": w_rad,
    "w_sin": w_sin,
})
profile_df.to_csv(os.path.join(OUTDIR, "disk_geometry_wtheta_profiles.csv"), index=False)

# ============================================================
# TARGET COMPARISON
# ============================================================
model_rows = [
    {
        "model": "w_mag_from_disk_field",
        "lambda_value": lambda_mag,
        "w_area_mean": area_average_w(w_mag),
        "f_tan_conditional": tangential_conditional(w_mag),
    },
    {
        "model": "w_rad_from_screen_normal_field",
        "lambda_value": lambda_rad,
        "w_area_mean": area_average_w(w_rad),
        "f_tan_conditional": tangential_conditional(w_rad),
    },
    {
        "model": "w_sin_lever_arm_candidate",
        "lambda_value": lambda_sin,
        "w_area_mean": area_average_w(w_sin),
        "f_tan_conditional": tangential_conditional(w_sin),
    },
]

models_df = pd.DataFrame(model_rows)

target_rows = []
for _, row in models_df.iterrows():
    for label, target in TARGETS:
        target_rows.append({
            "model": row["model"],
            "lambda_model": row["lambda_value"],
            "target_label": label,
            "target_lambda": target,
            "abs_difference": abs(row["lambda_value"] - target),
        })

target_df = pd.DataFrame(target_rows)
target_df.to_csv(os.path.join(OUTDIR, "disk_geometry_target_comparison.csv"), index=False)

# ============================================================
# PLOT
# ============================================================
plt.figure(figsize=(10, 6))
plt.plot(profile_df["theta_deg"], profile_df["w_mag"], label="w_mag from disk field")
plt.plot(profile_df["theta_deg"], profile_df["w_rad"], label="w_rad from radial screen coupling")
plt.plot(profile_df["theta_deg"], profile_df["w_sin"], label="w_sin = sin(theta)")
plt.xlabel("theta [deg]")
plt.ylabel("w(theta)")
plt.title("Thin-disk participation functions on a spherical screen")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUTDIR, "wtheta_profiles.png"), dpi=160)
plt.close()

# ============================================================
# SUMMARY
# ============================================================
lines = []
lines.append("SFT thin-disk geometry -> w(theta) test V1")
lines.append("=" * 80)
lines.append("")
lines.append("Setup:")
lines.append("  - idealized uniform razor-thin disk in equatorial plane")
lines.append("  - disk outer radius = spherical screen radius")
lines.append("  - spherical-source reference field = GM/r^2")
lines.append("")
lines.append("Definitions:")
lines.append("  w_mag(theta) = |g_disk(theta)| / g_sph")
lines.append("  w_rad(theta) = |g_disk(theta) · n_hat| / g_sph")
lines.append("  w_sin(theta) = sin(theta)")
lines.append("")
lines.append("Lambda functional:")
lines.append("  lambda[w] = ∫_0^pi w(theta) sin^3(theta) dtheta")
lines.append("")
lines.append("[Model predictions]")
lines.append(models_df.to_string(index=False))
lines.append("")
lines.append("[Closest targets]")
for _, row in models_df.iterrows():
    sub = target_df[target_df["model"] == row["model"]].sort_values("abs_difference")
    lines.append(sub.head(3).to_string(index=False))
    lines.append("")
lines.append("Reference values:")
lines.append(f"  4/3           = {4.0/3.0:.6f}")
lines.append(f"  6/5           = {6.0/5.0:.6f}")
lines.append(f"  1.19          = {1.19:.6f}")
lines.append(f"  3*pi/8        = {3.0*math.pi/8.0:.6f}")
lines.append("")
lines.append("Interpretation guide:")
lines.append("  - If w_mag or w_rad land near ~1.19-1.20, disk field geometry itself may close the derivation.")
lines.append("  - If only w_sin lands near the target, then the missing step is not raw field magnitude")
lines.append("    but an azimuthal/kinematic participation rule tied to circular support.")
lines.append("  - If none land near the target, the remaining suppression must live in the mixed-channel interaction itself.")

with open(os.path.join(OUTDIR, "disk_geometry_wtheta_summary.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("\n".join(lines))
print(f"\nSaved outputs to: {OUTDIR}")
