#!/usr/bin/env python3
"""
SFT V12 Gate 12B: Boundary Radius vs Spatial Radius Audit

Purpose
-------
Gate 12A showed that the unified shatter seed robustly produces the striking
scale cluster:

    R_area ~ 45.6 km
    t_shatter ~ 6.6e-23 s
    kT ~ 20 TeV
    E/N ~ 62 MeV

but it also showed that an ordinary spatial interpretation fails causal
coherence badly:

    c t_shatter / R_area ~ 4e-19

Gate 12B audits the possible interpretations of R_shatter.

Question
--------
Can the pre-shatter "radius" be consistently treated as a boundary-equivalent
area radius, while ordinary spatial separation is created only at/after the
shatter?

Interpretation branches
-----------------------
1. ordinary_spatial_ball
   R_area is an ordinary spatial radius before shatter.
   Requires c t_shatter >= R_area for causal coordination.
   Gate 12A suggests this fails.

2. boundary_equivalent_radius
   R_area is the radius of a sphere with the same boundary area N*a_unit.
   It is an accounting radius, not a pre-existing ordinary spatial separation.
   The unified object is one process; no internal light-crossing condition is
   imposed during the unified phase. This branch is conceptually allowed but
   requires explicit pre-geometric wording.

3. causal_core_plus_boundary_capacity
   The ordinary causal size during the unified phase is R_causal = c t_shatter,
   while the boundary capacity corresponds to R_area.
   This exposes the required capacity-to-spatial compression factor:
       R_area / R_causal
   and asks whether the theory can explain such compression.

4. post_shatter_spatialization
   The boundary area accumulated before shatter becomes distributed local
   service after shatter. This estimates the initial mean separation scale if
   N sites occupy a chosen post-shatter volume. This is not a derivation, only
   a sanity ledger.

Claim boundary
--------------
This script does NOT derive:
    - a_phi;
    - N;
    - the shatter mechanism;
    - inflation replacement;
    - perturbation spectrum.

It DOES:
    - make the causal failure of the ordinary spatial branch explicit;
    - quantify the boundary/spatial compression factor;
    - output clean language for which interpretation survives;
    - preserve the 2pi convention audit from Gate 12A.
"""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np


# -----------------------------
# Constants
# -----------------------------

C = 299_792_458.0
H = 6.626_070_15e-34
HBAR = H / (2.0 * math.pi)
G_MARKER = 6.674_30e-11
KB = 1.380_649e-23
SIGMA_SB = 5.670_374_419e-8
MPC_M = 3.085_677_581_491_3673e22

A_PHI_REF = HBAR * G_MARKER / C**3
A0_REF = H * G_MARKER / C**3
PLANCK_LENGTH_M = math.sqrt(HBAR * G_MARKER / C**3)
PLANCK_TIME_S = math.sqrt(HBAR * G_MARKER / C**5)


@dataclass
class Config:
    E_nominal_J: float = 1.0e69
    N_nominal: float = 1.0e80

    # Optional post-shatter volume choices for site spacing diagnostics.
    post_volume_radius_factors: tuple[float, ...] = (
        1.0,        # same as R_area
        1e3,        # 1000 times larger
        1e6,        # million times larger
        1e18,       # huge spatialization factor
    )

    # Sweep ranges around the seed.
    log10_E_min: float = 68.0
    log10_E_max: float = 71.0
    log10_E_num: int = 61
    log10_N_min: float = 78.0
    log10_N_max: float = 82.0
    log10_N_num: int = 81

    out_dir: str = "SFT_V12_GATE_12B_OUTPUT"


# -----------------------------
# Helpers
# -----------------------------

def sphere_radius_from_area(area_m2: float) -> float:
    return math.sqrt(area_m2 / (4.0 * math.pi))


def sphere_area(R_m: float) -> float:
    return 4.0 * math.pi * R_m**2


def sphere_volume(R_m: float) -> float:
    return (4.0 / 3.0) * math.pi * R_m**3


def schwarzschild_radius(E_J: float) -> float:
    return 2.0 * G_MARKER * E_J / C**4


def radiation_temperature(E_J: float, V_m3: float) -> float:
    a_rad = 4.0 * SIGMA_SB / C
    return (E_J / V_m3 / a_rad) ** 0.25


def rate(E_J: float, rate_convention: str) -> float:
    if rate_convention == "cycles":
        return E_J / H
    if rate_convention == "radians":
        return E_J / HBAR
    raise ValueError(rate_convention)


def area_unit(area_convention: str) -> float:
    if area_convention == "a_phi":
        return A_PHI_REF
    if area_convention == "A0":
        return A0_REF
    raise ValueError(area_convention)


def convention_name(rate_convention: str, area_convention: str) -> str:
    if rate_convention == "cycles" and area_convention == "a_phi":
        return "mixed_addendum_like_cycles_time_a_phi_area"
    if rate_convention == "cycles" and area_convention == "A0":
        return "cycle_consistent_cycles_time_A0_area"
    if rate_convention == "radians" and area_convention == "a_phi":
        return "radian_consistent_radian_time_a_phi_area"
    if rate_convention == "radians" and area_convention == "A0":
        return "radian_time_cycle_area_crosscheck"
    return f"{rate_convention}_{area_convention}"


def nearest_neighbor_spacing_for_N_in_sphere(N: float, R_m: float) -> float:
    # crude mean cell spacing = (V/N)^(1/3)
    return (sphere_volume(R_m) / N) ** (1.0 / 3.0)


def compute_seed(E_J: float, N: float, rate_convention: str, area_convention: str, label: str) -> dict:
    au = area_unit(area_convention)
    r = rate(E_J, rate_convention)
    t = N / r
    R_area = sphere_radius_from_area(N * au)
    R_causal = C * t
    Rs = schwarzschild_radius(E_J)
    V_area = sphere_volume(R_area)
    T_area = radiation_temperature(E_J, V_area)
    light_time = R_area / C
    ct_over_R = R_causal / R_area
    compression_radius = R_area / R_causal if R_causal > 0 else math.inf
    compression_area = compression_radius**2
    compression_volume = compression_radius**3

    return {
        "label": label,
        "convention": convention_name(rate_convention, area_convention),
        "rate_convention": rate_convention,
        "area_convention": area_convention,
        "E_J": E_J,
        "N": N,
        "log10_E": math.log10(E_J),
        "log10_N": math.log10(N),
        "area_unit_m2": au,
        "R_area_m": R_area,
        "R_area_km": R_area / 1e3,
        "t_shatter_s": t,
        "R_causal_m": R_causal,
        "R_causal_fm": R_causal / 1e-15,
        "light_crossing_time_R_area_s": light_time,
        "ct_over_R_area": ct_over_R,
        "R_area_over_ct": compression_radius,
        "area_compression_factor": compression_area,
        "volume_compression_factor": compression_volume,
        "ordinary_spatial_causal_pass": ct_over_R >= 1.0,
        "ordinary_spatial_causal_margin_log10": math.log10(ct_over_R) if ct_over_R > 0 else -math.inf,
        "R_schwarzschild_m": Rs,
        "R_area_over_Rs": R_area / Rs if Rs > 0 else math.nan,
        "inside_schwarzschild": R_area < Rs,
        "T_if_R_area_spatial_K": T_area,
        "kT_if_R_area_spatial_TeV": KB * T_area / (1e12 * 1.602_176_634e-19),
        "mean_spacing_if_sites_fill_R_area_m": nearest_neighbor_spacing_for_N_in_sphere(N, R_area),
        "mean_spacing_if_sites_fill_R_area_fm": nearest_neighbor_spacing_for_N_in_sphere(N, R_area) / 1e-15,
        "R_area_over_planck_length": R_area / PLANCK_LENGTH_M,
        "t_over_planck_time": t / PLANCK_TIME_S,
    }


def interpret_branch(row: dict) -> list[dict]:
    """Return branch audit rows for a seed row."""
    branches = []

    branches.append({
        "label": row["label"],
        "convention": row["convention"],
        "branch": "ordinary_spatial_ball",
        "status": "PASS" if row["ordinary_spatial_causal_pass"] else "FAIL",
        "primary_metric": "ct_over_R_area",
        "value": row["ct_over_R_area"],
        "requirement": ">= 1",
        "interpretation": (
            "R_area can be treated as ordinary pre-shatter spatial radius"
            if row["ordinary_spatial_causal_pass"]
            else "R_area cannot be treated as an ordinary causally coordinated pre-shatter spatial radius"
        ),
    })

    branches.append({
        "label": row["label"],
        "convention": row["convention"],
        "branch": "boundary_equivalent_radius",
        "status": "CONCEPTUAL_PASS_REQUIRES_EXPLICIT_WORDING",
        "primary_metric": "R_area_from_boundary_count",
        "value": row["R_area_m"],
        "requirement": "R_area is accounting radius, not ordinary internal distance",
        "interpretation": (
            "Survives the causal gate only if the unified phase is one pre-geometric process and "
            "R_area means equivalent boundary area radius."
        ),
    })

    branches.append({
        "label": row["label"],
        "convention": row["convention"],
        "branch": "causal_core_plus_boundary_capacity",
        "status": "DIAGNOSTIC_ONLY_NEEDS_MECHANISM",
        "primary_metric": "R_area_over_ct",
        "value": row["R_area_over_ct"],
        "requirement": "Theory must explain boundary capacity compressed over causal core",
        "interpretation": (
            "Ordinary causal core size is c*t. Boundary-equivalent radius is much larger. "
            "This branch quantifies the required pre-geometric compression."
        ),
    })

    branches.append({
        "label": row["label"],
        "convention": row["convention"],
        "branch": "post_shatter_spatialization",
        "status": "OPEN_GATE",
        "primary_metric": "mean_spacing_if_sites_fill_R_area",
        "value": row["mean_spacing_if_sites_fill_R_area_m"],
        "requirement": "Need a rule mapping boundary entries to emergent spatial sites",
        "interpretation": (
            "If N sites are distributed inside a volume of radius R_area, the mean cell spacing is computed. "
            "This is not yet a shatter mechanism."
        ),
    })

    return branches


def post_shatter_spacing_rows(cfg: Config, seed: dict) -> list[dict]:
    rows = []
    for factor in cfg.post_volume_radius_factors:
        R_post = seed["R_area_m"] * factor
        spacing = nearest_neighbor_spacing_for_N_in_sphere(seed["N"], R_post)
        rows.append({
            "label": seed["label"],
            "convention": seed["convention"],
            "post_radius_factor_vs_R_area": factor,
            "post_radius_m": R_post,
            "post_radius_km": R_post / 1e3,
            "mean_cell_spacing_m": spacing,
            "mean_cell_spacing_fm": spacing / 1e-15,
            "mean_cell_spacing_over_planck_length": spacing / PLANCK_LENGTH_M,
            "post_volume_m3": sphere_volume(R_post),
            "number_density_sites_m3": seed["N"] / sphere_volume(R_post),
        })
    return rows


def main_seed_rows(cfg: Config) -> list[dict]:
    conventions = [
        ("cycles", "a_phi"),
        ("cycles", "A0"),
        ("radians", "a_phi"),
        ("radians", "A0"),
    ]
    return [
        compute_seed(cfg.E_nominal_J, cfg.N_nominal, rc, ac, "nominal_E1e69_N1e80")
        for rc, ac in conventions
    ]


def sweep_rows(cfg: Config) -> list[dict]:
    rows = []
    logE_values = np.linspace(cfg.log10_E_min, cfg.log10_E_max, cfg.log10_E_num)
    logN_values = np.linspace(cfg.log10_N_min, cfg.log10_N_max, cfg.log10_N_num)
    conventions = [
        ("cycles", "a_phi"),
        ("cycles", "A0"),
        ("radians", "a_phi"),
    ]

    for logE in logE_values:
        E = 10.0 ** float(logE)
        for logN in logN_values:
            N = 10.0 ** float(logN)
            for rc, ac in conventions:
                row = compute_seed(E, N, rc, ac, "sweep")
                row["near_seed_radius_10_200_km"] = 10.0 <= row["R_area_km"] <= 200.0
                row["strong_time_window"] = 1e-24 <= row["t_shatter_s"] <= 1e-20
                row["causal_pass"] = row["ct_over_R_area"] >= 1.0
                row["boundary_interpretation_needed"] = not row["causal_pass"]
                rows.append(row)
    return rows


def sweep_summary(rows: list[dict]) -> list[dict]:
    groups: dict[str, list[dict]] = {}
    for r in rows:
        groups.setdefault(r["convention"], []).append(r)

    out = []
    for conv, group in groups.items():
        n = len(group)
        causal = [r for r in group if r["causal_pass"]]
        near_seed = [r for r in group if r["near_seed_radius_10_200_km"] and r["strong_time_window"]]
        near_seed_causal = [r for r in near_seed if r["causal_pass"]]

        max_ct = max(group, key=lambda r: r["ct_over_R_area"])
        min_compression = min(group, key=lambda r: r["R_area_over_ct"])

        out.append({
            "convention": conv,
            "num_rows": n,
            "num_causal_pass_ct_over_R_ge_1": len(causal),
            "num_near_seed_radius_and_strong_time": len(near_seed),
            "num_near_seed_and_causal": len(near_seed_causal),
            "max_ct_over_R": max_ct["ct_over_R_area"],
            "max_ct_over_R_log10_E": max_ct["log10_E"],
            "max_ct_over_R_log10_N": max_ct["log10_N"],
            "max_ct_over_R_R_km": max_ct["R_area_km"],
            "max_ct_over_R_t_s": max_ct["t_shatter_s"],
            "min_R_over_ct": min_compression["R_area_over_ct"],
            "min_R_over_ct_log10_E": min_compression["log10_E"],
            "min_R_over_ct_log10_N": min_compression["log10_N"],
        })
    return out


def inverse_constraints(cfg: Config, seed: dict) -> list[dict]:
    rows = []

    # Given N and t, area unit required for ordinary spatial causal equality R_area = ct.
    R_causal = seed["R_causal_m"]
    a_unit_for_causal = sphere_area(R_causal) / seed["N"]

    rows.append({
        "relation": "area_unit_required_for_R_area_equal_ct_given_N_t",
        "value_m2": a_unit_for_causal,
        "ratio_to_a_phi_ref": a_unit_for_causal / A_PHI_REF,
        "ratio_to_A0_ref": a_unit_for_causal / A0_REF,
        "interpretation": "To keep N fixed and make the boundary-equivalent radius causally small, the write area would need to be smaller by the listed factor.",
    })

    # Given area unit and N, E required so t=N h/E equals R_area/c.
    E_req_cycles = H * seed["N"] * C / seed["R_area_m"]
    E_req_radians = HBAR * seed["N"] * C / seed["R_area_m"]
    rows.append({
        "relation": "E_required_for_cycle_time_light_crossing",
        "value_J": E_req_cycles,
        "ratio_to_nominal_E": E_req_cycles / seed["E_J"],
        "interpretation": "Energy required for N cycle ticks to happen over the light-crossing time of R_area.",
    })
    rows.append({
        "relation": "E_required_for_radian_time_light_crossing",
        "value_J": E_req_radians,
        "ratio_to_nominal_E": E_req_radians / seed["E_J"],
        "interpretation": "Energy required for N radian ticks to happen over the light-crossing time of R_area.",
    })

    # Given E and area unit, N required for causal equality. Solve:
    # R = sqrt(N a/4pi), t=N h/E, require c t = R.
    # c N q/E = sqrt(N a/4pi) -> N = a E^2 / (4pi c^2 q^2)
    for quantum_label, quantum in [("cycles_h", H), ("radians_hbar", HBAR)]:
        for area_label, au in [("a_phi", A_PHI_REF), ("A0", A0_REF)]:
            N_req = au * seed["E_J"]**2 / (4.0 * math.pi * C**2 * quantum**2)
            rows.append({
                "relation": f"N_required_for_causal_equality_given_E_{quantum_label}_{area_label}",
                "value": N_req,
                "log10_value": math.log10(N_req),
                "ratio_to_nominal_N": N_req / seed["N"],
                "interpretation": "Count required for c*N*quantum/E = sqrt(N*area_unit/4pi).",
            })

    return rows


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_outputs(cfg: Config, seeds: list[dict], branches: list[dict], spacing: list[dict], sweep: list[dict], summary: list[dict], inverses: list[dict]) -> dict:
    out = Path(cfg.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    seed_csv = out / "gate12B_seed_radius_audit.csv"
    branch_csv = out / "gate12B_interpretation_branches.csv"
    spacing_csv = out / "gate12B_post_shatter_spacing.csv"
    sweep_csv = out / "gate12B_boundary_vs_spatial_sweep.csv"
    summary_csv = out / "gate12B_sweep_summary.csv"
    inverse_csv = out / "gate12B_inverse_constraints.csv"
    verdict_csv = out / "gate12B_verdict.csv"
    report = out / "gate12B_boundary_radius_vs_spatial_radius_report.txt"

    write_csv(seed_csv, seeds)
    write_csv(branch_csv, branches)
    write_csv(spacing_csv, spacing)
    write_csv(sweep_csv, sweep)
    write_csv(summary_csv, summary)
    write_csv(inverse_csv, inverses)

    nominal = [r for r in seeds if r["convention"] == "mixed_addendum_like_cycles_time_a_phi_area"][0]

    verdict = {
        "verdict": "BOUNDARY_RADIUS_INTERPRETATION_REQUIRED",
        "ordinary_spatial_ball_status": "FAIL",
        "boundary_equivalent_radius_status": "CONCEPTUAL_PASS_REQUIRES_EXPLICIT_PREGEOMETRIC_WORDING",
        "nominal_R_area_km": nominal["R_area_km"],
        "nominal_R_causal_m": nominal["R_causal_m"],
        "nominal_R_causal_fm": nominal["R_causal_fm"],
        "nominal_ct_over_R_area": nominal["ct_over_R_area"],
        "nominal_R_area_over_ct": nominal["R_area_over_ct"],
        "nominal_area_compression_factor": nominal["area_compression_factor"],
        "nominal_volume_compression_factor": nominal["volume_compression_factor"],
        "key_sentence": "The pre-shatter radius must be called a boundary-equivalent write-area radius, not an ordinary pre-shatter spatial radius.",
    }
    write_csv(verdict_csv, [verdict])

    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12B: Boundary Radius vs Spatial Radius Audit\n")
        f.write("=========================================================\n\n")
        f.write("Purpose:\n")
        f.write("  Test whether the 45 km shatter radius can be interpreted as boundary-equivalent\n")
        f.write("  area radius rather than ordinary pre-shatter spatial distance.\n\n")

        f.write("Nominal mixed addendum-like seed:\n")
        for k, v in nominal.items():
            if isinstance(v, float):
                f.write(f"  {k}: {v:.12e}\n")
            else:
                f.write(f"  {k}: {v}\n")

        f.write("\nInterpretation branches:\n")
        for row in branches:
            if row["label"] == "nominal_E1e69_N1e80" and row["convention"] == nominal["convention"]:
                f.write(f"  {row}\n")

        f.write("\nSweep summary:\n")
        for row in summary:
            f.write(f"  {row}\n")

        f.write("\nInverse constraints:\n")
        for row in inverses:
            f.write(f"  {row}\n")

        f.write("\nVerdict:\n")
        for k, v in verdict.items():
            if isinstance(v, float):
                f.write(f"  {k}: {v:.12e}\n")
            else:
                f.write(f"  {k}: {v}\n")

    plot_paths = []
    try:
        import matplotlib.pyplot as plt

        # Plot R_area vs R_causal for sweep.
        add_sweep = [r for r in sweep if r["convention"] == "mixed_addendum_like_cycles_time_a_phi_area"]
        x = [r["R_causal_m"] for r in add_sweep]
        y = [r["R_area_m"] for r in add_sweep]

        plt.figure(figsize=(7, 6))
        plt.scatter(x, y, s=6, alpha=0.35)
        lo = min(min(x), min(y))
        hi = max(max(x), max(y))
        plt.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1)
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("R_causal = c t_shatter (m)")
        plt.ylabel("R_area boundary-equivalent (m)")
        plt.title("Gate 12B: ordinary spatial branch requires points above/below equality")
        plt.tight_layout()
        p = out / "gate12B_Rcausal_vs_Rarea.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        # Histogram compression factor.
        compression = [r["R_area_over_ct"] for r in add_sweep]
        plt.figure(figsize=(8, 5))
        plt.hist(np.log10(compression), bins=60)
        plt.axvline(math.log10(nominal["R_area_over_ct"]), linestyle="--", linewidth=1)
        plt.xlabel("log10(R_area / c t)")
        plt.ylabel("count")
        plt.title("Gate 12B: boundary/spatial compression factor")
        plt.tight_layout()
        p = out / "gate12B_compression_hist.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        # Post-shatter spacing.
        nom_spacing = [r for r in spacing if r["convention"] == nominal["convention"]]
        factors = [r["post_radius_factor_vs_R_area"] for r in nom_spacing]
        spacings = [r["mean_cell_spacing_fm"] for r in nom_spacing]
        plt.figure(figsize=(8, 5))
        plt.plot(factors, spacings, marker="o")
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("post-shatter volume radius / R_area")
        plt.ylabel("mean site spacing (fm)")
        plt.title("Gate 12B: crude post-shatter mean spacing")
        plt.tight_layout()
        p = out / "gate12B_post_shatter_spacing.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")

    return {
        "out_dir": str(out),
        "seed_csv": str(seed_csv),
        "branch_csv": str(branch_csv),
        "spacing_csv": str(spacing_csv),
        "sweep_csv": str(sweep_csv),
        "summary_csv": str(summary_csv),
        "inverse_csv": str(inverse_csv),
        "verdict_csv": str(verdict_csv),
        "report": str(report),
        "plot_paths": plot_paths,
    }


def print_seed(row: dict) -> None:
    keys = [
        "convention",
        "R_area_km",
        "t_shatter_s",
        "R_causal_m",
        "R_causal_fm",
        "light_crossing_time_R_area_s",
        "ct_over_R_area",
        "R_area_over_ct",
        "area_compression_factor",
        "volume_compression_factor",
        "ordinary_spatial_causal_pass",
        "R_area_over_Rs",
        "mean_spacing_if_sites_fill_R_area_fm",
    ]
    for k in keys:
        v = row[k]
        if isinstance(v, float):
            print(f"    {k}: {v:.12e}")
        else:
            print(f"    {k}: {v}")


def main() -> None:
    cfg = Config()
    seeds = main_seed_rows(cfg)
    branches = []
    spacing = []
    for seed in seeds:
        branches.extend(interpret_branch(seed))
        spacing.extend(post_shatter_spacing_rows(cfg, seed))

    sweep = sweep_rows(cfg)
    summary = sweep_summary(sweep)

    nominal = [r for r in seeds if r["convention"] == "mixed_addendum_like_cycles_time_a_phi_area"][0]
    inverses = inverse_constraints(cfg, nominal)
    paths = save_outputs(cfg, seeds, branches, spacing, sweep, summary, inverses)

    print("\nSFT V12 GATE 12B RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Audit whether the pre-shatter radius is ordinary spatial radius or boundary-equivalent area radius.")
    print("  No derivation of a_phi, N, or shatter mechanism is claimed.")

    print("\nNominal seed radius audit:")
    print_seed(nominal)

    print("\nConvention radius/causal comparison:")
    for row in seeds:
        print(f"\n  {row['convention']}")
        print_seed(row)

    print("\nNominal interpretation branches:")
    for row in branches:
        if row["label"] == nominal["label"] and row["convention"] == nominal["convention"]:
            print(f"\n  {row['branch']}")
            print(f"    status: {row['status']}")
            print(f"    primary_metric: {row['primary_metric']}")
            print(f"    value: {row['value']}")
            print(f"    requirement: {row['requirement']}")
            print(f"    interpretation: {row['interpretation']}")

    print("\nPost-shatter spacing diagnostic, nominal convention:")
    for row in spacing:
        if row["convention"] == nominal["convention"]:
            print(f"\n  post_radius_factor_vs_R_area: {row['post_radius_factor_vs_R_area']:.12e}")
            print(f"    post_radius_km: {row['post_radius_km']:.12e}")
            print(f"    mean_cell_spacing_fm: {row['mean_cell_spacing_fm']:.12e}")
            print(f"    number_density_sites_m3: {row['number_density_sites_m3']:.12e}")

    print("\nSweep summary:")
    for row in summary:
        print(f"\n  {row['convention']}")
        print(f"    num_rows: {row['num_rows']}")
        print(f"    num_causal_pass_ct_over_R_ge_1: {row['num_causal_pass_ct_over_R_ge_1']}")
        print(f"    num_near_seed_radius_and_strong_time: {row['num_near_seed_radius_and_strong_time']}")
        print(f"    num_near_seed_and_causal: {row['num_near_seed_and_causal']}")
        print(f"    max_ct_over_R: {row['max_ct_over_R']:.12e}")

    print("\nInverse constraints:")
    for row in inverses:
        print(f"\n  {row['relation']}")
        for k, v in row.items():
            if k == "relation":
                continue
            if isinstance(v, float):
                print(f"    {k}: {v:.12e}")
            else:
                print(f"    {k}: {v}")

    print("\nGate 12B verdict:")
    print("  BOUNDARY_RADIUS_INTERPRETATION_REQUIRED")
    print("  ordinary_spatial_ball: FAIL")
    print("  boundary_equivalent_radius: CONCEPTUAL_PASS_REQUIRES_EXPLICIT_PREGEOMETRIC_WORDING")
    print("  Key sentence: The pre-shatter radius must be called a boundary-equivalent write-area radius,")
    print("  not an ordinary pre-shatter spatial radius.")

    print("\nFiles:")
    print(f"  output directory: {paths['out_dir']}")
    print(f"  report: {paths['report']}")
    print(f"  seed audit csv: {paths['seed_csv']}")
    print(f"  branch audit csv: {paths['branch_csv']}")
    print(f"  post-shatter spacing csv: {paths['spacing_csv']}")
    print(f"  sweep csv: {paths['sweep_csv']}")
    print(f"  summary csv: {paths['summary_csv']}")
    print(f"  inverse constraints csv: {paths['inverse_csv']}")
    print(f"  verdict csv: {paths['verdict_csv']}")
    for p in paths["plot_paths"]:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
