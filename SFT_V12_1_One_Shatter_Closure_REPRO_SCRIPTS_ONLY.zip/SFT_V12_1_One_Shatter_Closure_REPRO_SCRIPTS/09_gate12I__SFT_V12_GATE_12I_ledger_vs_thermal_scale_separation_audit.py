#!/usr/bin/env python3
"""
SFT V12 Gate 12I: Ledger-vs-Thermal Scale Separation Audit

Mobile-ready: embeds the Gate 12G / 12H bridge values directly.
No previous output folder is required.

Purpose
-------
Gate 12H drew the boundary:

    Q(T) is numerically useful only as a non-thermal ledger/spatialization factor.
    If Q(T) is inserted as ordinary local scale-factor expansion, it creates
    BBN/CMB rate risk.

Gate 12I asks the next structural question:

    Can SFT consistently define two scale variables?

        a_T(T) = T_post / T
        a_L(T) = a_T(T) * Q(T)

where:
    a_T is the local thermal/cooling scale,
    a_L is the effective ledger/settlement-geometry scale.

The core survival condition is:

    local photon temperature and reaction clocks track a_T,
    spatial settlement geometry tracks a_L,
    and Q = a_L/a_T is NOT counted as additional local adiabatic cooling.

This is a consistency audit, not a mechanism.

Claim boundary
--------------
This script does NOT:
    - derive Q(T);
    - derive the mechanism separating a_T from a_L;
    - prove BBN/CMB compatibility;
    - derive perturbations, flatness, or inflation replacement.

It DOES:
    - compare single-scale vs two-scale interpretations;
    - quantify the temperature/density penalty if a_L is misread as the thermal scale;
    - audit one-speed wording boundaries;
    - produce the formal scale-separation contract needed for the paper.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
import numpy as np


# -----------------------------
# Embedded Gate 12G / 12H seed
# -----------------------------

SEED = {
    "candidate_name": "thermal_Compton_fixed_kT_equals_hbarc_over_s",
    "spacing_fm": 2.080201237123,
    "R_post_AU": 4.003904729680,
    "kT_post_MeV": 94.85956307390,
    "kT_rec_eV": 2.562193818698e-1,
    "thermal_growth_to_rec": 3.702278975995e8,
    "thermal_efolds_to_rec": 19.72962931345,
    "q_rec": 25.98352226408,
    "q_rec_efolds": 3.257462578037,
    "alpha_power_law": 0.1651051079717,
    "R_thermal_rec_Mly": 0.02343978468746,
    "R_eff_rec_Mly": 0.6090481672918,
    "local_target_max_factor_error": 1.410461571124,
    "constant_alpha_H_eff_over_Hthermal_if_actual_scale": 1.165105107972,
    "constant_alpha_delta_Neff_proxy_if_actual_scale": 2.662151599967,
    "adiabatic_misread_q4_penalty": 4.558186500567e5,
}

LOCAL_TARGETS_MLY = {
    "sound_horizon": 0.4318077002313,
    "hubble_radius": 0.6246982112007,
    "particle_horizon": 0.8375182455706,
}

AU_M = 1.495978707e11
LY_M = 9.4607304725808e15
MLY_M = 1.0e6 * LY_M

OUT_DIR = Path("SFT_V12_GATE_12I_OUTPUT")


# -----------------------------
# Law and scale helpers
# -----------------------------

def Q_power_constant_alpha(kT_MeV: float) -> float:
    """Q=(Tpost/T)^alpha."""
    a_T = SEED["kT_post_MeV"] / kT_MeV
    return a_T ** SEED["alpha_power_law"]


def thermal_markers() -> list[dict]:
    rec_MeV = SEED["kT_rec_eV"] * 1e-6
    raw = [
        ("post_shatter", SEED["kT_post_MeV"], "post-shatter spatialization marker"),
        ("QCD_50MeV", 50.0, "hadronic comparison marker"),
        ("10MeV", 10.0, "early radiation-era comparison marker"),
        ("1MeV_BBNish", 1.0, "BBN-ish comparison marker, not a BBN calculation"),
        ("0p1MeV_BBNish", 0.1, "BBN-ish comparison marker, not a BBN calculation"),
        ("1keV", 1e-3, "keV-era marker"),
        ("1eV", 1e-6, "eV-era marker"),
        ("recombination", rec_MeV, "recombination thermal marker"),
    ]
    rows = []
    for name, mev, note in raw:
        if mev <= SEED["kT_post_MeV"]*(1+1e-12) and mev >= rec_MeV*(1-1e-12):
            rows.append({"marker_name": name, "kT_MeV": mev, "kT_eV": mev*1e6, "note": note})
    return rows


def scale_marker_rows() -> list[dict]:
    rows = []
    for m in thermal_markers():
        kT = m["kT_MeV"]
        a_T = SEED["kT_post_MeV"] / kT
        Q = Q_power_constant_alpha(kT)
        a_L = a_T * Q

        R_th_AU = SEED["R_post_AU"] * a_T
        R_L_AU = SEED["R_post_AU"] * a_L
        R_th_Mly = R_th_AU * AU_M / MLY_M
        R_L_Mly = R_L_AU * AU_M / MLY_M

        # If someone incorrectly ties photon temperature to a_L instead of a_T:
        kT_naive_thermal_from_ledger_MeV = SEED["kT_post_MeV"] / a_L
        temperature_underprediction_factor = kT_naive_thermal_from_ledger_MeV / kT
        temperature_restore_factor = kT / kT_naive_thermal_from_ledger_MeV

        rows.append({
            "marker_name": m["marker_name"],
            "kT_MeV": kT,
            "kT_eV": m["kT_eV"],
            "a_T_thermal_scale": a_T,
            "Q_ledger_over_thermal": Q,
            "a_L_ledger_scale": a_L,
            "ln_a_T": math.log(a_T) if a_T > 0 else math.nan,
            "ln_Q": math.log(Q) if Q > 0 else math.nan,
            "ln_a_L": math.log(a_L) if a_L > 0 else math.nan,
            "R_thermal_AU": R_th_AU,
            "R_ledger_AU": R_L_AU,
            "R_thermal_Mly": R_th_Mly,
            "R_ledger_Mly": R_L_Mly,
            "kT_if_aL_were_thermal_MeV": kT_naive_thermal_from_ledger_MeV,
            "temperature_ratio_if_aL_were_thermal_pred_over_actual": temperature_underprediction_factor,
            "temperature_restore_factor_needed_if_aL_were_thermal": temperature_restore_factor,
            "number_density_restore_factor_Q3_if_aL_were_thermal": Q**3,
            "radiation_density_restore_factor_Q4_if_aL_were_thermal": Q**4,
            "local_microphysics_clock": "tracks_a_T_not_a_L",
            "note": m["note"],
        })
    return rows


def target_comparison_rows() -> list[dict]:
    rows = []
    R_th = SEED["R_thermal_rec_Mly"]
    R_L = SEED["R_eff_rec_Mly"]

    for name, target in LOCAL_TARGETS_MLY.items():
        thermal_ratio = R_th / target
        ledger_ratio = R_L / target
        rows.append({
            "target_name": name,
            "R_target_Mly": target,
            "R_thermal_rec_Mly": R_th,
            "R_ledger_rec_Mly": R_L,
            "thermal_pred_over_target": thermal_ratio,
            "thermal_factor_error": max(thermal_ratio, 1.0/thermal_ratio),
            "ledger_pred_over_target": ledger_ratio,
            "ledger_factor_error": max(ledger_ratio, 1.0/ledger_ratio),
            "interpretation": "pure thermal scale misses; ledger scale fits local recombination targets within toy tolerance",
        })
    return rows


def branch_rows() -> list[dict]:
    rec = [r for r in scale_marker_rows() if r["marker_name"] == "recombination"][0]
    target_rows = target_comparison_rows()
    max_thermal_error = max(r["thermal_factor_error"] for r in target_rows)
    max_ledger_error = max(r["ledger_factor_error"] for r in target_rows)

    branches = [
        {
            "branch": "single_scale_pure_thermal_aL_equals_aT",
            "status": "FAILS_RECOMBINATION_GEOMETRY",
            "a_T_rec": rec["a_T_thermal_scale"],
            "Q_rec": 1.0,
            "a_L_rec": rec["a_T_thermal_scale"],
            "R_rec_Mly": SEED["R_thermal_rec_Mly"],
            "max_local_target_factor_error": max_thermal_error,
            "thermal_temperature_preserved": True,
            "local_clock_changed_by_Q": False,
            "one_speed_wording": "ordinary local thermal scale only; no ledger bridge",
            "interpretation": "Preserves thermal history but underreaches recombination local geometry.",
        },
        {
            "branch": "single_scale_ledger_aL_as_thermal_scale",
            "status": "FAILS_THERMAL_TEMPERATURE_AND_REHEATING_BOOKKEEPING",
            "a_T_rec": rec["a_T_thermal_scale"],
            "Q_rec": rec["Q_ledger_over_thermal"],
            "a_L_rec": rec["a_L_ledger_scale"],
            "R_rec_Mly": SEED["R_eff_rec_Mly"],
            "max_local_target_factor_error": max_ledger_error,
            "thermal_temperature_preserved": False,
            "local_clock_changed_by_Q": True,
            "temperature_pred_over_actual_at_rec": rec["temperature_ratio_if_aL_were_thermal_pred_over_actual"],
            "temperature_restore_factor_at_rec": rec["temperature_restore_factor_needed_if_aL_were_thermal"],
            "radiation_density_restore_factor_at_rec_Q4": rec["radiation_density_restore_factor_Q4_if_aL_were_thermal"],
            "one_speed_wording": "naive expansion reinterpretation; not allowed as final SFT claim",
            "interpretation": "Fits geometry but would overcool photons by Q and requires large reheating/entropy bookkeeping.",
        },
        {
            "branch": "two_scale_nonthermal_ledger_map",
            "status": "FORMAL_PASS_MECHANISM_OPEN",
            "a_T_rec": rec["a_T_thermal_scale"],
            "Q_rec": rec["Q_ledger_over_thermal"],
            "a_L_rec": rec["a_L_ledger_scale"],
            "R_rec_Mly": SEED["R_eff_rec_Mly"],
            "max_local_target_factor_error": max_ledger_error,
            "thermal_temperature_preserved": True,
            "local_clock_changed_by_Q": False,
            "H_for_BBN_microphysics_over_Hthermal": 1.0,
            "one_speed_wording": "local one-speed physics remains local; Q maps settlement geometry, not particle transport",
            "interpretation": "This is the surviving SFT contract: a_T controls thermal clocks, a_L controls effective settlement geometry.",
        },
        {
            "branch": "actual_local_expansion_rate_Q",
            "status": "RATE_RISK_FROM_GATE_12H",
            "a_T_rec": rec["a_T_thermal_scale"],
            "Q_rec": rec["Q_ledger_over_thermal"],
            "a_L_rec": rec["a_L_ledger_scale"],
            "R_rec_Mly": SEED["R_eff_rec_Mly"],
            "max_local_target_factor_error": max_ledger_error,
            "thermal_temperature_preserved": "ambiguous_or_no",
            "local_clock_changed_by_Q": True,
            "H_eff_over_Hthermal_if_actual_scale": SEED["constant_alpha_H_eff_over_Hthermal_if_actual_scale"],
            "delta_Neff_proxy_if_actual_scale": SEED["constant_alpha_delta_Neff_proxy_if_actual_scale"],
            "one_speed_wording": "turns Q into ordinary expansion-rate change; high BBN/CMB risk",
            "interpretation": "Numerically fits geometry but should not be used without real BBN/CMB treatment.",
        },
    ]
    return branches


def scale_separation_contract_rows() -> list[dict]:
    return [
        {
            "contract_item": "thermal_scale_definition",
            "symbol": "a_T(T)",
            "definition": "a_T = T_post / T",
            "role": "controls photon temperature, local thermal clocks, and reaction microphysics",
            "status": "REQUIRED",
        },
        {
            "contract_item": "ledger_scale_definition",
            "symbol": "a_L(T)",
            "definition": "a_L = a_T Q(T)",
            "role": "controls effective spatial settlement / ledger geometry",
            "status": "REQUIRED",
        },
        {
            "contract_item": "separation_factor",
            "symbol": "Q(T)",
            "definition": "Q = a_L/a_T",
            "role": "non-thermal settlement geometry stretch",
            "status": "MECHANISM_OPEN",
        },
        {
            "contract_item": "forbidden_identification",
            "symbol": "T = T_post/a_L",
            "definition": "identifies ledger scale as photon cooling scale",
            "role": "overcools photons by Q and creates reheating/entropy bill",
            "status": "FORBIDDEN_FOR_FINAL_CLAIM",
        },
        {
            "contract_item": "one_speed_boundary",
            "symbol": "c_local",
            "definition": "local one-speed physics is evaluated in local thermal/metric frame",
            "role": "Q is not ordinary particle transport through pre-existing space",
            "status": "REQUIRED_WORDING",
        },
        {
            "contract_item": "mechanism_debt",
            "symbol": "Q_mech",
            "definition": "rule that maps thermal ledger to settlement geometry without changing local thermal clock",
            "role": "future derivation/gate",
            "status": "OPEN",
        },
    ]


def consistency_matrix_rows() -> list[dict]:
    branches = branch_rows()
    tests = [
        ("fits_local_recombination_geometry", lambda b: b.get("max_local_target_factor_error", 999) <= 2.0),
        ("preserves_photon_temperature", lambda b: b.get("thermal_temperature_preserved") is True),
        ("does_not_change_BBN_micro_clock", lambda b: b.get("local_clock_changed_by_Q") is False),
        ("avoids_reheating_penalty", lambda b: b.get("radiation_density_restore_factor_at_rec_Q4", 1.0) < 10.0),
        ("keeps_Q_non_transport", lambda b: "not particle transport" in str(b.get("one_speed_wording", "")) or b["branch"] == "two_scale_nonthermal_ledger_map"),
    ]
    rows = []
    for b in branches:
        passed = 0
        for test_name, fn in tests:
            ok = bool(fn(b))
            if ok:
                passed += 1
            rows.append({
                "branch": b["branch"],
                "test": test_name,
                "pass": ok,
                "status": b["status"],
            })
        rows.append({
            "branch": b["branch"],
            "test": "total_pass_count",
            "pass": passed,
            "status": b["status"],
        })
    return rows


def verdict_row() -> dict:
    branches = branch_rows()
    two = next(b for b in branches if b["branch"] == "two_scale_nonthermal_ledger_map")
    single_thermal = next(b for b in branches if b["branch"] == "single_scale_pure_thermal_aL_equals_aT")
    single_ledger = next(b for b in branches if b["branch"] == "single_scale_ledger_aL_as_thermal_scale")
    actual_rate = next(b for b in branches if b["branch"] == "actual_local_expansion_rate_Q")

    return {
        "verdict": "TWO_SCALE_LEDGER_THERMAL_SEPARATION_FORMALLY_CONSISTENT_MECHANISM_OPEN",
        "claim_boundary": "formal consistency audit only; no physical mechanism, BBN/CMB fit, perturbations, flatness, or inflation replacement derived",
        "a_T_rec": two["a_T_rec"],
        "Q_rec": two["Q_rec"],
        "a_L_rec": two["a_L_rec"],
        "R_thermal_rec_Mly": SEED["R_thermal_rec_Mly"],
        "R_ledger_rec_Mly": SEED["R_eff_rec_Mly"],
        "two_scale_local_target_max_factor_error": two["max_local_target_factor_error"],
        "single_thermal_local_target_max_factor_error": single_thermal["max_local_target_factor_error"],
        "single_ledger_temperature_restore_factor_rec": single_ledger["temperature_restore_factor_at_rec"],
        "single_ledger_radiation_density_penalty_Q4_rec": single_ledger["radiation_density_restore_factor_at_rec_Q4"],
        "actual_rate_H_eff_over_Hthermal": actual_rate["H_eff_over_Hthermal_if_actual_scale"],
        "actual_rate_delta_Neff_proxy": actual_rate["delta_Neff_proxy_if_actual_scale"],
        "mechanism_debt": "derive or motivate Q as a settlement-geometry mapping that does not alter the local thermal clock",
        "key_sentence": (
            "Gate 12I formalizes the surviving contract: a_T=T_post/T controls local thermal physics, "
            "while a_L=a_T Q(T) controls effective settlement geometry. Identifying a_L with the photon "
            "cooling scale overcools the plasma by Q and carries a Q^4 reheating penalty; inserting Q as "
            "ordinary local expansion-rate change reproduces the Gate 12H BBN/CMB rate risk. Therefore "
            "the only viable reading is a two-scale non-thermal ledger map, with the mechanism still open."
        ),
    }


# -----------------------------
# Output helpers
# -----------------------------

def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def save_plots(markers: list[dict], branches: list[dict]) -> list[str]:
    paths = []
    try:
        import matplotlib.pyplot as plt

        names = [r["marker_name"] for r in markers]
        x = np.arange(len(names))

        plt.figure(figsize=(10, 5))
        plt.plot(x, [r["a_T_thermal_scale"] for r in markers], marker="o", label="a_T thermal")
        plt.plot(x, [r["a_L_ledger_scale"] for r in markers], marker="s", label="a_L ledger")
        plt.plot(x, [r["Q_ledger_over_thermal"] for r in markers], marker="^", label="Q=a_L/a_T")
        plt.yscale("log")
        plt.xticks(x, names, rotation=45, ha="right")
        plt.ylabel("scale factor")
        plt.title("Gate 12I: thermal scale vs ledger scale")
        plt.legend()
        plt.tight_layout()
        p = OUT_DIR / "gate12I_scale_separation.png"
        plt.savefig(p, dpi=160)
        plt.close()
        paths.append(str(p))

        plt.figure(figsize=(10, 5))
        plt.plot(x, [r["radiation_density_restore_factor_Q4_if_aL_were_thermal"] for r in markers], marker="o")
        plt.yscale("log")
        plt.xticks(x, names, rotation=45, ha="right")
        plt.ylabel("Q^4 penalty")
        plt.title("Gate 12I: reheating penalty if ledger scale is misread as thermal")
        plt.tight_layout()
        p = OUT_DIR / "gate12I_Q4_penalty.png"
        plt.savefig(p, dpi=160)
        plt.close()
        paths.append(str(p))

        target_rows = target_comparison_rows()
        labels = [r["target_name"] for r in target_rows]
        xpos = np.arange(len(labels))
        width = 0.35
        plt.figure(figsize=(9, 5))
        plt.bar(xpos - width/2, [r["thermal_factor_error"] for r in target_rows], width, label="pure thermal")
        plt.bar(xpos + width/2, [r["ledger_factor_error"] for r in target_rows], width, label="ledger")
        plt.yscale("log")
        plt.axhline(2.0, linestyle="--", linewidth=1)
        plt.xticks(xpos, labels, rotation=20, ha="right")
        plt.ylabel("factor error")
        plt.title("Gate 12I: target fit improvement from ledger scale")
        plt.legend()
        plt.tight_layout()
        p = OUT_DIR / "gate12I_target_factor_errors.png"
        plt.savefig(p, dpi=160)
        plt.close()
        paths.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")

    return paths


def print_kv(row: dict, keys=None, indent="  ") -> None:
    items = row.items() if keys is None else [(k, row[k]) for k in keys]
    for k, v in items:
        if isinstance(v, float):
            print(f"{indent}{k}: {v:.12e}")
        else:
            print(f"{indent}{k}: {v}")


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    markers = scale_marker_rows()
    targets = target_comparison_rows()
    branches = branch_rows()
    contract = scale_separation_contract_rows()
    matrix = consistency_matrix_rows()
    verdict = verdict_row()
    plots = save_plots(markers, branches)

    write_csv(OUT_DIR / "gate12I_seed.csv", [SEED])
    write_csv(OUT_DIR / "gate12I_scale_marker_rows.csv", markers)
    write_csv(OUT_DIR / "gate12I_target_comparison.csv", targets)
    write_csv(OUT_DIR / "gate12I_interpretation_branches.csv", branches)
    write_csv(OUT_DIR / "gate12I_scale_separation_contract.csv", contract)
    write_csv(OUT_DIR / "gate12I_consistency_matrix.csv", matrix)
    write_csv(OUT_DIR / "gate12I_verdict.csv", [verdict])

    report = OUT_DIR / "gate12I_ledger_vs_thermal_scale_separation_report.txt"
    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12I: Ledger-vs-Thermal Scale Separation Audit\n")
        f.write("==========================================================\n\n")
        f.write("Seed:\n")
        for k, v in SEED.items():
            f.write(f"  {k}: {v}\n")
        f.write("\nScale markers:\n")
        for row in markers:
            f.write(f"  {row}\n")
        f.write("\nBranches:\n")
        for row in branches:
            f.write(f"  {row}\n")
        f.write("\nContract:\n")
        for row in contract:
            f.write(f"  {row}\n")
        f.write("\nVerdict:\n")
        for k, v in verdict.items():
            f.write(f"  {k}: {v}\n")

    print("\nSFT V12 GATE 12I RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Ledger-vs-thermal scale separation audit.")
    print("  No physical Q mechanism, BBN/CMB fit, perturbations, flatness, or inflation replacement is claimed.")

    print("\nSeed:")
    print_kv(SEED, [
        "candidate_name", "spacing_fm", "R_post_AU", "kT_post_MeV",
        "thermal_efolds_to_rec", "q_rec", "alpha_power_law",
        "R_thermal_rec_Mly", "R_eff_rec_Mly",
    ])

    print("\nScale marker rows:")
    for row in markers:
        print(f"\n  {row['marker_name']}")
        print_kv(row, [
            "kT_MeV",
            "a_T_thermal_scale",
            "Q_ledger_over_thermal",
            "a_L_ledger_scale",
            "R_thermal_Mly",
            "R_ledger_Mly",
            "kT_if_aL_were_thermal_MeV",
            "temperature_ratio_if_aL_were_thermal_pred_over_actual",
            "temperature_restore_factor_needed_if_aL_were_thermal",
            "radiation_density_restore_factor_Q4_if_aL_were_thermal",
        ], indent="    ")

    print("\nLocal target comparison:")
    for row in targets:
        print(f"\n  {row['target_name']}")
        print_kv(row, [
            "R_target_Mly",
            "R_thermal_rec_Mly",
            "thermal_factor_error",
            "R_ledger_rec_Mly",
            "ledger_factor_error",
        ], indent="    ")

    print("\nInterpretation branches:")
    for row in branches:
        print(f"\n  {row['branch']}")
        print_kv(row, [
            "status",
            "a_T_rec",
            "Q_rec",
            "a_L_rec",
            "R_rec_Mly",
            "max_local_target_factor_error",
            "thermal_temperature_preserved",
            "local_clock_changed_by_Q",
            "one_speed_wording",
            "interpretation",
        ], indent="    ")

    print("\nScale-separation contract:")
    for row in contract:
        print(f"\n  {row['contract_item']}")
        print_kv(row, ["symbol", "definition", "role", "status"], indent="    ")

    print("\nGate 12I verdict:")
    print_kv(verdict)

    print("\nFiles:")
    print(f"  output directory: {OUT_DIR}")
    print(f"  report: {report}")
    print(f"  seed csv: {OUT_DIR / 'gate12I_seed.csv'}")
    print(f"  scale markers csv: {OUT_DIR / 'gate12I_scale_marker_rows.csv'}")
    print(f"  target comparison csv: {OUT_DIR / 'gate12I_target_comparison.csv'}")
    print(f"  branches csv: {OUT_DIR / 'gate12I_interpretation_branches.csv'}")
    print(f"  contract csv: {OUT_DIR / 'gate12I_scale_separation_contract.csv'}")
    print(f"  consistency matrix csv: {OUT_DIR / 'gate12I_consistency_matrix.csv'}")
    print(f"  verdict csv: {OUT_DIR / 'gate12I_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
