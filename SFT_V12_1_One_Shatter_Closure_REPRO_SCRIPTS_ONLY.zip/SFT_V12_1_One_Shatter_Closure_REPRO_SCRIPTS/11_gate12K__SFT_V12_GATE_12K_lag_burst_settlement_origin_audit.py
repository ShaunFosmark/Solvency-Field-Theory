#!/usr/bin/env python3
"""
SFT V12 Gate 12K: Lag-Burst Settlement Origin of Q(T)

Mobile-ready: embeds Gates 12G-12J values directly.
No previous output folder is required.

Purpose
-------
Gates 12G-12J found a viable post-shatter two-scale bookkeeping map:

    a_T(T) = T_post / T
    a_L(T) = a_T(T) Q(T)

with best fitted law:

    Q(T) = a_T^alpha
    alpha_fit ~= 0.165105
    q_rec ~= 25.9835

Gate 12K tests the new lag-burst mechanism candidate:

    Before shatter, the unified process ticks but has no spatial boundary to
    write to, so unresolved phase / settlement lag accumulates.

    The accumulated lag stress triggers shatter.

    The pent-up writes settle as boundary/spatial meaning.

    Q(T) is the continued relaxation of that initial lag burst.

The no-cheat question:

    Can alpha ~= 0.165 be explained by a simple SFT-native settlement rule,
    rather than inserted as a free fit parameter?

Key observation
---------------
Gate 12J showed:

    settlement volume ratio = V_L/V_T = Q^3

If Q = a_T^alpha, then:

    V_L/V_T = a_T^(3 alpha)

The fitted alpha gives:

    3 alpha_fit ~= 0.495315

which is very close to:

    1/2

That suggests the clean candidate:

    Q^3 = a_T^(1/2)
    Q = a_T^(1/6)
    alpha = 1/6

Interpretation candidate:
    post-shatter settlement volume relaxes like a square-root / diffusion-like
    lag reservoir relative to thermal expansion.

Claim boundary
--------------
This script DOES NOT prove the lag-burst mechanism.

It tests whether:
    - alpha=1/6 predicts the Gate 12G/12J q_rec without fitting;
    - the resulting recombination geometry remains within the prior local target window;
    - alternative simple exponents are worse;
    - the square-root settlement-volume rule is numerically plausible.

Verdict can only be:
    source hint / candidate mechanism, not derivation.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
import numpy as np


# -----------------------------
# Embedded Line 1 seed
# -----------------------------

SEED = {
    "candidate_name": "thermal_Compton_fixed_kT_equals_hbarc_over_s",
    "spacing_fm": 2.080201237123,
    "R_post_AU": 4.003904729680,
    "kT_post_MeV": 94.85956307390,
    "kT_rec_eV": 2.562193818698e-1,
    "thermal_growth_to_rec": 3.702278975995e8,
    "thermal_efolds_to_rec": 19.72962931345,
    "q_rec_fit": 25.98352226410,
    "q_rec_efolds_fit": 3.257462578037,
    "alpha_fit": 0.1651051079717,
    "R_thermal_rec_Mly": 0.02343978468746,
    "R_ledger_rec_Mly_fit": 0.6090481672918,
    "local_target_max_factor_error_fit": 1.410461571124,
    "actual_rate_H_eff_over_Hthermal_fit_if_misread": 1.165105107972,
    "actual_rate_delta_Neff_proxy_fit_if_misread": 2.662151599967,
}

LOCAL_TARGETS_MLY = {
    "sound_horizon": 0.4318077002313,
    "hubble_radius": 0.6246982112007,
    "particle_horizon": 0.8375182455706,
}

OUT_DIR = Path("SFT_V12_GATE_12K_OUTPUT")

N_EFF_REF = 3.044
NEFF_FACTOR = 0.22710731766


# -----------------------------
# Basic helpers
# -----------------------------

def delta_neff_proxy(H_ratio: float) -> float:
    total_factor = 1.0 + NEFF_FACTOR * N_EFF_REF
    return ((H_ratio**2 - 1.0) * total_factor) / NEFF_FACTOR


def q_from_alpha(alpha: float, a_T: float = SEED["thermal_growth_to_rec"]) -> float:
    return a_T ** alpha


def alpha_from_mu(mu: float) -> float:
    """mu is settlement volume exponent: Q^3 = a_T^mu."""
    return mu / 3.0


def target_factor_errors(R_rec_Mly: float) -> tuple[dict, float]:
    rows = {}
    factors = []
    for name, target in LOCAL_TARGETS_MLY.items():
        pred_over = R_rec_Mly / target
        factor = max(pred_over, 1.0 / pred_over)
        rows[name] = {
            "pred_over_target": pred_over,
            "factor_error": factor,
        }
        factors.append(factor)
    return rows, max(factors)


def rational_name(x: float) -> str:
    if abs(x - 1/6) < 1e-12:
        return "one_sixth"
    if abs(x - 1/5) < 1e-12:
        return "one_fifth"
    if abs(x - 1/7) < 1e-12:
        return "one_seventh"
    if abs(x - 1/8) < 1e-12:
        return "one_eighth"
    if abs(x - 1/(2*math.pi)) < 1e-12:
        return "one_over_2pi"
    return f"{x:.8g}"


# -----------------------------
# Alpha candidate audit
# -----------------------------

def alpha_candidates() -> list[dict]:
    """
    Candidate alphas include:
      - fitted alpha from Gate 12G (control, not a derivation)
      - alpha=1/6 from Q^3=a_T^1/2
      - nearby simple rationals/geometric constants for falsification context
    """
    return [
        {
            "candidate_id": "fit_alpha_from_gate12G",
            "alpha": SEED["alpha_fit"],
            "source_rule": "fit control: alpha=ln(q_rec)/ln(a_T_rec)",
            "status": "FITTED_CONTROL_NOT_MECHANISM",
        },
        {
            "candidate_id": "lag_volume_sqrt_alpha_1_over_6",
            "alpha": 1.0 / 6.0,
            "source_rule": "Q^3=a_T^(1/2), settlement volume relaxes as square-root of thermal scale",
            "status": "NO_CHEAT_CANDIDATE",
        },
        {
            "candidate_id": "lag_volume_two_fifths_alpha_2_over_15",
            "alpha": 2.0 / 15.0,
            "source_rule": "Q^3=a_T^(2/5), lower rational settlement-volume exponent",
            "status": "COMPARISON",
        },
        {
            "candidate_id": "lag_volume_one_third_alpha_1_over_9",
            "alpha": 1.0 / 9.0,
            "source_rule": "Q^3=a_T^(1/3), weak settlement-volume relaxation",
            "status": "COMPARISON",
        },
        {
            "candidate_id": "lag_volume_two_thirds_alpha_2_over_9",
            "alpha": 2.0 / 9.0,
            "source_rule": "Q^3=a_T^(2/3), strong settlement-volume relaxation",
            "status": "COMPARISON",
        },
        {
            "candidate_id": "alpha_1_over_5",
            "alpha": 1.0 / 5.0,
            "source_rule": "simple nearby rational",
            "status": "COMPARISON",
        },
        {
            "candidate_id": "alpha_1_over_7",
            "alpha": 1.0 / 7.0,
            "source_rule": "simple nearby rational",
            "status": "COMPARISON",
        },
        {
            "candidate_id": "alpha_1_over_8",
            "alpha": 1.0 / 8.0,
            "source_rule": "simple nearby rational",
            "status": "COMPARISON",
        },
        {
            "candidate_id": "alpha_1_over_2pi",
            "alpha": 1.0 / (2.0 * math.pi),
            "source_rule": "geometric comparison constant",
            "status": "COMPARISON_NUMEROLOGY_UNLESS_DERIVED",
        },
    ]


def alpha_candidate_rows() -> list[dict]:
    rows = []
    a_T = SEED["thermal_growth_to_rec"]
    q_fit = SEED["q_rec_fit"]
    R_th = SEED["R_thermal_rec_Mly"]

    for c in alpha_candidates():
        alpha = c["alpha"]
        q = q_from_alpha(alpha, a_T)
        R_rec = R_th * q
        target_rows, max_factor = target_factor_errors(R_rec)
        mu = 3.0 * alpha

        q_ratio_to_fit = q / q_fit
        alpha_abs_err = alpha - SEED["alpha_fit"]
        alpha_rel_err = alpha_abs_err / SEED["alpha_fit"]
        mu_abs_err_to_half = mu - 0.5
        mu_rel_err_to_half = mu_abs_err_to_half / 0.5

        if max_factor <= 1.5 and abs(q_ratio_to_fit - 1.0) <= 0.05:
            verdict = "PASSES_PRIOR_GEOMETRY_AND_Q_WITHIN_5_PERCENT"
        elif max_factor <= 2.0:
            verdict = "PASSES_LOCAL_GEOMETRY_WITHIN_FACTOR_2"
        else:
            verdict = "FAILS_LOCAL_GEOMETRY_WINDOW"

        rows.append({
            "candidate_id": c["candidate_id"],
            "alpha": alpha,
            "mu_volume_exponent_3alpha": mu,
            "q_rec_pred": q,
            "q_fit": q_fit,
            "q_pred_over_fit": q_ratio_to_fit,
            "q_percent_error_vs_fit": 100.0 * (q_ratio_to_fit - 1.0),
            "R_rec_Mly_pred": R_rec,
            "sound_pred_over_target": target_rows["sound_horizon"]["pred_over_target"],
            "hubble_pred_over_target": target_rows["hubble_radius"]["pred_over_target"],
            "particle_pred_over_target": target_rows["particle_horizon"]["pred_over_target"],
            "max_local_target_factor_error": max_factor,
            "alpha_abs_error_vs_fit": alpha_abs_err,
            "alpha_percent_error_vs_fit": 100.0 * alpha_rel_err,
            "mu_abs_error_to_one_half": mu_abs_err_to_half,
            "mu_percent_error_to_one_half": 100.0 * mu_rel_err_to_half,
            "H_eff_over_Hthermal_if_misread_actual_expansion": 1.0 + alpha,
            "delta_Neff_proxy_if_misread_actual_expansion": delta_neff_proxy(1.0 + alpha),
            "Q2_area_ratio": q**2,
            "Q3_volume_ratio": q**3,
            "Q4_forbidden_radiation_penalty_if_thermal": q**4,
            "source_rule": c["source_rule"],
            "source_status": c["status"],
            "verdict": verdict,
        })

    return sorted(rows, key=lambda r: (
        0 if r["candidate_id"] == "lag_volume_sqrt_alpha_1_over_6" else 1,
        abs(r["q_pred_over_fit"] - 1.0),
    ))


# -----------------------------
# Lag reservoir model audit
# -----------------------------

def lag_reservoir_rows() -> list[dict]:
    """
    Test toy reservoir laws. These are mechanism candidates, not derivations.

    Let L be unresolved lag, and let S be settled spatial volume.
    We only audit exponent consequences:

        Q^3 = a_T^mu
        alpha = mu/3

    The square-root settlement candidate is mu=1/2.
    """
    models = [
        {
            "model_id": "free_fit_lag_rate",
            "mu": 3.0 * SEED["alpha_fit"],
            "law": "Q^3=a_T^(3 alpha_fit)",
            "mechanism_reading": "fits Gate 12G exactly; no mechanism",
            "source_status": "FITTED_CONTROL_NOT_MECHANISM",
        },
        {
            "model_id": "diffusive_square_root_settlement",
            "mu": 0.5,
            "law": "Q^3=sqrt(a_T)",
            "mechanism_reading": "settlement volume grows as square-root of thermal expansion progress",
            "source_status": "BEST_NO_CHEAT_HINT",
        },
        {
            "model_id": "linear_settlement_volume",
            "mu": 1.0,
            "law": "Q^3=a_T",
            "mechanism_reading": "settlement volume tracks thermal volume directly",
            "source_status": "COMPARISON_TOO_STRONG",
        },
        {
            "model_id": "area_like_one_third",
            "mu": 1.0 / 3.0,
            "law": "Q^3=a_T^(1/3)",
            "mechanism_reading": "weak subdiffusive settlement",
            "source_status": "COMPARISON_WEAK",
        },
        {
            "model_id": "two_thirds_strong_sublinear",
            "mu": 2.0 / 3.0,
            "law": "Q^3=a_T^(2/3)",
            "mechanism_reading": "strong sublinear settlement",
            "source_status": "COMPARISON_STRONG",
        },
        {
            "model_id": "quarter_power_volume",
            "mu": 0.25,
            "law": "Q^3=a_T^(1/4)",
            "mechanism_reading": "very weak relaxation",
            "source_status": "COMPARISON_TOO_WEAK",
        },
    ]

    rows = []
    for m in models:
        alpha = m["mu"] / 3.0
        q = q_from_alpha(alpha)
        R_rec = SEED["R_thermal_rec_Mly"] * q
        target_rows, max_factor = target_factor_errors(R_rec)

        if max_factor <= 1.5:
            status = "GEOMETRY_PASS_STRONG"
        elif max_factor <= 2.0:
            status = "GEOMETRY_PASS_FACTOR_2"
        else:
            status = "GEOMETRY_FAIL"

        rows.append({
            "model_id": m["model_id"],
            "mu_volume_exponent": m["mu"],
            "alpha": alpha,
            "law": m["law"],
            "q_rec_pred": q,
            "q_pred_over_fit": q / SEED["q_rec_fit"],
            "R_rec_Mly_pred": R_rec,
            "max_local_target_factor_error": max_factor,
            "sound_pred_over_target": target_rows["sound_horizon"]["pred_over_target"],
            "hubble_pred_over_target": target_rows["hubble_radius"]["pred_over_target"],
            "particle_pred_over_target": target_rows["particle_horizon"]["pred_over_target"],
            "Q3_volume_ratio": q**3,
            "Q4_forbidden_radiation_penalty_if_thermal": q**4,
            "mechanism_reading": m["mechanism_reading"],
            "source_status": m["source_status"],
            "geometry_status": status,
        })

    return sorted(rows, key=lambda r: (
        0 if r["model_id"] == "diffusive_square_root_settlement" else 1,
        r["max_local_target_factor_error"],
    ))


# -----------------------------
# Marker predictions for alpha=1/6
# -----------------------------

def marker_rows_for_alpha(alpha: float, label: str) -> list[dict]:
    rec_MeV = SEED["kT_rec_eV"] * 1e-6
    markers = [
        ("post_shatter", SEED["kT_post_MeV"]),
        ("QCD_50MeV", 50.0),
        ("10MeV", 10.0),
        ("1MeV_BBNish", 1.0),
        ("0p1MeV_BBNish", 0.1),
        ("1keV", 1e-3),
        ("1eV", 1e-6),
        ("recombination", rec_MeV),
    ]

    rows = []
    for name, kT in markers:
        if kT > SEED["kT_post_MeV"] * (1.0 + 1e-12) or kT < rec_MeV * (1.0 - 1e-12):
            continue
        a_T = SEED["kT_post_MeV"] / kT
        Q = a_T ** alpha
        a_L = a_T * Q
        rows.append({
            "law_label": label,
            "marker_name": name,
            "kT_MeV": kT,
            "a_T": a_T,
            "Q": Q,
            "a_L": a_L,
            "Q2_area": Q**2,
            "Q3_volume": Q**3,
            "Q4_forbidden_radiation_penalty_if_thermal": Q**4,
            "settlement_density_ratio_Qminus3": Q**-3,
            "alpha": alpha,
            "mu_volume_exponent": 3.0 * alpha,
        })
    return rows


# -----------------------------
# Verdict
# -----------------------------

def verdict_row(alpha_rows: list[dict], reservoir_rows: list[dict]) -> dict:
    one_sixth = next(r for r in alpha_rows if r["candidate_id"] == "lag_volume_sqrt_alpha_1_over_6")
    fit = next(r for r in alpha_rows if r["candidate_id"] == "fit_alpha_from_gate12G")
    sqrt_model = next(r for r in reservoir_rows if r["model_id"] == "diffusive_square_root_settlement")

    # Decide result.
    if one_sixth["max_local_target_factor_error"] <= 1.5 and abs(one_sixth["q_pred_over_fit"] - 1.0) <= 0.05:
        verdict = "ALPHA_ONE_SIXTH_SQRT_SETTLEMENT_MATCHES_Q_NUMERICALLY_MECHANISM_NOT_DERIVED"
    elif one_sixth["max_local_target_factor_error"] <= 2.0:
        verdict = "ALPHA_ONE_SIXTH_PASSES_LOCAL_GEOMETRY_BUT_Q_MATCH_WEAKER"
    else:
        verdict = "ALPHA_ONE_SIXTH_FAILS_LOCAL_GEOMETRY"

    return {
        "verdict": verdict,
        "claim_boundary": "no-cheat source-hint audit only; lag-burst mechanism and V11.1B derivation are not proven",
        "alpha_fit_from_gate12G": SEED["alpha_fit"],
        "mu_fit_3alpha": 3.0 * SEED["alpha_fit"],
        "mu_fit_error_to_one_half": 3.0 * SEED["alpha_fit"] - 0.5,
        "mu_fit_percent_error_to_one_half": 100.0 * ((3.0 * SEED["alpha_fit"] - 0.5) / 0.5),
        "alpha_candidate_one_sixth": 1.0 / 6.0,
        "alpha_one_sixth_percent_error_vs_fit": one_sixth["alpha_percent_error_vs_fit"],
        "q_fit": SEED["q_rec_fit"],
        "q_one_sixth_pred": one_sixth["q_rec_pred"],
        "q_one_sixth_pred_over_fit": one_sixth["q_pred_over_fit"],
        "R_rec_one_sixth_Mly": one_sixth["R_rec_Mly_pred"],
        "one_sixth_max_local_target_factor_error": one_sixth["max_local_target_factor_error"],
        "one_sixth_Q3_volume_ratio": one_sixth["Q3_volume_ratio"],
        "one_sixth_Q4_forbidden_penalty": one_sixth["Q4_forbidden_radiation_penalty_if_thermal"],
        "surviving_candidate_rule": "Q^3=sqrt(a_T), equivalently Q=a_T^(1/6)",
        "lag_burst_reading": "initial unwritten phase/settlement lag relaxes as settlement volume square-root relative to thermal scale",
        "actual_expansion_warning": "if alpha=1/6 is misread as local Friedmann expansion, H/Hthermal=1.1667 and BBN/CMB rate risk remains",
        "next_required_test": "connect square-root settlement law to V11.1B lag diffusion/stress dynamics or no-overwrite boundary service",
        "key_sentence": (
            "Gate 12K finds a non-fitted source hint: the fitted exponent satisfies 3 alpha = "
            f"{3.0 * SEED['alpha_fit']:.6f}, within {abs(100.0*((3.0*SEED['alpha_fit']-0.5)/0.5)):.3f}% of 1/2. "
            "The simple rule Q^3=sqrt(a_T), or Q=a_T^(1/6), predicts the recombination stretch within a few percent "
            "and keeps the local recombination geometry inside the prior factor-window. This is a strong lag-burst "
            "settlement clue, not yet a derivation."
        ),
    }


# -----------------------------
# Output
# -----------------------------

def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_plots(alpha_rows: list[dict], marker_rows: list[dict]) -> list[str]:
    plots = []
    try:
        import matplotlib.pyplot as plt

        # Alpha candidate geometry error.
        rows = [r for r in alpha_rows if r["candidate_id"] != "fit_alpha_from_gate12G"]
        labels = [r["candidate_id"] for r in rows]
        x = np.arange(len(labels))
        plt.figure(figsize=(12, 5))
        plt.scatter(x, [r["max_local_target_factor_error"] for r in rows])
        plt.axhline(1.5, linestyle="--", linewidth=1)
        plt.axhline(2.0, linestyle=":", linewidth=1)
        plt.xticks(x, labels, rotation=65, ha="right", fontsize=7)
        plt.ylabel("max local target factor error")
        plt.title("Gate 12K: no-cheat alpha candidate geometry error")
        plt.tight_layout()
        p = OUT_DIR / "gate12K_alpha_candidate_factor_errors.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # q predicted vs fit.
        plt.figure(figsize=(12, 5))
        plt.scatter(x, [r["q_pred_over_fit"] for r in rows])
        plt.axhline(1.0, linestyle="-", linewidth=1)
        plt.axhline(1.05, linestyle="--", linewidth=1)
        plt.axhline(0.95, linestyle="--", linewidth=1)
        plt.xticks(x, labels, rotation=65, ha="right", fontsize=7)
        plt.ylabel("q_pred / q_fit")
        plt.title("Gate 12K: predicted stretch versus fitted Gate 12G stretch")
        plt.tight_layout()
        p = OUT_DIR / "gate12K_q_pred_over_fit.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Marker Q comparison fit vs 1/6.
        fit_rows = [r for r in marker_rows if r["law_label"] == "fit_alpha"]
        one_rows = [r for r in marker_rows if r["law_label"] == "alpha_1_over_6"]
        labels2 = [r["marker_name"] for r in fit_rows]
        xpos = np.arange(len(labels2))
        plt.figure(figsize=(10, 5))
        plt.plot(xpos, [r["Q"] for r in fit_rows], marker="o", label="fit alpha")
        plt.plot(xpos, [r["Q"] for r in one_rows], marker="s", label="alpha=1/6")
        plt.yscale("log")
        plt.xticks(xpos, labels2, rotation=45, ha="right")
        plt.ylabel("Q")
        plt.title("Gate 12K: fitted alpha vs alpha=1/6 marker Q")
        plt.legend()
        plt.tight_layout()
        p = OUT_DIR / "gate12K_marker_Q_fit_vs_one_sixth.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def print_kv(row: dict, keys=None, indent="  ") -> None:
    items = row.items() if keys is None else [(k, row[k]) for k in keys]
    for k, v in items:
        if isinstance(v, float):
            print(f"{indent}{k}: {v:.12e}")
        else:
            print(f"{indent}{k}: {v}")


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    alpha_rows = alpha_candidate_rows()
    reservoir = lag_reservoir_rows()
    marker_rows = marker_rows_for_alpha(SEED["alpha_fit"], "fit_alpha") + marker_rows_for_alpha(1.0/6.0, "alpha_1_over_6")
    verdict = verdict_row(alpha_rows, reservoir)
    plots = save_plots(alpha_rows, marker_rows)

    write_csv(OUT_DIR / "gate12K_seed.csv", [SEED])
    write_csv(OUT_DIR / "gate12K_alpha_candidate_audit.csv", alpha_rows)
    write_csv(OUT_DIR / "gate12K_lag_reservoir_models.csv", reservoir)
    write_csv(OUT_DIR / "gate12K_marker_predictions_fit_vs_one_sixth.csv", marker_rows)
    write_csv(OUT_DIR / "gate12K_verdict.csv", [verdict])

    report = OUT_DIR / "gate12K_lag_burst_settlement_origin_report.txt"
    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12K: Lag-Burst Settlement Origin of Q(T)\n")
        f.write("=====================================================\n\n")
        f.write("Seed:\n")
        for k, v in SEED.items():
            f.write(f"  {k}: {v}\n")
        f.write("\nAlpha candidate audit:\n")
        for row in alpha_rows:
            f.write(f"  {row}\n")
        f.write("\nLag reservoir models:\n")
        for row in reservoir:
            f.write(f"  {row}\n")
        f.write("\nVerdict:\n")
        for k, v in verdict.items():
            f.write(f"  {k}: {v}\n")

    print("\nSFT V12 GATE 12K RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Lag-burst settlement-origin audit for Q(T).")
    print("  Tests whether alpha≈0.165 has a simple no-cheat source hint, especially alpha=1/6.")
    print("  No lag-burst mechanism or V11.1B derivation is claimed.")

    print("\nSeed:")
    print_kv(SEED, [
        "candidate_name", "spacing_fm", "R_post_AU", "kT_post_MeV",
        "thermal_growth_to_rec", "q_rec_fit", "alpha_fit",
        "R_thermal_rec_Mly", "R_ledger_rec_Mly_fit",
    ])

    print("\nTop alpha candidate audit:")
    for row in alpha_rows:
        print(f"\n  {row['candidate_id']}")
        print_kv(row, [
            "alpha",
            "mu_volume_exponent_3alpha",
            "q_rec_pred",
            "q_pred_over_fit",
            "q_percent_error_vs_fit",
            "R_rec_Mly_pred",
            "max_local_target_factor_error",
            "alpha_percent_error_vs_fit",
            "mu_percent_error_to_one_half",
            "Q3_volume_ratio",
            "Q4_forbidden_radiation_penalty_if_thermal",
            "source_rule",
            "source_status",
            "verdict",
        ], indent="    ")

    print("\nLag reservoir model audit:")
    for row in reservoir:
        print(f"\n  {row['model_id']}")
        print_kv(row, [
            "mu_volume_exponent",
            "alpha",
            "law",
            "q_rec_pred",
            "q_pred_over_fit",
            "R_rec_Mly_pred",
            "max_local_target_factor_error",
            "mechanism_reading",
            "source_status",
            "geometry_status",
        ], indent="    ")

    print("\nMarker predictions: fit alpha vs alpha=1/6")
    for row in marker_rows:
        if row["marker_name"] in ["1MeV_BBNish", "0p1MeV_BBNish", "1eV", "recombination"]:
            print(f"\n  {row['law_label']} :: {row['marker_name']}")
            print_kv(row, [
                "kT_MeV", "a_T", "Q", "a_L", "Q3_volume",
                "settlement_density_ratio_Qminus3", "alpha", "mu_volume_exponent",
            ], indent="    ")

    print("\nGate 12K verdict:")
    print_kv(verdict)

    print("\nFiles:")
    print(f"  output directory: {OUT_DIR}")
    print(f"  report: {report}")
    print(f"  seed csv: {OUT_DIR / 'gate12K_seed.csv'}")
    print(f"  alpha audit csv: {OUT_DIR / 'gate12K_alpha_candidate_audit.csv'}")
    print(f"  lag reservoir csv: {OUT_DIR / 'gate12K_lag_reservoir_models.csv'}")
    print(f"  marker predictions csv: {OUT_DIR / 'gate12K_marker_predictions_fit_vs_one_sixth.csv'}")
    print(f"  verdict csv: {OUT_DIR / 'gate12K_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
