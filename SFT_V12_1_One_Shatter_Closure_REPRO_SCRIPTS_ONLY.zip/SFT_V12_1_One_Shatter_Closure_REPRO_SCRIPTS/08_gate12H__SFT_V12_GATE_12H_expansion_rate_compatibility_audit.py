#!/usr/bin/env python3
"""
SFT V12 Gate 12H: Expansion-Rate Compatibility Audit

Mobile-ready: embeds the Gate 12G selected bridge and law family values.
No previous output folder is required.

Purpose
-------
Gate 12G showed that a smooth non-thermal metric stretch law can carry the
missing recombination bridge:

    R_eff(T) = R_th(T) * Q(T)
    Q_rec ~= 25.98
    ln(Q_rec) ~= 3.26
    alpha ~= 0.165 for Q=(Tpost/T)^alpha

Gate 12H asks the critic's question:

    Does Q(T) wreck radiation history / BBN-ish timing / CMB timing if it is
    interpreted as an actual local expansion-rate change?

This is a compatibility-boundary audit, not a mechanism.

Key distinction
---------------
There are two very different readings:

1. Non-thermal ledger/spatialization map:
       Q(T) changes effective spatial ledger scale without changing the local
       thermal cooling clock. BBN microphysics sees the usual thermal clock.
       This can survive, but requires precise SFT wording and a mechanism.

2. Actual local scale-factor expansion:
       a_eff ∝ T^-(1+alpha_eff). Then
       H_eff/H_thermal = 1 + alpha_eff.
       This can strongly modify radiation-era timing and is a rate-risk.

This script quantifies that distinction.

Claim boundary
--------------
This script does NOT:
    - derive Q(T);
    - derive perturbations/flatness;
    - prove BBN/CMB compatibility;
    - replace a Boltzmann code or nuclear reaction network.

It DOES:
    - compute H_eff/H_thermal if Q is misread as actual local expansion;
    - compute a rough Delta-N_eff proxy for that misread;
    - identify law shapes that keep BBN-ish markers gentler by delaying stretch;
    - state the required wording boundary for SFT.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
import numpy as np


# -----------------------------
# Embedded Gate 12G selected bridge
# -----------------------------

SEED = {
    "candidate_name": "thermal_Compton_fixed_kT_equals_hbarc_over_s",
    "spacing_fm": 2.080201237123,
    "R_post_AU": 4.003904729680,
    "kT_post_MeV": 94.85956307390,
    "kT_rec_eV": 2.562193818698e-1,
    "thermal_growth_to_rec": 3.702278975995e8,
    "thermal_efolds_to_rec": 19.72962931345,
    "q_rec": 25.98352226408,
    "q_rec_efolds": 3.257462578037,
    "alpha_power_law": 0.1651051079717,
    "R_thermal_rec_Mly": 0.02343978468746,
    "R_eff_rec_Mly": 0.6090481672918,
    "local_target_max_factor_error": 1.410461571124,
    "adiabatic_misread_q4_penalty": 4.558186500567e5,
}

LOCAL_TARGETS_MLY = {
    "sound_horizon": 0.4318077002313,
    "hubble_radius": 0.6246982112007,
    "particle_horizon": 0.8375182455706,
}

# Comparison marker only, used to convert H/H_std into an equivalent extra radiation proxy.
N_EFF_REF = 3.044
NEFF_FACTOR = 0.22710731766  # rho_nu/rho_gamma per effective species for standard neutrino temperature ratio

OUT_DIR = Path("SFT_V12_GATE_12H_OUTPUT")


# -----------------------------
# Law families
# -----------------------------

def clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def sigmoid(z: float) -> float:
    if z >= 0:
        ez = math.exp(-z)
        return 1.0 / (1.0 + ez)
    ez = math.exp(z)
    return ez / (1.0 + ez)


def smoothstep(x: float) -> float:
    x = clamp01(x)
    return 3.0*x*x - 2.0*x*x*x


def smootherstep(x: float) -> float:
    x = clamp01(x)
    return 6.0*x**5 - 15.0*x**4 + 10.0*x**3


def normalized_logistic(x: float, x0: float, width: float) -> float:
    a = sigmoid((0.0 - x0) / width)
    b = sigmoid((1.0 - x0) / width)
    s = sigmoid((x - x0) / width)
    if abs(b - a) < 1e-14:
        return x
    return clamp01((s - a) / (b - a))


def shape_y(law_name: str, x: float, params: dict) -> float:
    x = clamp01(x)
    if law_name == "power_constant_alpha":
        return x
    if law_name == "smoothstep_symmetric":
        return smoothstep(x)
    if law_name == "smootherstep_symmetric":
        return smootherstep(x)
    if law_name == "early_smooth_sqrt":
        return math.sqrt(x)
    if law_name == "late_smooth_x2":
        return x*x
    if law_name == "late_smooth_x3":
        return x**3
    if law_name == "early_saturating_1_minus_1mx2":
        return 1.0 - (1.0 - x)**2
    if law_name == "logistic":
        return normalized_logistic(x, params["x0"], params["width"])
    raise ValueError(law_name)


def law_id(law: dict) -> str:
    if law["law_name"] != "logistic":
        return law["law_name"]
    return f"logistic_x0_{law['params']['x0']}_w_{law['params']['width']}"


def law_families() -> list[dict]:
    laws = [
        {"law_name": "power_constant_alpha", "params": {}, "interpretation": "constant extra metric stretch per thermal e-fold"},
        {"law_name": "smoothstep_symmetric", "params": {}, "interpretation": "symmetric smooth handoff"},
        {"law_name": "smootherstep_symmetric", "params": {}, "interpretation": "smoother symmetric handoff"},
        {"law_name": "early_smooth_sqrt", "params": {}, "interpretation": "front-loaded smooth stretch"},
        {"law_name": "late_smooth_x2", "params": {}, "interpretation": "back-loaded smooth stretch"},
        {"law_name": "late_smooth_x3", "params": {}, "interpretation": "strongly back-loaded stretch"},
        {"law_name": "early_saturating_1_minus_1mx2", "params": {}, "interpretation": "early saturating smooth stretch"},
    ]
    for x0 in [0.25, 0.50, 0.75]:
        for width in [0.08, 0.15, 0.25]:
            laws.append({
                "law_name": "logistic",
                "params": {"x0": x0, "width": width},
                "interpretation": f"localized handoff around x={x0}, width={width}",
            })
    return laws


# -----------------------------
# Core calculations
# -----------------------------

def x_from_kT(kT_MeV: float) -> float:
    return clamp01(math.log(SEED["kT_post_MeV"] / kT_MeV) / SEED["thermal_efolds_to_rec"])


def Q_metric(law: dict, x: float) -> float:
    return math.exp(SEED["q_rec_efolds"] * shape_y(law["law_name"], x, law["params"]))


def alpha_eff_numeric(law: dict, x: float, dx: float = 1e-5) -> float:
    """
    alpha_eff = d ln Q / d ln(Tpost/T)
              = (d ln Q / dx) / thermal_efolds_to_rec
    """
    x1 = clamp01(x - dx)
    x2 = clamp01(x + dx)
    if x2 == x1:
        return math.nan
    y1 = shape_y(law["law_name"], x1, law["params"])
    y2 = shape_y(law["law_name"], x2, law["params"])
    dlnQ_dx = SEED["q_rec_efolds"] * (y2 - y1) / (x2 - x1)
    return dlnQ_dx / SEED["thermal_efolds_to_rec"]


def delta_neff_proxy(H_ratio: float) -> float:
    """
    Rough radiation-era proxy:
        H^2 ∝ rho_rad
        rho_rad/rho_gamma = 1 + 0.2271 N_eff
    Additional H^2 is mapped to equivalent Delta N_eff.

    This is only a diagnostic marker, not a BBN/CMB fit.
    """
    total_factor = 1.0 + NEFF_FACTOR * N_EFF_REF
    return ((H_ratio**2 - 1.0) * total_factor) / NEFF_FACTOR


def temperature_markers() -> list[dict]:
    rec_MeV = SEED["kT_rec_eV"] * 1e-6
    raw = [
        ("post_shatter", SEED["kT_post_MeV"], "post-shatter marker"),
        ("QCD_50MeV", 50.0, "hadronic comparison marker"),
        ("10MeV", 10.0, "early radiation-era marker"),
        ("1MeV_BBNish", 1.0, "BBN-ish marker, not a BBN calculation"),
        ("0p1MeV_BBNish", 0.1, "BBN-ish marker, not a BBN calculation"),
        ("1keV", 1e-3, "keV-era marker"),
        ("1eV", 1e-6, "eV-era marker"),
        ("recombination", rec_MeV, "recombination marker"),
    ]
    rows = []
    for name, mev, note in raw:
        if mev <= SEED["kT_post_MeV"] * (1 + 1e-12) and mev >= rec_MeV * (1 - 1e-12):
            rows.append({
                "marker_name": name,
                "kT_MeV": mev,
                "kT_eV": mev * 1e6,
                "x_thermal_progress": x_from_kT(mev),
                "note": note,
            })
    return rows


def marker_rate_rows(laws: list[dict], markers: list[dict]) -> list[dict]:
    rows = []
    for law in laws:
        for m in markers:
            x = m["x_thermal_progress"]
            Q = Q_metric(law, x)
            alpha = alpha_eff_numeric(law, x)
            H_ratio_actual_scale = 1.0 + alpha
            dneff = delta_neff_proxy(H_ratio_actual_scale)
            time_ratio = 1.0 / H_ratio_actual_scale

            if m["marker_name"] in {"1MeV_BBNish", "0p1MeV_BBNish"}:
                if H_ratio_actual_scale <= 1.05:
                    rate_status = "LOW_BBN_RATE_RISK_IF_ACTUAL_SCALE"
                elif H_ratio_actual_scale <= 1.10:
                    rate_status = "MODERATE_BBN_RATE_RISK_IF_ACTUAL_SCALE"
                else:
                    rate_status = "HIGH_BBN_RATE_RISK_IF_ACTUAL_SCALE"
            else:
                rate_status = "RATE_MARKER_DIAGNOSTIC"

            rows.append({
                "law_id": law_id(law),
                "law_name": law["law_name"],
                "law_params": str(law["params"]),
                "marker_name": m["marker_name"],
                "kT_MeV": m["kT_MeV"],
                "x_thermal_progress": x,
                "Q_metric": Q,
                "alpha_eff": alpha,
                "H_eff_over_Hthermal_if_actual_scale": H_ratio_actual_scale,
                "time_at_fixed_T_ratio_if_actual_scale": time_ratio,
                "delta_Neff_proxy_if_actual_scale": dneff,
                "rate_status": rate_status,
                "interpretation": law["interpretation"],
            })
    return rows


def law_rate_audit_rows(laws: list[dict], marker_rows: list[dict]) -> list[dict]:
    rows = []
    for law in laws:
        lid = law_id(law)
        rs = [r for r in marker_rows if r["law_id"] == lid]
        bbn = [r for r in rs if r["marker_name"] in {"1MeV_BBNish", "0p1MeV_BBNish"}]
        rec = [r for r in rs if r["marker_name"] == "recombination"][0]
        one_ev = [r for r in rs if r["marker_name"] == "1eV"][0]

        xs = np.linspace(0, 1, 2001)
        alphas = np.array([alpha_eff_numeric(law, float(x), dx=1e-4) for x in xs])
        max_alpha = float(np.nanmax(alphas))
        min_alpha = float(np.nanmin(alphas))
        max_H = 1.0 + max_alpha
        max_dneff = delta_neff_proxy(max_H)

        max_bbn_H = max(r["H_eff_over_Hthermal_if_actual_scale"] for r in bbn)
        max_bbn_dneff = max(r["delta_Neff_proxy_if_actual_scale"] for r in bbn)
        max_bbn_Q = max(r["Q_metric"] for r in bbn)

        # All laws share final geometric fit if Q_rec is fixed.
        target_residuals = {
            k: SEED["R_eff_rec_Mly"] / v
            for k, v in LOCAL_TARGETS_MLY.items()
        }
        max_factor_error = max(max(r, 1/r) for r in target_residuals.values())

        if max_bbn_H <= 1.05 and max_factor_error <= 2:
            actual_scale_status = "BBNISH_RATE_RISK_LOW_BUT_LATE_CMB_RATE_STILL_OPEN"
        elif max_bbn_H <= 1.10 and max_factor_error <= 2:
            actual_scale_status = "BBNISH_RATE_RISK_MODERATE_NEEDS_REAL_BBN_TEST"
        else:
            actual_scale_status = "BBNISH_RATE_RISK_HIGH_IF_ACTUAL_SCALE"

        if max_factor_error <= 2:
            ledger_status = "NONTHERMAL_LEDGER_MAP_FITS_LOCAL_RECOMBINATION"
        else:
            ledger_status = "NONTHERMAL_LEDGER_MAP_DOES_NOT_FIT_LOCAL_RECOMBINATION"

        rows.append({
            "law_id": lid,
            "law_name": law["law_name"],
            "law_params": str(law["params"]),
            "max_alpha_eff": max_alpha,
            "min_alpha_eff": min_alpha,
            "max_H_eff_over_Hthermal_if_actual_scale": max_H,
            "max_delta_Neff_proxy_if_actual_scale": max_dneff,
            "max_BBNish_H_eff_over_Hthermal_if_actual_scale": max_bbn_H,
            "max_BBNish_delta_Neff_proxy_if_actual_scale": max_bbn_dneff,
            "max_BBNish_Q_metric": max_bbn_Q,
            "Q_at_1eV": one_ev["Q_metric"],
            "Q_at_recombination": rec["Q_metric"],
            "local_target_max_factor_error": max_factor_error,
            "sound_pred_over_target": target_residuals["sound_horizon"],
            "hubble_pred_over_target": target_residuals["hubble_radius"],
            "particle_pred_over_target": target_residuals["particle_horizon"],
            "actual_scale_status": actual_scale_status,
            "ledger_map_status": ledger_status,
            "interpretation": law["interpretation"],
        })

    return sorted(rows, key=lambda r: (
        0 if r["actual_scale_status"].startswith("BBNISH_RATE_RISK_LOW") else 1 if r["actual_scale_status"].startswith("BBNISH_RATE_RISK_MODERATE") else 2,
        r["max_BBNish_delta_Neff_proxy_if_actual_scale"],
        r["max_alpha_eff"],
    ))


def channel_audit_rows(law_audits: list[dict]) -> list[dict]:
    const = next(r for r in law_audits if r["law_id"] == "power_constant_alpha")
    best_actual = law_audits[0]

    rows = [
        {
            "channel": "nonthermal_ledger_spatialization_map",
            "status": "SURVIVES_AS_SFT_WORDING_BOUNDARY",
            "local_thermal_clock_changed": False,
            "H_eff_over_Hthermal_for_BBN_microphysics": 1.0,
            "q_rec": SEED["q_rec"],
            "local_target_max_factor_error": SEED["local_target_max_factor_error"],
            "interpretation": "Q changes effective spatial ledger scale, not the local photon cooling/reaction clock. Mechanism still open.",
        },
        {
            "channel": "actual_local_scale_factor_constant_alpha",
            "status": "RATE_RISK_IF_INSERTED_INTO_LOCAL_FRIEDMANN_HISTORY",
            "local_thermal_clock_changed": True,
            "H_eff_over_Hthermal": 1.0 + SEED["alpha_power_law"],
            "delta_Neff_proxy": delta_neff_proxy(1.0 + SEED["alpha_power_law"]),
            "alpha": SEED["alpha_power_law"],
            "interpretation": "If Q is actual local scale-factor expansion, constant alpha raises H by ~16.5 percent across the radiation era.",
        },
        {
            "channel": "best_delayed_actual_scale_candidate",
            "status": best_actual["actual_scale_status"],
            "law_id": best_actual["law_id"],
            "max_BBNish_H_eff_over_Hthermal": best_actual["max_BBNish_H_eff_over_Hthermal_if_actual_scale"],
            "max_BBNish_delta_Neff_proxy": best_actual["max_BBNish_delta_Neff_proxy_if_actual_scale"],
            "max_alpha_eff": best_actual["max_alpha_eff"],
            "Q_at_1eV": best_actual["Q_at_1eV"],
            "Q_at_recombination": best_actual["Q_at_recombination"],
            "interpretation": "Delaying Q can reduce BBN-ish rate risk but pushes the stretch toward later/CMB-sensitive eras.",
        },
        {
            "channel": "ordinary_adiabatic_extra_expansion",
            "status": "THERMODYNAMICALLY_COSTLY_AND_NOT_THE_CLEAN_SFT_READING",
            "q_rec": SEED["q_rec"],
            "radiation_density_reheat_penalty_q4": SEED["q_rec"]**4,
            "entropy_density_reheat_penalty_q3": SEED["q_rec"]**3,
            "interpretation": "If Q is ordinary adiabatic expansion, the plasma overcools and one must pay a reheating/entropy bookkeeping bill.",
        },
    ]
    return rows


def target_rows() -> list[dict]:
    rows = []
    for name, target in LOCAL_TARGETS_MLY.items():
        ratio = SEED["R_eff_rec_Mly"] / target
        rows.append({
            "target_name": name,
            "R_target_Mly": target,
            "R_eff_rec_Mly": SEED["R_eff_rec_Mly"],
            "pred_over_target": ratio,
            "factor_error": max(ratio, 1/ratio),
        })
    return rows


def verdict(law_audits: list[dict], channel_rows: list[dict]) -> dict:
    const = next(r for r in law_audits if r["law_id"] == "power_constant_alpha")
    best_actual = law_audits[0]

    return {
        "verdict": "NONTHERMAL_LEDGER_INTERPRETATION_REQUIRED_ACTUAL_EXPANSION_RATE_IS_RISKY",
        "claim_boundary": "compatibility-boundary audit only; no BBN/CMB fit, perturbations, flatness, or mechanism derived",
        "selected_Q_law_for_geometry": "power_constant_alpha",
        "alpha_constant": SEED["alpha_power_law"],
        "q_rec": SEED["q_rec"],
        "R_eff_rec_Mly": SEED["R_eff_rec_Mly"],
        "local_target_max_factor_error": SEED["local_target_max_factor_error"],
        "constant_alpha_H_eff_over_Hthermal_if_actual_scale": 1.0 + SEED["alpha_power_law"],
        "constant_alpha_delta_Neff_proxy_if_actual_scale": delta_neff_proxy(1.0 + SEED["alpha_power_law"]),
        "constant_alpha_Q_1MeV": next(r for r in marker_rate_rows([{"law_name": "power_constant_alpha", "params": {}, "interpretation": ""}], temperature_markers()) if r["marker_name"] == "1MeV_BBNish")["Q_metric"],
        "constant_alpha_Q_0p1MeV": next(r for r in marker_rate_rows([{"law_name": "power_constant_alpha", "params": {}, "interpretation": ""}], temperature_markers()) if r["marker_name"] == "0p1MeV_BBNish")["Q_metric"],
        "best_actual_scale_mitigation_law": best_actual["law_id"],
        "best_actual_scale_mitigation_status": best_actual["actual_scale_status"],
        "best_actual_scale_max_BBNish_H_eff_over_Hthermal": best_actual["max_BBNish_H_eff_over_Hthermal_if_actual_scale"],
        "best_actual_scale_max_BBNish_delta_Neff_proxy": best_actual["max_BBNish_delta_Neff_proxy_if_actual_scale"],
        "adiabatic_misread_radiation_density_penalty_q4": SEED["q_rec"]**4,
        "key_sentence": (
            "Gate 12H draws the line: Q(T) is numerically useful only as a non-thermal ledger/"
            "spatialization factor. If the same Q is inserted as ordinary local scale-factor expansion, "
            "even the constant-alpha law raises the radiation-era expansion-rate proxy by about 16.5%, "
            "creating a large BBN/CMB rate-risk. Delayed laws can soften BBN-ish markers, but then move "
            "the burden into later CMB-sensitive timing. Therefore Q needs an SFT-specific non-thermal "
            "metric/ledger mechanism, not a naive Friedmann expansion reinterpretation."
        ),
    }


# -----------------------------
# Output
# -----------------------------

def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def save_plots(law_audits: list[dict], marker_rows: list[dict]) -> list[str]:
    plots = []
    try:
        import matplotlib.pyplot as plt

        # BBN risk vs law.
        labels = [r["law_id"] for r in law_audits]
        vals = [r["max_BBNish_H_eff_over_Hthermal_if_actual_scale"] for r in law_audits]
        x = np.arange(len(labels))
        plt.figure(figsize=(12, 5))
        plt.scatter(x, vals)
        plt.axhline(1.05, linestyle="--", linewidth=1)
        plt.axhline(1.10, linestyle=":", linewidth=1)
        plt.xticks(x, labels, rotation=65, ha="right", fontsize=7)
        plt.ylabel("max BBN-ish H_eff/Hthermal if actual scale")
        plt.title("Gate 12H: actual-expansion BBN-ish rate risk by law")
        plt.tight_layout()
        p = OUT_DIR / "gate12H_BBNish_rate_risk_by_law.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Constant alpha marker values.
        const_rows = [r for r in marker_rows if r["law_id"] == "power_constant_alpha"]
        labels = [r["marker_name"] for r in const_rows]
        Qs = [r["Q_metric"] for r in const_rows]
        Hs = [r["H_eff_over_Hthermal_if_actual_scale"] for r in const_rows]
        x = np.arange(len(labels))
        plt.figure(figsize=(9, 5))
        plt.plot(x, Qs, marker="o", label="Q metric")
        plt.plot(x, Hs, marker="s", label="H/Hthermal if actual scale")
        plt.yscale("log")
        plt.xticks(x, labels, rotation=45, ha="right")
        plt.ylabel("value")
        plt.title("Gate 12H: constant-alpha Q versus actual-rate reading")
        plt.legend()
        plt.tight_layout()
        p = OUT_DIR / "gate12H_constant_alpha_markers.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Delta N_eff proxy scatter.
        vals = [r["max_BBNish_delta_Neff_proxy_if_actual_scale"] for r in law_audits]
        plt.figure(figsize=(12, 5))
        plt.scatter(x=np.arange(len(labels := [r["law_id"] for r in law_audits])), y=vals)
        plt.xticks(np.arange(len(labels)), labels, rotation=65, ha="right", fontsize=7)
        plt.yscale("symlog", linthresh=0.1)
        plt.ylabel("max BBN-ish Delta N_eff proxy if actual scale")
        plt.title("Gate 12H: rough Delta-N_eff proxy by law")
        plt.tight_layout()
        p = OUT_DIR / "gate12H_delta_neff_proxy_by_law.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def print_kv(row: dict, keys=None, indent="  ") -> None:
    items = row.items() if keys is None else [(k, row[k]) for k in keys]
    for k, v in items:
        if isinstance(v, float):
            print(f"{indent}{k}: {v:.12e}")
        else:
            print(f"{indent}{k}: {v}")


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    laws = law_families()
    markers = temperature_markers()
    marker_rows = marker_rate_rows(laws, markers)
    law_audits = law_rate_audit_rows(laws, marker_rows)
    channels = channel_audit_rows(law_audits)
    targets = target_rows()
    ver = verdict(law_audits, channels)
    plots = save_plots(law_audits, marker_rows)

    write_csv(OUT_DIR / "gate12H_seed.csv", [SEED])
    write_csv(OUT_DIR / "gate12H_temperature_markers.csv", markers)
    write_csv(OUT_DIR / "gate12H_marker_rate_rows.csv", marker_rows)
    write_csv(OUT_DIR / "gate12H_law_rate_audit.csv", law_audits)
    write_csv(OUT_DIR / "gate12H_channel_audit.csv", channels)
    write_csv(OUT_DIR / "gate12H_target_comparison.csv", targets)
    write_csv(OUT_DIR / "gate12H_verdict.csv", [ver])

    report = OUT_DIR / "gate12H_expansion_rate_compatibility_report.txt"
    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12H: Expansion-Rate Compatibility Audit\n")
        f.write("====================================================\n\n")
        f.write("Seed:\n")
        for k, v in SEED.items():
            f.write(f"  {k}: {v}\n")
        f.write("\nChannel audit:\n")
        for row in channels:
            f.write(f"  {row}\n")
        f.write("\nTop law rate audits:\n")
        for row in law_audits[:10]:
            f.write(f"  {row}\n")
        f.write("\nVerdict:\n")
        for k, v in ver.items():
            f.write(f"  {k}: {v}\n")

    print("\nSFT V12 GATE 12H RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Expansion-rate compatibility audit for Q(T).")
    print("  No BBN/CMB fit, perturbation derivation, flatness solution, or mechanism is claimed.")

    print("\nSeed:")
    print_kv(SEED, [
        "candidate_name", "spacing_fm", "R_post_AU", "kT_post_MeV",
        "thermal_efolds_to_rec", "q_rec", "q_rec_efolds",
        "alpha_power_law", "R_eff_rec_Mly", "local_target_max_factor_error",
    ])

    print("\nChannel audit:")
    for row in channels:
        print(f"\n  {row['channel']}")
        print_kv(row, [k for k in row.keys() if k != "channel"], indent="    ")

    print("\nTop actual-scale mitigation laws:")
    for i, row in enumerate(law_audits[:10], start=1):
        print(f"\n  #{i}")
        print_kv(row, [
            "law_id",
            "max_alpha_eff",
            "max_H_eff_over_Hthermal_if_actual_scale",
            "max_BBNish_H_eff_over_Hthermal_if_actual_scale",
            "max_BBNish_delta_Neff_proxy_if_actual_scale",
            "max_BBNish_Q_metric",
            "Q_at_1eV",
            "Q_at_recombination",
            "local_target_max_factor_error",
            "actual_scale_status",
            "ledger_map_status",
            "interpretation",
        ], indent="    ")

    print("\nConstant-alpha marker rate rows:")
    for row in [r for r in marker_rows if r["law_id"] == "power_constant_alpha"]:
        print(f"\n  {row['marker_name']}")
        print_kv(row, [
            "kT_MeV",
            "x_thermal_progress",
            "Q_metric",
            "alpha_eff",
            "H_eff_over_Hthermal_if_actual_scale",
            "time_at_fixed_T_ratio_if_actual_scale",
            "delta_Neff_proxy_if_actual_scale",
            "rate_status",
        ], indent="    ")

    print("\nLocal recombination target comparison:")
    for row in targets:
        print(f"\n  {row['target_name']}")
        print_kv(row, ["R_target_Mly", "R_eff_rec_Mly", "pred_over_target", "factor_error"], indent="    ")

    print("\nGate 12H verdict:")
    print_kv(ver)

    print("\nFiles:")
    print(f"  output directory: {OUT_DIR}")
    print(f"  report: {report}")
    print(f"  seed csv: {OUT_DIR / 'gate12H_seed.csv'}")
    print(f"  marker rate rows csv: {OUT_DIR / 'gate12H_marker_rate_rows.csv'}")
    print(f"  law rate audit csv: {OUT_DIR / 'gate12H_law_rate_audit.csv'}")
    print(f"  channel audit csv: {OUT_DIR / 'gate12H_channel_audit.csv'}")
    print(f"  target comparison csv: {OUT_DIR / 'gate12H_target_comparison.csv'}")
    print(f"  verdict csv: {OUT_DIR / 'gate12H_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
