#!/usr/bin/env python3
"""
SFT V12 Gate 12F: Modest Metric-Stretch Channel Audit

Purpose
-------
Gate 12E found that QCD/fm post-shatter spatialization plus ordinary adiabatic
cooling reaches a real fraction of the recombination local-horizon ledgers, but
underreaches the local recombination targets by roughly:

    sound horizon:   ~16x
    Hubble radius:   ~23x
    particle horizon:~31x

Gate 12F asks:

    Can that missing 16-31x be represented as a modest metric-stretch channel
    rather than ordinary particle transport or an inflation-sized miracle?

This is a channel audit, not a derivation.

Core diagnostics
----------------
For each QCD/fm candidate and recombination target:

    q_required = R_target / R_pred_thermal

where R_pred_thermal is the post-shatter radius after temperature-only cooling.

Then compute:

    extra_efolds = ln(q_required)
    alpha_extra  = ln(q_required) / ln(T_post/T_rec)

where alpha_extra is the extra stretch exponent if:

    R ∝ T^-(1 + alpha_extra)

instead of pure adiabatic R ∝ T^-1.

Also test a single-q bridge across the three local recombination targets:
    - physical acoustic sound horizon
    - physical Hubble radius
    - physical particle horizon

Claim boundary
--------------
This script does NOT:
    - derive the stretch channel mechanism;
    - derive inflation or replace inflation;
    - claim perturbation/flatness success;
    - derive a_phi or N.

It DOES:
    - quantify the required extra metric stretch;
    - show whether one modest q can cover the local recombination ledgers;
    - separate metric stretch from thermodynamic/adiabatic expansion;
    - compute the reheating penalty if the extra stretch is treated as ordinary
      adiabatic expansion instead of metric assignment.
"""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


# -----------------------------
# Constants / defaults
# -----------------------------

C = 299_792_458.0
EV_J = 1.602_176_634e-19
MEV_J = 1.0e6 * EV_J
LY_M = 9.460_730_472_5808e15
MLY_M = 1.0e6 * LY_M
MPC_M = 3.085_677_581_491_3673e22


@dataclass
class Config:
    # Prefer reading Gate 12E if available.
    gate12e_bridge_csv: str = "SFT_V12_GATE_12E_OUTPUT/gate12E_bridge_comparisons.csv"
    gate12e_candidates_csv: str = "SFT_V12_GATE_12E_OUTPUT/gate12E_post_shatter_candidates.csv"

    # Recombination marker from Gate 12E.
    kT_rec_eV: float = 2.562193818698e-1

    # Local recombination targets only. LSS is observational shell and tracked separately.
    local_targets: tuple[str, ...] = (
        "physical_acoustic_sound_horizon",
        "physical_hubble_radius",
        "physical_particle_horizon",
    )
    shell_targets: tuple[str, ...] = (
        "LSS_proper_radius_acoustic_angle",
        "LSS_proper_radius_LCDM_integral",
    )

    # Classification thresholds.
    modest_q_max: float = 50.0
    modest_efolds_max: float = 4.0
    modest_alpha_max: float = 0.20
    local_fit_max_factor_error: float = 2.0

    # Compare to inflation-sized expansion.
    inflation_reference_efolds: float = 60.0

    out_dir: str = "SFT_V12_GATE_12F_OUTPUT"


# -----------------------------
# CSV / parsing
# -----------------------------

def parse_bool(x: Any) -> bool:
    if isinstance(x, bool):
        return x
    return str(x).strip().lower() in {"true", "1", "yes", "y"}


def parse_float(x: Any, default: float = math.nan) -> float:
    try:
        return float(x)
    except Exception:
        return default


def read_csv_dicts(path: Path) -> list[dict]:
    with open(path, "r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def default_gate12e_bridge_rows() -> list[dict]:
    """
    Fallback rows copied from the Gate 12E nominal QCD/hadronic candidate outputs.
    These are enough for Gate 12F if the 12E CSV is not present.
    """
    local_targets = [
        ("physical_acoustic_sound_horizon", "local_causal_acoustic", 0.4318077002313),
        ("physical_hubble_radius", "local_expansion", 0.6246982112007),
        ("physical_particle_horizon", "local_causal_particle", 0.8375182455706),
        ("LSS_proper_radius_acoustic_angle", "observational_shell", 41.47650061294),
        ("LSS_proper_radius_LCDM_integral", "observational_shell", 41.45883810955),
    ]

    candidates = [
        ("one_fermi", 1.0, 1.924767978322, 164.3085385024, 6.412806763616e8),
        ("proton_charge_radius", 0.8409, 1.618537392971, 187.1120979954, 7.302808110374e8),
        ("QCD_200MeV_reduced_Compton", 0.9866349022965, 1.899043266235, 165.9750379938, 6.477848661668e8),
        ("thermal_Compton_fixed_kT_equals_hbarc_over_s", 2.080201237123, 4.003904729680, 94.85956307390, 3.702278975996e8),
        ("classical_electron_radius", 2.817940326200, 5.423881304691, 75.54596769919, 2.948487626030e8),
        ("piece_energy_reduced_Compton", 3.161526773497, 6.085205496233, 69.30067818394, 2.704739886507e8),
        ("thermal_piece_fixed_kT_equals_Epiece", 3.634913121798, 6.996364380818, 62.41509074461, 2.436001924957e8),
    ]

    # Gate 12E result for best candidate: R_pred_rec = 0.02694950479206 Mly.
    # In general, compute R_pred_rec from R_post_AU * AU / Mly * growth.
    AU_M = 1.495_978_707e11
    MLY_M = 9.460_730_472_5808e21

    rows = []
    for cand, spacing_fm, Rpost_AU, kT_MeV, growth in candidates:
        Rpred_Mly = Rpost_AU * AU_M * growth / MLY_M
        for target, cls, target_Mly in local_targets:
            pred_over = Rpred_Mly / target_Mly
            extra = target_Mly / Rpred_Mly
            rows.append({
                "candidate_name": cand,
                "target_name": target,
                "target_class": cls,
                "spacing_fm": spacing_fm,
                "R_post_AU": Rpost_AU,
                "kT_post_MeV": kT_MeV,
                "thermal_growth_to_rec": growth,
                "thermal_growth_efolds": math.log(growth),
                "R_pred_rec_Mly": Rpred_Mly,
                "R_target_Mly": target_Mly,
                "pred_over_target": pred_over,
                "target_over_pred_extra_metric_factor": extra,
                "extra_metric_efolds_needed": math.log(extra),
                "abs_log10_error": abs(math.log10(pred_over)),
                "qcd_bulk_candidate": True,
            })
    return rows


def load_gate12e_rows(cfg: Config) -> tuple[list[dict], str]:
    path = Path(cfg.gate12e_bridge_csv)
    if path.exists():
        rows = read_csv_dicts(path)
        # Normalize numeric fields.
        normalized = []
        for r in rows:
            nr = dict(r)
            for k in [
                "spacing_fm",
                "R_post_AU",
                "kT_post_MeV",
                "thermal_growth_to_rec",
                "thermal_growth_efolds",
                "R_pred_rec_Mly",
                "R_target_Mly",
                "pred_over_target",
                "target_over_pred_extra_metric_factor",
                "extra_metric_efolds_needed",
                "abs_log10_error",
            ]:
                if k in nr:
                    nr[k] = parse_float(nr[k])
            nr["qcd_bulk_candidate"] = parse_bool(nr.get("qcd_bulk_candidate", False))
            normalized.append(nr)
        return normalized, f"loaded from {path}"

    return default_gate12e_bridge_rows(), "fallback embedded Gate 12E nominal rows"


# -----------------------------
# Analysis
# -----------------------------

def q_requirement_rows(cfg: Config, bridge_rows: list[dict]) -> list[dict]:
    out = []
    for r in bridge_rows:
        if not parse_bool(r.get("qcd_bulk_candidate", False)):
            continue

        q = parse_float(r["target_over_pred_extra_metric_factor"])
        growth = parse_float(r["thermal_growth_to_rec"])
        extra_efolds = math.log(q)
        thermal_efolds = math.log(growth)
        alpha = extra_efolds / thermal_efolds if thermal_efolds > 0 else math.nan

        target_name = r["target_name"]
        target_kind = (
            "local_recombination_ledger" if target_name in cfg.local_targets
            else "observational_shell_or_other"
        )

        if q <= cfg.modest_q_max and extra_efolds <= cfg.modest_efolds_max and alpha <= cfg.modest_alpha_max and target_kind == "local_recombination_ledger":
            status = "MODEST_LOCAL_METRIC_STRETCH_TARGET"
        elif target_kind != "local_recombination_ledger":
            status = "LARGE_OBSERVATIONAL_SHELL_STRETCH_NOT_PRIMARY_LOCAL_TARGET"
        elif q <= 100.0:
            status = "INTERMEDIATE_LOCAL_METRIC_STRETCH_TARGET"
        else:
            status = "LARGE_LOCAL_STRETCH_TARGET"

        # Thermodynamic penalty if this were ordinary adiabatic expansion after already
        # cooling to T_rec: final temperature would drop by q; to restore T_rec requires
        # reheating by q in temperature, q^4 in radiation energy density.
        out.append({
            "candidate_name": r["candidate_name"],
            "target_name": target_name,
            "target_class": r.get("target_class", ""),
            "target_kind": target_kind,
            "spacing_fm": parse_float(r["spacing_fm"]),
            "R_post_AU": parse_float(r["R_post_AU"]),
            "kT_post_MeV": parse_float(r["kT_post_MeV"]),
            "thermal_growth_to_rec": growth,
            "thermal_efolds_to_rec": thermal_efolds,
            "R_pred_rec_Mly": parse_float(r["R_pred_rec_Mly"]),
            "R_target_Mly": parse_float(r["R_target_Mly"]),
            "q_required_extra_metric_factor": q,
            "extra_efolds": extra_efolds,
            "alpha_extra_per_thermal_efold": alpha,
            "extra_efolds_as_fraction_of_60": extra_efolds / cfg.inflation_reference_efolds,
            "effective_total_growth": growth * q,
            "effective_total_efolds": thermal_efolds + extra_efolds,
            "adiabatic_extra_final_kT_eV_without_reheating": cfg.kT_rec_eV / q,
            "temperature_reheat_factor_needed_if_adiabatic": q,
            "radiation_energy_density_reheat_factor_q4": q**4,
            "entropy_density_reheat_factor_q3": q**3,
            "status": status,
        })
    return out


def single_q_fit_rows(cfg: Config, q_rows: list[dict]) -> list[dict]:
    """
    For each QCD candidate, fit one q across the three local recombination targets.
    Use geometric mean q to minimize log residuals.
    """
    by_candidate: dict[str, list[dict]] = {}
    for r in q_rows:
        if r["target_name"] in cfg.local_targets:
            by_candidate.setdefault(r["candidate_name"], []).append(r)

    out = []
    for cand, rows in by_candidate.items():
        if len(rows) < len(cfg.local_targets):
            continue

        qs = np.array([r["q_required_extra_metric_factor"] for r in rows], dtype=float)
        ln_qs = np.log(qs)
        q_geo = float(math.exp(np.mean(ln_qs)))
        efolds = math.log(q_geo)
        thermal_efolds = float(np.mean([r["thermal_efolds_to_rec"] for r in rows]))
        alpha = efolds / thermal_efolds

        residuals = q_geo / qs  # predicted_after_single_q / target
        abs_factor_errors = np.maximum(residuals, 1.0 / residuals)
        log_rms = float(math.sqrt(np.mean(np.log(abs_factor_errors) ** 2)))
        max_factor = float(np.max(abs_factor_errors))

        # Use representative candidate values from first row.
        rep = rows[0]

        if q_geo <= cfg.modest_q_max and efolds <= cfg.modest_efolds_max and alpha <= cfg.modest_alpha_max and max_factor <= cfg.local_fit_max_factor_error:
            status = "SINGLE_MODEST_Q_FITS_LOCAL_TARGETS_WITHIN_FACTOR_2"
        elif q_geo <= cfg.modest_q_max and efolds <= cfg.modest_efolds_max:
            status = "SINGLE_MODEST_Q_REACHES_LOCAL_SCALE_BUT_RESIDUALS_EXCEED_FACTOR_2"
        else:
            status = "SINGLE_Q_NOT_MODEST"

        out.append({
            "candidate_name": cand,
            "spacing_fm": rep["spacing_fm"],
            "R_post_AU": rep["R_post_AU"],
            "kT_post_MeV": rep["kT_post_MeV"],
            "single_q_geometric_mean": q_geo,
            "single_q_efolds": efolds,
            "alpha_extra_per_thermal_efold": alpha,
            "single_q_as_fraction_of_60_efolds": efolds / cfg.inflation_reference_efolds,
            "log_rms_factor_error": log_rms,
            "max_factor_error_across_local_targets": max_factor,
            "sound_residual_pred_over_target": float(residuals[list(cfg.local_targets).index("physical_acoustic_sound_horizon")]) if len(residuals) == 3 else math.nan,
            "hubble_residual_pred_over_target": float(residuals[list(cfg.local_targets).index("physical_hubble_radius")]) if len(residuals) == 3 else math.nan,
            "particle_residual_pred_over_target": float(residuals[list(cfg.local_targets).index("physical_particle_horizon")]) if len(residuals) == 3 else math.nan,
            "temperature_reheat_factor_needed_if_adiabatic": q_geo,
            "radiation_energy_density_reheat_factor_q4": q_geo**4,
            "entropy_density_reheat_factor_q3": q_geo**3,
            "status": status,
        })

    return sorted(out, key=lambda r: (r["max_factor_error_across_local_targets"], r["single_q_efolds"]))


def channel_audit_rows(cfg: Config, q_rows: list[dict], single_rows: list[dict]) -> list[dict]:
    """
    Compare interpretations for the best single-q local bridge and selected target bridges.
    """
    best_single = single_rows[0]
    best_by_target = []
    for target in cfg.local_targets + cfg.shell_targets:
        rows = [r for r in q_rows if r["target_name"] == target]
        if rows:
            best_by_target.append(min(rows, key=lambda r: r["extra_efolds"]))

    out = []

    out.append({
        "channel": "pure_thermal_cooling_only",
        "q_extra": 1.0,
        "extra_efolds": 0.0,
        "status": "FAILS_LOCAL_RECOMBINATION_HORIZONS",
        "interpretation": "Gate 12E showed pure thermal cooling underreaches local horizons.",
    })

    out.append({
        "channel": "single_metric_q_for_local_horizons",
        "q_extra": best_single["single_q_geometric_mean"],
        "extra_efolds": best_single["single_q_efolds"],
        "alpha_extra_per_thermal_efold": best_single["alpha_extra_per_thermal_efold"],
        "max_factor_error_across_local_targets": best_single["max_factor_error_across_local_targets"],
        "status": best_single["status"],
        "interpretation": "A single metric-stretch factor applied to the local horizon bridge.",
    })

    for r in best_by_target:
        out.append({
            "channel": f"target_specific_metric_q__{r['target_name']}",
            "q_extra": r["q_required_extra_metric_factor"],
            "extra_efolds": r["extra_efolds"],
            "alpha_extra_per_thermal_efold": r["alpha_extra_per_thermal_efold"],
            "status": r["status"],
            "interpretation": (
                "Target-specific metric stretch. Local targets are primary; LSS targets are observational-shell diagnostics."
            ),
        })

    # Inflation-sized reference.
    q60 = math.exp(cfg.inflation_reference_efolds)
    out.append({
        "channel": "inflation_sized_60_efold_reference",
        "q_extra": q60,
        "extra_efolds": cfg.inflation_reference_efolds,
        "status": "REFERENCE_ONLY_WILDLY_LARGER_THAN_REQUIRED_LOCAL_STRETCH",
        "interpretation": "Comparison marker only; Gate 12F is auditing a few extra e-folds, not 60.",
    })

    # Ordinary adiabatic expansion channel penalty.
    out.append({
        "channel": "ordinary_adiabatic_extra_expansion_interpretation",
        "q_extra": best_single["single_q_geometric_mean"],
        "extra_efolds": best_single["single_q_efolds"],
        "temperature_reheat_factor_needed": best_single["temperature_reheat_factor_needed_if_adiabatic"],
        "radiation_energy_density_reheat_factor_q4": best_single["radiation_energy_density_reheat_factor_q4"],
        "entropy_density_reheat_factor_q3": best_single["entropy_density_reheat_factor_q3"],
        "status": "THERMODYNAMICALLY_COSTLY_IF_TREATED_AS_ORDINARY_ADIABATIC_EXPANSION",
        "interpretation": (
            "If the extra q is ordinary adiabatic expansion after cooling to recombination, it overcools the plasma; "
            "restoring T_rec requires reheating. Cleaner SFT interpretation is metric/spatialization stretch."
        ),
    })

    return out


def verdict(cfg: Config, q_rows: list[dict], single_rows: list[dict], channel_rows: list[dict]) -> dict:
    best_single = single_rows[0]
    local_target_specific = [r for r in q_rows if r["target_name"] in cfg.local_targets]
    q_min = min(r["q_required_extra_metric_factor"] for r in local_target_specific)
    q_max = max(r["q_required_extra_metric_factor"] for r in local_target_specific)
    e_min = min(r["extra_efolds"] for r in local_target_specific)
    e_max = max(r["extra_efolds"] for r in local_target_specific)
    alpha_min = min(r["alpha_extra_per_thermal_efold"] for r in local_target_specific)
    alpha_max = max(r["alpha_extra_per_thermal_efold"] for r in local_target_specific)

    shell_rows = [r for r in q_rows if r["target_name"] in cfg.shell_targets]
    shell_q_min = min(r["q_required_extra_metric_factor"] for r in shell_rows) if shell_rows else math.nan

    if (
        best_single["single_q_geometric_mean"] <= cfg.modest_q_max
        and best_single["single_q_efolds"] <= cfg.modest_efolds_max
        and best_single["alpha_extra_per_thermal_efold"] <= cfg.modest_alpha_max
        and best_single["max_factor_error_across_local_targets"] <= cfg.local_fit_max_factor_error
    ):
        v = "MODEST_METRIC_STRETCH_CHANNEL_NUMERICALLY_VIABLE_NOT_DERIVED"
    else:
        v = "METRIC_STRETCH_CHANNEL_REQUIRES_LARGER_OR_TARGET_SPECIFIC_TUNING"

    return {
        "verdict": v,
        "claim_boundary": "numerical channel audit only; no mechanism, perturbations, or flatness derived",
        "local_target_q_required_min": q_min,
        "local_target_q_required_max": q_max,
        "local_target_extra_efolds_min": e_min,
        "local_target_extra_efolds_max": e_max,
        "local_target_alpha_extra_min": alpha_min,
        "local_target_alpha_extra_max": alpha_max,
        "best_single_q_candidate": best_single["candidate_name"],
        "best_single_q_spacing_fm": best_single["spacing_fm"],
        "best_single_q_R_post_AU": best_single["R_post_AU"],
        "best_single_q_kT_post_MeV": best_single["kT_post_MeV"],
        "best_single_q": best_single["single_q_geometric_mean"],
        "best_single_q_efolds": best_single["single_q_efolds"],
        "best_single_q_alpha_extra": best_single["alpha_extra_per_thermal_efold"],
        "best_single_q_max_factor_error_across_local_targets": best_single["max_factor_error_across_local_targets"],
        "best_single_q_energy_density_reheat_penalty_if_adiabatic_q4": best_single["radiation_energy_density_reheat_factor_q4"],
        "LSS_shell_q_required_min": shell_q_min,
        "LSS_shell_is_primary_target": False,
        "inflation_reference_efolds": cfg.inflation_reference_efolds,
        "best_single_q_efolds_fraction_of_60": best_single["single_q_efolds"] / cfg.inflation_reference_efolds,
        "key_sentence": (
            "The missing recombination bridge can be represented by a single modest local metric stretch "
            "of about a few times ten, roughly three extra e-folds, or about 15-20 percent extra stretch "
            "per thermal e-fold. This is not an inflaton derivation and should not be treated as ordinary "
            "adiabatic expansion unless one also pays the reheating/entropy bookkeeping cost."
        ),
    }


# -----------------------------
# Output
# -----------------------------

def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_outputs(cfg: Config, source_note: str, q_rows: list[dict], single_rows: list[dict], channel_rows: list[dict], ver: dict) -> dict:
    out = Path(cfg.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    q_csv = out / "gate12F_extra_metric_requirements.csv"
    single_csv = out / "gate12F_single_q_local_fits.csv"
    channel_csv = out / "gate12F_channel_audit.csv"
    verdict_csv = out / "gate12F_verdict.csv"
    report = out / "gate12F_modest_metric_stretch_channel_report.txt"

    write_csv(q_csv, q_rows)
    write_csv(single_csv, single_rows)
    write_csv(channel_csv, channel_rows)
    write_csv(verdict_csv, [ver])

    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12F: Modest Metric-Stretch Channel Audit\n")
        f.write("=====================================================\n\n")
        f.write(f"Input source: {source_note}\n\n")
        f.write("Purpose:\n")
        f.write("  Audit whether the 16-31x recombination underreach from Gate 12E can be\n")
        f.write("  represented as a modest metric-stretch channel rather than ordinary transport\n")
        f.write("  or an inflation-sized expansion.\n\n")

        f.write("Best single-q local fits:\n")
        for row in single_rows[:10]:
            f.write(f"  {row}\n")

        f.write("\nChannel audit:\n")
        for row in channel_rows:
            f.write(f"  {row}\n")

        f.write("\nVerdict:\n")
        for k, val in ver.items():
            if isinstance(val, float):
                f.write(f"  {k}: {val:.12e}\n")
            else:
                f.write(f"  {k}: {val}\n")

    plot_paths = []
    try:
        import matplotlib.pyplot as plt

        local_q = [r for r in q_rows if r["target_name"] in cfg.local_targets]
        x_labels = [f"{r['candidate_name']}\n{r['target_name'].replace('physical_', '').replace('_', ' ')}" for r in local_q]
        y = [r["q_required_extra_metric_factor"] for r in local_q]
        xpos = np.arange(len(y))

        plt.figure(figsize=(13, 5))
        plt.scatter(xpos, y)
        plt.axhline(cfg.modest_q_max, linestyle="--", linewidth=1, label="modest q threshold")
        plt.yscale("log")
        plt.xticks(xpos, x_labels, rotation=70, ha="right", fontsize=7)
        plt.ylabel("q required")
        plt.title("Gate 12F: extra metric stretch required for local targets")
        plt.legend()
        plt.tight_layout()
        p = out / "gate12F_q_required_local_targets.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        plt.figure(figsize=(8, 5))
        plt.scatter(
            [r["single_q_geometric_mean"] for r in single_rows],
            [r["max_factor_error_across_local_targets"] for r in single_rows],
        )
        plt.axvline(cfg.modest_q_max, linestyle="--", linewidth=1)
        plt.axhline(cfg.local_fit_max_factor_error, linestyle="--", linewidth=1)
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("single q geometric mean")
        plt.ylabel("max local target factor error")
        plt.title("Gate 12F: single-q local fit quality")
        plt.tight_layout()
        p = out / "gate12F_single_q_fit_quality.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        plt.figure(figsize=(8, 5))
        plt.scatter(
            [r["thermal_efolds_to_rec"] for r in local_q],
            [r["extra_efolds"] for r in local_q],
        )
        plt.axhline(cfg.modest_efolds_max, linestyle="--", linewidth=1)
        plt.xlabel("thermal e-folds to recombination")
        plt.ylabel("extra metric e-folds")
        plt.title("Gate 12F: extra e-folds are small compared to thermal cooling")
        plt.tight_layout()
        p = out / "gate12F_extra_vs_thermal_efolds.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")

    return {
        "out_dir": str(out),
        "report": str(report),
        "q_csv": str(q_csv),
        "single_csv": str(single_csv),
        "channel_csv": str(channel_csv),
        "verdict_csv": str(verdict_csv),
        "plot_paths": plot_paths,
    }


def print_dict(row: dict, indent: str = "  ") -> None:
    for k, val in row.items():
        if isinstance(val, float):
            print(f"{indent}{k}: {val:.12e}")
        else:
            print(f"{indent}{k}: {val}")


def main() -> None:
    cfg = Config()
    bridge_rows, source_note = load_gate12e_rows(cfg)
    q_rows = q_requirement_rows(cfg, bridge_rows)
    single_rows = single_q_fit_rows(cfg, q_rows)
    channel_rows = channel_audit_rows(cfg, q_rows, single_rows)
    ver = verdict(cfg, q_rows, single_rows, channel_rows)
    paths = save_outputs(cfg, source_note, q_rows, single_rows, channel_rows, ver)

    print("\nSFT V12 GATE 12F RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Modest metric-stretch channel audit for the Gate 12E recombination underreach.")
    print("  No stretch mechanism, inflation replacement, perturbations, or flatness derivation is claimed.")
    print(f"\nInput source: {source_note}")

    print("\nBest target-specific local q requirements:")
    for target in cfg.local_targets:
        rows = [r for r in q_rows if r["target_name"] == target]
        best = min(rows, key=lambda r: r["extra_efolds"])
        print(f"\n  {target}")
        for k in [
            "candidate_name",
            "spacing_fm",
            "R_post_AU",
            "kT_post_MeV",
            "q_required_extra_metric_factor",
            "extra_efolds",
            "alpha_extra_per_thermal_efold",
            "extra_efolds_as_fraction_of_60",
            "radiation_energy_density_reheat_factor_q4",
            "status",
        ]:
            val = best[k]
            if isinstance(val, float):
                print(f"    {k}: {val:.12e}")
            else:
                print(f"    {k}: {val}")

    print("\nBest single-q local fits:")
    for i, row in enumerate(single_rows[:7], start=1):
        print(f"\n  #{i}")
        for k in [
            "candidate_name",
            "spacing_fm",
            "R_post_AU",
            "kT_post_MeV",
            "single_q_geometric_mean",
            "single_q_efolds",
            "alpha_extra_per_thermal_efold",
            "max_factor_error_across_local_targets",
            "sound_residual_pred_over_target",
            "hubble_residual_pred_over_target",
            "particle_residual_pred_over_target",
            "radiation_energy_density_reheat_factor_q4",
            "status",
        ]:
            val = row[k]
            if isinstance(val, float):
                print(f"    {k}: {val:.12e}")
            else:
                print(f"    {k}: {val}")

    print("\nChannel audit:")
    for row in channel_rows:
        print(f"\n  {row['channel']}")
        for k, val in row.items():
            if k == "channel":
                continue
            if isinstance(val, float):
                print(f"    {k}: {val:.12e}")
            else:
                print(f"    {k}: {val}")

    print("\nGate 12F verdict:")
    print_dict(ver, "  ")

    print("\nFiles:")
    print(f"  output directory: {paths['out_dir']}")
    print(f"  report: {paths['report']}")
    print(f"  q requirements csv: {paths['q_csv']}")
    print(f"  single-q fits csv: {paths['single_csv']}")
    print(f"  channel audit csv: {paths['channel_csv']}")
    print(f"  verdict csv: {paths['verdict_csv']}")
    for p in paths["plot_paths"]:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
