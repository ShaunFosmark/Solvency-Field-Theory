#!/usr/bin/env python3
"""
SFT V12 Gate 12L:
End-to-End Shatter-to-Recombination Closure with alpha = 1/6 Locked

Mobile-ready. No prior output folders required.

Purpose
-------
This is the single continuous closure calculation proposed after Gate 12K.

No sweeps. No fitting. No re-optimizing.

Pipeline:
    1. Pre-shatter / unified ticking seed from V12 One Addendum / Gate 12A.
    2. Frozen QCD/fm spatialization candidates from Gates 12D-12F.
    3. Ordinary thermal cooling:
            a_T = T_post / T_rec
    4. Locked lag-burst settlement stretch:
            Q = a_T^(1/6)
       equivalently:
            Q^3 = sqrt(a_T)
    5. Effective recombination settlement scale:
            R_eff_rec = R_post * a_T * Q
    6. Compare to Gate 11R local recombination ledgers:
            sound horizon, Hubble radius, particle horizon.

Claim boundary
--------------
This script does NOT:
    - derive the shatter mechanism;
    - prove alpha=1/6 from V11.1B;
    - run BBN/CMB perturbation constraints;
    - replace a Boltzmann code;
    - fit, sweep, or tune alpha.

It DOES:
    - lock alpha=1/6;
    - use frozen spatialization candidates;
    - compute one end-to-end closure residual per target;
    - identify whether the toy chain closes at factor-2 / factor-1.5 level.

Important wording
-----------------
alpha=1/6 is treated here as the Gate 12K no-cheat candidate:
    Q^3 = sqrt(a_T)

It should NOT be called fully derived until connected to V11.1B lag/stress
dynamics or no-overwrite boundary service.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
import numpy as np


OUT_DIR = Path("SFT_V12_GATE_12L_OUTPUT")

# Constants
AU_M = 1.495978707e11
LY_M = 9.4607304725808e15
MLY_M = 1.0e6 * LY_M
MEV_TO_EV = 1.0e6

# Locked Gate 12K law
ALPHA_LOCKED = 1.0 / 6.0
MU_VOLUME_LOCKED = 3.0 * ALPHA_LOCKED  # 1/2

# V12 One / Gate 12A pre-shatter seed.
# These are used as a provenance/continuity ledger. The closure radius calculation
# starts from frozen post-shatter QCD/fm candidates.
PRE_SHATTER_SEED = {
    "N_ticks_or_baryon_marker": 1.0e80,
    "R_area_nominal_km": 45.5937,
    "R_area_cycle_consistent_km": 114.286,
    "t_shatter_cycle_s": 6.62607015e-23,
    "t_shatter_radian_s": 1.0546e-23,
    "T_density_K": 2.402e17,
    "kT_density_TeV": 20.699,
    "E_per_piece_MeV": 62.41509074461,
    "R_schwarzschild_m": 1.653e25,
    "R_over_Rs": 2.759e-21,
    "ct_over_R": 4.357e-19,
    "interpretation": "boundary-equivalent / pre-geometric seed, not ordinary spatial ball",
}

# Gate 11R recombination snapshot local scales.
LOCAL_TARGETS_MLY = {
    "sound_horizon": 0.4318077002313,
    "hubble_radius": 0.6246982112007,
    "particle_horizon": 0.8375182455706,
}

# Recombination thermal marker from prior gates.
RECOMBINATION = {
    "T_rec_K": 2973.30246,
    "kT_rec_eV": 0.2562193818698,
    "kT_rec_MeV": 0.2562193818698e-6,
}

# Frozen Gate 12D/12E/12F spatialization candidates.
# Primary is the Gate 12F/12G best single-q local candidate.
SPATIALIZATION_CANDIDATES = [
    {
        "candidate_id": "PRIMARY_thermal_Compton_fixed_kT_equals_hbarc_over_s",
        "gate_origin": "Gate 12F/12G best single-q local fit candidate, frozen before alpha=1/6 lock",
        "spacing_fm": 2.080201237123,
        "R_post_AU": 4.003904729680,
        "kT_post_MeV": 94.85956307390,
        "rank_status": "PRIMARY",
    },
    {
        "candidate_id": "thermal_piece_fixed_kT_equals_Epiece",
        "gate_origin": "Gate 12D/12E best combined QCD bridge candidate",
        "spacing_fm": 3.634913121798,
        "R_post_AU": 6.996364380818,
        "kT_post_MeV": 62.41509074461,
        "rank_status": "FROZEN_COMPARISON",
    },
    {
        "candidate_id": "piece_energy_reduced_Compton",
        "gate_origin": "Gate 12D/12E QCD comparison",
        "spacing_fm": 3.16153,
        "R_post_AU": 6.08521,
        "kT_post_MeV": 69.3007,
        "rank_status": "FROZEN_COMPARISON",
    },
    {
        "candidate_id": "classical_electron_radius",
        "gate_origin": "Gate 12E comparison",
        "spacing_fm": 2.81794,
        "R_post_AU": 5.42388,
        "kT_post_MeV": 75.546,
        "rank_status": "FROZEN_COMPARISON",
    },
    {
        "candidate_id": "one_fermi",
        "gate_origin": "Gate 12D/12E QCD comparison",
        "spacing_fm": 1.0,
        "R_post_AU": 1.92477,
        "kT_post_MeV": 164.309,
        "rank_status": "FROZEN_COMPARISON",
    },
    {
        "candidate_id": "QCD_200MeV",
        "gate_origin": "Gate 12D/12E QCD comparison",
        "spacing_fm": 0.9866,
        "R_post_AU": 1.89904,
        "kT_post_MeV": 165.975,
        "rank_status": "FROZEN_COMPARISON",
    },
    {
        "candidate_id": "proton_radius",
        "gate_origin": "Gate 12E comparison",
        "spacing_fm": 0.8409,
        "R_post_AU": 1.61854,
        "kT_post_MeV": 187.112,
        "rank_status": "FROZEN_COMPARISON",
    },
]

# Fit-alpha diagnostic from Gate 12G/12K. Not used for locked closure verdict.
FIT_DIAGNOSTIC = {
    "alpha_fit": 0.1651051079717,
    "q_rec_fit_primary": 25.98352226410,
    "R_eff_rec_Mly_fit_primary": 0.6090481672918,
}


def factor_error(pred: float, target: float) -> float:
    ratio = pred / target
    return max(ratio, 1.0 / ratio)


def closure_status(max_factor_error: float) -> str:
    if max_factor_error <= 1.5:
        return "STRIKING_TOY_CLOSURE_WITHIN_FACTOR_1P5"
    if max_factor_error <= 2.0:
        return "TOY_CLOSURE_WITHIN_FACTOR_2"
    if max_factor_error <= 3.0:
        return "MARGINAL_TENSION_WITHIN_FACTOR_3"
    return "FAILS_END_TO_END_LOCAL_GEOMETRY_WINDOW"


def candidate_closure_rows() -> list[dict]:
    rows = []
    kT_rec_MeV = RECOMBINATION["kT_rec_MeV"]

    for cand in SPATIALIZATION_CANDIDATES:
        kT_post = cand["kT_post_MeV"]
        a_T = kT_post / kT_rec_MeV
        Q = a_T ** ALPHA_LOCKED
        a_L = a_T * Q

        R_thermal_Mly = cand["R_post_AU"] * a_T * AU_M / MLY_M
        R_eff_Mly = R_thermal_Mly * Q

        target_ratios = {}
        target_factors = {}
        for name, target in LOCAL_TARGETS_MLY.items():
            target_ratios[f"{name}_pred_over_target"] = R_eff_Mly / target
            target_factors[f"{name}_factor_error"] = factor_error(R_eff_Mly, target)

        max_factor = max(target_factors.values())

        # Fit diagnostic if this candidate used alpha_fit instead.
        Q_fit_diag = a_T ** FIT_DIAGNOSTIC["alpha_fit"]
        R_fit_diag = R_thermal_Mly * Q_fit_diag

        rows.append({
            "candidate_id": cand["candidate_id"],
            "rank_status": cand["rank_status"],
            "gate_origin": cand["gate_origin"],
            "spacing_fm": cand["spacing_fm"],
            "R_post_AU": cand["R_post_AU"],
            "kT_post_MeV": kT_post,
            "kT_rec_MeV": kT_rec_MeV,
            "alpha_locked": ALPHA_LOCKED,
            "mu_volume_locked_3alpha": MU_VOLUME_LOCKED,
            "a_T_thermal_growth": a_T,
            "Q_locked_aT_1_over_6": Q,
            "Q3_volume_ratio_sqrt_aT": Q**3,
            "Q4_forbidden_thermal_penalty": Q**4,
            "a_L_ledger_growth": a_L,
            "R_thermal_rec_Mly": R_thermal_Mly,
            "R_eff_rec_Mly_locked": R_eff_Mly,
            **target_ratios,
            **target_factors,
            "max_local_target_factor_error": max_factor,
            "closure_status": closure_status(max_factor),
            "Q_fit_alpha_diagnostic": Q_fit_diag,
            "R_eff_rec_Mly_fit_alpha_diagnostic": R_fit_diag,
            "locked_R_over_fit_R_diagnostic": R_eff_Mly / R_fit_diag,
            "claim_status": "NO_FIT_ALPHA_LOCKED_SPATIALIZATION_FROZEN",
        })

    # Preserve declared primary first, then sort comparisons by factor error.
    primary = [r for r in rows if r["rank_status"] == "PRIMARY"]
    comps = sorted([r for r in rows if r["rank_status"] != "PRIMARY"], key=lambda r: r["max_local_target_factor_error"])
    return primary + comps


def target_rows(primary_row: dict) -> list[dict]:
    rows = []
    for name, target in LOCAL_TARGETS_MLY.items():
        pred = primary_row["R_eff_rec_Mly_locked"]
        ratio = pred / target
        rows.append({
            "target_name": name,
            "R_target_Mly": target,
            "R_eff_rec_Mly_locked_primary": pred,
            "pred_over_target": ratio,
            "factor_error": max(ratio, 1.0 / ratio),
            "status": "PRIMARY_LOCKED_ALPHA_ONE_SIXTH",
        })
    return rows


def pipeline_rows(primary_row: dict) -> list[dict]:
    return [
        {
            "step": 1,
            "stage": "unified_pre_shatter_seed",
            "input": "N~1e80, unified ticking, boundary-equivalent radius",
            "output": f"R_area~{PRE_SHATTER_SEED['R_area_nominal_km']} km, t_shatter~{PRE_SHATTER_SEED['t_shatter_cycle_s']} s",
            "free_parameter": False,
            "claim_boundary": "pre-geometric boundary-equivalent seed, not ordinary spatial ball",
        },
        {
            "step": 2,
            "stage": "QCD_fm_spatialization",
            "input": "frozen primary spatialization candidate",
            "output": f"s={primary_row['spacing_fm']} fm, R_post={primary_row['R_post_AU']} AU, kT_post={primary_row['kT_post_MeV']} MeV",
            "free_parameter": "frozen candidate ambiguity only",
            "claim_boundary": "spacing selected from prior Gate 12D/12F candidates, not refit here",
        },
        {
            "step": 3,
            "stage": "thermal_cooling",
            "input": "kT_post to kT_rec",
            "output": f"a_T={primary_row['a_T_thermal_growth']}",
            "free_parameter": False,
            "claim_boundary": "ordinary thermal scale",
        },
        {
            "step": 4,
            "stage": "locked_lag_burst_settlement",
            "input": "Gate 12K no-cheat rule",
            "output": f"Q=a_T^(1/6)={primary_row['Q_locked_aT_1_over_6']}, Q^3=sqrt(a_T)={primary_row['Q3_volume_ratio_sqrt_aT']}",
            "free_parameter": False,
            "claim_boundary": "source hint, not yet derived from V11.1B",
        },
        {
            "step": 5,
            "stage": "effective_recombination_geometry",
            "input": "R_post * a_T * Q",
            "output": f"R_eff_rec={primary_row['R_eff_rec_Mly_locked']} Mly",
            "free_parameter": False,
            "claim_boundary": "settlement geometry scale, not photon cooling scale",
        },
        {
            "step": 6,
            "stage": "Gate_11R_target_comparison",
            "input": "sound/Hubble/particle local targets",
            "output": f"max factor error={primary_row['max_local_target_factor_error']}",
            "free_parameter": False,
            "claim_boundary": "toy closure only, not full CMB spectrum",
        },
    ]


def verdict_row(rows: list[dict]) -> dict:
    primary = rows[0]
    best = min(rows, key=lambda r: r["max_local_target_factor_error"])

    verdict = primary["closure_status"]
    if primary["max_local_target_factor_error"] <= 1.5:
        summary = "Primary locked-alpha chain closes at striking toy level."
    elif primary["max_local_target_factor_error"] <= 2.0:
        summary = "Primary locked-alpha chain closes at factor-2 toy level."
    elif primary["max_local_target_factor_error"] <= 3.0:
        summary = "Primary locked-alpha chain is marginal and points to spatialization/target tension."
    else:
        summary = "Primary locked-alpha chain fails the toy local geometry window."

    return {
        "verdict": verdict,
        "claim_boundary": "end-to-end toy closure only; alpha=1/6 mechanism, BBN/CMB constraints, perturbations, flatness, and inflation replacement are not derived",
        "primary_candidate": primary["candidate_id"],
        "primary_spacing_fm": primary["spacing_fm"],
        "primary_R_post_AU": primary["R_post_AU"],
        "primary_kT_post_MeV": primary["kT_post_MeV"],
        "alpha_locked": ALPHA_LOCKED,
        "locked_rule": "Q=a_T^(1/6), equivalently Q^3=sqrt(a_T)",
        "primary_a_T": primary["a_T_thermal_growth"],
        "primary_Q": primary["Q_locked_aT_1_over_6"],
        "primary_Q3": primary["Q3_volume_ratio_sqrt_aT"],
        "primary_R_thermal_rec_Mly": primary["R_thermal_rec_Mly"],
        "primary_R_eff_rec_Mly": primary["R_eff_rec_Mly_locked"],
        "primary_sound_factor_error": primary["sound_horizon_factor_error"],
        "primary_hubble_factor_error": primary["hubble_radius_factor_error"],
        "primary_particle_factor_error": primary["particle_horizon_factor_error"],
        "primary_max_local_target_factor_error": primary["max_local_target_factor_error"],
        "best_frozen_candidate_by_factor_error": best["candidate_id"],
        "best_frozen_candidate_max_factor_error": best["max_local_target_factor_error"],
        "best_frozen_candidate_R_eff_rec_Mly": best["R_eff_rec_Mly_locked"],
        "summary": summary,
        "key_sentence": (
            "Gate 12L locks alpha=1/6 and runs the frozen shatter-to-recombination chain with no alpha fit: "
            "QCD/fm spatialization, ordinary thermal cooling, and square-root settlement-volume relaxation "
            "produce a recombination settlement scale compared directly to the Gate 11R local sound/Hubble/particle ledgers. "
            "The result is a toy closure residual, not a full cosmological derivation."
        ),
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_plots(rows: list[dict], target_comp: list[dict]) -> list[str]:
    plots = []
    try:
        import matplotlib.pyplot as plt

        labels = [r["candidate_id"].replace("PRIMARY_", "") for r in rows]
        x = np.arange(len(labels))

        plt.figure(figsize=(12, 5))
        plt.scatter(x, [r["max_local_target_factor_error"] for r in rows])
        plt.axhline(1.5, linestyle="--", linewidth=1)
        plt.axhline(2.0, linestyle=":", linewidth=1)
        plt.axhline(3.0, linestyle="-.", linewidth=1)
        plt.xticks(x, labels, rotation=65, ha="right", fontsize=7)
        plt.ylabel("max local target factor error")
        plt.title("Gate 12L: locked alpha=1/6 end-to-end residual by frozen spatialization candidate")
        plt.tight_layout()
        p = OUT_DIR / "gate12L_candidate_factor_errors.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        primary = rows[0]
        target_names = [r["target_name"] for r in target_comp]
        target_vals = [r["R_target_Mly"] for r in target_comp]
        pred_vals = [primary["R_eff_rec_Mly_locked"]] * len(target_names)
        xpos = np.arange(len(target_names))
        width = 0.35
        plt.figure(figsize=(8, 5))
        plt.bar(xpos - width/2, target_vals, width, label="Gate 11R target")
        plt.bar(xpos + width/2, pred_vals, width, label="12L prediction")
        plt.xticks(xpos, target_names, rotation=20, ha="right")
        plt.ylabel("Mly")
        plt.title("Gate 12L: primary prediction vs local recombination ledgers")
        plt.legend()
        plt.tight_layout()
        p = OUT_DIR / "gate12L_primary_targets.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def print_kv(row: dict, keys=None, indent="  ") -> None:
    items = row.items() if keys is None else [(k, row[k]) for k in keys]
    for k, v in items:
        if isinstance(v, float):
            print(f"{indent}{k}: {v:.12e}")
        else:
            print(f"{indent}{k}: {v}")


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    rows = candidate_closure_rows()
    primary = rows[0]
    targets = target_rows(primary)
    pipeline = pipeline_rows(primary)
    verdict = verdict_row(rows)
    plots = save_plots(rows, targets)

    write_csv(OUT_DIR / "gate12L_pre_shatter_seed.csv", [PRE_SHATTER_SEED])
    write_csv(OUT_DIR / "gate12L_spatialization_candidates_locked_alpha.csv", rows)
    write_csv(OUT_DIR / "gate12L_primary_target_comparison.csv", targets)
    write_csv(OUT_DIR / "gate12L_pipeline_steps.csv", pipeline)
    write_csv(OUT_DIR / "gate12L_verdict.csv", [verdict])

    report = OUT_DIR / "gate12L_end_to_end_closure_report.txt"
    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12L: End-to-End Shatter-to-Recombination Closure with alpha=1/6 Locked\n")
        f.write("====================================================================================\n\n")
        f.write("Pre-shatter seed:\n")
        for k, v in PRE_SHATTER_SEED.items():
            f.write(f"  {k}: {v}\n")
        f.write("\nPipeline:\n")
        for row in pipeline:
            f.write(f"  {row}\n")
        f.write("\nCandidate closure rows:\n")
        for row in rows:
            f.write(f"  {row}\n")
        f.write("\nPrimary target comparison:\n")
        for row in targets:
            f.write(f"  {row}\n")
        f.write("\nVerdict:\n")
        for k, v in verdict.items():
            f.write(f"  {k}: {v}\n")

    print("\nSFT V12 GATE 12L RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  End-to-end shatter-to-recombination closure with alpha=1/6 locked.")
    print("  No alpha fitting, no sweeps, no BBN/CMB perturbation claim.")

    print("\nPre-shatter seed:")
    print_kv(PRE_SHATTER_SEED, [
        "N_ticks_or_baryon_marker",
        "R_area_nominal_km",
        "t_shatter_cycle_s",
        "T_density_K",
        "kT_density_TeV",
        "E_per_piece_MeV",
        "interpretation",
    ])

    print("\nPipeline steps:")
    for row in pipeline:
        print(f"\n  Step {row['step']}: {row['stage']}")
        print_kv(row, ["input", "output", "free_parameter", "claim_boundary"], indent="    ")

    print("\nLocked alpha closure rows:")
    for row in rows:
        print(f"\n  {row['candidate_id']}")
        print_kv(row, [
            "rank_status",
            "spacing_fm",
            "R_post_AU",
            "kT_post_MeV",
            "alpha_locked",
            "a_T_thermal_growth",
            "Q_locked_aT_1_over_6",
            "Q3_volume_ratio_sqrt_aT",
            "R_thermal_rec_Mly",
            "R_eff_rec_Mly_locked",
            "sound_horizon_factor_error",
            "hubble_radius_factor_error",
            "particle_horizon_factor_error",
            "max_local_target_factor_error",
            "closure_status",
            "locked_R_over_fit_R_diagnostic",
        ], indent="    ")

    print("\nPrimary target comparison:")
    for row in targets:
        print(f"\n  {row['target_name']}")
        print_kv(row, ["R_target_Mly", "R_eff_rec_Mly_locked_primary", "pred_over_target", "factor_error"], indent="    ")

    print("\nGate 12L verdict:")
    print_kv(verdict)

    print("\nFiles:")
    print(f"  output directory: {OUT_DIR}")
    print(f"  report: {report}")
    print(f"  pre-shatter seed csv: {OUT_DIR / 'gate12L_pre_shatter_seed.csv'}")
    print(f"  closure candidates csv: {OUT_DIR / 'gate12L_spatialization_candidates_locked_alpha.csv'}")
    print(f"  primary targets csv: {OUT_DIR / 'gate12L_primary_target_comparison.csv'}")
    print(f"  pipeline steps csv: {OUT_DIR / 'gate12L_pipeline_steps.csv'}")
    print(f"  verdict csv: {OUT_DIR / 'gate12L_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
