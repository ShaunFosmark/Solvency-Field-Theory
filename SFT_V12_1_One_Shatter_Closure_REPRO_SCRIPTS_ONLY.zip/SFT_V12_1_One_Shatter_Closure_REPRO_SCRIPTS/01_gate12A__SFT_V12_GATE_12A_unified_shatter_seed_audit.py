#!/usr/bin/env python3
"""
SFT V12 Gate 12A: Unified Shatter Seed Audit

Audits the V12 One Addendum seed:
  - one unified pre-shatter ticking process
  - N accumulated boundary writes
  - shatter into many distributed local tickers

This is an audit, not a derivation of a_phi, baryon number, particle masses,
or the shatter mechanism.

It recomputes:
  R_shatter, t_shatter, T_shatter, E/N, R_s, R/R_s, boundary growth rate,
  and c t / R for cycle-vs-radian convention branches.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path

import numpy as np

# Constants
c = 299_792_458.0
h = 6.626_070_15e-34
hbar = h / (2 * math.pi)
G = 6.674_30e-11
kB = 1.380_649e-23
sigma_sb = 5.670_374_419e-8
a_rad = 4 * sigma_sb / c
m_p = 1.672_621_923_69e-27
m_e = 9.109_383_7015e-31
eV = 1.602_176_634e-19
MeV = 1.0e6 * eV
TeV = 1.0e12 * eV

a_phi = hbar * G / c**3
A0 = h * G / c**3
l_root = math.sqrt(a_phi)
t_planck = math.sqrt(hbar * G / c**5)

OUT = Path("SFT_V12_GATE_12A_OUTPUT")


def sphere_radius_from_area(A: float) -> float:
    return math.sqrt(A / (4 * math.pi))


def sphere_area(R: float) -> float:
    return 4 * math.pi * R * R


def sphere_volume(R: float) -> float:
    return 4 * math.pi * R**3 / 3


def schwarzschild_radius(E: float) -> float:
    return 2 * G * E / c**4


def radiation_temperature(E: float, V: float) -> float:
    return (E / V / a_rad) ** 0.25


def convention_name(rate_kind: str, area_kind: str) -> str:
    if rate_kind == "cycles" and area_kind == "a_phi":
        return "mixed_addendum_like_cycles_time_a_phi_area"
    if rate_kind == "cycles" and area_kind == "A0":
        return "cycle_consistent_cycles_time_A0_area"
    if rate_kind == "radians" and area_kind == "a_phi":
        return "radian_consistent_radian_time_a_phi_area"
    if rate_kind == "radians" and area_kind == "A0":
        return "radian_time_cycle_area_crosscheck"
    return f"{rate_kind}_{area_kind}"


def compute(E: float, N: float, rate_kind: str, area_kind: str, case_label: str) -> dict:
    quantum = h if rate_kind == "cycles" else hbar
    area_unit = a_phi if area_kind == "a_phi" else A0
    rate = E / quantum
    t = N / rate
    A = N * area_unit
    R = sphere_radius_from_area(A)
    V = sphere_volume(R)
    T = radiation_temperature(E, V)
    Rs = schwarzschild_radius(E)
    light_time = R / c
    ct_over_R = c * t / R
    E_light = quantum * N / light_time

    return {
        "case_label": case_label,
        "convention": convention_name(rate_kind, area_kind),
        "rate_kind": rate_kind,
        "area_kind": area_kind,
        "E_total_J": E,
        "N_count": N,
        "log10_E": math.log10(E),
        "log10_N": math.log10(N),
        "area_unit_m2": area_unit,
        "area_total_m2": A,
        "R_shatter_m": R,
        "R_shatter_km": R / 1e3,
        "volume_m3": V,
        "tick_rate_per_s": rate,
        "t_shatter_s": t,
        "boundary_growth_rate_m2_s": area_unit * rate,
        "T_shatter_K": T,
        "kT_TeV": kB * T / TeV,
        "kT_GeV": kB * T / (1e9 * eV),
        "E_per_piece_MeV": E / N / MeV,
        "E_per_piece_GeV": E / N / (1e9 * eV),
        "R_schwarzschild_m": Rs,
        "R_over_Rs": R / Rs,
        "Rs_over_R": Rs / R,
        "light_crossing_s": light_time,
        "ct_shatter_over_R": ct_over_R,
        "R_over_ct_shatter": 1 / ct_over_R if ct_over_R else math.inf,
        "t_over_planck_time": t / t_planck,
        "R_over_lroot": R / l_root,
        "E_required_for_t_equal_R_over_c_J": E_light,
        "E_required_light_crossing_ratio_to_E": E_light / E,
        "a_phi_required_for_R_and_N_m2": sphere_area(R) / N,
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def make_main_rows() -> list[dict]:
    E0 = 1e69
    N0 = 1e80
    cases = [
        ("addendum_nominal_E1e69_N1e80", E0, N0),
        ("N1e80_proton_rest_energy", N0 * m_p * c**2, N0),
        ("N1e80_proton_plus_electron_rest_energy", N0 * (m_p + m_e) * c**2, N0),
        ("low_energy_E1e68_N1e80", 1e68, N0),
        ("high_energy_E1e70_N1e80", 1e70, N0),
        ("low_count_E1e69_N1e79", E0, 1e79),
        ("high_count_E1e69_N1e81", E0, 1e81),
    ]
    conventions = [("cycles", "a_phi"), ("cycles", "A0"), ("radians", "a_phi"), ("radians", "A0")]
    rows = []
    for label, E, N in cases:
        for rk, ak in conventions:
            rows.append(compute(E, N, rk, ak, label))
    return rows


def make_sweep_rows() -> list[dict]:
    rows = []
    conventions = [("cycles", "a_phi"), ("cycles", "A0"), ("radians", "a_phi")]
    for logE in np.linspace(68, 71, 61):
        E = 10**float(logE)
        for logN in np.linspace(78, 82, 81):
            N = 10**float(logN)
            for rk, ak in conventions:
                r = compute(E, N, rk, ak, "grid_sweep")
                flags = {
                    "flag_radius_10_to_200_km": 10 <= r["R_shatter_km"] <= 200,
                    "flag_kT_0p1_to_100_TeV": 0.1 <= r["kT_TeV"] <= 100,
                    "flag_piece_10_to_1000_MeV": 10 <= r["E_per_piece_MeV"] <= 1000,
                    "flag_t_1e_minus24_to_1e_minus20_s": 1e-24 <= r["t_shatter_s"] <= 1e-20,
                    "flag_inside_Rs": r["R_over_Rs"] < 1,
                    "flag_ct_over_R_ge_1": r["ct_shatter_over_R"] >= 1,
                }
                r.update(flags)
                r["coincidence_score_noncausal_out_of_5"] = sum(bool(flags[k]) for k in [
                    "flag_radius_10_to_200_km",
                    "flag_kT_0p1_to_100_TeV",
                    "flag_piece_10_to_1000_MeV",
                    "flag_t_1e_minus24_to_1e_minus20_s",
                    "flag_inside_Rs",
                ])
                rows.append(r)
    return rows


def summarize_sweep(rows: list[dict]) -> list[dict]:
    out = []
    groups = {}
    for r in rows:
        groups.setdefault(r["convention"], []).append(r)

    targets = {"R_shatter_km": 45.6, "kT_TeV": 20.7, "E_per_piece_MeV": 62.4, "t_shatter_s": 6.63e-23}

    def dist_to_nominal(r: dict) -> float:
        return math.sqrt(sum(math.log10(r[k] / v) ** 2 for k, v in targets.items()))

    for conv, group in groups.items():
        gold = [r for r in group if r["coincidence_score_noncausal_out_of_5"] == 5]
        causal_gold = [r for r in gold if r["flag_ct_over_R_ge_1"]]
        best_score = max(r["coincidence_score_noncausal_out_of_5"] for r in group)
        best_pool = [r for r in group if r["coincidence_score_noncausal_out_of_5"] == best_score]
        best = min(best_pool, key=dist_to_nominal)
        out.append({
            "convention": conv,
            "num_rows": len(group),
            "best_coincidence_score_noncausal_out_of_5": best_score,
            "num_rows_all_5_noncausal_gold_flags": len(gold),
            "num_rows_all_5_plus_ct_over_R_ge_1": len(causal_gold),
            "best_nominal_log_distance": dist_to_nominal(best),
            "best_nominal_log10_E": best["log10_E"],
            "best_nominal_log10_N": best["log10_N"],
            "best_nominal_R_km": best["R_shatter_km"],
            "best_nominal_kT_TeV": best["kT_TeV"],
            "best_nominal_E_piece_MeV": best["E_per_piece_MeV"],
            "best_nominal_t_s": best["t_shatter_s"],
            "best_nominal_R_over_Rs": best["R_over_Rs"],
            "best_nominal_ct_over_R": best["ct_shatter_over_R"],
        })
    return sorted(out, key=lambda x: x["convention"])


def inverse_rows() -> list[dict]:
    R = 45.6e3
    N = 1e80
    E = 1e69
    rows = []
    for name, unit in [("a_phi", a_phi), ("A0", A0)]:
        rows.append({
            "relation": f"N_required_for_R45p6km_using_{name}",
            "value": sphere_area(R) / unit,
            "log10_value": math.log10(sphere_area(R) / unit),
            "note": "N = 4*pi*R^2 / area_unit",
        })
        rows.append({
            "relation": f"area_unit_required_for_R45p6km_N1e80_vs_{name}",
            "value_m2": sphere_area(R) / N,
            "ratio_to_reference_unit": (sphere_area(R) / N) / unit,
            "note": "area_unit = 4*pi*R^2 / N",
        })
    for rate, quantum in [("cycles_h", h), ("radians_hbar", hbar)]:
        rows.append({
            "relation": f"t_for_N1e80_E1e69_{rate}",
            "value_s": quantum * N / E,
            "log10_value_s": math.log10(quantum * N / E),
            "note": "t = quantum*N/E",
        })
        rows.append({
            "relation": f"E_required_for_t_6p63e_minus23_N1e80_{rate}",
            "value_J": quantum * N / 6.63e-23,
            "ratio_to_E1e69": (quantum * N / 6.63e-23) / E,
            "note": "E = quantum*N/t",
        })
        rows.append({
            "relation": f"E_required_for_light_crossing_R45p6km_N1e80_{rate}",
            "value_J": quantum * N * c / R,
            "ratio_to_E1e69": (quantum * N * c / R) / E,
            "note": "Sets t = R/c for ordinary spatial causal coordination.",
        })
    return rows


def save_report(main_rows: list[dict], sweep_summary: list[dict], inv: list[dict], paths: dict) -> None:
    add = next(r for r in main_rows if r["case_label"] == "addendum_nominal_E1e69_N1e80" and r["convention"] == "mixed_addendum_like_cycles_time_a_phi_area")
    cyc = next(r for r in main_rows if r["case_label"] == "addendum_nominal_E1e69_N1e80" and r["convention"] == "cycle_consistent_cycles_time_A0_area")
    rad = next(r for r in main_rows if r["case_label"] == "addendum_nominal_E1e69_N1e80" and r["convention"] == "radian_consistent_radian_time_a_phi_area")

    with open(paths["report"], "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12A: Unified Shatter Seed Audit\n")
        f.write("============================================\n\n")
        f.write("Reference markers:\n")
        f.write(f"  a_phi = hbar G/c^3 = {a_phi:.12e} m^2\n")
        f.write(f"  A0 = h G/c^3 = 2pi a_phi = {A0:.12e} m^2/cycle\n")
        f.write(f"  sqrt(a_phi) = {l_root:.12e} m\n\n")

        f.write("Nominal addendum-like branch:\n")
        for k, v in add.items():
            if isinstance(v, float):
                f.write(f"  {k}: {v:.12e}\n")
            else:
                f.write(f"  {k}: {v}\n")

        f.write("\nConvention shifts:\n")
        f.write(f"  cycle_consistent_R/addendum_R = {cyc['R_shatter_km']/add['R_shatter_km']:.12e}\n")
        f.write(f"  radian_consistent_t/addendum_t = {rad['t_shatter_s']/add['t_shatter_s']:.12e}\n")
        f.write(f"  expected sqrt(2pi) = {math.sqrt(2*math.pi):.12e}\n")
        f.write(f"  expected 1/(2pi) = {1/(2*math.pi):.12e}\n\n")

        f.write("Sweep summary:\n")
        for row in sweep_summary:
            f.write(f"\n  {row['convention']}\n")
            for k, v in row.items():
                if k == "convention":
                    continue
                if isinstance(v, float):
                    f.write(f"    {k}: {v:.12e}\n")
                else:
                    f.write(f"    {k}: {v}\n")

        f.write("\nInverse relations:\n")
        for row in inv:
            f.write(f"  {row}\n")

        f.write("\nVerdict:\n")
        f.write("  PROMISING_SEED_WITH_CONVENTION_AND_CAUSALITY_GATES\n")
        f.write("  The nominal toy reproduces the striking scale cluster, but the 2pi convention\n")
        f.write("  and ordinary-spatial causal-coherence gate must be resolved before this becomes\n")
        f.write("  a claim rather than a seed.\n")


def make_plots(sweep_rows: list[dict]) -> list[str]:
    plot_paths = []
    try:
        import matplotlib.pyplot as plt
        add = [r for r in sweep_rows if r["convention"] == "mixed_addendum_like_cycles_time_a_phi_area"]

        p = OUT / "gate12A_radius_vs_piece_energy.png"
        plt.figure(figsize=(8,5))
        plt.scatter([r["R_shatter_km"] for r in add], [r["E_per_piece_MeV"] for r in add], c=[r["coincidence_score_noncausal_out_of_5"] for r in add], s=8, alpha=0.55)
        plt.xscale("log"); plt.yscale("log")
        plt.axvline(45.6, linestyle="--", linewidth=1)
        plt.axhline(62.4, linestyle="--", linewidth=1)
        plt.xlabel("R_shatter km"); plt.ylabel("E per piece MeV")
        plt.title("Gate 12A: radius vs piece energy")
        plt.tight_layout(); plt.savefig(p, dpi=160); plt.close()
        plot_paths.append(str(p))

        p = OUT / "gate12A_time_vs_temperature.png"
        plt.figure(figsize=(8,5))
        plt.scatter([r["t_shatter_s"] for r in add], [r["kT_TeV"] for r in add], c=[r["coincidence_score_noncausal_out_of_5"] for r in add], s=8, alpha=0.55)
        plt.xscale("log"); plt.yscale("log")
        plt.axvline(6.63e-23, linestyle="--", linewidth=1)
        plt.axhline(20.7, linestyle="--", linewidth=1)
        plt.xlabel("t_shatter s"); plt.ylabel("kT TeV")
        plt.title("Gate 12A: time vs temperature")
        plt.tight_layout(); plt.savefig(p, dpi=160); plt.close()
        plot_paths.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plot_paths


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    main_rows = make_main_rows()
    sweep_rows = make_sweep_rows()
    summary = summarize_sweep(sweep_rows)
    inv = inverse_rows()

    paths = {
        "main": str(OUT / "gate12A_main_convention_audit.csv"),
        "sweep": str(OUT / "gate12A_robustness_sweep.csv"),
        "summary": str(OUT / "gate12A_sweep_summary.csv"),
        "inverse": str(OUT / "gate12A_inverse_relations.csv"),
        "verdict": str(OUT / "gate12A_verdict.csv"),
        "report": str(OUT / "gate12A_unified_shatter_seed_audit_report.txt"),
    }
    write_csv(Path(paths["main"]), main_rows)
    write_csv(Path(paths["sweep"]), sweep_rows)
    write_csv(Path(paths["summary"]), summary)
    write_csv(Path(paths["inverse"]), inv)

    add = next(r for r in main_rows if r["case_label"] == "addendum_nominal_E1e69_N1e80" and r["convention"] == "mixed_addendum_like_cycles_time_a_phi_area")
    cyc = next(r for r in main_rows if r["case_label"] == "addendum_nominal_E1e69_N1e80" and r["convention"] == "cycle_consistent_cycles_time_A0_area")
    rad = next(r for r in main_rows if r["case_label"] == "addendum_nominal_E1e69_N1e80" and r["convention"] == "radian_consistent_radian_time_a_phi_area")

    verdict = [{
        "verdict": "PROMISING_SEED_WITH_CONVENTION_AND_CAUSALITY_GATES",
        "nominal_R_km_addendum_like": add["R_shatter_km"],
        "nominal_t_s_addendum_like": add["t_shatter_s"],
        "nominal_kT_TeV_addendum_like": add["kT_TeV"],
        "nominal_E_piece_MeV_addendum_like": add["E_per_piece_MeV"],
        "nominal_R_over_Rs_addendum_like": add["R_over_Rs"],
        "nominal_ct_over_R_addendum_like": add["ct_shatter_over_R"],
        "cycle_consistent_R_km": cyc["R_shatter_km"],
        "radian_consistent_t_s": rad["t_shatter_s"],
        "radius_factor_cycle_consistent_over_addendum_like": cyc["R_shatter_km"] / add["R_shatter_km"],
        "time_factor_radian_consistent_over_addendum_like": rad["t_shatter_s"] / add["t_shatter_s"],
        "key_boundary": "The 45 km / 20 TeV / 62 MeV / 6.6e-23 s pattern exists for the mixed addendum-like convention and nominal E,N, but 2pi convention and ordinary-causal-coherence gates must be resolved.",
    }]
    write_csv(Path(paths["verdict"]), verdict)
    save_report(main_rows, summary, inv, paths)
    plot_paths = make_plots(sweep_rows)

    print("\nSFT V12 GATE 12A RESULTS")
    print("========================")
    print("\nNominal addendum-like branch:")
    for k in ["R_shatter_km", "t_shatter_s", "boundary_growth_rate_m2_s", "T_shatter_K", "kT_TeV", "E_per_piece_MeV", "R_schwarzschild_m", "R_over_Rs", "light_crossing_s", "ct_shatter_over_R", "R_over_ct_shatter", "E_required_light_crossing_ratio_to_E"]:
        print(f"  {k}: {add[k]:.12e}")

    print("\nNominal convention comparison:")
    for row in [r for r in main_rows if r["case_label"] == "addendum_nominal_E1e69_N1e80"]:
        print(f"\n  {row['convention']}")
        for k in ["R_shatter_km", "t_shatter_s", "kT_TeV", "E_per_piece_MeV", "R_over_Rs", "ct_shatter_over_R"]:
            print(f"    {k}: {row[k]:.12e}")

    print("\nSweep summary:")
    for row in summary:
        print(f"\n  {row['convention']}")
        for k in ["best_coincidence_score_noncausal_out_of_5", "num_rows_all_5_noncausal_gold_flags", "num_rows_all_5_plus_ct_over_R_ge_1", "best_nominal_log10_E", "best_nominal_log10_N", "best_nominal_R_km", "best_nominal_kT_TeV", "best_nominal_E_piece_MeV", "best_nominal_t_s", "best_nominal_ct_over_R"]:
            print(f"    {k}: {row[k]}")

    print("\nGate 12A verdict:")
    print("  PROMISING_SEED_WITH_CONVENTION_AND_CAUSALITY_GATES")
    print("  The nominal toy reproduces the striking scale cluster, but the 2pi convention and")
    print("  ordinary-spatial causal-coherence gate must be resolved before this becomes a claim.")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    for label, p in paths.items():
        print(f"  {label}: {p}")
    for p in plot_paths:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
