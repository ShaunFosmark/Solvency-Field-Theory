#!/usr/bin/env python3
"""
SFT V12 Gate 12C: Post-Shatter Spatialization Map

Purpose
-------
Gate 12A established that the unified-shatter seed robustly gives a striking
scale cluster:

    R_area ~ 45.6 km
    t_shatter ~ 6.6e-23 s
    kT ~ 20 TeV
    E/N ~ 62 MeV

Gate 12B established that R_area cannot be an ordinary pre-shatter spatial
radius. It must be interpreted as a boundary-equivalent write-area radius.

Gate 12C asks the next question:

    How can N boundary entries become spatially distributed local sites
    without treating the process as ordinary particle transport faster than c?

This is a mapping/consistency audit, not a derivation.

Core distinction
----------------
Pre-shatter:
    one unified process, N accumulated boundary entries, no ordinary N-site
    spatial distribution yet.

At/after shatter:
    N entries become independent local ticker demands. Ordinary spatial
    separation appears as part of the spatialization/metric-distribution event.

Branches tested
---------------
1. boundary_capacity_only
   Boundary entries are ledger capacity. No N ordinary sites exist before shatter.

2. ordinary_transport
   N sites are moved/distributed through already-existing space.
   This requires v <= c and generally fails.

3. metric_spatialization
   Spatial distance is created/assigned by the shatter map. Not ordinary motion.
   This branch survives only with explicit pre-geometric wording.

4. packing_diagnostics
   Computes the radius required for N sites to have a chosen mean 3D spacing,
   and separately for N sites on a 2D shell with a chosen surface spacing.

Claim boundary
--------------
This script does NOT:
    - derive a_phi;
    - derive N;
    - derive the shatter mechanism;
    - prove inflation is unnecessary;
    - derive perturbation spectra.

It DOES:
    - quantify what post-shatter radii correspond to Planck/QCD/proton/electron
      spacing assumptions;
    - show which interpretations require superluminal ordinary transport;
    - state the surviving SFT wording boundary.
"""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


# -----------------------------
# Constants
# -----------------------------

C = 299_792_458.0
H = 6.626_070_15e-34
HBAR = H / (2.0 * math.pi)
G_MARKER = 6.674_30e-11
KB = 1.380_649e-23
SIGMA_SB = 5.670_374_419e-8
EV_J = 1.602_176_634e-19
MEV_J = 1.0e6 * EV_J
GEV_J = 1.0e9 * EV_J
TEV_J = 1.0e12 * EV_J
AU_M = 1.495_978_707e11
LY_M = 9.460_730_472_5808e15
MPC_M = 3.085_677_581_491_3673e22

A_PHI_REF = HBAR * G_MARKER / C**3
A0_REF = H * G_MARKER / C**3
L_ROOT = math.sqrt(A_PHI_REF)
T_ROOT = L_ROOT / C


@dataclass
class Config:
    E_total_J: float = 1.0e69
    N_count: float = 1.0e80

    # Use addendum-like branch by default: cycles for time, a_phi for area count.
    rate_convention: str = "cycles"
    area_convention: str = "a_phi"

    # Time windows for ordinary-transport speed diagnostics.
    time_windows_s: tuple[tuple[str, float], ...] = (
        ("shatter_time", 6.62607015e-23),
        ("strong_1e_minus23_s", 1.0e-23),
        ("electroweak_1e_minus12_s", 1.0e-12),
        ("one_second", 1.0),
        ("one_year", 365.25 * 24 * 3600),
    )

    out_dir: str = "SFT_V12_GATE_12C_OUTPUT"


# -----------------------------
# Helpers
# -----------------------------

def sphere_area(R: float) -> float:
    return 4.0 * math.pi * R**2


def sphere_volume(R: float) -> float:
    return (4.0 / 3.0) * math.pi * R**3


def radius_from_area(A: float) -> float:
    return math.sqrt(A / (4.0 * math.pi))


def radius_for_volume_spacing(N: float, spacing_m: float) -> float:
    """Radius of sphere whose mean cell spacing is spacing_m."""
    return ((3.0 * N * spacing_m**3) / (4.0 * math.pi)) ** (1.0 / 3.0)


def radius_for_surface_spacing(N: float, spacing_m: float) -> float:
    """Radius of shell whose area per site is spacing_m^2."""
    return math.sqrt(N * spacing_m**2 / (4.0 * math.pi))


def mean_volume_spacing(N: float, R: float) -> float:
    return (sphere_volume(R) / N) ** (1.0 / 3.0)


def mean_surface_spacing(N: float, R: float) -> float:
    return math.sqrt(sphere_area(R) / N)


def radiation_temperature(E: float, R: float) -> float:
    a_rad = 4.0 * SIGMA_SB / C
    u = E / sphere_volume(R)
    return (u / a_rad) ** 0.25


def kT_TeV(T: float) -> float:
    return KB * T / TEV_J


def schwarzschild_radius(E: float) -> float:
    return 2.0 * G_MARKER * E / C**4


def rate(E: float, convention: str) -> float:
    if convention == "cycles":
        return E / H
    if convention == "radians":
        return E / HBAR
    raise ValueError(convention)


def area_unit(convention: str) -> float:
    if convention == "a_phi":
        return A_PHI_REF
    if convention == "A0":
        return A0_REF
    raise ValueError(convention)


def length_label_rows() -> list[dict]:
    """Reference length scales for packing diagnostics."""
    # Approximate physical markers; these are comparison scales only.
    proton_charge_radius = 0.8409e-15
    one_fm = 1.0e-15
    qcd_200_mev_compton = HBAR * C / (200.0 * MEV_J)
    shatter_piece_62mev_compton = HBAR * C / (62.4150907446 * MEV_J)
    electron_compton_reduced = 3.8615926796e-13
    classical_electron_radius = 2.8179403262e-15

    return [
        {"scale_name": "root_length_sqrt_a_phi", "spacing_m": L_ROOT, "note": "sqrt(a_phi); Planck/root length marker"},
        {"scale_name": "causal_core_radius_ct", "spacing_m": C * 6.62607015e-23, "note": "c times nominal shatter time"},
        {"scale_name": "one_fermi", "spacing_m": one_fm, "note": "nuclear/QCD order spacing"},
        {"scale_name": "proton_charge_radius", "spacing_m": proton_charge_radius, "note": "proton charge-radius marker"},
        {"scale_name": "classical_electron_radius", "spacing_m": classical_electron_radius, "note": "classical electron radius marker"},
        {"scale_name": "QCD_200MeV_reduced_Compton", "spacing_m": qcd_200_mev_compton, "note": "hbar c / 200 MeV"},
        {"scale_name": "piece_62MeV_reduced_Compton", "spacing_m": shatter_piece_62mev_compton, "note": "hbar c / 62.4 MeV"},
        {"scale_name": "electron_reduced_Compton", "spacing_m": electron_compton_reduced, "note": "electron reduced Compton wavelength"},
    ]


def compute_seed(cfg: Config) -> dict:
    r = rate(cfg.E_total_J, cfg.rate_convention)
    au = area_unit(cfg.area_convention)
    t = cfg.N_count / r
    A = cfg.N_count * au
    R_area = radius_from_area(A)
    R_causal = C * t
    T = radiation_temperature(cfg.E_total_J, R_area)
    Rs = schwarzschild_radius(cfg.E_total_J)

    return {
        "E_total_J": cfg.E_total_J,
        "N_count": cfg.N_count,
        "rate_convention": cfg.rate_convention,
        "area_convention": cfg.area_convention,
        "area_unit_m2": au,
        "tick_rate_per_s": r,
        "t_shatter_s": t,
        "R_area_m": R_area,
        "R_area_km": R_area / 1e3,
        "A_boundary_m2": A,
        "R_causal_m": R_causal,
        "R_causal_fm": R_causal / 1e-15,
        "ct_over_R_area": R_causal / R_area,
        "R_area_over_ct": R_area / R_causal,
        "mean_3D_spacing_if_sites_fill_R_area_m": mean_volume_spacing(cfg.N_count, R_area),
        "mean_3D_spacing_if_sites_fill_R_area_fm": mean_volume_spacing(cfg.N_count, R_area) / 1e-15,
        "mean_surface_spacing_on_R_area_m": mean_surface_spacing(cfg.N_count, R_area),
        "mean_surface_spacing_on_R_area_over_lroot": mean_surface_spacing(cfg.N_count, R_area) / L_ROOT,
        "T_if_R_area_volume_K": T,
        "kT_if_R_area_volume_TeV": kT_TeV(T),
        "R_schwarzschild_m": Rs,
        "R_area_over_Rs": R_area / Rs,
    }


def packing_rows(cfg: Config, seed: dict) -> list[dict]:
    rows = []
    for scale in length_label_rows():
        s = scale["spacing_m"]
        R_vol = radius_for_volume_spacing(cfg.N_count, s)
        R_shell = radius_for_surface_spacing(cfg.N_count, s)
        T_vol = radiation_temperature(cfg.E_total_J, R_vol)
        T_shell_as_volume = radiation_temperature(cfg.E_total_J, R_shell)

        rows.append({
            "scale_name": scale["scale_name"],
            "spacing_m": s,
            "spacing_fm": s / 1e-15,
            "note": scale["note"],
            "R_required_3D_volume_m": R_vol,
            "R_required_3D_volume_km": R_vol / 1e3,
            "R_required_3D_volume_AU": R_vol / AU_M,
            "R_required_3D_volume_ly": R_vol / LY_M,
            "factor_vs_R_area_3D": R_vol / seed["R_area_m"],
            "T_if_volume_radius_K": T_vol,
            "kT_if_volume_radius_TeV": kT_TeV(T_vol),
            "R_required_2D_shell_m": R_shell,
            "R_required_2D_shell_km": R_shell / 1e3,
            "R_required_2D_shell_ly": R_shell / LY_M,
            "R_required_2D_shell_Mpc": R_shell / MPC_M,
            "factor_vs_R_area_2D": R_shell / seed["R_area_m"],
            "T_if_shell_radius_treated_as_volume_K": T_shell_as_volume,
            "kT_if_shell_radius_treated_as_volume_TeV": kT_TeV(T_shell_as_volume),
        })
    return rows


def transport_rows(cfg: Config, seed: dict, pack_rows: list[dict]) -> list[dict]:
    rows = []
    target_radii = [
        ("boundary_equivalent_R_area", seed["R_area_m"]),
        ("causal_core_ct", seed["R_causal_m"]),
    ]
    for p in pack_rows:
        target_radii.append((f"3D_spacing_{p['scale_name']}", p["R_required_3D_volume_m"]))
        target_radii.append((f"2D_shell_spacing_{p['scale_name']}", p["R_required_2D_shell_m"]))

    seen = set()
    unique_targets = []
    for name, R in target_radii:
        key = (name, round(math.log10(R), 12) if R > 0 else 0)
        if key not in seen:
            seen.add(key)
            unique_targets.append((name, R))

    for name, R_target in unique_targets:
        delta_R = abs(R_target - seed["R_causal_m"])
        for time_name, dt in cfg.time_windows_s:
            v_over_c = delta_R / (C * dt)
            rows.append({
                "target_name": name,
                "R_target_m": R_target,
                "R_target_km": R_target / 1e3,
                "time_window_name": time_name,
                "time_window_s": dt,
                "ordinary_transport_v_over_c": v_over_c,
                "ordinary_transport_pass": v_over_c <= 1.0,
                "interpretation": (
                    "ordinary transport allowed within this time window"
                    if v_over_c <= 1.0
                    else "ordinary transport would be superluminal; requires metric spatialization or longer time"
                ),
            })
    return rows


def branch_rows(seed: dict) -> list[dict]:
    return [
        {
            "branch": "boundary_capacity_only",
            "status": "PASS_AS_PRE_SHATTER_WORDING",
            "condition": "N entries are ledger capacity, not N ordinary spatial sites",
            "metric": "mean_surface_spacing_on_R_area_over_lroot",
            "value": seed["mean_surface_spacing_on_R_area_over_lroot"],
            "interpretation": "The boundary area count is exactly a capacity ledger when surface spacing is root-scale.",
        },
        {
            "branch": "ordinary_transport",
            "status": "FAIL_FOR_SHATTER_TIME",
            "condition": "ordinary sites must be physically transported across pre-existing space with v <= c",
            "metric": "ct_over_R_area",
            "value": seed["ct_over_R_area"],
            "interpretation": "The shatter-time causal radius is femtometer-scale, not 45 km.",
        },
        {
            "branch": "metric_spatialization",
            "status": "CONCEPTUAL_PASS_REQUIRES_MECHANISM",
            "condition": "distance is assigned/created by the shatter map rather than traversed by particles",
            "metric": "R_area_over_ct",
            "value": seed["R_area_over_ct"],
            "interpretation": "Survives only if the theory explicitly treats post-shatter separation as emergent geometry.",
        },
        {
            "branch": "packing_diagnostics",
            "status": "OPEN_GATE",
            "condition": "choose a physical post-shatter spacing scale and derive why that scale is selected",
            "metric": "mean_3D_spacing_if_sites_fill_R_area_fm",
            "value": seed["mean_3D_spacing_if_sites_fill_R_area_fm"],
            "interpretation": "If sites fill a 45.6 km volume, mean 3D spacing is far below nuclear scale but far above root length.",
        },
    ]


def inverse_rows(cfg: Config, seed: dict) -> list[dict]:
    rows = []

    # How many entries can fit at selected spacing inside/shell at R_area?
    for scale in length_label_rows():
        s = scale["spacing_m"]
        N_vol_at_R_area = sphere_volume(seed["R_area_m"]) / s**3
        N_shell_at_R_area = sphere_area(seed["R_area_m"]) / s**2
        rows.append({
            "scale_name": scale["scale_name"],
            "spacing_m": s,
            "N_capacity_3D_at_R_area": N_vol_at_R_area,
            "N_capacity_3D_at_R_area_over_N": N_vol_at_R_area / cfg.N_count,
            "N_capacity_2D_shell_at_R_area": N_shell_at_R_area,
            "N_capacity_2D_shell_at_R_area_over_N": N_shell_at_R_area / cfg.N_count,
            "interpretation": "Capacity comparison for chosen spacing at the boundary-equivalent radius.",
        })

    # Radius needed for exactly N entries at the R_area volume spacing (sanity identity)
    s3 = seed["mean_3D_spacing_if_sites_fill_R_area_m"]
    rows.append({
        "scale_name": "identity_mean_3D_spacing_at_R_area",
        "spacing_m": s3,
        "N_capacity_3D_at_R_area": sphere_volume(seed["R_area_m"]) / s3**3,
        "N_capacity_3D_at_R_area_over_N": sphere_volume(seed["R_area_m"]) / s3**3 / cfg.N_count,
        "N_capacity_2D_shell_at_R_area": sphere_area(seed["R_area_m"]) / s3**2,
        "N_capacity_2D_shell_at_R_area_over_N": sphere_area(seed["R_area_m"]) / s3**2 / cfg.N_count,
        "interpretation": "By construction, the 3D capacity equals N for this spacing.",
    })

    return rows


def verdict(seed: dict, pack: list[dict], transport: list[dict]) -> dict:
    # Does ordinary transport to R_area pass in shatter time?
    Rarea_transport = [
        r for r in transport
        if r["target_name"] == "boundary_equivalent_R_area"
        and r["time_window_name"] == "shatter_time"
    ][0]

    # Identify QCD/proton-like 3D radius rows.
    one_fm = [r for r in pack if r["scale_name"] == "one_fermi"][0]
    root = [r for r in pack if r["scale_name"] == "root_length_sqrt_a_phi"][0]

    if not Rarea_transport["ordinary_transport_pass"]:
        v = "POST_SHATTER_SPATIALIZATION_REQUIRES_METRIC_EMERGENCE_NOT_PARTICLE_TRANSPORT"
    else:
        v = "ORDINARY_TRANSPORT_NOT_EXCLUDED"

    return {
        "verdict": v,
        "ordinary_transport_to_R_area_in_shatter_time": Rarea_transport["ordinary_transport_pass"],
        "v_over_c_to_R_area_in_shatter_time": Rarea_transport["ordinary_transport_v_over_c"],
        "R_area_km": seed["R_area_km"],
        "R_causal_fm": seed["R_causal_fm"],
        "mean_3D_spacing_at_R_area_fm": seed["mean_3D_spacing_if_sites_fill_R_area_fm"],
        "mean_surface_spacing_at_R_area_over_lroot": seed["mean_surface_spacing_on_R_area_over_lroot"],
        "R_for_N_sites_3D_one_fm_AU": one_fm["R_required_3D_volume_AU"],
        "R_for_N_sites_2D_one_fm_Mpc": one_fm["R_required_2D_shell_Mpc"],
        "R_for_N_sites_3D_root_length_km": root["R_required_3D_volume_km"],
        "R_for_N_sites_2D_root_length_km": root["R_required_2D_shell_km"],
        "key_sentence": (
            "Boundary entries may be accumulated pre-shatter as ledger capacity, but their conversion "
            "into separated local tickers cannot be modeled as ordinary motion through pre-existing space; "
            "it must be a metric/spatialization map."
        ),
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_outputs(cfg: Config, seed: dict, branches: list[dict], pack: list[dict], transport: list[dict], inv: list[dict], ver: dict) -> dict:
    out = Path(cfg.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    seed_csv = out / "gate12C_seed_spatialization_audit.csv"
    branches_csv = out / "gate12C_branch_verdicts.csv"
    packing_csv = out / "gate12C_packing_diagnostics.csv"
    transport_csv = out / "gate12C_transport_diagnostics.csv"
    inverse_csv = out / "gate12C_inverse_capacity.csv"
    verdict_csv = out / "gate12C_verdict.csv"
    report = out / "gate12C_post_shatter_spatialization_report.txt"

    write_csv(seed_csv, [seed])
    write_csv(branches_csv, branches)
    write_csv(packing_csv, pack)
    write_csv(transport_csv, transport)
    write_csv(inverse_csv, inv)
    write_csv(verdict_csv, [ver])

    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12C: Post-Shatter Spatialization Map\n")
        f.write("=================================================\n\n")
        f.write("Purpose:\n")
        f.write("  Audit how N boundary entries could become post-shatter spatial sites without\n")
        f.write("  treating the shatter as superluminal ordinary transport.\n\n")

        f.write("Seed:\n")
        for k, val in seed.items():
            if isinstance(val, float):
                f.write(f"  {k}: {val:.12e}\n")
            else:
                f.write(f"  {k}: {val}\n")

        f.write("\nBranch verdicts:\n")
        for row in branches:
            f.write(f"  {row}\n")

        f.write("\nPacking diagnostics:\n")
        for row in pack:
            f.write(f"  {row}\n")

        f.write("\nTransport diagnostics, selected shatter-time rows:\n")
        for row in transport:
            if row["time_window_name"] == "shatter_time":
                f.write(f"  {row}\n")

        f.write("\nVerdict:\n")
        for k, val in ver.items():
            if isinstance(val, float):
                f.write(f"  {k}: {val:.12e}\n")
            else:
                f.write(f"  {k}: {val}\n")

    plot_paths = []
    try:
        import matplotlib.pyplot as plt

        names = [r["scale_name"] for r in pack]
        R3 = [r["R_required_3D_volume_m"] for r in pack]
        R2 = [r["R_required_2D_shell_m"] for r in pack]
        x = np.arange(len(names))

        plt.figure(figsize=(10, 5))
        plt.scatter(x, R3, label="3D volume radius")
        plt.scatter(x, R2, label="2D shell radius")
        plt.axhline(seed["R_area_m"], linestyle="--", linewidth=1, label="R_area")
        plt.yscale("log")
        plt.xticks(x, names, rotation=45, ha="right")
        plt.ylabel("required radius (m)")
        plt.title("Gate 12C: radius required for N sites at chosen spacing")
        plt.legend()
        plt.tight_layout()
        p = out / "gate12C_required_radius_by_spacing.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        # Transport v/c for shatter-time targets.
        shatter_rows = [r for r in transport if r["time_window_name"] == "shatter_time"]
        names2 = [r["target_name"] for r in shatter_rows]
        vals = [r["ordinary_transport_v_over_c"] for r in shatter_rows]
        x2 = np.arange(len(names2))
        plt.figure(figsize=(11, 5))
        plt.scatter(x2, vals)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.yscale("log")
        plt.xticks(x2, names2, rotation=60, ha="right")
        plt.ylabel("ordinary transport v/c over shatter time")
        plt.title("Gate 12C: ordinary transport test")
        plt.tight_layout()
        p = out / "gate12C_transport_v_over_c.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")

    return {
        "out_dir": str(out),
        "report": str(report),
        "seed_csv": str(seed_csv),
        "branches_csv": str(branches_csv),
        "packing_csv": str(packing_csv),
        "transport_csv": str(transport_csv),
        "inverse_csv": str(inverse_csv),
        "verdict_csv": str(verdict_csv),
        "plot_paths": plot_paths,
    }


def print_float(label: str, val) -> None:
    if isinstance(val, float):
        print(f"  {label}: {val:.12e}")
    else:
        print(f"  {label}: {val}")


def main() -> None:
    cfg = Config()
    seed = compute_seed(cfg)
    branches = branch_rows(seed)
    pack = packing_rows(cfg, seed)
    transport = transport_rows(cfg, seed, pack)
    inv = inverse_rows(cfg, seed)
    ver = verdict(seed, pack, transport)
    paths = save_outputs(cfg, seed, branches, pack, transport, inv, ver)

    print("\nSFT V12 GATE 12C RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Post-shatter spatialization map: boundary entries to local sites.")
    print("  No derivation of a_phi, N, or shatter mechanism is claimed.")

    print("\nSeed spatialization audit:")
    for k in [
        "R_area_km",
        "t_shatter_s",
        "R_causal_fm",
        "ct_over_R_area",
        "R_area_over_ct",
        "mean_3D_spacing_if_sites_fill_R_area_fm",
        "mean_surface_spacing_on_R_area_over_lroot",
        "kT_if_R_area_volume_TeV",
        "R_area_over_Rs",
    ]:
        print_float(k, seed[k])

    print("\nBranch verdicts:")
    for row in branches:
        print(f"\n  {row['branch']}")
        print(f"    status: {row['status']}")
        print(f"    condition: {row['condition']}")
        print(f"    metric: {row['metric']}")
        print(f"    value: {row['value']:.12e}")
        print(f"    interpretation: {row['interpretation']}")

    print("\nPacking diagnostics:")
    for row in pack:
        print(f"\n  {row['scale_name']}")
        print(f"    spacing_fm: {row['spacing_fm']:.12e}")
        print(f"    R_required_3D_volume_km: {row['R_required_3D_volume_km']:.12e}")
        print(f"    R_required_3D_volume_AU: {row['R_required_3D_volume_AU']:.12e}")
        print(f"    factor_vs_R_area_3D: {row['factor_vs_R_area_3D']:.12e}")
        print(f"    R_required_2D_shell_km: {row['R_required_2D_shell_km']:.12e}")
        print(f"    R_required_2D_shell_Mpc: {row['R_required_2D_shell_Mpc']:.12e}")
        print(f"    factor_vs_R_area_2D: {row['factor_vs_R_area_2D']:.12e}")
        print(f"    kT_if_volume_radius_TeV: {row['kT_if_volume_radius_TeV']:.12e}")

    print("\nOrdinary transport diagnostics, shatter-time only:")
    for row in transport:
        if row["time_window_name"] == "shatter_time":
            print(f"\n  {row['target_name']}")
            print(f"    R_target_km: {row['R_target_km']:.12e}")
            print(f"    ordinary_transport_v_over_c: {row['ordinary_transport_v_over_c']:.12e}")
            print(f"    ordinary_transport_pass: {row['ordinary_transport_pass']}")
            print(f"    interpretation: {row['interpretation']}")

    print("\nInverse capacity checks:")
    for row in inv:
        print(f"\n  {row['scale_name']}")
        print(f"    spacing_fm: {row['spacing_m']/1e-15:.12e}")
        print(f"    N_capacity_3D_at_R_area_over_N: {row['N_capacity_3D_at_R_area_over_N']:.12e}")
        print(f"    N_capacity_2D_shell_at_R_area_over_N: {row['N_capacity_2D_shell_at_R_area_over_N']:.12e}")
        print(f"    interpretation: {row['interpretation']}")

    print("\nGate 12C verdict:")
    print(f"  {ver['verdict']}")
    print(f"  v_over_c_to_R_area_in_shatter_time: {ver['v_over_c_to_R_area_in_shatter_time']:.12e}")
    print(f"  R_for_N_sites_3D_one_fm_AU: {ver['R_for_N_sites_3D_one_fm_AU']:.12e}")
    print(f"  R_for_N_sites_2D_one_fm_Mpc: {ver['R_for_N_sites_2D_one_fm_Mpc']:.12e}")
    print(f"  key_sentence: {ver['key_sentence']}")

    print("\nFiles:")
    print(f"  output directory: {paths['out_dir']}")
    print(f"  report: {paths['report']}")
    print(f"  seed audit csv: {paths['seed_csv']}")
    print(f"  branch verdicts csv: {paths['branches_csv']}")
    print(f"  packing diagnostics csv: {paths['packing_csv']}")
    print(f"  transport diagnostics csv: {paths['transport_csv']}")
    print(f"  inverse capacity csv: {paths['inverse_csv']}")
    print(f"  verdict csv: {paths['verdict_csv']}")
    for p in paths["plot_paths"]:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
