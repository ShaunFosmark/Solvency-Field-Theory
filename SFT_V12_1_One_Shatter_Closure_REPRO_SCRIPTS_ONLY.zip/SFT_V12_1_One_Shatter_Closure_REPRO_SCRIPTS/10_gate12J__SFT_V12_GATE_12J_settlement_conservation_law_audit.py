#!/usr/bin/env python3
"""
SFT V12 Gate 12J: Settlement Conservation Law Audit

Mobile-ready: embeds Gate 12I values directly.
No previous output folder is required.

Purpose
-------
Gate 12I established the formal two-scale contract:

    a_T(T) = T_post / T
    a_L(T) = a_T(T) Q(T)

where a_T controls local thermal clocks and photon temperature, while a_L
controls effective settlement / spatial ledger geometry.

Gate 12J asks whether Q(T) can be read as a settlement-density relaxation rather
than extra energy expansion.

Core idea
---------
If Q is non-thermal, then it should not dilute photon temperature as a_L^-1.
Instead:

    thermal radiation density follows a_T^-4
    thermal number density follows a_T^-3
    ledger/settlement spatial density follows a_L^-3 = (a_T Q)^-3

Thus Q changes effective settlement volume, area, and site density:

    linear stretch ratio: Q
    area stretch ratio:   Q^2
    volume stretch ratio: Q^3
    settlement density dilution relative to thermal comoving density: Q^-3

while NOT changing local photon temperature by an extra Q.

Claim boundary
--------------
This script does NOT:
    - derive Q(T);
    - prove energy conservation from first principles;
    - derive perturbations, flatness, BBN, or CMB compatibility;
    - replace a Boltzmann code.

It DOES:
    - test the bookkeeping difference between settlement redistribution and
      ordinary thermal expansion;
    - compute Q, Q^2, Q^3, Q^4 penalties at thermal markers;
    - formalize a conservation contract for fixed ledger count / boundary service;
    - identify the remaining mechanism debt.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
import numpy as np


SEED = {
    "candidate_name": "thermal_Compton_fixed_kT_equals_hbarc_over_s",
    "spacing_fm": 2.080201237123,
    "R_post_AU": 4.003904729680,
    "kT_post_MeV": 94.85956307390,
    "kT_rec_eV": 2.562193818698e-1,
    "thermal_growth_to_rec": 3.702278975995e8,
    "thermal_efolds_to_rec": 19.72962931345,
    "q_rec": 25.98352226410,
    "q_rec_efolds": 3.257462578037,
    "alpha_power_law": 0.1651051079717,
    "R_thermal_rec_Mly": 0.02343978468746,
    "R_ledger_rec_Mly": 0.6090481672918,
    "local_target_max_factor_error": 1.410461571124,
    "actual_rate_H_eff_over_Hthermal": 1.165105107972,
    "actual_rate_delta_Neff_proxy": 2.662151599967,
}

LOCAL_TARGETS_MLY = {
    "sound_horizon": 0.4318077002313,
    "hubble_radius": 0.6246982112007,
    "particle_horizon": 0.8375182455706,
}

AU_M = 1.495978707e11
LY_M = 9.4607304725808e15
MLY_M = 1.0e6 * LY_M
OUT_DIR = Path("SFT_V12_GATE_12J_OUTPUT")


def Q_power(kT_MeV: float) -> float:
    a_T = SEED["kT_post_MeV"] / kT_MeV
    return a_T ** SEED["alpha_power_law"]


def thermal_markers() -> list[dict]:
    rec_MeV = SEED["kT_rec_eV"] * 1e-6
    raw = [
        ("post_shatter", SEED["kT_post_MeV"], "post-shatter spatialization marker"),
        ("QCD_50MeV", 50.0, "hadronic comparison marker"),
        ("10MeV", 10.0, "early radiation-era marker"),
        ("1MeV_BBNish", 1.0, "BBN-ish marker, not a BBN calculation"),
        ("0p1MeV_BBNish", 0.1, "BBN-ish marker, not a BBN calculation"),
        ("1keV", 1e-3, "keV-era marker"),
        ("1eV", 1e-6, "eV-era marker"),
        ("recombination", rec_MeV, "recombination marker"),
    ]
    rows = []
    for name, mev, note in raw:
        if mev <= SEED["kT_post_MeV"] * (1.0 + 1e-12) and mev >= rec_MeV * (1.0 - 1e-12):
            rows.append({"marker_name": name, "kT_MeV": mev, "kT_eV": mev * 1e6, "note": note})
    return rows


def marker_ledger_rows() -> list[dict]:
    rows = []
    for m in thermal_markers():
        kT = m["kT_MeV"]
        a_T = SEED["kT_post_MeV"] / kT
        Q = Q_power(kT)
        a_L = a_T * Q
        rho_rad_T = a_T ** -4
        n_T = a_T ** -3
        rho_settle = a_L ** -3
        rho_rad_if_aL_thermal = a_L ** -4
        rows.append({
            "marker_name": m["marker_name"],
            "kT_MeV": kT,
            "a_T_thermal_scale": a_T,
            "Q_ledger_over_thermal": Q,
            "a_L_ledger_scale": a_L,
            "Q2_area_ratio_ledger_over_thermal": Q**2,
            "Q3_volume_ratio_ledger_over_thermal": Q**3,
            "Q4_radiation_penalty_if_thermal": Q**4,
            "rho_rad_T_norm_aT_minus4": rho_rad_T,
            "n_thermal_norm_aT_minus3": n_T,
            "rho_settlement_norm_aL_minus3": rho_settle,
            "settlement_density_over_thermal_number_density_Qminus3": Q**-3,
            "rho_rad_if_aL_were_thermal_norm": rho_rad_if_aL_thermal,
            "rho_rad_if_aL_thermal_over_correct_thermal_Qminus4": Q**-4,
            "temperature_restore_factor_if_aL_thermal": Q,
            "radiation_restore_factor_if_aL_thermal": Q**4,
            "settlement_interpretation": "Q redistributes settlement density over larger effective geometry; it is not photon cooling",
            "note": m["note"],
        })
    return rows


def target_comparison_rows() -> list[dict]:
    rows = []
    R_T = SEED["R_thermal_rec_Mly"]
    R_L = SEED["R_ledger_rec_Mly"]
    for name, target in LOCAL_TARGETS_MLY.items():
        rt = R_T / target
        rl = R_L / target
        rows.append({
            "target_name": name,
            "R_target_Mly": target,
            "R_thermal_rec_Mly": R_T,
            "thermal_pred_over_target": rt,
            "thermal_factor_error": max(rt, 1/rt),
            "R_ledger_rec_Mly": R_L,
            "ledger_pred_over_target": rl,
            "ledger_factor_error": max(rl, 1/rl),
        })
    return rows


def conservation_rows() -> list[dict]:
    rec = [r for r in marker_ledger_rows() if r["marker_name"] == "recombination"][0]
    return [
        {"quantity": "thermal_photon_temperature", "symbol": "T", "law": "T = T_post / a_T", "depends_on_Q": False, "rec_value_or_factor": SEED["kT_rec_eV"], "status": "PRESERVED_BY_TWO_SCALE_MAP", "interpretation": "local temperature follows a_T, not a_L"},
        {"quantity": "thermal_radiation_density", "symbol": "rho_gamma", "law": "rho_gamma ∝ a_T^-4", "depends_on_Q": False, "rec_value_or_factor": rec["rho_rad_T_norm_aT_minus4"], "status": "PRESERVED_BY_TWO_SCALE_MAP", "interpretation": "radiation energy density is not diluted by extra Q"},
        {"quantity": "thermal_number_density_proxy", "symbol": "n_T", "law": "n_T ∝ a_T^-3", "depends_on_Q": False, "rec_value_or_factor": rec["n_thermal_norm_aT_minus3"], "status": "PRESERVED_BY_TWO_SCALE_MAP", "interpretation": "local thermal dilution follows a_T"},
        {"quantity": "settlement_spatial_volume", "symbol": "V_L/V_T", "law": "V_L/V_T = Q^3", "depends_on_Q": True, "rec_value_or_factor": rec["Q3_volume_ratio_ledger_over_thermal"], "status": "SETTLEMENT_REDISTRIBUTION", "interpretation": "ledger geometry has larger effective volume than thermal scale alone"},
        {"quantity": "settlement_density_proxy", "symbol": "rho_L", "law": "rho_L ∝ a_L^-3 = (a_T Q)^-3", "depends_on_Q": True, "rec_value_or_factor": rec["rho_settlement_norm_aL_minus3"], "status": "SETTLEMENT_REDISTRIBUTION", "interpretation": "fixed ledger/service count is spread across larger effective settlement geometry"},
        {"quantity": "relative_settlement_dilution", "symbol": "rho_L/n_T", "law": "rho_L/n_T = Q^-3", "depends_on_Q": True, "rec_value_or_factor": rec["settlement_density_over_thermal_number_density_Qminus3"], "status": "NONTHERMAL_DILUTION_ONLY", "interpretation": "Q changes settlement density relative to thermal density without changing photon temperature"},
        {"quantity": "forbidden_radiation_density_loss", "symbol": "rho_gamma ∝ a_L^-4", "law": "rho_gamma_wrong/rho_gamma_correct = Q^-4", "depends_on_Q": True, "rec_value_or_factor": rec["rho_rad_if_aL_thermal_over_correct_thermal_Qminus4"], "status": "FORBIDDEN_MISREAD", "interpretation": "this is the overcooling/reheating error caught by Gates 12H/12I"},
    ]


def branch_rows() -> list[dict]:
    rec = [r for r in marker_ledger_rows() if r["marker_name"] == "recombination"][0]
    target_rows = target_comparison_rows()
    max_factor = max(r["ledger_factor_error"] for r in target_rows)
    return [
        {"branch": "energy_creating_expansion", "status": "FAIL_FOR_FINAL_CLAIM", "thermal_clock_changed": True, "uses_Q_as_photon_cooling": True, "requires_reheating": True, "rec_Q": rec["Q_ledger_over_thermal"], "rec_Q4_penalty": rec["Q4_radiation_penalty_if_thermal"], "interpretation": "Treats Q as ordinary expansion; overcools photons and requires large energy/entropy bookkeeping."},
        {"branch": "settlement_density_redistribution", "status": "FORMAL_PASS_MECHANISM_OPEN", "thermal_clock_changed": False, "uses_Q_as_photon_cooling": False, "requires_reheating": False, "rec_Q": rec["Q_ledger_over_thermal"], "rec_Q3_volume_ratio": rec["Q3_volume_ratio_ledger_over_thermal"], "rec_settlement_density_ratio_Qminus3": rec["settlement_density_over_thermal_number_density_Qminus3"], "local_target_max_factor_error": max_factor, "interpretation": "Reads Q as redistribution/dilution of settlement density over effective geometry while preserving local thermal history."},
        {"branch": "ordinary_particle_transport", "status": "FAIL_BY_PRIOR_GATES", "thermal_clock_changed": False, "uses_Q_as_photon_cooling": False, "requires_reheating": False, "rec_Q": rec["Q_ledger_over_thermal"], "interpretation": "Rejected by prior causal gates: Q is not particles flying through pre-existing space."},
        {"branch": "actual_local_friedmann_rate_change", "status": "RATE_RISK_FROM_GATE_12H", "thermal_clock_changed": True, "uses_Q_as_photon_cooling": "not necessarily, but changes local H", "requires_reheating": "not the main issue", "H_eff_over_Hthermal": SEED["actual_rate_H_eff_over_Hthermal"], "delta_Neff_proxy": SEED["actual_rate_delta_Neff_proxy"], "interpretation": "Even if not photon cooling directly, putting Q into local expansion rate creates BBN/CMB rate risk."},
    ]


def conservation_contract_rows() -> list[dict]:
    return [
        {"contract_item": "fixed_local_thermal_clock", "equation": "T = T_post/a_T", "allowed": True, "meaning": "thermal cooling and reaction rates use a_T only"},
        {"contract_item": "effective_ledger_geometry", "equation": "a_L = a_T Q", "allowed": True, "meaning": "settlement geometry uses ledger scale a_L"},
        {"contract_item": "settlement_volume_relaxation", "equation": "V_L/V_T = Q^3", "allowed": True, "meaning": "Q redistributes settlement service over larger effective volume"},
        {"contract_item": "settlement_density_relaxation", "equation": "rho_L/n_T = Q^-3", "allowed": True, "meaning": "settlement density dilutes relative to thermal number density"},
        {"contract_item": "forbidden_photon_overcooling", "equation": "T = T_post/a_L", "allowed": False, "meaning": "would overcool photons by Q and require Q^4 radiation restoration"},
        {"contract_item": "forbidden_naive_rate_insertion", "equation": "H -> (1+alpha)H everywhere", "allowed": False, "meaning": "reproduces Gate 12H BBN/CMB rate risk"},
        {"contract_item": "mechanism_debt", "equation": "derive Q_mech", "allowed": "open", "meaning": "need a rule for settlement-density relaxation from SFT ledger dynamics"},
    ]


def verdict_row() -> dict:
    rec = [r for r in marker_ledger_rows() if r["marker_name"] == "recombination"][0]
    targets = target_comparison_rows()
    return {
        "verdict": "SETTLEMENT_DENSITY_RELAXATION_BOOKKEEPING_IS_CONSISTENT_MECHANISM_OPEN",
        "claim_boundary": "bookkeeping audit only; Q mechanism, BBN/CMB fit, perturbations, flatness, and inflation replacement are not derived",
        "Q_rec": rec["Q_ledger_over_thermal"],
        "Q2_area_ratio_rec": rec["Q2_area_ratio_ledger_over_thermal"],
        "Q3_volume_ratio_rec": rec["Q3_volume_ratio_ledger_over_thermal"],
        "Q4_forbidden_radiation_penalty_rec": rec["Q4_radiation_penalty_if_thermal"],
        "settlement_density_relative_to_thermal_number_density_rec": rec["settlement_density_over_thermal_number_density_Qminus3"],
        "thermal_radiation_density_law": "rho_gamma ∝ a_T^-4",
        "settlement_density_law": "rho_L ∝ a_L^-3 = (a_T Q)^-3",
        "local_target_max_factor_error_ledger": max(r["ledger_factor_error"] for r in targets),
        "local_target_max_factor_error_thermal": max(r["thermal_factor_error"] for r in targets),
        "surviving_branch": "settlement_density_redistribution",
        "mechanism_debt": "derive Q from SFT settlement density, boundary service, or no-overwrite relaxation dynamics",
        "key_sentence": "Gate 12J shows that Q can be consistently booked as settlement-density relaxation: thermal radiation remains governed by a_T^-4, while effective settlement density follows a_L^-3=(a_T Q)^-3. The extra factor Q dilutes settlement density by Q^-3 and enlarges effective ledger volume by Q^3, without overcooling photons. The forbidden reading is rho_gamma∝a_L^-4, which would reintroduce the Q^4 reheating penalty.",
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def save_plots(markers: list[dict]) -> list[str]:
    plots = []
    try:
        import matplotlib.pyplot as plt
        labels = [r["marker_name"] for r in markers]
        x = np.arange(len(labels))

        plt.figure(figsize=(10, 5))
        plt.plot(x, [r["Q_ledger_over_thermal"] for r in markers], marker="o", label="Q")
        plt.plot(x, [r["Q3_volume_ratio_ledger_over_thermal"] for r in markers], marker="s", label="Q^3 volume")
        plt.plot(x, [r["Q4_radiation_penalty_if_thermal"] for r in markers], marker="^", label="Q^4 forbidden radiation penalty")
        plt.yscale("log")
        plt.xticks(x, labels, rotation=45, ha="right")
        plt.ylabel("factor")
        plt.title("Gate 12J: Q bookkeeping factors")
        plt.legend()
        plt.tight_layout()
        p = OUT_DIR / "gate12J_Q_bookkeeping_factors.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        plt.figure(figsize=(10, 5))
        plt.plot(x, [r["rho_rad_T_norm_aT_minus4"] for r in markers], marker="o", label="thermal radiation a_T^-4")
        plt.plot(x, [r["rho_settlement_norm_aL_minus3"] for r in markers], marker="s", label="settlement density a_L^-3")
        plt.yscale("log")
        plt.xticks(x, labels, rotation=45, ha="right")
        plt.ylabel("normalized density")
        plt.title("Gate 12J: thermal density vs settlement density")
        plt.legend()
        plt.tight_layout()
        p = OUT_DIR / "gate12J_density_laws.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        targets = target_comparison_rows()
        labels2 = [r["target_name"] for r in targets]
        xpos = np.arange(len(labels2))
        width = 0.35
        plt.figure(figsize=(9, 5))
        plt.bar(xpos - width/2, [r["thermal_factor_error"] for r in targets], width, label="thermal-only")
        plt.bar(xpos + width/2, [r["ledger_factor_error"] for r in targets], width, label="settlement ledger")
        plt.yscale("log")
        plt.axhline(2.0, linestyle="--", linewidth=1)
        plt.xticks(xpos, labels2, rotation=20, ha="right")
        plt.ylabel("factor error")
        plt.title("Gate 12J: recombination target fit")
        plt.legend()
        plt.tight_layout()
        p = OUT_DIR / "gate12J_target_fit.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def print_kv(row: dict, keys=None, indent="  ") -> None:
    items = row.items() if keys is None else [(k, row[k]) for k in keys]
    for k, v in items:
        if isinstance(v, float):
            print(f"{indent}{k}: {v:.12e}")
        else:
            print(f"{indent}{k}: {v}")


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    markers = marker_ledger_rows()
    conservation = conservation_rows()
    branches = branch_rows()
    targets = target_comparison_rows()
    contract = conservation_contract_rows()
    verdict = verdict_row()
    plots = save_plots(markers)

    write_csv(OUT_DIR / "gate12J_seed.csv", [SEED])
    write_csv(OUT_DIR / "gate12J_marker_ledger_rows.csv", markers)
    write_csv(OUT_DIR / "gate12J_conservation_rows.csv", conservation)
    write_csv(OUT_DIR / "gate12J_branch_audit.csv", branches)
    write_csv(OUT_DIR / "gate12J_target_comparison.csv", targets)
    write_csv(OUT_DIR / "gate12J_conservation_contract.csv", contract)
    write_csv(OUT_DIR / "gate12J_verdict.csv", [verdict])

    report = OUT_DIR / "gate12J_settlement_conservation_law_report.txt"
    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12J: Settlement Conservation Law Audit\n")
        f.write("===================================================\n\n")
        f.write("Seed:\n")
        for k, v in SEED.items():
            f.write(f"  {k}: {v}\n")
        f.write("\nMarker ledger rows:\n")
        for row in markers:
            f.write(f"  {row}\n")
        f.write("\nConservation rows:\n")
        for row in conservation:
            f.write(f"  {row}\n")
        f.write("\nBranch audit:\n")
        for row in branches:
            f.write(f"  {row}\n")
        f.write("\nContract:\n")
        for row in contract:
            f.write(f"  {row}\n")
        f.write("\nVerdict:\n")
        for k, v in verdict.items():
            f.write(f"  {k}: {v}\n")

    print("\nSFT V12 GATE 12J RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Settlement conservation / density-relaxation bookkeeping audit.")
    print("  No Q mechanism, BBN/CMB fit, perturbations, flatness, or inflation replacement is claimed.")

    print("\nSeed:")
    print_kv(SEED, ["candidate_name", "spacing_fm", "R_post_AU", "kT_post_MeV", "q_rec", "alpha_power_law", "R_thermal_rec_Mly", "R_ledger_rec_Mly", "local_target_max_factor_error"])

    print("\nMarker ledger rows:")
    for row in markers:
        print(f"\n  {row['marker_name']}")
        print_kv(row, ["kT_MeV", "a_T_thermal_scale", "Q_ledger_over_thermal", "a_L_ledger_scale", "Q2_area_ratio_ledger_over_thermal", "Q3_volume_ratio_ledger_over_thermal", "Q4_radiation_penalty_if_thermal", "rho_rad_T_norm_aT_minus4", "n_thermal_norm_aT_minus3", "rho_settlement_norm_aL_minus3", "settlement_density_over_thermal_number_density_Qminus3"], indent="    ")

    print("\nConservation rows:")
    for row in conservation:
        print(f"\n  {row['quantity']}")
        print_kv(row, ["symbol", "law", "depends_on_Q", "rec_value_or_factor", "status", "interpretation"], indent="    ")

    print("\nBranch audit:")
    for row in branches:
        print(f"\n  {row['branch']}")
        print_kv(row, [k for k in row.keys() if k != "branch"], indent="    ")

    print("\nLocal target comparison:")
    for row in targets:
        print(f"\n  {row['target_name']}")
        print_kv(row, ["R_target_Mly", "R_thermal_rec_Mly", "thermal_factor_error", "R_ledger_rec_Mly", "ledger_factor_error"], indent="    ")

    print("\nConservation contract:")
    for row in contract:
        print(f"\n  {row['contract_item']}")
        print_kv(row, ["equation", "allowed", "meaning"], indent="    ")

    print("\nGate 12J verdict:")
    print_kv(verdict)

    print("\nFiles:")
    print(f"  output directory: {OUT_DIR}")
    print(f"  report: {report}")
    print(f"  seed csv: {OUT_DIR / 'gate12J_seed.csv'}")
    print(f"  marker ledger rows csv: {OUT_DIR / 'gate12J_marker_ledger_rows.csv'}")
    print(f"  conservation rows csv: {OUT_DIR / 'gate12J_conservation_rows.csv'}")
    print(f"  branch audit csv: {OUT_DIR / 'gate12J_branch_audit.csv'}")
    print(f"  target comparison csv: {OUT_DIR / 'gate12J_target_comparison.csv'}")
    print(f"  contract csv: {OUT_DIR / 'gate12J_conservation_contract.csv'}")
    print(f"  verdict csv: {OUT_DIR / 'gate12J_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
