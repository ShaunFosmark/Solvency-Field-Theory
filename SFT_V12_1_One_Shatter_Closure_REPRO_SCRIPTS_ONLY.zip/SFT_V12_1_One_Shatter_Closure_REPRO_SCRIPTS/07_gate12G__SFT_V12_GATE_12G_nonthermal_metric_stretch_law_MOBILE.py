#!/usr/bin/env python3
"""
SFT V12 Gate 12G MOBILE: Non-Thermal Metric Stretch Law

This mobile-ready version has the Gate 12F single-q values embedded directly,
so it does NOT require the Gate 12F output directory.

Purpose
-------
Gate 12F found that the missing recombination bridge can be represented by a
single modest local metric stretch:

    q_rec ~ 20-30
    ln(q_rec) ~ 3 extra e-folds
    alpha_extra ~ 0.15-0.20 per thermal e-fold

Gate 12G asks whether that q_rec can be written as a smooth non-thermal metric
law Q(T), without reading it as ordinary adiabatic expansion.

Model
-----
Let:

    x(T) = ln(T_post/T) / ln(T_post/T_rec)

so x=0 at post-shatter spatialization and x=1 at recombination.

Pure thermal radius:
    R_th(T) = R_post * (T_post/T)

Metric-augmented radius:
    R_eff(T) = R_th(T) * Q(T)

Boundary conditions:
    Q(T_post) = 1
    Q(T_rec)  = q_rec

Claim boundary
--------------
This script does NOT derive the metric-stretch mechanism, perturbations,
flatness, inflation, a_phi, or N. It only audits smooth law shapes.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
import numpy as np


# -----------------------------
# Embedded Gate 12F values
# -----------------------------

# Official pasted Gate 12F best single-q table.
GATE12F_SINGLE_Q = [
    {
        "candidate_name": "thermal_Compton_fixed_kT_equals_hbarc_over_s",
        "spacing_fm": 2.080201237123,
        "R_post_AU": 4.003904729680,
        "kT_post_MeV": 94.85956307390,
        "single_q_geometric_mean": 25.98352226408,
        "single_q_efolds": 3.257462578037,
        "alpha_extra_per_thermal_efold": 0.1651051079716,
        "max_factor_error_across_local_targets": 1.410461571125,
        "sound_residual_pred_over_target": 1.410461571125,
        "hubble_residual_pred_over_target": 0.9749478330046,
        "particle_residual_pred_over_target": 0.7272058495597,
        "radiation_energy_density_reheat_factor_q4": 4.558186500567e5,
    },
    {
        "candidate_name": "QCD_200MeV_reduced_Compton",
        "spacing_fm": 0.9866349022965,
        "R_post_AU": 1.899043266235,
        "kT_post_MeV": 165.9750379938,
        "single_q_geometric_mean": 31.31015672976,
        "single_q_efolds": 3.443942541067,
        "alpha_extra_per_thermal_efold": 0.1697437426374,
        "max_factor_error_across_local_targets": 1.410461571125,
        "sound_residual_pred_over_target": 1.410461571125,
        "hubble_residual_pred_over_target": 0.9749478330046,
        "particle_residual_pred_over_target": 0.7272058495597,
        "radiation_energy_density_reheat_factor_q4": 9.610388985274e5,
    },
    {
        "candidate_name": "one_fermi",
        "spacing_fm": 1.0,
        "R_post_AU": 1.924767978322,
        "kT_post_MeV": 164.3085385024,
        "single_q_geometric_mean": 31.20501245280,
        "single_q_efolds": 3.440578737450,
        "alpha_extra_per_thermal_efold": 0.1696623356854,
        "max_factor_error_across_local_targets": 1.410461571125,
        "sound_residual_pred_over_target": 1.410461571125,
        "hubble_residual_pred_over_target": 0.9749478330046,
        "particle_residual_pred_over_target": 0.7272058495597,
        "radiation_energy_density_reheat_factor_q4": 9.481945197517e5,
    },
    {
        "candidate_name": "thermal_piece_fixed_kT_equals_Epiece",
        "spacing_fm": 3.634913121798,
        "R_post_AU": 6.996364380818,
        "kT_post_MeV": 62.41509074461,
        "single_q_geometric_mean": 22.59960515012,
        "single_q_efolds": 3.117932434892,
        "alpha_extra_per_thermal_efold": 0.1614585550586,
        "max_factor_error_across_local_targets": 1.410461571125,
        "sound_residual_pred_over_target": 1.410461571125,
        "hubble_residual_pred_over_target": 0.9749478330046,
        "particle_residual_pred_over_target": 0.7272058495597,
        "radiation_energy_density_reheat_factor_q4": 2.608575467913e5,
    },
    {
        "candidate_name": "piece_energy_reduced_Compton",
        "spacing_fm": 3.161526773497,
        "R_post_AU": 6.085205496233,
        "kT_post_MeV": 69.30067818394,
        "single_q_geometric_mean": 23.40184746349,
        "single_q_efolds": 3.152814970678,
        "alpha_extra_per_thermal_efold": 0.1623849340624,
        "max_factor_error_across_local_targets": 1.410461571125,
        "sound_residual_pred_over_target": 1.410461571125,
        "hubble_residual_pred_over_target": 0.9749478330046,
        "particle_residual_pred_over_target": 0.7272058495597,
        "radiation_energy_density_reheat_factor_q4": 2.999166503034e5,
    },
    {
        "candidate_name": "proton_charge_radius",
        "spacing_fm": 0.8409,
        "R_post_AU": 1.618537392971,
        "kT_post_MeV": 187.1120979954,
        "single_q_geometric_mean": 32.58654165568,
        "single_q_efolds": 3.483899370486,
        "alpha_extra_per_thermal_efold": 0.1707045747241,
        "max_factor_error_across_local_targets": 1.410461571125,
        "sound_residual_pred_over_target": 1.410461571125,
        "hubble_residual_pred_over_target": 0.9749478330046,
        "particle_residual_pred_over_target": 0.7272058495597,
        "radiation_energy_density_reheat_factor_q4": 1.127594862352e6,
    },
    {
        "candidate_name": "classical_electron_radius",
        "spacing_fm": 2.8179403262,
        "R_post_AU": 5.423881304691,
        "kT_post_MeV": 75.54596769919,
        "single_q_geometric_mean": 24.08470948944,
        "single_q_efolds": 3.181577178122,
        "alpha_extra_per_thermal_efold": 0.1631412965023,
        "max_factor_error_across_local_targets": 1.410461571125,
        "sound_residual_pred_over_target": 1.410461571125,
        "hubble_residual_pred_over_target": 0.9749478330046,
        "particle_residual_pred_over_target": 0.7272058495597,
        "radiation_energy_density_reheat_factor_q4": 3.364849535442e5,
    },
]

# User can change this to another embedded candidate name.
SELECTED_CANDIDATE_NAME = "thermal_Compton_fixed_kT_equals_hbarc_over_s"


# -----------------------------
# Constants and configuration
# -----------------------------

AU_M = 1.495978707e11
LY_M = 9.4607304725808e15
MLY_M = 1.0e6 * LY_M

K_T_REC_EV = 2.562193818698e-1

LOCAL_TARGETS_MLY = {
    "sound_horizon": 0.4318077002313,
    "hubble_radius": 0.6246982112007,
    "particle_horizon": 0.8375182455706,
}

OUT_DIR = Path("SFT_V12_GATE_12G_OUTPUT")

MAX_ALPHA_EFF_THRESHOLD = 0.35
MAX_SLOPE_RATIO_THRESHOLD = 3.0
BBN_Q_THRESHOLD_SOFT = 5.0
LAW_FIT_FACTOR_THRESHOLD = 2.0


# -----------------------------
# Helpers
# -----------------------------

def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def sigmoid(z: float) -> float:
    if z >= 0:
        ez = math.exp(-z)
        return 1.0 / (1.0 + ez)
    ez = math.exp(z)
    return ez / (1.0 + ez)


def smoothstep(x: float) -> float:
    x = clamp01(x)
    return 3.0*x*x - 2.0*x*x*x


def smootherstep(x: float) -> float:
    x = clamp01(x)
    return 6.0*x**5 - 15.0*x**4 + 10.0*x**3


def normalized_logistic(x: float, x0: float, width: float) -> float:
    a = sigmoid((0.0 - x0) / width)
    b = sigmoid((1.0 - x0) / width)
    s = sigmoid((x - x0) / width)
    if abs(b - a) < 1e-14:
        return x
    return clamp01((s - a) / (b - a))


def law_shape(law_name: str, x: float, params: dict) -> float:
    x = clamp01(x)
    if law_name == "power_constant_alpha":
        return x
    if law_name == "smoothstep_symmetric":
        return smoothstep(x)
    if law_name == "smootherstep_symmetric":
        return smootherstep(x)
    if law_name == "early_smooth_sqrt":
        return math.sqrt(x)
    if law_name == "late_smooth_x2":
        return x*x
    if law_name == "late_smooth_x3":
        return x**3
    if law_name == "early_saturating_1_minus_1mx2":
        return 1.0 - (1.0 - x)**2
    if law_name == "logistic":
        return normalized_logistic(x, params["x0"], params["width"])
    raise ValueError(law_name)


def law_id(law: dict) -> str:
    if law["law_name"] != "logistic":
        return law["law_name"]
    return f"logistic_x0_{law['params']['x0']}_w_{law['params']['width']}"


def law_families() -> list[dict]:
    laws = [
        {"law_name": "power_constant_alpha", "params": {}, "interpretation": "constant extra metric stretch per thermal e-fold"},
        {"law_name": "smoothstep_symmetric", "params": {}, "interpretation": "symmetric smooth handoff with zero endpoint slope"},
        {"law_name": "smootherstep_symmetric", "params": {}, "interpretation": "smoother symmetric handoff with zero endpoint slopes"},
        {"law_name": "early_smooth_sqrt", "params": {}, "interpretation": "front-loaded smooth stretch"},
        {"law_name": "late_smooth_x2", "params": {}, "interpretation": "back-loaded smooth stretch"},
        {"law_name": "late_smooth_x3", "params": {}, "interpretation": "strongly back-loaded stretch"},
        {"law_name": "early_saturating_1_minus_1mx2", "params": {}, "interpretation": "early saturating smooth stretch"},
    ]
    for x0 in [0.25, 0.50, 0.75]:
        for width in [0.08, 0.15, 0.25]:
            laws.append({"law_name": "logistic", "params": {"x0": x0, "width": width}, "interpretation": f"localized handoff around x={x0}, width={width}"})
    return laws


def selected_candidate() -> dict:
    for row in GATE12F_SINGLE_Q:
        if row["candidate_name"] == SELECTED_CANDIDATE_NAME:
            return row
    return GATE12F_SINGLE_Q[0]


def make_seed(c: dict) -> dict:
    kT_post_eV = c["kT_post_MeV"] * 1.0e6
    thermal_growth = kT_post_eV / K_T_REC_EV
    thermal_efolds = math.log(thermal_growth)
    q_rec = c["single_q_geometric_mean"]
    q_efolds = math.log(q_rec)
    alpha = q_efolds / thermal_efolds
    R_post_Mly = c["R_post_AU"] * AU_M / MLY_M
    R_thermal_rec_Mly = R_post_Mly * thermal_growth
    R_eff_rec_Mly = R_thermal_rec_Mly * q_rec

    return {
        "candidate_name": c["candidate_name"],
        "spacing_fm": c["spacing_fm"],
        "R_post_AU": c["R_post_AU"],
        "kT_post_MeV": c["kT_post_MeV"],
        "kT_rec_eV": K_T_REC_EV,
        "thermal_growth_to_rec": thermal_growth,
        "thermal_efolds_to_rec": thermal_efolds,
        "q_rec": q_rec,
        "q_rec_efolds": q_efolds,
        "alpha_power_law": alpha,
        "R_thermal_rec_Mly": R_thermal_rec_Mly,
        "R_eff_rec_Mly": R_eff_rec_Mly,
        "max_factor_error_local_targets_from_12F": c["max_factor_error_across_local_targets"],
        "sound_residual_pred_over_target_from_12F": c["sound_residual_pred_over_target"],
        "hubble_residual_pred_over_target_from_12F": c["hubble_residual_pred_over_target"],
        "particle_residual_pred_over_target_from_12F": c["particle_residual_pred_over_target"],
        "adiabatic_misread_q4_penalty": c["radiation_energy_density_reheat_factor_q4"],
    }


def marker_temperatures(seed: dict) -> list[dict]:
    rec_MeV = K_T_REC_EV * 1.0e-6
    raw = [
        ("post_shatter", seed["kT_post_MeV"], "post-shatter QCD spatialization marker"),
        ("QCD_100MeV", 100.0, "QCD-order comparison marker"),
        ("QCD_50MeV", 50.0, "lower hadronic comparison marker"),
        ("10MeV", 10.0, "early radiation-era comparison marker"),
        ("1MeV_BBNish", 1.0, "BBN-ish comparison marker; not a BBN calculation"),
        ("0p1MeV_BBNish", 0.1, "BBN-ish comparison marker; not a BBN calculation"),
        ("1keV", 1.0e-3, "keV-era comparison marker"),
        ("1eV", 1.0e-6, "eV-era comparison marker"),
        ("recombination", rec_MeV, "recombination thermal marker"),
    ]
    rows = []
    for name, mev, note in raw:
        if mev <= seed["kT_post_MeV"]*(1.0 + 1e-12) and mev >= rec_MeV*(1.0 - 1e-12):
            rows.append({"marker_name": name, "kT_marker_MeV": mev, "kT_marker_eV": mev*1.0e6, "note": note})
    return rows


def x_from_marker(seed: dict, kT_marker_MeV: float) -> float:
    return clamp01(math.log(seed["kT_post_MeV"] / kT_marker_MeV) / seed["thermal_efolds_to_rec"])


def Q_metric(seed: dict, law: dict, x: float) -> float:
    y = law_shape(law["law_name"], x, law["params"])
    return math.exp(seed["q_rec_efolds"] * y)


def sample_laws(seed: dict, markers: list[dict], laws: list[dict]) -> list[dict]:
    rows = []
    for law in laws:
        for m in markers:
            x = x_from_marker(seed, m["kT_marker_MeV"])
            y = law_shape(law["law_name"], x, law["params"])
            Q = math.exp(seed["q_rec_efolds"] * y)
            thermal_growth_to_marker = seed["kT_post_MeV"] / m["kT_marker_MeV"]
            R_thermal_AU = seed["R_post_AU"] * thermal_growth_to_marker
            R_eff_AU = R_thermal_AU * Q
            rows.append({
                "law_id": law_id(law),
                "law_name": law["law_name"],
                "law_params": str(law["params"]),
                "marker_name": m["marker_name"],
                "kT_marker_MeV": m["kT_marker_MeV"],
                "x_thermal_progress": x,
                "shape_y": y,
                "Q_metric": Q,
                "thermal_growth_to_marker": thermal_growth_to_marker,
                "R_thermal_AU": R_thermal_AU,
                "R_eff_AU": R_eff_AU,
                "R_eff_Mly": R_eff_AU * AU_M / MLY_M,
                "interpretation": law["interpretation"],
            })
    return rows


def audit_laws(seed: dict, markers: list[dict], laws: list[dict]) -> list[dict]:
    xs = np.linspace(0.0, 1.0, 2001)
    avg_slope = seed["q_rec_efolds"]
    rows = []

    for law in laws:
        ys = np.array([law_shape(law["law_name"], float(x), law["params"]) for x in xs])
        lnQ = seed["q_rec_efolds"] * ys
        dlnQ_dx = np.gradient(lnQ, xs)
        alpha_eff = dlnQ_dx / seed["thermal_efolds_to_rec"]

        max_alpha = float(np.max(alpha_eff))
        min_alpha = float(np.min(alpha_eff))
        max_slope_ratio = float(np.max(dlnQ_dx) / avg_slope) if avg_slope else math.nan

        marker_Q = {}
        for m in markers:
            x = x_from_marker(seed, m["kT_marker_MeV"])
            marker_Q[m["marker_name"]] = Q_metric(seed, law, x)

        residuals = {}
        for name, target in LOCAL_TARGETS_MLY.items():
            residuals[name] = seed["R_eff_rec_Mly"] / target
        max_factor = max(max(r, 1.0/r) for r in residuals.values())

        smooth_status = "SMOOTH_MODEST" if max_alpha <= MAX_ALPHA_EFF_THRESHOLD and max_slope_ratio <= MAX_SLOPE_RATIO_THRESHOLD else "SHARP_OR_FRONTLOADED"
        bbn_status = "BBN_MARKER_Q_SOFT_OK"
        if marker_Q.get("1MeV_BBNish", 0.0) > BBN_Q_THRESHOLD_SOFT or marker_Q.get("0p1MeV_BBNish", 0.0) > BBN_Q_THRESHOLD_SOFT:
            bbn_status = "BBN_MARKER_Q_LARGE_CHECK_REQUIRED"
        fit_status = "LOCAL_TARGETS_WITHIN_FACTOR_2" if max_factor <= LAW_FIT_FACTOR_THRESHOLD else "LOCAL_TARGETS_NOT_WITHIN_FACTOR_2"

        if smooth_status == "SMOOTH_MODEST" and bbn_status == "BBN_MARKER_Q_SOFT_OK" and fit_status == "LOCAL_TARGETS_WITHIN_FACTOR_2":
            verdict = "PASS_SMOOTH_NONTHERMAL_METRIC_LAW_CANDIDATE"
        elif fit_status == "LOCAL_TARGETS_WITHIN_FACTOR_2":
            verdict = "FITS_RECOMBINATION_BUT_SHAPE_NEEDS_REVIEW"
        else:
            verdict = "FAILS_LOCAL_RECOMBINATION_FIT"

        rows.append({
            "law_id": law_id(law),
            "law_name": law["law_name"],
            "law_params": str(law["params"]),
            "q_rec": seed["q_rec"],
            "q_rec_efolds": seed["q_rec_efolds"],
            "thermal_efolds_to_rec": seed["thermal_efolds_to_rec"],
            "constant_power_alpha_reference": seed["alpha_power_law"],
            "min_alpha_eff": min_alpha,
            "max_alpha_eff": max_alpha,
            "max_slope_ratio_vs_average": max_slope_ratio,
            "Q_at_1MeV_BBNish": marker_Q.get("1MeV_BBNish", math.nan),
            "Q_at_0p1MeV_BBNish": marker_Q.get("0p1MeV_BBNish", math.nan),
            "Q_at_1eV": marker_Q.get("1eV", math.nan),
            "Q_at_recombination": marker_Q.get("recombination", math.nan),
            "R_eff_rec_Mly": seed["R_eff_rec_Mly"],
            "sound_residual_pred_over_target": residuals["sound_horizon"],
            "hubble_residual_pred_over_target": residuals["hubble_radius"],
            "particle_residual_pred_over_target": residuals["particle_horizon"],
            "max_factor_error_local_targets": max_factor,
            "temperature_reheat_factor_if_misread_as_adiabatic": seed["q_rec"],
            "radiation_density_reheat_penalty_q4_if_adiabatic": seed["q_rec"]**4,
            "entropy_density_reheat_penalty_q3_if_adiabatic": seed["q_rec"]**3,
            "smoothness_status": smooth_status,
            "bbn_marker_status": bbn_status,
            "fit_status": fit_status,
            "verdict": verdict,
            "interpretation": law["interpretation"],
        })

    return sorted(rows, key=lambda r: (
        0 if r["verdict"] == "PASS_SMOOTH_NONTHERMAL_METRIC_LAW_CANDIDATE" else 1,
        r["max_alpha_eff"],
        r["max_slope_ratio_vs_average"],
    ))


def target_comparison(seed: dict) -> list[dict]:
    rows = []
    for name, target in LOCAL_TARGETS_MLY.items():
        ratio = seed["R_eff_rec_Mly"] / target
        rows.append({
            "target_name": name,
            "R_target_Mly": target,
            "R_eff_rec_Mly": seed["R_eff_rec_Mly"],
            "pred_over_target": ratio,
            "factor_error": max(ratio, 1.0/ratio),
            "interpretation": "local recombination target comparison using selected single-q bridge",
        })
    return rows


def final_verdict(seed: dict, audits: list[dict]) -> dict:
    passes = [r for r in audits if r["verdict"] == "PASS_SMOOTH_NONTHERMAL_METRIC_LAW_CANDIDATE"]
    best = passes[0] if passes else audits[0]
    verdict = "SMOOTH_NONTHERMAL_METRIC_STRETCH_LAW_NUMERICALLY_VIABLE_NOT_DERIVED" if passes else "NONTHERMAL_METRIC_STRETCH_REQUIRES_REVIEWED_LAW_SHAPE"
    return {
        "verdict": verdict,
        "claim_boundary": "law-shape audit only; no physical mechanism, perturbations, flatness, or inflation replacement derived",
        "selected_bridge_candidate": seed["candidate_name"],
        "spacing_fm": seed["spacing_fm"],
        "R_post_AU": seed["R_post_AU"],
        "kT_post_MeV": seed["kT_post_MeV"],
        "thermal_efolds_to_recombination": seed["thermal_efolds_to_rec"],
        "q_rec": seed["q_rec"],
        "q_rec_efolds": seed["q_rec_efolds"],
        "power_law_alpha": seed["alpha_power_law"],
        "best_law_id": best["law_id"],
        "best_law_max_alpha_eff": best["max_alpha_eff"],
        "best_law_Q_1MeV_BBNish": best["Q_at_1MeV_BBNish"],
        "best_law_Q_0p1MeV_BBNish": best["Q_at_0p1MeV_BBNish"],
        "best_law_Q_1eV": best["Q_at_1eV"],
        "best_law_R_eff_rec_Mly": best["R_eff_rec_Mly"],
        "best_law_max_factor_error_local_targets": best["max_factor_error_local_targets"],
        "adiabatic_misread_radiation_density_penalty_q4": seed["q_rec"]**4,
        "num_passing_smooth_laws": len(passes),
        "key_sentence": (
            "A smooth non-thermal stretch law Q(T) can carry the missing recombination bridge: "
            "for the selected q, a simple constant-alpha law needs only alpha≈0.165 extra metric "
            "stretch per thermal e-fold, reaching q≈26 by recombination while keeping the stretch "
            "modest at BBN-ish markers. This is a viable law shape, not a derived mechanism."
        ),
    }


def save_plots(out: Path, seed: dict, laws: list[dict], audits: list[dict], samples: list[dict], best_law_id: str) -> list[str]:
    plot_paths = []
    try:
        import matplotlib.pyplot as plt

        xs = np.linspace(0.0, 1.0, 300)
        top = audits[:6]

        plt.figure(figsize=(8, 5))
        for audit in top:
            law = next(l for l in laws if law_id(l) == audit["law_id"])
            Qs = [Q_metric(seed, law, float(x)) for x in xs]
            plt.plot(xs, Qs, label=audit["law_id"][:32])
        plt.yscale("log")
        plt.xlabel("x = ln(Tpost/T) / ln(Tpost/Trec)")
        plt.ylabel("Q(T)")
        plt.title("Gate 12G: candidate non-thermal metric stretch laws")
        plt.legend(fontsize=7)
        plt.tight_layout()
        p = out / "gate12G_Q_laws.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        plt.figure(figsize=(8, 5))
        for audit in top:
            law = next(l for l in laws if law_id(l) == audit["law_id"])
            ys = np.array([law_shape(law["law_name"], float(x), law["params"]) for x in xs])
            lnQ = seed["q_rec_efolds"] * ys
            alpha_eff = np.gradient(lnQ, xs) / seed["thermal_efolds_to_rec"]
            plt.plot(xs, alpha_eff, label=audit["law_id"][:32])
        plt.axhline(MAX_ALPHA_EFF_THRESHOLD, linestyle="--", linewidth=1)
        plt.xlabel("x")
        plt.ylabel("instantaneous alpha_eff")
        plt.title("Gate 12G: instantaneous extra stretch per thermal e-fold")
        plt.legend(fontsize=7)
        plt.tight_layout()
        p = out / "gate12G_alpha_eff_laws.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        best_samples = [r for r in samples if r["law_id"] == best_law_id]
        plt.figure(figsize=(9, 5))
        xpos = np.arange(len(best_samples))
        plt.bar(xpos, [r["Q_metric"] for r in best_samples])
        plt.yscale("log")
        plt.xticks(xpos, [r["marker_name"] for r in best_samples], rotation=45, ha="right")
        plt.ylabel("Q(T)")
        plt.title(f"Gate 12G: Q at markers for {best_law_id}")
        plt.tight_layout()
        p = out / "gate12G_best_law_marker_Q.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")

    return plot_paths


def print_kv(row: dict, keys: list[str] | None = None, indent: str = "  ") -> None:
    items = row.items() if keys is None else [(k, row[k]) for k in keys]
    for k, v in items:
        if isinstance(v, float):
            print(f"{indent}{k}: {v:.12e}")
        else:
            print(f"{indent}{k}: {v}")


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    c = selected_candidate()
    seed = make_seed(c)
    markers = marker_temperatures(seed)
    laws = law_families()
    samples = sample_laws(seed, markers, laws)
    audits = audit_laws(seed, markers, laws)
    targets = target_comparison(seed)
    verdict = final_verdict(seed, audits)

    write_csv(OUT_DIR / "gate12G_embedded_gate12F_values.csv", GATE12F_SINGLE_Q)
    write_csv(OUT_DIR / "gate12G_seed_bridge.csv", [seed])
    write_csv(OUT_DIR / "gate12G_temperature_markers.csv", markers)
    write_csv(OUT_DIR / "gate12G_law_samples.csv", samples)
    write_csv(OUT_DIR / "gate12G_law_audit.csv", audits)
    write_csv(OUT_DIR / "gate12G_target_comparison.csv", targets)
    write_csv(OUT_DIR / "gate12G_verdict.csv", [verdict])

    plots = save_plots(OUT_DIR, seed, laws, audits, samples, verdict["best_law_id"])

    report = OUT_DIR / "gate12G_nonthermal_metric_stretch_law_report.txt"
    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12G MOBILE: Non-Thermal Metric Stretch Law\n")
        f.write("=======================================================\n\n")
        f.write("Gate 12F values are embedded directly in this script.\n\n")
        f.write("Selected bridge:\n")
        for k, v in seed.items():
            f.write(f"  {k}: {v}\n")
        f.write("\nTop law audits:\n")
        for row in audits[:10]:
            f.write(f"  {row}\n")
        f.write("\nTarget comparison:\n")
        for row in targets:
            f.write(f"  {row}\n")
        f.write("\nVerdict:\n")
        for k, v in verdict.items():
            f.write(f"  {k}: {v}\n")

    print("\nSFT V12 GATE 12G RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Mobile-integrated non-thermal metric stretch law audit.")
    print("  Gate 12F single-q values are embedded; no previous output folder is required.")
    print("  No stretch mechanism, inflation replacement, perturbations, or flatness derivation is claimed.")

    print("\nSelected Gate 12F bridge:")
    print_kv(seed, [
        "candidate_name", "spacing_fm", "R_post_AU", "kT_post_MeV", "kT_rec_eV",
        "thermal_growth_to_rec", "thermal_efolds_to_rec", "q_rec", "q_rec_efolds",
        "alpha_power_law", "R_thermal_rec_Mly", "R_eff_rec_Mly",
    ])

    print("\nTop law audits:")
    for i, row in enumerate(audits[:10], 1):
        print(f"\n  #{i}")
        print_kv(row, [
            "law_id", "q_rec", "max_alpha_eff", "max_slope_ratio_vs_average",
            "Q_at_1MeV_BBNish", "Q_at_0p1MeV_BBNish", "Q_at_1eV",
            "Q_at_recombination", "max_factor_error_local_targets",
            "smoothness_status", "bbn_marker_status", "fit_status", "verdict",
            "interpretation",
        ], indent="    ")

    best_law_id = verdict["best_law_id"]
    print(f"\nBest-law marker samples: {best_law_id}")
    for row in [r for r in samples if r["law_id"] == best_law_id]:
        print(f"\n  {row['marker_name']}")
        print_kv(row, ["kT_marker_MeV", "x_thermal_progress", "Q_metric", "R_thermal_AU", "R_eff_AU", "R_eff_Mly"], indent="    ")

    print("\nLocal recombination target comparison:")
    for row in targets:
        print(f"\n  {row['target_name']}")
        print_kv(row, ["R_target_Mly", "R_eff_rec_Mly", "pred_over_target", "factor_error"], indent="    ")

    print("\nGate 12G verdict:")
    print_kv(verdict)

    print("\nFiles:")
    print(f"  output directory: {OUT_DIR}")
    print(f"  report: {report}")
    print(f"  embedded 12F values csv: {OUT_DIR / 'gate12G_embedded_gate12F_values.csv'}")
    print(f"  seed csv: {OUT_DIR / 'gate12G_seed_bridge.csv'}")
    print(f"  markers csv: {OUT_DIR / 'gate12G_temperature_markers.csv'}")
    print(f"  samples csv: {OUT_DIR / 'gate12G_law_samples.csv'}")
    print(f"  audits csv: {OUT_DIR / 'gate12G_law_audit.csv'}")
    print(f"  targets csv: {OUT_DIR / 'gate12G_target_comparison.csv'}")
    print(f"  verdict csv: {OUT_DIR / 'gate12G_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
