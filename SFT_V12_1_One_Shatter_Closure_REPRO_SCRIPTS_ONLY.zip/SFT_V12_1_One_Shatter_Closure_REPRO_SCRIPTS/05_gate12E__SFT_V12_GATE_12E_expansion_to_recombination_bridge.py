#!/usr/bin/env python3
"""
SFT V12 Gate 12E: Expansion-to-Recombination Bridge

Purpose
-------
Gate 12D found that a post-shatter 3D bulk spatialization scale in the
fm-to-few-fm range maps N~1e80 local sites to AU-scale radii and QCD/hadronic
temperatures.

Gate 12E asks:

    If post-shatter spatialization starts at AU-scale radius and QCD/hadronic
    temperature, does ordinary adiabatic cooling to recombination land near the
    recombination sound horizon / particle horizon / Hubble radius ledgers?

This is a bridge audit, not a derivation.

Core calculation
----------------
For each post-shatter candidate:

    thermal_growth = T_post / T_rec

assuming radiation-like cooling T proportional to 1/a.

Then:

    R_pred_rec = R_post * thermal_growth

Compare R_pred_rec against recombination physical radii previously established
in Gates 11R/11S:

    physical acoustic sound horizon
    physical particle horizon
    physical Hubble radius
    LSS proper radius at emission

Claim boundary
--------------
This script does NOT:
    - derive the shatter mechanism;
    - derive inflation or replace inflation;
    - claim full thermal history correctness;
    - derive perturbations or flatness;
    - derive a_phi or N.

It DOES:
    - test whether the AU/QCD post-shatter selector naturally reaches
      recombination horizon scales under simple adiabatic cooling;
    - compute any extra metric stretch needed beyond thermal cooling;
    - invert the problem: what post-shatter spacing would be required to hit
      each recombination target by pure thermal cooling?
"""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np


# -----------------------------
# Constants
# -----------------------------

C = 299_792_458.0
H = 6.626_070_15e-34
HBAR = H / (2.0 * math.pi)
G_MARKER = 6.674_30e-11
KB = 1.380_649e-23
SIGMA_SB = 5.670_374_419e-8
A_RAD = 4.0 * SIGMA_SB / C

EV_J = 1.602_176_634e-19
MEV_J = 1.0e6 * EV_J
GEV_J = 1.0e9 * EV_J
TEV_J = 1.0e12 * EV_J

AU_M = 1.495_978_707e11
LY_M = 9.460_730_472_5808e15
MLY_M = 1.0e6 * LY_M
MPC_M = 3.085_677_581_491_3673e22

A_PHI_REF = HBAR * G_MARKER / C**3
A0_REF = H * G_MARKER / C**3
L_ROOT = math.sqrt(A_PHI_REF)


@dataclass
class Config:
    E_total_J: float = 1.0e69
    N_count: float = 1.0e80

    T0_K: float = 2.7255
    z_rec: float = 1089.92

    # Gate 11R / 11S physical recombination ledger radii.
    R_lss_theta_m: float = 3.923979932449e23
    R_lss_lcdm_m: float = 3.922308930608e23
    R_sound_horizon_m: float = 4.085216267873e21
    R_particle_horizon_m: float = 7.923534387212e21
    R_hubble_radius_m: float = 5.910101402873e21

    # Selector windows.
    qcd_kT_min_MeV: float = 50.0
    qcd_kT_max_MeV: float = 300.0
    fm_min: float = 0.5
    fm_max: float = 5.0

    out_dir: str = "SFT_V12_GATE_12E_OUTPUT"


# -----------------------------
# Helpers
# -----------------------------

def sphere_volume(R: float) -> float:
    return (4.0 / 3.0) * math.pi * R**3


def sphere_area(R: float) -> float:
    return 4.0 * math.pi * R**2


def radius_from_area(A: float) -> float:
    return math.sqrt(A / (4.0 * math.pi))


def radius_3d_for_spacing(N: float, s: float) -> float:
    return ((3.0 * N * s**3) / (4.0 * math.pi)) ** (1.0 / 3.0)


def radiation_temperature_from_spacing(E: float, N: float, s: float) -> float:
    # 3D bulk cell map has volume V = N*s^3 exactly.
    return (E / (N * s**3) / A_RAD) ** 0.25


def kT_eV(T: float) -> float:
    return KB * T / EV_J


def kT_MeV(T: float) -> float:
    return KB * T / MEV_J


def scale_energy_MeV(s: float) -> float:
    return HBAR * C / s / MEV_J


def schwarzschild_radius(E: float) -> float:
    return 2.0 * G_MARKER * E / C**4


def efolds(x: float) -> float:
    return math.log(x) if x > 0 else math.nan


def safe_log10(x: float) -> float:
    return math.log10(x) if x > 0 else math.nan


def seed(cfg: Config) -> dict:
    E_piece_MeV = cfg.E_total_J / cfg.N_count / MEV_J
    R_area = radius_from_area(cfg.N_count * A_PHI_REF)
    t_shatter = cfg.N_count / (cfg.E_total_J / H)
    R_causal = C * t_shatter
    T_rec = cfg.T0_K * (1.0 + cfg.z_rec)
    kT_rec_eV = kT_eV(T_rec)

    return {
        "E_total_J": cfg.E_total_J,
        "N_count": cfg.N_count,
        "E_piece_MeV": E_piece_MeV,
        "R_area_m": R_area,
        "R_area_km": R_area / 1e3,
        "t_shatter_s": t_shatter,
        "R_causal_m": R_causal,
        "R_causal_fm": R_causal / 1e-15,
        "T_rec_K": T_rec,
        "kT_rec_eV": kT_rec_eV,
        "R_schwarzschild_m": schwarzschild_radius(cfg.E_total_J),
    }


def recombination_targets(cfg: Config) -> list[dict]:
    return [
        {
            "target_name": "physical_acoustic_sound_horizon",
            "R_target_m": cfg.R_sound_horizon_m,
            "target_class": "local_causal_acoustic",
            "note": "physical sound horizon at recombination from Gate 11R",
        },
        {
            "target_name": "physical_hubble_radius",
            "R_target_m": cfg.R_hubble_radius_m,
            "target_class": "local_expansion",
            "note": "physical Hubble radius at recombination from Gate 11R",
        },
        {
            "target_name": "physical_particle_horizon",
            "R_target_m": cfg.R_particle_horizon_m,
            "target_class": "local_causal_particle",
            "note": "physical particle horizon at recombination from Gate 11R",
        },
        {
            "target_name": "LSS_proper_radius_acoustic_angle",
            "R_target_m": cfg.R_lss_theta_m,
            "target_class": "observational_shell",
            "note": "proper radius to observed CMB shell at emission from acoustic angle; not local causal horizon",
        },
        {
            "target_name": "LSS_proper_radius_LCDM_integral",
            "R_target_m": cfg.R_lss_lcdm_m,
            "target_class": "observational_shell",
            "note": "proper radius to observed CMB shell at emission from LCDM integral; not local causal horizon",
        },
    ]


def candidate_scales(cfg: Config, sd: dict) -> list[dict]:
    E_piece_MeV = sd["E_piece_MeV"]

    # Same candidate family as Gate 12D.
    def thermal_piece_spacing() -> float:
        E_piece_J = cfg.E_total_J / cfg.N_count
        T = E_piece_J / KB
        return (E_piece_J / (A_RAD * T**4)) ** (1.0 / 3.0)

    def thermal_compton_fixed_spacing() -> float:
        E_piece_J = cfg.E_total_J / cfg.N_count
        return A_RAD * (HBAR * C / KB) ** 4 / E_piece_J

    candidates = [
        ("one_fermi", 1.0e-15, "nuclear/QCD order spacing"),
        ("proton_charge_radius", 0.8409e-15, "proton charge-radius marker"),
        ("QCD_200MeV_reduced_Compton", HBAR * C / (200.0 * MEV_J), "hbar c / 200 MeV"),
        ("thermal_Compton_fixed_kT_equals_hbarc_over_s", thermal_compton_fixed_spacing(), "3D radiation cell has kT = hbar c / s"),
        ("classical_electron_radius", 2.8179403262e-15, "classical electron radius marker"),
        ("piece_energy_reduced_Compton", HBAR * C / (E_piece_MeV * MEV_J), "hbar c / (E/N)"),
        ("thermal_piece_fixed_kT_equals_Epiece", thermal_piece_spacing(), "3D radiation cell has kT = E/N"),
        ("causal_core_ct_shatter", sd["R_causal_m"], "ordinary causal radius during shatter time"),
        ("electron_reduced_Compton", 3.8615926796e-13, "electron reduced Compton wavelength"),
    ]

    rows = []
    for name, s, note in candidates:
        R_post = radius_3d_for_spacing(cfg.N_count, s)
        T_post = radiation_temperature_from_spacing(cfg.E_total_J, cfg.N_count, s)
        kT_post_MeV = kT_MeV(T_post)
        qcd_flag = (cfg.fm_min <= s / 1e-15 <= cfg.fm_max) and (cfg.qcd_kT_min_MeV <= kT_post_MeV <= cfg.qcd_kT_max_MeV)
        rows.append({
            "candidate_name": name,
            "spacing_m": s,
            "spacing_fm": s / 1e-15,
            "scale_energy_MeV": scale_energy_MeV(s),
            "R_post_m": R_post,
            "R_post_km": R_post / 1e3,
            "R_post_AU": R_post / AU_M,
            "R_post_ly": R_post / LY_M,
            "T_post_K": T_post,
            "kT_post_MeV": kT_post_MeV,
            "thermal_growth_to_rec": T_post / sd["T_rec_K"],
            "thermal_growth_efolds": efolds(T_post / sd["T_rec_K"]),
            "qcd_bulk_candidate": qcd_flag,
            "note": note,
        })
    return rows


def bridge_rows(cfg: Config, sd: dict, candidates: list[dict], targets: list[dict]) -> list[dict]:
    rows = []
    for c in candidates:
        R_pred = c["R_post_m"] * c["thermal_growth_to_rec"]
        for t in targets:
            ratio = R_pred / t["R_target_m"]
            extra = t["R_target_m"] / R_pred
            rows.append({
                "candidate_name": c["candidate_name"],
                "target_name": t["target_name"],
                "target_class": t["target_class"],
                "spacing_fm": c["spacing_fm"],
                "R_post_AU": c["R_post_AU"],
                "kT_post_MeV": c["kT_post_MeV"],
                "thermal_growth_to_rec": c["thermal_growth_to_rec"],
                "thermal_growth_efolds": c["thermal_growth_efolds"],
                "R_pred_rec_m": R_pred,
                "R_pred_rec_Mly": R_pred / MLY_M,
                "R_pred_rec_Mpc": R_pred / MPC_M,
                "R_target_m": t["R_target_m"],
                "R_target_Mly": t["R_target_m"] / MLY_M,
                "R_target_Mpc": t["R_target_m"] / MPC_M,
                "pred_over_target": ratio,
                "target_over_pred_extra_metric_factor": extra,
                "extra_metric_efolds_needed": efolds(extra),
                "abs_log10_error": abs(safe_log10(ratio)),
                "qcd_bulk_candidate": c["qcd_bulk_candidate"],
                "candidate_note": c["note"],
                "target_note": t["note"],
            })
    return rows


def inverse_spacing_for_target(cfg: Config, sd: dict, target_R: float) -> dict:
    """
    For 3D bulk map:
        R_post = C_R * s, C_R=(3N/4pi)^(1/3)
        T_post = (E/(N A_rad s^3))^(1/4)
        R_rec_pred = R_post * T_post/T_rec = K * s^(1/4)

    Solve s = (R_target/K)^4.
    """
    C_R = (3.0 * cfg.N_count / (4.0 * math.pi)) ** (1.0 / 3.0)
    K = C_R * (cfg.E_total_J / (cfg.N_count * A_RAD)) ** 0.25 / sd["T_rec_K"]
    s_req = (target_R / K) ** 4
    R_post = radius_3d_for_spacing(cfg.N_count, s_req)
    T_post = radiation_temperature_from_spacing(cfg.E_total_J, cfg.N_count, s_req)
    return {
        "spacing_required_m": s_req,
        "spacing_required_fm": s_req / 1e-15,
        "scale_energy_MeV": scale_energy_MeV(s_req),
        "R_post_required_m": R_post,
        "R_post_required_AU": R_post / AU_M,
        "R_post_required_ly": R_post / LY_M,
        "T_post_required_K": T_post,
        "kT_post_required_MeV": kT_MeV(T_post),
        "thermal_growth_required": T_post / sd["T_rec_K"],
        "thermal_growth_required_efolds": efolds(T_post / sd["T_rec_K"]),
    }


def inverse_rows(cfg: Config, sd: dict, targets: list[dict]) -> list[dict]:
    rows = []
    for t in targets:
        inv = inverse_spacing_for_target(cfg, sd, t["R_target_m"])
        rows.append({
            "target_name": t["target_name"],
            "target_class": t["target_class"],
            "R_target_m": t["R_target_m"],
            "R_target_Mly": t["R_target_m"] / MLY_M,
            **inv,
            "qcd_like_spacing_flag": cfg.fm_min <= inv["spacing_required_fm"] <= cfg.fm_max,
            "qcd_like_temperature_flag": cfg.qcd_kT_min_MeV <= inv["kT_post_required_MeV"] <= cfg.qcd_kT_max_MeV,
            "note": "3D spacing that would hit this recombination radius by pure adiabatic cooling only.",
        })
    return rows


def summary_rows(cfg: Config, sd: dict, candidates: list[dict], bridges: list[dict], inverses: list[dict]) -> list[dict]:
    qcd_bridges = [r for r in bridges if r["qcd_bulk_candidate"]]
    local_targets = {"physical_acoustic_sound_horizon", "physical_hubble_radius", "physical_particle_horizon"}
    qcd_local = [r for r in qcd_bridges if r["target_name"] in local_targets]

    best_by_target = []
    for target in sorted(set(r["target_name"] for r in bridges)):
        target_rows = [r for r in bridges if r["target_name"] == target]
        target_qcd_rows = [r for r in target_rows if r["qcd_bulk_candidate"]]
        best_any = min(target_rows, key=lambda r: r["abs_log10_error"])
        best_qcd = min(target_qcd_rows, key=lambda r: r["abs_log10_error"]) if target_qcd_rows else None
        best_by_target.append({
            "summary_name": f"best_any_for_{target}",
            "candidate_name": best_any["candidate_name"],
            "target_name": target,
            "R_pred_rec_Mly": best_any["R_pred_rec_Mly"],
            "R_target_Mly": best_any["R_target_Mly"],
            "pred_over_target": best_any["pred_over_target"],
            "extra_metric_factor_needed": best_any["target_over_pred_extra_metric_factor"],
            "extra_metric_efolds_needed": best_any["extra_metric_efolds_needed"],
            "qcd_bulk_candidate": best_any["qcd_bulk_candidate"],
        })
        if best_qcd:
            best_by_target.append({
                "summary_name": f"best_qcd_for_{target}",
                "candidate_name": best_qcd["candidate_name"],
                "target_name": target,
                "R_pred_rec_Mly": best_qcd["R_pred_rec_Mly"],
                "R_target_Mly": best_qcd["R_target_Mly"],
                "pred_over_target": best_qcd["pred_over_target"],
                "extra_metric_factor_needed": best_qcd["target_over_pred_extra_metric_factor"],
                "extra_metric_efolds_needed": best_qcd["extra_metric_efolds_needed"],
                "qcd_bulk_candidate": True,
            })

    best_qcd_sound = min(
        [r for r in qcd_bridges if r["target_name"] == "physical_acoustic_sound_horizon"],
        key=lambda r: r["abs_log10_error"]
    )
    best_qcd_hubble = min(
        [r for r in qcd_bridges if r["target_name"] == "physical_hubble_radius"],
        key=lambda r: r["abs_log10_error"]
    )
    best_qcd_particle = min(
        [r for r in qcd_bridges if r["target_name"] == "physical_particle_horizon"],
        key=lambda r: r["abs_log10_error"]
    )

    rows = [
        {
            "summary_name": "recombination_temperature",
            "T_rec_K": sd["T_rec_K"],
            "kT_rec_eV": sd["kT_rec_eV"],
            "interpretation": "Temperature marker used for adiabatic cooling T proportional to 1/a.",
        },
        {
            "summary_name": "best_qcd_sound_horizon_bridge",
            "candidate_name": best_qcd_sound["candidate_name"],
            "spacing_fm": best_qcd_sound["spacing_fm"],
            "R_post_AU": best_qcd_sound["R_post_AU"],
            "kT_post_MeV": best_qcd_sound["kT_post_MeV"],
            "R_pred_rec_Mly": best_qcd_sound["R_pred_rec_Mly"],
            "R_target_Mly": best_qcd_sound["R_target_Mly"],
            "extra_metric_factor_needed": best_qcd_sound["target_over_pred_extra_metric_factor"],
            "extra_metric_efolds_needed": best_qcd_sound["extra_metric_efolds_needed"],
        },
        {
            "summary_name": "best_qcd_hubble_radius_bridge",
            "candidate_name": best_qcd_hubble["candidate_name"],
            "spacing_fm": best_qcd_hubble["spacing_fm"],
            "R_post_AU": best_qcd_hubble["R_post_AU"],
            "kT_post_MeV": best_qcd_hubble["kT_post_MeV"],
            "R_pred_rec_Mly": best_qcd_hubble["R_pred_rec_Mly"],
            "R_target_Mly": best_qcd_hubble["R_target_Mly"],
            "extra_metric_factor_needed": best_qcd_hubble["target_over_pred_extra_metric_factor"],
            "extra_metric_efolds_needed": best_qcd_hubble["extra_metric_efolds_needed"],
        },
        {
            "summary_name": "best_qcd_particle_horizon_bridge",
            "candidate_name": best_qcd_particle["candidate_name"],
            "spacing_fm": best_qcd_particle["spacing_fm"],
            "R_post_AU": best_qcd_particle["R_post_AU"],
            "kT_post_MeV": best_qcd_particle["kT_post_MeV"],
            "R_pred_rec_Mly": best_qcd_particle["R_pred_rec_Mly"],
            "R_target_Mly": best_qcd_particle["R_target_Mly"],
            "extra_metric_factor_needed": best_qcd_particle["target_over_pred_extra_metric_factor"],
            "extra_metric_efolds_needed": best_qcd_particle["extra_metric_efolds_needed"],
        },
    ]
    rows.extend(best_by_target)
    return rows


def verdict(cfg: Config, sd: dict, bridges: list[dict], inverses: list[dict]) -> dict:
    qcd_sound = [
        r for r in bridges
        if r["qcd_bulk_candidate"] and r["target_name"] == "physical_acoustic_sound_horizon"
    ]
    best_qcd_sound = min(qcd_sound, key=lambda r: r["abs_log10_error"])

    qcd_local = [
        r for r in bridges
        if r["qcd_bulk_candidate"]
        and r["target_name"] in {"physical_acoustic_sound_horizon", "physical_hubble_radius", "physical_particle_horizon"}
    ]
    min_extra = min(r["target_over_pred_extra_metric_factor"] for r in qcd_local)
    max_extra = max(r["target_over_pred_extra_metric_factor"] for r in qcd_local)
    min_efold = min(r["extra_metric_efolds_needed"] for r in qcd_local)
    max_efold = max(r["extra_metric_efolds_needed"] for r in qcd_local)

    if 0.5 <= best_qcd_sound["pred_over_target"] <= 2.0:
        v = "QCD_SPATIALIZATION_THERMAL_COOLING_HITS_SOUND_HORIZON_ORDER"
    elif best_qcd_sound["target_over_pred_extra_metric_factor"] < 100.0:
        v = "QCD_SPATIALIZATION_UNDERREACHES_RECOMBINATION_LOCAL_HORIZONS_NEEDS_SMALL_EXTRA_METRIC_STRETCH"
    else:
        v = "QCD_SPATIALIZATION_THERMAL_COOLING_FAILS_RECOMBINATION_SCALE"

    inv_sound = [r for r in inverses if r["target_name"] == "physical_acoustic_sound_horizon"][0]

    return {
        "verdict": v,
        "claim_boundary": "bridge audit only; no expansion mechanism derived",
        "best_qcd_sound_candidate": best_qcd_sound["candidate_name"],
        "best_qcd_sound_spacing_fm": best_qcd_sound["spacing_fm"],
        "best_qcd_sound_R_post_AU": best_qcd_sound["R_post_AU"],
        "best_qcd_sound_kT_MeV": best_qcd_sound["kT_post_MeV"],
        "best_qcd_sound_R_pred_rec_Mly": best_qcd_sound["R_pred_rec_Mly"],
        "sound_horizon_target_Mly": best_qcd_sound["R_target_Mly"],
        "sound_horizon_extra_metric_factor_needed": best_qcd_sound["target_over_pred_extra_metric_factor"],
        "sound_horizon_extra_metric_efolds_needed": best_qcd_sound["extra_metric_efolds_needed"],
        "local_horizon_extra_metric_factor_range_min": min_extra,
        "local_horizon_extra_metric_factor_range_max": max_extra,
        "local_horizon_extra_metric_efolds_range_min": min_efold,
        "local_horizon_extra_metric_efolds_range_max": max_efold,
        "pure_thermal_spacing_required_for_sound_horizon_fm": inv_sound["spacing_required_fm"],
        "pure_thermal_kT_required_for_sound_horizon_MeV": inv_sound["kT_post_required_MeV"],
        "pure_thermal_Rpost_required_for_sound_horizon_ly": inv_sound["R_post_required_ly"],
        "key_sentence": (
            "QCD/fm post-shatter spatialization plus ordinary adiabatic cooling reaches a real "
            "fraction of the recombination local-horizon ledgers but underreaches them by roughly "
            "one to a few dozen in radius; therefore the shatter bridge needs a modest additional "
            "metric-stretch channel, not ordinary particle transport and not a derivation of inflation."
        ),
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_outputs(cfg: Config, sd: dict, candidates: list[dict], targets: list[dict], bridges: list[dict], inverses: list[dict], summaries: list[dict], ver: dict) -> dict:
    out = Path(cfg.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    seed_csv = out / "gate12E_seed.csv"
    candidates_csv = out / "gate12E_post_shatter_candidates.csv"
    targets_csv = out / "gate12E_recombination_targets.csv"
    bridge_csv = out / "gate12E_bridge_comparisons.csv"
    inverse_csv = out / "gate12E_inverse_spacing_for_targets.csv"
    summary_csv = out / "gate12E_summary.csv"
    verdict_csv = out / "gate12E_verdict.csv"
    report = out / "gate12E_expansion_to_recombination_bridge_report.txt"

    write_csv(seed_csv, [sd])
    write_csv(candidates_csv, candidates)
    write_csv(targets_csv, targets)
    write_csv(bridge_csv, bridges)
    write_csv(inverse_csv, inverses)
    write_csv(summary_csv, summaries)
    write_csv(verdict_csv, [ver])

    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12E: Expansion-to-Recombination Bridge\n")
        f.write("===================================================\n\n")
        f.write("Purpose:\n")
        f.write("  Compare AU/QCD post-shatter spatialization candidates to recombination\n")
        f.write("  horizon ledgers under simple adiabatic cooling.\n\n")

        f.write("Seed:\n")
        for k, val in sd.items():
            if isinstance(val, float):
                f.write(f"  {k}: {val:.12e}\n")
            else:
                f.write(f"  {k}: {val}\n")

        f.write("\nSummary:\n")
        for row in summaries:
            f.write(f"  {row}\n")

        f.write("\nVerdict:\n")
        for k, val in ver.items():
            if isinstance(val, float):
                f.write(f"  {k}: {val:.12e}\n")
            else:
                f.write(f"  {k}: {val}\n")

    plot_paths = []
    try:
        import matplotlib.pyplot as plt

        qcd = [r for r in bridges if r["qcd_bulk_candidate"]]
        sound = [r for r in qcd if r["target_name"] == "physical_acoustic_sound_horizon"]
        x = [r["spacing_fm"] for r in sound]
        y = [r["R_pred_rec_Mly"] for r in sound]

        target_sound = [t for t in targets if t["target_name"] == "physical_acoustic_sound_horizon"][0]
        target_hubble = [t for t in targets if t["target_name"] == "physical_hubble_radius"][0]
        target_particle = [t for t in targets if t["target_name"] == "physical_particle_horizon"][0]

        plt.figure(figsize=(8, 5))
        plt.scatter(x, y)
        plt.axhline(target_sound["R_target_m"] / MLY_M, linestyle="--", linewidth=1, label="sound horizon")
        plt.axhline(target_hubble["R_target_m"] / MLY_M, linestyle=":", linewidth=1, label="Hubble radius")
        plt.axhline(target_particle["R_target_m"] / MLY_M, linestyle="-.", linewidth=1, label="particle horizon")
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("post-shatter spacing (fm)")
        plt.ylabel("predicted recombination radius (Mly)")
        plt.title("Gate 12E: QCD candidates after thermal cooling")
        plt.legend()
        plt.tight_layout()
        p = out / "gate12E_qcd_predicted_rec_radius.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        plt.figure(figsize=(8, 5))
        plt.scatter(
            [r["spacing_fm"] for r in sound],
            [r["target_over_pred_extra_metric_factor"] for r in sound],
        )
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("post-shatter spacing (fm)")
        plt.ylabel("extra metric factor needed to sound horizon")
        plt.title("Gate 12E: extra stretch beyond thermal cooling")
        plt.tight_layout()
        p = out / "gate12E_extra_metric_factor_sound.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        inv_names = [r["target_name"] for r in inverses]
        inv_spacing = [r["spacing_required_fm"] for r in inverses]
        xpos = np.arange(len(inv_names))
        plt.figure(figsize=(9, 5))
        plt.bar(xpos, inv_spacing)
        plt.yscale("log")
        plt.xticks(xpos, inv_names, rotation=45, ha="right")
        plt.ylabel("required spacing for pure thermal hit (fm)")
        plt.title("Gate 12E: inverse pure-thermal spacing")
        plt.tight_layout()
        p = out / "gate12E_inverse_required_spacing.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")

    return {
        "out_dir": str(out),
        "report": str(report),
        "seed_csv": str(seed_csv),
        "candidates_csv": str(candidates_csv),
        "targets_csv": str(targets_csv),
        "bridge_csv": str(bridge_csv),
        "inverse_csv": str(inverse_csv),
        "summary_csv": str(summary_csv),
        "verdict_csv": str(verdict_csv),
        "plot_paths": plot_paths,
    }


def print_row(row: dict, indent: str = "  ") -> None:
    for k, val in row.items():
        if isinstance(val, float):
            print(f"{indent}{k}: {val:.12e}")
        else:
            print(f"{indent}{k}: {val}")


def main() -> None:
    cfg = Config()
    sd = seed(cfg)
    targets = recombination_targets(cfg)
    candidates = candidate_scales(cfg, sd)
    bridges = bridge_rows(cfg, sd, candidates, targets)
    inverses = inverse_rows(cfg, sd, targets)
    summaries = summary_rows(cfg, sd, candidates, bridges, inverses)
    ver = verdict(cfg, sd, bridges, inverses)
    paths = save_outputs(cfg, sd, candidates, targets, bridges, inverses, summaries, ver)

    qcd_bridges = [r for r in bridges if r["qcd_bulk_candidate"]]
    best_qcd_by_target = []
    for t in targets:
        rows = [r for r in qcd_bridges if r["target_name"] == t["target_name"]]
        if rows:
            best_qcd_by_target.append(min(rows, key=lambda r: r["abs_log10_error"]))

    print("\nSFT V12 GATE 12E RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Expansion-to-recombination bridge: AU/QCD spatialization plus thermal cooling.")
    print("  No shatter mechanism, inflation replacement, or perturbation derivation is claimed.")

    print("\nSeed and recombination marker:")
    for k in ["R_area_km", "R_causal_fm", "E_piece_MeV", "T_rec_K", "kT_rec_eV"]:
        print(f"  {k}: {sd[k]:.12e}")

    print("\nPost-shatter candidates:")
    for c in candidates:
        if c["qcd_bulk_candidate"]:
            print(f"\n  {c['candidate_name']}")
            for k in ["spacing_fm", "scale_energy_MeV", "R_post_AU", "kT_post_MeV", "thermal_growth_to_rec", "thermal_growth_efolds"]:
                print(f"    {k}: {c[k]:.12e}")

    print("\nBest QCD bridge by recombination target:")
    for row in best_qcd_by_target:
        print(f"\n  {row['target_name']} ({row['target_class']})")
        for k in [
            "candidate_name",
            "spacing_fm",
            "R_post_AU",
            "kT_post_MeV",
            "R_pred_rec_Mly",
            "R_target_Mly",
            "pred_over_target",
            "target_over_pred_extra_metric_factor",
            "extra_metric_efolds_needed",
        ]:
            val = row[k]
            if isinstance(val, float):
                print(f"    {k}: {val:.12e}")
            else:
                print(f"    {k}: {val}")

    print("\nInverse pure-thermal spacing required by target:")
    for row in inverses:
        print(f"\n  {row['target_name']} ({row['target_class']})")
        for k in [
            "R_target_Mly",
            "spacing_required_fm",
            "scale_energy_MeV",
            "R_post_required_AU",
            "R_post_required_ly",
            "kT_post_required_MeV",
            "thermal_growth_required",
            "qcd_like_spacing_flag",
            "qcd_like_temperature_flag",
        ]:
            val = row[k]
            if isinstance(val, float):
                print(f"    {k}: {val:.12e}")
            else:
                print(f"    {k}: {val}")

    print("\nSummary:")
    for row in summaries[:4]:
        print(f"\n  {row['summary_name']}")
        for k, val in row.items():
            if k == "summary_name":
                continue
            if isinstance(val, float):
                print(f"    {k}: {val:.12e}")
            else:
                print(f"    {k}: {val}")

    print("\nGate 12E verdict:")
    print_row(ver, "  ")

    print("\nFiles:")
    print(f"  output directory: {paths['out_dir']}")
    print(f"  report: {paths['report']}")
    print(f"  seed csv: {paths['seed_csv']}")
    print(f"  candidates csv: {paths['candidates_csv']}")
    print(f"  targets csv: {paths['targets_csv']}")
    print(f"  bridge csv: {paths['bridge_csv']}")
    print(f"  inverse csv: {paths['inverse_csv']}")
    print(f"  summary csv: {paths['summary_csv']}")
    print(f"  verdict csv: {paths['verdict_csv']}")
    for p in paths["plot_paths"]:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
