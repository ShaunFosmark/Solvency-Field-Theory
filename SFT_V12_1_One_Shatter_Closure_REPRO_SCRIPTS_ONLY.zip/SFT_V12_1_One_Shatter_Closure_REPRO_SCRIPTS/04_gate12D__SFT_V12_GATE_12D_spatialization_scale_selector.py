#!/usr/bin/env python3
"""
SFT V12 Gate 12D: Spatialization Scale Selector

Purpose
-------
Gate 12C established that post-shatter distribution of boundary entries cannot be
ordinary particle transport through already-existing space. It must be a
metric/spatialization map.

Gate 12D asks:

    If N boundary entries become N local ticker sites, what spacing scale is
    selected by the map?

This is a selector audit, not a derivation.

Core idea
---------
For a candidate post-shatter spacing s, compute the radius needed to hold N sites:

    3D bulk map:
        V = N s^3
        R_3D = (3 N s^3 / 4pi)^(1/3)

    2D shell map:
        A = N s^2
        R_2D = sqrt(N s^2 / 4pi)

Then compute the radiation-equivalent temperature if total energy E occupies
that 3D radius:

    u = E / (4pi R^3/3)
    u = a_rad T^4

and compare kT to:
    - the per-piece energy E/N;
    - the scale energy hbar c / s;
    - QCD/nuclear windows.

Claim boundary
--------------
This script does NOT:
    - derive a_phi;
    - derive N;
    - derive the shatter mechanism;
    - prove inflation is unnecessary;
    - derive particle masses.

It DOES:
    - compare root, causal-core, fm, proton, QCD, 62 MeV, electron, and
      self-consistent thermal spacing scales;
    - quantify which spacings land in the QCD / hadronic temperature window;
    - show that fm-to-few-fm 3D spatialization maps N~1e80 to AU-scale radii;
    - keep ordinary-transport failure explicit.
"""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np


# -----------------------------
# Constants
# -----------------------------

C = 299_792_458.0
H = 6.626_070_15e-34
HBAR = H / (2.0 * math.pi)
G_MARKER = 6.674_30e-11
KB = 1.380_649e-23
SIGMA_SB = 5.670_374_419e-8
A_RAD = 4.0 * SIGMA_SB / C

EV_J = 1.602_176_634e-19
MEV_J = 1.0e6 * EV_J
GEV_J = 1.0e9 * EV_J
TEV_J = 1.0e12 * EV_J

AU_M = 1.495_978_707e11
LY_M = 9.460_730_472_5808e15
MPC_M = 3.085_677_581_491_3673e22

A_PHI_REF = HBAR * G_MARKER / C**3
A0_REF = H * G_MARKER / C**3
L_ROOT = math.sqrt(A_PHI_REF)


@dataclass
class Config:
    E_total_J: float = 1.0e69
    N_count: float = 1.0e80

    # Nominal addendum-like convention: cycles for time, a_phi for area count.
    use_area_unit_m2: float = A_PHI_REF

    qcd_kT_min_MeV: float = 50.0
    qcd_kT_max_MeV: float = 300.0
    qcd_scale_min_MeV: float = 50.0
    qcd_scale_max_MeV: float = 300.0

    out_dir: str = "SFT_V12_GATE_12D_OUTPUT"


# -----------------------------
# Helpers
# -----------------------------

def sphere_volume(R: float) -> float:
    return (4.0 / 3.0) * math.pi * R**3


def sphere_area(R: float) -> float:
    return 4.0 * math.pi * R**2


def radius_from_area(A: float) -> float:
    return math.sqrt(A / (4.0 * math.pi))


def radius_3d_for_spacing(N: float, s: float) -> float:
    return ((3.0 * N * s**3) / (4.0 * math.pi)) ** (1.0 / 3.0)


def radius_2d_for_spacing(N: float, s: float) -> float:
    return math.sqrt(N * s**2 / (4.0 * math.pi))


def radiation_temperature(E: float, R: float) -> float:
    return (E / sphere_volume(R) / A_RAD) ** 0.25


def kT_MeV(T: float) -> float:
    return KB * T / MEV_J


def kT_TeV(T: float) -> float:
    return KB * T / TEV_J


def schwarzschild_radius(E: float) -> float:
    return 2.0 * G_MARKER * E / C**4


def scale_energy_MeV(s: float) -> float:
    return HBAR * C / s / MEV_J


def safe_log10(x: float) -> float:
    if x <= 0 or not math.isfinite(x):
        return math.nan
    return math.log10(x)


def seed_quantities(cfg: Config) -> dict:
    E_piece_J = cfg.E_total_J / cfg.N_count
    E_piece_MeV = E_piece_J / MEV_J
    t_shatter_s = cfg.N_count / (cfg.E_total_J / H)
    R_area = radius_from_area(cfg.N_count * cfg.use_area_unit_m2)
    R_causal = C * t_shatter_s
    return {
        "E_piece_J": E_piece_J,
        "E_piece_MeV": E_piece_MeV,
        "t_shatter_s": t_shatter_s,
        "R_area_m": R_area,
        "R_area_km": R_area / 1e3,
        "R_causal_m": R_causal,
        "R_causal_fm": R_causal / 1e-15,
        "R_schwarzschild_m": schwarzschild_radius(cfg.E_total_J),
        "boundary_area_m2": cfg.N_count * cfg.use_area_unit_m2,
    }


def thermal_piece_spacing(cfg: Config) -> float:
    """Spacing such that 3D cell energy density gives kT = E_piece."""
    E_piece = cfg.E_total_J / cfg.N_count
    T = E_piece / KB
    return (E_piece / (A_RAD * T**4)) ** (1.0 / 3.0)


def thermal_compton_fixed_spacing(cfg: Config) -> float:
    """Spacing such that 3D cell energy density gives kT = hbar c / s."""
    E_piece = cfg.E_total_J / cfg.N_count
    return A_RAD * (HBAR * C / KB) ** 4 / E_piece


def candidate_scales(cfg: Config, seed: dict) -> list[dict]:
    E_piece_MeV = seed["E_piece_MeV"]

    # Physical comparison markers. They are selector candidates, not derived facts.
    scales = [
        ("root_length_sqrt_a_phi", L_ROOT, "root/boundary scale"),
        ("causal_core_ct_shatter", seed["R_causal_m"], "ordinary causal radius during shatter time"),
        ("one_fermi", 1.0e-15, "nuclear/QCD order spacing"),
        ("proton_charge_radius", 0.8409e-15, "proton charge-radius marker"),
        ("classical_electron_radius", 2.8179403262e-15, "classical electron radius marker"),
        ("QCD_200MeV_reduced_Compton", HBAR * C / (200.0 * MEV_J), "hbar c / 200 MeV"),
        ("piece_energy_reduced_Compton", HBAR * C / (E_piece_MeV * MEV_J), "hbar c / (E/N)"),
        ("thermal_piece_fixed_kT_equals_Epiece", thermal_piece_spacing(cfg), "3D radiation cell has kT = E/N"),
        ("thermal_Compton_fixed_kT_equals_hbarc_over_s", thermal_compton_fixed_spacing(cfg), "3D radiation cell has kT = hbar c / s"),
        ("electroweak_160GeV_reduced_Compton", HBAR * C / (160.0 * GEV_J), "hbar c / 160 GeV"),
        ("initial_20TeV_reduced_Compton", HBAR * C / (20.69947179648 * TEV_J), "hbar c / nominal initial kT"),
        ("electron_reduced_Compton", 3.8615926796e-13, "electron reduced Compton wavelength"),
    ]

    return [
        {
            "scale_name": name,
            "spacing_m": s,
            "spacing_fm": s / 1e-15,
            "scale_energy_MeV": scale_energy_MeV(s),
            "note": note,
        }
        for name, s, note in scales
    ]


def compute_map_row(cfg: Config, seed: dict, scale: dict, topology: str) -> dict:
    s = scale["spacing_m"]
    if topology == "3D_bulk":
        R = radius_3d_for_spacing(cfg.N_count, s)
        volume_for_temperature_R = R
    elif topology == "2D_shell":
        R = radius_2d_for_spacing(cfg.N_count, s)
        # Temperature as if the shell radius were filled as a volume. Diagnostic only.
        volume_for_temperature_R = R
    else:
        raise ValueError(topology)

    T = radiation_temperature(cfg.E_total_J, volume_for_temperature_R)
    kT_mev = kT_MeV(T)
    E_piece = seed["E_piece_MeV"]
    E_scale = scale["scale_energy_MeV"]

    R_over_Rs = R / seed["R_schwarzschild_m"]
    transport_v_over_c = abs(R - seed["R_causal_m"]) / (C * seed["t_shatter_s"])

    log_kT_over_piece = safe_log10(kT_mev / E_piece)
    log_kT_over_scale = safe_log10(kT_mev / E_scale)
    log_scale_over_piece = safe_log10(E_scale / E_piece)

    qcd_kT_flag = cfg.qcd_kT_min_MeV <= kT_mev <= cfg.qcd_kT_max_MeV
    qcd_scale_flag = cfg.qcd_scale_min_MeV <= E_scale <= cfg.qcd_scale_max_MeV
    fm_spacing_flag = 0.5 <= scale["spacing_fm"] <= 5.0

    combined_selector_score = math.sqrt(log_kT_over_piece**2 + log_kT_over_scale**2)

    if topology == "2D_shell" and scale["scale_name"] == "root_length_sqrt_a_phi":
        selector_class = "PRE_SHATTER_BOUNDARY_LEDGER_IDENTITY"
    elif topology == "3D_bulk" and qcd_kT_flag and qcd_scale_flag and fm_spacing_flag:
        selector_class = "QCD_BULK_SPATIALIZATION_CANDIDATE"
    elif topology == "3D_bulk" and qcd_kT_flag and fm_spacing_flag:
        selector_class = "HADRONIC_BULK_TEMPERATURE_CANDIDATE"
    elif topology == "3D_bulk" and kT_mev > 1.0e6:
        selector_class = "TOO_HOT_FOR_HADRONIC_SPATIALIZATION"
    elif topology == "3D_bulk" and kT_mev < 1.0:
        selector_class = "TOO_COLD_FOR_INITIAL_HADRONIC_SPATIALIZATION"
    else:
        selector_class = "DIAGNOSTIC_OPEN"

    return {
        "scale_name": scale["scale_name"],
        "topology": topology,
        "spacing_m": s,
        "spacing_fm": scale["spacing_fm"],
        "scale_energy_MeV_hbarc_over_s": E_scale,
        "E_piece_MeV": E_piece,
        "R_post_m": R,
        "R_post_km": R / 1e3,
        "R_post_AU": R / AU_M,
        "R_post_ly": R / LY_M,
        "R_post_Mpc": R / MPC_M,
        "factor_vs_R_area": R / seed["R_area_m"],
        "efolds_vs_R_area": math.log(R / seed["R_area_m"]) if R > 0 else math.nan,
        "factor_vs_R_causal": R / seed["R_causal_m"],
        "T_if_volume_K": T,
        "kT_MeV_if_volume": kT_mev,
        "kT_TeV_if_volume": kT_mev / 1.0e6,
        "kT_over_Epiece": kT_mev / E_piece,
        "kT_over_scale_energy": kT_mev / E_scale,
        "scale_energy_over_Epiece": E_scale / E_piece,
        "log10_kT_over_Epiece": log_kT_over_piece,
        "log10_kT_over_scale_energy": log_kT_over_scale,
        "log10_scale_energy_over_Epiece": log_scale_over_piece,
        "combined_selector_score": combined_selector_score,
        "qcd_kT_window_flag": qcd_kT_flag,
        "qcd_scale_window_flag": qcd_scale_flag,
        "fm_spacing_window_flag": fm_spacing_flag,
        "selector_class": selector_class,
        "R_over_Rs": R_over_Rs,
        "inside_schwarzschild": R < seed["R_schwarzschild_m"],
        "ordinary_transport_v_over_c_from_causal_core_in_shatter_time": transport_v_over_c,
        "ordinary_transport_pass": transport_v_over_c <= 1.0,
        "note": scale["note"],
    }


def all_map_rows(cfg: Config, seed: dict) -> list[dict]:
    rows = []
    for scale in candidate_scales(cfg, seed):
        rows.append(compute_map_row(cfg, seed, scale, "3D_bulk"))
        rows.append(compute_map_row(cfg, seed, scale, "2D_shell"))
    return rows


def selector_summary(cfg: Config, rows: list[dict]) -> list[dict]:
    bulk = [r for r in rows if r["topology"] == "3D_bulk"]
    shell = [r for r in rows if r["topology"] == "2D_shell"]

    qcd_bulk = [
        r for r in bulk
        if r["selector_class"] in ("QCD_BULK_SPATIALIZATION_CANDIDATE", "HADRONIC_BULK_TEMPERATURE_CANDIDATE")
    ]
    best_combined = sorted(bulk, key=lambda r: r["combined_selector_score"])[:10]
    best_piece = sorted(bulk, key=lambda r: abs(r["log10_kT_over_Epiece"]))[:10]
    best_scale = sorted(bulk, key=lambda r: abs(r["log10_kT_over_scale_energy"]))[:10]

    root_shell = [
        r for r in shell
        if r["scale_name"] == "root_length_sqrt_a_phi"
    ][0]

    return [
        {
            "summary_name": "num_3D_qcd_or_hadronic_bulk_candidates",
            "value": len(qcd_bulk),
            "interpretation": "3D candidates with fm-ish spacing and QCD/hadronic kT.",
        },
        {
            "summary_name": "best_combined_3D_candidate",
            "scale_name": best_combined[0]["scale_name"],
            "R_post_AU": best_combined[0]["R_post_AU"],
            "spacing_fm": best_combined[0]["spacing_fm"],
            "kT_MeV": best_combined[0]["kT_MeV_if_volume"],
            "scale_energy_MeV": best_combined[0]["scale_energy_MeV_hbarc_over_s"],
            "E_piece_MeV": best_combined[0]["E_piece_MeV"],
            "combined_selector_score": best_combined[0]["combined_selector_score"],
            "selector_class": best_combined[0]["selector_class"],
        },
        {
            "summary_name": "best_piece_temperature_3D_candidate",
            "scale_name": best_piece[0]["scale_name"],
            "R_post_AU": best_piece[0]["R_post_AU"],
            "spacing_fm": best_piece[0]["spacing_fm"],
            "kT_MeV": best_piece[0]["kT_MeV_if_volume"],
            "kT_over_Epiece": best_piece[0]["kT_over_Epiece"],
            "selector_class": best_piece[0]["selector_class"],
        },
        {
            "summary_name": "best_thermal_compton_3D_candidate",
            "scale_name": best_scale[0]["scale_name"],
            "R_post_AU": best_scale[0]["R_post_AU"],
            "spacing_fm": best_scale[0]["spacing_fm"],
            "kT_MeV": best_scale[0]["kT_MeV_if_volume"],
            "scale_energy_MeV": best_scale[0]["scale_energy_MeV_hbarc_over_s"],
            "kT_over_scale": best_scale[0]["kT_over_scale_energy"],
            "selector_class": best_scale[0]["selector_class"],
        },
        {
            "summary_name": "root_length_2D_shell_identity",
            "scale_name": root_shell["scale_name"],
            "R_post_km": root_shell["R_post_km"],
            "factor_vs_R_area": root_shell["factor_vs_R_area"],
            "selector_class": root_shell["selector_class"],
            "interpretation": "This is the pre-shatter boundary ledger identity, not a 3D spatialization map.",
        },
    ]


def verdict(cfg: Config, seed: dict, rows: list[dict]) -> dict:
    bulk = [r for r in rows if r["topology"] == "3D_bulk"]
    qcd = [
        r for r in bulk
        if r["selector_class"] in ("QCD_BULK_SPATIALIZATION_CANDIDATE", "HADRONIC_BULK_TEMPERATURE_CANDIDATE")
    ]
    best_combined = sorted(bulk, key=lambda r: r["combined_selector_score"])[0]
    one_fm = [r for r in bulk if r["scale_name"] == "one_fermi"][0]
    piece = [r for r in bulk if r["scale_name"] == "piece_energy_reduced_Compton"][0]
    fixed = [r for r in bulk if r["scale_name"] == "thermal_Compton_fixed_kT_equals_hbarc_over_s"][0]

    if qcd:
        v = "QCD_SCALE_3D_BULK_SPATIALIZATION_IS_VIABLE_SELECTOR_TARGET"
    else:
        v = "NO_QCD_BULK_SELECTOR_IN_CANDIDATE_SET"

    return {
        "verdict": v,
        "claim_boundary": "selector target only; no mechanism derived",
        "R_area_km": seed["R_area_km"],
        "R_causal_fm": seed["R_causal_fm"],
        "E_piece_MeV": seed["E_piece_MeV"],
        "num_qcd_or_hadronic_bulk_candidates": len(qcd),
        "best_combined_scale_name": best_combined["scale_name"],
        "best_combined_spacing_fm": best_combined["spacing_fm"],
        "best_combined_R_AU": best_combined["R_post_AU"],
        "best_combined_kT_MeV": best_combined["kT_MeV_if_volume"],
        "best_combined_scale_energy_MeV": best_combined["scale_energy_MeV_hbarc_over_s"],
        "one_fm_R_AU": one_fm["R_post_AU"],
        "one_fm_kT_MeV": one_fm["kT_MeV_if_volume"],
        "piece_compton_R_AU": piece["R_post_AU"],
        "piece_compton_kT_MeV": piece["kT_MeV_if_volume"],
        "thermal_compton_fixed_spacing_fm": fixed["spacing_fm"],
        "thermal_compton_fixed_R_AU": fixed["R_post_AU"],
        "thermal_compton_fixed_kT_MeV": fixed["kT_MeV_if_volume"],
        "ordinary_transport_to_best_combined_v_over_c": best_combined["ordinary_transport_v_over_c_from_causal_core_in_shatter_time"],
        "key_sentence": (
            "The root-scale 2D surface is the pre-shatter boundary ledger, while fm-to-few-fm "
            "3D bulk spacing is the natural post-shatter spatialization target: it maps N~1e80 "
            "sites to AU-scale radii and QCD/hadronic temperatures. This is a selector target, "
            "not yet a shatter mechanism."
        ),
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    for r in rows[1:]:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def save_outputs(cfg: Config, seed: dict, rows: list[dict], summary: list[dict], ver: dict) -> dict:
    out = Path(cfg.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    seed_csv = out / "gate12D_seed.csv"
    full_csv = out / "gate12D_full_spatialization_selector.csv"
    qcd_csv = out / "gate12D_qcd_bulk_candidates.csv"
    best_combined_csv = out / "gate12D_best_combined_3D.csv"
    best_piece_csv = out / "gate12D_best_piece_temperature_3D.csv"
    best_scale_csv = out / "gate12D_best_thermal_compton_3D.csv"
    summary_csv = out / "gate12D_selector_summary.csv"
    verdict_csv = out / "gate12D_verdict.csv"
    report = out / "gate12D_spatialization_scale_selector_report.txt"

    bulk = [r for r in rows if r["topology"] == "3D_bulk"]
    qcd = [
        r for r in bulk
        if r["selector_class"] in ("QCD_BULK_SPATIALIZATION_CANDIDATE", "HADRONIC_BULK_TEMPERATURE_CANDIDATE")
    ]
    best_combined = sorted(bulk, key=lambda r: r["combined_selector_score"])
    best_piece = sorted(bulk, key=lambda r: abs(r["log10_kT_over_Epiece"]))
    best_scale = sorted(bulk, key=lambda r: abs(r["log10_kT_over_scale_energy"]))

    write_csv(seed_csv, [seed])
    write_csv(full_csv, rows)
    write_csv(qcd_csv, qcd)
    write_csv(best_combined_csv, best_combined)
    write_csv(best_piece_csv, best_piece)
    write_csv(best_scale_csv, best_scale)
    write_csv(summary_csv, summary)
    write_csv(verdict_csv, [ver])

    with open(report, "w", encoding="utf-8") as f:
        f.write("SFT V12 Gate 12D: Spatialization Scale Selector\n")
        f.write("===============================================\n\n")
        f.write("Purpose:\n")
        f.write("  Compare candidate post-shatter spacing scales for mapping N boundary entries\n")
        f.write("  into local ticker sites. No shatter mechanism or root invariant derivation claimed.\n\n")

        f.write("Seed:\n")
        for k, val in seed.items():
            if isinstance(val, float):
                f.write(f"  {k}: {val:.12e}\n")
            else:
                f.write(f"  {k}: {val}\n")

        f.write("\nSelector summary:\n")
        for row in summary:
            f.write(f"  {row}\n")

        f.write("\nTop combined 3D candidates:\n")
        for row in best_combined[:10]:
            f.write(f"  {row}\n")

        f.write("\nQCD/hadronic 3D candidates:\n")
        for row in qcd:
            f.write(f"  {row}\n")

        f.write("\nVerdict:\n")
        for k, val in ver.items():
            if isinstance(val, float):
                f.write(f"  {k}: {val:.12e}\n")
            else:
                f.write(f"  {k}: {val}\n")

    plot_paths = []
    try:
        import matplotlib.pyplot as plt

        bulk_rows = [r for r in rows if r["topology"] == "3D_bulk"]
        names = [r["scale_name"] for r in bulk_rows]
        x = np.arange(len(names))

        plt.figure(figsize=(11, 5))
        plt.scatter(x, [r["R_post_AU"] for r in bulk_rows])
        plt.yscale("log")
        plt.xticks(x, names, rotation=50, ha="right")
        plt.ylabel("3D post radius (AU)")
        plt.title("Gate 12D: 3D post-shatter radius by spacing scale")
        plt.tight_layout()
        p = out / "gate12D_3D_radius_AU_by_scale.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        plt.figure(figsize=(11, 5))
        plt.scatter(x, [r["kT_MeV_if_volume"] for r in bulk_rows])
        plt.axhline(cfg.qcd_kT_min_MeV, linestyle="--", linewidth=1)
        plt.axhline(cfg.qcd_kT_max_MeV, linestyle="--", linewidth=1)
        plt.axhline(seed["E_piece_MeV"], linestyle=":", linewidth=1)
        plt.yscale("log")
        plt.xticks(x, names, rotation=50, ha="right")
        plt.ylabel("kT if volume-filled (MeV)")
        plt.title("Gate 12D: temperature by 3D spatialization scale")
        plt.tight_layout()
        p = out / "gate12D_3D_kT_by_scale.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

        plt.figure(figsize=(7, 5))
        plt.scatter(
            [r["scale_energy_MeV_hbarc_over_s"] for r in bulk_rows],
            [r["kT_MeV_if_volume"] for r in bulk_rows],
        )
        lo = min(min(r["scale_energy_MeV_hbarc_over_s"] for r in bulk_rows), min(r["kT_MeV_if_volume"] for r in bulk_rows))
        hi = max(max(r["scale_energy_MeV_hbarc_over_s"] for r in bulk_rows), max(r["kT_MeV_if_volume"] for r in bulk_rows))
        plt.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1)
        plt.axhline(seed["E_piece_MeV"], linestyle=":", linewidth=1)
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("scale energy hbar c / s (MeV)")
        plt.ylabel("kT from E/(N s^3) (MeV)")
        plt.title("Gate 12D: thermal-Compton self-consistency")
        plt.tight_layout()
        p = out / "gate12D_thermal_compton_consistency.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plot_paths.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")

    return {
        "out_dir": str(out),
        "report": str(report),
        "seed_csv": str(seed_csv),
        "full_csv": str(full_csv),
        "qcd_csv": str(qcd_csv),
        "best_combined_csv": str(best_combined_csv),
        "best_piece_csv": str(best_piece_csv),
        "best_scale_csv": str(best_scale_csv),
        "summary_csv": str(summary_csv),
        "verdict_csv": str(verdict_csv),
        "plot_paths": plot_paths,
    }


def print_row(row: dict, keys: list[str]) -> None:
    for k in keys:
        val = row.get(k, "")
        if isinstance(val, float):
            print(f"    {k}: {val:.12e}")
        else:
            print(f"    {k}: {val}")


def main() -> None:
    cfg = Config()
    seed = seed_quantities(cfg)
    rows = all_map_rows(cfg, seed)
    summary = selector_summary(cfg, rows)
    ver = verdict(cfg, seed, rows)
    paths = save_outputs(cfg, seed, rows, summary, ver)

    bulk = [r for r in rows if r["topology"] == "3D_bulk"]
    qcd = [
        r for r in bulk
        if r["selector_class"] in ("QCD_BULK_SPATIALIZATION_CANDIDATE", "HADRONIC_BULK_TEMPERATURE_CANDIDATE")
    ]
    best_combined = sorted(bulk, key=lambda r: r["combined_selector_score"])[:10]
    best_piece = sorted(bulk, key=lambda r: abs(r["log10_kT_over_Epiece"]))[:5]
    best_scale = sorted(bulk, key=lambda r: abs(r["log10_kT_over_scale_energy"]))[:5]

    print("\nSFT V12 GATE 12D RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Spatialization scale selector: compare candidate post-shatter spacing maps.")
    print("  No derivation of a_phi, N, or shatter mechanism is claimed.")

    print("\nSeed:")
    for k in [
        "R_area_km",
        "R_causal_fm",
        "t_shatter_s",
        "E_piece_MeV",
        "R_schwarzschild_m",
    ]:
        print(f"  {k}: {seed[k]:.12e}")

    print("\nSelector summary:")
    for row in summary:
        print(f"\n  {row['summary_name']}")
        for k, val in row.items():
            if k == "summary_name":
                continue
            if isinstance(val, float):
                print(f"    {k}: {val:.12e}")
            else:
                print(f"    {k}: {val}")

    keys = [
        "scale_name",
        "spacing_fm",
        "scale_energy_MeV_hbarc_over_s",
        "R_post_AU",
        "R_post_km",
        "factor_vs_R_area",
        "efolds_vs_R_area",
        "kT_MeV_if_volume",
        "kT_over_Epiece",
        "kT_over_scale_energy",
        "combined_selector_score",
        "selector_class",
        "ordinary_transport_v_over_c_from_causal_core_in_shatter_time",
    ]

    print("\nBest combined 3D candidates:")
    for i, row in enumerate(best_combined, start=1):
        print(f"\n  #{i}")
        print_row(row, keys)

    print("\nQCD/hadronic 3D candidates:")
    if not qcd:
        print("  none")
    for i, row in enumerate(qcd, start=1):
        print(f"\n  #{i}")
        print_row(row, keys)

    print("\nBest kT ≈ E_piece 3D candidates:")
    for i, row in enumerate(best_piece, start=1):
        print(f"\n  #{i}")
        print_row(row, keys)

    print("\nBest kT ≈ hbar c / s 3D candidates:")
    for i, row in enumerate(best_scale, start=1):
        print(f"\n  #{i}")
        print_row(row, keys)

    print("\nGate 12D verdict:")
    for k, val in ver.items():
        if isinstance(val, float):
            print(f"  {k}: {val:.12e}")
        else:
            print(f"  {k}: {val}")

    print("\nFiles:")
    print(f"  output directory: {paths['out_dir']}")
    print(f"  report: {paths['report']}")
    print(f"  seed csv: {paths['seed_csv']}")
    print(f"  full selector csv: {paths['full_csv']}")
    print(f"  qcd candidates csv: {paths['qcd_csv']}")
    print(f"  best combined csv: {paths['best_combined_csv']}")
    print(f"  best piece csv: {paths['best_piece_csv']}")
    print(f"  best thermal-compton csv: {paths['best_scale_csv']}")
    print(f"  summary csv: {paths['summary_csv']}")
    print(f"  verdict csv: {paths['verdict_csv']}")
    for p in paths["plot_paths"]:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
