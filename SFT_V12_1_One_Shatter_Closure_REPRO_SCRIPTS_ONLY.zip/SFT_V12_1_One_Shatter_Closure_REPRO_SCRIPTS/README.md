# SFT V12.1 One-Shatter Closure — Reproduction Scripts

This ZIP contains only the successful scripts needed to recreate the V12.1 One-Shatter Closure chain.

It intentionally excludes failed/no-go exploratory scripts and unrelated CMB branch scripts.

## Run order

Run the scripts in numeric order:

```bash
python 01_gate12A__SFT_V12_GATE_12A_unified_shatter_seed_audit.py
python 02_gate12B__SFT_V12_GATE_12B_boundary_radius_vs_spatial_radius_audit.py
python 03_gate12C__SFT_V12_GATE_12C_post_shatter_spatialization_map.py
python 04_gate12D__SFT_V12_GATE_12D_spatialization_scale_selector.py
python 05_gate12E__SFT_V12_GATE_12E_expansion_to_recombination_bridge.py
python 06_gate12F__SFT_V12_GATE_12F_modest_metric_stretch_channel_audit.py
python 07_gate12G__SFT_V12_GATE_12G_nonthermal_metric_stretch_law_MOBILE.py
python 08_gate12H__SFT_V12_GATE_12H_expansion_rate_compatibility_audit.py
python 09_gate12I__SFT_V12_GATE_12I_ledger_vs_thermal_scale_separation_audit.py
python 10_gate12J__SFT_V12_GATE_12J_settlement_conservation_law_audit.py
python 11_gate12K__SFT_V12_GATE_12K_lag_burst_settlement_origin_audit.py
python 12_gate12L__SFT_V12_GATE_12L_end_to_end_shatter_to_recombination_closure_alpha_locked.py
```

## Final closure result

Gate 12L is the final locked end-to-end result:

- locked rule: `Q = a_T^(1/6)`, equivalently `Q^3 = sqrt(a_T)`
- primary spatialization candidate: `s = 2.080201237123 fm`
- `R_post = 4.003904729680 AU`
- `kT_post = 94.85956307390 MeV`
- `a_T = 3.702278975995e8`
- `Q = 26.79650724224`
- `R_eff_rec = 0.6281043601339 Mly`
- recombination Hubble-radius target: `0.6246982112007 Mly`
- Hubble residual: factor `1.005452471085`
- max local target factor error across sound/Hubble/particle ledgers: `1.454592773120`

## Claim boundary

These scripts reproduce a toy closure chain. They do not prove:

- the physical derivation of `alpha = 1/6`;
- full BBN/CMB compatibility;
- perturbations or flatness;
- an inflation replacement;
- the root invariant / absolute gravitational normalization.

The open derivation debt is connecting `Q^3 = sqrt(a_T)` to V11.1B-style settlement diffusion, no-overwrite dynamics, or boundary-service relaxation.
