# FORK 08 CHARTER — Participation-Weighted Settlement (Worldline-Recurrence λ)

**Status: predeclared fork, chartered July 2026, tri-review pending (Shaun / 5.5 / Atlas). Born from the sealed S5/P2′ falsification of Modern SFT SPARC 06C. This charter defines the hypothesis, its frozen ancestry, its constraints, its gate ladder, and its kill criteria. It rescues nothing; the 06C verdict is final.**

---

## 1. The hypothesis (plain statement)

The weak-field solvency boost is sourced not by the instantaneous baryonic mass distribution but by the **time-integrated, relaxation-discounted worldline density** — accumulated settlement debt. Matter that repeatedly re-occupies the same settlement neighborhood (stars on closed orbits, for gigayears) compounds a deep coherent record and receives the full geometric boost. Matter whose worldlines decorrelate before recurrence (turbulent gas, recently accreted or disturbed material) contributes fully to g_bar but has banked little history, and receives a reduced boost. One sentence: **the boost is paid from the ledger, and the ledger records where matter has been, not merely where it is.**

## 2. Frozen ancestry (nothing new except the one operator)

- Worldline write current J_ops: V12.11 eq. (10) — the instantaneous deposit.
- Event-permanence no-overwrite: R182 — deposits are permanent; recurrence deepens, never rewrites.
- Null timelessness: R181 — grounds the frame-advance necessity (the "yielded frame" doctrine, Fosmark July 2026, DESCRIBED status).
- Relaxation rate Γ_settle: the program's standing open operator (V12.13 mass balance; V13.1 gravity–expansion equilibrium; R266F rigidity class). **Fork 08 adds no second unknown: the memory kernel's decay IS Γ_settle**, now constrained from a third scale.
- Endpoints 4/3, 3π/8; mixture rule; source-weight ledger: Traceability Table rows 3–6, 12–13, unchanged.

Schematic operator (words first, math at G0): settlement debt S(x) = history integral of local worldline deposition, discounted by exp(−Γ_settle·Δt); per-component **participation p_j ∈ [0,1]** = the recurrence-vs-relaxation fraction; the component's boost coefficient becomes p_j·λ_j + (1−p_j)·λ_unsettled, with λ_unsettled a *derived target of the operator, never a fitted constant*.

## 3. Constraints (inherited law)

Zero fitted parameters. One new operator, source-side computable. All constants from frozen documents or cited literature. SPEC SHARED / CODE NOT SHARED / HASHES FIRST / VALUES SECOND / TARGET LAST. The 06C target set remains quarantined from all model-form decisions; the old fitted-λ dwarf values (~0.7) are *known to exist* and are hereby declared **forbidden as calibration targets** — if the operator independently lands near them, that is a result; if it is steered to them, that is the disease we cured.

## 4. First-order SPARC-computable proxies (for the G0 collision, not frozen here)

- Stellar disk & bulge: p ≈ 1 (orbital recurrence over ~10² –10³ dynamical times vs any plausible Γ_settle⁻¹). Candidate refinement: p_star from stellar-population age proxies if source-side data permit; else p_star = 1 declared.
- Turbulent gas: p_gas = f(τ_decorrelation/τ_recurrence), both from declared literature scales (HI turbulence decorrelation vs orbital period at R_d); the functional form f is the principal G0 design question — dial not cliff, per the basin picture (smooth in its argument).
- Explicit guards (audit-registered): **bulk galaxy motion is not a variable** (recurrence is counted in the comoving basin frame; R005 Lorentz compatibility); **the operator without relaxation is meaningless** (saturation) — Γ_settle > 0 is structural, and its galactic-scale bound is itself a deliverable.

## 5. Registered long-range predictions (consequences, not test criteria for this fork)

- **P-z:** λ_eff rises with cosmic time as structures accumulate laps — high-z rotation curves show systematically weaker boost at fixed baryonic content (kinematic-settling prediction, now derived; the Erika-facing claim).
- **P-dist:** recently disturbed systems (post-mergers, strong interactions) sit low off the RAR relative to settled twins of equal g_bar.
- **P-acc:** recently accreted gas is boost-discounted even where dynamically cold.

## 6. Gate ladder (mirrors the proven 04→06C chain)

F08-G0 theory/operator freeze (three-way collision on the p_j form and the debt kernel) → F08-G1 data/units audit (unchanged quarantine) → F08-G2 synthetic unit tests (settled disk → prior model recovered; fully decorrelated tracer → λ_unsettled; dial monotone; frame-independence check) → F08-G3 dual-sealed predictions (two engines, hashes first) → F08-G4 validation on the identical 06C rows, metrics, controls, and subgroup cells, **with S5 re-scored as the headline cell** → F08-G5 verdict, blind dual interpretation.

## 7. Predeclared success and kill criteria

- **PASS:** beats λ* on full-sample M1 AND wins the S5 cells it was built to explain AND does not lose the four cells the frozen model won (spirals/Q1/bulge within parity 1.02).
- **PARTIAL:** repairs S5 at spiral parity, or improves dwarfs without full-sample gain — reported as sector repair, boost structure still open.
- **KILL (and its meaning, declared now):** if participation weighting fails the dwarfs *in the same direction again*, the failure is no longer the gas rule — it is the lock→λ map itself, and the morphology-λ program demotes to "spiral-sector effective description" with the a_S scale as SFT's sole surviving SPARC claim. If it wins dwarfs but destroys spirals, the recurrence proxy is wrong, not the concept — one redesign permitted at a new G0, then the kill applies.

## 8. Provenance line for the paper

Fork 08 was chartered from a sealed falsification, three independently generated readings of it (compounding / basin topology / two-maps), and the convergence of its required operator with the program's standing open (Γ_settle). It tests the sentence: *galactic gravity is set by how deeply and coherently weight has settled, and settlement is written in time.*

*— drafted by Atlas for the three-way collision; nothing herein is frozen until three signatures land.*
