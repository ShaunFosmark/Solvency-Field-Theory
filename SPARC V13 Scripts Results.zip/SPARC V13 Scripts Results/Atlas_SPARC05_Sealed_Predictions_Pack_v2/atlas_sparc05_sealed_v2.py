"""Atlas shadow — SPARC 05 Dual-Sealed Predictions, v2.
Changes from v1: (1) --source-dir argument + auto-search for Rotmod_LTG;
(2) HARD GUARD: zero galaxies -> abort, no seal block (empty seals are protocol violations).
Model logic byte-identical to v1: prediction CSV hash must reproduce e5ac20ab..."""
import numpy as np, glob, os, hashlib, zipfile, sys, argparse
ap=argparse.ArgumentParser(); ap.add_argument('--source-dir', default=None); A=ap.parse_args()
def find_source():
    if A.source_dir and glob.glob(os.path.join(A.source_dir,'*_rotmod.dat')): return A.source_dir
    cands=[]
    for root in ['.', '..', os.path.dirname(os.path.abspath(sys.argv[0])),
                 '/home/claude/sft/sparcfull/SPARC', os.path.expanduser('~')]:
        for d,_,_ in os.walk(root):
            n=len(glob.glob(os.path.join(d,'*_rotmod.dat')))
            if n>=100 and 'ETG' not in d.upper(): cands.append((n,d))
            if len(cands)>200: break
    return sorted(cands)[-1][1] if cands else None
SRC=find_source()
files=sorted(glob.glob(os.path.join(SRC,'*_rotmod.dat'))) if SRC else []
if len(files)==0:
    print('ERROR_NO_SOURCE_FILES_FOUND — pass --source-dir pointing at the Rotmod_LTG folder. NO SEAL EMITTED.'); sys.exit(1)
print(f'resolved source dir: {SRC}  ({len(files)} files)')
C=2.99792458e8; H0=67.74*1000/3.0856775814913673e22; A_S=C*H0/(2*np.pi)
KPC=3.0856775814913673e19
LS,LD=4.0/3.0,3*np.pi/8; UD,UB=0.5,0.7
LAM_STAR=LS-(LS-LD)*(1.0-1.0/7.3); MID=(LS+LD)/2.0
rows=[]; nsrc=0; nflag=0
for f in files:
    name=os.path.basename(f).replace('_rotmod.dat','')
    d=np.loadtxt(f, usecols=(0,3,4,5,6,7))
    if d.ndim==1: d=d[None,:]
    R,Vg,Vd,Vb=d[:,0],d[:,1],d[:,2],d[:,3]
    keep=R>0; R,Vg,Vd,Vb=R[keep],Vg[keep],Vd[keep],Vb[keep]; nsrc+=len(R)
    Vbar2=UD*Vd**2+UB*Vb**2+Vg*np.abs(Vg)
    Sd,Sb,Sg=UD*Vd**2,UB*Vb**2,np.abs(Vg)**2
    St=np.where(Sd+Sb+Sg>0,Sd+Sb+Sg,1.0)
    lam=(Sd/St)*LAM_STAR+(Sb/St)*LS+(Sg/St)*LS
    gbar=Vbar2*1e6/(R*KPC); flag=(Vbar2<=0).astype(int); nflag+=int(flag.sum())
    def vp(l):
        g2=gbar**2+l*A_S*gbar
        return np.where(flag==1,0.0,np.where(g2>0,np.sqrt(np.sqrt(np.maximum(g2,0))*R*KPC)/1000.0,0.0))
    gpos=np.maximum(gbar,0.0)
    vN=np.where(flag==1,0.0,np.sqrt(gpos*R*KPC)/1000.0)
    for i in range(len(R)):
        rows.append((name,R[i],lam[i],vp(lam)[i],vp(1.0)[i],vp(LS)[i],vp(LD)[i],vp(MID)[i],vN[i],flag[i]))
hdr='Galaxy,R_kpc,lambda_eff_primary,Vpred_primary,Vpred_lam1,Vpred_lam4over3,Vpred_lam3pi8,Vpred_mid,Vpred_newton,flag'
csv='\n'.join([hdr]+[f'{r[0]},{r[1]:.6f},{r[2]:.6f},{r[3]:.6f},{r[4]:.6f},{r[5]:.6f},{r[6]:.6f},{r[7]:.6f},{r[8]:.6f},{int(r[9])}' for r in rows])+'\n'
open('atlas_sparc05_predictions.csv','w').write(csv)
hS=hashlib.sha256(open(sys.argv[0],'rb').read()).hexdigest(); hC=hashlib.sha256(csv.encode()).hexdigest()
with zipfile.ZipFile('Atlas_SPARC05_Sealed_Predictions_Pack_v2.zip','w') as z:
    z.write(sys.argv[0]); z.write('atlas_sparc05_predictions.csv')
hZ=hashlib.sha256(open('Atlas_SPARC05_Sealed_Predictions_Pack_v2.zip','rb').read()).hexdigest()
print('BEGIN_ATLAS_SPARC05_SHADOW_PREDICTION_SEAL_V2')
print(f'script_sha256={hS}'); print(f'source_row_count={nsrc}'); print(f'galaxy_count={len(files)}')
print(f'prediction_row_count={len(rows)}'); print(f'flag_count={nflag}')
print(f'prediction_csv_sha256={hC}')
print(f'results_zip_sha256={hZ}')
print('v1_csv_reproduction_check=' + ('MATCH_e5ac20ab' if hC.startswith('e5ac20abc7572ad5') else 'MISMATCH_INVESTIGATE'))
print('END_ATLAS_SPARC05_SHADOW_PREDICTION_SEAL_V2')
