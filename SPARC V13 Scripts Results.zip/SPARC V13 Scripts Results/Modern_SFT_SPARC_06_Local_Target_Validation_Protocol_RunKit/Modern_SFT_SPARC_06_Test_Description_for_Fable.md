# Modern SFT SPARC 06 — Description for Fable/Atlas

## Gate name

```text
Modern SFT SPARC 06 — Target Validation
```

## Purpose

Open target-locked \(V_{\rm obs}\) / \(eV_{\rm obs}\) and score the already-sealed SPARC05 predictions.

This gate validates predictions. It does not generate new predictions.

## Hard rule

Use the exact sealed SPARC05 prediction file.

No edits. No rescue. No changed cuts. No regenerated model after target open.

## Inputs

### Prediction file

Sealed G5 prediction CSV from the engine.

5.5 sealed hash:

```text
f0ec5069674768f32adeb0e4d73b54fd3ea2d4d710820a5fff3e2c3414b187e9
```

Atlas sealed hash:

```text
e5ac20abc7572ad5ea9bdb156f4a4e228db4e810e95bf17ff7463504c93e6331
```

### Target

Target-locked rotmod columns only:

```text
Galaxy
R_kpc
Vobs_kms
eVobs_kms
```

Target can be extracted from the original SPARC rotmod files, but only these target columns are used in validation.

## Row matching

Match by:

```text
Galaxy + row_in_galaxy
```

Then verify:

```text
|R_prediction - R_target| <= 1e-6 kpc
```

Any row-count or radius mismatch is a technical failure.

## Exclusions

Rows are excluded from metric calculations only if:

```text
prediction flag is non-OK/nonzero
or Vpred is non-finite/non-positive
or Vobs is non-finite/non-positive
or eVobs is non-finite/non-positive
```

No science cuts are added after target open.

## Primary metric

```text
global per-point log10V RMS
sqrt(mean((log10(Vpred) - log10(Vobs))^2))
```

## Secondary metrics

```text
RMSV_kms = sqrt(mean((Vpred - Vobs)^2))
MAE_kms
sqrt_chi2_per_point = sqrt(mean(((Vpred - Vobs)/eVobs)^2))
median_abs_frac = median(abs(Vpred - Vobs)/Vobs)
```

## Controls

Score the same rows for:

```text
Newtonian
lambda = 1
lambda = 4/3
lambda = 3*pi/8
lambda = midpoint
best global lambda*
```

Important:

```text
best global lambda* is a validation-only control.
It is fitted after target open.
It cannot alter the primary model.
```

For the shared runner, best global \(\lambda^\*\) is found over:

```text
lambda in [0, 2]
```

by minimizing global log10V RMS.

## Help/hurt metrics

Per galaxy, compute log10V RMS for primary and controls.

Report help fractions:

```text
primary vs Newtonian
primary vs midpoint
primary vs best global lambda*
```

Only galaxies with at least 3 valid points are counted in help/hurt fractions.

## Strict science pass condition

```text
PRIMARY_PASS_VS_BEST_GLOBAL_LAMBDA_CONTROL
```

requires:

```text
primary global log10V RMS < best_global_lambda* global log10V RMS
and
primary helps >50% of galaxies versus best_global_lambda*
```

## Partial pass condition

```text
PARTIAL_PASS_VS_NEWTONIAN_ONLY_NOT_BEST_GLOBAL_CONTROL
```

requires:

```text
primary global log10V RMS < Newtonian global log10V RMS
and
primary helps >50% of galaxies versus Newtonian
```

but primary does not beat best global \(\lambda^\*\).

## Fail condition

If neither condition is met:

```text
PRIMARY_FAIL_OR_NO_IMPROVEMENT_UNDER_PREDECLARED_METRICS
```

## Expected output block

```text
BEGIN_ATLAS_SPARC06_VALIDATION_SUMMARY
engine=atlas
technical_verdict=<PASS/FAIL>
science_verdict=<...>
prediction_rows=<N>
target_rows=<N>
merged_rows=<N>
prediction_excluded_rows=<N>
primary_log10V_RMS=<value>
primary_RMSV_kms=<value>
newtonian_log10V_RMS=<value>
midpoint_log10V_RMS=<value>
best_global_lambda_star=<value>
best_global_lambda_star_log10V_RMS=<value>
help_fraction_primary_vs_newtonian=<value>
help_fraction_primary_vs_best_lambda=<value>
prediction_csv_sha256=<sealed hash>
target_sha256=<target hash>
script_sha256=<hash>
results_zip_sha256=<hash>
END_ATLAS_SPARC06_VALIDATION_SUMMARY
```
