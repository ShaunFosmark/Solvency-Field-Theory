@echo off
echo Modern SFT SPARC 06 target validation
echo.
set /p ENGINE=Engine name (fivep5 or atlas): 
set /p PREDS=Prediction CSV or folder path: 
set /p ZIP=SPARC V13.zip path: 
python modern_sft_sparc_06_validation_runner.py --engine-name "%ENGINE%" --predictions "%PREDS%" --sparc-zip "%ZIP%"
pause
