# Modern SFT SPARC 06 — Local Target Validation Run Kit

This validates a sealed SPARC05 prediction file against target-locked SPARC rotation velocities.

## Run for 5.5 predictions

```bash
py modern_sft_sparc_06_validation_runner.py --engine-name fivep5 --predictions "PATH_TO_5P5_PREDICTIONS_OR_FOLDER" --sparc-zip "PATH_TO_SPARC V13.zip"
```

Example:

```bash
py modern_sft_sparc_06_validation_runner.py --engine-name fivep5 --predictions "C:\Users\TaicHI\SPARC V13\Modern_SFT_SPARC_05_Local_Dual_Sealed_Source_Only_Prediction_RunKit\Modern_SFT_SPARC_05_Source_Only_Prediction_Seal_20260702_223950" --sparc-zip "C:\Users\TaicHI\SPARC V13\SPARC V13.zip"
```

## Run for Fable/Atlas predictions

```bash
py modern_sft_sparc_06_validation_runner.py --engine-name atlas --predictions "C:\Users\TaicHI\SPARC V13\Atlas_SPARC05_Sealed_Predictions_Pack_v2" --sparc-zip "C:\Users\TaicHI\SPARC V13\SPARC V13.zip"
```

## Output

The script prints:

```text
BEGIN_MODERN_SFT_SPARC_06_VALIDATION_SUMMARY
...
END_MODERN_SFT_SPARC_06_VALIDATION_SUMMARY
```

Send that block back.

It also creates a local zipped validation pack.
