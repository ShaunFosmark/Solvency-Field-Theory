#!/usr/bin/env python3
"""
Modern SFT SPARC 06 — Target Validation Runner

Run AFTER SPARC05 prediction seals are frozen.

This script validates a sealed source-only prediction CSV against target-locked Vobs/eVobs.
It does not change predictions.
It does not refit the primary model.
It computes predeclared metrics and controls.

Examples:

  py modern_sft_sparc_06_validation_runner.py ^
    --engine-name fivep5 ^
    --predictions "C:\path\Modern_SFT_SPARC_05_Source_Only_Predictions.csv" ^
    --sparc-zip "C:\path\SPARC V13.zip"

  py modern_sft_sparc_06_validation_runner.py ^
    --engine-name atlas ^
    --predictions "C:\path\atlas_sparc05_predictions.csv" ^
    --sparc-zip "C:\path\SPARC V13.zip"

Protocol:
- Use only sealed predictions from G5.
- Open target only here.
- Do not edit prediction files after seeing validation.
- Share the copy/paste summary and zipped results.
"""

from __future__ import annotations
import argparse
import csv
import datetime as dt
import hashlib
import json
import math
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import numpy as np

# Frozen constants from G5
C_M_S = 299_792_458.0
MPC_M = 3.0856775814913673e22
KPC_M = 3.0856775814913673e19
H0_KM_S_MPC = 67.74
H0_SI = H0_KM_S_MPC * 1000.0 / MPC_M
A_S_M_S2 = C_M_S * H0_SI / (2.0 * math.pi)

LAMBDA_SEARCH_MIN = 0.0
LAMBDA_SEARCH_MAX = 2.0


PREDICTION_ALIASES = {
    "primary": ["Vpred_primary_kms", "Vpred_primary"],
    "newtonian": ["Vnewton_kms", "Vpred_newton", "Vnewton"],
    "lambda1": ["Vpred_lambda_1_kms", "Vpred_lam1"],
    "sphere": ["Vpred_lambda_sphere_kms", "Vpred_lam4over3"],
    "disk": ["Vpred_lambda_disk_kms", "Vpred_lam3pi8"],
    "midpoint": ["Vpred_lambda_midpoint_kms", "Vpred_mid"],
}

FORBIDDEN_IN_PREDICTIONS = {
    "Vobs", "eVobs", "errV", "gobs", "residual", "residuals", "chi2", "lambda_best", "best_lambda"
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_rotmod(text: str) -> List[List[float]]:
    rows = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 8:
            try:
                rows.append([float(x) for x in parts[:8]])
            except ValueError:
                pass
    return rows


def load_target_from_sparc_zip(zip_path: Path) -> pd.DataFrame:
    target_rows = []
    with zipfile.ZipFile(zip_path, "r") as z:
        infos = sorted(z.infolist(), key=lambda i: i.filename)
        for info in infos:
            name = info.filename.replace("\\", "/")
            low = name.lower()
            if not (low.endswith("_rotmod.dat") and "rotmod_ltg/" in low):
                continue
            galaxy = Path(name).name.replace("_rotmod.dat", "")
            for row_idx, vals in enumerate(parse_rotmod(z.read(info).decode("utf-8", errors="replace"))):
                Rad, Vobs, errV, Vgas, Vdisk, Vbul, SBdisk, SBbul = vals[:8]
                target_rows.append({
                    "Galaxy": galaxy,
                    "row_in_galaxy": row_idx,
                    "R_kpc_target": Rad,
                    "Vobs_kms": Vobs,
                    "eVobs_kms": errV,
                    "target_source": name,
                })
    return pd.DataFrame(target_rows)


def load_target_from_target_dir(target_dir: Path) -> pd.DataFrame:
    target_rows = []
    files = sorted(target_dir.rglob("*target*.csv"))
    if not files:
        files = sorted(target_dir.rglob("*.csv"))
    for path in files:
        df = pd.read_csv(path)
        required = {"Galaxy", "R_kpc", "Vobs_kms", "eVobs_kms"}
        if not required.issubset(df.columns):
            continue
        for row_idx, r in df.reset_index(drop=True).iterrows():
            target_rows.append({
                "Galaxy": str(r["Galaxy"]).strip(),
                "row_in_galaxy": int(row_idx),
                "R_kpc_target": float(r["R_kpc"]),
                "Vobs_kms": float(r["Vobs_kms"]),
                "eVobs_kms": float(r["eVobs_kms"]),
                "target_source": str(path),
            })
    return pd.DataFrame(target_rows)


def find_prediction_csv(path: Path) -> Path:
    if path.is_file():
        return path
    candidates = []
    patterns = [
        "*Source_Only_Predictions.csv",
        "atlas_sparc05_predictions.csv",
        "*predictions*.csv",
        "*Predictions*.csv",
    ]
    for pat in patterns:
        candidates.extend(sorted(path.rglob(pat)))
    if not candidates:
        raise SystemExit(f"No prediction CSV found in folder: {path}")
    return candidates[0]


def get_col(df: pd.DataFrame, aliases: List[str]) -> Optional[str]:
    for c in aliases:
        if c in df.columns:
            return c
    return None


def load_predictions(path: Path) -> pd.DataFrame:
    pred_csv = find_prediction_csv(path)
    df = pd.read_csv(pred_csv)
    bad = sorted(set(df.columns) & FORBIDDEN_IN_PREDICTIONS)
    if bad:
        raise SystemExit(f"Prediction CSV contains target-like columns, refusing: {bad}")

    if "Galaxy" not in df.columns or "R_kpc" not in df.columns:
        raise SystemExit("Prediction CSV must contain Galaxy and R_kpc.")

    df = df.copy()
    df["Galaxy"] = df["Galaxy"].astype(str).str.strip()
    df["row_in_galaxy"] = df.groupby("Galaxy").cumcount()
    df.attrs["prediction_csv"] = str(pred_csv)
    df.attrs["prediction_csv_sha256"] = sha256_file(pred_csv)
    return df


def normalize_prediction_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df[["Galaxy", "row_in_galaxy", "R_kpc"]].copy()
    out["R_kpc"] = pd.to_numeric(out["R_kpc"], errors="coerce")

    for key, aliases in PREDICTION_ALIASES.items():
        col = get_col(df, aliases)
        if col is None:
            out[key] = np.nan
        else:
            out[key] = pd.to_numeric(df[col], errors="coerce")

    # Flag column can be text or numeric; normalize to boolean exclude.
    flag_col = None
    for c in ["prediction_flag", "flag"]:
        if c in df.columns:
            flag_col = c
            break
    if flag_col is None:
        out["prediction_flag_raw"] = "OK"
        out["prediction_exclude"] = False
    else:
        raw = df[flag_col].astype(str)
        out["prediction_flag_raw"] = raw
        # Atlas uses 0/1; 5.5 uses OK/NONPOSITIVE...
        out["prediction_exclude"] = ~raw.isin(["0", "0.0", "OK", "ok", ""])
    return out


def merge_pred_target(pred: pd.DataFrame, target: pd.DataFrame, r_tol: float = 1e-6) -> Tuple[pd.DataFrame, List[str]]:
    norm = normalize_prediction_columns(pred)
    merged = norm.merge(target, on=["Galaxy", "row_in_galaxy"], how="inner")
    issues = []
    if len(merged) != len(norm) or len(merged) != len(target):
        issues.append(f"ROW_COUNT_MERGE_MISMATCH pred={len(norm)} target={len(target)} merged={len(merged)}")
    rdiff = np.abs(pd.to_numeric(merged["R_kpc"], errors="coerce") - pd.to_numeric(merged["R_kpc_target"], errors="coerce"))
    n_bad_r = int((rdiff > r_tol).sum())
    if n_bad_r:
        issues.append(f"RADIUS_MISMATCH_COUNT={n_bad_r}")
    merged["radius_abs_diff"] = rdiff
    return merged, issues


def valid_mask(df: pd.DataFrame, pred_col: str) -> pd.Series:
    vpred = pd.to_numeric(df[pred_col], errors="coerce")
    vobs = pd.to_numeric(df["Vobs_kms"], errors="coerce")
    eobs = pd.to_numeric(df["eVobs_kms"], errors="coerce")
    return (
        (~df["prediction_exclude"].astype(bool))
        & np.isfinite(vpred)
        & np.isfinite(vobs)
        & (vpred > 0)
        & (vobs > 0)
        & np.isfinite(eobs)
        & (eobs > 0)
    )


def metrics_for(df: pd.DataFrame, pred_col: str) -> Dict[str, float]:
    m = valid_mask(df, pred_col)
    vpred = pd.to_numeric(df.loc[m, pred_col], errors="coerce").to_numpy(dtype=float)
    vobs = pd.to_numeric(df.loc[m, "Vobs_kms"], errors="coerce").to_numpy(dtype=float)
    eobs = pd.to_numeric(df.loc[m, "eVobs_kms"], errors="coerce").to_numpy(dtype=float)
    if len(vpred) == 0:
        return {"N": 0, "log10V_RMS": float("nan"), "RMSV_kms": float("nan"), "MAE_kms": float("nan"), "sqrt_chi2_per_point": float("nan"), "median_abs_frac": float("nan")}
    resid = vpred - vobs
    logres = np.log10(vpred) - np.log10(vobs)
    return {
        "N": int(len(vpred)),
        "log10V_RMS": float(np.sqrt(np.mean(logres * logres))),
        "RMSV_kms": float(np.sqrt(np.mean(resid * resid))),
        "MAE_kms": float(np.mean(np.abs(resid))),
        "sqrt_chi2_per_point": float(np.sqrt(np.mean((resid / eobs) ** 2))),
        "median_abs_frac": float(np.median(np.abs(resid) / vobs)),
    }


def compute_gbar_from_newton(row: pd.Series) -> float:
    vnew = row.get("newtonian", np.nan)
    r = row.get("R_kpc", np.nan)
    try:
        vnew = float(vnew)
        r = float(r)
    except Exception:
        return float("nan")
    if not math.isfinite(vnew) or not math.isfinite(r) or vnew <= 0 or r <= 0:
        return float("nan")
    return vnew * vnew * 1e6 / (r * KPC_M)


def vpred_from_lambda_for_rows(df: pd.DataFrame, lam: float) -> np.ndarray:
    vals = []
    for _, row in df.iterrows():
        gbar = compute_gbar_from_newton(row)
        r = row.get("R_kpc", np.nan)
        if not math.isfinite(gbar) or gbar <= 0 or not math.isfinite(r) or r <= 0:
            vals.append(float("nan"))
            continue
        gsq = gbar * gbar + lam * A_S_M_S2 * gbar
        if gsq < 0:
            vals.append(float("nan"))
            continue
        g = math.sqrt(gsq)
        v2 = g * float(r) * KPC_M
        vals.append(math.sqrt(v2) / 1000.0 if v2 > 0 else float("nan"))
    return np.array(vals, dtype=float)


def log_rms_for_lambda(df: pd.DataFrame, lam: float) -> float:
    tmp = df.copy()
    tmp["lambda_star_control"] = vpred_from_lambda_for_rows(tmp, lam)
    return metrics_for(tmp, "lambda_star_control")["log10V_RMS"]


def golden_minimize_lambda(df: pd.DataFrame, lo: float = LAMBDA_SEARCH_MIN, hi: float = LAMBDA_SEARCH_MAX, iters: int = 80) -> Tuple[float, float]:
    # Golden-section minimization for one smooth-ish scalar objective.
    gr = (math.sqrt(5) - 1) / 2
    x1 = hi - gr * (hi - lo)
    x2 = lo + gr * (hi - lo)
    f1 = log_rms_for_lambda(df, x1)
    f2 = log_rms_for_lambda(df, x2)
    for _ in range(iters):
        if not math.isfinite(f1) or (math.isfinite(f2) and f1 > f2):
            lo = x1
            x1 = x2
            f1 = f2
            x2 = lo + gr * (hi - lo)
            f2 = log_rms_for_lambda(df, x2)
        else:
            hi = x2
            x2 = x1
            f2 = f1
            x1 = hi - gr * (hi - lo)
            f1 = log_rms_for_lambda(df, x1)
    x = 0.5 * (lo + hi)
    return x, log_rms_for_lambda(df, x)


def per_galaxy_help_fraction(df: pd.DataFrame, col_a: str, col_b: str, min_points: int = 3) -> Tuple[float, int, int]:
    galaxies = []
    for gal, gdf in df.groupby("Galaxy"):
        ma = metrics_for(gdf, col_a)
        mb = metrics_for(gdf, col_b)
        if ma["N"] >= min_points and mb["N"] >= min_points:
            galaxies.append(ma["log10V_RMS"] < mb["log10V_RMS"])
    if not galaxies:
        return float("nan"), 0, 0
    helped = sum(1 for x in galaxies if x)
    return helped / len(galaxies), helped, len(galaxies)


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)


def zip_folder(folder: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(folder)))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine-name", required=True, help="e.g. fivep5 or atlas")
    ap.add_argument("--predictions", required=True, help="Prediction CSV or folder containing sealed prediction CSV.")
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--sparc-zip", help="Path to SPARC V13.zip; target Vobs/eVobs extracted from rotmods.")
    group.add_argument("--target-dir", help="Path to TARGET_LOCKED folder from SPARC 02.")
    args = ap.parse_args()

    engine = args.engine_name.strip().replace(" ", "_")
    pred_path = Path(args.predictions).expanduser().resolve()
    pred_csv = find_prediction_csv(pred_path)
    pred_df = load_predictions(pred_path)

    if args.sparc_zip:
        target_source = Path(args.sparc_zip).expanduser().resolve()
        target_df = load_target_from_sparc_zip(target_source)
        target_sha = sha256_file(target_source)
    else:
        target_source = Path(args.target_dir).expanduser().resolve()
        target_df = load_target_from_target_dir(target_source)
        target_sha = "directory_not_single_hash"

    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path.cwd() / f"Modern_SFT_SPARC_06_Target_Validation_{engine}_{timestamp}"
    out_dir.mkdir(parents=True, exist_ok=True)

    merged, issues = merge_pred_target(pred_df, target_df)

    # Compute best global lambda* as a validation-only control.
    lam_star_best, lam_star_logrms = golden_minimize_lambda(merged)
    merged["best_global_lambda_star_control"] = vpred_from_lambda_for_rows(merged, lam_star_best)

    model_cols = {
        "primary": "primary",
        "newtonian": "newtonian",
        "lambda_1": "lambda1",
        "lambda_sphere": "sphere",
        "lambda_disk": "disk",
        "lambda_midpoint": "midpoint",
        "best_global_lambda_star": "best_global_lambda_star_control",
    }

    metric_rows = []
    for name, col in model_cols.items():
        if col not in merged.columns:
            continue
        met = metrics_for(merged, col)
        metric_rows.append({"model": name, **met})

    # Help fractions.
    help_rows = []
    for control_name, control_col in [
        ("newtonian", "newtonian"),
        ("lambda_midpoint", "midpoint"),
        ("best_global_lambda_star", "best_global_lambda_star_control"),
    ]:
        frac, helped, total = per_galaxy_help_fraction(merged, "primary", control_col)
        help_rows.append({
            "comparison": f"primary_vs_{control_name}",
            "help_fraction": frac,
            "galaxies_helped": helped,
            "galaxies_compared": total,
        })

    # Science verdict.
    metrics = {r["model"]: r for r in metric_rows}
    primary = metrics.get("primary", {})
    best = metrics.get("best_global_lambda_star", {})
    newt = metrics.get("newtonian", {})
    help_best = next((r for r in help_rows if r["comparison"] == "primary_vs_best_global_lambda_star"), None)
    help_newt = next((r for r in help_rows if r["comparison"] == "primary_vs_newtonian"), None)

    strict_pass = (
        primary.get("log10V_RMS", float("inf")) < best.get("log10V_RMS", -float("inf"))
        and help_best
        and help_best["help_fraction"] > 0.5
    )
    partial_newton = (
        primary.get("log10V_RMS", float("inf")) < newt.get("log10V_RMS", -float("inf"))
        and help_newt
        and help_newt["help_fraction"] > 0.5
    )
    if strict_pass:
        science_verdict = "PRIMARY_PASS_VS_BEST_GLOBAL_LAMBDA_CONTROL"
    elif partial_newton:
        science_verdict = "PARTIAL_PASS_VS_NEWTONIAN_ONLY_NOT_BEST_GLOBAL_CONTROL"
    else:
        science_verdict = "PRIMARY_FAIL_OR_NO_IMPROVEMENT_UNDER_PREDECLARED_METRICS"

    technical_verdict = "PASS" if len(merged) == len(pred_df) == len(target_df) and not any("RADIUS_MISMATCH" in x for x in issues) else "FAIL"

    # Save outputs.
    merged.to_csv(out_dir / "Modern_SFT_SPARC_06_Merged_Prediction_Target_Table.csv", index=False)
    write_csv(out_dir / "Modern_SFT_SPARC_06_Global_Metrics.csv", metric_rows)
    write_csv(out_dir / "Modern_SFT_SPARC_06_Galaxy_Help_Fractions.csv", help_rows)
    with (out_dir / "Modern_SFT_SPARC_06_Issues.csv").open("w", encoding="utf-8", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["issue"])
        for issue in issues:
            wr.writerow([issue])

    config = {
        "gate": "Modern SFT SPARC 06 — Target Validation",
        "engine": engine,
        "timestamp": timestamp,
        "prediction_csv": str(pred_csv),
        "prediction_csv_sha256": pred_df.attrs.get("prediction_csv_sha256"),
        "target_source": str(target_source),
        "target_sha256": target_sha,
        "technical_verdict": technical_verdict,
        "science_verdict": science_verdict,
        "best_global_lambda_star": lam_star_best,
        "best_global_lambda_star_log10V_RMS": lam_star_logrms,
        "metrics": metric_rows,
        "help_fractions": help_rows,
        "row_counts": {
            "prediction_rows": int(len(pred_df)),
            "target_rows": int(len(target_df)),
            "merged_rows": int(len(merged)),
            "prediction_excluded_rows": int(merged["prediction_exclude"].sum()),
        },
        "notes": [
            "Primary predictions are sealed G5 outputs.",
            "Best global lambda* is a validation-only control computed after target open.",
            "No model changes are allowed from this output.",
            "Strict pass requires primary beating best global lambda* on global log10V RMS and helping >50% galaxies vs best lambda*.",
        ],
    }
    (out_dir / "Modern_SFT_SPARC_06_Config_and_Result.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    shutil.copy2(Path(__file__).resolve(), out_dir / Path(__file__).name)

    # Manifest and zip.
    manifest = []
    for p in sorted(out_dir.rglob("*")):
        if p.is_file() and p.name != "file_manifest.csv":
            manifest.append({
                "relative_path": str(p.relative_to(out_dir)),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    with (out_dir / "file_manifest.csv").open("w", encoding="utf-8", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=["relative_path", "size_bytes", "sha256"])
        wr.writeheader()
        wr.writerows(manifest)

    zip_path = Path.cwd() / f"{out_dir.name}.zip"
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)

    def get_metric(model: str, key: str) -> float:
        return metrics.get(model, {}).get(key, float("nan"))

    summary_lines = [
        "BEGIN_MODERN_SFT_SPARC_06_VALIDATION_SUMMARY",
        "gate=Modern SFT SPARC 06 — Target Validation",
        f"engine={engine}",
        f"timestamp={timestamp}",
        f"technical_verdict={technical_verdict}",
        f"science_verdict={science_verdict}",
        f"prediction_rows={len(pred_df)}",
        f"target_rows={len(target_df)}",
        f"merged_rows={len(merged)}",
        f"prediction_excluded_rows={int(merged['prediction_exclude'].sum())}",
        f"primary_log10V_RMS={get_metric('primary', 'log10V_RMS'):.12g}",
        f"primary_RMSV_kms={get_metric('primary', 'RMSV_kms'):.12g}",
        f"newtonian_log10V_RMS={get_metric('newtonian', 'log10V_RMS'):.12g}",
        f"midpoint_log10V_RMS={get_metric('lambda_midpoint', 'log10V_RMS'):.12g}",
        f"best_global_lambda_star={lam_star_best:.12g}",
        f"best_global_lambda_star_log10V_RMS={get_metric('best_global_lambda_star', 'log10V_RMS'):.12g}",
        f"help_fraction_primary_vs_newtonian={help_newt['help_fraction']:.12g}" if help_newt else "help_fraction_primary_vs_newtonian=nan",
        f"help_fraction_primary_vs_best_lambda={help_best['help_fraction']:.12g}" if help_best else "help_fraction_primary_vs_best_lambda=nan",
        f"prediction_csv_sha256={pred_df.attrs.get('prediction_csv_sha256')}",
        f"target_sha256={target_sha}",
        f"runner_sha256={sha256_file(Path(__file__).resolve())}",
        f"results_zip={zip_path.name}",
        f"results_zip_sha256={zip_hash}",
        "END_MODERN_SFT_SPARC_06_VALIDATION_SUMMARY",
    ]
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_VALIDATION_SUMMARY.txt").write_text(summary_text, encoding="utf-8")

    # Rezip with summary and update final hash.
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)
    summary_lines[-2] = f"results_zip_sha256={zip_hash}"
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_VALIDATION_SUMMARY.txt").write_text(summary_text, encoding="utf-8")
    zip_folder(out_dir, zip_path)

    print("\n" + summary_text)
    print(f"Saved validation folder: {out_dir}")
    print(f"Saved zipped validation pack: {zip_path}")
    return 0 if technical_verdict == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
