#!/usr/bin/env python3
r"""
Modern SFT SPARC 06C — Canonical Subgroup Cross-Check Runner

Purpose:
Score the predeclared subgroup cells after target validation, using the pinned Atlas/5.5
cell definition:

  cell statistic = mean over galaxies of median |Δlog10 V|
  win = primary cell statistic < global lambda* cell statistic

This is a subgroup scoring witness only. It does not change predictions.

Run in IDLE/F5 or command line.

IDLE/F5 mode:
  The script prompts for engine name, prediction path, and SPARC V13.zip path.

Command-line mode:
  py modern_sft_sparc_06c_canonical_subgroup_runner.py --engine-name fivep5 --predictions "PATH" --sparc-zip "PATH\SPARC V13.zip"

Important parsing note:
  Table1 galaxy names are right-justified; this script uses split() after strip-like handling
  and never filters on ^\S.
"""

from __future__ import annotations
import argparse
import csv
import datetime as dt
import hashlib
import json
import math
import re
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import pandas as pd
    import numpy as np
except Exception as e:
    raise SystemExit(
        "This runner needs pandas and numpy. Install with:\n"
        "  py -m pip install pandas numpy\n"
        f"Original import error: {e}"
    )

# Constants
C_M_S = 299_792_458.0
MPC_M = 3.0856775814913673e22
KPC_M = 3.0856775814913673e19
H0_KM_S_MPC = 67.74
H0_SI = H0_KM_S_MPC * 1000.0 / MPC_M
A_S_M_S2 = C_M_S * H0_SI / (2.0 * math.pi)

GRID_LAMBDA_MIN = 0.3
GRID_LAMBDA_MAX = 2.5
GRID_LAMBDA_STEP = 0.001

S5_FGAS_THRESHOLD = 0.751189693950

PREDICTION_ALIASES = {
    "primary": ["Vpred_primary_kms", "Vpred_primary"],
    "newtonian": ["Vnewton_kms", "Vpred_newton", "Vnewton"],
    "lambda1": ["Vpred_lambda_1_kms", "Vpred_lam1"],
    "sphere": ["Vpred_lambda_sphere_kms", "Vpred_lam4over3"],
    "disk": ["Vpred_lambda_disk_kms", "Vpred_lam3pi8"],
    "midpoint": ["Vpred_lambda_midpoint_kms", "Vpred_mid"],
    "w_gas": ["w_gas"],
    "Vbul": ["Vbul_kms", "Vbul"],
}

FORBIDDEN_IN_PREDICTIONS = {
    "Vobs", "eVobs", "errV", "gobs", "residual", "residuals", "chi2", "lambda_best", "best_lambda"
}


def clean_path(s: str) -> str:
    return s.strip().strip('"').strip("'")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_rotmod(text: str) -> List[List[float]]:
    rows = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 8:
            try:
                rows.append([float(x) for x in parts[:8]])
            except ValueError:
                pass
    return rows


def parse_table1_from_zip(zip_path: Path) -> pd.DataFrame:
    rows = []
    with zipfile.ZipFile(zip_path, "r") as z:
        candidates = [n for n in z.namelist() if n.replace("\\", "/").lower().endswith("table1.txt")]
        if not candidates:
            raise SystemExit("Table1.txt not found in SPARC zip.")
        text = z.read(candidates[0]).decode("utf-8", errors="replace")
    for raw in text.splitlines():
        # Do not use ^\S. Names are right-justified in an 11-character field.
        parts = raw.split()
        if len(parts) >= 18 and re.match(r"^[A-Za-z0-9_+\-]+$", parts[0]):
            try:
                rows.append({
                    "Galaxy": parts[0],
                    "Ttype": int(float(parts[1])),
                    "Q": int(float(parts[17])),
                })
            except Exception:
                pass
    if not rows:
        raise SystemExit("Parsed zero Table1 rows. Check Table1 format/path.")
    return pd.DataFrame(rows)


def load_target_and_source_from_zip(zip_path: Path) -> pd.DataFrame:
    rows = []
    with zipfile.ZipFile(zip_path, "r") as z:
        infos = sorted(z.infolist(), key=lambda i: i.filename)
        for info in infos:
            name = info.filename.replace("\\", "/")
            low = name.lower()
            if not (low.endswith("_rotmod.dat") and "rotmod_ltg/" in low):
                continue
            galaxy = Path(name).name.replace("_rotmod.dat", "")
            for row_idx, vals in enumerate(parse_rotmod(z.read(info).decode("utf-8", errors="replace"))):
                Rad, Vobs, errV, Vgas, Vdisk, Vbul, SBdisk, SBbul = vals[:8]
                rows.append({
                    "Galaxy": galaxy,
                    "row_in_galaxy": row_idx,
                    "R_kpc_target": Rad,
                    "Vobs_kms": Vobs,
                    "eVobs_kms": errV,
                    "Vgas_source": Vgas,
                    "Vdisk_source": Vdisk,
                    "Vbul_source": Vbul,
                    "target_source": name,
                })
    if not rows:
        raise SystemExit("No LTG target rows found in SPARC zip.")
    return pd.DataFrame(rows)


def find_prediction_csv(path: Path) -> Path:
    if path.is_file():
        return path
    candidates = []
    patterns = [
        "*Source_Only_Predictions.csv",
        "atlas_sparc05_predictions.csv",
        "*predictions*.csv",
        "*Predictions*.csv",
    ]
    for pat in patterns:
        candidates.extend(sorted(path.rglob(pat)))
    if not candidates:
        raise SystemExit(f"No prediction CSV found in folder: {path}")
    return candidates[0]


def get_col(df: pd.DataFrame, aliases: List[str]) -> Optional[str]:
    for c in aliases:
        if c in df.columns:
            return c
    return None


def load_predictions(path: Path) -> pd.DataFrame:
    pred_csv = find_prediction_csv(path)
    df = pd.read_csv(pred_csv)
    bad = sorted(set(df.columns) & FORBIDDEN_IN_PREDICTIONS)
    if bad:
        raise SystemExit(f"Prediction CSV contains target-like columns, refusing: {bad}")
    if "Galaxy" not in df.columns or "R_kpc" not in df.columns:
        raise SystemExit("Prediction CSV must contain Galaxy and R_kpc.")
    df = df.copy()
    df["Galaxy"] = df["Galaxy"].astype(str).str.strip()
    df["row_in_galaxy"] = df.groupby("Galaxy").cumcount()
    df.attrs["prediction_csv"] = str(pred_csv)
    df.attrs["prediction_csv_sha256"] = sha256_file(pred_csv)
    return df


def normalize_prediction_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df[["Galaxy", "row_in_galaxy", "R_kpc"]].copy()
    out["R_kpc"] = pd.to_numeric(out["R_kpc"], errors="coerce")

    for key in ["primary", "newtonian", "lambda1", "sphere", "disk", "midpoint", "w_gas", "Vbul"]:
        col = get_col(df, PREDICTION_ALIASES[key])
        out[key] = np.nan if col is None else pd.to_numeric(df[col], errors="coerce")

    flag_col = None
    for c in ["prediction_flag", "flag"]:
        if c in df.columns:
            flag_col = c
            break
    if flag_col is None:
        out["prediction_flag_raw"] = "OK"
        out["prediction_exclude"] = False
    else:
        raw = df[flag_col].astype(str)
        out["prediction_flag_raw"] = raw
        out["prediction_exclude"] = ~raw.isin(["0", "0.0", "OK", "ok", ""])
    return out


def merge_all(pred: pd.DataFrame, target_source: pd.DataFrame, table1: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    norm = normalize_prediction_columns(pred)
    merged = norm.merge(target_source, on=["Galaxy", "row_in_galaxy"], how="inner")
    issues = []
    if len(merged) != len(norm) or len(merged) != len(target_source):
        issues.append(f"ROW_COUNT_MERGE_MISMATCH pred={len(norm)} target={len(target_source)} merged={len(merged)}")
    rdiff = np.abs(pd.to_numeric(merged["R_kpc"], errors="coerce") - pd.to_numeric(merged["R_kpc_target"], errors="coerce"))
    if int((rdiff > 1e-6).sum()):
        issues.append(f"RADIUS_MISMATCH_COUNT={int((rdiff > 1e-6).sum())}")
    merged["radius_abs_diff"] = rdiff
    merged = merged.merge(table1, on="Galaxy", how="left")
    if merged["Ttype"].isna().any() or merged["Q"].isna().any():
        issues.append(f"TABLE1_MISSING_METADATA_ROWS={int(merged['Ttype'].isna().sum())}")
    return merged, issues


def fill_missing_source_fields(df: pd.DataFrame) -> pd.DataFrame:
    # If prediction CSV lacks w_gas / Vbul, recompute from source columns extracted from the SPARC zip.
    out = df.copy()
    if out["w_gas"].isna().all():
        s_star = 0.5 * out["Vdisk_source"] ** 2
        s_bul = 0.7 * out["Vbul_source"] ** 2
        s_gas = np.abs(out["Vgas_source"]) ** 2
        total = s_star + s_bul + s_gas
        out["w_gas"] = np.where(total > 0, s_gas / total, 0.0)
    if out["Vbul"].isna().all():
        out["Vbul"] = out["Vbul_source"]
    return out


def valid_base(df: pd.DataFrame) -> pd.Series:
    return (
        (~df["prediction_exclude"].astype(bool))
        & np.isfinite(pd.to_numeric(df["primary"], errors="coerce"))
        & (pd.to_numeric(df["primary"], errors="coerce") > 0)
        & np.isfinite(pd.to_numeric(df["Vobs_kms"], errors="coerce"))
        & (pd.to_numeric(df["Vobs_kms"], errors="coerce") > 0)
        & np.isfinite(pd.to_numeric(df["eVobs_kms"], errors="coerce"))
        & (pd.to_numeric(df["eVobs_kms"], errors="coerce") > 0)
    )


def vpred_from_lambda(df: pd.DataFrame, lam: float) -> np.ndarray:
    vals = []
    for _, row in df.iterrows():
        vnew = row.get("newtonian", np.nan)
        r = row.get("R_kpc", np.nan)
        try:
            vnew = float(vnew); r = float(r)
        except Exception:
            vals.append(np.nan); continue
        if not math.isfinite(vnew) or not math.isfinite(r) or vnew <= 0 or r <= 0:
            vals.append(np.nan); continue
        gbar = vnew * vnew * 1e6 / (r * KPC_M)
        gsq = gbar * gbar + lam * A_S_M_S2 * gbar
        if gsq < 0:
            vals.append(np.nan); continue
        vals.append(math.sqrt(math.sqrt(gsq) * r * KPC_M) / 1000.0)
    return np.array(vals, dtype=float)


def m1_per_point(df: pd.DataFrame, pred_col: str, submask: Optional[pd.Series] = None) -> Tuple[float, int]:
    m = valid_base(df)
    vals = pd.to_numeric(df[pred_col], errors="coerce")
    m = m & np.isfinite(vals) & (vals > 0)
    if submask is not None:
        m = m & submask
    if int(m.sum()) == 0:
        return float("nan"), 0
    d = np.log10(pd.to_numeric(df.loc[m, "Vobs_kms"], errors="coerce").to_numpy()) - np.log10(vals.loc[m].to_numpy())
    return float(np.sqrt(np.mean(d*d))), int(m.sum())


def find_grid_lambda_star(df: pd.DataFrame) -> Tuple[float, float]:
    best_lam = None
    best_m1 = float("inf")
    n_steps = int(round((GRID_LAMBDA_MAX - GRID_LAMBDA_MIN) / GRID_LAMBDA_STEP)) + 1
    for i in range(n_steps):
        lam = round(GRID_LAMBDA_MIN + i * GRID_LAMBDA_STEP, 3)
        col = f"tmp_lambda_{lam:.3f}"
        df[col] = vpred_from_lambda(df, lam)
        m1, _ = m1_per_point(df, col)
        del df[col]
        if math.isfinite(m1) and m1 < best_m1:
            best_m1 = m1
            best_lam = lam
    if best_lam is None:
        raise SystemExit("Could not find grid lambda*.")
    return float(best_lam), float(best_m1)


def galaxy_scores(df: pd.DataFrame, pred_col: str, submask: pd.Series) -> pd.DataFrame:
    rows = []
    dff = df[submask].copy()
    for gal, g in dff.groupby("Galaxy"):
        m = valid_base(g)
        vals = pd.to_numeric(g[pred_col], errors="coerce")
        m = m & np.isfinite(vals) & (vals > 0)
        if int(m.sum()) == 0:
            continue
        resid_abs = np.abs(np.log10(pd.to_numeric(g.loc[m, "Vobs_kms"], errors="coerce").to_numpy()) - np.log10(vals.loc[m].to_numpy()))
        rows.append({
            "Galaxy": gal,
            "n_valid": int(m.sum()),
            "median_abs_dlog10V": float(np.median(resid_abs)),
        })
    return pd.DataFrame(rows)


def cell_score_and_help(df: pd.DataFrame, submask: pd.Series, pred_col: str = "primary", control_col: str = "lambda_star_grid_control") -> Dict[str, Any]:
    gp = galaxy_scores(df, pred_col, submask)
    gc = galaxy_scores(df, control_col, submask)
    merged = gp.merge(gc, on="Galaxy", suffixes=("_primary", "_control"))
    if len(merged) == 0:
        return {
            "galaxies_compared": 0,
            "cell_primary_mean_median_abs_dlog10V": float("nan"),
            "cell_control_mean_median_abs_dlog10V": float("nan"),
            "cell_win_primary_lt_control": False,
            "help_fraction": float("nan"),
            "galaxies_helped": 0,
        }
    primary_score = float(merged["median_abs_dlog10V_primary"].mean())
    control_score = float(merged["median_abs_dlog10V_control"].mean())
    helped = int((merged["median_abs_dlog10V_primary"] < merged["median_abs_dlog10V_control"]).sum())
    return {
        "galaxies_compared": int(len(merged)),
        "cell_primary_mean_median_abs_dlog10V": primary_score,
        "cell_control_mean_median_abs_dlog10V": control_score,
        "cell_win_primary_lt_control": bool(primary_score < control_score),
        "help_fraction": float(helped / len(merged)),
        "galaxies_helped": helped,
    }


def build_subgroups(df: pd.DataFrame) -> Dict[str, pd.Series]:
    medgas = df.groupby("Galaxy")["w_gas"].median().rename("median_w_gas")
    bulge = df.groupby("Galaxy")["Vbul"].max().gt(0).rename("bulge_present")
    df2 = df.merge(medgas, on="Galaxy").merge(bulge, on="Galaxy")
    # Put merged fields back into df by index order (same row count/order after merge)
    df["median_w_gas"] = df2["median_w_gas"].values
    df["bulge_present"] = df2["bulge_present"].values

    return {
        "S1_T_le_3": df["Ttype"] <= 3,
        "S1_T_4_7": (df["Ttype"] >= 4) & (df["Ttype"] <= 7),
        "S1_T_8_9": (df["Ttype"] >= 8) & (df["Ttype"] <= 9),
        "S1_T_ge_10": df["Ttype"] >= 10,
        "S2_Q1": df["Q"] == 1,
        "S2_Q2": df["Q"] == 2,
        "S2_Q3": df["Q"] == 3,
        "S3_gas_dominant_median_wgas_gt_0p5": df["median_w_gas"] > 0.5,
        "S3_not_gas_dominant_median_wgas_le_0p5": df["median_w_gas"] <= 0.5,
        "S4_bulge_present": df["bulge_present"],
        "S4_bulge_absent": ~df["bulge_present"],
        "S5_P2prime_dwarf_hi_gas_T_ge_10_wgas_gt_0p7512": (df["Ttype"] >= 10) & (df["median_w_gas"] > S5_FGAS_THRESHOLD),
        "S5_P2prime_dwarf_lo_gas_T_ge_10_wgas_le_0p7512": (df["Ttype"] >= 10) & (df["median_w_gas"] <= S5_FGAS_THRESHOLD),
    }


def zip_folder(folder: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(folder)))


def prompt_if_missing(args: argparse.Namespace) -> argparse.Namespace:
    if len(sys.argv) > 1:
        return args
    print("\nModern SFT SPARC 06C — Canonical Subgroup Cross-Check Runner")
    print("Paste paths without worrying about quotes.\n")
    args.engine_name = input("Engine name (fivep5 or atlas): ").strip() or "fivep5"
    args.predictions = clean_path(input("Prediction CSV or folder path: "))
    args.sparc_zip = clean_path(input("SPARC V13.zip path: "))
    return args


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine-name", default=None)
    ap.add_argument("--predictions", default=None)
    ap.add_argument("--sparc-zip", default=None)
    args = prompt_if_missing(ap.parse_args())

    if not args.engine_name or not args.predictions or not args.sparc_zip:
        raise SystemExit("Missing inputs.")

    engine = args.engine_name.strip().replace(" ", "_")
    pred_path = Path(clean_path(args.predictions)).expanduser().resolve()
    sparc_zip = Path(clean_path(args.sparc_zip)).expanduser().resolve()

    pred_df = load_predictions(pred_path)
    pred_csv = find_prediction_csv(pred_path)
    target_source = load_target_and_source_from_zip(sparc_zip)
    table1 = parse_table1_from_zip(sparc_zip)
    merged, issues = merge_all(pred_df, target_source, table1)
    merged = fill_missing_source_fields(merged)

    grid_lam, grid_lam_m1 = find_grid_lambda_star(merged)
    merged["lambda_star_grid_control"] = vpred_from_lambda(merged, grid_lam)

    subgroups = build_subgroups(merged)
    subgroup_rows = []
    for name, sub in subgroups.items():
        cell = cell_score_and_help(merged, sub)
        perpoint_primary, valid_rows = m1_per_point(merged, "primary", sub)
        perpoint_control, _ = m1_per_point(merged, "lambda_star_grid_control", sub)
        subgroup_rows.append({
            "subgroup": name,
            "valid_rows": valid_rows,
            "galaxies_total_in_cell": int(merged.loc[sub, "Galaxy"].nunique()),
            "galaxies_compared": cell["galaxies_compared"],
            "cell_primary_mean_median_abs_dlog10V": cell["cell_primary_mean_median_abs_dlog10V"],
            "cell_lambdastar_mean_median_abs_dlog10V": cell["cell_control_mean_median_abs_dlog10V"],
            "cell_win_primary_lt_lambdastar": cell["cell_win_primary_lt_control"],
            "help_fraction": cell["help_fraction"],
            "galaxies_helped": cell["galaxies_helped"],
            "perpoint_primary_M1_log10V_RMS": perpoint_primary,
            "perpoint_lambdastar_M1_log10V_RMS": perpoint_control,
        })

    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path.cwd() / f"Modern_SFT_SPARC_06C_Canonical_Subgroups_{engine}_{timestamp}"
    out_dir.mkdir(parents=True, exist_ok=True)

    pd.DataFrame(subgroup_rows).to_csv(out_dir / "Modern_SFT_SPARC_06C_Canonical_Subgroup_Table.csv", index=False)
    merged.to_csv(out_dir / "Modern_SFT_SPARC_06C_Merged_With_Metadata.csv", index=False)

    primary_m1, n_primary = m1_per_point(merged, "primary")
    lambdastar_m1, _ = m1_per_point(merged, "lambda_star_grid_control")
    newton_m1, _ = m1_per_point(merged, "newtonian")
    disk_m1, _ = m1_per_point(merged, "disk")
    midpoint_m1, _ = m1_per_point(merged, "midpoint")

    sdf = pd.DataFrame(subgroup_rows)
    wins = sdf[sdf["cell_win_primary_lt_lambdastar"]]["subgroup"].tolist()
    s5_hi = sdf[sdf["subgroup"].str.contains("S5_P2prime_dwarf_hi")].iloc[0]
    s5_lo = sdf[sdf["subgroup"].str.contains("S5_P2prime_dwarf_lo")].iloc[0]
    s5_falsified = (not bool(s5_hi["cell_win_primary_lt_lambdastar"])) and (not bool(s5_lo["cell_win_primary_lt_lambdastar"]))

    technical_verdict = "PASS" if len(merged) == len(pred_df) == len(target_source) and not any("RADIUS_MISMATCH" in x for x in issues) else "FAIL"
    route_b = (primary_m1 <= 1.02 * lambdastar_m1) and len(wins) >= 1
    verdict = "PARTIAL_BY_ROUTE_B" if route_b else "NO_ROUTE_B"

    result = {
        "gate": "Modern SFT SPARC 06C — Canonical Subgroup Cross-Check",
        "engine": engine,
        "timestamp": timestamp,
        "prediction_csv": str(pred_csv),
        "prediction_csv_sha256": pred_df.attrs.get("prediction_csv_sha256"),
        "target_zip_sha256": sha256_file(sparc_zip),
        "technical_verdict": technical_verdict,
        "subgroup_verdict": verdict,
        "grid_lambda_star": grid_lam,
        "grid_lambda_star_M1": grid_lam_m1,
        "primary_M1": primary_m1,
        "newtonian_M1": newton_m1,
        "disk_M1": disk_m1,
        "midpoint_M1": midpoint_m1,
        "parity_ratio_primary_over_grid_lambdastar": primary_m1 / lambdastar_m1,
        "subgroup_wins": wins,
        "S5_P2prime_falsified": s5_falsified,
        "issues": issues,
    }
    (out_dir / "Modern_SFT_SPARC_06C_Result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    shutil.copy2(Path(__file__).resolve(), out_dir / Path(__file__).name)

    # Manifest and zip.
    manifest = []
    for p in sorted(out_dir.rglob("*")):
        if p.is_file() and p.name != "file_manifest.csv":
            manifest.append({
                "relative_path": str(p.relative_to(out_dir)),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    with (out_dir / "file_manifest.csv").open("w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=["relative_path", "size_bytes", "sha256"])
        wr.writeheader()
        wr.writerows(manifest)

    zip_path = Path.cwd() / f"{out_dir.name}.zip"
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)

    summary_lines = [
        "BEGIN_MODERN_SFT_SPARC_06C_SUBGROUP_SUMMARY",
        "gate=Modern SFT SPARC 06C — Canonical Subgroup Cross-Check",
        f"engine={engine}",
        f"timestamp={timestamp}",
        f"technical_verdict={technical_verdict}",
        f"subgroup_verdict={verdict}",
        f"prediction_rows={len(pred_df)}",
        f"merged_rows={len(merged)}",
        f"grid_lambda_star={grid_lam:.3f}",
        f"grid_lambda_star_M1={grid_lam_m1:.12g}",
        f"primary_M1={primary_m1:.12g}",
        f"disk_M1={disk_m1:.12g}",
        f"midpoint_M1={midpoint_m1:.12g}",
        f"newtonian_M1={newton_m1:.12g}",
        f"parity_ratio_primary_over_grid_lambdastar={primary_m1/lambdastar_m1:.12g}",
        f"subgroup_wins={','.join(wins) if wins else 'NONE'}",
        f"S5_P2prime_falsified={s5_falsified}",
        f"S5_hi_gas_help_fraction={float(s5_hi['help_fraction']):.12g}",
        f"S5_lo_gas_help_fraction={float(s5_lo['help_fraction']):.12g}",
        f"prediction_csv_sha256={pred_df.attrs.get('prediction_csv_sha256')}",
        f"target_zip_sha256={sha256_file(sparc_zip)}",
        f"runner_sha256={sha256_file(Path(__file__).resolve())}",
        f"results_zip={zip_path.name}",
        f"results_zip_sha256={zip_hash}",
        "END_MODERN_SFT_SPARC_06C_SUBGROUP_SUMMARY",
    ]
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SUBGROUP_SUMMARY.txt").write_text(summary_text, encoding="utf-8")

    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)
    summary_lines[-2] = f"results_zip_sha256={zip_hash}"
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SUBGROUP_SUMMARY.txt").write_text(summary_text, encoding="utf-8")
    zip_folder(out_dir, zip_path)

    print("\n" + summary_text)
    print(f"Saved subgroup folder: {out_dir}")
    print(f"Saved zipped subgroup pack: {zip_path}")
    return 0 if technical_verdict == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
