@echo off
echo Modern SFT SPARC 06C subgroup cross-check
python modern_sft_sparc_06c_canonical_subgroup_runner.py
pause
