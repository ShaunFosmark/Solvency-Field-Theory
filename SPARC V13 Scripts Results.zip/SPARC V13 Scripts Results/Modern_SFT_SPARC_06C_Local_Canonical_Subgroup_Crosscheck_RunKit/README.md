# Modern SFT SPARC 06C — Canonical Subgroup Cross-Check Run Kit

This runner works in IDLE/F5 and command line.

## IDLE/F5

Open:

```text
modern_sft_sparc_06c_canonical_subgroup_runner.py
```

Press F5.

For 5.5:

```text
engine = fivep5
prediction path = C:\Users\TaicHI\SPARC V13\Modern_SFT_SPARC_05_Local_Dual_Sealed_Source_Only_Prediction_RunKit\Modern_SFT_SPARC_05_Source_Only_Prediction_Seal_20260702_223950
SPARC zip = C:\Users\TaicHI\SPARC V13\Modern_SFT_SPARC_05_Local_Dual_Sealed_Source_Only_Prediction_RunKit\SPARC V13.zip
```

For Atlas:

```text
engine = atlas
prediction path = C:\Users\TaicHI\SPARC V13\Atlas_SPARC05_Sealed_Predictions_Pack_v2
SPARC zip = C:\Users\TaicHI\SPARC V13\Modern_SFT_SPARC_05_Local_Dual_Sealed_Source_Only_Prediction_RunKit\SPARC V13.zip
```

## Output

Copy back:

```text
BEGIN_MODERN_SFT_SPARC_06C_SUBGROUP_SUMMARY
...
END_MODERN_SFT_SPARC_06C_SUBGROUP_SUMMARY
```
