# Modern SFT SPARC 06C — Description for Fable/Atlas

## Gate name

```text
Modern SFT SPARC 06C — Canonical Subgroup Cross-Check
```

## Purpose

This is the final cell-for-cell witness for the 06 verdict.

The full-sample validation already converged. This gate scores the frozen predeclared subgroup cells using the exact cell statistic Atlas pinned:

```text
per-galaxy score = median |Δlog10 V| over that galaxy's scored rows
cell score = mean of per-galaxy scores
cell win = primary cell score < global lambda* cell score
```

## Table1 parsing warning

Table1 galaxy names are right-justified in an 11-character field.

Do **not** use a `^\S` line filter.

Use token parsing / split after whitespace handling.

## Metadata source

Membership must be source/shared-side only.

Use Table1 for:

```text
T
Q
```

Use sealed/source-side quantities for:

```text
median w_gas per galaxy
any Vbul > 0
```

## Frozen cells

### S1 morphology

```text
T ≤ 3
T = 4–7
T = 8–9
T ≥ 10
```

### S2 quality

```text
Q = 1
Q = 2
Q = 3
```

### S3 gas dominance

```text
galaxy-median w_gas > 0.5
galaxy-median w_gas ≤ 0.5
```

### S4 bulge

```text
any Vbul > 0
Vbul absent
```

### S5 / P2′ dwarf gas-share split

```text
T ≥ 10 and galaxy-median w_gas > 0.751189693950
T ≥ 10 and galaxy-median w_gas ≤ 0.751189693950
```

The threshold is frozen from 04B.

## Lambda-star definition reconciliation

Use the protocol-canonical grid value:

```text
lambda* grid search over [0.3, 2.5] with step 0.001
```

Expected:

```text
lambda* = 1.156
```

The continuous optimum near 1.15602776 may be reported as a note, but the canonical subgroup control is grid λ*.

## Verdict route

If cells confirm:

```text
PARTIAL_BY_ROUTE_B
```

requires:

```text
full-sample parity primary M1 ≤ 1.02 × λ* M1
and at least one predeclared subgroup win
```

Expected subgroup anatomy:

```text
wins:
T ≤ 3
T = 4–7
Q1
bulge-present

losses:
T = 8–9
T ≥ 10
Q2
Q3
gas-dominant
bulge-absent
S5 high-gas dwarfs
S5 low-gas dwarfs
```

S5/P2′ is falsified only if both S5 cells lose to λ*.

## Expected output block

```text
BEGIN_ATLAS_SPARC06C_SUBGROUP_SUMMARY
technical_verdict=<PASS/FAIL>
subgroup_verdict=<PARTIAL_BY_ROUTE_B or ...>
grid_lambda_star=1.156
primary_M1=<value>
grid_lambda_star_M1=<value>
parity_ratio_primary_over_grid_lambdastar=<value>
subgroup_wins=<comma-list>
S5_P2prime_falsified=<True/False>
S5_hi_gas_help_fraction=<value>
S5_lo_gas_help_fraction=<value>
prediction_csv_sha256=<sealed hash>
target_zip_sha256=<hash>
script_sha256=<hash>
results_zip_sha256=<hash>
END_ATLAS_SPARC06C_SUBGROUP_SUMMARY
```
