# Fork 08 — Operator Convention Freeze (G0-final, Atlas)

**Answers 5.5's three pre-signature items. Nothing here may change after F08-G2 synthetics begin.**

## 1. The f_perp trace — verdict: STRUCTURAL ANCESTOR, NOT IDENTITY (declared honestly)

Frozen R025 lines, verbatim (pack lines 180/186): `f_perp = <(J_spatial dot n)^2>/<|J_spatial|^2>` and `h_lock = h_planar(1 - f_perp)`.

Exact evaluation for a gas disk (ordered in-plane V, isotropic 1D turbulence σ per axis): f_perp = σ²/(V²+3σ²), so 1 − f_perp = (V²+2σ²)/(V²+3σ²). The proposed participation p = V²/(V²+3σ²) is the **ordered-to-total kinetic-energy ratio** — same currency (squared speeds, per 5.5's energy argument), same structural role (current-coherence gating a coefficient), **different projection**: f_perp gates the normal direction only; participation gates against total turbulent energy. Classification in the traceability register: rows 8/9 = structural ancestor; the participation operator = **new operator, F08-native**, with its geometry-derived convention below. The false identity is withdrawn; the honest lineage is recorded.

## 2. V_src — FROZEN (5.5's form, accepted verbatim)

V_src²(r) = max(V_bar_signed²(r), 0), with V_bar_signed² = Υ_d V_disk² + Υ_b V_bul² + V_gas|V_gas| — the identical source-only ledger (traceability row 13), evaluated locally per radius (row 14 discipline). Rows with V_bar_signed² ≤ 0 are already flagged/excluded by the frozen 05/06 rules; p_gas is undefined-and-irrelevant there.

## 3. σ_gas and the η convention — FROZEN, η from geometry, not a knob

σ_gas,1D = 10 ± 2 km/s, line-of-sight HI dispersion (Leroy et al. 2008; Tamburro et al. 2009 — traceability row 16, already frozen). The support ratio requires total turbulent energy; for isotropic turbulence σ_3D² = 3σ_1D² — **η = 3 by isotropy, a geometric fact, not a tunable**. Primary operator:

**p_gas(r) = V_src²(r) / (V_src²(r) + 3σ_1D²);  p_star = p_bulge = 1 (collisionless);  λ_eff(r) = Σ_j w_j(r) p_j(r) λ_j.**

Declared lanes for G2/G4: **Lane η3 (primary)** as above; **Lane η1 (variant)** p = V²/(V²+σ_1D²), reported alongside; **parcel-clock lane (control)** p = 1−exp(−τ_coh/τ_rec) with cited scales, carried explicitly because its predicted self-kill (p ≈ 0.05, near-Newtonian dwarfs) is itself a test of the coherence picture. Anisotropic-turbulence sensitivity: η ∈ [2, 3] band noted for the systematics section only.

## 4. Declared expectations (registered before any target contact)

Under Lane η3: spiral gas p ≥ 0.95 (four frozen-model subgroup wins preserved; U-profile damage removed); gas-rich dwarfs p ≈ 0.43–0.75 → pure-gas λ_eff ≈ 0.57–1.00, below λ* = 1.156 — the direction and neighborhood the sealed falsification demanded, reached from frozen constants with the quarantined old fits untouched. If G4 lands there, it is a result; the calibration firewall held throughout.

## 5. F08-G2 synthetic battery (5.5's additions folded in)

(a) Limit recovery: V ≫ σ reproduces the frozen 06C model to 10⁻⁶ at every radius. (b) V → 0 → Newtonian, emergent. (c) Monotonicity of λ_eff in V/σ. (d) **M/L sensitivity of p**: Υ_d ∈ {0.4, 0.5, 0.6} propagated through V_src; dwarf λ_eff shift quantified and declared. (e) η3-vs-η1 lane comparison on identical synthetics. (f) Parcel-clock control lane demonstrated self-killing on literature scales. (g) Frame-independence spot check (bulk-boost invariance of p under the comoving-basin rule). (h) Flag-row behavior. Dual-engine, shared deck, hashes first — the proven ladder, unchanged.

*Status requested: G0_STATUS → SIGNED. Three signatures unlock the deck.*
