"""Atlas shadow — Modern SFT SPARC 04B Gas-Lane Fork Decision. Exact spec from 5.5's kit description."""
import numpy as np, json, hashlib, sys
LAM_S, LAM_D = 4.0/3.0, 3*np.pi/8
h_star   = 1.0 - 1.0/7.3
lam_star = LAM_S - (LAM_S - LAM_D)*h_star
lam_gas  = LAM_S
THRESH   = 1.30
f_gas_min = (THRESH - lam_star)/(LAM_S - lam_star)
fg = np.round(np.linspace(0,1,21), 3)
lam_eff = fg*lam_gas + (1-fg)*lam_star
i_cross = int(np.argmax(lam_eff >= THRESH))
tests = [
 dict(test='T1_lambda_star', value=float(round(lam_star,9)), expect='4/3 - dL*(1-1/7.3)', ok=bool(abs(lam_star-1.199362)<1e-5)),
 dict(test='T2_f_gas_min', value=float(round(f_gas_min,9)), expect='(1.30-lam_star)/(4/3-lam_star)', ok=bool(0.74<f_gas_min<0.76)),
 dict(test='T3_endpoints', value=[float(round(lam_eff[0],6)), float(round(lam_eff[-1],6))], expect='[lam_star, 4/3]', ok=bool(abs(lam_eff[0]-lam_star)<1e-12 and abs(lam_eff[-1]-LAM_S)<1e-12)),
 dict(test='T4_monotone', value=float(round(float(np.min(np.diff(lam_eff))),9)), expect='>0', ok=bool(np.all(np.diff(lam_eff)>0))),
 dict(test='T5_threshold_crossing', value=float(fg[i_cross]), expect=f'first fg >= {f_gas_min:.4f}', ok=bool(fg[i_cross]-0.05 < f_gas_min <= fg[i_cross])),
]
ok_all = all(t['ok'] for t in tests)
out = dict(gate='Modern_SFT_SPARC_04B_shadow', engine='Atlas',
           verdict=('PASS' if ok_all else 'FAIL'),
           decision='PRIMARY_DWARF_HIGH_LAMBDA_CONDITIONAL_ON_GAS_SHARE',
           lambda_star=float(round(lam_star,12)), lambda_gas=float(lam_gas),
           f_gas_min=float(round(f_gas_min,12)), threshold=THRESH,
           n_tests=len(tests), n_pass=int(sum(t['ok'] for t in tests)), tests=tests)
js = json.dumps(out, sort_keys=True, indent=1)
open('atlas_04b_results.json','w').write(js)
hs = hashlib.sha256(open(sys.argv[0],'rb').read()).hexdigest()
hr = hashlib.sha256(js.encode()).hexdigest()
print('BEGIN_ATLAS_SPARC04B_SHADOW_SUMMARY')
print('verdict:', out['verdict'], '| decision:', out['decision'])
print(f'lambda_star = {lam_star:.9f}')
print(f'lambda_gas  = {lam_gas:.9f}   (primary lane: h_gas = 0)')
print(f'f_gas_min   = {f_gas_min:.9f}   -> lambda >= 1.30 requires gas source share > {100*f_gas_min:.2f}%')
for t in tests: print(f"  {'PASS' if t['ok'] else 'FAIL'}  {t['test']:24s} val={t['value']}")
print('script_sha256:', hs); print('results_sha256:', hr)
print('END_ATLAS_SPARC04B_SHADOW_SUMMARY')
