#!/usr/bin/env python3


from __future__ import annotations
import argparse
import csv
import datetime as dt
import hashlib
import json
import math
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

# -----------------------------
# Frozen constants
# -----------------------------
C_M_S = 299_792_458.0
MPC_M = 3.0856775814913673e22
KPC_M = 3.0856775814913673e19
H0_KM_S_MPC = 67.74
H0_SI = H0_KM_S_MPC * 1000.0 / MPC_M
A_S_M_S2 = C_M_S * H0_SI / (2.0 * math.pi)

LAMBDA_SPHERE = 4.0 / 3.0
LAMBDA_DISK = 3.0 * math.pi / 8.0
LAMBDA_MIDPOINT = 0.5 * (LAMBDA_SPHERE + LAMBDA_DISK)
DELTA_LAMBDA = LAMBDA_SPHERE - LAMBDA_DISK

UPSILON_DISK = 0.5
UPSILON_BULGE = 0.7
RD_OVER_HZ_MID = 7.3

SOURCE_REQUIRED = [
    "Galaxy",
    "R_kpc",
    "Vgas_kms",
    "Vdisk_kms",
    "Vbul_kms",
    "SBdisk_Lsun_pc2",
    "SBbul_Lsun_pc2",
]

FORBIDDEN_COLS = {
    "Vobs", "eVobs", "errV", "Vflat", "e_Vflat", "gobs", "g_obs", "RAR_All_Data",
    "residual", "residuals", "chi2", "chisq", "best_lambda", "lambda_best", "lambda_fit",
    "V_obs", "e_Vobs"
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def clip(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def safe_float(x: Any) -> float:
    if x is None:
        return float("nan")
    s = str(x).strip()
    if not s:
        return float("nan")
    return float(s)


def fmt(x: float, nd: int = 12) -> str:
    if x is None or not math.isfinite(x):
        return ""
    return f"{x:.{nd}g}"


def lambda_from_hlock(h_lock: float) -> float:
    h = clip(h_lock)
    return LAMBDA_SPHERE - DELTA_LAMBDA * h


def h_star_mid() -> float:
    return clip(1.0 - 1.0 / RD_OVER_HZ_MID)


def lambda_star_mid() -> float:
    return lambda_from_hlock(h_star_mid())


def source_terms(vgas: float, vdisk: float, vbul: float) -> Dict[str, float]:
    return {
        "star": UPSILON_DISK * vdisk * vdisk,
        "bulge": UPSILON_BULGE * vbul * vbul,
        "gas": abs(vgas) * abs(vgas),
    }


def source_weights(vgas: float, vdisk: float, vbul: float) -> Dict[str, float]:
    s = source_terms(vgas, vdisk, vbul)
    total = s["star"] + s["bulge"] + s["gas"]
    if total <= 0:
        return {"star": 0.0, "bulge": 0.0, "gas": 0.0}
    return {k: v / total for k, v in s.items()}


def vbar_signed_sq_km2s2(vgas: float, vdisk: float, vbul: float) -> float:
    return UPSILON_DISK * vdisk * vdisk + UPSILON_BULGE * vbul * vbul + vgas * abs(vgas)


def vbar_abs_kms(vgas: float, vdisk: float, vbul: float) -> float:
    s = source_terms(vgas, vdisk, vbul)
    return math.sqrt(max(s["star"] + s["bulge"] + s["gas"], 0.0))


def lambda_eff_primary(vgas: float, vdisk: float, vbul: float) -> Tuple[float, Dict[str, float]]:
    w = source_weights(vgas, vdisk, vbul)
    lam_star = lambda_star_mid()
    lam_bul = LAMBDA_SPHERE
    lam_gas = LAMBDA_SPHERE  # primary puffy/unlocked gas lane
    lam_eff = w["star"] * lam_star + w["bulge"] * lam_bul + w["gas"] * lam_gas
    return lam_eff, w


def predict_v_kms_from_lambda(r_kpc: float, vbar_signed_sq: float, lam: float) -> Tuple[float, float, str]:
    """
    Returns (gbar_m_s2, vpred_kms, flag).
    If radius or signed gbar invalid, returns nan prediction with flag.
    """
    if not math.isfinite(r_kpc) or r_kpc <= 0:
        return float("nan"), float("nan"), "BAD_RADIUS"
    if not math.isfinite(vbar_signed_sq):
        return float("nan"), float("nan"), "BAD_VBAR"
    gbar = vbar_signed_sq * 1.0e6 / (r_kpc * KPC_M)
    if gbar <= 0:
        return gbar, float("nan"), "NONPOSITIVE_GBAR"
    g_sft_sq = gbar * gbar + lam * A_S_M_S2 * gbar
    if g_sft_sq < 0:
        return gbar, float("nan"), "NEGATIVE_GSFTSQ"
    g_sft = math.sqrt(g_sft_sq)
    v2_m2s2 = g_sft * r_kpc * KPC_M
    if v2_m2s2 < 0:
        return gbar, float("nan"), "NEGATIVE_V2"
    return gbar, math.sqrt(v2_m2s2) / 1000.0, "OK"


def newton_v_kms(vbar_signed_sq: float) -> float:
    if vbar_signed_sq < 0 or not math.isfinite(vbar_signed_sq):
        return float("nan")
    return math.sqrt(vbar_signed_sq)


def find_source_dir(start: Path) -> Optional[Path]:
    candidates = []
    names = {
        "Modern_SFT_SPARC_02_SOURCE_ONLY",
        "SOURCE_ONLY",
        "Modern_SFT_SPARC_05_PREPARED_SOURCE_ONLY",
    }
    for p in [start, *start.parents]:
        for name in names:
            c = p / name
            if c.exists() and c.is_dir():
                candidates.append(c)
        # one-level recursive scan, to avoid walking entire disks
        for c in p.glob("*/Modern_SFT_SPARC_02_SOURCE_ONLY"):
            if c.is_dir():
                candidates.append(c)
        for c in p.glob("*/Modern_SFT_SPARC_05_PREPARED_SOURCE_ONLY"):
            if c.is_dir():
                candidates.append(c)
    return candidates[0] if candidates else None


def iter_source_csvs(source_dir: Path) -> List[Path]:
    files = sorted(source_dir.rglob("*_source.csv"))
    if not files:
        files = sorted(source_dir.rglob("*.csv"))
    return files


def classify_population(path: Path) -> str:
    parts = [p.lower() for p in path.parts]
    if any(p == "ltg" for p in parts):
        return "LTG"
    if any(p == "etg" for p in parts):
        return "ETG"
    return "UNKNOWN"


def read_source_rows(source_dir: Path) -> Tuple[List[Dict[str, Any]], List[str]]:
    rows: List[Dict[str, Any]] = []
    issues: List[str] = []
    files = iter_source_csvs(source_dir)
    if not files:
        raise SystemExit(f"No source CSV files found under: {source_dir}")

    for path in files:
        with path.open("r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            header = reader.fieldnames or []
            bad = sorted(set(header) & FORBIDDEN_COLS)
            if bad:
                raise SystemExit(f"FORBIDDEN TARGET-LIKE COLUMNS in {path}: {bad}")
            missing = [c for c in SOURCE_REQUIRED if c not in header]
            if missing:
                issues.append(f"SKIP {path}: missing {missing}")
                continue
            pop = classify_population(path)
            for i, r in enumerate(reader, start=2):
                try:
                    row = {
                        "Galaxy": str(r["Galaxy"]).strip(),
                        "population": pop,
                        "R_kpc": safe_float(r["R_kpc"]),
                        "Vgas_kms": safe_float(r["Vgas_kms"]),
                        "Vdisk_kms": safe_float(r["Vdisk_kms"]),
                        "Vbul_kms": safe_float(r["Vbul_kms"]),
                        "SBdisk_Lsun_pc2": safe_float(r["SBdisk_Lsun_pc2"]),
                        "SBbul_Lsun_pc2": safe_float(r["SBbul_Lsun_pc2"]),
                        "source_file": str(path.relative_to(source_dir)),
                        "source_line": i,
                    }
                    rows.append(row)
                except Exception as e:
                    issues.append(f"BAD_ROW {path}:{i}: {e}")
    return rows, issues


def make_predictions(source_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    lam_star = lambda_star_mid()
    for r in source_rows:
        vg, vd, vb = r["Vgas_kms"], r["Vdisk_kms"], r["Vbul_kms"]
        rr = r["R_kpc"]
        s = source_terms(vg, vd, vb)
        w = source_weights(vg, vd, vb)
        lam_eff, _ = lambda_eff_primary(vg, vd, vb)
        vbar_signed = vbar_signed_sq_km2s2(vg, vd, vb)
        vbar_abs = vbar_abs_kms(vg, vd, vb)

        gbar, vprim, flag = predict_v_kms_from_lambda(rr, vbar_signed, lam_eff)
        _, v_lam1, flag1 = predict_v_kms_from_lambda(rr, vbar_signed, 1.0)
        _, v_sph, flags = predict_v_kms_from_lambda(rr, vbar_signed, LAMBDA_SPHERE)
        _, v_disk, flagd = predict_v_kms_from_lambda(rr, vbar_signed, LAMBDA_DISK)
        _, v_mid, flagm = predict_v_kms_from_lambda(rr, vbar_signed, LAMBDA_MIDPOINT)

        flags_all = sorted(set(f for f in [flag, flag1, flags, flagd, flagm] if f != "OK"))
        out.append({
            "Galaxy": r["Galaxy"],
            "population": r["population"],
            "R_kpc": fmt(rr),
            "Vgas_kms": fmt(vg),
            "Vdisk_kms": fmt(vd),
            "Vbul_kms": fmt(vb),
            "SBdisk_Lsun_pc2": fmt(r["SBdisk_Lsun_pc2"]),
            "SBbul_Lsun_pc2": fmt(r["SBbul_Lsun_pc2"]),
            "S_star": fmt(s["star"]),
            "S_bulge": fmt(s["bulge"]),
            "S_gas": fmt(s["gas"]),
            "w_star": fmt(w["star"]),
            "w_bulge": fmt(w["bulge"]),
            "w_gas": fmt(w["gas"]),
            "lambda_star_mid": fmt(lam_star),
            "lambda_bulge": fmt(LAMBDA_SPHERE),
            "lambda_gas_primary": fmt(LAMBDA_SPHERE),
            "lambda_eff_primary": fmt(lam_eff),
            "Vbar_signed_sq_km2s2": fmt(vbar_signed),
            "Vbar_abs_kms": fmt(vbar_abs),
            "gbar_m_s2": fmt(gbar),
            "a_S_m_s2": fmt(A_S_M_S2),
            "Vpred_primary_kms": fmt(vprim),
            "Vpred_lambda_1_kms": fmt(v_lam1),
            "Vpred_lambda_sphere_kms": fmt(v_sph),
            "Vpred_lambda_disk_kms": fmt(v_disk),
            "Vpred_lambda_midpoint_kms": fmt(v_mid),
            "Vnewton_kms": fmt(newton_v_kms(vbar_signed)),
            "prediction_flag": ";".join(flags_all) if flags_all else "OK",
            "source_file": r["source_file"],
            "source_line": r["source_line"],
        })
    return out


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        raise SystemExit(f"No rows to write: {path}")
    with path.open("w", encoding="utf-8", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)


def write_galaxy_summary(path: Path, predictions: List[Dict[str, Any]]) -> None:
    by_gal: Dict[str, List[Dict[str, Any]]] = {}
    for r in predictions:
        by_gal.setdefault(r["Galaxy"], []).append(r)

    rows = []
    for gal, rs in sorted(by_gal.items()):
        lambdas = [float(r["lambda_eff_primary"]) for r in rs if r["lambda_eff_primary"]]
        wg = [float(r["w_gas"]) for r in rs if r["w_gas"]]
        flags = sorted(set(r["prediction_flag"] for r in rs if r["prediction_flag"] != "OK"))
        rows.append({
            "Galaxy": gal,
            "population": rs[0]["population"],
            "n_rows": len(rs),
            "lambda_eff_min": fmt(min(lambdas) if lambdas else float("nan")),
            "lambda_eff_max": fmt(max(lambdas) if lambdas else float("nan")),
            "w_gas_mean": fmt(sum(wg)/len(wg) if wg else float("nan")),
            "flag_count": sum(1 for r in rs if r["prediction_flag"] != "OK"),
            "flags": ";".join(flags) if flags else "OK",
        })
    write_csv(path, rows)


def zip_folder(folder: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(folder)))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-dir", default=None, help="Path to SOURCE_ONLY directory from Modern SFT SPARC 02.")
    ap.add_argument("--allow-etg", action="store_true", help="Include ETG if present. Default keeps all source CSVs but reports population.")
    args = ap.parse_args()

    script_path = Path(__file__).resolve()
    cwd = Path.cwd()

    if args.source_dir:
        source_dir = Path(args.source_dir).expanduser().resolve()
    else:
        found = find_source_dir(cwd)
        if found is None:
            raise SystemExit(
                "Could not find SOURCE_ONLY directory automatically. "
                "Run with --source-dir PATH_TO_Modern_SFT_SPARC_02_SOURCE_ONLY"
            )
        source_dir = found.resolve()

    if not source_dir.exists():
        raise SystemExit(f"Source dir does not exist: {source_dir}")

    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = cwd / f"Modern_SFT_SPARC_05_Source_Only_Prediction_Seal_{timestamp}"
    out_dir.mkdir(parents=True, exist_ok=True)

    source_rows, issues = read_source_rows(source_dir)
    predictions = make_predictions(source_rows)

    pred_csv = out_dir / "Modern_SFT_SPARC_05_Source_Only_Predictions.csv"
    gal_csv = out_dir / "Modern_SFT_SPARC_05_Galaxy_Source_Summary.csv"
    issues_csv = out_dir / "Modern_SFT_SPARC_05_Source_Issues.csv"

    write_csv(pred_csv, predictions)
    write_galaxy_summary(gal_csv, predictions)
    with issues_csv.open("w", encoding="utf-8", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["issue"])
        for issue in issues:
            wr.writerow([issue])

    config = {
        "gate": "Modern SFT SPARC 05 — Dual-Sealed Source-Only Predictions",
        "timestamp": timestamp,
        "source_dir": str(source_dir),
        "data_access": "SOURCE_ONLY directory only; no target validation opened",
        "forbidden_inputs": sorted(FORBIDDEN_COLS),
        "constants": {
            "c_m_s": C_M_S,
            "H0_km_s_Mpc": H0_KM_S_MPC,
            "a_S_m_s2": A_S_M_S2,
            "lambda_sphere": LAMBDA_SPHERE,
            "lambda_disk": LAMBDA_DISK,
            "lambda_midpoint": LAMBDA_MIDPOINT,
            "upsilon_disk": UPSILON_DISK,
            "upsilon_bulge": UPSILON_BULGE,
            "R_d_over_h_z_mid": RD_OVER_HZ_MID,
            "lambda_star_mid": lambda_star_mid(),
            "lambda_gas_primary": LAMBDA_SPHERE,
        },
        "prediction_columns": list(predictions[0].keys()) if predictions else [],
        "notes": [
            "Primary model only.",
            "No gas-geometry/hydro fork included.",
            "Best global lambda* not computed here because it requires target data.",
            "Share summary/hash block before exchanging prediction CSV values."
        ],
    }
    (out_dir / "Modern_SFT_SPARC_05_Config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    shutil.copy2(script_path, out_dir / script_path.name)

    # Manifest before zip
    manifest_rows = []
    for p in sorted(out_dir.rglob("*")):
        if p.is_file() and p.name != "file_manifest.csv":
            manifest_rows.append({
                "relative_path": str(p.relative_to(out_dir)),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    with (out_dir / "file_manifest.csv").open("w", encoding="utf-8", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=["relative_path", "size_bytes", "sha256"])
        wr.writeheader()
        wr.writerows(manifest_rows)

    zip_path = cwd / f"{out_dir.name}.zip"
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)

    galaxies = sorted(set(r["Galaxy"] for r in predictions))
    flagged = sum(1 for r in predictions if r["prediction_flag"] != "OK")
    ok_rows = sum(1 for r in predictions if r["prediction_flag"] == "OK")

    verdict = "PASS" if predictions and ok_rows > 0 else "FAIL"
    summary_lines = [
        "BEGIN_MODERN_SFT_SPARC_05_LOCAL_PREDICTION_SEAL",
        "gate=Modern SFT SPARC 05 — Dual-Sealed Source-Only Predictions",
        f"timestamp={timestamp}",
        f"verdict={verdict}",
        f"source_dir={source_dir}",
        f"galaxies={len(galaxies)}",
        f"source_rows={len(source_rows)}",
        f"prediction_rows={len(predictions)}",
        f"prediction_rows_ok={ok_rows}",
        f"prediction_rows_flagged={flagged}",
        f"issues_count={len(issues)}",
        f"lambda_star_mid={lambda_star_mid():.12f}",
        f"lambda_sphere={LAMBDA_SPHERE:.12f}",
        f"lambda_disk={LAMBDA_DISK:.12f}",
        f"a_S_m_s2={A_S_M_S2:.12e}",
        f"predictions_csv_sha256={sha256_file(pred_csv)}",
        f"galaxy_summary_sha256={sha256_file(gal_csv)}",
        f"runner_sha256={sha256_file(script_path)}",
        f"results_zip={zip_path.name}",
        f"results_zip_sha256={zip_hash}",
        "decision=SEALED_SOURCE_ONLY_PREDICTIONS_READY_FOR_HASH_EXCHANGE",
        "END_MODERN_SFT_SPARC_05_LOCAL_PREDICTION_SEAL",
    ]

    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SEAL_SUMMARY.txt").write_text(summary_text, encoding="utf-8")

    # Rezip with summary, update hash once more
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)
    summary_lines[-3] = f"results_zip_sha256={zip_hash}"
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SEAL_SUMMARY.txt").write_text(summary_text, encoding="utf-8")
    zip_folder(out_dir, zip_path)

    print("\n" + summary_text)
    print("IMPORTANT: share only the seal summary first. Do not exchange prediction CSV values until both engines have sealed.")
    print(f"Saved local results folder: {out_dir}")
    print(f"Saved zipped results pack: {zip_path}")
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
