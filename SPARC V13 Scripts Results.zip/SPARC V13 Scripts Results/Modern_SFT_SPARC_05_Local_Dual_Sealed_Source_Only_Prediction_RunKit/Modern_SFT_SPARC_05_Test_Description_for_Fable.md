# Modern SFT SPARC 05 — Description for Fable/Atlas

## Gate name

```text
Modern SFT SPARC 05 — Dual-Sealed Source-Only Predictions
```

## Purpose

Generate source-only predictions from the frozen Modern SFT SPARC 03/04B primary model, then seal the prediction file by hash before any target validation is opened.

This is not a validation gate.

This is not an interpretation gate.

This is a two-engine source-only prediction seal.

## Dual-engine rule

5.5 and Atlas/Fable independently implement the same frozen prediction model.

Before exchanging prediction values, each engine reports only:

```text
script hash
input/source manifest hash or source row counts
prediction CSV hash
galaxy count
row count
flag count
results zip hash
```

Only after both summaries are frozen may Shaun allow value exchange.

## Allowed input

SOURCE_ONLY files only, with schema:

```text
Galaxy
R_kpc
Vgas_kms
Vdisk_kms
Vbul_kms
SBdisk_Lsun_pc2
SBbul_Lsun_pc2
```

Shared infrastructure may be used only if explicitly declared, but the 5.5 primary runner does not require Table1.

## Forbidden input

```text
Vobs
eVobs
errV
Vflat
RAR_All_Data
gobs
residuals
chi2
best lambda
old Track outputs
target-derived cuts
```

## Frozen constants

```text
c = 299792458 m/s
H0 = 67.74 km/s/Mpc
a_S = c H0 / (2*pi)
lambda_sphere = 4/3
lambda_disk = 3*pi/8
lambda_midpoint = (lambda_sphere + lambda_disk)/2
Upsilon_disk = 0.5
Upsilon_bulge = 0.7
R_d/h_z = 7.3
```

Derived:

```text
h_star = 1 - 1/7.3
lambda_star = lambda_sphere - (lambda_sphere - lambda_disk)*h_star
lambda_bulge = 4/3
lambda_gas_primary = 4/3
```

## Prediction model

Signed acceleration ledger:

```text
Vbar_signed_sq = Upsilon_disk*Vdisk^2 + Upsilon_bulge*Vbul^2 + Vgas*abs(Vgas)
```

Nonnegative source-weight ledger:

```text
S_star = Upsilon_disk*Vdisk^2
S_bulge = Upsilon_bulge*Vbul^2
S_gas = abs(Vgas)^2
w_j = S_j / (S_star + S_bulge + S_gas)
```

Primary lambda:

```text
lambda_eff_primary =
    w_star*lambda_star +
    w_bulge*lambda_bulge +
    w_gas*lambda_gas_primary
```

Acceleration conversion:

```text
gbar = Vbar_signed_sq * 1e6 / (R_kpc * kpc_m)
```

Prediction law:

```text
gSFT = sqrt(gbar^2 + lambda_eff_primary*a_S*gbar)
Vpred_primary = sqrt(gSFT * R_kpc * kpc_m) / 1000
```

If:

```text
R_kpc <= 0
or gbar <= 0
```

then prediction is flagged and not used as a valid prediction row. It remains in the sealed file with a flag.

## Source-only controls also generated

Generate the same prediction law for fixed lambdas:

```text
lambda = 1
lambda = 4/3
lambda = 3*pi/8
lambda = midpoint
Newtonian: Vnewton = sqrt(Vbar_signed_sq), if Vbar_signed_sq >= 0
```

Do **not** compute best global lambda*. That requires target data and belongs to validation.

## Expected seal summary

Atlas/Fable should output a block similar to:

```text
BEGIN_ATLAS_SPARC05_PREDICTION_SEAL
verdict: PASS
galaxies: <N>
source_rows: <N>
prediction_rows: <N>
prediction_rows_flagged: <N>
lambda_star: <value>
a_S: <value>
script_sha256: <hash>
predictions_sha256: <hash>
results_sha256: <hash>
decision: SEALED_SOURCE_ONLY_PREDICTIONS_READY_FOR_HASH_EXCHANGE
END_ATLAS_SPARC05_PREDICTION_SEAL
```

## Expected comparison

The two engines should agree on:

```text
galaxy count
source row count
prediction row count
lambda_star
a_S
flag count or named flagged rows
prediction values after value exchange
```

But in the first pass, only hashes and counts are exchanged.
