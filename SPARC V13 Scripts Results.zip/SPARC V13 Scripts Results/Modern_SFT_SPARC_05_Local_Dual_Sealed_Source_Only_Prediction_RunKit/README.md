# Modern SFT SPARC 05 — Local Dual-Sealed Source-Only Prediction Run Kit

This kit generates the local source-only prediction seal.

## Strict run

Use the SOURCE_ONLY folder from Modern SFT SPARC 02:

```bash
python modern_sft_sparc_05_source_only_prediction_runner.py --source-dir PATH_TO_Modern_SFT_SPARC_02_SOURCE_ONLY
```

Windows example:

```bash
py modern_sft_sparc_05_source_only_prediction_runner.py --source-dir "C:\Users\TaicHI\SPARC V13\Modern_SFT_SPARC_02_SOURCE_ONLY"
```

## If you do not have a SOURCE_ONLY folder

Run the helper first from the folder containing `SPARC V13.zip`:

```bash
py modern_sft_sparc_05_prepare_source_only_from_sparc_v13_zip.py --zip "SPARC V13.zip"
```

Then:

```bash
py modern_sft_sparc_05_source_only_prediction_runner.py --source-dir Modern_SFT_SPARC_05_PREPARED_SOURCE_ONLY
```

## Output

The runner prints:

```text
BEGIN_MODERN_SFT_SPARC_05_LOCAL_PREDICTION_SEAL
...
END_MODERN_SFT_SPARC_05_LOCAL_PREDICTION_SEAL
```

Share only that seal block first.

Do not exchange prediction CSV values until Fable/Atlas has also sealed his hash.
