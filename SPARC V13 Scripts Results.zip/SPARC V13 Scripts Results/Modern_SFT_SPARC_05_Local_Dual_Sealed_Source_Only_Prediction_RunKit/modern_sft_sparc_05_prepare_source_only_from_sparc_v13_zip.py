#!/usr/bin/env python3
"""
Modern SFT SPARC 05 helper — Prepare SOURCE_ONLY from SPARC V13.zip

Use this ONLY if you do not already have the Modern SFT SPARC 02 SOURCE_ONLY folder.

This helper reads SPARC V13.zip and writes only source-side columns:
  Galaxy,R_kpc,Vgas_kms,Vdisk_kms,Vbul_kms,SBdisk_Lsun_pc2,SBbul_Lsun_pc2

It does not write Vobs/eVobs.
The prediction runner should then be pointed to the generated folder:

  python modern_sft_sparc_05_source_only_prediction_runner.py --source-dir Modern_SFT_SPARC_05_PREPARED_SOURCE_ONLY
"""
from __future__ import annotations
import argparse
import csv
import zipfile
from pathlib import Path

def parse_rotmod(text):
    rows = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 8:
            try:
                vals = [float(x) for x in parts[:8]]
                rows.append(vals)
            except ValueError:
                pass
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", default="SPARC V13.zip", help="Path to SPARC V13.zip")
    ap.add_argument("--out", default="Modern_SFT_SPARC_05_PREPARED_SOURCE_ONLY")
    args = ap.parse_args()

    zpath = Path(args.zip)
    if not zpath.exists():
        raise SystemExit(f"Missing zip: {zpath}")

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    n_files = 0
    n_rows = 0

    with zipfile.ZipFile(zpath, "r") as z:
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            low = name.lower()
            if not (low.endswith("_rotmod.dat") and "rotmod_ltg/" in low):
                continue
            galaxy = Path(name).name.replace("_rotmod.dat", "")
            rows = parse_rotmod(z.read(info).decode("utf-8", errors="replace"))
            if not rows:
                continue
            dst = out / "LTG" / f"{galaxy}_source.csv"
            dst.parent.mkdir(parents=True, exist_ok=True)
            with dst.open("w", newline="", encoding="utf-8") as f:
                wr = csv.writer(f)
                wr.writerow(["Galaxy","R_kpc","Vgas_kms","Vdisk_kms","Vbul_kms","SBdisk_Lsun_pc2","SBbul_Lsun_pc2"])
                for vals in rows:
                    Rad, Vobs, errV, Vgas, Vdisk, Vbul, SBdisk, SBbul = vals[:8]
                    wr.writerow([galaxy, Rad, Vgas, Vdisk, Vbul, SBdisk, SBbul])
            n_files += 1
            n_rows += len(rows)

    print("BEGIN_MODERN_SFT_SPARC_05_SOURCE_PREP_SUMMARY")
    print(f"source_zip={zpath}")
    print(f"out_dir={out.resolve()}")
    print(f"source_files={n_files}")
    print(f"source_rows={n_rows}")
    print("target_columns_written=NO")
    print("END_MODERN_SFT_SPARC_05_SOURCE_PREP_SUMMARY")

if __name__ == "__main__":
    main()
