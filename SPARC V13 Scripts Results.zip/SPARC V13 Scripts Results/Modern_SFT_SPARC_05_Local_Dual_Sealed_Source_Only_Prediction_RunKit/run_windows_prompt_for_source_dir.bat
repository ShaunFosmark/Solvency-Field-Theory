@echo off
echo Modern SFT SPARC 05 source-only prediction seal
echo.
echo If you have a source-only folder, drag it into this window when asked or paste the path.
set /p SRCDIR=Enter SOURCE_ONLY folder path: 
python modern_sft_sparc_05_source_only_prediction_runner.py --source-dir "%SRCDIR%"
pause
