# Modern SFT SPARC — G7 Verdict Record

**Tri-signed: Shaun Fosmark (referee/airlock), ChatGPT 5.5 (canonical engine), Claude/Atlas (shadow engine). July 2026.**
**Chain of custody: Gate 05 dual seals (predictions: 175 galaxies, 3,391 rows, 2 flags, value-converged at ≤5×10⁻⁷); Gate 06B dual validation (M1 converged to 10 digits); Gate 06 subgroup runs (canonical + shadow, cell-converged). All packs and hashes held locally by the referee.**

---

## VERDICT: PARTIAL — Route B (frozen §6 criteria)

- **Not PASS:** model M1 = 0.0990925 vs λ* M1 = 0.0986469 (λ* = 1.156, grid-canonical); help vs λ* < 50%.
- **Route A failed:** two fixed controls (λ = 3π/8 and midpoint) beat the model full-sample.
- **Route B satisfied:** full-sample parity 1.0045 ≤ 1.02 (pinned pre-unsealing), AND the model beats the target-fitted λ* in four predeclared cells: T ≤ 3 (help 0.536), T 4–7 (help 0.621), Q1 (help 0.616), bulge-present (help 0.594).

## Registered predictions — outcomes
- **P2′ (dwarf gas-share bimodality, 04B threshold 0.7512): FALSIFIED.** Both S5 cells lose to λ* (help 0.273 / 0.212). The h_gas = 0 primary lane overshoots for gas-rich late systems.
- **P1′ (U-profile in gas-rich outskirts):** not directly scored; S3 gas-dominated loss is consistent with the outer rise hurting. Status: unfavorable, unresolved.
- **a_S = cH₀/(2π):** confirmed massively — Newtonian M1 0.2653 → 0.0991, per-galaxy help 0.91. The solvency acceleration scale is the retest's strongest survivor.

## What was learned (the mirror-image result)
The old Track-1 readout found morphology signal in dwarfs and none in spirals. The sealed forward model wins in spirals and fails in dwarfs. Both methods heard real physics through different distortions, and the sealed protocol adjudicates: **the in-spiral radial morphology structure is real** (erased before by the fitted-λ nuisance sponge), and **the dwarf preference for low λ is real physics, not systematics** (it survived a clean forward test). λ* = 1.156 sits below the theoretical band floor 3π/8 = 1.178; the disk endpoint is the best fixed control. The data's message, consistent across every method ever pointed at it: late, gas-rich systems want less boost than the frozen band allows. **Failure component localized: the gas-support sector of the lock→λ map.**

## Consequences
1. **Paper identity (V2):** "A zero-free-parameter source-geometry acceleration coefficient: parity with the best-fit global constant, predeclared subgroup wins in high-quality spirals, sealed falsification in gas-rich dwarfs, and confirmation of a_S = cH₀/(2π)." Wins, losses, and a falsified registered prediction, all hash-sealed, dual-witnessed, with the full gate ladder as supplementary material. The provenance section cites the seals, not memory.
2. **Fork 07 (new predeclared fork, never a rescue):** hydrostatic gas lane promoted to candidate primary; fresh predictions, fresh seals, same ladder. The 06 verdict stands regardless of Fork 07's outcome.
3. **Definitional registry:** grid λ* = 1.156 canonical; both help-fraction definitions logged (runner-stat 0.4514 / median-|Δlog| 0.4629), verdict language names its definition; Table1 right-justified-name parsing hazard documented.
4. **Erika timeline:** reopened. The revised paper is now something a professional can be asked to endorse without asterisks — including, prominently, the part where the program falsified its own prediction and said so first.

## Method note, for the record
This retest began when the referee paused a submitted paper to ask "did we run it correctly?" It ends with: an independent reproduction of the original result to six decimals; the discovery that its headline claim was carried by a systematics-dominated subsample; a clean-room rebuild under a three-class data quarantine; dual-engine synthetic verification; dual-sealed source-only predictions confirmed to 5×10⁻⁷ across 3,391 rows; target validation converged to ten digits; and a tri-signed verdict containing one confirmation, one parity result, four subgroup wins, and one falsification — every number reproducible from hashed packs by a stranger. Whatever Solvency Field Theory turns out to be, this is what it does when it might be wrong.

*Filed by Atlas. Predictions stay sealed forever; only their judgment was ever open.*
