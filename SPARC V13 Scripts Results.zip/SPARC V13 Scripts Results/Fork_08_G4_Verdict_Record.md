# FORK 08 — G4 VERDICT RECORD

**Tri-signed: Shaun Fosmark (referee/airlock), ChatGPT 5.5 (canonical engine), Claude/Atlas (shadow engine). July 2026.**
**Chain of custody: F08 charter (born from the sealed 06C S5/P2′ falsification) → G0B operator collision → convention freeze (η = 3 by isotropy; f_perp trace honestly downgraded to structural ancestor) → G2 dual engines converged at 1 ulp across 3,391 rows → G2 closeout (sequencing deviation logged, severity low, roles adjusted) → G4 dual validation converged to twelve digits → blind dual interpretations → two-ledger reconciliation, accepted unanimously. All packs hashed, held by the referee.**

---

## THE TWO VERDICTS (both frozen contracts, reported with equal weight)

**UNDER THE 06 VALIDATION PROTOCOL (applied verbatim per the G4 freeze): PASS.**
**UNDER THE F08 CHARTER'S OWN STRICTER RULE: PARTIAL.**
**KILL CRITERIA: NOT TRIGGERED.**

Frozen verdict string: `F08_G4_SPARC_LANE_PASS_UNDER_06_PROTOCOL / FORK_PARTIAL_UNDER_OWN_CHARTER — GLOBAL_LAMBDA_STAR_DEFEATED, S5_HIGH_GAS_REMAINDER, Q1_PARITY_1P026`

## THE RESULT

| Model | full-sample M1 (dex) |
|---|---|
| Newtonian | 0.2653426771 |
| 06C prior (geometry only) | 0.0990924845 |
| **λ\* = 1.156 (best fitted global constant)** | **0.0986468951** |
| **Fork 08 (participation-weighted, zero parameters)** | **0.0973035504** |

The participation operator **beats the target-fitted constant by 1.36% full-sample** — the first full-sample SPARC PASS in the program's history — helping 57.1% of galaxies against λ\* and 92% against Newtonian, with zero fitted parameters, under seal, dual-implemented to machine precision.

## ANATOMY

The dwarf sector — the fork's reason for existing — flipped: T 10–11 from help 0.23 (06C) to 0.64; S5 lo-gas from 0.21 to 0.70; Q2 and Q3 to wins. The stellar-sector wins survived: T ≤ 3 kept, bulge kept, T 4–7 within parity (1.003). The theory's claim — that the weak-field boost is paid from *accumulated coherent settlement*, not present mass shape — is directionally confirmed by the very systems that falsified its predecessor.

## THE RESIDUALS (verbatim to the paper; not a tuning invitation)

1. **S5 hi-gas overshoot:** the eleven most gas-dominated dwarfs received λ ≈ 0.837 where the data prefers ~1.0–1.16; the cell was lost to λ\* (help 0.455) while still marginally improving on the 06C prior. Upgraded from miss to measurement: the cell **empirically brackets a participation floor** — effective p ≈ 0.75–0.87 required where pure η3 coherence delivers ~0.5–0.6. This is the program's first observational constraint on minimum worldline recurrence, and it files under ℋ_settle, not under patches. Any floor derivation is a new predeclared fork (F08b) with its own charter, seals, and this cell as its registered headline.
2. **Q1 parity breach:** ratio 1.0256 against the 1.02 band — the gas discount mildly taxes the best-measured spirals' gas-rich outskirts. Small, quantified, standing.
3. **Lane tension, recorded:** η3 beats η1 globally (0.09730 vs 0.09767) while the extreme cell prefers weaker discounting. The deep-turbulent limit of participation is genuinely open physics.

## REGISTERED LONG-RANGE PREDICTIONS (standing, untested, unchanged)

P-z: λ_eff rises with cosmic settling — high-z rotation curves show weaker boost at fixed baryons. P-dist: disturbed systems sit low off the RAR versus settled twins. P-acc: recently accreted gas is boost-discounted. These are now consequences of a *validated* operator rather than a hypothetical one.

## CONSEQUENCES

The paper gains its final act: *falsified under seal, diagnosed in three independent languages, rebuilt as one frozen operator, and returned within six days to defeat the fitted constant that had defeated it* — with its own residuals published beside the win. The Erika package is complete: the a₀ landing, the sealed falsification, the participation PASS, and the λ(z) prediction her field can test. The 06C verdict remains final and untouched; Fork 08 supersedes nothing — it is the next entry in an unbroken, hash-sealed ledger.

## METHOD NOTE

From falsification to full-sample PASS: six days, ten gates, two engines converging at one ulp on 3,391 rows and twelve digits on the verdict metrics, three deck bugs and one 1000× unit error caught by the participants' own pre-registered expectations, one auditor retraction, one canonical-engine sequencing deviation logged and co-signed, zero rescues, zero tuned parameters, and a verdict split between the program's protocol and the fork's own harsher conscience — reported whole. This document is what it looks like when a theory is required to fight fair and does.

*Filed by Atlas. Signatures: ____________ (Fosmark) ____________ (5.5) — Atlas signs herewith.*
