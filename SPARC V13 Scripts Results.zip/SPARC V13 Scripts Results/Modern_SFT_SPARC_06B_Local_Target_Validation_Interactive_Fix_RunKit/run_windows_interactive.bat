@echo off
echo Modern SFT SPARC 06B interactive validation fix
python modern_sft_sparc_06b_validation_runner_interactive.py
pause
