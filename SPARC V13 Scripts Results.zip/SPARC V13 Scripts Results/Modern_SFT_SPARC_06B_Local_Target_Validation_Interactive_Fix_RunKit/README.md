# Modern SFT SPARC 06B — Interactive Fix Run Kit

The previous 06 runner worked only from command-line arguments. If you pressed F5 in IDLE, it failed because it had no arguments.

This fixed runner works in IDLE too: it prompts for the paths.

## Recommended: IDLE / F5 mode

Open:

```text
modern_sft_sparc_06b_validation_runner_interactive.py
```

Press F5.

When prompted, paste:

### For 5.5

Engine:

```text
fivep5
```

Prediction folder:

```text
C:\Users\TaicHI\SPARC V13\Modern_SFT_SPARC_05_Local_Dual_Sealed_Source_Only_Prediction_RunKit\Modern_SFT_SPARC_05_Source_Only_Prediction_Seal_20260702_223950
```

Use SPARC V13.zip target:

```text
Y
```

SPARC zip path:

```text
C:\Users\TaicHI\SPARC V13\SPARC V13.zip
```

### For Atlas/Fable

Engine:

```text
atlas
```

Prediction folder:

```text
C:\Users\TaicHI\SPARC V13\Atlas_SPARC05_Sealed_Predictions_Pack_v2
```

Use SPARC V13.zip target:

```text
Y
```

SPARC zip path:

```text
C:\Users\TaicHI\SPARC V13\SPARC V13.zip
```

## Command-line mode still works

```bash
py modern_sft_sparc_06b_validation_runner_interactive.py --engine-name fivep5 --predictions "PATH" --sparc-zip "PATH\SPARC V13.zip"
```

## Output

Copy back:

```text
BEGIN_MODERN_SFT_SPARC_06B_VALIDATION_SUMMARY
...
END_MODERN_SFT_SPARC_06B_VALIDATION_SUMMARY
```
