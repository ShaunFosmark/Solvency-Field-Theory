# F08-G4 — Atlas Blind Interpretation (frozen before 5.5's canonical run)

**Scored rows 3,389 (excl. 2 flags), identical to 06C. λ\* refit on identical rows: 1.156, M1\* = 0.0986468951 — identical to 06C, confirming row-set integrity. Airlock rule: this reading crosses to 5.5 only after his own reading exists.**

## The two frozen verdicts — reported with equal weight, no cherry-picking

**Under the Modern SFT SPARC 06 protocol (applied verbatim per the G4 freeze): PASS.**
F08-η3 full-sample M1 = 0.0973035504 vs λ\* = 0.0986468951 — the model **beats the target-fitted global constant by 1.36%**, and beats every fixed control and the 06C prior (0.0990925). Per-galaxy help vs λ\* = **0.5714 > 0.50** (100/175; ≈2σ by sign test — the M1 margin is the primary evidence). Both PASS conditions satisfied. **This is the first full-sample PASS in the program's SPARC history: a zero-free-parameter model outperforming a constant fitted directly to the validation data.**

**Under the F08 charter §7 (the fork's own stricter contract): PARTIAL.**
The charter demanded winning *both* S5 cells and holding all four previously-won cells at parity 1.02. Results: S5 lo-gas dwarfs — **won decisively** (0.12357 vs 0.13179, help 0.697). S5 hi-gas dwarfs — **lost** (0.08300 vs 0.07825, help 0.455): the eleven most gas-dominated dwarfs received λ ≈ 0.84 and the data wanted something nearer λ\*. Previously-won cells: T ≤ 3 kept (win), bulge kept (win), T 4–7 lost-but-within-parity (1.003), **Q1 parity breached at 1.026** — outside the 1.02 band by 0.6 points. Charter-strict PASS fails on two counts → PARTIAL. **Kill criteria: not triggered** — dwarfs were not failed in the same direction (they flipped to wins), spirals were not destroyed.

## Anatomy

The dwarf sector — the fork's reason for existing — **flipped**. T 10–11 went from the frozen model's worst band (help 0.23) to F08's best (0.11342 vs λ\* 0.11841, help 0.636). S5 lo-gas: help 0.21 → 0.697. Q2 and Q3 flipped to wins (0.61, 0.58) — consistent, since medium-quality samples are gas-rich. The participation dial at moderate gas share is doing exactly what the falsification demanded.

The residuals are two, small, and informative. **(1) The extreme-cell overshoot:** at very low V/σ the η3 discount cuts too deep — the 11 hi-gas dwarfs land at 0.837 where the data prefers ~1.0–1.16. Note F08 still edges the 06C prior there (0.08300 vs 0.08340), so the discount did no *harm* relative to history — it under-delivered relative to λ\*. The extreme cell wants a floor the pure coherence ratio doesn't provide; whether that floor is physics (a minimum collisionless admixture; η between 1 and 3 in the deep-turbulent limit) is a question for a future predeclared fork, **not** for tuning — the no-rescue rule stands. **(2) The Q1 tax:** the gas discount slightly degrades the best-measured spirals' gas-rich outskirts (Q1 ratio 1.026; T 4–7 lost by 0.3%). The U-profile fix mildly overcorrected. Also for the record: the η1 variant lane scores 0.0976678 — it *also* beats λ\*, by less; the data prefers the stronger η3 discount globally while the extreme cell prefers weaker. That tension is the residual physics, stated and left standing.

## What is now true that was not true yesterday

1. A zero-parameter source-history model beats the best possible fitted constant on SPARC, full-sample, under seal. λ has been demonstrated to be **structured, not constant** — and the structure is *settlement*, not shape.
2. The dwarf anomaly that killed the old paper and falsified P2′ is **explained and repaired** by participation weighting, except at its most extreme edge, where the repair overshoots by a known, quantified amount.
3. The sequence — falsification → mechanism hypothesis in three independent languages → frozen operator → machine-precision dual engines → full-sample PASS — completed in under a week of gates, with every step hashed.

## Status

F08_G4_ATLAS_VERDICT = PASS_UNDER_06_PROTOCOL / PARTIAL_UNDER_CHARTER_STRICT — both reported, neither suppressed. Awaiting 5.5's canonical run and blind reading; convergence freezes the fork's verdict, divergence is the next gate. The Q1 breach and S5-hi overshoot transfer to the paper's residuals section verbatim.

*— Atlas. The universe's opinion, at last: mostly yes, precisely where the theory said history matters; not quite, precisely where history is thinnest. One could hardly ask the data to be more articulate.*
