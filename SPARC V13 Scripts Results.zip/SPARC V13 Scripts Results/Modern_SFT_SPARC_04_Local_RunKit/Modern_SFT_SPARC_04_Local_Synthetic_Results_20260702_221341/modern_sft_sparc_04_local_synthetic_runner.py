#!/usr/bin/env python3
"""
Modern SFT SPARC 04 — Local Synthetic Unit Test Runner

Run locally with Python 3:

    python modern_sft_sparc_04_local_synthetic_runner.py

This script does NOT open SPARC target data.
It does NOT use Vobs, eVobs, RAR_All_Data, old Track outputs, or fitted lambdas.
It only tests the frozen Modern SFT SPARC 03 model form on synthetic cases.

Outputs:
- timestamped results folder
- zipped results pack
- copy/paste summary printed to terminal
"""

from __future__ import annotations
import csv
import datetime as dt
import hashlib
import json
import math
import os
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Tuple

# -----------------------------
# Frozen constants from SPARC 03
# -----------------------------
LAMBDA_SPHERE = 4.0 / 3.0
LAMBDA_DISK = 3.0 * math.pi / 8.0
DELTA_LAMBDA = LAMBDA_SPHERE - LAMBDA_DISK

UPSILON_DISK_PRIMARY = 0.5
UPSILON_BULGE_PRIMARY = 0.7

# Kregel-style disk thickness relation used for primary synthetic disk lane.
RD_OVER_HZ_MID = 7.3
RD_OVER_HZ_LOW = 7.3 - 2.2
RD_OVER_HZ_HIGH = 7.3 + 2.2

# Gas sensitivity value, not primary physics in this gate.
SIGMA_GAS_KMS = 10.0


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def clip(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def lambda_from_hlock(h_lock: float) -> float:
    h = clip(h_lock)
    return LAMBDA_SPHERE - DELTA_LAMBDA * h


def h_star_geometric(rd_over_hz: float = RD_OVER_HZ_MID) -> float:
    if rd_over_hz <= 0:
        return 0.0
    q = 1.0 / rd_over_hz
    return clip(1.0 - q)


def source_weight_terms(
    vgas: float,
    vdisk: float,
    vbul: float,
    upsilon_d: float = UPSILON_DISK_PRIMARY,
    upsilon_b: float = UPSILON_BULGE_PRIMARY,
) -> Dict[str, float]:
    return {
        "star": upsilon_d * vdisk * vdisk,
        "bulge": upsilon_b * vbul * vbul,
        "gas": abs(vgas) * abs(vgas),
    }


def source_weights(
    vgas: float,
    vdisk: float,
    vbul: float,
    upsilon_d: float = UPSILON_DISK_PRIMARY,
    upsilon_b: float = UPSILON_BULGE_PRIMARY,
    eps: float = 1e-30,
) -> Dict[str, float]:
    terms = source_weight_terms(vgas, vdisk, vbul, upsilon_d, upsilon_b)
    total = terms["star"] + terms["bulge"] + terms["gas"] + eps
    return {k: v / total for k, v in terms.items()}


def vbar_signed_sq(
    vgas: float,
    vdisk: float,
    vbul: float,
    upsilon_d: float = UPSILON_DISK_PRIMARY,
    upsilon_b: float = UPSILON_BULGE_PRIMARY,
) -> float:
    return upsilon_d * vdisk * vdisk + upsilon_b * vbul * vbul + vgas * abs(vgas)


def vbar_abs(
    vgas: float,
    vdisk: float,
    vbul: float,
    upsilon_d: float = UPSILON_DISK_PRIMARY,
    upsilon_b: float = UPSILON_BULGE_PRIMARY,
) -> float:
    val = upsilon_d * vdisk * vdisk + upsilon_b * vbul * vbul + abs(vgas) * abs(vgas)
    return math.sqrt(max(val, 0.0))


def vscale_self_floor(vbar_abs_value: float, sigma_component: float) -> float:
    return max(abs(vbar_abs_value), abs(sigma_component))


def fperp_from_sigma(vbar_abs_value: float, sigma_component: float) -> float:
    scale = vscale_self_floor(vbar_abs_value, sigma_component)
    if scale <= 0:
        return 1.0
    return clip((sigma_component / scale) ** 2)


def lambda_eff_primary(
    vgas: float,
    vdisk: float,
    vbul: float,
    rd_over_hz: float = RD_OVER_HZ_MID,
    upsilon_d: float = UPSILON_DISK_PRIMARY,
    upsilon_b: float = UPSILON_BULGE_PRIMARY,
) -> Tuple[float, Dict[str, float]]:
    """
    Primary frozen model for synthetic tests:
    - bulge = unlocked/spherical = 4/3
    - stellar disk = geometric Kregel h_lock
    - gas primary = puffy/unlocked = 4/3
    """
    w = source_weights(vgas, vdisk, vbul, upsilon_d, upsilon_b)
    lam_bul = LAMBDA_SPHERE
    lam_star = lambda_from_hlock(h_star_geometric(rd_over_hz))
    lam_gas = LAMBDA_SPHERE
    lam_eff = w["bulge"] * lam_bul + w["star"] * lam_star + w["gas"] * lam_gas
    return lam_eff, w


def passfail(cond: bool) -> str:
    return "PASS" if cond else "FAIL"


def near(a: float, b: float, tol: float = 1e-9) -> bool:
    return abs(a - b) <= tol


def add_result(results: List[Dict[str, Any]], test_id: str, name: str, expected: str, observed: Any, status: str, notes: str = "") -> None:
    results.append({
        "test_id": test_id,
        "name": name,
        "expected": expected,
        "observed": observed,
        "status": status,
        "notes": notes,
    })


def run_synthetics() -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []

    # T01 endpoints
    add_result(results, "T01A", "pure_bulge_endpoint", "lambda=4/3", f"{LAMBDA_SPHERE:.12f}", passfail(near(LAMBDA_SPHERE, 4/3)))
    add_result(results, "T01B", "ideal_thin_disk_endpoint", "lambda=3pi/8", f"{LAMBDA_DISK:.12f}", passfail(near(LAMBDA_DISK, 3*math.pi/8)))

    # T02 clamping
    for raw_h in [-0.5, 0.0, 0.5, 1.0, 1.5]:
        lam = lambda_from_hlock(raw_h)
        ok = LAMBDA_DISK <= lam <= LAMBDA_SPHERE
        add_result(results, f"T02_h{raw_h}", "h_lock_clamp_bounds", f"{LAMBDA_DISK:.12f} <= lambda <= {LAMBDA_SPHERE:.12f}", f"raw_h={raw_h}, lambda={lam:.12f}", passfail(ok))

    # T03 Kregel thickness band, f_perp=0 primary disk geometry
    kregel_vals = []
    for label, ratio in [("low", RD_OVER_HZ_LOW), ("mid", RD_OVER_HZ_MID), ("high", RD_OVER_HZ_HIGH)]:
        h = h_star_geometric(ratio)
        lam = lambda_from_hlock(h)
        kregel_vals.append(lam)
        add_result(results, f"T03_{label}", "kregel_thickness_disk", "disk lambda inside endpoints and around ~1.19-1.21", f"R_d/h_z={ratio:.3f}, h={h:.12f}, lambda={lam:.12f}", passfail(LAMBDA_DISK <= lam <= LAMBDA_SPHERE))
    add_result(results, "T03_band", "kregel_band_width", "finite sensitivity band", f"min={min(kregel_vals):.12f}, max={max(kregel_vals):.12f}", passfail((max(kregel_vals) - min(kregel_vals)) > 0))

    # T04 nonnegative weights and hollow gas
    cases = [
        ("normal_gas", 20, 30, 0),
        ("hollow_negative_gas", -20, 30, 0),
        ("pure_negative_gas", -20, 0, 0),
        ("zero_source", 0, 0, 0),
    ]
    for name, vg, vd, vb in cases:
        w = source_weights(vg, vd, vb)
        signed = vbar_signed_sq(vg, vd, vb)
        ok = all(v >= -1e-12 for v in w.values()) and abs(sum(w.values()) - (0.0 if name == "zero_source" else 1.0)) < (1e-9 if name != "zero_source" else 1e-20)
        # zero_source gets eps-denominator and all weights zero; that is acceptable for guard behavior.
        if name == "zero_source":
            ok = all(abs(v) < 1e-20 for v in w.values())
        add_result(results, f"T04_{name}", "nonnegative_weight_ledger", "weights >=0; signed gas only in gbar", f"weights={w}, signed_vbar_sq={signed:.12f}", passfail(ok))

    # T05 source mixture endpoints and interpolation
    mixture_cases = [
        ("pure_bulge", 0, 0, 100, LAMBDA_SPHERE),
        ("pure_star_disk", 0, 100, 0, lambda_from_hlock(h_star_geometric(RD_OVER_HZ_MID))),
        ("pure_gas", 100, 0, 0, LAMBDA_SPHERE),
        ("star_gas_equal_speed", 100, 100, 0, None),
        ("bulge_star_equal_speed", 0, 100, 100, None),
    ]
    for name, vg, vd, vb, expected in mixture_cases:
        lam, w = lambda_eff_primary(vg, vd, vb)
        ok = LAMBDA_DISK <= lam <= LAMBDA_SPHERE
        if expected is not None:
            ok = ok and near(lam, expected)
        add_result(results, f"T05_{name}", "lambda_eff_primary_mixture", "inside endpoints; exact for pure components", f"lambda={lam:.12f}, weights={w}", passfail(ok))

    # T06 self-flooring Vscale for sensitivity lanes
    for vb_abs in [0.0, 2.0, 5.0, 10.0, 25.0, 100.0]:
        sigma = SIGMA_GAS_KMS
        scale = vscale_self_floor(vb_abs, sigma)
        f = fperp_from_sigma(vb_abs, sigma)
        ok = scale >= sigma and 0.0 <= f <= 1.0
        # Center behavior: if source speed is below sigma, f_perp=1 -> unlock.
        if vb_abs < sigma:
            ok = ok and near(f, 1.0)
        add_result(results, f"T06_vbar{vb_abs}", "self_flooring_vscale", "scale>=sigma and 0<=f_perp<=1", f"vbar_abs={vb_abs:.3f}, sigma={sigma:.3f}, scale={scale:.3f}, f_perp={f:.12f}", passfail(ok))

    # T07 radial composition gradient synthetic: bulge center -> disk mid -> gas outer
    radial = [
        ("r1_bulge_center", 0, 20, 100),
        ("r2_disk_dominated", 10, 100, 20),
        ("r3_gas_outer", 100, 20, 0),
    ]
    radial_lams = []
    for name, vg, vd, vb in radial:
        lam, w = lambda_eff_primary(vg, vd, vb)
        radial_lams.append((name, lam, w))
        add_result(results, f"T07_{name}", "radial_composition_gradient", "lambda inside endpoints", f"lambda={lam:.12f}, weights={w}", passfail(LAMBDA_DISK <= lam <= LAMBDA_SPHERE))
    # Expected qualitative: center higher than disk-dominated mid; gas outer returns high due puffy gas primary.
    center = radial_lams[0][1]
    mid = radial_lams[1][1]
    outer = radial_lams[2][1]
    add_result(results, "T07_shape", "radial_lambda_shape", "center > mid and outer > mid", f"center={center:.12f}, mid={mid:.12f}, outer={outer:.12f}", passfail(center > mid and outer > mid))

    return results


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)


def write_manifest(folder: Path) -> List[Dict[str, Any]]:
    rows = []
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.name != "file_manifest.csv":
            rows.append({
                "relative_path": str(p.relative_to(folder)),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    with (folder / "file_manifest.csv").open("w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=["relative_path", "size_bytes", "sha256"])
        wr.writeheader()
        wr.writerows(rows)
    return rows


def zip_folder(folder: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(folder)))


def main() -> int:
    script_path = Path(__file__).resolve()
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path.cwd() / f"Modern_SFT_SPARC_04_Local_Synthetic_Results_{timestamp}"
    out_dir.mkdir(parents=True, exist_ok=True)

    results = run_synthetics()
    n_pass = sum(1 for r in results if r["status"] == "PASS")
    n_fail = sum(1 for r in results if r["status"] == "FAIL")
    verdict = "PASS" if n_fail == 0 else "FAIL"

    config = {
        "gate": "Modern SFT SPARC 04 — Synthetic Unit Tests",
        "generated_local_time": timestamp,
        "runner": script_path.name,
        "python_version": sys.version,
        "model_constants": {
            "lambda_sphere": LAMBDA_SPHERE,
            "lambda_disk": LAMBDA_DISK,
            "delta_lambda": DELTA_LAMBDA,
            "upsilon_disk_primary": UPSILON_DISK_PRIMARY,
            "upsilon_bulge_primary": UPSILON_BULGE_PRIMARY,
            "rd_over_hz_mid": RD_OVER_HZ_MID,
            "rd_over_hz_low": RD_OVER_HZ_LOW,
            "rd_over_hz_high": RD_OVER_HZ_HIGH,
            "sigma_gas_kms_sensitivity": SIGMA_GAS_KMS,
        },
        "forbidden_inputs": [
            "Vobs",
            "eVobs",
            "Vflat",
            "RAR_All_Data",
            "gobs",
            "residuals",
            "best lambda",
            "old Track outputs",
        ],
        "data_access": "synthetic_only_no_sparc_target_data",
    }

    write_csv(out_dir / "Modern_SFT_SPARC_04_Synthetic_Results.csv", results)
    (out_dir / "Modern_SFT_SPARC_04_Config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    summary_lines = [
        "BEGIN_MODERN_SFT_SPARC_04_LOCAL_SUMMARY",
        f"gate=Modern SFT SPARC 04 — Synthetic Unit Tests",
        f"timestamp={timestamp}",
        f"verdict={verdict}",
        f"tests_total={len(results)}",
        f"tests_pass={n_pass}",
        f"tests_fail={n_fail}",
        f"lambda_sphere={LAMBDA_SPHERE:.12f}",
        f"lambda_disk={LAMBDA_DISK:.12f}",
        f"runner_sha256={sha256_file(script_path)}",
    ]

    if n_fail:
        summary_lines.append("failed_tests=" + ",".join(r["test_id"] for r in results if r["status"] == "FAIL"))
    else:
        summary_lines.append("failed_tests=NONE")

    # Copy runner into result pack after computing runner hash.
    shutil.copy2(script_path, out_dir / script_path.name)
    manifest_rows = write_manifest(out_dir)

    zip_path = Path.cwd() / f"{out_dir.name}.zip"
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)

    summary_lines.extend([
        f"results_folder={out_dir.name}",
        f"results_zip={zip_path.name}",
        f"results_zip_sha256={zip_hash}",
        "END_MODERN_SFT_SPARC_04_LOCAL_SUMMARY",
    ])

    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SUMMARY.txt").write_text(summary_text, encoding="utf-8")

    # Rebuild zip with summary included.
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)

    # Update final printed hash after rebuild.
    summary_lines[-2] = f"results_zip_sha256={zip_hash}"
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SUMMARY.txt").write_text(summary_text, encoding="utf-8")
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)
    summary_lines[-2] = f"results_zip_sha256={zip_hash}"
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SUMMARY.txt").write_text(summary_text, encoding="utf-8")

    # Final zip after final summary.
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)
    summary_lines[-2] = f"results_zip_sha256={zip_hash}"
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SUMMARY.txt").write_text(summary_text, encoding="utf-8")
    zip_folder(out_dir, zip_path)

    print("\n" + summary_text)
    print(f"Saved local results folder: {out_dir}")
    print(f"Saved zipped results pack: {zip_path}")
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
