# Modern SFT SPARC 04 — Local Run Kit

This is a local Python 3 runner for **Modern SFT SPARC 04 — Synthetic Unit Tests**.

It is designed for Shaun to run on his own PC so the output zip and hashes are saved locally.

## Run

Open PowerShell or Command Prompt in this folder and run:

```bash
python modern_sft_sparc_04_local_synthetic_runner.py
```

If Windows uses the Python launcher:

```bash
py modern_sft_sparc_04_local_synthetic_runner.py
```

## What it does

It runs synthetic-only unit tests for the frozen Modern SFT SPARC 03 model form:

- pure bulge endpoint
- ideal thin disk endpoint
- Kregel-thickness disk band
- h-lock clamping
- nonnegative source weights
- hollow negative-gas sanity check
- self-flooring \(V_{\rm scale}\)
- mixture interpolation
- radial composition-gradient toy

## What it does NOT do

It does **not** open SPARC target data.

It does **not** use:

- Vobs
- eVobs
- Vflat
- RAR_All_Data
- gobs
- residuals
- best lambda
- old Track outputs

## Outputs

A timestamped folder:

```text
Modern_SFT_SPARC_04_Local_Synthetic_Results_YYYYMMDD_HHMMSS/
```

A zipped results pack:

```text
Modern_SFT_SPARC_04_Local_Synthetic_Results_YYYYMMDD_HHMMSS.zip
```

The terminal prints a copy/paste block:

```text
BEGIN_MODERN_SFT_SPARC_04_LOCAL_SUMMARY
...
END_MODERN_SFT_SPARC_04_LOCAL_SUMMARY
```

Copy that block back into ChatGPT/Fable so we can compare engines.
