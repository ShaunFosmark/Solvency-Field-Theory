@echo off
echo Running Modern SFT SPARC 04 local synthetic tests...
python modern_sft_sparc_04_local_synthetic_runner.py
if errorlevel 1 (
  echo.
  echo Runner reported FAIL. Copy the summary block and send it back.
) else (
  echo.
  echo Runner reported PASS. Copy the summary block and send it back.
)
pause
