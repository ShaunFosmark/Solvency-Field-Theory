"""Atlas shadow — Modern SFT SPARC 05: Dual-Sealed Source-Only Predictions.
Exact frozen spec. Parser physically restricted to source columns (usecols 0,3,4,5,6,7).
Vobs/errV never enter memory. No values printed — seal block only."""
import numpy as np, glob, os, hashlib, json, zipfile, sys
C=2.99792458e8; H0=67.74*1000/3.0856775814913673e22; A_S=C*H0/(2*np.pi)
KPC=3.0856775814913673e19
LS,LD=4.0/3.0,3*np.pi/8; UD,UB=0.5,0.7
H_STAR=1.0-1.0/7.3; LAM_STAR=LS-(LS-LD)*H_STAR; LAM_B=LS; LAM_G=LS
MID=(LS+LD)/2.0
SRC='/home/claude/sft/sparcfull/SPARC/Rotmod_LTG'
files=sorted(glob.glob(os.path.join(SRC,'*_rotmod.dat')))
rows_out=[]; n_src_rows=0; n_flag=0
for f in files:
    name=os.path.basename(f).replace('_rotmod.dat','')
    d=np.loadtxt(f, usecols=(0,3,4,5,6,7))     # R,Vgas,Vdisk,Vbul,SBdisk,SBbul ONLY
    if d.ndim==1: d=d[None,:]
    R,Vg,Vd,Vb=d[:,0],d[:,1],d[:,2],d[:,3]
    keep=R>0; R,Vg,Vd,Vb=R[keep],Vg[keep],Vd[keep],Vb[keep]
    n_src_rows+=len(R)
    Vbar2=UD*Vd**2+UB*Vb**2+Vg*np.abs(Vg)
    Sd,Sb,Sg=UD*Vd**2,UB*Vb**2,np.abs(Vg)**2
    St=Sd+Sb+Sg; St=np.where(St>0,St,1.0)
    lam=(Sd/St)*LAM_STAR+(Sb/St)*LAM_B+(Sg/St)*LAM_G
    gbar=Vbar2*1e6/(R*KPC)
    flag=(Vbar2<=0).astype(int); n_flag+=int(flag.sum())
    def vp(l):
        g2=gbar**2+l*A_S*gbar
        v=np.where(g2>0, np.sqrt(np.sqrt(np.maximum(g2,0))*R*KPC)/1000.0, 0.0)
        return np.where(flag==1, 0.0, v)
    vN=np.where(flag==1,0.0,np.where(gbar>0,np.sqrt(gbar*R*KPC)/1000.0,0.0))
    for i in range(len(R)):
        rows_out.append((name,R[i],lam[i],vp(lam)[i],vp(1.0)[i],vp(LS)[i],vp(LD)[i],vp(MID)[i],vN[i],flag[i]))
hdr='Galaxy,R_kpc,lambda_eff_primary,Vpred_primary,Vpred_lam1,Vpred_lam4over3,Vpred_lam3pi8,Vpred_mid,Vpred_newton,flag'
lines=[hdr]+[f'{r[0]},{r[1]:.6f},{r[2]:.6f},{r[3]:.6f},{r[4]:.6f},{r[5]:.6f},{r[6]:.6f},{r[7]:.6f},{r[8]:.6f},{int(r[9])}' for r in rows_out]
csv='\n'.join(lines)+'\n'
open('atlas_sparc05_predictions.csv','w').write(csv)
h_script=hashlib.sha256(open(sys.argv[0],'rb').read()).hexdigest()
h_csv=hashlib.sha256(csv.encode()).hexdigest()
with zipfile.ZipFile('Atlas_SPARC05_Sealed_Predictions_Pack.zip','w') as z:
    z.write(sys.argv[0]); z.write('atlas_sparc05_predictions.csv')
h_zip=hashlib.sha256(open('Atlas_SPARC05_Sealed_Predictions_Pack.zip','rb').read()).hexdigest()
print('BEGIN_ATLAS_SPARC05_SHADOW_PREDICTION_SEAL')
print('gate=Modern SFT SPARC 05 — Dual-Sealed Source-Only Predictions (Atlas shadow)')
print(f'script_sha256={h_script}')
print(f'source_row_count={n_src_rows}')
print(f'galaxy_count={len(files)}')
print(f'prediction_row_count={len(rows_out)}')
print(f'flag_count={n_flag}   (declared rule: rows with Vbar_signed_sq<=0 -> predictions 0.0, flag=1)')
print(f'prediction_csv_sha256={h_csv}')
print(f'results_zip_sha256={h_zip}')
print('float_format=%.6f fixed; galaxy order = sorted filename; all R>0 rows included (no errV filtering possible: column never loaded)')
print('END_ATLAS_SPARC05_SHADOW_PREDICTION_SEAL')
