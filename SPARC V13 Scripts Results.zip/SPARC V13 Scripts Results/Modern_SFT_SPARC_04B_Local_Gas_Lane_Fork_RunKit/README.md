# Modern SFT SPARC 04B — Local Gas-Lane Fork Run Kit

Run locally with Python 3:

```bash
python modern_sft_sparc_04b_gas_lane_fork_runner.py
```

or on Windows:

```bash
py modern_sft_sparc_04b_gas_lane_fork_runner.py
```

This creates:

```text
Modern_SFT_SPARC_04B_Gas_Lane_Fork_Results_YYYYMMDD_HHMMSS/
Modern_SFT_SPARC_04B_Gas_Lane_Fork_Results_YYYYMMDD_HHMMSS.zip
```

It also prints:

```text
BEGIN_MODERN_SFT_SPARC_04B_LOCAL_SUMMARY
...
END_MODERN_SFT_SPARC_04B_LOCAL_SUMMARY
```

Copy/paste that block back to ChatGPT and Fable.
