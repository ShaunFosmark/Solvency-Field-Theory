# Modern SFT SPARC 04B — Gas-Lane Fork Decision Synthetic

## Short description for Fable/Atlas

This is the next convergence test before source-only predictions.

**Gate name:** `Modern SFT SPARC 04B — Gas-Lane Fork Decision Synthetic`

**Purpose:** Decide exactly what the SPARC04 lane-dependence result means. The question is not whether the model can pass endpoints. It already did. The question is whether the registered dwarf-high-\(\lambda\) expectation belongs to the frozen **primary puffy-gas lane** universally, only conditionally, or to a gas-geometry/hydro sensitivity fork.

## No data rule

Use synthetic inputs only.

Forbidden:

```text
Vobs
eVobs
Vflat
RAR_All_Data
gobs
residuals
best lambda
old Track outputs
real SPARC validation metrics
```

## Shared constants

```text
lambda_sphere = 4/3
lambda_disk = 3*pi/8
Upsilon_disk = 0.5
Upsilon_bulge = 0.7
R_d/h_z = 7.3
dwarf_high_lambda_threshold = 1.30
```

Stellar disk lock:

```text
h_star = 1 - 1/7.3
lambda_star = lambda_sphere - (lambda_sphere - lambda_disk) * h_star
```

Primary gas lane:

```text
gas is puffy/unlocked
h_gas = 0
lambda_gas = 4/3
```

Primary two-component dwarf synthetic:

```text
lambda_eff(f_gas) = f_gas * lambda_gas + (1 - f_gas) * lambda_star
```

where \(f_{\rm gas}\) is the nonnegative gas source share, not signed acceleration share.

## Required tests

### 04B-T01 threshold formula

Compute:

```text
f_gas_min = (1.30 - lambda_star) / (lambda_sphere - lambda_star)
```

Pass if:

```text
0 < f_gas_min < 1
lambda_eff(f_gas_min) = 1.30 within tolerance
```

### 04B-T02 gas-share grid

Evaluate:

```text
f_gas = 0.00, 0.25, 0.50, 0.75, 0.80, 1.00
```

Pass if:

```text
lambda_eff >= 1.30 iff f_gas >= f_gas_min
```

### 04B-T03 velocity/source-share reconstruction

Build synthetic velocities that reproduce source shares:

```text
S_gas = |Vgas|^2
S_star = Upsilon_disk * Vdisk^2
S_total = 10000
S_gas = f_gas * S_total
S_star = (1 - f_gas) * S_total
```

For:

```text
f_gas = 0.25, 0.50, 0.80
```

Pass if the recovered weights equal the requested gas shares and the velocity-based lambda equals the direct share-based lambda.

### 04B-T04 monotonicity

Evaluate \(f_{\rm gas}\) from 0 to 1 in steps of 0.05.

Pass if:

```text
lambda_eff is monotonically increasing
lambda_eff(0) = lambda_star
lambda_eff(1) = 4/3
```

### 04B-T05 classification

Pass if the engine reports:

```text
PRIMARY_DWARF_HIGH_LAMBDA_CONDITIONAL_ON_GAS_SHARE
```

Equivalent wording is fine, but the meaning must be:

```text
The primary puffy-gas lane does not imply universal dwarf lambda >= 1.30.
It implies lambda >= 1.30 only for gas source share above f_gas_min.
```

### 04B-T06 optional kinematic sensitivity bound check

Sensitivity/demo only, not primary.

Use:

```text
V_scale = max(Vbar_abs, sigma_gas)
sigma_gas = 10 km/s
f_perp = (sigma_gas / V_scale)^2
h_planar = 1 - q_gas
h_lock = h_planar * (1 - f_perp)
lambda_gas = lambda_sphere - (lambda_sphere - lambda_disk) * h_lock
```

Grid:

```text
q_gas = 0.10, 0.30, 0.60, 1.00
Vbar_abs = 0, 5, 10, 25, 100 km/s
```

Pass if all \(\lambda_{\rm gas}\) remain inside:

```text
[3*pi/8, 4/3]
```

## Expected gate verdict

If implemented correctly, this should pass with the decision:

```text
PRIMARY_DWARF_HIGH_LAMBDA_CONDITIONAL_ON_GAS_SHARE
```

The important number to compare between engines is:

```text
f_gas_min_for_primary_high_lambda
```

The two engines should agree on it to numerical precision.
