#!/usr/bin/env python3
"""
Modern SFT SPARC 04B — Gas-Lane Fork Decision Synthetic Runner

Run locally with Python 3:

    python modern_sft_sparc_04b_gas_lane_fork_runner.py

Purpose:
Decide exactly what the synthetic result from SPARC04 means for the dwarf-high-lambda claim.

This script uses synthetic inputs only.
It does NOT open SPARC target data.
It does NOT use Vobs, eVobs, Vflat, RAR_All_Data, old Track outputs, residuals, or fitted lambdas.

Core question:
Under the frozen primary lane,
    gas = puffy/unlocked, lambda_gas = 4/3
    stellar disk = Kregel mid-thickness, lambda_star ≈ 1.199
is "dwarf lambda_eff >= 1.30" universal, or conditional on gas source share?

Expected answer:
It is conditional. In the primary puffy-gas lane, lambda_eff >= 1.30 only when gas source share
exceeds a computable threshold f_gas_min.
"""

from __future__ import annotations
import csv
import datetime as dt
import hashlib
import json
import math
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any, Dict, List

# Frozen constants
LAMBDA_SPHERE = 4.0 / 3.0
LAMBDA_DISK = 3.0 * math.pi / 8.0
DELTA_LAMBDA = LAMBDA_SPHERE - LAMBDA_DISK

UPSILON_DISK = 0.5
UPSILON_BULGE = 0.7
RD_OVER_HZ_MID = 7.3

# Registered threshold from Atlas/Fable synthetics discussion.
DWARF_HIGH_LAMBDA_THRESHOLD = 1.30

# Gas sensitivity/demo constant from trace table. Sensitivity only, not primary validation physics.
SIGMA_GAS_KMS = 10.0


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def clip(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def lambda_from_hlock(h_lock: float) -> float:
    return LAMBDA_SPHERE - DELTA_LAMBDA * clip(h_lock)


def h_star_mid() -> float:
    return clip(1.0 - 1.0 / RD_OVER_HZ_MID)


def lambda_star_mid() -> float:
    return lambda_from_hlock(h_star_mid())


def lambda_primary_from_gas_share(f_gas: float) -> float:
    """Two-component dwarf synthetic: gas + stellar disk only, no bulge."""
    f = clip(f_gas)
    return f * LAMBDA_SPHERE + (1.0 - f) * lambda_star_mid()


def gas_share_threshold_for_high_lambda(threshold: float = DWARF_HIGH_LAMBDA_THRESHOLD) -> float:
    lam_star = lambda_star_mid()
    if threshold <= lam_star:
        return 0.0
    if threshold >= LAMBDA_SPHERE:
        return 1.0
    return (threshold - lam_star) / (LAMBDA_SPHERE - lam_star)


def synthetic_velocities_for_source_share(f_gas: float, total_source_term: float = 10000.0) -> Dict[str, float]:
    """
    Construct synthetic Vgas/Vdisk so source weights equal f_gas and 1-f_gas.

    Source terms:
      S_gas = |Vgas|^2
      S_star = Upsilon_d Vdisk^2
    """
    f = clip(f_gas)
    s_gas = f * total_source_term
    s_star = (1.0 - f) * total_source_term
    vgas = math.sqrt(max(s_gas, 0.0))
    vdisk = math.sqrt(max(s_star / UPSILON_DISK, 0.0)) if UPSILON_DISK > 0 else 0.0
    return {"Vgas": vgas, "Vdisk": vdisk, "Vbul": 0.0}


def source_weights(vgas: float, vdisk: float, vbul: float) -> Dict[str, float]:
    s_star = UPSILON_DISK * vdisk * vdisk
    s_bul = UPSILON_BULGE * vbul * vbul
    s_gas = abs(vgas) * abs(vgas)
    total = s_star + s_bul + s_gas
    if total <= 0:
        return {"star": 0.0, "bulge": 0.0, "gas": 0.0}
    return {"star": s_star / total, "bulge": s_bul / total, "gas": s_gas / total}


def lambda_eff_primary(vgas: float, vdisk: float, vbul: float) -> float:
    w = source_weights(vgas, vdisk, vbul)
    lam_star = lambda_star_mid()
    lam_bul = LAMBDA_SPHERE
    lam_gas = LAMBDA_SPHERE
    return w["star"] * lam_star + w["bulge"] * lam_bul + w["gas"] * lam_gas


def vbar_abs(vgas: float, vdisk: float, vbul: float) -> float:
    val = UPSILON_DISK * vdisk * vdisk + UPSILON_BULGE * vbul * vbul + abs(vgas) * abs(vgas)
    return math.sqrt(max(val, 0.0))


def fperp_self_floor(vbar_abs_value: float, sigma: float = SIGMA_GAS_KMS) -> float:
    scale = max(abs(vbar_abs_value), abs(sigma))
    if scale <= 0:
        return 1.0
    return clip((sigma / scale) ** 2)


def lambda_gas_kinematic_demo(q_gas: float, vbar_abs_value: float, sigma: float = SIGMA_GAS_KMS) -> float:
    """
    Sensitivity/demo lane only:
      h_planar = clip(1 - q_gas)
      f_perp = (sigma/max(Vbar_abs, sigma))^2
      h_lock = h_planar*(1-f_perp)
    """
    h_planar = clip(1.0 - q_gas)
    f = fperp_self_floor(vbar_abs_value, sigma)
    h = clip(h_planar * (1.0 - f))
    return lambda_from_hlock(h)


def add(rows: List[Dict[str, Any]], test_id: str, name: str, expected: str, observed: str, ok: bool, notes: str = "") -> None:
    rows.append({
        "test_id": test_id,
        "name": name,
        "expected": expected,
        "observed": observed,
        "status": "PASS" if ok else "FAIL",
        "notes": notes,
    })


def near(a: float, b: float, tol: float = 1e-9) -> bool:
    return abs(a - b) <= tol


def run_tests() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    lam_star = lambda_star_mid()
    f_min = gas_share_threshold_for_high_lambda()

    # T01: threshold should be internal endpoint interpolation, not fitted.
    add(
        rows,
        "04B_T01",
        "gas_share_threshold_formula",
        "0 < f_gas_min < 1 and lambda(f_min)=1.30",
        f"lambda_star={lam_star:.12f}, f_gas_min={f_min:.12f}, lambda_at_min={lambda_primary_from_gas_share(f_min):.12f}",
        0.0 < f_min < 1.0 and near(lambda_primary_from_gas_share(f_min), DWARF_HIGH_LAMBDA_THRESHOLD, 1e-9),
        "Primary dwarf-high-lambda claim is conditional if f_min is inside (0,1).",
    )

    # T02: grid around threshold.
    for f in [0.0, 0.25, 0.50, 0.75, 0.80, 1.0]:
        lam = lambda_primary_from_gas_share(f)
        should_high = f >= f_min - 1e-12
        is_high = lam >= DWARF_HIGH_LAMBDA_THRESHOLD - 1e-12
        add(
            rows,
            f"04B_T02_fgas_{f:.2f}",
            "primary_lane_gas_share_grid",
            "lambda>=1.30 iff f_gas>=f_min",
            f"f_gas={f:.2f}, lambda={lam:.12f}, f_min={f_min:.12f}, is_high={is_high}",
            should_high == is_high,
        )

    # T03: velocity construction reproduces exact source shares and lambda.
    for f in [0.25, 0.50, 0.80]:
        vel = synthetic_velocities_for_source_share(f)
        w = source_weights(vel["Vgas"], vel["Vdisk"], vel["Vbul"])
        lam_v = lambda_eff_primary(vel["Vgas"], vel["Vdisk"], vel["Vbul"])
        lam_f = lambda_primary_from_gas_share(f)
        add(
            rows,
            f"04B_T03_velocity_share_{f:.2f}",
            "synthetic_velocity_share_reconstruction",
            "weights reproduce requested gas share and lambda",
            f"f={f:.2f}, weights={w}, lambda_velocity={lam_v:.12f}, lambda_share={lam_f:.12f}",
            near(w["gas"], f, 1e-9) and near(lam_v, lam_f, 1e-9),
        )

    # T04: monotonicity in gas share.
    grid = [i / 20 for i in range(21)]
    vals = [lambda_primary_from_gas_share(f) for f in grid]
    mono = all(vals[i+1] >= vals[i] - 1e-12 for i in range(len(vals)-1))
    add(
        rows,
        "04B_T04",
        "primary_lane_monotone_in_gas_share",
        "lambda_eff increases monotonically with puffy gas source share",
        f"lambda_min={min(vals):.12f}, lambda_max={max(vals):.12f}",
        mono and near(vals[0], lam_star) and near(vals[-1], LAMBDA_SPHERE),
    )

    # T05: classification of registered dwarf-high claim.
    classification = "CONDITIONAL_PRIMARY_NOT_UNIVERSAL"
    ok_class = 0.0 < f_min < 1.0
    add(
        rows,
        "04B_T05",
        "registered_dwarf_high_lambda_classification",
        "classification=CONDITIONAL_PRIMARY_NOT_UNIVERSAL",
        f"classification={classification}, f_gas_min={f_min:.12f}",
        ok_class,
        "Universal dwarf-high claim is not supported by primary lane; gas-share conditional claim is supported.",
    )

    # T06: kinematic sensitivity/demo stays inside endpoints for q/Vbar grid.
    for q in [0.10, 0.30, 0.60, 1.00]:
        for vb in [0.0, 5.0, 10.0, 25.0, 100.0]:
            lam = lambda_gas_kinematic_demo(q, vb)
            ok = LAMBDA_DISK <= lam <= LAMBDA_SPHERE
            add(
                rows,
                f"04B_T06_q{q:.2f}_v{vb:.1f}",
                "kinematic_gas_sensitivity_bounds",
                "lambda remains inside endpoints",
                f"q_gas={q:.2f}, Vbar_abs={vb:.1f}, lambda={lam:.12f}",
                ok,
                "Sensitivity/demo only; not primary gas lane.",
            )

    return rows


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)


def zip_folder(folder: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(folder)))


def main() -> int:
    script_path = Path(__file__).resolve()
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path.cwd() / f"Modern_SFT_SPARC_04B_Gas_Lane_Fork_Results_{timestamp}"
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = run_tests()
    n_pass = sum(1 for r in rows if r["status"] == "PASS")
    n_fail = sum(1 for r in rows if r["status"] == "FAIL")
    verdict = "PASS" if n_fail == 0 else "FAIL"

    lam_star = lambda_star_mid()
    f_min = gas_share_threshold_for_high_lambda()
    decision = "PRIMARY_DWARF_HIGH_LAMBDA_CONDITIONAL_ON_GAS_SHARE" if verdict == "PASS" else "UNRESOLVED"

    config = {
        "gate": "Modern SFT SPARC 04B — Gas-Lane Fork Decision Synthetic",
        "generated_local_time": timestamp,
        "python_version": sys.version,
        "constants": {
            "lambda_sphere": LAMBDA_SPHERE,
            "lambda_disk": LAMBDA_DISK,
            "lambda_star_mid": lam_star,
            "rd_over_hz_mid": RD_OVER_HZ_MID,
            "upsilon_disk": UPSILON_DISK,
            "upsilon_bulge": UPSILON_BULGE,
            "dwarf_high_lambda_threshold": DWARF_HIGH_LAMBDA_THRESHOLD,
            "f_gas_min_for_high_lambda": f_min,
            "sigma_gas_kms_sensitivity": SIGMA_GAS_KMS,
        },
        "decision": decision,
        "forbidden_inputs": [
            "Vobs", "eVobs", "Vflat", "RAR_All_Data", "gobs", "residuals", "best lambda", "old Track outputs"
        ],
        "data_access": "synthetic_only_no_sparc_target_data",
    }

    write_csv(out_dir / "Modern_SFT_SPARC_04B_Gas_Lane_Fork_Results.csv", rows)
    (out_dir / "Modern_SFT_SPARC_04B_Config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    shutil.copy2(script_path, out_dir / script_path.name)

    # File manifest
    manifest = []
    for p in sorted(out_dir.rglob("*")):
        if p.is_file() and p.name != "file_manifest.csv":
            manifest.append({
                "relative_path": str(p.relative_to(out_dir)),
                "size_bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    with (out_dir / "file_manifest.csv").open("w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=["relative_path", "size_bytes", "sha256"])
        wr.writeheader()
        wr.writerows(manifest)

    zip_path = Path.cwd() / f"{out_dir.name}.zip"
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)

    summary_lines = [
        "BEGIN_MODERN_SFT_SPARC_04B_LOCAL_SUMMARY",
        "gate=Modern SFT SPARC 04B — Gas-Lane Fork Decision Synthetic",
        f"timestamp={timestamp}",
        f"verdict={verdict}",
        f"tests_total={len(rows)}",
        f"tests_pass={n_pass}",
        f"tests_fail={n_fail}",
        f"lambda_star_mid={lam_star:.12f}",
        f"lambda_sphere={LAMBDA_SPHERE:.12f}",
        f"lambda_disk={LAMBDA_DISK:.12f}",
        f"dwarf_high_lambda_threshold={DWARF_HIGH_LAMBDA_THRESHOLD:.12f}",
        f"f_gas_min_for_primary_high_lambda={f_min:.12f}",
        f"decision={decision}",
        f"failed_tests={','.join(r['test_id'] for r in rows if r['status']=='FAIL') if n_fail else 'NONE'}",
        f"runner_sha256={sha256_file(script_path)}",
        f"results_zip={zip_path.name}",
        f"results_zip_sha256={zip_hash}",
        "END_MODERN_SFT_SPARC_04B_LOCAL_SUMMARY",
    ]
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SUMMARY.txt").write_text(summary_text, encoding="utf-8")

    # Rezip with summary file included and update final hash once.
    zip_folder(out_dir, zip_path)
    zip_hash = sha256_file(zip_path)
    summary_lines[-2] = f"results_zip_sha256={zip_hash}"
    summary_text = "\n".join(summary_lines) + "\n"
    (out_dir / "COPY_PASTE_SUMMARY.txt").write_text(summary_text, encoding="utf-8")
    zip_folder(out_dir, zip_path)

    print("\n" + summary_text)
    print(f"Saved local results folder: {out_dir}")
    print(f"Saved zipped results pack: {zip_path}")
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
