@echo off
echo Running Modern SFT SPARC 04B gas-lane fork synthetic test...
python modern_sft_sparc_04b_gas_lane_fork_runner.py
if errorlevel 1 (
  echo.
  echo Runner reported FAIL. Copy the summary block and send it back.
) else (
  echo.
  echo Runner reported PASS. Copy the summary block and send it back.
)
pause
