# Draft §4–§5 for "Where Source Geometry Works: A Sealed, Zero-Parameter Retest of Solvency Field Theory on SPARC"

**Atlas draft v1 — from the tri-signed G7 record and sealed packs. All numbers reproduce from hashed artifacts; nothing here is quotable without its pack.**

---

## 4. Protocol summary

Predictions were generated under a sealed, source-only protocol. The model inputs were restricted to the baryonic mass-model columns of the SPARC rotation-mass files (R, V_gas, V_disk, V_bul, surface-brightness profiles) and shared-infrastructure metadata (Hubble type T, quality flag Q from the sample table); the observed velocities V_obs and their uncertainties were withheld behind a data quarantine until predictions were hashed. Two fully independent implementations — built from a common frozen specification with no shared code — generated predictions for all 175 late-type galaxies (3,391 radial points); the two prediction sets agree to ≤ 5×10⁻⁷ km/s at every point, with the identical two rows flagged by the declared non-positive-source rule. The model contains **zero per-galaxy free parameters and zero global fitted parameters**: the acceleration scale is a_S = cH₀/(2π) with H₀ = 67.74 km s⁻¹ Mpc⁻¹, the coefficient endpoints λ_sphere = 4/3 and λ_disk = 3π/8 are geometric constants, the stellar-disk thickness ratio is the literature value R_d/h_z = 7.3, and mass-to-light ratios are fixed at the population-synthesis values (0.5, 0.7). Validation metrics, controls, row-inclusion rules, subgroup definitions, and PASS/PARTIAL/FAIL criteria were frozen in writing before the target columns were unsealed; scoring was likewise dual-implemented and agrees to ten significant figures. All prediction files, scoring outputs, and protocol documents are archived with SHA-256 hashes.

## 5. Results

### 5.1 Full sample

Over the 3,389 scored points, the per-point RMS of log₁₀V_obs − log₁₀V_pred (metric M1) is:

| Model / control | M1 (dex) | RMSV (km/s) |
|---|---|---|
| Newtonian (baryons only) | 0.26534 | 58.62 |
| λ = 1 | 0.09939 | 25.97 |
| λ = 4/3 (sphere endpoint) | 0.09939 | 23.67 |
| λ = 3π/8 (disk endpoint) | 0.09866 | 24.46 |
| λ = midpoint (1.2557) | 0.09890 | 24.01 |
| **λ\* = 1.156 (best global constant, target-fit)** | **0.09865** | — |
| **Source-geometry model (zero parameters)** | **0.09909** | 24.14 |

The solvency-family law dominates the Newtonian prediction at every level of aggregation: the model improves 90.9% of galaxies individually, and the full-sample M1 improves by a factor of 2.7. Against the deliberately generous control — the single global constant λ\* fitted directly to the validation data — the zero-parameter model reaches **parity within 0.45%** (ratio 1.0045, inside the pre-declared 1.02 parity band) but does not beat it; the per-galaxy help fraction against λ\* is 45–46% (two per-galaxy aggregation conventions were pre-logged; both give the same conclusion).

### 5.2 The acceleration scale

The fitted control carries an independent physical message. The effective deep-regime scale preferred by the data is λ\*·a_S = **1.211×10⁻¹⁰ m s⁻²**, within 0.9% (≈0.5σ statistical) of the empirical radial-acceleration-relation scale a₀ = (1.20 ± 0.02)×10⁻¹⁰ m s⁻² (McGaugh et al. 2016). Equivalently, the data select a₀ = cH₀/5.44, quantitatively realizing the long-noted a₀ ∼ cH₀ coincidence (Milgrom 1983) with a derived scale and an O(1) geometric coefficient. The fitted coefficient falls 1.9% below the predicted geometric interval [3π/8, 4/3]; the interval's lower endpoint is recovered exactly for H₀ = 66.5 km s⁻¹ Mpc⁻¹, so the offset is degenerate with the Hubble tension and the mass-to-light normalization at its full size. The disk endpoint λ = 3π/8 is the best-performing fixed control in the study.

### 5.3 Predeclared subgroups

Eleven cells were frozen before unsealing, with membership computable from source-side or shared-infrastructure quantities only (per-galaxy statistic: median |Δlog₁₀V|; cell value: mean over member galaxies; "win" = model beats λ\*):

| Cell | N | Model | λ\* | Outcome | Help |
|---|---|---|---|---|---|
| T ≤ 3 | 28 | 0.0454 | 0.0457 | **model wins** | 0.54 |
| T 4–7 | 66 | 0.0493 | 0.0510 | **model wins** | 0.62 |
| T 8–9 | 37 | 0.0834 | 0.0816 | λ\* wins | 0.41 |
| T 10–11 | 44 | 0.1227 | 0.1184 | λ\* wins | 0.23 |
| Q = 1 | 99 | 0.0546 | 0.0558 | **model wins** | 0.62 |
| Q = 2 | 64 | 0.0801 | 0.0772 | λ\* wins | 0.30 |
| Q = 3 | 12 | 0.2060 | 0.2003 | λ\* wins | 0.08 |
| Gas-dominated (w_gas > 0.5) | 32 | 0.0707 | 0.0687 | λ\* wins | 0.41 |
| Bulge-present | 32 | 0.0425 | 0.0434 | **model wins** | 0.59 |
| **S5: dwarfs, gas share > 0.751** | **11** | **0.0834** | **0.0783** | **λ\* wins — registered prediction falsified** | 0.27 |
| S5: dwarfs, gas share ≤ 0.751 | 33 | 0.1358 | 0.1318 | λ\* wins | 0.21 |

The pattern is sharply sector-localized. The radius-dependent coefficient beats the target-fitted constant precisely where the data are best and the source structure is richest — high-quality, bulge-bearing, early-to-mid spirals — demonstrating that a morphology-dependent weak-field coefficient exists in the predicted direction. The model fails precisely in gas-dominated and dwarf systems, and the registered dwarf gas-share prediction (P2′: gas-dominated dwarfs prefer λ → 4/3, frozen threshold 0.7512) is **falsified in both of its predeclared cells**: gas-rich dwarfs prefer coefficients at or below λ\* = 1.156, the opposite sign from the frozen gas-support rule. Under the pre-registered criteria the overall verdict is **PARTIAL (route B)**: full-sample parity plus predeclared subgroup wins, with a falsified registered prediction reported alongside.

### 5.4 Verdict statement

A zero-free-parameter source-geometry model (i) confirms the derived acceleration scale a_S = cH₀/(2π) against the Newtonian baseline at overwhelming significance, with the data's preferred effective scale landing on the empirical a₀ to 0.9%; (ii) reaches 0.45% parity with the best possible fitted global coefficient; (iii) beats that fitted coefficient in the predeclared high-quality spiral and bulge cells, establishing morphology-dependent weak-field structure under seal; and (iv) is decisively rejected in gas-rich dwarfs, falsifying its registered prediction there and localizing the theory's error to the gas-support sector. A successor gas-sector hypothesis, with its own sealed criteria, is registered in §7 of this paper; the present verdict is final and independent of its outcome.

*[Hashes, pack manifests, and per-gate verdict strings: Appendix A. Historical Track 1/Track 2 analyses and their autopsy: Appendix B.]*
