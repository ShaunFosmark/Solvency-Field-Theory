#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R012_racetrack_plus_abundance_rollup_gate.py

V12.10-R012:
Racetrack + Abundance-Proxy Rollup Gate.

This gate rolls up V12.10 R001-R011:

  R001-R009:
    Built and froze the radiation-era formation racetrack:
      radiation + cooling + formation thresholds + disruption + closure adequacy
      => generic ordered sorting / robust-scenario-fragile archetype capacity.

  R010:
    Built toy abundance/capture proxies under multiple budget conventions:
      equal relic occupancy, inverse-mass number, log-tempered number,
      energy capture, robustness-weighted, fragility-suppressed.

  R011:
    Tested those proxy profiles against class-preserving/archetype-preserving nulls:
      budget effects are localized;
      some proxy/null combinations show signal;
      exact abundance profiles remain open;
      no physical budget law is selected.

Purpose:
  - Freeze the current V12.10 status before deeper cosmology.
  - Preserve the real wins:
      * formation racetrack works as toy mechanism
      * lock order is internally stable
      * archetype capacity is present
      * budget conventions separate number-count from energy-density questions
      * class-preserving nulls were run
  - Preserve the hard boundaries:
      * no particle mapping
      * no physical abundance prediction
      * no BBN/CMB/baryon-to-photon claim
      * no GR/Boltzmann closure
"""

from __future__ import annotations

import csv
import json
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, UTC
from pathlib import Path
from typing import List


GATE_ID = "FORCE_V12_10_R012"
TITLE = "V12.10-R012: Racetrack + Abundance-Proxy Rollup Gate"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
SELECTED_SEED = "{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}"
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"


@dataclass
class GateStatus:
    gate: str
    result: str
    survives: str
    boundary: str


@dataclass
class EvidenceItem:
    evidence_id: str
    status: str
    survives: str
    does_not_survive: str


@dataclass
class BudgetStatus:
    scheme_id: str
    r010_result: str
    r011_control_status: str
    safe_interpretation: str
    not_claimed: str


@dataclass
class ClaimBoundary:
    status: str
    claim: str
    reason: str


@dataclass
class NextProgram:
    program_id: str
    title: str
    goal: str
    must_not_do: str


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_racetrack_plus_abundance_rollup_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    gate_status = [
        GateStatus("R001-R004", "FORMATION/DISRUPTION TOY BUILT", "Radiation-era formation, drive, and disruption terms produce meaningful survival sensitivity.", "Dimensionless toy only."),
        GateStatus("R005", "ODE FREEZEOUT TOY BUILT", "Integrated Y_i proxies distinguish robust, fragile, transient, and scenario-dependent outcomes.", "Final Y values are not physical abundances."),
        GateStatus("R006-R008", "COLD-AUDIT / ARCHETYPE CAPACITY FROZEN", "Robust, scenario-dependent, and fragile/transient internal classes exist.", "Exact rho ecology is not null-resistant and not a physical mapping."),
        GateStatus("R009", "RACETRACK ROLLUP FROZEN", "Generic inevitability/sorting result is preserved.", "Specific rho ecology is not claimed."),
        GateStatus("R010", "ABUNDANCE PROXY TOY BUILT", "Multiple budget conventions expose number-count vs energy-density vs relic-occupancy questions.", "No budget convention is selected as physical."),
        GateStatus("R011", "CLASS-PRESERVING NULLS RUN", "Budget effects are localized and some proxy/null combinations show signal.", "Exact abundance profiles remain open; no physical abundance law is selected."),
    ]

    evidence = [
        EvidenceItem(
            "formation_racetrack",
            "SURVIVES_AS_TOY_MECHANISM",
            "Radiation-era cooling plus thresholds/disruption/adequacy generically sorts modes.",
            "Does not by itself identify particles or sectors."
        ),
        EvidenceItem(
            "lock_order",
            "SURVIVES_AS_INTERNAL_ORDER",
            "Mass-amplitude ordering drives hot-to-cold lock chronology.",
            "Monotonic ordering alone is not unique enough for particle claims."
        ),
        EvidenceItem(
            "three_class_archetype_capacity",
            "SURVIVES_AS_SANITY_CAPACITY",
            "Toy contains robust, intermediate/scenario-dependent, and fragile/transient classes.",
            "Exact rho membership in those classes is not null-resistant."
        ),
        EvidenceItem(
            "abundance_budget_split",
            "SURVIVES_AS_QUESTION_SEPARATION",
            "Number-count proxies favor low mass; energy-capture proxies favor high mass; occupancy proxies are distributed.",
            "This does not select a physical abundance law."
        ),
        EvidenceItem(
            "R011_null_controls",
            "MIXED_SCREEN_SIGNAL",
            "Class-preserving nulls localize budget effects and show some local non-null behavior.",
            "Strict physical abundance specificity remains open."
        ),
    ]

    budgets = [
        BudgetStatus(
            "equal_relic_occupancy_proxy",
            "distributed; top=5/3; effective modes about 8.7",
            "class-label null shows local signal, but full tuple shuffles keep high null risk",
            "Good relic-occupancy question-type screen.",
            "Not a physical relic abundance law."
        ),
        BudgetStatus(
            "inverse_mass_number_proxy",
            "high dominance by 1/2; number-count style",
            "dominance largely budget-convention expected",
            "Useful as number-count convention control.",
            "Not a particle count prediction."
        ),
        BudgetStatus(
            "log_tempered_number_proxy",
            "distributed but light-leaning; top=1/2",
            "mild class-label signal but not enough for physical specificity",
            "Useful softened number-style control.",
            "Not an observed abundance profile."
        ),
        BudgetStatus(
            "energy_capture_proxy",
            "high dominance by 2; energy-density style",
            "dominance largely budget-convention expected",
            "Useful energy-capture convention control.",
            "Not a physical energy-density prediction."
        ),
        BudgetStatus(
            "robustness_weighted_proxy",
            "distributed; top=1/2; robust class favored",
            "requires later controls beyond class-preserving nulls",
            "Useful relic-survival weighting screen.",
            "Not a physical survival abundance law."
        ),
        BudgetStatus(
            "fragility_suppressed_proxy",
            "distributed; top=3/2; robust class favored",
            "requires later controls beyond class-preserving nulls",
            "Useful fragility-suppressed screen.",
            "Not a physical decay/lifetime law."
        ),
    ]

    claim_boundary = [
        ClaimBoundary(
            "YES_SCREEN",
            "V12.10 R001-R012 freezes a working formation-racetrack toy program.",
            "The program has formation thresholds, disruption, ODE freezeout proxies, cold-audit classes, and budget-convention controls."
        ),
        ClaimBoundary(
            "YES",
            "The major V12.10 win is inevitability of sorting, not exact rho specificity.",
            "R007/R007B/R009 established that generic racetrack sorting is expected and exact rho ecology is not claimed."
        ),
        ClaimBoundary(
            "YES_SCREEN",
            "R010/R011 separate abundance-style question types.",
            "Number-count, energy-capture, relic-occupancy, robustness-weighted, and fragility-suppressed proxies behave differently."
        ),
        ClaimBoundary(
            "YES_SCREEN",
            "R011 localizes budget-convention effects with class-preserving nulls.",
            "Some local non-null behavior appears, but exact fraction profiles remain open."
        ),
        ClaimBoundary(
            "NO",
            "V12.10 has not predicted physical abundances.",
            "No empirical abundance table, baryon-to-photon ratio, BBN yield, or CMB spectrum is loaded or matched."
        ),
        ClaimBoundary(
            "NO",
            "V12.10 has not mapped rho modes to particles, sectors, or lifetimes.",
            "No charge/color/generation/stability assignment is performed."
        ),
        ClaimBoundary(
            "NO",
            "V12.10 has not selected a physical budget convention or abundance law.",
            "All budget schemes remain question-types and controls."
        ),
        ClaimBoundary(
            "NO",
            "V12.10 has not closed GR/Boltzmann cosmogenesis.",
            "Rates and Y_i are dimensionless screen proxies."
        ),
    ]

    next_program = [
        NextProgram(
            "DEEP_COSMO_R013",
            "Physical Background Replacement Gate",
            "Begin replacing dimensionless x/tau knobs with standard radiation-era scalings H(T), a(T), and thermal threshold variables while keeping SFT mode data frozen.",
            "Do not fit observed abundances or map rho modes to particles."
        ),
        NextProgram(
            "DEEP_COSMO_R014",
            "Interaction / Destruction Term Derivation Gate",
            "Replace ad hoc disruption coefficients with mechanically motivated radiation bath, expansion dilution, and support-ecology terms.",
            "Do not select coefficients from observed abundances."
        ),
        NextProgram(
            "V12_10_PUBLIC_NOTE",
            "Safe V12.10 Formation Racetrack Note",
            "Prepare public-facing language: formation racetrack and abundance-proxy toy screens, with strict no-mapping/no-abundance boundary.",
            "Do not claim particle formation proof, physical abundances, BBN/CMB, or SM mapping."
        ),
    ]

    racetrack_toy_freeze_ready = True
    abundance_proxy_toy_freeze_ready = True
    exact_abundance_profile_open = True
    physical_cosmogenesis_open = True
    no_empirical_data_loaded = True
    no_mapping_performed = True
    no_final_abundance_law_selected = True

    write_csv(out_dir / "V12_10_R012_gate_status.csv", [asdict(x) for x in gate_status])
    write_csv(out_dir / "V12_10_R012_evidence_status.csv", [asdict(x) for x in evidence])
    write_csv(out_dir / "V12_10_R012_budget_status.csv", [asdict(x) for x in budgets])
    write_csv(out_dir / "V12_10_R012_claim_boundary.csv", [asdict(x) for x in claim_boundary])
    write_csv(out_dir / "V12_10_R012_next_program.csv", [asdict(x) for x in next_program])

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "racetrack_toy_freeze_ready": racetrack_toy_freeze_ready,
        "abundance_proxy_toy_freeze_ready": abundance_proxy_toy_freeze_ready,
        "exact_abundance_profile_open": exact_abundance_profile_open,
        "physical_cosmogenesis_open": physical_cosmogenesis_open,
        "no_empirical_data_loaded": no_empirical_data_loaded,
        "no_mapping_performed": no_mapping_performed,
        "no_final_abundance_law_selected": no_final_abundance_law_selected,
        "claim_boundary": [asdict(x) for x in claim_boundary],
        "next_program": [asdict(x) for x in next_program],
    }
    payload_path = out_dir / "V12_10_R012_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Verdict")
    lines.append("")
    lines.append("V12.10 R001-R012 freezes a toy formation-racetrack and abundance-proxy program.")
    lines.append("")
    lines.append("The result is not a physical abundance prediction. The result is a structured toy framework that separates:")
    lines.append("")
    lines.append("- formation sorting / lock order,")
    lines.append("- cold-audit robustness classes,")
    lines.append("- number-count vs energy-density vs occupancy budget conventions,")
    lines.append("- exact fraction profiles, which remain open.")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    for c in claim_boundary:
        lines.append(f"- **{c.status}** — {c.claim} {c.reason}")
    lines.append("")
    lines.append("## Next")
    lines.append("")
    lines.append("The next scientific move is to replace toy background knobs with physical radiation-era scalings, without fitting abundances or mapping rho modes to particles.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_racetrack_plus_abundance_rollup_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R012_gate_status.csv",
        out_dir / "V12_10_R012_evidence_status.csv",
        out_dir / "V12_10_R012_budget_status.csv",
        out_dir / "V12_10_R012_claim_boundary.csv",
        out_dir / "V12_10_R012_next_program.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R012 RESULT ===")
    print("V12.10-R012 COMPLETE")
    print("VERDICT: RACETRACK + ABUNDANCE-PROXY ROLLUP PASS / TOY PROGRAM FROZEN, PHYSICAL COSMOGENESIS OPEN")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("gate_status_generated: True")
    print("evidence_status_generated: True")
    print("budget_status_generated: True")
    print("claim_boundary_generated: True")
    print("next_program_generated: True")
    print(f"racetrack_toy_freeze_ready: {racetrack_toy_freeze_ready}")
    print(f"abundance_proxy_toy_freeze_ready: {abundance_proxy_toy_freeze_ready}")
    print(f"exact_abundance_profile_open: {exact_abundance_profile_open}")
    print(f"physical_cosmogenesis_open: {physical_cosmogenesis_open}")
    print("no_empirical_abundances_loaded: True")
    print("no_baryon_to_photon_matching_performed: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_abundance_claimed: True")
    print(f"selected_seed: {SELECTED_SEED}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("EVIDENCE_STATUS:")
    for e in evidence:
        print(f"  {e.evidence_id} | status={e.status} | survives={e.survives} | boundary={e.does_not_survive}")
    print("BUDGET_STATUS:")
    for b in budgets:
        print(f"  {b.scheme_id} | R010={b.r010_result} | R011={b.r011_control_status} | safe={b.safe_interpretation}")
    print("CLAIM_BOUNDARY:")
    for c in claim_boundary:
        print(f"  {c.status} | {c.claim} -- {c.reason}")
    print("NEXT_PROGRAM:")
    for n in next_program:
        print(f"  {n.program_id} | {n.title} | goal={n.goal} | must_not={n.must_not_do}")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: DEEP_COSMO_R013_physical_background_replacement_gate_or_V12_10_public_note")
    print("=== END COPY/PASTE V12.10-R012 RESULT ===")


if __name__ == "__main__":
    main()
