# V12.10-R008: Qualitative Stability / Lifetime Archetype Sanity Gate

## Result

R008 checks whether the V12.10 toy contains qualitative capacity for robust, scenario-dependent, and fragile/transient relic archetypes.

- Robust modes: `1/2, 4/3, 3/2, 5/3, 2`
- Scenario-dependent modes: `2/3, 3/4, 5/4`
- Fragile/transient modes: `1`

No rho-to-particle mapping is performed.