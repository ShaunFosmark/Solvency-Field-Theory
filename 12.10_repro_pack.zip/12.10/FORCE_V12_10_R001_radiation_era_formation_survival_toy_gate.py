#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R001_radiation_era_formation_survival_toy_gate.py

V12.10-R001 broad toy:
Radiation-era formation / survival sandbox for the V12.8/V12.9 nine-mode seed.

Purpose:
  - Adapt the frozen V12.8/V12.9 mode data into a toy cosmogenesis screen.
  - Model a dimensionless radiation-dominated "twirl/capture vs disruption" survival score.
  - Produce a mode-by-mode formation/lock-in/recombination-audit ledger.
  - Preserve strict claim boundaries:
      * toy screen only
      * no empirical abundance loading
      * no particle mapping
      * no BBN/CMB prediction
      * no final cosmogenesis law

This is intentionally a broad first toy, not a physical Boltzmann/GR calculation.
"""

from __future__ import annotations

import csv
import json
import math
import hashlib
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
from fractions import Fraction
from pathlib import Path
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R001"
FREEZE_PARENT = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R001: Radiation-Era Formation / Survival Toy Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

# R126 primary fixed-point feedback preview values, used as raw V12.9 mass-amplitude baseline.
# These are dimensionless screen values, not physical masses.
RAW_FEEDBACK = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

# R151 force-shape-topology screen candidates. Used here only as internal susceptibility proxies.
# Not physical quantum numbers or particle identities.
G_FORCE_SHAPE_TOPOLOGY = {
    "1/2": 5.7426406871,
    "2/3": 2.03823702542,
    "3/4": 1.0,
    "1":   8.12132034355,
    "5/4": 1.20454951288,
    "4/3": 1.256762611,
    "3/2": 2.55433304545,
    "5/3": 1.39089397103,
    "2":   10.1516504294,
}

# R137 transverse phase measure exponent candidate.
BETA_6PI = 0.299699441600

# R132/R133 p=5 self-energy rent candidate.
RENT_POWER = 5.0

# Toy timeline:
# x = log10(T / E_lightest_proxy), where E_lightest_proxy is the lightest-mode screen scale.
# x=0 is the lightest-mode formation threshold in this dimensionless toy.
# x=-4 is a cold "recombination audit" marker: photons are decoupled in the toy ledger;
# this is NOT a physical recombination temperature calculation.
X_HOT = 7.0
X_COLD = -4.0
N_STEPS = 1101
RECOMBINATION_AUDIT_X = -4.0
BBN_PROXY_X = -1.0

# Radiation active source factor: in GR-safe language, radiation has p=rho/3,
# so rho+3p = 2rho in the acceleration-source combination. This is a screen factor only.
RADIATION_ACTIVE_GRAVITY_FACTOR = 2.0


@dataclass
class Mode:
    rho_str: str
    rho: float
    m: int
    N: int
    denominator_class: str
    occupancy_vector: Tuple[int, int, int]
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    radiation_coupling_proxy: float
    tightness_proxy: float


@dataclass
class ModeResult:
    rho: str
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    peak_x: float
    peak_temperature_over_lightest: float
    max_survival_score: float
    first_lock_x: str
    first_lock_temperature_over_lightest: str
    capture_fraction_proxy: float
    recombination_survival_audit: str
    failure_or_status: str


def frac_value(s: str) -> Fraction:
    return Fraction(s)


def denominator_class(N: int) -> str:
    if N == 1:
        return "integer_base_cadence"
    if N == 2:
        return "binary_no_overwrite_class"
    if N == 3:
        return "tri_slot_normal_bundle_class"
    if N == 4:
        return "full_3plus1_slot_capacity_class"
    return f"denominator_{N}_outside_v12_8_slot_cap"


def occupancy_vector(m: int, N: int) -> Tuple[int, int, int]:
    """Minimal 3-normal occupancy toy used in R147 style.

    Fill up to three normal slots as evenly as possible, using total winding count m.
    N is still retained separately as the cadence denominator/slot class.
    """
    slots = min(3, max(1, N))
    base = m // slots
    rem = m % slots
    occ = [base + (1 if i < rem else 0) for i in range(slots)]
    while len(occ) < 3:
        occ.append(0)
    return tuple(occ[:3])


def support_ecology(rho_str: str) -> str:
    if rho_str in {"5/4", "5/3"}:
        return "virtual_support_dependent"
    if rho_str == "2":
        return "boundary_assisted"
    return "clean_internal"


def build_modes() -> List[Mode]:
    min_raw = min(RAW_FEEDBACK.values())
    raw_at_identity = RAW_FEEDBACK["1"]
    min_g = min(G_FORCE_SHAPE_TOPOLOGY.values())

    modes: List[Mode] = []
    for s in SELECTED_SEED_STR:
        f = frac_value(s)
        rho = float(f)
        m, N = f.numerator, f.denominator

        raw = RAW_FEEDBACK[s]
        raw_norm = raw / min_raw
        bridge = raw_norm ** (1.0 + BETA_6PI)

        # Adequacy ratio A = available focusing / required p=5 self-energy rent,
        # normalized so rho=1 is exactly break-even in the R132/R133 convention.
        adequacy = raw / (raw_at_identity * (rho ** RENT_POWER))

        g_norm = G_FORCE_SHAPE_TOPOLOGY[s] / min_g
        susceptibility = math.sqrt(g_norm)

        # Toy radiation coupling: higher denominator, virtual support, and boundary assistance
        # are treated as more exposed to radiation/plasma disruption.
        ecology = support_ecology(s)
        rad_coupling = 1.0 + 0.12 * (N - 1)
        if ecology == "virtual_support_dependent":
            rad_coupling += 0.18
        if ecology == "boundary_assisted":
            rad_coupling += 0.25

        tightness = math.sqrt(bridge / max(1.0, max((RAW_FEEDBACK[x] / min_raw) ** (1.0 + BETA_6PI) for x in SELECTED_SEED_STR)))

        modes.append(
            Mode(
                rho_str=s,
                rho=rho,
                m=m,
                N=N,
                denominator_class=denominator_class(N),
                occupancy_vector=occupancy_vector(m, N),
                support_ecology=ecology,
                raw_feedback=raw,
                mass_bridge=bridge,
                adequacy_p5=adequacy,
                force_shape_susceptibility=susceptibility,
                radiation_coupling_proxy=rad_coupling,
                tightness_proxy=tightness,
            )
        )
    return modes


def timeline_grid() -> List[float]:
    return [X_HOT + (X_COLD - X_HOT) * i / (N_STEPS - 1) for i in range(N_STEPS)]


def survival_score(mode: Mode, x: float, scenario: str = "baseline") -> float:
    """Dimensionless toy survival/capture score.

    x = log10(T / E_lightest_proxy).
    logM = log10(M_i / M_lightest).

    The score is intentionally schematic:
      - formation window peaks near T ~ M_i
      - radiation twirl/capture drive is active during hot radiation era
      - overheat disruption penalizes T >> M_i
      - Hubble/radiation tearing penalizes early high-T environment
      - closure adequacy and force-shape susceptibility help persistence

    This is a sandbox equation, not a physical Boltzmann equation.
    """
    logM = math.log10(max(mode.mass_bridge, 1e-300))
    dx = x - logM

    # Formation window: broad enough for a cooling-era capture band.
    sigma = 1.15
    threshold_window = math.exp(-0.5 * (dx / sigma) ** 2)

    # Thermal availability: suppressed below threshold.
    thermal_availability = 1.0 / (1.0 + math.exp(-4.0 * dx))

    # Radiation-driven twirl source. Factor 2 is the radiation active-gravity screen.
    active = RADIATION_ACTIVE_GRAVITY_FACTOR
    if scenario == "no_radiation_double_burden":
        active = 1.0

    twirl_background = active * (1.0 + 0.12 * max(x, 0.0))

    bridge_mass_factor = mode.mass_bridge ** 0.045
    if scenario == "no_bridge_mass_amplitude":
        # Use weaker raw feedback range instead of bridged amplitude.
        min_raw = min(RAW_FEEDBACK.values())
        bridge_mass_factor = (mode.raw_feedback / min_raw) ** 0.045

    adequacy_factor = mode.adequacy_p5 ** 0.62
    if scenario == "no_closure_adequacy":
        adequacy_factor = 1.0

    force_factor = mode.force_shape_susceptibility ** 0.35
    if scenario == "no_shape_force_susceptibility":
        force_factor = 1.0

    formation_drive = twirl_background * threshold_window * thermal_availability * bridge_mass_factor * adequacy_factor * force_factor

    # Disruptive terms:
    # Overheat: T far above the mode threshold smashes/turbulently erases nascent vortices.
    overheat = max(dx, 0.0)
    overheat_disruption = 0.42 * (overheat ** 2) * mode.radiation_coupling_proxy / max(mode.adequacy_p5, 0.1) ** 0.25

    # Hubble tearing / dilution: strongest at high x, mildly sensitive to tightness.
    hubble_tearing = 0.22 * (10.0 ** (0.105 * max(x, 0.0))) * (0.85 + 0.75 * mode.tightness_proxy)

    # Photon/radiation bath disruption: declines as cooling proceeds.
    photon_disruption = 0.18 * (10.0 ** (0.075 * max(x, 0.0))) * mode.radiation_coupling_proxy

    # Closure rent stress: inverse adequacy. Adequacy already helps in numerator,
    # but this keeps barely adequate modes close to threshold.
    closure_rent = 1.0 / max(mode.adequacy_p5, 1e-9)
    if scenario == "no_closure_adequacy":
        closure_rent = 1.0

    disruption = closure_rent + overheat_disruption + hubble_tearing + photon_disruption

    return formation_drive / max(disruption, 1e-12)


def run_scenario(modes: List[Mode], scenario: str = "baseline") -> Tuple[List[ModeResult], Dict[str, float]]:
    xs = timeline_grid()
    results: List[ModeResult] = []

    for mode in modes:
        scores = [survival_score(mode, x, scenario=scenario) for x in xs]
        max_score = max(scores)
        peak_idx = scores.index(max_score)
        peak_x = xs[peak_idx]

        locked_indices = [i for i, sc in enumerate(scores) if sc >= 1.0]
        if locked_indices:
            first_i = locked_indices[0]  # earliest in cooling order, since xs descends hot->cold
            first_lock_x = xs[first_i]
            first_lock_temp = 10.0 ** first_lock_x
            lock_str = f"{first_lock_x:.4g}"
            lock_temp_str = f"{first_lock_temp:.6g}"
        else:
            first_lock_x = None
            first_lock_temp = None
            lock_str = "none"
            lock_temp_str = "none"

        # Integral of super-threshold score as capture proxy.
        # This is a dimensionless formation/capture opportunity measure, not an abundance prediction.
        dx_abs = abs((X_COLD - X_HOT) / (N_STEPS - 1))
        excess_integral = sum(max(0.0, sc - 1.0) * dx_abs for sc in scores)
        capture_proxy = excess_integral / (1.0 + excess_integral)

        survives = (first_lock_x is not None) and mode.adequacy_p5 >= 1.0
        if survives:
            audit = "SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN"
            status = "locked_before_cold_audit_in_toy"
        elif max_score >= 1.0 and mode.adequacy_p5 < 1.0:
            audit = "LOCK_ATTEMPT_BUT_RENT_FAILS"
            status = "formation_window_present_but_closure_adequacy_below_one"
        else:
            audit = "NO_LOCK_IN_TOY"
            if max_score < 1.0:
                status = "formation_drive_never_exceeds_disruption"
            else:
                status = "unknown_toy_failure"

        results.append(
            ModeResult(
                rho=mode.rho_str,
                m=mode.m,
                N=mode.N,
                denominator_class=mode.denominator_class,
                support_ecology=mode.support_ecology,
                raw_feedback=mode.raw_feedback,
                mass_bridge=mode.mass_bridge,
                log10_mass_bridge=math.log10(max(mode.mass_bridge, 1e-300)),
                adequacy_p5=mode.adequacy_p5,
                force_shape_susceptibility=mode.force_shape_susceptibility,
                peak_x=peak_x,
                peak_temperature_over_lightest=10.0 ** peak_x,
                max_survival_score=max_score,
                first_lock_x=lock_str,
                first_lock_temperature_over_lightest=lock_temp_str,
                capture_fraction_proxy=capture_proxy,
                recombination_survival_audit=audit,
                failure_or_status=status,
            )
        )

    summary = {
        "scenario": scenario,
        "locked_count": sum(1 for r in results if r.first_lock_x != "none"),
        "survive_to_recombination_audit_count": sum(1 for r in results if r.recombination_survival_audit == "SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN"),
        "mean_max_survival_score": sum(r.max_survival_score for r in results) / len(results),
        "max_capture_fraction_proxy": max(r.capture_fraction_proxy for r in results),
        "mean_capture_fraction_proxy": sum(r.capture_fraction_proxy for r in results) / len(results),
    }
    return results, summary


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_radiation_era_formation_survival_toy_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    modes = build_modes()
    baseline_results, baseline_summary = run_scenario(modes, "baseline")

    scenarios = [
        "baseline",
        "no_radiation_double_burden",
        "no_bridge_mass_amplitude",
        "no_closure_adequacy",
        "no_shape_force_susceptibility",
    ]

    scenario_rows = []
    scenario_result_lookup = {}
    for sc in scenarios:
        res, summ = run_scenario(modes, sc)
        scenario_result_lookup[sc] = res
        scenario_rows.append(summ)

    # Save mode feature ledger.
    feature_rows = []
    for m in modes:
        row = asdict(m)
        row["occupancy_vector"] = str(m.occupancy_vector)
        feature_rows.append(row)

    baseline_rows = [asdict(r) for r in baseline_results]

    # Timeline markers.
    timeline_rows = [
        {
            "marker": "hot_start",
            "x_log10_T_over_lightest": X_HOT,
            "interpretation": "dimensionless hot radiation-storm start for toy sweep",
        },
        {
            "marker": "BBN_proxy_marker",
            "x_log10_T_over_lightest": BBN_PROXY_X,
            "interpretation": "toy marker only; no nucleosynthesis prediction performed",
        },
        {
            "marker": "recombination_audit_marker",
            "x_log10_T_over_lightest": RECOMBINATION_AUDIT_X,
            "interpretation": "cold visibility/decoupling audit marker; not particle birth",
        },
    ]

    write_csv(out_dir / "V12_10_R001_mode_features.csv", feature_rows)
    write_csv(out_dir / "V12_10_R001_baseline_survival_ledger.csv", baseline_rows)
    write_csv(out_dir / "V12_10_R001_scenario_controls.csv", scenario_rows)
    write_csv(out_dir / "V12_10_R001_timeline_markers.csv", timeline_rows)

    # JSON payload.
    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_freeze": FREEZE_PARENT,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "toy_equation": {
            "x": "log10(T/E_lightest_proxy)",
            "survival_score": "formation_drive / (closure_rent + overheat_disruption + hubble_tearing + photon_disruption)",
            "radiation_active_gravity_factor": RADIATION_ACTIVE_GRAVITY_FACTOR,
            "claim_boundary": "dimensionless toy screen, not a physical Boltzmann/GR abundance calculation",
        },
        "baseline_summary": baseline_summary,
        "scenario_controls": scenario_rows,
        "claim_boundary": [
            {"claim": "R001 runs a radiation-era formation/survival toy using V12.8/V12.9 seed data.", "status": "YES_SCREEN"},
            {"claim": "R001 proves particles formed from photons at recombination.", "status": "NO"},
            {"claim": "R001 predicts physical abundances, baryon-to-photon ratio, or the CMB spectrum.", "status": "NO"},
            {"claim": "R001 maps rho modes to Standard Model particles.", "status": "NO"},
            {"claim": "R001 closes GR/Boltzmann cosmogenesis.", "status": "NO"},
        ],
    }
    payload_path = out_dir / "V12_10_R001_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # Markdown summary.
    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append(f"Parent freeze: `{FREEZE_PARENT}`")
    lines.append("")
    lines.append("## Purpose")
    lines.append("")
    lines.append("This gate runs the first broad V12.10 toy model for radiation-era mode formation and survival filtering.")
    lines.append("It uses the V12.8 nine-mode seed and V12.9 mass-amplitude / adequacy / shape-label screens as internal inputs.")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("- This is a dimensionless formation/survival toy.")
    lines.append("- It does not model physical abundances, BBN, CMB spectra, or recombination microphysics.")
    lines.append("- Recombination is treated as a cold visibility/decoupling audit marker, not as particle birth.")
    lines.append("- No empirical abundances or Standard Model particle mappings are loaded.")
    lines.append("")
    lines.append("## Baseline scenario summary")
    lines.append("")
    for k, v in baseline_summary.items():
        lines.append(f"- `{k}`: `{v}`")
    lines.append("")
    lines.append("## Baseline mode survival ledger")
    lines.append("")
    lines.append("| rho | m | N | class | ecology | log10M | adequacy | max_score | first_lock_x | capture_proxy | recombination_audit |")
    lines.append("| --- | --- | --- | --- | --- | ---: | ---: | ---: | --- | ---: | --- |")
    for r in baseline_results:
        lines.append(
            f"| {r.rho} | {r.m} | {r.N} | {r.denominator_class} | {r.support_ecology} | "
            f"{r.log10_mass_bridge:.3f} | {r.adequacy_p5:.3f} | {r.max_survival_score:.3f} | "
            f"{r.first_lock_x} | {r.capture_fraction_proxy:.3f} | {r.recombination_survival_audit} |"
        )
    lines.append("")
    lines.append("## Scenario controls")
    lines.append("")
    lines.append("| scenario | locked_count | survive_to_recombination_audit_count | mean_max_score | mean_capture_proxy |")
    lines.append("| --- | ---: | ---: | ---: | ---: |")
    for row in scenario_rows:
        lines.append(
            f"| {row['scenario']} | {row['locked_count']} | {row['survive_to_recombination_audit_count']} | "
            f"{row['mean_max_survival_score']:.3f} | {row['mean_capture_fraction_proxy']:.3f} |"
        )
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    # Pack zip.
    pack_path = here / f"{GATE_ID}_radiation_era_formation_survival_toy_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R001_mode_features.csv",
        out_dir / "V12_10_R001_baseline_survival_ledger.csv",
        out_dir / "V12_10_R001_scenario_controls.csv",
        out_dir / "V12_10_R001_timeline_markers.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R001 RESULT ===")
    print("V12.10-R001 COMPLETE")
    print("VERDICT: RADIATION-ERA FORMATION/SURVIVAL TOY PASS / MODE SURVIVAL LEDGER GENERATED, PHYSICAL ABUNDANCES OPEN")
    print(f"PARENT_FREEZE: {FREEZE_PARENT}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("timeline_generated: True")
    print("radiation_active_gravity_factor_used: True")
    print(f"radiation_active_gravity_factor: {RADIATION_ACTIVE_GRAVITY_FACTOR}")
    print("seed_modes_loaded: True")
    print("mass_amplitude_loaded_from_v12_9: True")
    print("closure_adequacy_loaded: True")
    print("shape_force_susceptibility_loaded: True")
    print("survival_scores_computed: True")
    print("recombination_audit_generated: True")
    print("scenario_controls_generated: True")
    print("no_empirical_abundances_loaded: True")
    print("no_baryon_to_photon_matching_performed: True")
    print("no_CMB_spectrum_prediction_performed: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_cosmogenesis_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("BASELINE_SUMMARY:")
    for k, v in baseline_summary.items():
        print(f"  {k}: {v}")
    print("MODE_SURVIVAL_LEDGER:")
    for r in baseline_results:
        print(
            f"  rho={r.rho} | m={r.m} | N={r.N} | log10M={r.log10_mass_bridge:.4g} | "
            f"A_p5={r.adequacy_p5:.4g} | peak_x={r.peak_x:.4g} | maxS={r.max_survival_score:.4g} | "
            f"first_lock_x={r.first_lock_x} | capture_proxy={r.capture_fraction_proxy:.4g} | "
            f"audit={r.recombination_survival_audit}"
        )
    print("SCENARIO_CONTROLS:")
    for row in scenario_rows:
        print(
            f"  {row['scenario']} | locked={row['locked_count']} | "
            f"survive_audit={row['survive_to_recombination_audit_count']} | "
            f"mean_maxS={row['mean_max_survival_score']:.4g} | "
            f"mean_capture={row['mean_capture_fraction_proxy']:.4g}"
        )
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R001 runs a dimensionless radiation-era formation/survival toy. -- Uses V12.8/V12.9 seed, mass-amplitude, adequacy, and shape-label screens.")
    print("  YES_SCREEN | Radiation active-gravity factor 2 is used as a toy source modifier. -- It is a screen factor, not a literal 2x expansion claim.")
    print("  NO | R001 proves particles formed from photons at recombination. -- Recombination is treated only as a cold visibility/decoupling audit marker.")
    print("  NO | R001 predicts physical abundances, baryon-to-photon ratio, BBN, or CMB spectra. -- No empirical abundance/CMB data are loaded.")
    print("  NO | R001 maps rho modes to Standard Model particles. -- Modes remain internal V12.8/V12.9 seed modes.")
    print("  NO | R001 closes GR/Boltzmann cosmogenesis. -- This is a broad toy sandbox.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: V12_10_R002_timeline_background_calibration_gate_or_V12_10_R003_formation_drive_refinement_gate")
    print("=== END COPY/PASTE V12.10-R001 RESULT ===")


if __name__ == "__main__":
    main()
