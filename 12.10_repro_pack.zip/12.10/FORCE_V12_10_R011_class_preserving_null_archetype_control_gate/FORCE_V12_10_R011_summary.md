# V12.10-R011: Class-Preserving Null / Archetype Control Gate

## Result

- Class-preserving nulls generated: `True`
- Any proxy null resistance: `True`
- Budget convention dominance confirmed: `True`
- Exact fraction profiles not claimed: `True`

## Rollup

| scheme | null family | p top>=obs | p eff<=obs | top match | interpretation |
| --- | --- | ---: | ---: | ---: | --- |
| equal_relic_occupancy_proxy | class_tuple_shuffle | 1 | 1 | 0.1 | Null risk remains; profile should not be treated as a prediction. |
| equal_relic_occupancy_proxy | class_label_shuffle | 0.001664 | 0.001664 | 0 | Some profile structure is less common under this class-preserving null, but remains toy-screen evidence only. |
| equal_relic_occupancy_proxy | within_class_Y_shuffle | 1 | 1 | 0.175 | Null risk remains; profile should not be treated as a prediction. |
| equal_relic_occupancy_proxy | class_jitter | 0.8303 | 0.7504 | 0.4167 | Null risk remains; profile should not be treated as a prediction. |
| inverse_mass_number_proxy | class_tuple_shuffle | 0.09983 | 0.06656 | 1 | Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence. |
| inverse_mass_number_proxy | class_label_shuffle | 0.08819 | 0.06988 | 1 | Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence. |
| inverse_mass_number_proxy | within_class_Y_shuffle | 0.7388 | 0.6689 | 1 | Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence. |
| inverse_mass_number_proxy | class_jitter | 0.5075 | 0.5275 | 1 | Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence. |
| log_tempered_number_proxy | class_tuple_shuffle | 0.1947 | 0.4942 | 0.8967 | Top mode is common under nulls; exact proxy profile is not specific. |
| log_tempered_number_proxy | class_label_shuffle | 0.04326 | 0.5241 | 0.955 | Some profile structure is less common under this class-preserving null, but remains toy-screen evidence only. |
| log_tempered_number_proxy | within_class_Y_shuffle | 0.6889 | 0.7188 | 1 | Top mode is common under nulls; exact proxy profile is not specific. |
| log_tempered_number_proxy | class_jitter | 0.4676 | 0.5491 | 1 | Top mode is common under nulls; exact proxy profile is not specific. |
| energy_capture_proxy | class_tuple_shuffle | 0.574 | 0.5541 | 1 | Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence. |
| energy_capture_proxy | class_label_shuffle | 0.6156 | 0.5724 | 1 | Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence. |
| energy_capture_proxy | within_class_Y_shuffle | 0.7105 | 0.6955 | 1 | Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence. |
| energy_capture_proxy | class_jitter | 0.4859 | 0.4775 | 1 | Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence. |
| robustness_weighted_proxy | class_tuple_shuffle | 1 | 0.985 | 0.105 | Null risk remains; profile should not be treated as a prediction. |
| robustness_weighted_proxy | class_label_shuffle | 0.001664 | 0.001664 | 0.5317 | Some profile structure is less common under this class-preserving null, but remains toy-screen evidence only. |
| robustness_weighted_proxy | within_class_Y_shuffle | 1 | 0.9501 | 0.2283 | Null risk remains; profile should not be treated as a prediction. |
| robustness_weighted_proxy | class_jitter | 0.8835 | 0.6223 | 0.2867 | Null risk remains; profile should not be treated as a prediction. |
| fragility_suppressed_proxy | class_tuple_shuffle | 1 | 0.9484 | 0.1017 | Null risk remains; profile should not be treated as a prediction. |
| fragility_suppressed_proxy | class_label_shuffle | 0.001664 | 0.001664 | 0 | Some profile structure is less common under this class-preserving null, but remains toy-screen evidence only. |
| fragility_suppressed_proxy | within_class_Y_shuffle | 1 | 0.9767 | 0.2017 | Null risk remains; profile should not be treated as a prediction. |
| fragility_suppressed_proxy | class_jitter | 0.9002 | 0.6522 | 0.365 | Null risk remains; profile should not be treated as a prediction. |

## Claim boundary

- R011 tests toy proxy profiles against class-preserving nulls.
- R011 does not predict physical abundances, BBN yields, CMB spectra, or particle identities.