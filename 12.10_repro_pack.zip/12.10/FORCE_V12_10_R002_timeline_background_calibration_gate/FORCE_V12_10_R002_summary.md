# V12.10-R002: Timeline / Background Calibration Gate

## Claim boundary

R002 is a timeline/background calibration screen. It does not load empirical abundances, BBN yields, CMB data, or particle mappings.

## Main calibration flags

- radiation_factor_informative: `True`
- sweep_survival_varies: `True`
- partial_survival_windows_present: `True`
- lock_order_stable: `True`
- sweep_survivor_count_range: `5..9`

## Named controls

| scenario | survivors | failed modes | order score | mean maxS | mean capture |
| --- | ---: | --- | ---: | ---: | ---: |
| baseline_R001_reproduction | 9 | none | 1.000 | 6.132 | 0.645 |
| control_no_radiation_double_burden | 7 | 2/3, 3/4 | 1.000 | 3.066 | 0.352 |
| control_no_bridge_mass_amplitude | 9 | none | 1.000 | 5.561 | 0.629 |
| control_no_closure_adequacy | 9 | none | 1.000 | 1.693 | 0.322 |
| control_no_shape_force_susceptibility | 9 | none | 1.000 | 4.888 | 0.574 |
| control_high_disruption | 9 | none | 1.000 | 4.766 | 0.570 |
| control_low_disruption | 9 | none | 1.000 | 7.767 | 0.700 |
| control_narrow_formation_window | 9 | none | 1.000 | 5.835 | 0.598 |

## Phase threshold ledger

| rho | m | N | log10M | threshold phase | hot margin | cold audit margin |
| --- | ---: | ---: | ---: | --- | ---: | ---: |
| 1/2 | 1 | 2 | 0.000 | cooling_late_lock_window | 7.000 | 4.000 |
| 2/3 | 2 | 3 | 0.744 | cooling_late_lock_window | 6.256 | 4.744 |
| 3/4 | 3 | 4 | 1.066 | cooling_late_lock_window | 5.934 | 5.066 |
| 1 | 1 | 1 | 1.774 | cooling_late_lock_window | 5.226 | 5.774 |
| 5/4 | 5 | 4 | 2.756 | hot_formation_lock_window | 4.244 | 6.756 |
| 4/3 | 4 | 3 | 3.039 | hot_formation_lock_window | 3.961 | 7.039 |
| 3/2 | 3 | 2 | 3.645 | hot_formation_lock_window | 3.355 | 7.645 |
| 5/3 | 5 | 3 | 4.417 | hot_formation_lock_window | 2.583 | 8.417 |
| 2 | 2 | 1 | 5.531 | hot_smash_transient | 1.469 | 9.531 |