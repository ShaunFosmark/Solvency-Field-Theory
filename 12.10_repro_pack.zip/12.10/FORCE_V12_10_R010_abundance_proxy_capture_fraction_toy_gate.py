#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R010_abundance_proxy_capture_fraction_toy_gate.py

V12.10-R010:
Abundance Proxy / Capture Fraction Toy Gate.

R009 froze the honest V12.10 formation-racetrack result:
  - radiation-era cooling generically sorts modes
  - exact rho ecology is not claimed
  - three-class archetype capacity exists
  - abundance proxy may be attempted only as a toy screen

R010 asks:
  Given the R005/R006 integrated ODE toy histories, can we construct relative
  capture / relic-fraction proxies without empirical abundance data?

Important:
  These are NOT physical abundances.
  These are NOT baryon-to-photon predictions.
  These are NOT BBN/CMB predictions.
  These do NOT map rho modes to Standard Model particles.
  These do NOT close GR/Boltzmann cosmogenesis.

R010 deliberately reports multiple budget conventions:
  - equal relic occupancy proxy
  - inverse-mass number proxy
  - log-tempered number proxy
  - energy-capture proxy
  - robustness-weighted proxy
  - fragility-suppressed proxy

The point is to see which abundance-style questions are even well-posed before
any empirical comparison or physical mapping.
"""

from __future__ import annotations

import csv
import json
import math
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
from fractions import Fraction
from pathlib import Path
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R010"
PARENT_GATE = "FORCE_V12_10_R009"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R010: Abundance Proxy / Capture Fraction Toy Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

RAW_FEEDBACK = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

G_FORCE_SHAPE_TOPOLOGY = {
    "1/2": 5.7426406871,
    "2/3": 2.03823702542,
    "3/4": 1.0,
    "1":   8.12132034355,
    "5/4": 1.20454951288,
    "4/3": 1.256762611,
    "3/2": 2.55433304545,
    "5/3": 1.39089397103,
    "2":   10.1516504294,
}

BETA_6PI = 0.299699441600
RENT_POWER = 5.0
X_HOT = 7.0
X_COLD = -4.0
N_STEPS = 2201


@dataclass
class Mode:
    rho_str: str
    rho: float
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    radiation_coupling_proxy: float
    tightness_proxy: float


@dataclass
class ODEScenario:
    scenario_id: str
    family: str
    radiation_factor: float
    overheat_coeff: float
    hubble_coeff: float
    photon_coeff: float
    denominator_weight: float
    ecology_weight: float
    tightness_weight: float
    hot_smash_extra: float
    formation_rate_scale: float
    destruction_rate_scale: float
    cooling_clock_scale: float
    freeze_threshold: float
    notes: str


@dataclass
class ModeAggregate:
    rho: str
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    baseline_finalY: float
    mean_finalY: float
    min_finalY: float
    max_finalY: float
    mean_peakY: float
    robust_fraction: float
    fragile_fraction: float
    mean_freeze_x: float
    cold_audit_class: str


@dataclass
class BudgetScheme:
    scheme_id: str
    description: str
    weight_formula: str
    selected_for_physics: bool


@dataclass
class SchemeSummary:
    scheme_id: str
    top_mode: str
    top_fraction: float
    effective_mode_count: float
    robust_class_fraction: float
    scenario_dependent_class_fraction: float
    fragile_class_fraction: float
    low_mass_half_fraction: float
    high_mass_half_fraction: float
    dominance_warning: str
    interpretation: str


def frac_value(s: str) -> Fraction:
    return Fraction(s)


def denominator_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, f"denominator_{N}_outside_v12_8_slot_cap")


def support_ecology(rho_str: str) -> str:
    if rho_str in {"5/4", "5/3"}:
        return "virtual_support_dependent"
    if rho_str == "2":
        return "boundary_assisted"
    return "clean_internal"


def build_modes() -> List[Mode]:
    min_raw = min(RAW_FEEDBACK.values())
    raw_at_identity = RAW_FEEDBACK["1"]
    min_g = min(G_FORCE_SHAPE_TOPOLOGY.values())

    bridges = {}
    for s in SELECTED_SEED_STR:
        raw_norm = RAW_FEEDBACK[s] / min_raw
        bridges[s] = raw_norm ** (1.0 + BETA_6PI)
    max_bridge = max(bridges.values())

    modes = []
    for s in SELECTED_SEED_STR:
        f = frac_value(s)
        rho = float(f)
        m, N = f.numerator, f.denominator
        ecology = support_ecology(s)
        base_rad = 1.0 + 0.12 * (N - 1)
        if ecology == "virtual_support_dependent":
            base_rad += 0.18
        if ecology == "boundary_assisted":
            base_rad += 0.25

        bridge = bridges[s]
        modes.append(Mode(
            rho_str=s,
            rho=rho,
            m=m,
            N=N,
            denominator_class=denominator_class(N),
            support_ecology=ecology,
            raw_feedback=RAW_FEEDBACK[s],
            mass_bridge=bridge,
            log10_mass_bridge=math.log10(max(bridge, 1e-300)),
            adequacy_p5=RAW_FEEDBACK[s] / (raw_at_identity * (rho ** RENT_POWER)),
            force_shape_susceptibility=math.sqrt(G_FORCE_SHAPE_TOPOLOGY[s] / min_g),
            radiation_coupling_proxy=base_rad,
            tightness_proxy=math.sqrt(bridge / max_bridge),
        ))
    return modes


def build_scenarios() -> List[ODEScenario]:
    base = dict(
        radiation_factor=2.0,
        overheat_coeff=0.55,
        hubble_coeff=0.22,
        photon_coeff=0.18,
        denominator_weight=0.0,
        ecology_weight=0.0,
        tightness_weight=0.0,
        hot_smash_extra=0.0,
        formation_rate_scale=0.95,
        destruction_rate_scale=0.26,
        cooling_clock_scale=1.0,
        freeze_threshold=0.22,
    )
    return [
        ODEScenario("baseline_ODE_R003_R004", "baseline", **base, notes="Baseline cold-audit reference."),
        ODEScenario("fast_cooling_less_reaction_time", "cooling_clock", **{**base, "cooling_clock_scale":0.55}, notes="Fast cooling."),
        ODEScenario("slow_cooling_more_reaction_time", "cooling_clock", **{**base, "cooling_clock_scale":1.8}, notes="Slow cooling."),
        ODEScenario("strong_photon_disruption_ODE", "radiation_disruption", **{**base, "photon_coeff":0.52, "destruction_rate_scale":0.34}, notes="Photon disruption."),
        ODEScenario("denominator_ecology_disruption_ODE", "radiation_disruption", **{**base, "photon_coeff":0.40, "denominator_weight":0.85, "ecology_weight":0.85, "destruction_rate_scale":0.34}, notes="Denominator/ecology disruption."),
        ODEScenario("no_radiation_double_burden_ODE", "radiation_drive_control", **{**base, "radiation_factor":1.0}, notes="Radiation active-gravity source removed."),
        ODEScenario("weak_formation_drive_ODE", "formation_drive", **{**base, "formation_rate_scale":0.55}, notes="Reduced formation rate."),
        ODEScenario("strong_destruction_drive_ODE", "radiation_disruption", **{**base, "destruction_rate_scale":0.52, "photon_coeff":0.38, "hubble_coeff":0.36}, notes="Strong destruction."),
        ODEScenario("permissive_lock_control", "control", **{**base, "formation_rate_scale":1.3, "destruction_rate_scale":0.18, "freeze_threshold":0.18}, notes="Permissive control."),
        ODEScenario("strict_lock_control", "control", **{**base, "formation_rate_scale":0.75, "destruction_rate_scale":0.36, "freeze_threshold":0.32}, notes="Strict control."),
    ]


def timeline_grid() -> List[float]:
    return [X_HOT + (X_COLD - X_HOT) * i / (N_STEPS - 1) for i in range(N_STEPS)]


XS = timeline_grid()
DX_ABS = abs((X_COLD - X_HOT) / (N_STEPS - 1))


def formation_window_asymmetric(dx: float) -> float:
    sigma_hot = 0.85
    sigma_cold = 1.35
    sigma = sigma_hot if dx >= 0 else sigma_cold
    base = math.exp(-0.5 * (dx / sigma) ** 2)
    hot_penalty = math.exp(-0.18 * max(dx, 0.0) ** 2)
    return base * hot_penalty


def mode_radiation_weight(mode: Mode, sc: ODEScenario) -> float:
    denom_part = 1.0 + sc.denominator_weight * (mode.N - 1) / 3.0
    ecology_part = 1.0
    if mode.support_ecology == "virtual_support_dependent":
        ecology_part += sc.ecology_weight * 0.6
    if mode.support_ecology == "boundary_assisted":
        ecology_part += sc.ecology_weight * 0.8
    return mode.radiation_coupling_proxy * denom_part * ecology_part


def instantaneous_terms(mode: Mode, x: float, sc: ODEScenario) -> Tuple[float, float, float]:
    dx = x - mode.log10_mass_bridge
    thermal_availability = 1.0 / (1.0 + math.exp(-4.0 * dx))
    window = formation_window_asymmetric(dx)
    twirl_background = sc.radiation_factor * (1.0 + 0.12 * max(x, 0.0))

    formation_drive = (
        twirl_background
        * window
        * thermal_availability
        * (mode.mass_bridge ** 0.045)
        * (mode.adequacy_p5 ** 0.62)
        * (mode.force_shape_susceptibility ** 0.35)
    )

    rad_weight = mode_radiation_weight(mode, sc)
    overheat = max(dx, 0.0)
    overheat_disruption = sc.overheat_coeff * (overheat ** 2) * rad_weight / max(mode.adequacy_p5, 0.1) ** 0.25
    overheat_disruption *= (1.0 + sc.hot_smash_extra * max(dx - 0.75, 0.0))
    hubble_disruption = (
        sc.hubble_coeff
        * (10.0 ** (0.105 * max(x, 0.0)))
        * (0.85 + (0.75 + sc.tightness_weight) * mode.tightness_proxy)
    )
    photon_disruption = sc.photon_coeff * (10.0 ** (0.075 * max(x, 0.0))) * rad_weight
    closure_rent = 1.0 / max(mode.adequacy_p5, 1e-9)
    disruption_total = closure_rent + overheat_disruption + hubble_disruption + photon_disruption

    gamma_form = sc.formation_rate_scale * formation_drive / (1.0 + disruption_total)
    gamma_destroy = sc.destruction_rate_scale * disruption_total / (1.0 + formation_drive)
    gamma_destroy *= 0.35 + 0.65 / (1.0 + mode.adequacy_p5)

    cooling_suppression = 1.0 / (1.0 + math.exp(-2.0 * (x - (-2.0))))
    gamma_form *= cooling_suppression
    gamma_destroy *= cooling_suppression
    survival_score = formation_drive / max(disruption_total, 1e-12)
    return gamma_form, gamma_destroy, survival_score


def integrate_mode(mode: Mode, sc: ODEScenario) -> Dict[str, float | str | bool]:
    Y = 0.0
    peakY = 0.0
    peakS = 0.0
    freeze_x = None

    for x in XS:
        gf, gd, S = instantaneous_terms(mode, x, sc)
        peakS = max(peakS, S)
        dtau = DX_ABS * sc.cooling_clock_scale
        dY = (gf * (1.0 - Y) - gd * Y) * dtau
        Y = max(0.0, min(1.0, Y + dY))
        peakY = max(peakY, Y)
        if freeze_x is None and Y >= sc.freeze_threshold and S >= 1.0:
            freeze_x = x

    robust = Y >= sc.freeze_threshold and mode.adequacy_p5 >= 1.0
    fragile = (0.05 <= Y < sc.freeze_threshold) or (peakS >= 1.0 and Y < sc.freeze_threshold)

    return {
        "scenario_id": sc.scenario_id,
        "rho": mode.rho_str,
        "final_Y": Y,
        "peak_Y": peakY,
        "peak_S": peakS,
        "freeze_x": -999.0 if freeze_x is None else freeze_x,
        "robust": robust,
        "fragile": fragile,
    }


def cold_class(robust_fraction: float, fragile_fraction: float) -> str:
    if robust_fraction >= 0.8:
        return "ROBUST_COLD_RELIC_SCREEN"
    if robust_fraction >= 0.5:
        return "SCENARIO_DEPENDENT_RELIC_SCREEN"
    if fragile_fraction >= 0.5:
        return "FRAGILE_TRANSIENT_RELIC_SCREEN"
    return "MOSTLY_FAILED_COLD_AUDIT_SCREEN"


def aggregate_modes(modes: List[Mode], scenarios: List[ODEScenario]) -> Tuple[List[ModeAggregate], List[dict]]:
    all_rows: List[dict] = []
    aggs: List[ModeAggregate] = []

    for mode in modes:
        rows = []
        for sc in scenarios:
            row = integrate_mode(mode, sc)
            rows.append(row)
            enriched = dict(row)
            enriched.update({
                "m": mode.m,
                "N": mode.N,
                "denominator_class": mode.denominator_class,
                "support_ecology": mode.support_ecology,
                "mass_bridge": mode.mass_bridge,
                "log10_mass_bridge": mode.log10_mass_bridge,
                "adequacy_p5": mode.adequacy_p5,
            })
            all_rows.append(enriched)

        finalYs = [float(r["final_Y"]) for r in rows]
        peakYs = [float(r["peak_Y"]) for r in rows]
        robust_count = sum(1 for r in rows if r["robust"])
        fragile_count = sum(1 for r in rows if r["fragile"] and not r["robust"])
        freeze_vals = [float(r["freeze_x"]) for r in rows if float(r["freeze_x"]) > -900]
        baseline = [r for r in rows if r["scenario_id"] == "baseline_ODE_R003_R004"][0]

        rf = robust_count / len(scenarios)
        ff = fragile_count / len(scenarios)

        aggs.append(ModeAggregate(
            rho=mode.rho_str,
            m=mode.m,
            N=mode.N,
            denominator_class=mode.denominator_class,
            support_ecology=mode.support_ecology,
            mass_bridge=mode.mass_bridge,
            log10_mass_bridge=mode.log10_mass_bridge,
            adequacy_p5=mode.adequacy_p5,
            baseline_finalY=float(baseline["final_Y"]),
            mean_finalY=sum(finalYs) / len(finalYs),
            min_finalY=min(finalYs),
            max_finalY=max(finalYs),
            mean_peakY=sum(peakYs) / len(peakYs),
            robust_fraction=rf,
            fragile_fraction=ff,
            mean_freeze_x=sum(freeze_vals) / len(freeze_vals) if freeze_vals else -999.0,
            cold_audit_class=cold_class(rf, ff),
        ))
    return aggs, all_rows


def build_budget_schemes() -> List[BudgetScheme]:
    return [
        BudgetScheme(
            "equal_relic_occupancy_proxy",
            "Relative relic occupancy from ensemble mean final Y only.",
            "weight = mean_finalY",
            False
        ),
        BudgetScheme(
            "inverse_mass_number_proxy",
            "Fixed captured energy would create fewer high-mass quanta; number proxy divides by mass amplitude.",
            "weight = mean_finalY / mass_bridge",
            False
        ),
        BudgetScheme(
            "log_tempered_number_proxy",
            "Softened number proxy that divides by 1+log10(mass_bridge) rather than mass itself.",
            "weight = mean_finalY / (1 + log10_mass_bridge)",
            False
        ),
        BudgetScheme(
            "energy_capture_proxy",
            "Energy-weighted capture proxy; high mass-amplitude modes dominate if energy retention scales with mass.",
            "weight = mean_finalY * mass_bridge",
            False
        ),
        BudgetScheme(
            "robustness_weighted_proxy",
            "Relic proxy weighted by robust survival fraction across the cold-audit scenario ensemble.",
            "weight = mean_finalY * robust_fraction",
            False
        ),
        BudgetScheme(
            "fragility_suppressed_proxy",
            "Relic proxy that partially suppresses fragile/scenario-dependent modes without deleting them.",
            "weight = mean_finalY * (0.25 + 0.75*robust_fraction)",
            False
        ),
    ]


def scheme_weight(agg: ModeAggregate, scheme_id: str) -> float:
    eps = 1e-300
    if scheme_id == "equal_relic_occupancy_proxy":
        return max(agg.mean_finalY, 0.0)
    if scheme_id == "inverse_mass_number_proxy":
        return max(agg.mean_finalY, 0.0) / max(agg.mass_bridge, eps)
    if scheme_id == "log_tempered_number_proxy":
        return max(agg.mean_finalY, 0.0) / max(1.0 + agg.log10_mass_bridge, eps)
    if scheme_id == "energy_capture_proxy":
        return max(agg.mean_finalY, 0.0) * max(agg.mass_bridge, eps)
    if scheme_id == "robustness_weighted_proxy":
        return max(agg.mean_finalY, 0.0) * max(agg.robust_fraction, 0.0)
    if scheme_id == "fragility_suppressed_proxy":
        return max(agg.mean_finalY, 0.0) * (0.25 + 0.75 * max(agg.robust_fraction, 0.0))
    raise ValueError(f"unknown scheme {scheme_id}")


def normalize_weights(aggs: List[ModeAggregate], scheme_id: str) -> Dict[str, float]:
    raw = {a.rho: scheme_weight(a, scheme_id) for a in aggs}
    total = sum(raw.values())
    if total <= 0:
        return {k: 0.0 for k in raw}
    return {k: v / total for k, v in raw.items()}


def effective_mode_count(fracs: Dict[str, float]) -> float:
    H = 0.0
    for p in fracs.values():
        if p > 0:
            H -= p * math.log(p)
    return math.exp(H)


def summarize_scheme(aggs: List[ModeAggregate], scheme: BudgetScheme) -> Tuple[SchemeSummary, List[dict]]:
    fracs = normalize_weights(aggs, scheme.scheme_id)
    class_by_rho = {a.rho: a.cold_audit_class for a in aggs}
    logM_by_rho = {a.rho: a.log10_mass_bridge for a in aggs}
    sorted_by_frac = sorted(fracs.items(), key=lambda kv: kv[1], reverse=True)
    top_mode, top_fraction = sorted_by_frac[0]

    robust_frac = sum(v for rho, v in fracs.items() if class_by_rho[rho] == "ROBUST_COLD_RELIC_SCREEN")
    scenario_frac = sum(v for rho, v in fracs.items() if class_by_rho[rho] == "SCENARIO_DEPENDENT_RELIC_SCREEN")
    fragile_frac = sum(v for rho, v in fracs.items() if class_by_rho[rho] == "FRAGILE_TRANSIENT_RELIC_SCREEN")

    median_logM = sorted(logM_by_rho.values())[len(logM_by_rho)//2]
    low_half = sum(v for rho, v in fracs.items() if logM_by_rho[rho] <= median_logM)
    high_half = 1.0 - low_half

    eff = effective_mode_count(fracs)
    warning = "HIGH_DOMINANCE" if top_fraction >= 0.75 else ("MODERATE_DOMINANCE" if top_fraction >= 0.40 else "DISTRIBUTED")

    if scheme.scheme_id == "inverse_mass_number_proxy":
        interp = "Number-style proxy is expected to favor low mass-amplitude modes; this is not an observed abundance."
    elif scheme.scheme_id == "energy_capture_proxy":
        interp = "Energy-style proxy is expected to favor high mass-amplitude modes; this is not an observed energy density."
    else:
        interp = "Toy relative capture proxy reported for sensitivity only."

    rows = []
    for a in aggs:
        rows.append({
            "scheme_id": scheme.scheme_id,
            "rho": a.rho,
            "fraction": fracs[a.rho],
            "raw_weight": scheme_weight(a, scheme.scheme_id),
            "cold_audit_class": a.cold_audit_class,
            "mean_finalY": a.mean_finalY,
            "robust_fraction": a.robust_fraction,
            "mass_bridge": a.mass_bridge,
            "log10_mass_bridge": a.log10_mass_bridge,
            "adequacy_p5": a.adequacy_p5,
        })

    summary = SchemeSummary(
        scheme_id=scheme.scheme_id,
        top_mode=top_mode,
        top_fraction=top_fraction,
        effective_mode_count=eff,
        robust_class_fraction=robust_frac,
        scenario_dependent_class_fraction=scenario_frac,
        fragile_class_fraction=fragile_frac,
        low_mass_half_fraction=low_half,
        high_mass_half_fraction=high_half,
        dominance_warning=warning,
        interpretation=interp,
    )
    return summary, rows


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_abundance_proxy_capture_fraction_toy_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    modes = build_modes()
    scenarios = build_scenarios()
    aggs, scenario_rows = aggregate_modes(modes, scenarios)
    schemes = build_budget_schemes()

    scheme_summaries: List[SchemeSummary] = []
    fraction_rows: List[dict] = []

    for scheme in schemes:
        summary, rows = summarize_scheme(aggs, scheme)
        scheme_summaries.append(summary)
        fraction_rows.extend(rows)

    dominance_warning_present = any(s.dominance_warning == "HIGH_DOMINANCE" for s in scheme_summaries)
    multiple_budget_conventions_reported = len(schemes) >= 3
    no_scheme_selected_as_physical = all(not s.selected_for_physics for s in schemes)
    abundance_proxy_generated = True
    physical_abundance_claimed = False

    write_csv(out_dir / "V12_10_R010_mode_aggregate_ODE_inputs.csv", [asdict(a) for a in aggs])
    write_csv(out_dir / "V12_10_R010_mode_by_scenario_ODE_ledger.csv", scenario_rows)
    write_csv(out_dir / "V12_10_R010_budget_scheme_definitions.csv", [asdict(s) for s in schemes])
    write_csv(out_dir / "V12_10_R010_budget_scheme_summary.csv", [asdict(s) for s in scheme_summaries])
    write_csv(out_dir / "V12_10_R010_mode_fraction_by_scheme.csv", fraction_rows)

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "abundance_proxy_generated": abundance_proxy_generated,
        "multiple_budget_conventions_reported": multiple_budget_conventions_reported,
        "dominance_warning_present": dominance_warning_present,
        "no_scheme_selected_as_physical": no_scheme_selected_as_physical,
        "physical_abundance_claimed": physical_abundance_claimed,
        "scheme_summaries": [asdict(s) for s in scheme_summaries],
        "claim_boundary": [
            "toy capture/relic-fraction proxies only",
            "no empirical abundance loading",
            "no baryon-to-photon matching",
            "no BBN/CMB prediction",
            "no rho-to-particle mapping",
            "no physical budget convention selected",
            "no final cosmogenesis law",
        ],
    }
    payload_path = out_dir / "V12_10_R010_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Result")
    lines.append("")
    lines.append("R010 constructs multiple toy relative capture / relic-fraction proxies from the R005/R006 ODE ensemble.")
    lines.append("")
    lines.append("No budget convention is selected as physical.")
    lines.append("")
    lines.append("## Budget scheme summary")
    lines.append("")
    lines.append("| scheme | top mode | top fraction | effective modes | robust-class fraction | dominance |")
    lines.append("| --- | --- | ---: | ---: | ---: | --- |")
    for s in scheme_summaries:
        lines.append(f"| {s.scheme_id} | {s.top_mode} | {s.top_fraction:.4g} | {s.effective_mode_count:.4g} | {s.robust_class_fraction:.4g} | {s.dominance_warning} |")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("- R010 does not predict physical abundances, baryon-to-photon ratio, BBN yields, or CMB spectra.")
    lines.append("- R010 does not map rho modes to particles.")
    lines.append("- R010 reports budget-convention sensitivity only.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_abundance_proxy_capture_fraction_toy_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R010_mode_aggregate_ODE_inputs.csv",
        out_dir / "V12_10_R010_mode_by_scenario_ODE_ledger.csv",
        out_dir / "V12_10_R010_budget_scheme_definitions.csv",
        out_dir / "V12_10_R010_budget_scheme_summary.csv",
        out_dir / "V12_10_R010_mode_fraction_by_scheme.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R010 RESULT ===")
    print("V12.10-R010 COMPLETE")
    print("VERDICT: ABUNDANCE PROXY / CAPTURE FRACTION TOY PASS / BUDGET CONVENTIONS REPORTED, PHYSICAL ABUNDANCES OPEN")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("ODE_mode_aggregates_generated: True")
    print("budget_scheme_definitions_generated: True")
    print("mode_fraction_by_scheme_generated: True")
    print(f"abundance_proxy_generated: {abundance_proxy_generated}")
    print(f"multiple_budget_conventions_reported: {multiple_budget_conventions_reported}")
    print(f"dominance_warning_present: {dominance_warning_present}")
    print(f"no_scheme_selected_as_physical: {no_scheme_selected_as_physical}")
    print("no_empirical_abundances_loaded: True")
    print("no_baryon_to_photon_matching_performed: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_abundance_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("MODE_AGGREGATE_LEDGER:")
    for a in aggs:
        print(f"  rho={a.rho} | class={a.cold_audit_class} | meanY={a.mean_finalY:.4g} | robust_frac={a.robust_fraction:.4g} | log10M={a.log10_mass_bridge:.4g} | A_p5={a.adequacy_p5:.4g}")
    print("BUDGET_SCHEME_SUMMARY:")
    for s in scheme_summaries:
        print(f"  {s.scheme_id} | top={s.top_mode} | top_frac={s.top_fraction:.4g} | eff_modes={s.effective_mode_count:.4g} | robust_class_frac={s.robust_class_fraction:.4g} | low/high={s.low_mass_half_fraction:.4g}/{s.high_mass_half_fraction:.4g} | dominance={s.dominance_warning}")
    print("INTERPRETATION:")
    print("  equal/robustness proxies ask relic-occupancy-style questions.")
    print("  inverse-mass proxy asks number-count-style questions and naturally favors lighter modes.")
    print("  energy-capture proxy asks energy-density-style questions and naturally favors heavier modes.")
    print("  no proxy is selected as physical in R010.")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R010 constructs toy relative capture/relic-fraction proxies from the V12.10 ODE ensemble. -- Multiple budget conventions are reported.")
    print("  YES | R010 reports dominance and budget-convention sensitivity. -- This identifies which abundance-style questions are well-posed.")
    print("  NO | R010 predicts physical abundances, baryon-to-photon ratio, BBN yields, or CMB spectra. -- No empirical cosmology data are loaded.")
    print("  NO | R010 maps rho modes to observed particles or sectors. -- Modes remain internal SFT seed modes.")
    print("  NO | R010 selects a physical abundance law. -- No budget convention is selected as final.")
    print("  NO | R010 closes GR/Boltzmann cosmogenesis. -- This remains a dimensionless toy proxy gate.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: FORCE_V12_10_R011_class_preserving_null_archetype_control_gate_or_FORCE_V12_10_R012_racetrack_plus_abundance_rollup_gate")
    print("=== END COPY/PASTE V12.10-R010 RESULT ===")


if __name__ == "__main__":
    main()
