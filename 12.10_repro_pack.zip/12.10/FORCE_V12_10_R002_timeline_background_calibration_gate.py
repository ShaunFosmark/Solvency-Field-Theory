#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R002_timeline_background_calibration_gate.py

V12.10-R002:
Timeline / background calibration gate for the radiation-era formation-survival toy.

Purpose:
  - Turn R001 from a broad toy into a calibrated screen framework.
  - Sweep only background/timeline knobs, not mode properties.
  - Identify which phases and controls are doing work:
      * hot-smash suppression
      * formation/cooling lock-in window
      * radiation active-gravity/twirl drive
      * photon/radiation disruption
      * Hubble tearing
  - Preserve strict claim boundaries:
      * no empirical abundance loading
      * no baryon-to-photon matching
      * no CMB prediction
      * no particle mapping
      * no final cosmogenesis law
"""

from __future__ import annotations

import csv
import json
import math
import hashlib
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
from fractions import Fraction
from pathlib import Path
from itertools import product
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R002"
PARENT_GATE = "FORCE_V12_10_R001"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R002: Timeline / Background Calibration Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

RAW_FEEDBACK = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

G_FORCE_SHAPE_TOPOLOGY = {
    "1/2": 5.7426406871,
    "2/3": 2.03823702542,
    "3/4": 1.0,
    "1":   8.12132034355,
    "5/4": 1.20454951288,
    "4/3": 1.256762611,
    "3/2": 2.55433304545,
    "5/3": 1.39089397103,
    "2":   10.1516504294,
}

BETA_6PI = 0.299699441600
RENT_POWER = 5.0

X_HOT = 7.0
X_COLD = -4.0
N_STEPS = 1101
BBN_PROXY_X = -1.0
RECOMBINATION_AUDIT_X = -4.0


@dataclass(frozen=True)
class BackgroundParams:
    scenario_id: str
    radiation_active_factor: float
    window_sigma: float
    overheat_scale: float
    hubble_scale: float
    photon_scale: float
    closure_scale: float
    bridge_enabled: bool
    adequacy_enabled: bool
    force_shape_enabled: bool


@dataclass
class Mode:
    rho_str: str
    rho: float
    m: int
    N: int
    denominator_class: str
    occupancy_vector: Tuple[int, int, int]
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    radiation_coupling_proxy: float
    tightness_proxy: float


@dataclass
class ModeCalibrationResult:
    scenario_id: str
    rho: str
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    log10_mass_bridge: float
    adequacy_p5: float
    peak_x: float
    peak_phase: str
    max_survival_score: float
    first_lock_x: str
    first_lock_phase: str
    capture_fraction_proxy: float
    survives_recombination_audit: bool
    failure_reason: str


def frac_value(s: str) -> Fraction:
    return Fraction(s)


def denominator_class(N: int) -> str:
    if N == 1:
        return "integer_base_cadence"
    if N == 2:
        return "binary_no_overwrite_class"
    if N == 3:
        return "tri_slot_normal_bundle_class"
    if N == 4:
        return "full_3plus1_slot_capacity_class"
    return f"denominator_{N}_outside_v12_8_slot_cap"


def occupancy_vector(m: int, N: int) -> Tuple[int, int, int]:
    slots = min(3, max(1, N))
    base = m // slots
    rem = m % slots
    occ = [base + (1 if i < rem else 0) for i in range(slots)]
    while len(occ) < 3:
        occ.append(0)
    return tuple(occ[:3])


def support_ecology(rho_str: str) -> str:
    if rho_str in {"5/4", "5/3"}:
        return "virtual_support_dependent"
    if rho_str == "2":
        return "boundary_assisted"
    return "clean_internal"


def build_modes() -> List[Mode]:
    min_raw = min(RAW_FEEDBACK.values())
    raw_at_identity = RAW_FEEDBACK["1"]
    min_g = min(G_FORCE_SHAPE_TOPOLOGY.values())

    # Precompute bridge amplitudes for tightness normalization.
    bridge_tmp = {}
    for s in SELECTED_SEED_STR:
        raw_norm = RAW_FEEDBACK[s] / min_raw
        bridge_tmp[s] = raw_norm ** (1.0 + BETA_6PI)
    max_bridge = max(bridge_tmp.values())

    modes: List[Mode] = []
    for s in SELECTED_SEED_STR:
        f = frac_value(s)
        rho = float(f)
        m, N = f.numerator, f.denominator
        raw = RAW_FEEDBACK[s]
        bridge = bridge_tmp[s]
        adequacy = raw / (raw_at_identity * (rho ** RENT_POWER))
        g_norm = G_FORCE_SHAPE_TOPOLOGY[s] / min_g
        susceptibility = math.sqrt(g_norm)
        ecology = support_ecology(s)

        rad_coupling = 1.0 + 0.12 * (N - 1)
        if ecology == "virtual_support_dependent":
            rad_coupling += 0.18
        if ecology == "boundary_assisted":
            rad_coupling += 0.25

        tightness = math.sqrt(bridge / max_bridge)

        modes.append(
            Mode(
                rho_str=s,
                rho=rho,
                m=m,
                N=N,
                denominator_class=denominator_class(N),
                occupancy_vector=occupancy_vector(m, N),
                support_ecology=ecology,
                raw_feedback=raw,
                mass_bridge=bridge,
                adequacy_p5=adequacy,
                force_shape_susceptibility=susceptibility,
                radiation_coupling_proxy=rad_coupling,
                tightness_proxy=tightness,
            )
        )
    return modes


def timeline_grid() -> List[float]:
    return [X_HOT + (X_COLD - X_HOT) * i / (N_STEPS - 1) for i in range(N_STEPS)]


def timeline_phase(x: float) -> str:
    if x >= 5.5:
        return "hot_smash_transient"
    if x >= 2.0:
        return "hot_formation_lock_window"
    if x >= 0.0:
        return "cooling_late_lock_window"
    if x >= BBN_PROXY_X:
        return "BBN_proxy_no_abundance_prediction"
    return "cold_recombination_audit_tail"


def survival_score(mode: Mode, x: float, params: BackgroundParams) -> float:
    logM = math.log10(max(mode.mass_bridge, 1e-300))
    dx = x - logM

    threshold_window = math.exp(-0.5 * (dx / params.window_sigma) ** 2)
    thermal_availability = 1.0 / (1.0 + math.exp(-4.0 * dx))

    twirl_background = params.radiation_active_factor * (1.0 + 0.12 * max(x, 0.0))

    if params.bridge_enabled:
        bridge_mass_factor = mode.mass_bridge ** 0.045
    else:
        min_raw = min(RAW_FEEDBACK.values())
        bridge_mass_factor = (mode.raw_feedback / min_raw) ** 0.045

    adequacy_factor = mode.adequacy_p5 ** 0.62 if params.adequacy_enabled else 1.0
    force_factor = mode.force_shape_susceptibility ** 0.35 if params.force_shape_enabled else 1.0

    formation_drive = twirl_background * threshold_window * thermal_availability * bridge_mass_factor * adequacy_factor * force_factor

    overheat = max(dx, 0.0)
    adequacy_disruption_relief = max(mode.adequacy_p5, 0.1) ** 0.25 if params.adequacy_enabled else 1.0
    overheat_disruption = params.overheat_scale * 0.42 * (overheat ** 2) * mode.radiation_coupling_proxy / adequacy_disruption_relief

    hubble_tearing = params.hubble_scale * 0.22 * (10.0 ** (0.105 * max(x, 0.0))) * (0.85 + 0.75 * mode.tightness_proxy)
    photon_disruption = params.photon_scale * 0.18 * (10.0 ** (0.075 * max(x, 0.0))) * mode.radiation_coupling_proxy

    closure_rent = params.closure_scale / max(mode.adequacy_p5 if params.adequacy_enabled else 1.0, 1e-9)

    disruption = closure_rent + overheat_disruption + hubble_tearing + photon_disruption
    return formation_drive / max(disruption, 1e-12)


def run_params(modes: List[Mode], params: BackgroundParams) -> List[ModeCalibrationResult]:
    xs = timeline_grid()
    dx_abs = abs((X_COLD - X_HOT) / (N_STEPS - 1))
    results: List[ModeCalibrationResult] = []

    for mode in modes:
        scores = [survival_score(mode, x, params) for x in xs]
        max_score = max(scores)
        peak_i = scores.index(max_score)
        peak_x = xs[peak_i]
        locked = [i for i, sc in enumerate(scores) if sc >= 1.0]

        if locked:
            first_i = locked[0]
            first_x = xs[first_i]
            lock_str = f"{first_x:.4g}"
            first_phase = timeline_phase(first_x)
            survives = mode.adequacy_p5 >= 1.0
        else:
            lock_str = "none"
            first_phase = "none"
            survives = False

        excess_integral = sum(max(0.0, sc - 1.0) * dx_abs for sc in scores)
        capture = excess_integral / (1.0 + excess_integral)

        if survives:
            failure = "locked_before_cold_audit_in_toy"
        elif max_score < 1.0:
            failure = "formation_drive_never_exceeds_disruption"
        elif mode.adequacy_p5 < 1.0:
            failure = "formation_window_present_but_closure_adequacy_below_one"
        else:
            failure = "unknown_toy_failure"

        results.append(
            ModeCalibrationResult(
                scenario_id=params.scenario_id,
                rho=mode.rho_str,
                m=mode.m,
                N=mode.N,
                denominator_class=mode.denominator_class,
                support_ecology=mode.support_ecology,
                log10_mass_bridge=math.log10(max(mode.mass_bridge, 1e-300)),
                adequacy_p5=mode.adequacy_p5,
                peak_x=peak_x,
                peak_phase=timeline_phase(peak_x),
                max_survival_score=max_score,
                first_lock_x=lock_str,
                first_lock_phase=first_phase,
                capture_fraction_proxy=capture,
                survives_recombination_audit=survives,
                failure_reason=failure,
            )
        )

    return results


def summarize_results(params: BackgroundParams, results: List[ModeCalibrationResult]) -> Dict[str, object]:
    locked_modes = [r.rho for r in results if r.first_lock_x != "none"]
    survivor_modes = [r.rho for r in results if r.survives_recombination_audit]
    failed_modes = [r.rho for r in results if not r.survives_recombination_audit]

    # Lock order: sort by first lock x descending/hotter first. Failed modes go last.
    def lock_key(r: ModeCalibrationResult):
        return float(r.first_lock_x) if r.first_lock_x != "none" else -999.0

    lock_order = [r.rho for r in sorted(results, key=lock_key, reverse=True)]

    # Mass order: heavier/hotter bridge first.
    mass_order = [r.rho for r in sorted(results, key=lambda r: r.log10_mass_bridge, reverse=True)]

    # Count pairwise inversions between lock order and mass order for modes that lock.
    order_pos = {rho: i for i, rho in enumerate(mass_order)}
    lock_locked = [rho for rho in lock_order if rho in locked_modes]
    inversions = 0
    total_pairs = 0
    for i in range(len(lock_locked)):
        for j in range(i + 1, len(lock_locked)):
            total_pairs += 1
            if order_pos[lock_locked[i]] > order_pos[lock_locked[j]]:
                inversions += 1
    monotonic_order_score = 1.0 - inversions / total_pairs if total_pairs else 0.0

    return {
        "scenario_id": params.scenario_id,
        "radiation_active_factor": params.radiation_active_factor,
        "window_sigma": params.window_sigma,
        "overheat_scale": params.overheat_scale,
        "hubble_scale": params.hubble_scale,
        "photon_scale": params.photon_scale,
        "closure_scale": params.closure_scale,
        "bridge_enabled": params.bridge_enabled,
        "adequacy_enabled": params.adequacy_enabled,
        "force_shape_enabled": params.force_shape_enabled,
        "locked_count": len(locked_modes),
        "survivor_count": len(survivor_modes),
        "failed_modes": ", ".join(failed_modes) if failed_modes else "none",
        "lock_order_hot_to_cold": ", ".join(lock_order),
        "mass_order_hot_to_cold": ", ".join(mass_order),
        "monotonic_lock_mass_order_score": monotonic_order_score,
        "mean_max_survival_score": sum(r.max_survival_score for r in results) / len(results),
        "mean_capture_proxy": sum(r.capture_fraction_proxy for r in results) / len(results),
        "max_capture_proxy": max(r.capture_fraction_proxy for r in results),
        "min_capture_proxy": min(r.capture_fraction_proxy for r in results),
    }


def baseline_params() -> BackgroundParams:
    return BackgroundParams(
        scenario_id="baseline_R001_reproduction",
        radiation_active_factor=2.0,
        window_sigma=1.15,
        overheat_scale=1.0,
        hubble_scale=1.0,
        photon_scale=1.0,
        closure_scale=1.0,
        bridge_enabled=True,
        adequacy_enabled=True,
        force_shape_enabled=True,
    )


def control_params() -> List[BackgroundParams]:
    base = baseline_params()
    return [
        base,
        BackgroundParams("control_no_radiation_double_burden", 1.0, base.window_sigma, base.overheat_scale, base.hubble_scale, base.photon_scale, base.closure_scale, True, True, True),
        BackgroundParams("control_no_bridge_mass_amplitude", 2.0, base.window_sigma, base.overheat_scale, base.hubble_scale, base.photon_scale, base.closure_scale, False, True, True),
        BackgroundParams("control_no_closure_adequacy", 2.0, base.window_sigma, base.overheat_scale, base.hubble_scale, base.photon_scale, base.closure_scale, True, False, True),
        BackgroundParams("control_no_shape_force_susceptibility", 2.0, base.window_sigma, base.overheat_scale, base.hubble_scale, base.photon_scale, base.closure_scale, True, True, False),
        BackgroundParams("control_high_disruption", 2.0, base.window_sigma, 1.35, 1.35, 1.35, base.closure_scale, True, True, True),
        BackgroundParams("control_low_disruption", 2.0, base.window_sigma, 0.75, 0.75, 0.75, base.closure_scale, True, True, True),
        BackgroundParams("control_narrow_formation_window", 2.0, 0.85, base.overheat_scale, base.hubble_scale, base.photon_scale, base.closure_scale, True, True, True),
    ]


def sweep_params() -> List[BackgroundParams]:
    rows = []
    for rad, sigma, over, hub, phot in product([1.0, 1.5, 2.0], [0.85, 1.15, 1.45], [0.75, 1.0, 1.35], [0.75, 1.0, 1.35], [0.75, 1.0, 1.35]):
        sid = f"sweep_rad{rad}_sig{sigma}_over{over}_hub{hub}_phot{phot}"
        rows.append(BackgroundParams(sid, rad, sigma, over, hub, phot, 1.0, True, True, True))
    return rows


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_timeline_background_calibration_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    modes = build_modes()

    # Baseline + named controls.
    named_results = []
    named_summary = []
    for p in control_params():
        res = run_params(modes, p)
        named_results.extend(asdict(r) for r in res)
        named_summary.append(summarize_results(p, res))

    # Parameter sweep.
    sweep_summary = []
    for p in sweep_params():
        res = run_params(modes, p)
        sweep_summary.append(summarize_results(p, res))

    # Phase ledger: for each mode under baseline, compare logM with toy phase markers.
    phase_rows = []
    for m in modes:
        logM = math.log10(max(m.mass_bridge, 1e-300))
        phase_rows.append({
            "rho": m.rho_str,
            "m": m.m,
            "N": m.N,
            "log10_mass_bridge": logM,
            "formation_phase_at_threshold": timeline_phase(logM),
            "hot_smash_margin_x": X_HOT - logM,
            "recombination_audit_margin_x": logM - RECOMBINATION_AUDIT_X,
            "interpretation": "dimensionless toy threshold placement; not a physical temperature",
        })

    # Find no-rad failure modes.
    no_rad_row = next(row for row in named_summary if row["scenario_id"] == "control_no_radiation_double_burden")
    baseline_row = next(row for row in named_summary if row["scenario_id"] == "baseline_R001_reproduction")

    # Sweep ranges.
    survivor_counts = [int(r["survivor_count"]) for r in sweep_summary]
    order_scores = [float(r["monotonic_lock_mass_order_score"]) for r in sweep_summary]
    partial_survival_cases = [r for r in sweep_summary if 0 < int(r["survivor_count"]) < 9]
    total_failure_cases = [r for r in sweep_summary if int(r["survivor_count"]) == 0]

    # Necessary/informative criteria.
    radiation_factor_informative = int(baseline_row["survivor_count"]) > int(no_rad_row["survivor_count"])
    sweep_survival_varies = len(set(survivor_counts)) > 1
    partial_survival_windows_present = len(partial_survival_cases) > 0
    lock_order_stable = sum(1 for s in order_scores if s >= 0.85) / len(order_scores) >= 0.8

    write_csv(out_dir / "V12_10_R002_named_control_mode_results.csv", named_results)
    write_csv(out_dir / "V12_10_R002_named_control_summary.csv", named_summary)
    write_csv(out_dir / "V12_10_R002_parameter_sweep_summary.csv", sweep_summary)
    write_csv(out_dir / "V12_10_R002_phase_threshold_ledger.csv", phase_rows)

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "timeline_variable": "x = log10(T/E_lightest_proxy), dimensionless",
        "phase_markers": {
            "hot_smash_transient": "x >= 5.5",
            "hot_formation_lock_window": "2.0 <= x < 5.5",
            "cooling_late_lock_window": "0.0 <= x < 2.0",
            "BBN_proxy_no_abundance_prediction": "-1.0 <= x < 0.0",
            "cold_recombination_audit_tail": "x < -1.0",
        },
        "calibration_results": {
            "radiation_factor_informative": radiation_factor_informative,
            "sweep_survival_varies": sweep_survival_varies,
            "partial_survival_windows_present": partial_survival_windows_present,
            "lock_order_stable": lock_order_stable,
            "sweep_survivor_count_min": min(survivor_counts),
            "sweep_survivor_count_max": max(survivor_counts),
            "sweep_order_score_mean": sum(order_scores) / len(order_scores),
        },
        "claim_boundary": [
            {"status": "YES_SCREEN", "claim": "R002 calibrates the toy timeline/background controls from R001."},
            {"status": "YES_SCREEN", "claim": "R002 sweeps background knobs without retuning mode properties."},
            {"status": "NO", "claim": "R002 predicts physical abundances, BBN yields, or CMB spectra."},
            {"status": "NO", "claim": "R002 maps rho modes to particles."},
            {"status": "NO", "claim": "R002 closes GR/Boltzmann cosmogenesis."},
        ],
    }
    payload_path = out_dir / "V12_10_R002_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("R002 is a timeline/background calibration screen. It does not load empirical abundances, BBN yields, CMB data, or particle mappings.")
    lines.append("")
    lines.append("## Main calibration flags")
    lines.append("")
    lines.append(f"- radiation_factor_informative: `{radiation_factor_informative}`")
    lines.append(f"- sweep_survival_varies: `{sweep_survival_varies}`")
    lines.append(f"- partial_survival_windows_present: `{partial_survival_windows_present}`")
    lines.append(f"- lock_order_stable: `{lock_order_stable}`")
    lines.append(f"- sweep_survivor_count_range: `{min(survivor_counts)}..{max(survivor_counts)}`")
    lines.append("")
    lines.append("## Named controls")
    lines.append("")
    lines.append("| scenario | survivors | failed modes | order score | mean maxS | mean capture |")
    lines.append("| --- | ---: | --- | ---: | ---: | ---: |")
    for row in named_summary:
        lines.append(
            f"| {row['scenario_id']} | {row['survivor_count']} | {row['failed_modes']} | "
            f"{row['monotonic_lock_mass_order_score']:.3f} | {row['mean_max_survival_score']:.3f} | {row['mean_capture_proxy']:.3f} |"
        )
    lines.append("")
    lines.append("## Phase threshold ledger")
    lines.append("")
    lines.append("| rho | m | N | log10M | threshold phase | hot margin | cold audit margin |")
    lines.append("| --- | ---: | ---: | ---: | --- | ---: | ---: |")
    for row in phase_rows:
        lines.append(
            f"| {row['rho']} | {row['m']} | {row['N']} | {row['log10_mass_bridge']:.3f} | "
            f"{row['formation_phase_at_threshold']} | {row['hot_smash_margin_x']:.3f} | {row['recombination_audit_margin_x']:.3f} |"
        )
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_timeline_background_calibration_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R002_named_control_mode_results.csv",
        out_dir / "V12_10_R002_named_control_summary.csv",
        out_dir / "V12_10_R002_parameter_sweep_summary.csv",
        out_dir / "V12_10_R002_phase_threshold_ledger.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R002 RESULT ===")
    print("V12.10-R002 COMPLETE")
    print("VERDICT: TIMELINE / BACKGROUND CALIBRATION PASS / SURVIVAL SENSITIVITY LOCALIZED, PHYSICAL COSMOGENESIS OPEN")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("timeline_phase_ledger_generated: True")
    print("background_parameter_sweep_generated: True")
    print("named_controls_generated: True")
    print(f"radiation_factor_informative: {radiation_factor_informative}")
    print(f"sweep_survival_varies: {sweep_survival_varies}")
    print(f"partial_survival_windows_present: {partial_survival_windows_present}")
    print(f"lock_order_stable: {lock_order_stable}")
    print(f"sweep_survivor_count_min: {min(survivor_counts)}")
    print(f"sweep_survivor_count_max: {max(survivor_counts)}")
    print(f"sweep_order_score_mean: {sum(order_scores)/len(order_scores):.6g}")
    print("no_empirical_abundances_loaded: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_cosmogenesis_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("NAMED_CONTROL_SUMMARY:")
    for row in named_summary:
        print(
            f"  {row['scenario_id']} | survivors={row['survivor_count']} | failed={row['failed_modes']} | "
            f"order_score={row['monotonic_lock_mass_order_score']:.3f} | mean_maxS={row['mean_max_survival_score']:.4g} | "
            f"mean_capture={row['mean_capture_proxy']:.4g}"
        )
    print("NO_RADIATION_DOUBLE_BURDEN_FAILURE_MODES:")
    print(f"  failed_modes: {no_rad_row['failed_modes']}")
    print("PHASE_THRESHOLD_LEDGER:")
    for row in phase_rows:
        print(
            f"  rho={row['rho']} | m={row['m']} | N={row['N']} | log10M={row['log10_mass_bridge']:.4g} | "
            f"phase={row['formation_phase_at_threshold']} | hot_margin={row['hot_smash_margin_x']:.4g}"
        )
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R002 calibrates timeline/background controls for the R001 toy. -- Background knobs are swept without retuning mode data.")
    print("  YES_SCREEN | R002 identifies whether radiation factor, disruption, and formation-window parameters affect survival. -- This is sensitivity localization, not physical fitting.")
    print("  NO | R002 predicts abundances, BBN yields, baryon-to-photon ratio, or CMB spectra. -- No empirical cosmology tables are loaded.")
    print("  NO | R002 maps rho modes to Standard Model particles. -- Modes remain internal SFT seed modes.")
    print("  NO | R002 closes GR/Boltzmann cosmogenesis. -- The toy timeline remains dimensionless and schematic.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: V12_10_R003_formation_drive_refinement_gate_or_V12_10_R004_radiation_disruption_gate")
    print("=== END COPY/PASTE V12.10-R002 RESULT ===")


if __name__ == "__main__":
    main()
