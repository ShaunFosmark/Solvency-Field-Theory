#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R008_qualitative_stability_lifetime_archetype_sanity_gate.py

V12.10-R008:
Qualitative Stability / Lifetime Archetype Sanity Gate.

This gate follows R007B:
  - R007B preserved the broad "formation racetrack" result.
  - R007B rejected exact rho-ecology specificity as unsupported by nulls.
  - R008 asks only whether the toy contains the right qualitative archetype capacity:
      robust relic-like
      scenario-sensitive / intermediate
      fragile / transient
    without mapping rho modes to particles.

No empirical masses, abundances, BBN yields, CMB data, or particle identities are loaded.
This is not a Standard Model mapping.
"""

from __future__ import annotations

import csv
import json
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, UTC
from pathlib import Path
from typing import List


GATE_ID = "FORCE_V12_10_R008"
PARENT_GATE = "FORCE_V12_10_R007B"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R008: Qualitative Stability / Lifetime Archetype Sanity Gate"

SELECTED_SEED = "{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}"
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

# R006 cold audit categories, kept as internal SFT toy classes.
R006_MODE_AUDIT = [
    {"rho": "1/2", "N": 2, "ecology": "clean_internal", "baselineY": 0.5298, "robust": 10, "fragile": 0, "failed": 0, "meanY": 0.4327, "toy_status": "ROBUST_COLD_RELIC_SCREEN"},
    {"rho": "2/3", "N": 3, "ecology": "clean_internal", "baselineY": 0.3928, "robust": 7, "fragile": 3, "failed": 0, "meanY": 0.2997, "toy_status": "SCENARIO_DEPENDENT_RELIC_SCREEN"},
    {"rho": "3/4", "N": 4, "ecology": "clean_internal", "baselineY": 0.3359, "robust": 5, "fragile": 5, "failed": 0, "meanY": 0.2469, "toy_status": "SCENARIO_DEPENDENT_RELIC_SCREEN"},
    {"rho": "1", "N": 1, "ecology": "clean_internal", "baselineY": 0.3212, "robust": 4, "fragile": 6, "failed": 0, "meanY": 0.2423, "toy_status": "FRAGILE_TRANSIENT_RELIC_SCREEN"},
    {"rho": "5/4", "N": 4, "ecology": "virtual_support_dependent", "baselineY": 0.4145, "robust": 6, "fragile": 4, "failed": 0, "meanY": 0.2903, "toy_status": "SCENARIO_DEPENDENT_RELIC_SCREEN"},
    {"rho": "4/3", "N": 3, "ecology": "clean_internal", "baselineY": 0.4847, "robust": 8, "fragile": 2, "failed": 0, "meanY": 0.3634, "toy_status": "ROBUST_COLD_RELIC_SCREEN"},
    {"rho": "3/2", "N": 2, "ecology": "clean_internal", "baselineY": 0.5946, "robust": 9, "fragile": 1, "failed": 0, "meanY": 0.4802, "toy_status": "ROBUST_COLD_RELIC_SCREEN"},
    {"rho": "5/3", "N": 3, "ecology": "virtual_support_dependent", "baselineY": 0.6202, "robust": 8, "fragile": 2, "failed": 0, "meanY": 0.4900, "toy_status": "ROBUST_COLD_RELIC_SCREEN"},
    {"rho": "2", "N": 1, "ecology": "boundary_assisted", "baselineY": 0.5627, "robust": 9, "fragile": 1, "failed": 0, "meanY": 0.4532, "toy_status": "ROBUST_COLD_RELIC_SCREEN"},
]


@dataclass
class Archetype:
    archetype_id: str
    description: str
    minimum_capacity_required: int
    toy_modes_available: str
    toy_capacity_count: int
    sanity_status: str
    boundary: str


@dataclass
class SanityLedgerItem:
    test_id: str
    result: str
    interpretation: str


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_qualitative_stability_lifetime_archetype_sanity_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    robust = [r["rho"] for r in R006_MODE_AUDIT if r["toy_status"] == "ROBUST_COLD_RELIC_SCREEN"]
    scenario_dep = [r["rho"] for r in R006_MODE_AUDIT if r["toy_status"] == "SCENARIO_DEPENDENT_RELIC_SCREEN"]
    fragile = [r["rho"] for r in R006_MODE_AUDIT if r["toy_status"] == "FRAGILE_TRANSIENT_RELIC_SCREEN"]
    failed = [r["rho"] for r in R006_MODE_AUDIT if r["toy_status"] == "MOSTLY_FAILED_COLD_AUDIT_SCREEN"]

    archetypes = [
        Archetype(
            "stable_relic_like_capacity",
            "Toy has modes that remain robust across most cold-audit scenarios.",
            1,
            ", ".join(robust) if robust else "none",
            len(robust),
            "PASS_CAPACITY_PRESENT" if len(robust) >= 1 else "FAIL_NO_CAPACITY",
            "Capacity only; no claim that any robust rho is a specific observed stable particle."
        ),
        Archetype(
            "scenario_sensitive_intermediate_capacity",
            "Toy has modes that survive baseline but depend on cooling/disruption scenario.",
            1,
            ", ".join(scenario_dep) if scenario_dep else "none",
            len(scenario_dep),
            "PASS_CAPACITY_PRESENT" if len(scenario_dep) >= 1 else "FAIL_NO_CAPACITY",
            "Capacity only; no lifetime or particle identity is assigned."
        ),
        Archetype(
            "fragile_transient_capacity",
            "Toy has at least one mode that is often fragile/transient rather than robust.",
            1,
            ", ".join(fragile) if fragile else "none",
            len(fragile),
            "PASS_CAPACITY_PRESENT" if len(fragile) >= 1 else "FAIL_NO_CAPACITY",
            "Capacity only; no claim about specific unstable particles."
        ),
        Archetype(
            "complete_failure_absence_control",
            "Toy does not force most seed modes into total failure under the cold audit ensemble.",
            0,
            ", ".join(failed) if failed else "none",
            len(failed),
            "PASS_NO_MOSTLY_FAILED_MODES" if len(failed) == 0 else "SCREEN_HAS_FAILED_MODES",
            "Absence of mostly-failed modes is a toy result, not an abundance prediction."
        ),
    ]

    sanity_items = [
        SanityLedgerItem(
            "three_archetype_capacity_present",
            "PASS" if len(robust) >= 1 and len(scenario_dep) >= 1 and len(fragile) >= 1 else "FAIL",
            "The toy contains robust, scenario-dependent, and fragile/transient internal classes."
        ),
        SanityLedgerItem(
            "exact_rho_to_particle_mapping",
            "NO",
            "No rho mode is assigned to any observed particle or Standard Model sector."
        ),
        SanityLedgerItem(
            "qualitative_observation_context_used_for_tuning",
            "NO",
            "Archetype categories are used as sanity context only; no formulas or thresholds are tuned."
        ),
        SanityLedgerItem(
            "abundance_proxy_ready",
            "PARTIAL_NEXT",
            "A future abundance proxy can be attempted only as a toy screen and must keep mapping open."
        ),
        SanityLedgerItem(
            "R007_null_boundary_preserved",
            "PASS",
            "R008 does not claim the exact R006 rho split is unique or null-resistant."
        ),
    ]

    archetype_pass = all(a.sanity_status.startswith("PASS") for a in archetypes)
    three_class_ecology_present = len(robust) >= 1 and len(scenario_dep) >= 1 and len(fragile) >= 1
    mapping_open = True
    no_empirical_data_loaded = True
    abundance_proxy_not_performed = True

    write_csv(out_dir / "V12_10_R008_archetype_capacity_ledger.csv", [asdict(a) for a in archetypes])
    write_csv(out_dir / "V12_10_R008_sanity_ledger.csv", [asdict(s) for s in sanity_items])
    write_csv(out_dir / "V12_10_R008_mode_audit_input.csv", R006_MODE_AUDIT)

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "robust_modes": robust,
        "scenario_dependent_modes": scenario_dep,
        "fragile_modes": fragile,
        "mostly_failed_modes": failed,
        "archetype_capacity_pass": archetype_pass,
        "three_class_ecology_present": three_class_ecology_present,
        "mapping_open": mapping_open,
        "abundance_proxy_not_performed": abundance_proxy_not_performed,
        "claim_boundary": [
            "qualitative archetype sanity only",
            "no observed particle mapping",
            "no empirical abundance loading",
            "no BBN/CMB prediction",
            "no final cosmogenesis law",
        ],
    }
    payload_path = out_dir / "V12_10_R008_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Result")
    lines.append("")
    lines.append("R008 checks whether the V12.10 toy contains qualitative capacity for robust, scenario-dependent, and fragile/transient relic archetypes.")
    lines.append("")
    lines.append(f"- Robust modes: `{', '.join(robust) if robust else 'none'}`")
    lines.append(f"- Scenario-dependent modes: `{', '.join(scenario_dep) if scenario_dep else 'none'}`")
    lines.append(f"- Fragile/transient modes: `{', '.join(fragile) if fragile else 'none'}`")
    lines.append("")
    lines.append("No rho-to-particle mapping is performed.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_qualitative_stability_lifetime_archetype_sanity_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R008_archetype_capacity_ledger.csv",
        out_dir / "V12_10_R008_sanity_ledger.csv",
        out_dir / "V12_10_R008_mode_audit_input.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R008 RESULT ===")
    print("V12.10-R008 COMPLETE")
    print("VERDICT: QUALITATIVE STABILITY / LIFETIME ARCHETYPE SANITY PASS / THREE-CLASS CAPACITY PRESENT, PHYSICAL MAPPING OPEN")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print(f"archetype_capacity_pass: {archetype_pass}")
    print(f"three_class_ecology_present: {three_class_ecology_present}")
    print(f"mapping_open: {mapping_open}")
    print("observations_used_for_tuning: False")
    print("no_empirical_abundances_loaded: True")
    print("no_baryon_to_photon_matching_performed: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_cosmogenesis_claimed: True")
    print(f"selected_seed: {SELECTED_SEED}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("ARCHETYPE_CAPACITY_LEDGER:")
    for a in archetypes:
        print(f"  {a.archetype_id} | count={a.toy_capacity_count} | modes={a.toy_modes_available} | status={a.sanity_status}")
    print("SANITY_LEDGER:")
    for s in sanity_items:
        print(f"  {s.test_id} | result={s.result} | {s.interpretation}")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R008 checks qualitative stability/lifetime archetype capacity in the V12.10 toy. -- It asks whether robust, scenario-dependent, and fragile/transient classes exist.")
    print("  YES | R008 preserves the R007 null boundary. -- It does not claim the exact rho split is unique or null-resistant.")
    print("  NO | R008 maps rho modes to observed particles, sectors, or lifetimes. -- No physical identities are assigned.")
    print("  NO | R008 predicts abundances, BBN yields, baryon-to-photon ratio, or CMB spectra. -- No empirical cosmology data are loaded.")
    print("  NO | R008 closes GR/Boltzmann cosmogenesis. -- This is a qualitative sanity gate.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: V12_10_R009_toy_rollup_gate_or_V12_10_R010_abundance_proxy_gate")
    print("=== END COPY/PASTE V12.10-R008 RESULT ===")


if __name__ == "__main__":
    main()
