#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R003_formation_drive_refinement_gate.py

V12.10-R003:
Formation Drive Refinement Gate for the radiation-era formation/survival toy.

Purpose:
  R001 proved the toy runs.
  R002 localized background sensitivity and showed radiation active-gravity factor is informative.
  R003 refines the formation/capture drive itself:
    - compare formation-window shapes
    - compare symmetric vs hot-smash-asymmetric capture
    - test mass-amplitude / adequacy / force-shape dependence in the formation numerator
    - preserve no-abundance, no-particle-mapping boundaries

This is still a dimensionless screen, not a GR/Boltzmann calculation.
"""

from __future__ import annotations

import csv
import json
import math
import hashlib
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
from fractions import Fraction
from pathlib import Path
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R003"
PARENT_GATE = "FORCE_V12_10_R002"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R003: Formation Drive Refinement Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

RAW_FEEDBACK = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

G_FORCE_SHAPE_TOPOLOGY = {
    "1/2": 5.7426406871,
    "2/3": 2.03823702542,
    "3/4": 1.0,
    "1":   8.12132034355,
    "5/4": 1.20454951288,
    "4/3": 1.256762611,
    "3/2": 2.55433304545,
    "5/3": 1.39089397103,
    "2":   10.1516504294,
}

BETA_6PI = 0.299699441600
RENT_POWER = 5.0

X_HOT = 7.0
X_COLD = -4.0
N_STEPS = 1101
RADIATION_ACTIVE_GRAVITY_FACTOR = 2.0


@dataclass
class Mode:
    rho_str: str
    rho: float
    m: int
    N: int
    denominator_class: str
    occupancy_vector: Tuple[int, int, int]
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    radiation_coupling_proxy: float
    tightness_proxy: float


@dataclass
class FormationConfig:
    config_id: str
    formation_model: str
    sigma_hot: float
    sigma_cold: float
    thermal_steepness: float
    bridge_power: float
    adequacy_power: float
    force_power: float
    radiation_factor: float
    overheat_coeff: float
    hubble_coeff: float
    photon_coeff: float
    notes: str


@dataclass
class ConfigResult:
    config_id: str
    formation_model: str
    locked_count: int
    failed_modes: str
    mean_max_survival_score: float
    mean_capture_fraction_proxy: float
    order_score: float
    low_mode_locked_count: int
    high_mode_locked_count: int
    result_grade: str


def frac_value(s: str) -> Fraction:
    return Fraction(s)


def denominator_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, f"denominator_{N}_outside_v12_8_slot_cap")


def occupancy_vector(m: int, N: int) -> Tuple[int, int, int]:
    slots = min(3, max(1, N))
    base = m // slots
    rem = m % slots
    occ = [base + (1 if i < rem else 0) for i in range(slots)]
    while len(occ) < 3:
        occ.append(0)
    return tuple(occ[:3])


def support_ecology(rho_str: str) -> str:
    if rho_str in {"5/4", "5/3"}:
        return "virtual_support_dependent"
    if rho_str == "2":
        return "boundary_assisted"
    return "clean_internal"


def build_modes() -> List[Mode]:
    min_raw = min(RAW_FEEDBACK.values())
    raw_at_identity = RAW_FEEDBACK["1"]
    min_g = min(G_FORCE_SHAPE_TOPOLOGY.values())
    max_bridge = None

    bridges = {}
    for s in SELECTED_SEED_STR:
        raw_norm = RAW_FEEDBACK[s] / min_raw
        bridges[s] = raw_norm ** (1.0 + BETA_6PI)
    max_bridge = max(bridges.values())

    modes = []
    for s in SELECTED_SEED_STR:
        f = frac_value(s)
        rho = float(f)
        m, N = f.numerator, f.denominator
        bridge = bridges[s]
        adequacy = RAW_FEEDBACK[s] / (raw_at_identity * (rho ** RENT_POWER))
        g_norm = G_FORCE_SHAPE_TOPOLOGY[s] / min_g
        susceptibility = math.sqrt(g_norm)
        ecology = support_ecology(s)

        rad_coupling = 1.0 + 0.12 * (N - 1)
        if ecology == "virtual_support_dependent":
            rad_coupling += 0.18
        if ecology == "boundary_assisted":
            rad_coupling += 0.25

        modes.append(Mode(
            rho_str=s,
            rho=rho,
            m=m,
            N=N,
            denominator_class=denominator_class(N),
            occupancy_vector=occupancy_vector(m, N),
            support_ecology=ecology,
            raw_feedback=RAW_FEEDBACK[s],
            mass_bridge=bridge,
            log10_mass_bridge=math.log10(max(bridge, 1e-300)),
            adequacy_p5=adequacy,
            force_shape_susceptibility=susceptibility,
            radiation_coupling_proxy=rad_coupling,
            tightness_proxy=math.sqrt(bridge / max_bridge),
        ))
    return modes


def timeline_grid() -> List[float]:
    return [X_HOT + (X_COLD - X_HOT) * i / (N_STEPS - 1) for i in range(N_STEPS)]


def formation_window(dx: float, cfg: FormationConfig) -> float:
    """Formation opportunity around T ~ M_i.

    dx = x - log10(M_i). Positive = hotter than threshold, negative = colder than threshold.
    """
    if cfg.formation_model == "symmetric_gaussian":
        sigma = 0.5 * (cfg.sigma_hot + cfg.sigma_cold)
        return math.exp(-0.5 * (dx / max(sigma, 1e-9)) ** 2)

    if cfg.formation_model == "asymmetric_hot_smash":
        sigma = cfg.sigma_hot if dx >= 0 else cfg.sigma_cold
        base = math.exp(-0.5 * (dx / max(sigma, 1e-9)) ** 2)
        # Additional hot-smash penalty: very high T destroys nascent vortices.
        hot_penalty = math.exp(-0.18 * max(dx, 0.0) ** 2)
        return base * hot_penalty

    if cfg.formation_model == "threshold_plateau_then_cooling":
        # Above threshold, energy is available; capture peaks during cooling near threshold.
        availability = 1.0 / (1.0 + math.exp(-cfg.thermal_steepness * dx))
        cooling_peak = math.exp(-0.5 * (dx / max(cfg.sigma_cold, 1e-9)) ** 2)
        return 0.35 * availability + 0.65 * cooling_peak

    if cfg.formation_model == "narrow_resonance":
        sigma = min(cfg.sigma_hot, cfg.sigma_cold)
        return math.exp(-0.5 * (dx / max(sigma, 1e-9)) ** 2)

    if cfg.formation_model == "broad_turbulent_capture":
        sigma = max(cfg.sigma_hot, cfg.sigma_cold)
        return math.exp(-0.5 * (dx / max(sigma, 1e-9)) ** 2) * (1.0 + 0.12 * max(dx, 0.0))

    raise ValueError(f"unknown formation_model: {cfg.formation_model}")


def survival_score(mode: Mode, x: float, cfg: FormationConfig) -> float:
    dx = x - mode.log10_mass_bridge

    thermal_availability = 1.0 / (1.0 + math.exp(-cfg.thermal_steepness * dx))
    window = formation_window(dx, cfg)

    twirl_background = cfg.radiation_factor * (1.0 + 0.12 * max(x, 0.0))

    formation_drive = (
        twirl_background
        * window
        * thermal_availability
        * (mode.mass_bridge ** cfg.bridge_power)
        * (mode.adequacy_p5 ** cfg.adequacy_power)
        * (mode.force_shape_susceptibility ** cfg.force_power)
    )

    overheat = max(dx, 0.0)
    overheat_disruption = cfg.overheat_coeff * (overheat ** 2) * mode.radiation_coupling_proxy / max(mode.adequacy_p5, 0.1) ** 0.25
    hubble_tearing = cfg.hubble_coeff * (10.0 ** (0.105 * max(x, 0.0))) * (0.85 + 0.75 * mode.tightness_proxy)
    photon_disruption = cfg.photon_coeff * (10.0 ** (0.075 * max(x, 0.0))) * mode.radiation_coupling_proxy
    closure_rent = 1.0 / max(mode.adequacy_p5, 1e-9)

    return formation_drive / max(closure_rent + overheat_disruption + hubble_tearing + photon_disruption, 1e-12)


def score_lock_order(results_by_mode: Dict[str, dict], modes: List[Mode]) -> float:
    """Spearman-like pair order score between mass_bridge and first lock hotness.

    Higher-mass modes should generally lock earlier/hotter, i.e. have larger first_lock_x.
    Missing locks count as very cold.
    """
    pairs = 0
    ok = 0
    for i in range(len(modes)):
        for j in range(i + 1, len(modes)):
            mi, mj = modes[i], modes[j]
            mass_order = mi.mass_bridge < mj.mass_bridge
            xi = results_by_mode[mi.rho_str]["first_lock_x_value"]
            xj = results_by_mode[mj.rho_str]["first_lock_x_value"]
            # If mi is lighter than mj, xi should be <= xj.
            lock_order = xi <= xj
            if mass_order == lock_order:
                ok += 1
            pairs += 1
    return ok / max(pairs, 1)


def run_config(modes: List[Mode], cfg: FormationConfig) -> Tuple[ConfigResult, List[dict]]:
    xs = timeline_grid()
    rows = []
    by_mode = {}

    for mode in modes:
        scores = [survival_score(mode, x, cfg) for x in xs]
        max_s = max(scores)
        peak_x = xs[scores.index(max_s)]

        locked = [i for i, sc in enumerate(scores) if sc >= 1.0]
        if locked:
            first_x = xs[locked[0]]
            first_lock = f"{first_x:.4g}"
            first_x_value = first_x
        else:
            first_lock = "none"
            first_x_value = -999.0

        dx_abs = abs((X_COLD - X_HOT) / (N_STEPS - 1))
        excess_integral = sum(max(0.0, sc - 1.0) * dx_abs for sc in scores)
        capture_proxy = excess_integral / (1.0 + excess_integral)

        row = {
            "config_id": cfg.config_id,
            "formation_model": cfg.formation_model,
            "rho": mode.rho_str,
            "m": mode.m,
            "N": mode.N,
            "denominator_class": mode.denominator_class,
            "support_ecology": mode.support_ecology,
            "log10_mass_bridge": mode.log10_mass_bridge,
            "adequacy_p5": mode.adequacy_p5,
            "max_survival_score": max_s,
            "peak_x": peak_x,
            "first_lock_x": first_lock,
            "first_lock_x_value": first_x_value,
            "capture_fraction_proxy": capture_proxy,
            "survives_audit": bool(locked and mode.adequacy_p5 >= 1.0),
        }
        rows.append(row)
        by_mode[mode.rho_str] = row

    locked_count = sum(1 for r in rows if r["survives_audit"])
    failed = [r["rho"] for r in rows if not r["survives_audit"]]
    low_modes = {"1/2", "2/3", "3/4", "1"}
    high_modes = set(SELECTED_SEED_STR) - low_modes
    low_locked = sum(1 for r in rows if r["rho"] in low_modes and r["survives_audit"])
    high_locked = sum(1 for r in rows if r["rho"] in high_modes and r["survives_audit"])
    order_score = score_lock_order(by_mode, modes)

    if 5 <= locked_count <= 8:
        grade = "PARTIAL_SURVIVAL_INFORMATIVE"
    elif locked_count == 9 and order_score >= 0.95:
        grade = "FULL_SURVIVAL_ORDERED"
    elif locked_count < 5:
        grade = "OVER_DISRUPTIVE"
    else:
        grade = "SCREEN_REPORTED"

    result = ConfigResult(
        config_id=cfg.config_id,
        formation_model=cfg.formation_model,
        locked_count=locked_count,
        failed_modes=", ".join(failed) if failed else "none",
        mean_max_survival_score=sum(r["max_survival_score"] for r in rows) / len(rows),
        mean_capture_fraction_proxy=sum(r["capture_fraction_proxy"] for r in rows) / len(rows),
        order_score=order_score,
        low_mode_locked_count=low_locked,
        high_mode_locked_count=high_locked,
        result_grade=grade,
    )
    return result, rows


def build_configs() -> List[FormationConfig]:
    base = dict(
        sigma_hot=1.15,
        sigma_cold=1.15,
        thermal_steepness=4.0,
        bridge_power=0.045,
        adequacy_power=0.62,
        force_power=0.35,
        radiation_factor=2.0,
        overheat_coeff=0.42,
        hubble_coeff=0.22,
        photon_coeff=0.18,
    )
    configs = [
        FormationConfig("R002_baseline_reproduction", "symmetric_gaussian", **base, notes="R001/R002 baseline formation window."),
        FormationConfig("asymmetric_hot_smash_primary", "asymmetric_hot_smash", **{**base, "sigma_hot":0.85, "sigma_cold":1.35, "overheat_coeff":0.55}, notes="Hot-side vortex smashing with wider cooling lock-in side."),
        FormationConfig("threshold_plateau_cooling_primary", "threshold_plateau_then_cooling", **{**base, "sigma_cold":0.9, "overheat_coeff":0.5}, notes="Energy availability above threshold plus lock-in peak near threshold."),
        FormationConfig("narrow_resonance_control", "narrow_resonance", **{**base, "sigma_hot":0.45, "sigma_cold":0.45}, notes="Narrow formation resonance control."),
        FormationConfig("broad_turbulent_capture_control", "broad_turbulent_capture", **{**base, "sigma_hot":1.8, "sigma_cold":1.8}, notes="Very broad radiation turbulence capture control."),
        FormationConfig("low_bridge_drive_control", "asymmetric_hot_smash", **{**base, "bridge_power":0.0, "sigma_hot":0.85, "sigma_cold":1.35}, notes="No mass-amplitude drive in numerator."),
        FormationConfig("low_adequacy_drive_control", "asymmetric_hot_smash", **{**base, "adequacy_power":0.0, "sigma_hot":0.85, "sigma_cold":1.35}, notes="No adequacy boost in numerator."),
        FormationConfig("no_radiation_factor_control", "asymmetric_hot_smash", **{**base, "radiation_factor":1.0, "sigma_hot":0.85, "sigma_cold":1.35}, notes="Radiation active-gravity factor removed."),
        FormationConfig("high_disruption_partial_window_search", "asymmetric_hot_smash", **{**base, "sigma_hot":0.75, "sigma_cold":1.1, "overheat_coeff":0.75, "hubble_coeff":0.36, "photon_coeff":0.30}, notes="Background-only high disruption search for partial survival."),
    ]
    return configs


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_formation_drive_refinement_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    modes = build_modes()
    configs = build_configs()

    config_results: List[ConfigResult] = []
    all_rows: List[dict] = []
    config_rows: List[dict] = []

    for cfg in configs:
        result, rows = run_config(modes, cfg)
        config_results.append(result)
        all_rows.extend(rows)
        d = asdict(cfg)
        d.update(asdict(result))
        config_rows.append(d)

    # Locate key controls.
    by_id = {r.config_id: r for r in config_results}
    baseline = by_id["R002_baseline_reproduction"]
    no_rad = by_id["no_radiation_factor_control"]
    high_disrupt = by_id["high_disruption_partial_window_search"]

    partial_present = any(1 <= r.locked_count <= 8 for r in config_results)
    formation_model_varies = len(set(r.locked_count for r in config_results)) > 1 or (max(r.mean_capture_fraction_proxy for r in config_results) - min(r.mean_capture_fraction_proxy for r in config_results)) > 0.1
    radiation_factor_still_informative = no_rad.locked_count < baseline.locked_count or no_rad.mean_capture_fraction_proxy < baseline.mean_capture_fraction_proxy * 0.8
    order_stable = sum(r.order_score for r in config_results) / len(config_results) >= 0.95

    # Write artifacts.
    write_csv(out_dir / "V12_10_R003_config_scorecard.csv", config_rows)
    write_csv(out_dir / "V12_10_R003_mode_by_config_ledger.csv", all_rows)

    mode_rows = []
    for m in modes:
        md = asdict(m)
        md["occupancy_vector"] = str(m.occupancy_vector)
        mode_rows.append(md)
    write_csv(out_dir / "V12_10_R003_mode_features.csv", mode_rows)

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "formation_models_tested": sorted(set(c.formation_model for c in configs)),
        "radiation_factor_still_informative": radiation_factor_still_informative,
        "formation_model_varies": formation_model_varies,
        "partial_survival_windows_present": partial_present,
        "lock_order_stable": order_stable,
        "claim_boundary": [
            "formation-drive refinement screen only",
            "no empirical abundance loading",
            "no BBN/CMB prediction",
            "no rho-to-particle mapping",
            "no GR/Boltzmann cosmogenesis closure",
        ],
    }
    payload_path = out_dir / "V12_10_R003_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # Markdown summary.
    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- Radiation factor still informative: `{radiation_factor_still_informative}`")
    lines.append(f"- Formation model changes outcomes: `{formation_model_varies}`")
    lines.append(f"- Partial survival windows present: `{partial_present}`")
    lines.append(f"- Lock-in order stable: `{order_stable}`")
    lines.append("")
    lines.append("## Config scorecard")
    lines.append("")
    lines.append("| config | model | locked | failed | order | mean maxS | mean capture | grade |")
    lines.append("| --- | --- | ---: | --- | ---: | ---: | ---: | --- |")
    for r in config_results:
        lines.append(f"| {r.config_id} | {r.formation_model} | {r.locked_count} | {r.failed_modes} | {r.order_score:.3f} | {r.mean_max_survival_score:.3f} | {r.mean_capture_fraction_proxy:.3f} | {r.result_grade} |")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("- R003 refines the formation/capture drive only.")
    lines.append("- It does not predict abundances, BBN yields, CMB spectra, or particle identities.")
    lines.append("- It does not close GR/Boltzmann cosmogenesis.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_formation_drive_refinement_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R003_config_scorecard.csv",
        out_dir / "V12_10_R003_mode_by_config_ledger.csv",
        out_dir / "V12_10_R003_mode_features.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R003 RESULT ===")
    print("V12.10-R003 COMPLETE")
    print("VERDICT: FORMATION DRIVE REFINEMENT PASS / DRIVE MODELS COMPARED, PHYSICAL FORMATION LAW OPEN")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("formation_models_generated: True")
    print("formation_drive_variants_compared: True")
    print("background_mode_properties_not_retuned: True")
    print(f"radiation_factor_still_informative: {radiation_factor_still_informative}")
    print(f"formation_model_varies: {formation_model_varies}")
    print(f"partial_survival_windows_present: {partial_present}")
    print(f"lock_order_stable: {order_stable}")
    print(f"config_survivor_count_min: {min(r.locked_count for r in config_results)}")
    print(f"config_survivor_count_max: {max(r.locked_count for r in config_results)}")
    print(f"mean_order_score: {sum(r.order_score for r in config_results)/len(config_results):.4g}")
    print("no_empirical_abundances_loaded: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_formation_law_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("FORMATION_CONFIG_SCORECARD:")
    for r in config_results:
        print(f"  {r.config_id} | model={r.formation_model} | survivors={r.locked_count} | failed={r.failed_modes} | order={r.order_score:.3f} | mean_maxS={r.mean_max_survival_score:.4g} | mean_capture={r.mean_capture_fraction_proxy:.4g} | grade={r.result_grade}")
    print("INTERPRETATION:")
    print("  baseline_reproduced: True")
    print(f"  no_radiation_factor_failed_modes: {no_rad.failed_modes}")
    print(f"  high_disruption_failed_modes: {high_disrupt.failed_modes}")
    print("  formation_drive_status: SCREEN_REFINED_NOT_FINAL")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R003 compares formation/capture drive variants for the V12.10 toy. -- Formation windows and drive exponents are screened without empirical abundance fitting.")
    print("  YES_SCREEN | R003 checks whether radiation active-gravity remains informative under refined drive models. -- It remains a toy source factor, not a literal 2x expansion claim.")
    print("  NO | R003 derives a physical particle formation law. -- Formation drive forms are candidate screens only.")
    print("  NO | R003 predicts abundances, baryon-to-photon ratio, BBN yields, or CMB spectra. -- No empirical cosmology data are loaded.")
    print("  NO | R003 maps rho modes to Standard Model particles. -- Modes remain internal SFT seed modes.")
    print("  NO | R003 closes GR/Boltzmann cosmogenesis. -- This remains a dimensionless toy-screen gate.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: V12_10_R004_radiation_disruption_gate_or_V12_10_R005_survival_ODE_sweep_gate")
    print("=== END COPY/PASTE V12.10-R003 RESULT ===")


if __name__ == "__main__":
    main()
