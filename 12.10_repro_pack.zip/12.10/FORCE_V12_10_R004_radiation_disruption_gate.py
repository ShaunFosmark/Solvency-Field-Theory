#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R004_radiation_disruption_gate.py

V12.10-R004:
Radiation / Expansion Disruption Gate for the V12.10 cosmogenesis toy.

R001: broad radiation-era survival toy.
R002: background/timeline calibration.
R003: formation-drive refinement.
R004: isolate disruption channels:
  - hot-smash / overheat disruption
  - Hubble tearing / expansion dilution
  - photon/radiation bath disruption
  - denominator/ecology-weighted radiation sensitivity

Claim boundary:
  - dimensionless toy-screen only
  - no empirical abundances
  - no BBN/CMB prediction
  - no rho-to-particle mapping
  - no final cosmogenesis law
"""

from __future__ import annotations

import csv
import json
import math
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
from fractions import Fraction
from pathlib import Path
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R004"
PARENT_GATE = "FORCE_V12_10_R003"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R004: Radiation / Expansion Disruption Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

RAW_FEEDBACK = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

G_FORCE_SHAPE_TOPOLOGY = {
    "1/2": 5.7426406871,
    "2/3": 2.03823702542,
    "3/4": 1.0,
    "1":   8.12132034355,
    "5/4": 1.20454951288,
    "4/3": 1.256762611,
    "3/2": 2.55433304545,
    "5/3": 1.39089397103,
    "2":   10.1516504294,
}

BETA_6PI = 0.299699441600
RENT_POWER = 5.0
X_HOT = 7.0
X_COLD = -4.0
N_STEPS = 1101


@dataclass
class Mode:
    rho_str: str
    rho: float
    m: int
    N: int
    denominator_class: str
    occupancy_vector: Tuple[int, int, int]
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    radiation_coupling_proxy: float
    tightness_proxy: float


@dataclass
class DisruptionConfig:
    config_id: str
    radiation_factor: float
    overheat_coeff: float
    hubble_coeff: float
    photon_coeff: float
    denominator_weight: float
    ecology_weight: float
    tightness_weight: float
    hot_smash_extra: float
    notes: str


@dataclass
class ScenarioSummary:
    config_id: str
    locked_count: int
    failed_modes: str
    mean_max_survival_score: float
    mean_capture_fraction_proxy: float
    low_mode_locked_count: int
    mid_mode_locked_count: int
    high_mode_locked_count: int
    order_score: float
    result_grade: str


def frac_value(s: str) -> Fraction:
    return Fraction(s)


def denominator_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, f"denominator_{N}_outside_v12_8_slot_cap")


def occupancy_vector(m: int, N: int) -> Tuple[int, int, int]:
    slots = min(3, max(1, N))
    base = m // slots
    rem = m % slots
    occ = [base + (1 if i < rem else 0) for i in range(slots)]
    while len(occ) < 3:
        occ.append(0)
    return tuple(occ[:3])


def support_ecology(rho_str: str) -> str:
    if rho_str in {"5/4", "5/3"}:
        return "virtual_support_dependent"
    if rho_str == "2":
        return "boundary_assisted"
    return "clean_internal"


def build_modes() -> List[Mode]:
    min_raw = min(RAW_FEEDBACK.values())
    raw_at_identity = RAW_FEEDBACK["1"]
    min_g = min(G_FORCE_SHAPE_TOPOLOGY.values())

    bridges = {}
    for s in SELECTED_SEED_STR:
        raw_norm = RAW_FEEDBACK[s] / min_raw
        bridges[s] = raw_norm ** (1.0 + BETA_6PI)
    max_bridge = max(bridges.values())

    modes = []
    for s in SELECTED_SEED_STR:
        f = frac_value(s)
        rho = float(f)
        m, N = f.numerator, f.denominator
        ecology = support_ecology(s)
        base_rad = 1.0 + 0.12 * (N - 1)
        if ecology == "virtual_support_dependent":
            base_rad += 0.18
        if ecology == "boundary_assisted":
            base_rad += 0.25

        bridge = bridges[s]
        modes.append(Mode(
            rho_str=s,
            rho=rho,
            m=m,
            N=N,
            denominator_class=denominator_class(N),
            occupancy_vector=occupancy_vector(m, N),
            support_ecology=ecology,
            raw_feedback=RAW_FEEDBACK[s],
            mass_bridge=bridge,
            log10_mass_bridge=math.log10(max(bridge, 1e-300)),
            adequacy_p5=RAW_FEEDBACK[s] / (raw_at_identity * (rho ** RENT_POWER)),
            force_shape_susceptibility=math.sqrt(G_FORCE_SHAPE_TOPOLOGY[s] / min_g),
            radiation_coupling_proxy=base_rad,
            tightness_proxy=math.sqrt(bridge / max_bridge),
        ))
    return modes


def timeline_grid() -> List[float]:
    return [X_HOT + (X_COLD - X_HOT) * i / (N_STEPS - 1) for i in range(N_STEPS)]


def formation_window_asymmetric(dx: float) -> float:
    sigma_hot = 0.85
    sigma_cold = 1.35
    sigma = sigma_hot if dx >= 0 else sigma_cold
    base = math.exp(-0.5 * (dx / sigma) ** 2)
    hot_penalty = math.exp(-0.18 * max(dx, 0.0) ** 2)
    return base * hot_penalty


def mode_radiation_weight(mode: Mode, cfg: DisruptionConfig) -> float:
    denom_part = 1.0 + cfg.denominator_weight * (mode.N - 1) / 3.0
    ecology_part = 1.0
    if mode.support_ecology == "virtual_support_dependent":
        ecology_part += cfg.ecology_weight * 0.6
    if mode.support_ecology == "boundary_assisted":
        ecology_part += cfg.ecology_weight * 0.8
    return mode.radiation_coupling_proxy * denom_part * ecology_part


def survival_score(mode: Mode, x: float, cfg: DisruptionConfig) -> float:
    dx = x - mode.log10_mass_bridge

    thermal_availability = 1.0 / (1.0 + math.exp(-4.0 * dx))
    window = formation_window_asymmetric(dx)

    twirl_background = cfg.radiation_factor * (1.0 + 0.12 * max(x, 0.0))
    formation_drive = (
        twirl_background
        * window
        * thermal_availability
        * (mode.mass_bridge ** 0.045)
        * (mode.adequacy_p5 ** 0.62)
        * (mode.force_shape_susceptibility ** 0.35)
    )

    rad_weight = mode_radiation_weight(mode, cfg)
    overheat = max(dx, 0.0)

    overheat_disruption = cfg.overheat_coeff * (overheat ** 2) * rad_weight / max(mode.adequacy_p5, 0.1) ** 0.25
    overheat_disruption *= (1.0 + cfg.hot_smash_extra * max(dx - 0.75, 0.0))

    hubble_disruption = (
        cfg.hubble_coeff
        * (10.0 ** (0.105 * max(x, 0.0)))
        * (0.85 + (0.75 + cfg.tightness_weight) * mode.tightness_proxy)
    )

    photon_disruption = cfg.photon_coeff * (10.0 ** (0.075 * max(x, 0.0))) * rad_weight

    closure_rent = 1.0 / max(mode.adequacy_p5, 1e-9)

    return formation_drive / max(closure_rent + overheat_disruption + hubble_disruption + photon_disruption, 1e-12)


def score_lock_order(mode_rows: Dict[str, dict], modes: List[Mode]) -> float:
    pairs = 0
    ok = 0
    for i in range(len(modes)):
        for j in range(i + 1, len(modes)):
            mi, mj = modes[i], modes[j]
            mass_order = mi.mass_bridge < mj.mass_bridge
            xi = mode_rows[mi.rho_str]["first_lock_x_value"]
            xj = mode_rows[mj.rho_str]["first_lock_x_value"]
            lock_order = xi <= xj
            if mass_order == lock_order:
                ok += 1
            pairs += 1
    return ok / max(pairs, 1)


def run_config(modes: List[Mode], cfg: DisruptionConfig) -> Tuple[ScenarioSummary, List[dict]]:
    xs = timeline_grid()
    rows = []
    by_mode = {}

    for mode in modes:
        scores = [survival_score(mode, x, cfg) for x in xs]
        max_s = max(scores)
        peak_x = xs[scores.index(max_s)]
        locked_i = [i for i, sc in enumerate(scores) if sc >= 1.0]
        if locked_i:
            first_x = xs[locked_i[0]]
            first_lock = f"{first_x:.4g}"
            first_x_value = first_x
        else:
            first_lock = "none"
            first_x_value = -999.0

        dx_abs = abs((X_COLD - X_HOT) / (N_STEPS - 1))
        excess = sum(max(0.0, sc - 1.0) * dx_abs for sc in scores)
        capture = excess / (1.0 + excess)
        survives = bool(locked_i and mode.adequacy_p5 >= 1.0)

        row = {
            "config_id": cfg.config_id,
            "rho": mode.rho_str,
            "m": mode.m,
            "N": mode.N,
            "denominator_class": mode.denominator_class,
            "support_ecology": mode.support_ecology,
            "log10_mass_bridge": mode.log10_mass_bridge,
            "adequacy_p5": mode.adequacy_p5,
            "radiation_weight": mode_radiation_weight(mode, cfg),
            "max_survival_score": max_s,
            "peak_x": peak_x,
            "first_lock_x": first_lock,
            "first_lock_x_value": first_x_value,
            "capture_fraction_proxy": capture,
            "survives_audit": survives,
        }
        rows.append(row)
        by_mode[mode.rho_str] = row

    locked_count = sum(1 for r in rows if r["survives_audit"])
    failed_modes = [r["rho"] for r in rows if not r["survives_audit"]]
    low = {"1/2", "2/3", "3/4", "1"}
    mid = {"5/4", "4/3", "3/2"}
    high = {"5/3", "2"}

    order = score_lock_order(by_mode, modes)

    if 5 <= locked_count <= 8:
        grade = "PARTIAL_SURVIVAL_DISRUPTION_INFORMATIVE"
    elif locked_count == 9:
        grade = "FULL_SURVIVAL_DISRUPTION_WEAK"
    elif locked_count < 5:
        grade = "OVER_DISRUPTIVE_CONTROL"
    else:
        grade = "SCREEN_REPORTED"

    summary = ScenarioSummary(
        config_id=cfg.config_id,
        locked_count=locked_count,
        failed_modes=", ".join(failed_modes) if failed_modes else "none",
        mean_max_survival_score=sum(r["max_survival_score"] for r in rows) / len(rows),
        mean_capture_fraction_proxy=sum(r["capture_fraction_proxy"] for r in rows) / len(rows),
        low_mode_locked_count=sum(1 for r in rows if r["rho"] in low and r["survives_audit"]),
        mid_mode_locked_count=sum(1 for r in rows if r["rho"] in mid and r["survives_audit"]),
        high_mode_locked_count=sum(1 for r in rows if r["rho"] in high and r["survives_audit"]),
        order_score=order,
        result_grade=grade,
    )
    return summary, rows


def build_configs() -> List[DisruptionConfig]:
    base = dict(
        radiation_factor=2.0,
        overheat_coeff=0.55,
        hubble_coeff=0.22,
        photon_coeff=0.18,
        denominator_weight=0.0,
        ecology_weight=0.0,
        tightness_weight=0.0,
        hot_smash_extra=0.0,
    )

    return [
        DisruptionConfig("R003_asymmetric_baseline", **base, notes="R003 primary asymmetric formation model."),
        DisruptionConfig("remove_overheat_disruption", **{**base, "overheat_coeff":0.0}, notes="No hot-smash disruption."),
        DisruptionConfig("remove_hubble_tearing", **{**base, "hubble_coeff":0.0}, notes="No Hubble/expansion tearing term."),
        DisruptionConfig("remove_photon_bath_disruption", **{**base, "photon_coeff":0.0}, notes="No photon/radiation bath disruption term."),
        DisruptionConfig("high_overheat_disruption", **{**base, "overheat_coeff":1.2, "hot_smash_extra":0.25}, notes="Strong hot-smash disruption."),
        DisruptionConfig("high_hubble_tearing", **{**base, "hubble_coeff":0.55, "tightness_weight":0.55}, notes="Strong expansion tearing, tightness weighted."),
        DisruptionConfig("high_photon_bath_disruption", **{**base, "photon_coeff":0.55}, notes="Strong photon/radiation bath disruption."),
        DisruptionConfig("denominator_weighted_photon_disruption", **{**base, "photon_coeff":0.42, "denominator_weight":0.9}, notes="Denominator/slot-sensitive photon disruption."),
        DisruptionConfig("ecology_weighted_disruption", **{**base, "photon_coeff":0.38, "denominator_weight":0.5, "ecology_weight":0.9}, notes="Virtual/boundary-support sensitive radiation disruption."),
        DisruptionConfig("aggressive_full_disruption_control", **{**base, "overheat_coeff":1.15, "hubble_coeff":0.48, "photon_coeff":0.50, "denominator_weight":0.8, "ecology_weight":0.8, "tightness_weight":0.35, "hot_smash_extra":0.35}, notes="Aggressive combined disruption control."),
        DisruptionConfig("no_radiation_double_burden_reference", **{**base, "radiation_factor":1.0}, notes="Reference control: radiation active-gravity factor removed."),
    ]


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_radiation_disruption_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    modes = build_modes()
    configs = build_configs()

    summaries: List[ScenarioSummary] = []
    all_rows: List[dict] = []
    config_rows: List[dict] = []

    for cfg in configs:
        summary, rows = run_config(modes, cfg)
        summaries.append(summary)
        all_rows.extend(rows)
        cfg_row = asdict(cfg)
        cfg_row.update(asdict(summary))
        config_rows.append(cfg_row)

    by_id = {s.config_id: s for s in summaries}
    baseline = by_id["R003_asymmetric_baseline"]

    channel_rows = []
    for s in summaries:
        if s.config_id == baseline.config_id:
            continue
        channel_rows.append({
            "config_id": s.config_id,
            "delta_locked_vs_baseline": s.locked_count - baseline.locked_count,
            "delta_mean_maxS_vs_baseline": s.mean_max_survival_score - baseline.mean_max_survival_score,
            "delta_mean_capture_vs_baseline": s.mean_capture_fraction_proxy - baseline.mean_capture_fraction_proxy,
            "failed_modes": s.failed_modes,
            "interpretation": "disruption_channel_informative" if s.locked_count != baseline.locked_count or abs(s.mean_capture_fraction_proxy - baseline.mean_capture_fraction_proxy) > 0.08 else "weak_channel_effect",
        })

    survivor_counts = [s.locked_count for s in summaries]
    disruption_survival_varies = min(survivor_counts) < max(survivor_counts)
    partial_survival_present = any(1 <= s.locked_count <= 8 for s in summaries)
    no_rad_failed = by_id["no_radiation_double_burden_reference"].failed_modes
    aggressive_failed = by_id["aggressive_full_disruption_control"].failed_modes
    denominator_or_ecology_informative = (
        by_id["denominator_weighted_photon_disruption"].locked_count < baseline.locked_count
        or by_id["ecology_weighted_disruption"].locked_count < baseline.locked_count
        or abs(by_id["denominator_weighted_photon_disruption"].mean_capture_fraction_proxy - baseline.mean_capture_fraction_proxy) > 0.08
        or abs(by_id["ecology_weighted_disruption"].mean_capture_fraction_proxy - baseline.mean_capture_fraction_proxy) > 0.08
    )
    radiation_factor_informative = by_id["no_radiation_double_burden_reference"].locked_count < baseline.locked_count

    write_csv(out_dir / "V12_10_R004_disruption_config_scorecard.csv", config_rows)
    write_csv(out_dir / "V12_10_R004_mode_by_config_ledger.csv", all_rows)
    write_csv(out_dir / "V12_10_R004_channel_effect_ledger.csv", channel_rows)

    mode_rows = []
    for m in modes:
        d = asdict(m)
        d["occupancy_vector"] = str(m.occupancy_vector)
        mode_rows.append(d)
    write_csv(out_dir / "V12_10_R004_mode_features.csv", mode_rows)

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "disruption_survival_varies": disruption_survival_varies,
        "partial_survival_present": partial_survival_present,
        "radiation_factor_informative": radiation_factor_informative,
        "denominator_or_ecology_informative": denominator_or_ecology_informative,
        "claim_boundary": [
            "radiation/expansion disruption screen only",
            "no empirical abundance loading",
            "no BBN/CMB prediction",
            "no rho-to-particle mapping",
            "no final cosmogenesis law",
        ],
    }
    payload_path = out_dir / "V12_10_R004_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- Disruption survival varies: `{disruption_survival_varies}`")
    lines.append(f"- Partial survival present: `{partial_survival_present}`")
    lines.append(f"- Radiation factor informative: `{radiation_factor_informative}`")
    lines.append(f"- Denominator/ecology disruption informative: `{denominator_or_ecology_informative}`")
    lines.append("")
    lines.append("## Disruption scorecard")
    lines.append("")
    lines.append("| config | locked | failed | low/mid/high | order | mean maxS | mean capture | grade |")
    lines.append("| --- | ---: | --- | --- | ---: | ---: | ---: | --- |")
    for s in summaries:
        lines.append(f"| {s.config_id} | {s.locked_count} | {s.failed_modes} | {s.low_mode_locked_count}/{s.mid_mode_locked_count}/{s.high_mode_locked_count} | {s.order_score:.3f} | {s.mean_max_survival_score:.3f} | {s.mean_capture_fraction_proxy:.3f} | {s.result_grade} |")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("- R004 isolates toy disruption channels only.")
    lines.append("- It does not predict physical abundances, BBN yields, CMB spectra, or particle identities.")
    lines.append("- It does not close GR/Boltzmann cosmogenesis.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_radiation_disruption_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R004_disruption_config_scorecard.csv",
        out_dir / "V12_10_R004_mode_by_config_ledger.csv",
        out_dir / "V12_10_R004_channel_effect_ledger.csv",
        out_dir / "V12_10_R004_mode_features.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R004 RESULT ===")
    print("V12.10-R004 COMPLETE")
    print("VERDICT: RADIATION / EXPANSION DISRUPTION PASS / DISRUPTION CHANNELS LOCALIZED, PHYSICAL COSMOGENESIS OPEN")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("disruption_configs_generated: True")
    print("channel_effect_ledger_generated: True")
    print("mode_by_config_ledger_generated: True")
    print(f"disruption_survival_varies: {disruption_survival_varies}")
    print(f"partial_survival_present: {partial_survival_present}")
    print(f"radiation_factor_informative: {radiation_factor_informative}")
    print(f"denominator_or_ecology_informative: {denominator_or_ecology_informative}")
    print(f"survivor_count_min: {min(survivor_counts)}")
    print(f"survivor_count_max: {max(survivor_counts)}")
    print("no_empirical_abundances_loaded: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_disruption_law_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("DISRUPTION_CONFIG_SCORECARD:")
    for s in summaries:
        print(f"  {s.config_id} | survivors={s.locked_count} | failed={s.failed_modes} | low/mid/high={s.low_mode_locked_count}/{s.mid_mode_locked_count}/{s.high_mode_locked_count} | order={s.order_score:.3f} | mean_maxS={s.mean_max_survival_score:.4g} | mean_capture={s.mean_capture_fraction_proxy:.4g} | grade={s.result_grade}")
    print("CHANNEL_LOCALIZATION:")
    print(f"  no_radiation_double_burden_failed_modes: {no_rad_failed}")
    print(f"  aggressive_full_disruption_failed_modes: {aggressive_failed}")
    print("  disruption_channel_status: SCREEN_LOCALIZED_NOT_FINAL")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R004 isolates radiation/expansion disruption channels for the V12.10 toy. -- Overheat, Hubble tearing, photon bath, denominator, and ecology weights are screened.")
    print("  YES_SCREEN | R004 checks whether disruption channels create partial survival windows. -- Background/disruption knobs are varied without retuning mode properties.")
    print("  NO | R004 derives a physical disruption law or cosmogenesis equation. -- Disruption terms are candidate screens only.")
    print("  NO | R004 predicts abundances, BBN yields, baryon-to-photon ratio, or CMB spectra. -- No empirical cosmology data are loaded.")
    print("  NO | R004 maps rho modes to Standard Model particles. -- Modes remain internal SFT seed modes.")
    print("  NO | R004 closes GR/Boltzmann cosmogenesis. -- This remains a dimensionless toy-screen gate.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: V12_10_R005_survival_ODE_sweep_gate_or_V12_10_R006_recombination_audit_gate")
    print("=== END COPY/PASTE V12.10-R004 RESULT ===")


if __name__ == "__main__":
    main()
