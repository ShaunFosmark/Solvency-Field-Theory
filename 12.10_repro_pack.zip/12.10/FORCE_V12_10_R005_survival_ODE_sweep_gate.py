#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R005_survival_ODE_sweep_gate.py

V12.10-R005:
Survival ODE / Freezeout Sweep Gate.

R001: broad radiation-era survival toy.
R002: timeline/background calibration.
R003: formation-drive refinement.
R004: radiation/expansion disruption localization.
R005: turn instantaneous survival score into an integrated formation/destruction ODE.

Purpose:
  - Compute a dimensionless abundance/capture state Y_i(x) for each V12.8/V12.9 seed mode.
  - Use formation and destruction rates derived from the R003/R004 screen terms.
  - Sweep only global cosmology/toy clock/disruption parameters; do not retune mode data.
  - Report freezeout / lock-in order, final survival proxies, and fragile modes.

Claim boundary:
  - toy ODE screen only
  - no empirical abundances loaded
  - no baryon-to-photon matching
  - no BBN/CMB prediction
  - no rho-to-particle mapping
  - no GR/Boltzmann closure
"""

from __future__ import annotations

import csv
import json
import math
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
from fractions import Fraction
from pathlib import Path
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R005"
PARENT_GATE = "FORCE_V12_10_R004"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R005: Survival ODE / Freezeout Sweep Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

RAW_FEEDBACK = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

G_FORCE_SHAPE_TOPOLOGY = {
    "1/2": 5.7426406871,
    "2/3": 2.03823702542,
    "3/4": 1.0,
    "1":   8.12132034355,
    "5/4": 1.20454951288,
    "4/3": 1.256762611,
    "3/2": 2.55433304545,
    "5/3": 1.39089397103,
    "2":   10.1516504294,
}

BETA_6PI = 0.299699441600
RENT_POWER = 5.0
X_HOT = 7.0
X_COLD = -4.0
N_STEPS = 2201


@dataclass
class Mode:
    rho_str: str
    rho: float
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    radiation_coupling_proxy: float
    tightness_proxy: float


@dataclass
class ODEScenario:
    scenario_id: str
    radiation_factor: float
    overheat_coeff: float
    hubble_coeff: float
    photon_coeff: float
    denominator_weight: float
    ecology_weight: float
    tightness_weight: float
    hot_smash_extra: float
    formation_rate_scale: float
    destruction_rate_scale: float
    cooling_clock_scale: float
    freeze_threshold: float
    notes: str


@dataclass
class ODESummary:
    scenario_id: str
    final_survivor_count: int
    robust_survivor_count: int
    fragile_modes: str
    failed_modes: str
    mean_final_Y: float
    mean_peak_Y: float
    mean_freeze_x: float
    lock_order_score: float
    result_grade: str


def frac_value(s: str) -> Fraction:
    return Fraction(s)


def denominator_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, f"denominator_{N}_outside_v12_8_slot_cap")


def support_ecology(rho_str: str) -> str:
    if rho_str in {"5/4", "5/3"}:
        return "virtual_support_dependent"
    if rho_str == "2":
        return "boundary_assisted"
    return "clean_internal"


def build_modes() -> List[Mode]:
    min_raw = min(RAW_FEEDBACK.values())
    raw_at_identity = RAW_FEEDBACK["1"]
    min_g = min(G_FORCE_SHAPE_TOPOLOGY.values())

    bridges = {}
    for s in SELECTED_SEED_STR:
        raw_norm = RAW_FEEDBACK[s] / min_raw
        bridges[s] = raw_norm ** (1.0 + BETA_6PI)
    max_bridge = max(bridges.values())

    modes = []
    for s in SELECTED_SEED_STR:
        f = frac_value(s)
        rho = float(f)
        m, N = f.numerator, f.denominator
        ecology = support_ecology(s)
        base_rad = 1.0 + 0.12 * (N - 1)
        if ecology == "virtual_support_dependent":
            base_rad += 0.18
        if ecology == "boundary_assisted":
            base_rad += 0.25

        bridge = bridges[s]
        modes.append(Mode(
            rho_str=s,
            rho=rho,
            m=m,
            N=N,
            denominator_class=denominator_class(N),
            support_ecology=ecology,
            raw_feedback=RAW_FEEDBACK[s],
            mass_bridge=bridge,
            log10_mass_bridge=math.log10(max(bridge, 1e-300)),
            adequacy_p5=RAW_FEEDBACK[s] / (raw_at_identity * (rho ** RENT_POWER)),
            force_shape_susceptibility=math.sqrt(G_FORCE_SHAPE_TOPOLOGY[s] / min_g),
            radiation_coupling_proxy=base_rad,
            tightness_proxy=math.sqrt(bridge / max_bridge),
        ))
    return modes


def timeline_grid() -> List[float]:
    return [X_HOT + (X_COLD - X_HOT) * i / (N_STEPS - 1) for i in range(N_STEPS)]


def formation_window_asymmetric(dx: float) -> float:
    sigma_hot = 0.85
    sigma_cold = 1.35
    sigma = sigma_hot if dx >= 0 else sigma_cold
    base = math.exp(-0.5 * (dx / sigma) ** 2)
    hot_penalty = math.exp(-0.18 * max(dx, 0.0) ** 2)
    return base * hot_penalty


def mode_radiation_weight(mode: Mode, sc: ODEScenario) -> float:
    denom_part = 1.0 + sc.denominator_weight * (mode.N - 1) / 3.0
    ecology_part = 1.0
    if mode.support_ecology == "virtual_support_dependent":
        ecology_part += sc.ecology_weight * 0.6
    if mode.support_ecology == "boundary_assisted":
        ecology_part += sc.ecology_weight * 0.8
    return mode.radiation_coupling_proxy * denom_part * ecology_part


def instantaneous_terms(mode: Mode, x: float, sc: ODEScenario) -> Dict[str, float]:
    dx = x - mode.log10_mass_bridge

    thermal_availability = 1.0 / (1.0 + math.exp(-4.0 * dx))
    window = formation_window_asymmetric(dx)
    twirl_background = sc.radiation_factor * (1.0 + 0.12 * max(x, 0.0))

    formation_drive = (
        twirl_background
        * window
        * thermal_availability
        * (mode.mass_bridge ** 0.045)
        * (mode.adequacy_p5 ** 0.62)
        * (mode.force_shape_susceptibility ** 0.35)
    )

    rad_weight = mode_radiation_weight(mode, sc)
    overheat = max(dx, 0.0)

    overheat_disruption = sc.overheat_coeff * (overheat ** 2) * rad_weight / max(mode.adequacy_p5, 0.1) ** 0.25
    overheat_disruption *= (1.0 + sc.hot_smash_extra * max(dx - 0.75, 0.0))

    hubble_disruption = (
        sc.hubble_coeff
        * (10.0 ** (0.105 * max(x, 0.0)))
        * (0.85 + (0.75 + sc.tightness_weight) * mode.tightness_proxy)
    )

    photon_disruption = sc.photon_coeff * (10.0 ** (0.075 * max(x, 0.0))) * rad_weight
    closure_rent = 1.0 / max(mode.adequacy_p5, 1e-9)

    disruption_total = closure_rent + overheat_disruption + hubble_disruption + photon_disruption
    survival_score = formation_drive / max(disruption_total, 1e-12)

    # Convert screen terms into dimensionless ODE rates.
    # Formation rate is localized to the formation drive and saturates as Y approaches 1.
    # Destruction rate is strongest when disruption beats formation and during overheat.
    gamma_form = sc.formation_rate_scale * formation_drive / (1.0 + disruption_total)
    gamma_destroy = sc.destruction_rate_scale * disruption_total / (1.0 + formation_drive)
    gamma_destroy *= 0.35 + 0.65 / (1.0 + mode.adequacy_p5)  # high adequacy is more robust

    # Cooling/freezeout: as x becomes cold, interactions stop changing Y rapidly.
    # This is a toy decoupling/freeze factor, not physical recombination.
    cooling_suppression = 1.0 / (1.0 + math.exp(-2.0 * (x - (-2.0))))
    gamma_form *= cooling_suppression
    gamma_destroy *= cooling_suppression

    return {
        "formation_drive": formation_drive,
        "disruption_total": disruption_total,
        "survival_score": survival_score,
        "gamma_form": gamma_form,
        "gamma_destroy": gamma_destroy,
    }


def integrate_mode(mode: Mode, sc: ODEScenario) -> Dict[str, float | str | bool]:
    xs = timeline_grid()
    dx_abs = abs((X_COLD - X_HOT) / (N_STEPS - 1))
    Y = 0.0
    peakY = 0.0
    peakS = 0.0
    freeze_x = None
    first_score_lock_x = None
    accumulated_supercritical = 0.0

    for x in xs:
        terms = instantaneous_terms(mode, x, sc)
        S = terms["survival_score"]
        peakS = max(peakS, S)
        if S >= 1.0 and first_score_lock_x is None:
            first_score_lock_x = x

        if S >= 1.0:
            accumulated_supercritical += dx_abs

        # ODE step over cooling time. Larger cooling_clock_scale means more reaction time per dlogT.
        dtau = dx_abs * sc.cooling_clock_scale

        dY = (terms["gamma_form"] * (1.0 - Y) - terms["gamma_destroy"] * Y) * dtau
        Y = max(0.0, min(1.0, Y + dY))
        peakY = max(peakY, Y)

        if freeze_x is None and Y >= sc.freeze_threshold and S >= 1.0:
            freeze_x = x

    finalY = Y
    robust = finalY >= sc.freeze_threshold and mode.adequacy_p5 >= 1.0
    fragile = (0.05 <= finalY < sc.freeze_threshold) or (peakS >= 1.0 and finalY < sc.freeze_threshold)

    return {
        "scenario_id": sc.scenario_id,
        "rho": mode.rho_str,
        "m": mode.m,
        "N": mode.N,
        "denominator_class": mode.denominator_class,
        "support_ecology": mode.support_ecology,
        "log10_mass_bridge": mode.log10_mass_bridge,
        "adequacy_p5": mode.adequacy_p5,
        "peak_survival_score": peakS,
        "final_Y_proxy": finalY,
        "peak_Y_proxy": peakY,
        "freeze_x": "none" if freeze_x is None else f"{freeze_x:.4g}",
        "freeze_x_value": -999.0 if freeze_x is None else freeze_x,
        "first_score_lock_x": "none" if first_score_lock_x is None else f"{first_score_lock_x:.4g}",
        "supercritical_window_width": accumulated_supercritical,
        "robust_survivor": robust,
        "fragile_candidate": fragile,
        "status": "ROBUST_SURVIVOR_TO_COLD_AUDIT" if robust else ("FRAGILE_OR_TRANSIENT" if fragile else "FAILED_INTEGRATED_ODE"),
    }


def order_score(rows_by_rho: Dict[str, dict], modes: List[Mode]) -> float:
    pairs = 0
    ok = 0
    for i in range(len(modes)):
        for j in range(i + 1, len(modes)):
            mi, mj = modes[i], modes[j]
            mass_order = mi.mass_bridge < mj.mass_bridge
            xi = rows_by_rho[mi.rho_str]["freeze_x_value"]
            xj = rows_by_rho[mj.rho_str]["freeze_x_value"]
            lock_order = xi <= xj
            if mass_order == lock_order:
                ok += 1
            pairs += 1
    return ok / max(pairs, 1)


def run_scenario(modes: List[Mode], sc: ODEScenario) -> Tuple[ODESummary, List[dict]]:
    rows = [integrate_mode(m, sc) for m in modes]
    by_rho = {r["rho"]: r for r in rows}

    robust = [r for r in rows if r["robust_survivor"]]
    fragile = [r for r in rows if r["fragile_candidate"] and not r["robust_survivor"]]
    failed = [r for r in rows if not r["robust_survivor"] and not r["fragile_candidate"]]

    freeze_values = [r["freeze_x_value"] for r in robust if r["freeze_x_value"] > -900]
    mean_freeze_x = sum(freeze_values) / len(freeze_values) if freeze_values else -999.0

    if len(robust) == 9:
        grade = "FULL_ODE_SURVIVAL"
    elif 5 <= len(robust) <= 8:
        grade = "PARTIAL_ODE_SURVIVAL_INFORMATIVE"
    elif len(robust) < 5 and len(fragile) > 0:
        grade = "MOSTLY_FRAGILE"
    else:
        grade = "OVER_DISRUPTIVE"

    summary = ODESummary(
        scenario_id=sc.scenario_id,
        final_survivor_count=len([r for r in rows if r["final_Y_proxy"] >= 0.05]),
        robust_survivor_count=len(robust),
        fragile_modes=", ".join(r["rho"] for r in fragile) if fragile else "none",
        failed_modes=", ".join(r["rho"] for r in failed) if failed else "none",
        mean_final_Y=sum(float(r["final_Y_proxy"]) for r in rows) / len(rows),
        mean_peak_Y=sum(float(r["peak_Y_proxy"]) for r in rows) / len(rows),
        mean_freeze_x=mean_freeze_x,
        lock_order_score=order_score(by_rho, modes),
        result_grade=grade,
    )
    return summary, rows


def build_scenarios() -> List[ODEScenario]:
    base = dict(
        radiation_factor=2.0,
        overheat_coeff=0.55,
        hubble_coeff=0.22,
        photon_coeff=0.18,
        denominator_weight=0.0,
        ecology_weight=0.0,
        tightness_weight=0.0,
        hot_smash_extra=0.0,
        formation_rate_scale=0.95,
        destruction_rate_scale=0.26,
        cooling_clock_scale=1.0,
        freeze_threshold=0.22,
    )
    return [
        ODEScenario("baseline_ODE_R003_R004", **base, notes="ODE translation of R003/R004 primary screen."),
        ODEScenario("fast_cooling_less_reaction_time", **{**base, "cooling_clock_scale":0.55}, notes="Faster expansion/cooling gives less time to lock."),
        ODEScenario("slow_cooling_more_reaction_time", **{**base, "cooling_clock_scale":1.8}, notes="Slower cooling gives more time to lock."),
        ODEScenario("strong_photon_disruption_ODE", **{**base, "photon_coeff":0.52, "destruction_rate_scale":0.34}, notes="Photon-bath disruption emphasized."),
        ODEScenario("denominator_ecology_disruption_ODE", **{**base, "photon_coeff":0.40, "denominator_weight":0.85, "ecology_weight":0.85, "destruction_rate_scale":0.34}, notes="Slot/ecology-sensitive disruption."),
        ODEScenario("no_radiation_double_burden_ODE", **{**base, "radiation_factor":1.0}, notes="Radiation active-gravity source removed."),
        ODEScenario("weak_formation_drive_ODE", **{**base, "formation_rate_scale":0.55}, notes="Reduced formation/capture rate."),
        ODEScenario("strong_destruction_drive_ODE", **{**base, "destruction_rate_scale":0.52, "photon_coeff":0.38, "hubble_coeff":0.36}, notes="Strong integrated destruction control."),
        ODEScenario("permissive_lock_control", **{**base, "formation_rate_scale":1.3, "destruction_rate_scale":0.18, "freeze_threshold":0.18}, notes="Permissive full-survival control."),
        ODEScenario("strict_lock_control", **{**base, "formation_rate_scale":0.75, "destruction_rate_scale":0.36, "freeze_threshold":0.32}, notes="Strict lock threshold and higher destruction."),
    ]


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_survival_ODE_sweep_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    modes = build_modes()
    scenarios = build_scenarios()

    all_rows: List[dict] = []
    summary_rows: List[dict] = []
    summaries: List[ODESummary] = []

    for sc in scenarios:
        summary, rows = run_scenario(modes, sc)
        summaries.append(summary)
        all_rows.extend(rows)
        d = asdict(sc)
        d.update(asdict(summary))
        summary_rows.append(d)

    by_id = {s.scenario_id: s for s in summaries}
    baseline = by_id["baseline_ODE_R003_R004"]

    partial_ODE_windows_present = any(1 <= s.robust_survivor_count <= 8 for s in summaries)
    ODE_survival_varies = min(s.robust_survivor_count for s in summaries) < max(s.robust_survivor_count for s in summaries)
    radiation_factor_informative = by_id["no_radiation_double_burden_ODE"].robust_survivor_count < baseline.robust_survivor_count
    cooling_clock_informative = (
        by_id["fast_cooling_less_reaction_time"].robust_survivor_count != baseline.robust_survivor_count
        or abs(by_id["fast_cooling_less_reaction_time"].mean_final_Y - baseline.mean_final_Y) > 0.05
        or abs(by_id["slow_cooling_more_reaction_time"].mean_final_Y - baseline.mean_final_Y) > 0.05
    )
    disruption_informative = (
        by_id["strong_photon_disruption_ODE"].robust_survivor_count < baseline.robust_survivor_count
        or by_id["denominator_ecology_disruption_ODE"].robust_survivor_count < baseline.robust_survivor_count
        or by_id["strong_destruction_drive_ODE"].robust_survivor_count < baseline.robust_survivor_count
    )
    lock_order_stable = sum(s.lock_order_score for s in summaries) / len(summaries) >= 0.88

    mode_rows = []
    for m in modes:
        mode_rows.append(asdict(m))

    write_csv(out_dir / "V12_10_R005_ODE_scenario_scorecard.csv", summary_rows)
    write_csv(out_dir / "V12_10_R005_mode_by_scenario_ledger.csv", all_rows)
    write_csv(out_dir / "V12_10_R005_mode_features.csv", mode_rows)

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "ODE_survival_varies": ODE_survival_varies,
        "partial_ODE_windows_present": partial_ODE_windows_present,
        "radiation_factor_informative": radiation_factor_informative,
        "cooling_clock_informative": cooling_clock_informative,
        "disruption_informative": disruption_informative,
        "lock_order_stable": lock_order_stable,
        "claim_boundary": [
            "dimensionless survival ODE screen only",
            "no empirical abundance loading",
            "no BBN/CMB prediction",
            "no rho-to-particle mapping",
            "no final cosmogenesis law",
        ],
    }
    payload_path = out_dir / "V12_10_R005_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- ODE survival varies: `{ODE_survival_varies}`")
    lines.append(f"- Partial ODE windows present: `{partial_ODE_windows_present}`")
    lines.append(f"- Radiation factor informative: `{radiation_factor_informative}`")
    lines.append(f"- Cooling clock informative: `{cooling_clock_informative}`")
    lines.append(f"- Disruption informative: `{disruption_informative}`")
    lines.append(f"- Lock order stable: `{lock_order_stable}`")
    lines.append("")
    lines.append("## Scenario scorecard")
    lines.append("")
    lines.append("| scenario | robust | fragile | failed | mean final Y | mean peak Y | order | grade |")
    lines.append("| --- | ---: | --- | --- | ---: | ---: | ---: | --- |")
    for s in summaries:
        lines.append(f"| {s.scenario_id} | {s.robust_survivor_count} | {s.fragile_modes} | {s.failed_modes} | {s.mean_final_Y:.3f} | {s.mean_peak_Y:.3f} | {s.lock_order_score:.3f} | {s.result_grade} |")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("- R005 is an integrated toy ODE screen, not a physical Boltzmann calculation.")
    lines.append("- It does not predict physical abundances, BBN yields, CMB spectra, or particle identities.")
    lines.append("- It does not close GR/Boltzmann cosmogenesis.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_survival_ODE_sweep_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R005_ODE_scenario_scorecard.csv",
        out_dir / "V12_10_R005_mode_by_scenario_ledger.csv",
        out_dir / "V12_10_R005_mode_features.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R005 RESULT ===")
    print("V12.10-R005 COMPLETE")
    print("VERDICT: SURVIVAL ODE / FREEZEOUT SWEEP PASS / INTEGRATED SURVIVAL WINDOWS REPORTED, PHYSICAL ABUNDANCES OPEN")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("ODE_scenarios_generated: True")
    print("mode_by_scenario_ledger_generated: True")
    print("freezeout_proxy_generated: True")
    print(f"ODE_survival_varies: {ODE_survival_varies}")
    print(f"partial_ODE_windows_present: {partial_ODE_windows_present}")
    print(f"radiation_factor_informative: {radiation_factor_informative}")
    print(f"cooling_clock_informative: {cooling_clock_informative}")
    print(f"disruption_informative: {disruption_informative}")
    print(f"lock_order_stable: {lock_order_stable}")
    print(f"robust_survivor_count_min: {min(s.robust_survivor_count for s in summaries)}")
    print(f"robust_survivor_count_max: {max(s.robust_survivor_count for s in summaries)}")
    print("no_empirical_abundances_loaded: True")
    print("no_baryon_to_photon_matching_performed: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_cosmogenesis_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("ODE_SCENARIO_SCORECARD:")
    for s in summaries:
        print(f"  {s.scenario_id} | robust={s.robust_survivor_count} | final_survivors={s.final_survivor_count} | fragile={s.fragile_modes} | failed={s.failed_modes} | mean_finalY={s.mean_final_Y:.4g} | mean_peakY={s.mean_peak_Y:.4g} | order={s.lock_order_score:.3f} | grade={s.result_grade}")
    print("BASELINE_MODE_LEDGER:")
    base_rows = [r for r in all_rows if r["scenario_id"] == "baseline_ODE_R003_R004"]
    for r in base_rows:
        print(f"  rho={r['rho']} | finalY={r['final_Y_proxy']:.4g} | peakY={r['peak_Y_proxy']:.4g} | peakS={r['peak_survival_score']:.4g} | freeze_x={r['freeze_x']} | status={r['status']}")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R005 converts instantaneous survival scores into integrated toy ODE freezeout/capture proxies. -- Formation and destruction rates are dimensionless screen rates derived from R003/R004 terms.")
    print("  YES_SCREEN | R005 sweeps cooling-clock, radiation-factor, and disruption controls without retuning mode data. -- Sensitivity is reported as screen evidence only.")
    print("  NO | R005 predicts physical abundances or baryon-to-photon ratio. -- Final Y values are proxies, not observed abundances.")
    print("  NO | R005 predicts BBN yields or CMB spectra. -- No empirical cosmology data are loaded.")
    print("  NO | R005 maps rho modes to Standard Model particles. -- Modes remain internal SFT seed modes.")
    print("  NO | R005 closes GR/Boltzmann cosmogenesis. -- This is a dimensionless toy ODE screen.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: V12_10_R006_recombination_survival_audit_gate_or_V12_10_R007_controls_nulls_gate")
    print("=== END COPY/PASTE V12.10-R005 RESULT ===")


if __name__ == "__main__":
    main()
