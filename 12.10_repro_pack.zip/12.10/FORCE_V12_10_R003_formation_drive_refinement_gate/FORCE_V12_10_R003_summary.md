# V12.10-R003: Formation Drive Refinement Gate

## Summary

- Radiation factor still informative: `True`
- Formation model changes outcomes: `True`
- Partial survival windows present: `True`
- Lock-in order stable: `True`

## Config scorecard

| config | model | locked | failed | order | mean maxS | mean capture | grade |
| --- | --- | ---: | --- | ---: | ---: | ---: | --- |
| R002_baseline_reproduction | symmetric_gaussian | 9 | none | 1.000 | 6.132 | 0.645 | FULL_SURVIVAL_ORDERED |
| asymmetric_hot_smash_primary | asymmetric_hot_smash | 9 | none | 1.000 | 5.666 | 0.570 | FULL_SURVIVAL_ORDERED |
| threshold_plateau_cooling_primary | threshold_plateau_then_cooling | 9 | none | 1.000 | 5.746 | 0.614 | FULL_SURVIVAL_ORDERED |
| narrow_resonance_control | narrow_resonance | 9 | none | 1.000 | 5.108 | 0.479 | FULL_SURVIVAL_ORDERED |
| broad_turbulent_capture_control | broad_turbulent_capture | 9 | none | 1.000 | 6.865 | 0.728 | FULL_SURVIVAL_ORDERED |
| low_bridge_drive_control | asymmetric_hot_smash | 9 | none | 1.000 | 3.777 | 0.497 | FULL_SURVIVAL_ORDERED |
| low_adequacy_drive_control | asymmetric_hot_smash | 9 | none | 1.000 | 2.094 | 0.393 | FULL_SURVIVAL_ORDERED |
| no_radiation_factor_control | asymmetric_hot_smash | 6 | 2/3, 3/4, 1 | 0.917 | 2.853 | 0.313 | PARTIAL_SURVIVAL_INFORMATIVE |
| high_disruption_partial_window_search | asymmetric_hot_smash | 9 | none | 1.000 | 3.668 | 0.429 | FULL_SURVIVAL_ORDERED |

## Claim boundary

- R003 refines the formation/capture drive only.
- It does not predict abundances, BBN yields, CMB spectra, or particle identities.
- It does not close GR/Boltzmann cosmogenesis.