# V12.10-R001: Radiation-Era Formation / Survival Toy Gate

Parent freeze: `SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE`

## Purpose

This gate runs the first broad V12.10 toy model for radiation-era mode formation and survival filtering.
It uses the V12.8 nine-mode seed and V12.9 mass-amplitude / adequacy / shape-label screens as internal inputs.

## Claim boundary

- This is a dimensionless formation/survival toy.
- It does not model physical abundances, BBN, CMB spectra, or recombination microphysics.
- Recombination is treated as a cold visibility/decoupling audit marker, not as particle birth.
- No empirical abundances or Standard Model particle mappings are loaded.

## Baseline scenario summary

- `scenario`: `baseline`
- `locked_count`: `9`
- `survive_to_recombination_audit_count`: `9`
- `mean_max_survival_score`: `6.132405601814635`
- `max_capture_fraction_proxy`: `0.9682826190209279`
- `mean_capture_fraction_proxy`: `0.6448539655281711`

## Baseline mode survival ledger

| rho | m | N | class | ecology | log10M | adequacy | max_score | first_lock_x | capture_proxy | recombination_audit |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | --- | ---: | --- |
| 1/2 | 1 | 2 | binary_no_overwrite_class | clean_internal | 0.000 | 1.381 | 2.245 | 1.31 | 0.523 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |
| 2/3 | 2 | 3 | tri_slot_normal_bundle_class | clean_internal | 0.744 | 1.224 | 1.748 | 1.88 | 0.358 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |
| 3/4 | 3 | 4 | full_3plus1_slot_capacity_class | clean_internal | 1.066 | 1.201 | 1.536 | 2.09 | 0.259 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |
| 1 | 1 | 1 | integer_base_cadence | clean_internal | 1.774 | 1.000 | 2.087 | 3.09 | 0.488 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |
| 5/4 | 5 | 4 | full_3plus1_slot_capacity_class | virtual_support_dependent | 2.756 | 1.868 | 2.882 | 4.19 | 0.647 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |
| 4/3 | 4 | 3 | tri_slot_normal_bundle_class | clean_internal | 3.039 | 2.230 | 3.786 | 4.66 | 0.752 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |
| 3/2 | 3 | 2 | binary_no_overwrite_class | clean_internal | 3.645 | 3.626 | 6.935 | 5.61 | 0.882 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |
| 5/3 | 5 | 3 | tri_slot_normal_bundle_class | virtual_support_dependent | 4.417 | 8.407 | 10.279 | 6.59 | 0.926 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |
| 2 | 2 | 1 | integer_base_cadence | boundary_assisted | 5.531 | 24.276 | 23.693 | 7 | 0.968 | SURVIVES_TO_RECOMBINATION_AUDIT_SCREEN |

## Scenario controls

| scenario | locked_count | survive_to_recombination_audit_count | mean_max_score | mean_capture_proxy |
| --- | ---: | ---: | ---: | ---: |
| baseline | 9 | 9 | 6.132 | 0.645 |
| no_radiation_double_burden | 7 | 7 | 3.066 | 0.352 |
| no_bridge_mass_amplitude | 9 | 9 | 5.561 | 0.629 |
| no_closure_adequacy | 9 | 9 | 1.710 | 0.333 |
| no_shape_force_susceptibility | 9 | 9 | 4.888 | 0.574 |