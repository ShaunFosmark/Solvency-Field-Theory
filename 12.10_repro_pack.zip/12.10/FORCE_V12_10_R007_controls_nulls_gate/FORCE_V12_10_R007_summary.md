# V12.10-R007: Controls / Nulls Gate

## Summary

- Any null resistance: `False`
- Strong null resistance: `False`
- Mass bridge control informative: `False`
- Adequacy control informative: `False`
- Monotonic range null risk remains: `True`

## Canonical pattern

- Robust modes: `1/2, 4/3, 3/2, 5/3, 2`
- Scenario-dependent modes: `2/3, 3/4, 5/4`
- Fragile modes: `1`
- Pattern score: `0.8202`

## Null family rollup

| null family | p(pattern>=canonical) | p(order>=canonical) | p(adequacy>=canonical) | null mean pattern |
| --- | ---: | ---: | ---: | ---: |
| shuffle_mass_bridge | 0.9752 | 0.3884 | 0.7355 | 0.9098 |
| shuffle_adequacy | 0.9669 | 0.4545 | 0.6529 | 0.9036 |
| shuffle_force_shape | 0.3884 | 1.0000 | 0.1818 | 0.8070 |
| shuffle_radiation_coupling | 0.4876 | 1.0000 | 0.3802 | 0.8226 |
| random_monotonic_mass_same_range | 0.5207 | 0.7769 | 0.2149 | 0.8071 |

## Claim boundary

- R007 runs controls/nulls only.
- It does not predict physical abundances, BBN yields, CMB spectra, or particle identities.
- It does not close GR/Boltzmann cosmogenesis.