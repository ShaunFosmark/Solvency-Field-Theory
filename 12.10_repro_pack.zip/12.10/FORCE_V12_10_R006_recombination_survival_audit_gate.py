#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R006_recombination_survival_audit_gate.py

V12.10-R006:
Recombination / Cold Visibility Survival Audit Gate.

R001: broad radiation-era survival toy.
R002: background/timeline calibration.
R003: formation-drive refinement.
R004: radiation/expansion disruption localization.
R005: integrated survival ODE / freezeout sweep.
R006: aggregate R005-style ODE scenarios into a cold/recombination-audit ledger.

Purpose:
  - Treat recombination as a cold visibility / photon-decoupling audit marker,
    NOT as fundamental particle birth.
  - Classify each V12.8/V12.9 seed mode as robust, fragile, or transient in the
    integrated toy ODE across scenarios.
  - Identify repeatedly fragile modes and scenario-dependent modes.
  - Preserve strict boundaries:
      * no empirical abundance loading
      * no BBN/CMB prediction
      * no baryon-to-photon matching
      * no rho-to-particle mapping
      * no GR/Boltzmann closure
"""

from __future__ import annotations

import csv
import json
import math
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, UTC
from fractions import Fraction
from pathlib import Path
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R006"
PARENT_GATE = "FORCE_V12_10_R005"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R006: Recombination / Cold Visibility Survival Audit Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

RAW_FEEDBACK = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

G_FORCE_SHAPE_TOPOLOGY = {
    "1/2": 5.7426406871,
    "2/3": 2.03823702542,
    "3/4": 1.0,
    "1":   8.12132034355,
    "5/4": 1.20454951288,
    "4/3": 1.256762611,
    "3/2": 2.55433304545,
    "5/3": 1.39089397103,
    "2":   10.1516504294,
}

BETA_6PI = 0.299699441600
RENT_POWER = 5.0
X_HOT = 7.0
X_COLD = -4.0
N_STEPS = 2201
COLD_VISIBILITY_AUDIT_X = -4.0


@dataclass
class Mode:
    rho_str: str
    rho: float
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    radiation_coupling_proxy: float
    tightness_proxy: float


@dataclass
class ODEScenario:
    scenario_id: str
    family: str
    radiation_factor: float
    overheat_coeff: float
    hubble_coeff: float
    photon_coeff: float
    denominator_weight: float
    ecology_weight: float
    tightness_weight: float
    hot_smash_extra: float
    formation_rate_scale: float
    destruction_rate_scale: float
    cooling_clock_scale: float
    freeze_threshold: float
    notes: str


@dataclass
class ModeAudit:
    rho: str
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    log10_mass_bridge: float
    adequacy_p5: float
    baseline_final_Y: float
    baseline_peak_Y: float
    baseline_freeze_x: str
    robust_count: int
    fragile_count: int
    failed_count: int
    mean_final_Y: float
    min_final_Y: float
    max_final_Y: float
    robust_fraction: float
    recombination_audit_status: str
    interpretation: str


def frac_value(s: str) -> Fraction:
    return Fraction(s)


def denominator_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, f"denominator_{N}_outside_v12_8_slot_cap")


def support_ecology(rho_str: str) -> str:
    if rho_str in {"5/4", "5/3"}:
        return "virtual_support_dependent"
    if rho_str == "2":
        return "boundary_assisted"
    return "clean_internal"


def build_modes() -> List[Mode]:
    min_raw = min(RAW_FEEDBACK.values())
    raw_at_identity = RAW_FEEDBACK["1"]
    min_g = min(G_FORCE_SHAPE_TOPOLOGY.values())

    bridges = {}
    for s in SELECTED_SEED_STR:
        raw_norm = RAW_FEEDBACK[s] / min_raw
        bridges[s] = raw_norm ** (1.0 + BETA_6PI)
    max_bridge = max(bridges.values())

    modes = []
    for s in SELECTED_SEED_STR:
        f = frac_value(s)
        rho = float(f)
        m, N = f.numerator, f.denominator
        ecology = support_ecology(s)
        base_rad = 1.0 + 0.12 * (N - 1)
        if ecology == "virtual_support_dependent":
            base_rad += 0.18
        if ecology == "boundary_assisted":
            base_rad += 0.25

        bridge = bridges[s]
        modes.append(Mode(
            rho_str=s,
            rho=rho,
            m=m,
            N=N,
            denominator_class=denominator_class(N),
            support_ecology=ecology,
            raw_feedback=RAW_FEEDBACK[s],
            mass_bridge=bridge,
            log10_mass_bridge=math.log10(max(bridge, 1e-300)),
            adequacy_p5=RAW_FEEDBACK[s] / (raw_at_identity * (rho ** RENT_POWER)),
            force_shape_susceptibility=math.sqrt(G_FORCE_SHAPE_TOPOLOGY[s] / min_g),
            radiation_coupling_proxy=base_rad,
            tightness_proxy=math.sqrt(bridge / max_bridge),
        ))
    return modes


def timeline_grid() -> List[float]:
    return [X_HOT + (X_COLD - X_HOT) * i / (N_STEPS - 1) for i in range(N_STEPS)]


def formation_window_asymmetric(dx: float) -> float:
    sigma_hot = 0.85
    sigma_cold = 1.35
    sigma = sigma_hot if dx >= 0 else sigma_cold
    base = math.exp(-0.5 * (dx / sigma) ** 2)
    hot_penalty = math.exp(-0.18 * max(dx, 0.0) ** 2)
    return base * hot_penalty


def mode_radiation_weight(mode: Mode, sc: ODEScenario) -> float:
    denom_part = 1.0 + sc.denominator_weight * (mode.N - 1) / 3.0
    ecology_part = 1.0
    if mode.support_ecology == "virtual_support_dependent":
        ecology_part += sc.ecology_weight * 0.6
    if mode.support_ecology == "boundary_assisted":
        ecology_part += sc.ecology_weight * 0.8
    return mode.radiation_coupling_proxy * denom_part * ecology_part


def instantaneous_terms(mode: Mode, x: float, sc: ODEScenario) -> Dict[str, float]:
    dx = x - mode.log10_mass_bridge

    thermal_availability = 1.0 / (1.0 + math.exp(-4.0 * dx))
    window = formation_window_asymmetric(dx)
    twirl_background = sc.radiation_factor * (1.0 + 0.12 * max(x, 0.0))

    formation_drive = (
        twirl_background
        * window
        * thermal_availability
        * (mode.mass_bridge ** 0.045)
        * (mode.adequacy_p5 ** 0.62)
        * (mode.force_shape_susceptibility ** 0.35)
    )

    rad_weight = mode_radiation_weight(mode, sc)
    overheat = max(dx, 0.0)

    overheat_disruption = sc.overheat_coeff * (overheat ** 2) * rad_weight / max(mode.adequacy_p5, 0.1) ** 0.25
    overheat_disruption *= (1.0 + sc.hot_smash_extra * max(dx - 0.75, 0.0))

    hubble_disruption = (
        sc.hubble_coeff
        * (10.0 ** (0.105 * max(x, 0.0)))
        * (0.85 + (0.75 + sc.tightness_weight) * mode.tightness_proxy)
    )

    photon_disruption = sc.photon_coeff * (10.0 ** (0.075 * max(x, 0.0))) * rad_weight
    closure_rent = 1.0 / max(mode.adequacy_p5, 1e-9)

    disruption_total = closure_rent + overheat_disruption + hubble_disruption + photon_disruption
    survival_score = formation_drive / max(disruption_total, 1e-12)

    gamma_form = sc.formation_rate_scale * formation_drive / (1.0 + disruption_total)
    gamma_destroy = sc.destruction_rate_scale * disruption_total / (1.0 + formation_drive)
    gamma_destroy *= 0.35 + 0.65 / (1.0 + mode.adequacy_p5)

    cooling_suppression = 1.0 / (1.0 + math.exp(-2.0 * (x - (-2.0))))
    gamma_form *= cooling_suppression
    gamma_destroy *= cooling_suppression

    return {
        "formation_drive": formation_drive,
        "disruption_total": disruption_total,
        "survival_score": survival_score,
        "gamma_form": gamma_form,
        "gamma_destroy": gamma_destroy,
    }


def integrate_mode(mode: Mode, sc: ODEScenario) -> Dict[str, float | str | bool]:
    xs = timeline_grid()
    dx_abs = abs((X_COLD - X_HOT) / (N_STEPS - 1))
    Y = 0.0
    peakY = 0.0
    peakS = 0.0
    freeze_x = None
    first_score_lock_x = None

    for x in xs:
        terms = instantaneous_terms(mode, x, sc)
        S = terms["survival_score"]
        peakS = max(peakS, S)
        if S >= 1.0 and first_score_lock_x is None:
            first_score_lock_x = x

        dtau = dx_abs * sc.cooling_clock_scale
        dY = (terms["gamma_form"] * (1.0 - Y) - terms["gamma_destroy"] * Y) * dtau
        Y = max(0.0, min(1.0, Y + dY))
        peakY = max(peakY, Y)

        if freeze_x is None and Y >= sc.freeze_threshold and S >= 1.0:
            freeze_x = x

    finalY = Y
    robust = finalY >= sc.freeze_threshold and mode.adequacy_p5 >= 1.0
    fragile = (0.05 <= finalY < sc.freeze_threshold) or (peakS >= 1.0 and finalY < sc.freeze_threshold)

    return {
        "scenario_id": sc.scenario_id,
        "scenario_family": sc.family,
        "rho": mode.rho_str,
        "m": mode.m,
        "N": mode.N,
        "denominator_class": mode.denominator_class,
        "support_ecology": mode.support_ecology,
        "log10_mass_bridge": mode.log10_mass_bridge,
        "adequacy_p5": mode.adequacy_p5,
        "peak_survival_score": peakS,
        "final_Y_proxy": finalY,
        "peak_Y_proxy": peakY,
        "freeze_x": "none" if freeze_x is None else f"{freeze_x:.4g}",
        "freeze_x_value": -999.0 if freeze_x is None else freeze_x,
        "first_score_lock_x": "none" if first_score_lock_x is None else f"{first_score_lock_x:.4g}",
        "cold_visibility_audit_x": COLD_VISIBILITY_AUDIT_X,
        "robust_survivor": robust,
        "fragile_candidate": fragile,
        "cold_audit_status": "ROBUST_RELIC_SCREEN" if robust else ("FRAGILE_RELIC_SCREEN" if fragile else "TRANSIENT_OR_FAILED_SCREEN"),
    }


def build_scenarios() -> List[ODEScenario]:
    base = dict(
        radiation_factor=2.0,
        overheat_coeff=0.55,
        hubble_coeff=0.22,
        photon_coeff=0.18,
        denominator_weight=0.0,
        ecology_weight=0.0,
        tightness_weight=0.0,
        hot_smash_extra=0.0,
        formation_rate_scale=0.95,
        destruction_rate_scale=0.26,
        cooling_clock_scale=1.0,
        freeze_threshold=0.22,
    )
    return [
        ODEScenario("baseline_ODE_R003_R004", "baseline", **base, notes="Baseline cold-audit reference."),
        ODEScenario("fast_cooling_less_reaction_time", "cooling_clock", **{**base, "cooling_clock_scale":0.55}, notes="Fast cooling."),
        ODEScenario("slow_cooling_more_reaction_time", "cooling_clock", **{**base, "cooling_clock_scale":1.8}, notes="Slow cooling."),
        ODEScenario("strong_photon_disruption_ODE", "radiation_disruption", **{**base, "photon_coeff":0.52, "destruction_rate_scale":0.34}, notes="Photon disruption."),
        ODEScenario("denominator_ecology_disruption_ODE", "radiation_disruption", **{**base, "photon_coeff":0.40, "denominator_weight":0.85, "ecology_weight":0.85, "destruction_rate_scale":0.34}, notes="Denominator/ecology disruption."),
        ODEScenario("no_radiation_double_burden_ODE", "radiation_drive_control", **{**base, "radiation_factor":1.0}, notes="Radiation active-gravity source removed."),
        ODEScenario("weak_formation_drive_ODE", "formation_drive", **{**base, "formation_rate_scale":0.55}, notes="Reduced formation rate."),
        ODEScenario("strong_destruction_drive_ODE", "radiation_disruption", **{**base, "destruction_rate_scale":0.52, "photon_coeff":0.38, "hubble_coeff":0.36}, notes="Strong destruction."),
        ODEScenario("permissive_lock_control", "control", **{**base, "formation_rate_scale":1.3, "destruction_rate_scale":0.18, "freeze_threshold":0.18}, notes="Permissive control."),
        ODEScenario("strict_lock_control", "control", **{**base, "formation_rate_scale":0.75, "destruction_rate_scale":0.36, "freeze_threshold":0.32}, notes="Strict control."),
    ]


def audit_modes(modes: List[Mode], rows: List[dict], scenarios: List[ODEScenario]) -> List[ModeAudit]:
    by_rho = {m.rho_str: [] for m in modes}
    for r in rows:
        by_rho[r["rho"]].append(r)

    audits: List[ModeAudit] = []
    n_scen = len(scenarios)

    baseline_rows = {r["rho"]: r for r in rows if r["scenario_id"] == "baseline_ODE_R003_R004"}

    for mode in modes:
        rs = by_rho[mode.rho_str]
        robust_count = sum(1 for r in rs if r["robust_survivor"])
        fragile_count = sum(1 for r in rs if r["fragile_candidate"] and not r["robust_survivor"])
        failed_count = n_scen - robust_count - fragile_count
        finalYs = [float(r["final_Y_proxy"]) for r in rs]
        robust_fraction = robust_count / n_scen
        b = baseline_rows[mode.rho_str]

        if robust_fraction >= 0.8:
            status = "ROBUST_COLD_RELIC_SCREEN"
            interp = "Mode remains robust across most cold-audit scenarios."
        elif robust_fraction >= 0.5:
            status = "SCENARIO_DEPENDENT_RELIC_SCREEN"
            interp = "Mode survives baseline but is sensitive to cooling/disruption assumptions."
        elif fragile_count >= 5:
            status = "FRAGILE_TRANSIENT_RELIC_SCREEN"
            interp = "Mode often remains present only as fragile/transient proxy."
        else:
            status = "MOSTLY_FAILED_COLD_AUDIT_SCREEN"
            interp = "Mode does not robustly survive the cold audit under the toy ensemble."

        audits.append(ModeAudit(
            rho=mode.rho_str,
            m=mode.m,
            N=mode.N,
            denominator_class=mode.denominator_class,
            support_ecology=mode.support_ecology,
            log10_mass_bridge=mode.log10_mass_bridge,
            adequacy_p5=mode.adequacy_p5,
            baseline_final_Y=float(b["final_Y_proxy"]),
            baseline_peak_Y=float(b["peak_Y_proxy"]),
            baseline_freeze_x=str(b["freeze_x"]),
            robust_count=robust_count,
            fragile_count=fragile_count,
            failed_count=failed_count,
            mean_final_Y=sum(finalYs) / len(finalYs),
            min_final_Y=min(finalYs),
            max_final_Y=max(finalYs),
            robust_fraction=robust_fraction,
            recombination_audit_status=status,
            interpretation=interp,
        ))
    return audits


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_recombination_survival_audit_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    modes = build_modes()
    scenarios = build_scenarios()

    all_rows: List[dict] = []
    for sc in scenarios:
        for m in modes:
            all_rows.append(integrate_mode(m, sc))

    audits = audit_modes(modes, all_rows, scenarios)

    audit_rows = [asdict(a) for a in audits]
    scenario_summary_rows = []
    for sc in scenarios:
        rows = [r for r in all_rows if r["scenario_id"] == sc.scenario_id]
        scenario_summary_rows.append({
            "scenario_id": sc.scenario_id,
            "family": sc.family,
            "robust_count": sum(1 for r in rows if r["robust_survivor"]),
            "fragile_count": sum(1 for r in rows if r["fragile_candidate"] and not r["robust_survivor"]),
            "failed_count": sum(1 for r in rows if not r["robust_survivor"] and not r["fragile_candidate"]),
            "mean_final_Y": sum(float(r["final_Y_proxy"]) for r in rows) / len(rows),
            "notes": sc.notes,
        })

    robust_modes = [a.rho for a in audits if a.recombination_audit_status == "ROBUST_COLD_RELIC_SCREEN"]
    scenario_dependent_modes = [a.rho for a in audits if a.recombination_audit_status == "SCENARIO_DEPENDENT_RELIC_SCREEN"]
    fragile_modes = [a.rho for a in audits if a.recombination_audit_status == "FRAGILE_TRANSIENT_RELIC_SCREEN"]
    mostly_failed_modes = [a.rho for a in audits if a.recombination_audit_status == "MOSTLY_FAILED_COLD_AUDIT_SCREEN"]

    baseline_robust_all = all(
        r["robust_survivor"] for r in all_rows if r["scenario_id"] == "baseline_ODE_R003_R004"
    )
    cold_audit_status_generated = True
    scenario_sensitivity_present = len(scenario_dependent_modes) > 0 or len(fragile_modes) > 0 or len(mostly_failed_modes) > 0
    repeatedly_fragile_modes_present = len(fragile_modes) > 0
    no_physical_recombination_claim = True

    write_csv(out_dir / "V12_10_R006_cold_audit_mode_ledger.csv", audit_rows)
    write_csv(out_dir / "V12_10_R006_mode_by_scenario_cold_ledger.csv", all_rows)
    write_csv(out_dir / "V12_10_R006_scenario_summary.csv", scenario_summary_rows)

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "cold_visibility_audit_x": COLD_VISIBILITY_AUDIT_X,
        "baseline_robust_all": baseline_robust_all,
        "scenario_sensitivity_present": scenario_sensitivity_present,
        "robust_modes": robust_modes,
        "scenario_dependent_modes": scenario_dependent_modes,
        "fragile_modes": fragile_modes,
        "mostly_failed_modes": mostly_failed_modes,
        "claim_boundary": [
            "cold visibility/recombination audit marker only",
            "not particle birth",
            "no empirical abundance loading",
            "no BBN/CMB prediction",
            "no rho-to-particle mapping",
            "no final cosmogenesis law",
        ],
    }
    payload_path = out_dir / "V12_10_R006_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- Baseline robust all modes: `{baseline_robust_all}`")
    lines.append(f"- Scenario sensitivity present: `{scenario_sensitivity_present}`")
    lines.append(f"- Robust cold relic screen modes: `{', '.join(robust_modes) if robust_modes else 'none'}`")
    lines.append(f"- Scenario-dependent modes: `{', '.join(scenario_dependent_modes) if scenario_dependent_modes else 'none'}`")
    lines.append(f"- Fragile/transient modes: `{', '.join(fragile_modes) if fragile_modes else 'none'}`")
    lines.append("")
    lines.append("## Mode audit ledger")
    lines.append("")
    lines.append("| rho | N | ecology | baseline Y | robust/fragile/failed | mean Y | status |")
    lines.append("| --- | ---: | --- | ---: | --- | ---: | --- |")
    for a in audits:
        lines.append(f"| {a.rho} | {a.N} | {a.support_ecology} | {a.baseline_final_Y:.3f} | {a.robust_count}/{a.fragile_count}/{a.failed_count} | {a.mean_final_Y:.3f} | {a.recombination_audit_status} |")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("- Recombination is treated only as a cold visibility / photon-decoupling audit marker.")
    lines.append("- R006 does not claim fundamental particles first form at recombination.")
    lines.append("- R006 does not predict physical abundances, BBN yields, CMB spectra, or particle identities.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_recombination_survival_audit_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R006_cold_audit_mode_ledger.csv",
        out_dir / "V12_10_R006_mode_by_scenario_cold_ledger.csv",
        out_dir / "V12_10_R006_scenario_summary.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R006 RESULT ===")
    print("V12.10-R006 COMPLETE")
    print("VERDICT: RECOMBINATION / COLD VISIBILITY AUDIT PASS / RELIC ROBUSTNESS CLASSIFIED, PHYSICAL CMB/ABUNDANCES OPEN")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("cold_audit_mode_ledger_generated: True")
    print("mode_by_scenario_cold_ledger_generated: True")
    print("scenario_summary_generated: True")
    print(f"baseline_robust_all: {baseline_robust_all}")
    print(f"scenario_sensitivity_present: {scenario_sensitivity_present}")
    print(f"repeatedly_fragile_modes_present: {repeatedly_fragile_modes_present}")
    print(f"cold_visibility_audit_x: {COLD_VISIBILITY_AUDIT_X}")
    print("no_empirical_abundances_loaded: True")
    print("no_baryon_to_photon_matching_performed: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_recombination_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("COLD_AUDIT_MODE_LEDGER:")
    for a in audits:
        print(f"  rho={a.rho} | N={a.N} | ecology={a.support_ecology} | baselineY={a.baseline_final_Y:.4g} | robust/fragile/failed={a.robust_count}/{a.fragile_count}/{a.failed_count} | meanY={a.mean_final_Y:.4g} | status={a.recombination_audit_status}")
    print("AUDIT_ROLLUP:")
    print(f"  robust_cold_relic_screen_modes: {', '.join(robust_modes) if robust_modes else 'none'}")
    print(f"  scenario_dependent_relic_screen_modes: {', '.join(scenario_dependent_modes) if scenario_dependent_modes else 'none'}")
    print(f"  fragile_transient_relic_screen_modes: {', '.join(fragile_modes) if fragile_modes else 'none'}")
    print(f"  mostly_failed_cold_audit_screen_modes: {', '.join(mostly_failed_modes) if mostly_failed_modes else 'none'}")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R006 audits integrated toy ODE relic survival at a cold visibility/recombination marker. -- The audit classifies robust, scenario-dependent, and fragile relic proxies.")
    print("  YES | R006 treats recombination as a visibility/photon-decoupling audit, not particle birth. -- Fundamental mode formation remains an earlier radiation-era process in the toy story.")
    print("  NO | R006 predicts CMB spectrum, physical recombination microphysics, or baryon-to-photon ratio. -- No empirical cosmology data are loaded.")
    print("  NO | R006 maps rho modes to Standard Model particles. -- Modes remain internal SFT seed modes.")
    print("  NO | R006 closes GR/Boltzmann cosmogenesis. -- This remains a dimensionless toy audit.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: V12_10_R007_controls_nulls_gate_or_V12_10_R008_abundance_proxy_gate")
    print("=== END COPY/PASTE V12.10-R006 RESULT ===")


if __name__ == "__main__":
    main()
