# V12.10-R010: Abundance Proxy / Capture Fraction Toy Gate

## Result

R010 constructs multiple toy relative capture / relic-fraction proxies from the R005/R006 ODE ensemble.

No budget convention is selected as physical.

## Budget scheme summary

| scheme | top mode | top fraction | effective modes | robust-class fraction | dominance |
| --- | --- | ---: | ---: | ---: | --- |
| equal_relic_occupancy_proxy | 5/3 | 0.1485 | 8.702 | 0.6728 | DISTRIBUTED |
| inverse_mass_number_proxy | 1/2 | 0.8434 | 1.759 | 0.8443 | HIGH_DOMINANCE |
| log_tempered_number_proxy | 1/2 | 0.3484 | 7.206 | 0.6328 | DISTRIBUTED |
| energy_capture_proxy | 2 | 0.9084 | 1.433 | 0.9989 | HIGH_DOMINANCE |
| robustness_weighted_proxy | 1/2 | 0.169 | 8.052 | 0.7639 | DISTRIBUTED |
| fragility_suppressed_proxy | 3/2 | 0.1618 | 8.293 | 0.7365 | DISTRIBUTED |

## Claim boundary

- R010 does not predict physical abundances, baryon-to-photon ratio, BBN yields, or CMB spectra.
- R010 does not map rho modes to particles.
- R010 reports budget-convention sensitivity only.