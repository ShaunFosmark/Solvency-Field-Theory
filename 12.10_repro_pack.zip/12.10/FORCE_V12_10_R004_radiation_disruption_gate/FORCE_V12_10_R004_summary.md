# V12.10-R004: Radiation / Expansion Disruption Gate

## Summary

- Disruption survival varies: `True`
- Partial survival present: `True`
- Radiation factor informative: `True`
- Denominator/ecology disruption informative: `True`

## Disruption scorecard

| config | locked | failed | low/mid/high | order | mean maxS | mean capture | grade |
| --- | ---: | --- | --- | ---: | ---: | ---: | --- |
| R003_asymmetric_baseline | 9 | none | 4/3/2 | 1.000 | 5.666 | 0.570 | FULL_SURVIVAL_DISRUPTION_WEAK |
| remove_overheat_disruption | 9 | none | 4/3/2 | 1.000 | 5.865 | 0.613 | FULL_SURVIVAL_DISRUPTION_WEAK |
| remove_hubble_tearing | 9 | none | 4/3/2 | 1.000 | 12.811 | 0.667 | FULL_SURVIVAL_DISRUPTION_WEAK |
| remove_photon_bath_disruption | 9 | none | 4/3/2 | 1.000 | 8.147 | 0.666 | FULL_SURVIVAL_DISRUPTION_WEAK |
| high_overheat_disruption | 9 | none | 4/3/2 | 1.000 | 5.497 | 0.537 | FULL_SURVIVAL_DISRUPTION_WEAK |
| high_hubble_tearing | 9 | none | 4/3/2 | 1.000 | 2.980 | 0.426 | FULL_SURVIVAL_DISRUPTION_WEAK |
| high_photon_bath_disruption | 8 | 3/4 | 3/3/2 | 0.944 | 3.533 | 0.403 | PARTIAL_SURVIVAL_DISRUPTION_INFORMATIVE |
| denominator_weighted_photon_disruption | 8 | 3/4 | 3/3/2 | 0.944 | 3.591 | 0.371 | PARTIAL_SURVIVAL_DISRUPTION_INFORMATIVE |
| ecology_weighted_disruption | 8 | 3/4 | 3/3/2 | 0.944 | 3.289 | 0.391 | PARTIAL_SURVIVAL_DISRUPTION_INFORMATIVE |
| aggressive_full_disruption_control | 6 | 2/3, 3/4, 5/4 | 2/2/2 | 0.889 | 2.007 | 0.249 | PARTIAL_SURVIVAL_DISRUPTION_INFORMATIVE |
| no_radiation_double_burden_reference | 6 | 2/3, 3/4, 1 | 1/3/2 | 0.917 | 2.833 | 0.309 | PARTIAL_SURVIVAL_DISRUPTION_INFORMATIVE |

## Claim boundary

- R004 isolates toy disruption channels only.
- It does not predict physical abundances, BBN yields, CMB spectra, or particle identities.
- It does not close GR/Boltzmann cosmogenesis.