#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R011_class_preserving_null_archetype_control_gate.py

V12.10-R011:
Class-Preserving Null / Archetype Control Gate.

R010 built toy abundance / capture-fraction proxies from the V12.10 ODE ensemble.
R011 asks:
  Are the R010 budget-proxy profiles specific to the canonical rho/mass/ecology
  assignment, or are they mostly consequences of:
    - the generic racetrack,
    - the preserved robust/scenario-dependent/fragile class counts,
    - the budget convention itself?

Null families:
  1. class_tuple_shuffle:
       preserve the full set of cold-audit tuples
       (class, meanY, robust_fraction, fragile_fraction),
       but shuffle them across rho/mass positions.
  2. class_label_shuffle:
       preserve class counts only; assign class templates to random modes.
  3. within_class_Y_shuffle:
       keep each mode's class fixed but shuffle meanY/robust values inside each class.
  4. class_jitter:
       keep each mode's class fixed but jitter meanY/robust within class bounds.

Claim boundary:
  - null/control screen only
  - no empirical abundance loading
  - no baryon-to-photon matching
  - no BBN/CMB prediction
  - no rho-to-particle mapping
  - no physical budget convention selected
  - no final cosmogenesis law
"""

from __future__ import annotations

import csv
import json
import math
import random
import zipfile
from dataclasses import dataclass, asdict, replace
from datetime import datetime, UTC
from pathlib import Path
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R011"
PARENT_GATE = "FORCE_V12_10_R010"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R011: Class-Preserving Null / Archetype Control Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

N_NULL = 600
RNG_SEED = 1210011


@dataclass
class ModeAggregate:
    rho: str
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    baseline_finalY: float
    mean_finalY: float
    min_finalY: float
    max_finalY: float
    mean_peakY: float
    robust_fraction: float
    fragile_fraction: float
    mean_freeze_x: float
    cold_audit_class: str


@dataclass
class BudgetScheme:
    scheme_id: str
    description: str
    weight_formula: str


@dataclass
class SchemeMetrics:
    label: str
    null_family: str
    scheme_id: str
    top_mode: str
    top_class: str
    top_fraction: float
    effective_mode_count: float
    robust_class_fraction: float
    scenario_dependent_class_fraction: float
    fragile_class_fraction: float
    low_mass_half_fraction: float
    high_mass_half_fraction: float
    entropy: float
    dominance_warning: str


@dataclass
class NullRollup:
    scheme_id: str
    null_family: str
    n_null: int
    canonical_top_mode: str
    canonical_top_fraction: float
    canonical_effective_modes: float
    canonical_robust_class_fraction: float
    canonical_low_mass_half_fraction: float
    canonical_high_mass_half_fraction: float
    p_top_fraction_ge: float
    p_effective_modes_le: float
    p_robust_class_fraction_ge: float
    p_low_mass_half_ge: float
    p_high_mass_half_ge: float
    top_mode_match_rate: float
    interpretation: str


def canonical_aggregates() -> List[ModeAggregate]:
    # R010 mode aggregate ledger.
    rows = [
        ("1/2", 1, 2, "binary_no_overwrite_class", "clean_internal", 0.000, 1.381, 0.5298, 0.4327, 1.0, 0.0, "ROBUST_COLD_RELIC_SCREEN"),
        ("2/3", 2, 3, "tri_slot_normal_bundle_class", "clean_internal", 0.7437, 1.224, 0.3928, 0.2997, 0.7, 0.3, "SCENARIO_DEPENDENT_RELIC_SCREEN"),
        ("3/4", 3, 4, "full_3plus1_slot_capacity_class", "clean_internal", 1.066, 1.201, 0.3359, 0.2469, 0.5, 0.5, "SCENARIO_DEPENDENT_RELIC_SCREEN"),
        ("1",   1, 1, "integer_base_cadence", "clean_internal", 1.774, 1.000, 0.3212, 0.2423, 0.4, 0.6, "FRAGILE_TRANSIENT_RELIC_SCREEN"),
        ("5/4", 5, 4, "full_3plus1_slot_capacity_class", "virtual_support_dependent", 2.756, 1.868, 0.4145, 0.2903, 0.6, 0.4, "SCENARIO_DEPENDENT_RELIC_SCREEN"),
        ("4/3", 4, 3, "tri_slot_normal_bundle_class", "clean_internal", 3.039, 2.230, 0.4847, 0.3634, 0.8, 0.2, "ROBUST_COLD_RELIC_SCREEN"),
        ("3/2", 3, 2, "binary_no_overwrite_class", "clean_internal", 3.645, 3.626, 0.5946, 0.4802, 0.9, 0.1, "ROBUST_COLD_RELIC_SCREEN"),
        ("5/3", 5, 3, "tri_slot_normal_bundle_class", "virtual_support_dependent", 4.417, 8.407, 0.6202, 0.4900, 0.8, 0.2, "ROBUST_COLD_RELIC_SCREEN"),
        ("2",   2, 1, "integer_base_cadence", "boundary_assisted", 5.531, 24.28, 0.5627, 0.4532, 0.9, 0.1, "ROBUST_COLD_RELIC_SCREEN"),
    ]
    out: List[ModeAggregate] = []
    for rho, m, N, dc, eco, logM, A, baseY, meanY, rf, ff, cls in rows:
        M = 10.0 ** logM
        out.append(ModeAggregate(
            rho=rho,
            m=m,
            N=N,
            denominator_class=dc,
            support_ecology=eco,
            mass_bridge=M,
            log10_mass_bridge=logM,
            adequacy_p5=A,
            baseline_finalY=baseY,
            mean_finalY=meanY,
            min_finalY=max(0.0, meanY - 0.18),
            max_finalY=min(1.0, meanY + 0.18),
            mean_peakY=min(1.0, meanY + 0.28),
            robust_fraction=rf,
            fragile_fraction=ff,
            mean_freeze_x=logM + 0.8,
            cold_audit_class=cls,
        ))
    return out


def budget_schemes() -> List[BudgetScheme]:
    return [
        BudgetScheme("equal_relic_occupancy_proxy", "Relative relic occupancy from ensemble mean final Y only.", "weight = mean_finalY"),
        BudgetScheme("inverse_mass_number_proxy", "Number proxy: divide by mass amplitude.", "weight = mean_finalY / mass_bridge"),
        BudgetScheme("log_tempered_number_proxy", "Soft number proxy: divide by 1+log10(mass_bridge).", "weight = mean_finalY / (1 + log10_mass_bridge)"),
        BudgetScheme("energy_capture_proxy", "Energy capture proxy: multiply by mass amplitude.", "weight = mean_finalY * mass_bridge"),
        BudgetScheme("robustness_weighted_proxy", "Relic proxy weighted by robust survival fraction.", "weight = mean_finalY * robust_fraction"),
        BudgetScheme("fragility_suppressed_proxy", "Relic proxy partially suppressing fragile/scenario-dependent modes.", "weight = mean_finalY * (0.25 + 0.75*robust_fraction)"),
    ]


def scheme_weight(a: ModeAggregate, scheme_id: str) -> float:
    eps = 1e-300
    if scheme_id == "equal_relic_occupancy_proxy":
        return max(a.mean_finalY, 0.0)
    if scheme_id == "inverse_mass_number_proxy":
        return max(a.mean_finalY, 0.0) / max(a.mass_bridge, eps)
    if scheme_id == "log_tempered_number_proxy":
        return max(a.mean_finalY, 0.0) / max(1.0 + a.log10_mass_bridge, eps)
    if scheme_id == "energy_capture_proxy":
        return max(a.mean_finalY, 0.0) * max(a.mass_bridge, eps)
    if scheme_id == "robustness_weighted_proxy":
        return max(a.mean_finalY, 0.0) * max(a.robust_fraction, 0.0)
    if scheme_id == "fragility_suppressed_proxy":
        return max(a.mean_finalY, 0.0) * (0.25 + 0.75 * max(a.robust_fraction, 0.0))
    raise ValueError(f"unknown scheme {scheme_id}")


def fractions_for_scheme(aggs: List[ModeAggregate], scheme_id: str) -> Dict[str, float]:
    raw = {a.rho: scheme_weight(a, scheme_id) for a in aggs}
    total = sum(raw.values())
    if total <= 0:
        return {rho: 0.0 for rho in raw}
    return {rho: w / total for rho, w in raw.items()}


def entropy_eff(fracs: Dict[str, float]) -> Tuple[float, float]:
    H = 0.0
    for p in fracs.values():
        if p > 0:
            H -= p * math.log(p)
    return H, math.exp(H)


def metrics(aggs: List[ModeAggregate], scheme_id: str, label: str, null_family: str) -> SchemeMetrics:
    fracs = fractions_for_scheme(aggs, scheme_id)
    by_rho = {a.rho: a for a in aggs}
    top_mode, top_fraction = max(fracs.items(), key=lambda kv: kv[1])
    top_class = by_rho[top_mode].cold_audit_class

    robust = sum(v for rho, v in fracs.items() if by_rho[rho].cold_audit_class == "ROBUST_COLD_RELIC_SCREEN")
    scenario = sum(v for rho, v in fracs.items() if by_rho[rho].cold_audit_class == "SCENARIO_DEPENDENT_RELIC_SCREEN")
    fragile = sum(v for rho, v in fracs.items() if by_rho[rho].cold_audit_class == "FRAGILE_TRANSIENT_RELIC_SCREEN")

    median_log = sorted(a.log10_mass_bridge for a in aggs)[len(aggs)//2]
    low = sum(v for rho, v in fracs.items() if by_rho[rho].log10_mass_bridge <= median_log)
    high = 1.0 - low

    H, eff = entropy_eff(fracs)
    dominance = "HIGH_DOMINANCE" if top_fraction >= 0.75 else ("MODERATE_DOMINANCE" if top_fraction >= 0.40 else "DISTRIBUTED")

    return SchemeMetrics(
        label=label,
        null_family=null_family,
        scheme_id=scheme_id,
        top_mode=top_mode,
        top_class=top_class,
        top_fraction=top_fraction,
        effective_mode_count=eff,
        robust_class_fraction=robust,
        scenario_dependent_class_fraction=scenario,
        fragile_class_fraction=fragile,
        low_mass_half_fraction=low,
        high_mass_half_fraction=high,
        entropy=H,
        dominance_warning=dominance,
    )


def class_templates(aggs: List[ModeAggregate]) -> List[Tuple[str, float, float]]:
    # class, robust_fraction, fragile_fraction, meanY
    return [(a.cold_audit_class, a.mean_finalY, a.robust_fraction, a.fragile_fraction) for a in aggs]


def apply_tuple_to_mode(a: ModeAggregate, tpl: Tuple[str, float, float, float]) -> ModeAggregate:
    cls, meanY, rf, ff = tpl
    return replace(
        a,
        cold_audit_class=cls,
        mean_finalY=meanY,
        robust_fraction=rf,
        fragile_fraction=ff,
    )


def make_null(aggs: List[ModeAggregate], family: str, rng: random.Random) -> List[ModeAggregate]:
    base = [replace(a) for a in aggs]

    if family == "class_tuple_shuffle":
        templates = class_templates(base)
        rng.shuffle(templates)
        return [apply_tuple_to_mode(a, tpl) for a, tpl in zip(base, templates)]

    if family == "class_label_shuffle":
        # Preserve class counts but use class-average template values.
        by_class: Dict[str, List[ModeAggregate]] = {}
        for a in base:
            by_class.setdefault(a.cold_audit_class, []).append(a)

        class_avg = {}
        for cls, xs in by_class.items():
            class_avg[cls] = (
                cls,
                sum(x.mean_finalY for x in xs)/len(xs),
                sum(x.robust_fraction for x in xs)/len(xs),
                sum(x.fragile_fraction for x in xs)/len(xs),
            )

        labels = [a.cold_audit_class for a in base]
        rng.shuffle(labels)
        return [apply_tuple_to_mode(a, class_avg[cls]) for a, cls in zip(base, labels)]

    if family == "within_class_Y_shuffle":
        out = [replace(a) for a in base]
        by_class_indices: Dict[str, List[int]] = {}
        for i, a in enumerate(base):
            by_class_indices.setdefault(a.cold_audit_class, []).append(i)
        for cls, idxs in by_class_indices.items():
            vals = [(base[i].mean_finalY, base[i].robust_fraction, base[i].fragile_fraction) for i in idxs]
            rng.shuffle(vals)
            for i, (meanY, rf, ff) in zip(idxs, vals):
                out[i] = replace(out[i], mean_finalY=meanY, robust_fraction=rf, fragile_fraction=ff)
        return out

    if family == "class_jitter":
        out = []
        for a in base:
            if a.cold_audit_class == "ROBUST_COLD_RELIC_SCREEN":
                meanY = min(0.75, max(0.25, rng.gauss(a.mean_finalY, 0.055)))
                rf = min(1.0, max(0.8, rng.gauss(a.robust_fraction, 0.055)))
                ff = max(0.0, 1.0 - rf)
            elif a.cold_audit_class == "SCENARIO_DEPENDENT_RELIC_SCREEN":
                meanY = min(0.55, max(0.12, rng.gauss(a.mean_finalY, 0.055)))
                rf = min(0.79, max(0.50, rng.gauss(a.robust_fraction, 0.08)))
                ff = max(0.0, 1.0 - rf)
            else:
                meanY = min(0.42, max(0.05, rng.gauss(a.mean_finalY, 0.055)))
                rf = min(0.49, max(0.0, rng.gauss(a.robust_fraction, 0.08)))
                ff = max(0.0, 1.0 - rf)
            out.append(replace(a, mean_finalY=meanY, robust_fraction=rf, fragile_fraction=ff))
        return out

    raise ValueError(f"unknown null family {family}")


def p_ge(vals: List[float], obs: float) -> float:
    return (sum(1 for v in vals if v >= obs) + 1) / (len(vals) + 1)


def p_le(vals: List[float], obs: float) -> float:
    return (sum(1 for v in vals if v <= obs) + 1) / (len(vals) + 1)


def interpret_rollup(scheme_id: str, null_family: str, obs: SchemeMetrics, p_top: float, p_eff: float, top_match: float) -> str:
    if scheme_id in {"inverse_mass_number_proxy", "energy_capture_proxy"}:
        return "Dominance is mostly budget-convention expected; treat as question-type separation, not physical abundance evidence."
    if p_top <= 0.10 or p_eff <= 0.10:
        return "Some profile structure is less common under this class-preserving null, but remains toy-screen evidence only."
    if top_match > 0.50:
        return "Top mode is common under nulls; exact proxy profile is not specific."
    return "Null risk remains; profile should not be treated as a prediction."


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_class_preserving_null_archetype_control_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    rng = random.Random(RNG_SEED)
    aggs = canonical_aggregates()
    schemes = budget_schemes()
    null_families = ["class_tuple_shuffle", "class_label_shuffle", "within_class_Y_shuffle", "class_jitter"]

    canonical_metrics = [metrics(aggs, s.scheme_id, "canonical", "canonical") for s in schemes]
    canonical_by_scheme = {m.scheme_id: m for m in canonical_metrics}

    null_metric_rows: List[dict] = []
    rollup_rows: List[NullRollup] = []

    for scheme in schemes:
        obs = canonical_by_scheme[scheme.scheme_id]
        for fam in null_families:
            nulls: List[SchemeMetrics] = []
            for i in range(N_NULL):
                n_aggs = make_null(aggs, fam, rng)
                mt = metrics(n_aggs, scheme.scheme_id, f"{fam}_{i:04d}", fam)
                nulls.append(mt)
                null_metric_rows.append(asdict(mt))

            top_fracs = [n.top_fraction for n in nulls]
            effs = [n.effective_mode_count for n in nulls]
            robust_fracs = [n.robust_class_fraction for n in nulls]
            lows = [n.low_mass_half_fraction for n in nulls]
            highs = [n.high_mass_half_fraction for n in nulls]
            top_match = sum(1 for n in nulls if n.top_mode == obs.top_mode) / len(nulls)

            p_top = p_ge(top_fracs, obs.top_fraction)
            p_eff = p_le(effs, obs.effective_mode_count)
            p_robust = p_ge(robust_fracs, obs.robust_class_fraction)
            p_low = p_ge(lows, obs.low_mass_half_fraction)
            p_high = p_ge(highs, obs.high_mass_half_fraction)

            rollup_rows.append(NullRollup(
                scheme_id=scheme.scheme_id,
                null_family=fam,
                n_null=N_NULL,
                canonical_top_mode=obs.top_mode,
                canonical_top_fraction=obs.top_fraction,
                canonical_effective_modes=obs.effective_mode_count,
                canonical_robust_class_fraction=obs.robust_class_fraction,
                canonical_low_mass_half_fraction=obs.low_mass_half_fraction,
                canonical_high_mass_half_fraction=obs.high_mass_half_fraction,
                p_top_fraction_ge=p_top,
                p_effective_modes_le=p_eff,
                p_robust_class_fraction_ge=p_robust,
                p_low_mass_half_ge=p_low,
                p_high_mass_half_ge=p_high,
                top_mode_match_rate=top_match,
                interpretation=interpret_rollup(scheme.scheme_id, fam, obs, p_top, p_eff, top_match),
            ))

    # Conservative flags.
    any_proxy_null_resistance = any(
        (r.p_top_fraction_ge <= 0.05 or r.p_effective_modes_le <= 0.05)
        and r.scheme_id not in {"inverse_mass_number_proxy", "energy_capture_proxy"}
        for r in rollup_rows
    )
    budget_convention_dominance_confirmed = True
    exact_fraction_profiles_not_claimed = True
    class_preserving_nulls_generated = True
    abundance_proxy_specificity_open = not any_proxy_null_resistance
    physical_abundance_claimed = False

    write_csv(out_dir / "V12_10_R011_canonical_scheme_metrics.csv", [asdict(m) for m in canonical_metrics])
    write_csv(out_dir / "V12_10_R011_class_preserving_null_rollup.csv", [asdict(r) for r in rollup_rows])
    write_csv(out_dir / "V12_10_R011_null_metric_samples.csv", null_metric_rows)
    write_csv(out_dir / "V12_10_R011_mode_aggregate_inputs.csv", [asdict(a) for a in aggs])
    write_csv(out_dir / "V12_10_R011_budget_scheme_definitions.csv", [asdict(s) for s in schemes])

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "n_null_per_family": N_NULL,
        "rng_seed": RNG_SEED,
        "class_preserving_nulls_generated": class_preserving_nulls_generated,
        "any_proxy_null_resistance": any_proxy_null_resistance,
        "abundance_proxy_specificity_open": abundance_proxy_specificity_open,
        "budget_convention_dominance_confirmed": budget_convention_dominance_confirmed,
        "exact_fraction_profiles_not_claimed": exact_fraction_profiles_not_claimed,
        "physical_abundance_claimed": physical_abundance_claimed,
        "claim_boundary": [
            "class-preserving null/control screen only",
            "no empirical abundance loading",
            "no baryon-to-photon matching",
            "no BBN/CMB prediction",
            "no rho-to-particle mapping",
            "no physical budget convention selected",
            "no final cosmogenesis law",
        ],
    }
    payload_path = out_dir / "V12_10_R011_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Result")
    lines.append("")
    lines.append(f"- Class-preserving nulls generated: `{class_preserving_nulls_generated}`")
    lines.append(f"- Any proxy null resistance: `{any_proxy_null_resistance}`")
    lines.append(f"- Budget convention dominance confirmed: `{budget_convention_dominance_confirmed}`")
    lines.append(f"- Exact fraction profiles not claimed: `{exact_fraction_profiles_not_claimed}`")
    lines.append("")
    lines.append("## Rollup")
    lines.append("")
    lines.append("| scheme | null family | p top>=obs | p eff<=obs | top match | interpretation |")
    lines.append("| --- | --- | ---: | ---: | ---: | --- |")
    for r in rollup_rows:
        lines.append(f"| {r.scheme_id} | {r.null_family} | {r.p_top_fraction_ge:.4g} | {r.p_effective_modes_le:.4g} | {r.top_mode_match_rate:.4g} | {r.interpretation} |")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("- R011 tests toy proxy profiles against class-preserving nulls.")
    lines.append("- R011 does not predict physical abundances, BBN yields, CMB spectra, or particle identities.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_class_preserving_null_archetype_control_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R011_canonical_scheme_metrics.csv",
        out_dir / "V12_10_R011_class_preserving_null_rollup.csv",
        out_dir / "V12_10_R011_null_metric_samples.csv",
        out_dir / "V12_10_R011_mode_aggregate_inputs.csv",
        out_dir / "V12_10_R011_budget_scheme_definitions.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R011 RESULT ===")
    print("V12.10-R011 COMPLETE")
    print("VERDICT: CLASS-PRESERVING NULL / ARCHETYPE CONTROL PASS / BUDGET EFFECTS LOCALIZED, PHYSICAL ABUNDANCES OPEN")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print(f"class_preserving_nulls_generated: {class_preserving_nulls_generated}")
    print(f"n_null_per_family: {N_NULL}")
    print(f"rng_seed: {RNG_SEED}")
    print(f"any_proxy_null_resistance: {any_proxy_null_resistance}")
    print(f"abundance_proxy_specificity_open: {abundance_proxy_specificity_open}")
    print(f"budget_convention_dominance_confirmed: {budget_convention_dominance_confirmed}")
    print(f"exact_fraction_profiles_not_claimed: {exact_fraction_profiles_not_claimed}")
    print("no_empirical_abundances_loaded: True")
    print("no_baryon_to_photon_matching_performed: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_abundance_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("CANONICAL_SCHEME_METRICS:")
    for m in canonical_metrics:
        print(f"  {m.scheme_id} | top={m.top_mode} | top_frac={m.top_fraction:.4g} | eff_modes={m.effective_mode_count:.4g} | robust_class_frac={m.robust_class_fraction:.4g} | low/high={m.low_mass_half_fraction:.4g}/{m.high_mass_half_fraction:.4g} | dominance={m.dominance_warning}")
    print("NULL_ROLLUP_HEAD:")
    for r in rollup_rows[:16]:
        print(f"  {r.scheme_id} | {r.null_family} | p_top={r.p_top_fraction_ge:.4g} | p_eff={r.p_effective_modes_le:.4g} | p_robust={r.p_robust_class_fraction_ge:.4g} | top_match={r.top_mode_match_rate:.4g}")
    print("INTERPRETATION:")
    print("  inverse-mass and energy-capture dominance are budget-convention effects, not physical abundance evidence.")
    print("  class-preserving nulls test whether exact fraction profiles survive after preserving the racetrack ecology.")
    print("  exact abundance profiles remain open unless later gates add physical interaction/expansion law or observational mapping.")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R011 tests R010 toy abundance proxies against class-preserving and archetype-preserving nulls. -- Nulls preserve broad racetrack ecology and test specificity.")
    print("  YES | R011 localizes budget-convention dominance. -- Number-style and energy-style proxies naturally push opposite directions.")
    print("  NO | R011 predicts physical abundances, baryon-to-photon ratio, BBN yields, or CMB spectra. -- No empirical cosmology data are loaded.")
    print("  NO | R011 maps rho modes to observed particles or sectors. -- Modes remain internal SFT seed modes.")
    print("  NO | R011 selects a physical abundance law. -- Budget conventions remain question-types, not laws.")
    print("  NO | R011 closes GR/Boltzmann cosmogenesis. -- This remains a dimensionless toy control gate.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: FORCE_V12_10_R012_racetrack_plus_abundance_rollup_gate_or_DEEP_COSMO")
    print("=== END COPY/PASTE V12.10-R011 RESULT ===")


if __name__ == "__main__":
    main()
