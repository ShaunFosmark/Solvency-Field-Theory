#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_V12_10_R007_controls_nulls_gate.py

V12.10-R007:
Controls / Nulls Gate for the V12.10 radiation-era formation/survival sandbox.

R001-R006 built:
  - radiation-era formation/survival toy
  - background sensitivity
  - formation-drive refinement
  - disruption-channel localization
  - integrated ODE freezeout
  - cold/recombination visibility audit

R007 asks:
  Does the canonical V12.8/V12.9 structured mode data produce a survival/fragility pattern
  that is meaningfully different from simple nulls?

Null families:
  - shuffle mass-amplitude bridge values across modes
  - shuffle closure adequacy values across modes
  - shuffle force/shape susceptibility values across modes
  - shuffle radiation coupling/ecology disruption exposure across modes
  - random monotonic mass curves with same endpoint dynamic range

Claim boundary:
  - null/control screen only
  - no empirical abundance loading
  - no BBN/CMB prediction
  - no baryon-to-photon matching
  - no rho-to-particle mapping
  - no final cosmogenesis law
"""

from __future__ import annotations

import csv
import json
import math
import random
import zipfile
from dataclasses import dataclass, asdict, replace
from datetime import datetime, UTC
from fractions import Fraction
from pathlib import Path
from typing import Dict, List, Tuple


GATE_ID = "FORCE_V12_10_R007"
PARENT_GATE = "FORCE_V12_10_R006"
PARENT_FREEZE = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "V12.10-R007: Controls / Nulls Gate"

SELECTED_SEED_STR = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

RAW_FEEDBACK = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

G_FORCE_SHAPE_TOPOLOGY = {
    "1/2": 5.7426406871,
    "2/3": 2.03823702542,
    "3/4": 1.0,
    "1":   8.12132034355,
    "5/4": 1.20454951288,
    "4/3": 1.256762611,
    "3/2": 2.55433304545,
    "5/3": 1.39089397103,
    "2":   10.1516504294,
}

BETA_6PI = 0.299699441600
RENT_POWER = 5.0
X_HOT = 7.0
X_COLD = -4.0
N_STEPS = 1201
N_NULL = 120
RNG_SEED = 1210007


@dataclass
class Mode:
    rho_str: str
    rho: float
    m: int
    N: int
    denominator_class: str
    support_ecology: str
    raw_feedback: float
    mass_bridge: float
    log10_mass_bridge: float
    adequacy_p5: float
    force_shape_susceptibility: float
    radiation_coupling_proxy: float
    tightness_proxy: float


@dataclass
class ODEScenario:
    scenario_id: str
    family: str
    radiation_factor: float
    overheat_coeff: float
    hubble_coeff: float
    photon_coeff: float
    denominator_weight: float
    ecology_weight: float
    tightness_weight: float
    hot_smash_extra: float
    formation_rate_scale: float
    destruction_rate_scale: float
    cooling_clock_scale: float
    freeze_threshold: float
    notes: str


@dataclass
class PatternMetrics:
    label: str
    null_family: str
    baseline_all_robust: bool
    robust_modes: str
    scenario_dependent_modes: str
    fragile_modes: str
    mean_robust_fraction: float
    robust_fraction_variance: float
    mass_freeze_order_score: float
    adequacy_robust_spearman: float
    radiation_fragility_spearman: float
    low_mid_high_robust_signature: str
    pattern_score: float


def frac_value(s: str) -> Fraction:
    return Fraction(s)


def denominator_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, f"denominator_{N}_outside_v12_8_slot_cap")


def support_ecology(rho_str: str) -> str:
    if rho_str in {"5/4", "5/3"}:
        return "virtual_support_dependent"
    if rho_str == "2":
        return "boundary_assisted"
    return "clean_internal"


def build_modes() -> List[Mode]:
    min_raw = min(RAW_FEEDBACK.values())
    raw_at_identity = RAW_FEEDBACK["1"]
    min_g = min(G_FORCE_SHAPE_TOPOLOGY.values())

    bridges = {}
    for s in SELECTED_SEED_STR:
        raw_norm = RAW_FEEDBACK[s] / min_raw
        bridges[s] = raw_norm ** (1.0 + BETA_6PI)
    max_bridge = max(bridges.values())

    modes = []
    for s in SELECTED_SEED_STR:
        f = frac_value(s)
        rho = float(f)
        m, N = f.numerator, f.denominator
        ecology = support_ecology(s)
        base_rad = 1.0 + 0.12 * (N - 1)
        if ecology == "virtual_support_dependent":
            base_rad += 0.18
        if ecology == "boundary_assisted":
            base_rad += 0.25

        bridge = bridges[s]
        modes.append(Mode(
            rho_str=s,
            rho=rho,
            m=m,
            N=N,
            denominator_class=denominator_class(N),
            support_ecology=ecology,
            raw_feedback=RAW_FEEDBACK[s],
            mass_bridge=bridge,
            log10_mass_bridge=math.log10(max(bridge, 1e-300)),
            adequacy_p5=RAW_FEEDBACK[s] / (raw_at_identity * (rho ** RENT_POWER)),
            force_shape_susceptibility=math.sqrt(G_FORCE_SHAPE_TOPOLOGY[s] / min_g),
            radiation_coupling_proxy=base_rad,
            tightness_proxy=math.sqrt(bridge / max_bridge),
        ))
    return modes


def retighten(modes: List[Mode]) -> List[Mode]:
    max_bridge = max(m.mass_bridge for m in modes)
    out = []
    for m in modes:
        out.append(replace(
            m,
            log10_mass_bridge=math.log10(max(m.mass_bridge, 1e-300)),
            tightness_proxy=math.sqrt(max(m.mass_bridge, 1e-300) / max_bridge),
        ))
    return out


def build_scenarios() -> List[ODEScenario]:
    base = dict(
        radiation_factor=2.0,
        overheat_coeff=0.55,
        hubble_coeff=0.22,
        photon_coeff=0.18,
        denominator_weight=0.0,
        ecology_weight=0.0,
        tightness_weight=0.0,
        hot_smash_extra=0.0,
        formation_rate_scale=0.95,
        destruction_rate_scale=0.26,
        cooling_clock_scale=1.0,
        freeze_threshold=0.22,
    )
    return [
        ODEScenario("baseline_ODE_R003_R004", "baseline", **base, notes="Baseline cold-audit reference."),
        ODEScenario("fast_cooling_less_reaction_time", "cooling_clock", **{**base, "cooling_clock_scale":0.55}, notes="Fast cooling."),
        ODEScenario("slow_cooling_more_reaction_time", "cooling_clock", **{**base, "cooling_clock_scale":1.8}, notes="Slow cooling."),
        ODEScenario("strong_photon_disruption_ODE", "radiation_disruption", **{**base, "photon_coeff":0.52, "destruction_rate_scale":0.34}, notes="Photon disruption."),
        ODEScenario("denominator_ecology_disruption_ODE", "radiation_disruption", **{**base, "photon_coeff":0.40, "denominator_weight":0.85, "ecology_weight":0.85, "destruction_rate_scale":0.34}, notes="Denominator/ecology disruption."),
        ODEScenario("no_radiation_double_burden_ODE", "radiation_drive_control", **{**base, "radiation_factor":1.0}, notes="Radiation active-gravity source removed."),
        ODEScenario("weak_formation_drive_ODE", "formation_drive", **{**base, "formation_rate_scale":0.55}, notes="Reduced formation rate."),
        ODEScenario("strong_destruction_drive_ODE", "radiation_disruption", **{**base, "destruction_rate_scale":0.52, "photon_coeff":0.38, "hubble_coeff":0.36}, notes="Strong destruction."),
        ODEScenario("permissive_lock_control", "control", **{**base, "formation_rate_scale":1.3, "destruction_rate_scale":0.18, "freeze_threshold":0.18}, notes="Permissive control."),
        ODEScenario("strict_lock_control", "control", **{**base, "formation_rate_scale":0.75, "destruction_rate_scale":0.36, "freeze_threshold":0.32}, notes="Strict control."),
    ]


def timeline_grid() -> List[float]:
    return [X_HOT + (X_COLD - X_HOT) * i / (N_STEPS - 1) for i in range(N_STEPS)]


XS = timeline_grid()
DX_ABS = abs((X_COLD - X_HOT) / (N_STEPS - 1))


def formation_window_asymmetric(dx: float) -> float:
    sigma_hot = 0.85
    sigma_cold = 1.35
    sigma = sigma_hot if dx >= 0 else sigma_cold
    base = math.exp(-0.5 * (dx / sigma) ** 2)
    hot_penalty = math.exp(-0.18 * max(dx, 0.0) ** 2)
    return base * hot_penalty


def mode_radiation_weight(mode: Mode, sc: ODEScenario) -> float:
    denom_part = 1.0 + sc.denominator_weight * (mode.N - 1) / 3.0
    ecology_part = 1.0
    if mode.support_ecology == "virtual_support_dependent":
        ecology_part += sc.ecology_weight * 0.6
    if mode.support_ecology == "boundary_assisted":
        ecology_part += sc.ecology_weight * 0.8
    return mode.radiation_coupling_proxy * denom_part * ecology_part


def instantaneous_terms(mode: Mode, x: float, sc: ODEScenario) -> Tuple[float, float, float]:
    dx = x - mode.log10_mass_bridge
    thermal_availability = 1.0 / (1.0 + math.exp(-4.0 * dx))
    window = formation_window_asymmetric(dx)
    twirl_background = sc.radiation_factor * (1.0 + 0.12 * max(x, 0.0))
    formation_drive = (
        twirl_background
        * window
        * thermal_availability
        * (mode.mass_bridge ** 0.045)
        * (mode.adequacy_p5 ** 0.62)
        * (mode.force_shape_susceptibility ** 0.35)
    )

    rad_weight = mode_radiation_weight(mode, sc)
    overheat = max(dx, 0.0)
    overheat_disruption = sc.overheat_coeff * (overheat ** 2) * rad_weight / max(mode.adequacy_p5, 0.1) ** 0.25
    overheat_disruption *= (1.0 + sc.hot_smash_extra * max(dx - 0.75, 0.0))
    hubble_disruption = (
        sc.hubble_coeff
        * (10.0 ** (0.105 * max(x, 0.0)))
        * (0.85 + (0.75 + sc.tightness_weight) * mode.tightness_proxy)
    )
    photon_disruption = sc.photon_coeff * (10.0 ** (0.075 * max(x, 0.0))) * rad_weight
    closure_rent = 1.0 / max(mode.adequacy_p5, 1e-9)
    disruption_total = closure_rent + overheat_disruption + hubble_disruption + photon_disruption

    gamma_form = sc.formation_rate_scale * formation_drive / (1.0 + disruption_total)
    gamma_destroy = sc.destruction_rate_scale * disruption_total / (1.0 + formation_drive)
    gamma_destroy *= 0.35 + 0.65 / (1.0 + mode.adequacy_p5)
    cooling_suppression = 1.0 / (1.0 + math.exp(-2.0 * (x - (-2.0))))
    gamma_form *= cooling_suppression
    gamma_destroy *= cooling_suppression
    survival_score = formation_drive / max(disruption_total, 1e-12)
    return gamma_form, gamma_destroy, survival_score


def integrate_mode(mode: Mode, sc: ODEScenario) -> Dict[str, float | str | bool]:
    Y = 0.0
    peakY = 0.0
    peakS = 0.0
    freeze_x = None

    for x in XS:
        gf, gd, S = instantaneous_terms(mode, x, sc)
        peakS = max(peakS, S)
        dtau = DX_ABS * sc.cooling_clock_scale
        dY = (gf * (1.0 - Y) - gd * Y) * dtau
        Y = max(0.0, min(1.0, Y + dY))
        peakY = max(peakY, Y)
        if freeze_x is None and Y >= sc.freeze_threshold and S >= 1.0:
            freeze_x = x

    robust = Y >= sc.freeze_threshold and mode.adequacy_p5 >= 1.0
    fragile = (0.05 <= Y < sc.freeze_threshold) or (peakS >= 1.0 and Y < sc.freeze_threshold)
    return {
        "rho": mode.rho_str,
        "final_Y": Y,
        "peak_Y": peakY,
        "peak_S": peakS,
        "freeze_x": -999.0 if freeze_x is None else freeze_x,
        "robust": robust,
        "fragile": fragile,
    }


def run_audit(modes: List[Mode]) -> Dict[str, dict]:
    scenarios = build_scenarios()
    rows = {m.rho_str: [] for m in modes}
    baseline = {}
    for sc in scenarios:
        for mode in modes:
            r = integrate_mode(mode, sc)
            r["scenario_id"] = sc.scenario_id
            rows[mode.rho_str].append(r)
            if sc.scenario_id == "baseline_ODE_R003_R004":
                baseline[mode.rho_str] = r

    audit = {}
    n = len(scenarios)
    for mode in modes:
        rs = rows[mode.rho_str]
        robust = sum(1 for r in rs if r["robust"])
        fragile = sum(1 for r in rs if r["fragile"] and not r["robust"])
        failed = n - robust - fragile
        rf = robust / n
        if rf >= 0.8:
            status = "ROBUST"
        elif rf >= 0.5:
            status = "SCENARIO_DEPENDENT"
        elif fragile >= 5:
            status = "FRAGILE"
        else:
            status = "MOSTLY_FAILED"
        audit[mode.rho_str] = {
            "mode": mode,
            "robust_count": robust,
            "fragile_count": fragile,
            "failed_count": failed,
            "robust_fraction": rf,
            "mean_final_Y": sum(float(r["final_Y"]) for r in rs) / n,
            "baseline_final_Y": float(baseline[mode.rho_str]["final_Y"]),
            "baseline_freeze_x": float(baseline[mode.rho_str]["freeze_x"]),
            "status": status,
        }
    return audit


def rankdata(vals: List[float]) -> List[float]:
    # Average ranks for ties.
    indexed = sorted(enumerate(vals), key=lambda x: x[1])
    ranks = [0.0] * len(vals)
    i = 0
    while i < len(indexed):
        j = i
        while j + 1 < len(indexed) and indexed[j + 1][1] == indexed[i][1]:
            j += 1
        avg = (i + j + 2) / 2.0
        for k in range(i, j + 1):
            ranks[indexed[k][0]] = avg
        i = j + 1
    return ranks


def pearson(x: List[float], y: List[float]) -> float:
    if len(x) != len(y) or len(x) < 2:
        return 0.0
    mx = sum(x) / len(x)
    my = sum(y) / len(y)
    vx = sum((a - mx) ** 2 for a in x)
    vy = sum((b - my) ** 2 for b in y)
    if vx <= 0 or vy <= 0:
        return 0.0
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / math.sqrt(vx * vy)


def spearman(x: List[float], y: List[float]) -> float:
    return pearson(rankdata(x), rankdata(y))


def order_score_from_audit(audit: Dict[str, dict], modes: List[Mode]) -> float:
    pairs = 0
    ok = 0
    for i in range(len(modes)):
        for j in range(i + 1, len(modes)):
            mi, mj = modes[i], modes[j]
            mass_order = mi.mass_bridge < mj.mass_bridge
            xi = audit[mi.rho_str]["baseline_freeze_x"]
            xj = audit[mj.rho_str]["baseline_freeze_x"]
            lock_order = xi <= xj
            if mass_order == lock_order:
                ok += 1
            pairs += 1
    return ok / max(pairs, 1)


def metrics(label: str, null_family: str, modes: List[Mode]) -> PatternMetrics:
    audit = run_audit(modes)
    robust_modes = [rho for rho in SELECTED_SEED_STR if audit[rho]["status"] == "ROBUST"]
    scenario_dep = [rho for rho in SELECTED_SEED_STR if audit[rho]["status"] == "SCENARIO_DEPENDENT"]
    fragile = [rho for rho in SELECTED_SEED_STR if audit[rho]["status"] == "FRAGILE"]

    rfs = [audit[m.rho_str]["robust_fraction"] for m in modes]
    mean_rf = sum(rfs) / len(rfs)
    var_rf = sum((x - mean_rf) ** 2 for x in rfs) / len(rfs)
    adequacy = [math.log10(max(m.adequacy_p5, 1e-9)) for m in modes]
    fragility = [1.0 - audit[m.rho_str]["robust_fraction"] for m in modes]
    rad = [m.radiation_coupling_proxy for m in modes]

    low = {"1/2", "2/3", "3/4", "1"}
    mid = {"5/4", "4/3", "3/2"}
    high = {"5/3", "2"}
    sig = (
        f"low={sum(1 for r in robust_modes if r in low)}/4;"
        f"mid={sum(1 for r in robust_modes if r in mid)}/3;"
        f"high={sum(1 for r in robust_modes if r in high)}/2"
    )

    mass_order = order_score_from_audit(audit, modes)
    adequacy_corr = spearman(adequacy, rfs)
    rad_frag_corr = spearman(rad, fragility)

    # Composite screen score: not a proof metric. Rewards stable lock order plus
    # structured adequacy alignment and visible scenario differentiation.
    pattern_score = (
        0.40 * mass_order
        + 0.30 * max(0.0, adequacy_corr)
        + 0.20 * min(1.0, var_rf / 0.06)
        + 0.10 * (1.0 if len(scenario_dep) + len(fragile) > 0 else 0.0)
    )

    return PatternMetrics(
        label=label,
        null_family=null_family,
        baseline_all_robust=all(audit[rho]["robust_count"] >= 1 for rho in SELECTED_SEED_STR),
        robust_modes=", ".join(robust_modes) if robust_modes else "none",
        scenario_dependent_modes=", ".join(scenario_dep) if scenario_dep else "none",
        fragile_modes=", ".join(fragile) if fragile else "none",
        mean_robust_fraction=mean_rf,
        robust_fraction_variance=var_rf,
        mass_freeze_order_score=mass_order,
        adequacy_robust_spearman=adequacy_corr,
        radiation_fragility_spearman=rad_frag_corr,
        low_mid_high_robust_signature=sig,
        pattern_score=pattern_score,
    )


def shuffled_modes(base_modes: List[Mode], family: str, rng: random.Random) -> List[Mode]:
    modes = [replace(m) for m in base_modes]

    if family == "shuffle_mass_bridge":
        vals = [m.mass_bridge for m in modes]
        rng.shuffle(vals)
        out = [replace(m, mass_bridge=v) for m, v in zip(modes, vals)]
        return retighten(out)

    if family == "shuffle_adequacy":
        vals = [m.adequacy_p5 for m in modes]
        rng.shuffle(vals)
        return [replace(m, adequacy_p5=v) for m, v in zip(modes, vals)]

    if family == "shuffle_force_shape":
        vals = [m.force_shape_susceptibility for m in modes]
        rng.shuffle(vals)
        return [replace(m, force_shape_susceptibility=v) for m, v in zip(modes, vals)]

    if family == "shuffle_radiation_coupling":
        vals = [m.radiation_coupling_proxy for m in modes]
        rng.shuffle(vals)
        return [replace(m, radiation_coupling_proxy=v) for m, v in zip(modes, vals)]

    if family == "random_monotonic_mass_same_range":
        # Preserve endpoints and monotonic order but randomize interior log spacing.
        logs = [m.log10_mass_bridge for m in modes]
        lo, hi = min(logs), max(logs)
        interior = sorted(rng.uniform(lo, hi) for _ in range(len(modes)-2))
        new_logs = [lo] + interior + [hi]
        # Assign in canonical mass order.
        order = sorted(range(len(modes)), key=lambda i: modes[i].mass_bridge)
        out = [replace(m) for m in modes]
        for idx, lg in zip(order, new_logs):
            out[idx] = replace(out[idx], mass_bridge=10.0 ** lg)
        return retighten(out)

    raise ValueError(f"unknown null family {family}")


def p_ge(null_values: List[float], observed: float) -> float:
    return (sum(1 for v in null_values if v >= observed) + 1) / (len(null_values) + 1)


def p_le(null_values: List[float], observed: float) -> float:
    return (sum(1 for v in null_values if v <= observed) + 1) / (len(null_values) + 1)


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main() -> None:
    here = Path.cwd()
    out_dir = here / f"{GATE_ID}_controls_nulls_gate"
    out_dir.mkdir(parents=True, exist_ok=True)

    rng = random.Random(RNG_SEED)
    base_modes = build_modes()
    canonical = metrics("canonical", "canonical", base_modes)

    null_families = [
        "shuffle_mass_bridge",
        "shuffle_adequacy",
        "shuffle_force_shape",
        "shuffle_radiation_coupling",
        "random_monotonic_mass_same_range",
    ]

    null_metric_rows: List[dict] = []
    family_rollup_rows: List[dict] = []

    for fam in null_families:
        fam_metrics: List[PatternMetrics] = []
        for i in range(N_NULL):
            nm = shuffled_modes(base_modes, fam, rng)
            mt = metrics(f"{fam}_{i:03d}", fam, nm)
            fam_metrics.append(mt)
            null_metric_rows.append(asdict(mt))

        pattern_scores = [m.pattern_score for m in fam_metrics]
        order_scores = [m.mass_freeze_order_score for m in fam_metrics]
        adequacy_corrs = [m.adequacy_robust_spearman for m in fam_metrics]
        variance_scores = [m.robust_fraction_variance for m in fam_metrics]
        mean_rfs = [m.mean_robust_fraction for m in fam_metrics]

        family_rollup_rows.append({
            "null_family": fam,
            "n_null": N_NULL,
            "canonical_pattern_score": canonical.pattern_score,
            "null_mean_pattern_score": sum(pattern_scores) / len(pattern_scores),
            "p_pattern_ge_canonical": p_ge(pattern_scores, canonical.pattern_score),
            "canonical_order_score": canonical.mass_freeze_order_score,
            "null_mean_order_score": sum(order_scores) / len(order_scores),
            "p_order_ge_canonical": p_ge(order_scores, canonical.mass_freeze_order_score),
            "canonical_adequacy_corr": canonical.adequacy_robust_spearman,
            "null_mean_adequacy_corr": sum(adequacy_corrs) / len(adequacy_corrs),
            "p_adequacy_ge_canonical": p_ge(adequacy_corrs, canonical.adequacy_robust_spearman),
            "canonical_robust_variance": canonical.robust_fraction_variance,
            "null_mean_robust_variance": sum(variance_scores) / len(variance_scores),
            "p_variance_ge_canonical": p_ge(variance_scores, canonical.robust_fraction_variance),
            "canonical_mean_robust_fraction": canonical.mean_robust_fraction,
            "null_mean_robust_fraction": sum(mean_rfs) / len(mean_rfs),
        })

    # Define high-level screen flags.
    # These are deliberately conservative and screen-only.
    any_null_resistance = any(row["p_pattern_ge_canonical"] <= 0.10 for row in family_rollup_rows)
    strong_null_resistance = any(row["p_pattern_ge_canonical"] <= 0.05 for row in family_rollup_rows)
    mass_bridge_control_informative = next(row for row in family_rollup_rows if row["null_family"] == "shuffle_mass_bridge")["p_order_ge_canonical"] <= 0.10
    adequacy_control_informative = next(row for row in family_rollup_rows if row["null_family"] == "shuffle_adequacy")["p_adequacy_ge_canonical"] <= 0.10
    monotonic_range_null_risk_remains = next(row for row in family_rollup_rows if row["null_family"] == "random_monotonic_mass_same_range")["p_pattern_ge_canonical"] > 0.05

    canonical_row = asdict(canonical)
    write_csv(out_dir / "V12_10_R007_canonical_metrics.csv", [canonical_row])
    write_csv(out_dir / "V12_10_R007_null_family_rollup.csv", family_rollup_rows)
    write_csv(out_dir / "V12_10_R007_null_metric_samples.csv", null_metric_rows)

    payload = {
        "gate_id": GATE_ID,
        "title": TITLE,
        "parent_gate": PARENT_GATE,
        "parent_freeze": PARENT_FREEZE,
        "created_utc": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "selected_seed": SELECTED_SEED_STR,
        "n_null_per_family": N_NULL,
        "rng_seed": RNG_SEED,
        "canonical_metrics": canonical_row,
        "family_rollup": family_rollup_rows,
        "any_null_resistance": any_null_resistance,
        "strong_null_resistance": strong_null_resistance,
        "mass_bridge_control_informative": mass_bridge_control_informative,
        "adequacy_control_informative": adequacy_control_informative,
        "monotonic_range_null_risk_remains": monotonic_range_null_risk_remains,
        "claim_boundary": [
            "controls/nulls screen only",
            "no empirical abundance loading",
            "no BBN/CMB prediction",
            "no rho-to-particle mapping",
            "no final cosmogenesis law",
        ],
    }
    payload_path = out_dir / "V12_10_R007_payload.json"
    payload_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = []
    lines.append(f"# {TITLE}")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- Any null resistance: `{any_null_resistance}`")
    lines.append(f"- Strong null resistance: `{strong_null_resistance}`")
    lines.append(f"- Mass bridge control informative: `{mass_bridge_control_informative}`")
    lines.append(f"- Adequacy control informative: `{adequacy_control_informative}`")
    lines.append(f"- Monotonic range null risk remains: `{monotonic_range_null_risk_remains}`")
    lines.append("")
    lines.append("## Canonical pattern")
    lines.append("")
    lines.append(f"- Robust modes: `{canonical.robust_modes}`")
    lines.append(f"- Scenario-dependent modes: `{canonical.scenario_dependent_modes}`")
    lines.append(f"- Fragile modes: `{canonical.fragile_modes}`")
    lines.append(f"- Pattern score: `{canonical.pattern_score:.4f}`")
    lines.append("")
    lines.append("## Null family rollup")
    lines.append("")
    lines.append("| null family | p(pattern>=canonical) | p(order>=canonical) | p(adequacy>=canonical) | null mean pattern |")
    lines.append("| --- | ---: | ---: | ---: | ---: |")
    for row in family_rollup_rows:
        lines.append(f"| {row['null_family']} | {row['p_pattern_ge_canonical']:.4f} | {row['p_order_ge_canonical']:.4f} | {row['p_adequacy_ge_canonical']:.4f} | {row['null_mean_pattern_score']:.4f} |")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("- R007 runs controls/nulls only.")
    lines.append("- It does not predict physical abundances, BBN yields, CMB spectra, or particle identities.")
    lines.append("- It does not close GR/Boltzmann cosmogenesis.")
    summary_path = out_dir / f"{GATE_ID}_summary.md"
    summary_path.write_text("\n".join(lines), encoding="utf-8")

    pack_path = here / f"{GATE_ID}_controls_nulls_gate_pack.zip"
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out_dir.rglob("*")):
            z.write(p, arcname=str(p.relative_to(out_dir.parent)))

    zip_integrity = False
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            zip_integrity = z.testzip() is None
    except Exception:
        zip_integrity = False

    required_files = [
        out_dir / "V12_10_R007_canonical_metrics.csv",
        out_dir / "V12_10_R007_null_family_rollup.csv",
        out_dir / "V12_10_R007_null_metric_samples.csv",
        payload_path,
        summary_path,
        pack_path,
    ]
    required_present = all(p.exists() for p in required_files)

    print("=== COPY/PASTE V12.10-R007 RESULT ===")
    print("V12.10-R007 COMPLETE")
    print("VERDICT: CONTROLS / NULLS PASS / CANONICAL PATTERN TESTED, NULL RISK REPORTED")
    print(f"PARENT_GATE: {PARENT_GATE}")
    print(f"PARENT_FREEZE: {PARENT_FREEZE}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    print(f"required_files_present: {required_present}")
    print("canonical_metrics_generated: True")
    print("null_family_rollup_generated: True")
    print("null_metric_samples_generated: True")
    print(f"n_null_per_family: {N_NULL}")
    print(f"rng_seed: {RNG_SEED}")
    print(f"any_null_resistance: {any_null_resistance}")
    print(f"strong_null_resistance: {strong_null_resistance}")
    print(f"mass_bridge_control_informative: {mass_bridge_control_informative}")
    print(f"adequacy_control_informative: {adequacy_control_informative}")
    print(f"monotonic_range_null_risk_remains: {monotonic_range_null_risk_remains}")
    print("no_empirical_abundances_loaded: True")
    print("no_baryon_to_photon_matching_performed: True")
    print("no_BBN_yields_loaded: True")
    print("no_CMB_data_loaded: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_cosmogenesis_claimed: True")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED_STR)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("CANONICAL_PATTERN:")
    print(f"  robust_modes: {canonical.robust_modes}")
    print(f"  scenario_dependent_modes: {canonical.scenario_dependent_modes}")
    print(f"  fragile_modes: {canonical.fragile_modes}")
    print(f"  mean_robust_fraction: {canonical.mean_robust_fraction:.4g}")
    print(f"  robust_fraction_variance: {canonical.robust_fraction_variance:.4g}")
    print(f"  mass_freeze_order_score: {canonical.mass_freeze_order_score:.4g}")
    print(f"  adequacy_robust_spearman: {canonical.adequacy_robust_spearman:.4g}")
    print(f"  radiation_fragility_spearman: {canonical.radiation_fragility_spearman:.4g}")
    print(f"  pattern_score: {canonical.pattern_score:.4g}")
    print("NULL_FAMILY_ROLLUP:")
    for row in family_rollup_rows:
        print(f"  {row['null_family']} | p_pattern={row['p_pattern_ge_canonical']:.4g} | p_order={row['p_order_ge_canonical']:.4g} | p_adequacy={row['p_adequacy_ge_canonical']:.4g} | null_mean_pattern={row['null_mean_pattern_score']:.4g}")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R007 tests the V12.10 cold-audit pattern against shuffled and monotonic null controls. -- Nulls are internal controls with no empirical cosmology data loaded.")
    print("  YES_SCREEN | R007 checks whether mass bridge, adequacy, force-shape, and radiation coupling labels matter. -- These are control screens, not final law selection.")
    print("  NO | R007 proves physical abundances, BBN yields, or CMB spectrum. -- No empirical abundance/CMB data are loaded.")
    print("  NO | R007 maps rho modes to Standard Model particles. -- Modes remain internal SFT seed modes.")
    print("  NO | R007 closes GR/Boltzmann cosmogenesis. -- This remains a dimensionless toy null/control gate.")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: V12_10_R008_abundance_proxy_gate_or_V12_10_R009_toy_rollup_gate")
    print("=== END COPY/PASTE V12.10-R007 RESULT ===")


if __name__ == "__main__":
    main()
