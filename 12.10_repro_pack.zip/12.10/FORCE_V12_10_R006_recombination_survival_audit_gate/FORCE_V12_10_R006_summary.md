# V12.10-R006: Recombination / Cold Visibility Survival Audit Gate

## Summary

- Baseline robust all modes: `True`
- Scenario sensitivity present: `True`
- Robust cold relic screen modes: `1/2, 4/3, 3/2, 5/3, 2`
- Scenario-dependent modes: `2/3, 3/4, 5/4`
- Fragile/transient modes: `1`

## Mode audit ledger

| rho | N | ecology | baseline Y | robust/fragile/failed | mean Y | status |
| --- | ---: | --- | ---: | --- | ---: | --- |
| 1/2 | 2 | clean_internal | 0.530 | 10/0/0 | 0.433 | ROBUST_COLD_RELIC_SCREEN |
| 2/3 | 3 | clean_internal | 0.393 | 7/3/0 | 0.300 | SCENARIO_DEPENDENT_RELIC_SCREEN |
| 3/4 | 4 | clean_internal | 0.336 | 5/5/0 | 0.247 | SCENARIO_DEPENDENT_RELIC_SCREEN |
| 1 | 1 | clean_internal | 0.321 | 4/6/0 | 0.242 | FRAGILE_TRANSIENT_RELIC_SCREEN |
| 5/4 | 4 | virtual_support_dependent | 0.415 | 6/4/0 | 0.290 | SCENARIO_DEPENDENT_RELIC_SCREEN |
| 4/3 | 3 | clean_internal | 0.485 | 8/2/0 | 0.363 | ROBUST_COLD_RELIC_SCREEN |
| 3/2 | 2 | clean_internal | 0.595 | 9/1/0 | 0.480 | ROBUST_COLD_RELIC_SCREEN |
| 5/3 | 3 | virtual_support_dependent | 0.620 | 8/2/0 | 0.490 | ROBUST_COLD_RELIC_SCREEN |
| 2 | 1 | boundary_assisted | 0.563 | 9/1/0 | 0.453 | ROBUST_COLD_RELIC_SCREEN |

## Claim boundary

- Recombination is treated only as a cold visibility / photon-decoupling audit marker.
- R006 does not claim fundamental particles first form at recombination.
- R006 does not predict physical abundances, BBN yields, CMB spectra, or particle identities.