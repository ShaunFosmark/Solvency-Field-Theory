# V12.10-R005: Survival ODE / Freezeout Sweep Gate

## Summary

- ODE survival varies: `True`
- Partial ODE windows present: `True`
- Radiation factor informative: `True`
- Cooling clock informative: `True`
- Disruption informative: `True`
- Lock order stable: `True`

## Scenario scorecard

| scenario | robust | fragile | failed | mean final Y | mean peak Y | order | grade |
| --- | ---: | --- | --- | ---: | ---: | ---: | --- |
| baseline_ODE_R003_R004 | 9 | none | none | 0.473 | 0.795 | 1.000 | FULL_ODE_SURVIVAL |
| fast_cooling_less_reaction_time | 9 | none | none | 0.501 | 0.662 | 1.000 | FULL_ODE_SURVIVAL |
| slow_cooling_more_reaction_time | 8 | 1 | none | 0.347 | 0.890 | 1.000 | PARTIAL_ODE_SURVIVAL_INFORMATIVE |
| strong_photon_disruption_ODE | 6 | 3/4, 1, 5/4 | none | 0.259 | 0.724 | 1.000 | PARTIAL_ODE_SURVIVAL_INFORMATIVE |
| denominator_ecology_disruption_ODE | 3 | 2/3, 3/4, 1, 5/4, 4/3, 5/3 | none | 0.212 | 0.685 | 0.861 | MOSTLY_FRAGILE |
| no_radiation_double_burden_ODE | 7 | 3/4, 1 | none | 0.363 | 0.614 | 0.917 | PARTIAL_ODE_SURVIVAL_INFORMATIVE |
| weak_formation_drive_ODE | 9 | none | none | 0.396 | 0.663 | 1.000 | FULL_ODE_SURVIVAL |
| strong_destruction_drive_ODE | 1 | 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2 | none | 0.153 | 0.708 | 1.000 | MOSTLY_FRAGILE |
| permissive_lock_control | 9 | none | none | 0.606 | 0.869 | 1.000 | FULL_ODE_SURVIVAL |
| strict_lock_control | 5 | 2/3, 3/4, 1, 5/4 | none | 0.356 | 0.730 | 1.000 | PARTIAL_ODE_SURVIVAL_INFORMATIVE |

## Claim boundary

- R005 is an integrated toy ODE screen, not a physical Boltzmann calculation.
- It does not predict physical abundances, BBN yields, CMB spectra, or particle identities.
- It does not close GR/Boltzmann cosmogenesis.