# File inventory

| File | Bytes | SHA-256 |
|---|---:|---|
| `README_FIRST.md` | 2213 | `0f0ec4bfe87f8220dcdcc302f2c41919a239e6a06e5081cb79b1e3b318cfdc69` |
| `companions/SFT_Alpha_137_Pack.zip` | 1109508 | `19e7b92025fad4e71f8e23d9d68d9a63df29b2d7516cf491f35b24da009e16e5` |
| `figures/fig1_architecture.png` | 170528 | `0b1d6ba6856d18ca07cdb8ccedab4900bcd8e833c16da17988383ae05b534ce7` |
| `figures/fig2_profiles.png` | 150975 | `0c9e93da5fcacfb0a651d96b62005a15a619aa5979ea42989021c28ed9e98476` |
| `figures/fig3_framing.png` | 112239 | `9fcd7e458f2fa340cf50367e0e8ba6a099d25d49616865d9e9d0d10311e961c6` |
| `figures/fig4_stability.png` | 112652 | `741fdd35637365768efaf131b1203b004176a6792e830bb7c944298088bb745c` |
| `figures/fig5_alpha_ablation.png` | 130620 | `e4774c2f85c9f2fe42bbe52d3af136465fc25a0f06514b4df38493da791eaa34` |
| `frozen_numerical_authority/SFT_IEMM_C17G19_FULL_FREEZE_PACK.zip` | 3238215 | `4fbed37786bfa3a39170cc1a3e5dd1d325967a8bd7438400238d6fb479ab8a8d` |
| `paper/SFT_V13_12_The_Maintained_Electron_Public_Draft_v0_2.docx` | 669919 | `414aaa72abae5e14320f5b25f920610fbffa1fa0ed3e75a5178a4fa34ac67107` |
| `paper/SFT_V13_12_The_Maintained_Electron_Public_Draft_v0_2.pdf` | 1043712 | `439b63c872a60d366df89f77eaab85cc2682984d748d7bdc0c9d6c2453fee4ef` |
| `repro/CLAIM_TO_ARTIFACT_MAP.md` | 2184 | `fc155d7240fcfea6991e02ba3ee906b865bb1ddc7071272e9de5b07e5cfcc622` |
| `repro/PACK_MANIFEST.json` | 905 | `1f726f0ad8f808e15f5891369ab424819ceab4a1dc0cc15ca21050e1a0c5f3c4` |
| `repro/REPRODUCTION_CHECKLIST.md` | 1165 | `3664cc00dd96a8cb81eaab5cc2256b0092b3b4447869bf68ba7b01ae2f0a8d70` |
