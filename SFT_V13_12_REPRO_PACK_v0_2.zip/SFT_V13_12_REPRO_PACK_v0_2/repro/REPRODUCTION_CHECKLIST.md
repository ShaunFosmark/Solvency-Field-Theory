# Reproduction / audit checklist

- [ ] Verify every file in this wrapper with `repro/SHA256SUMS.txt`.
- [ ] Verify the nested `SFT_IEMM_C17G19_FULL_FREEZE_PACK.zip` opens with no CRC errors.
- [ ] Verify the frozen NPZ inside that pack hashes to `ba57e94177dae9f6ff2b734ae25caa05105b7aa7d9636e39403022843f1dd6dd`.
- [ ] Treat C17G19 as numerical source of truth and V13.12 as the public presentation layer.
- [ ] Do not promote `Gamma_star` from free formation/support parameter to prediction.
- [ ] Do not promote `alpha_EM` / absolute charge stiffness from interface input to prediction.
- [ ] Do not promote inherited route `R/Z` reference labels to physical observables.
- [ ] Keep post-closure clock/readout relations downstream of structural closure.
- [ ] Keep whole-space ADM/Coulomb matching, anomalous moment, formation, scattering/form factor, interactions, pair production, exchange statistics, and stronger nonlinear stability explicitly open where V13.12 leaves them open.
- [ ] If any future observable requires retuning the frozen isolated state merely to make the observable work, declare a new model/version rather than silently updating V13.12.
