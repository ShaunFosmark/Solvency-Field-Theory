# Claim-to-artifact map — SFT V13.12 v0.2

This map is a navigation aid, not a new derivation. Numerical authority remains the nested C17G19 freeze pack.

| V13.12 claim family | Primary frozen authority inside C17G19 pack | Notes |
|---|---|---|
| Isolated maintained structure / frozen representative | `core/IEMM_C17G15p1_Good_Enough_Isolated_Electron_V1_Structure_Freeze.md`; `core/SFT_ELECTRON_V1_STRUCTURE_GOOD_ENOUGH_FROZEN.npz` | Structure frozen before readout/stability claims. |
| Maintained-dynamics stability | `core/IEMM_C17G16_Final_Stability_Audit_v1_0.md` | Scoped V1 stability only; arbitrary fully nonlinear time-dependent stability remains open. |
| Clock, rest momentum, source normalization, local closure gravity, spin/readout ledger | `core/IEMM_C17G17_Frozen_State_Physical_Readout_Ledger_v1_0.md` | Read from the same frozen SHA with no retuning. |
| Alpha ancestry and no-retuning consistency | `provenance/IEMM_C17G18_One_State_Consistency_No_Retuning_Audit_v1_0.md`; `core/C17G18_ALPHA_*` JSON files | Alpha is exposed as external EM/interface normalization, not an Electron-V1 prediction. |
| Route R/Z retyping | `provenance/C17G14_ROUTE_LIVE_RZ_GATE.md` | R/Z retained as reference embedding/scaffold, not physical predictions. |
| Curved charged Maxwell lineage | `provenance/IEMM_C17G9_*`; `provenance/IEMM_C17G10_*`; `provenance/IEMM_C17G11_*` | Preserves the charged hot-swap/common-descent ancestry and claim boundaries. |
| Final parameter/interface ledger and freeze boundary | `final/IEMM_C17G19_Final_SFT_Electron_V1_Freeze_v1_0.md`; `final/C17G19_FINAL_STATUS_LEDGER.csv`; `final/CURRENT_RESULT_C17G19.json` | Final controlling maintained-electron V1 ruling. |
| Fine-structure-constant companion context | `companions/SFT_Alpha_137_Pack.zip` in this wrapper | Context only. The Alpha-137 program explicitly does not derive alpha and is not used to rescue the electron freeze. |

## Figure status

The PNGs in `figures/` are presentation assets used by the public paper. They do not supersede the frozen numerical tables or JSON receipts. Where a figure visualizes a numerical result, the underlying frozen artifact above is the authority.
