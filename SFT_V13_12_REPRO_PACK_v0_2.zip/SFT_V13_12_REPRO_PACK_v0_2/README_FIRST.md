# SFT V13.12 — The Maintained Electron
## Reproduction / provenance pack v0.2

This package accompanies **SFT V13.12 — The Maintained Electron**, public draft v0.2.

The purpose of this wrapper is deliberately narrow: it binds the public-facing paper to the frozen numerical electron and exposes the paper's presentation assets and companion context without confusing them with the numerical source of truth.

## Source-of-truth hierarchy

1. **Frozen numerical authority:** `frozen_numerical_authority/SFT_IEMM_C17G19_FULL_FREEZE_PACK.zip`
2. **Public presentation:** the PDF/DOCX in `paper/`
3. **Publication figures:** `figures/`
4. **Companion context only:** `companions/SFT_Alpha_137_Pack.zip`

If prose in the public paper and a frozen numerical artifact ever disagree, the frozen C17G19 artifact controls.

## Canonical frozen electron

SHA-256 of the frozen numerical state:

`ba57e94177dae9f6ff2b734ae25caa05105b7aa7d9636e39403022843f1dd6dd`

The state inside the nested C17G19 pack was re-hashed while building this wrapper and matches that value exactly. No numerical electron state was modified in preparing V13.12.

## What this pack reproduces

This package supports reproduction/audit of the claims actually made by V13.12: the frozen maintained structure, its scoped stability result, one-state readout ledger, alpha-ancestry ablation, parameter/interface classification, and public claim boundary.

It does **not** claim to contain every historical exploratory script ever used during the C17 program. Historical negative controls and development archaeology live in the broader SFT archive. The nested C17G19 freeze pack is the preservation-grade authority for the final V1 electron.

## Quick verification

From the root of this extracted package:

```bash
sha256sum -c repro/SHA256SUMS.txt
```

Then inspect `repro/CLAIM_TO_ARTIFACT_MAP.md` before using any number from the paper as an independent result.

## Narrative companion

`What the Particle Remembers` is intentionally **not included in v0.2 of this technical repro pack**. Its draft is being claim-firewalled against V13.12 first; once sealed it should ship as a clearly labeled narrative companion, not as numerical authority.
