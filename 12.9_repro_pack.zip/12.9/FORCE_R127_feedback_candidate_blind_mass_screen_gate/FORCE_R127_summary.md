# FORCE_R127_feedback_candidate_blind_mass_screen_gate Summary

**Verdict:** FEEDBACK CANDIDATE BLIND MASS-RATIO SCREEN PASS / SCREEN HITS REPORTED, FULL MASS LAW NOT CLOSED
**Freeze ID:** `SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM`

## Interpretation

R127 freezes R126 radius/depth feedback candidate values first, then performs a blind charged-fermion pairwise mass-ratio screen.
It does not fit, retune, map rho modes to particles, or select a final physical mass law.

## Top matches

- `feedback_finite_lens_saturating_R126_primary` | 3/4 vs 5/4 | F=19.9945 | down_quark vs strange_quark | M=20 | err=0.02737% | same_sector=True | lepton_lepton=False | quark_quark=True
- `feedback_finite_lens_saturating_R126_raw_scale` | 3/4 vs 5/4 | F=19.9945 | down_quark vs strange_quark | M=20 | err=0.02737% | same_sector=True | lepton_lepton=False | quark_quark=True
- `feedback_R125_density_depth_like_dynamic` | 3/4 vs 3/2 | F=13.6013 | strange_quark vs charm_quark | M=13.5974 | err=0.02856% | same_sector=True | lepton_lepton=False | quark_quark=True
- `feedback_R125_density_depth_like_dynamic` | 1 vs 2 | F=44.7354 | strange_quark vs bottom_quark | M=44.7537 | err=0.04103% | same_sector=True | lepton_lepton=False | quark_quark=True
- `feedback_finite_lens_saturating_R126_primary` | 5/4 vs 2 | F=136.284 | charm_quark vs top_quark | M=136.031 | err=0.1856% | same_sector=True | lepton_lepton=False | quark_quark=True
- `feedback_finite_lens_saturating_R126_raw_scale` | 5/4 vs 2 | F=136.284 | charm_quark vs top_quark | M=136.031 | err=0.1856% | same_sector=True | lepton_lepton=False | quark_quark=True
- `feedback_finite_lens_saturating_R126_primary` | 5/4 vs 5/3 | F=18.966 | tau vs strange_quark | M=19.0242 | err=0.3059% | same_sector=False | lepton_lepton=False | quark_quark=False
- `feedback_finite_lens_saturating_R126_raw_scale` | 5/4 vs 5/3 | F=18.966 | tau vs strange_quark | M=19.0242 | err=0.3059% | same_sector=False | lepton_lepton=False | quark_quark=False
- `feedback_finite_lens_saturating_R126_raw_scale` | 3/4 vs 5/3 | F=379.216 | tau vs down_quark | M=380.484 | err=0.3332% | same_sector=False | lepton_lepton=False | quark_quark=False
- `feedback_finite_lens_saturating_R126_primary` | 3/4 vs 5/3 | F=379.216 | tau vs down_quark | M=380.484 | err=0.3332% | same_sector=False | lepton_lepton=False | quark_quark=False
- `feedback_sqrt_saturating_eta05_R126_dynamic` | 1/2 vs 1 | F=22.5349 | muon vs down_quark | M=22.6249 | err=0.3978% | same_sector=False | lepton_lepton=False | quark_quark=False
- `feedback_sqrt_saturating_eta05_R126_dynamic` | 1/2 vs 4/3 | F=207.644 | electron vs muon | M=206.768 | err=0.4234% | same_sector=True | lepton_lepton=True | quark_quark=False

## Threshold summary

- `feedback_R125_density_depth_like_dynamic` | dyn=269.251 | best_err=0.02856% | hits<=1%=5 | hits<=5%=20 | same_sector<=5%=11
- `feedback_sqrt_saturating_eta05_R126_dynamic` | dyn=16504.8 | best_err=0.3978% | hits<=1%=3 | hits<=5%=10 | same_sector<=5%=4
- `feedback_log_saturating_R126_dynamic` | dyn=17293.6 | best_err=1.105% | hits<=1%=0 | hits<=5%=11 | same_sector<=5%=4
- `feedback_finite_lens_saturating_R126_primary` | dyn=17999.8 | best_err=0.02737% | hits<=1%=6 | hits<=5%=10 | same_sector<=5%=3
- `feedback_finite_lens_saturating_R126_raw_scale` | dyn=17999.8 | best_err=0.02737% | hits<=1%=6 | hits<=5%=10 | same_sector<=5%=3
