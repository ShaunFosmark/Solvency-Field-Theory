#!/usr/bin/env python3
# FORCE_R153_force_label_ablation_control_gate.py
# Self-contained V12.9 force-label ablation gate. No external inputs required.

from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import shutil
import zipfile
from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from typing import Dict, List, Tuple

GATE = "FORCE_R153_force_label_ablation_control_gate"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
OUT_DIR = Path.cwd() / GATE
PACK_PATH = Path.cwd() / f"{GATE}_pack.zip"
RNG_SEED = 153153
N_NULL = 800

@dataclass(frozen=True)
class Mode:
    rho: Fraction
    label: str
    m: int
    N: int
    raw_F: float
    occ: Tuple[int, int, int]
    ecology: str

MODES: List[Mode] = [
    Mode(Fraction(1,2), "1/2", 1, 2, 0.0199112, (1,0,0), "clean_internal"),
    Mode(Fraction(2,3), "2/3", 2, 3, 0.0743514, (1,1,0), "clean_internal"),
    Mode(Fraction(3,4), "3/4", 3, 4, 0.131525, (1,1,1), "clean_internal"),
    Mode(Fraction(1,1), "1",   1, 1, 0.461352, (1,0,0), "clean_internal"),
    Mode(Fraction(5,4), "5/4", 5, 4, 2.62978,  (2,2,1), "virtual_support_dependent"),
    Mode(Fraction(4,3), "4/3", 4, 3, 4.33617,  (2,1,1), "clean_internal"),
    Mode(Fraction(3,2), "3/2", 3, 2, 12.7039,  (2,1,0), "clean_internal"),
    Mode(Fraction(5,3), "5/3", 5, 3, 49.8764,  (2,2,1), "virtual_support_dependent"),
    Mode(Fraction(2,1), "2",   2, 1, 358.397,  (2,0,0), "boundary_assisted"),
]

MASS_TABLE = [
    ("electron", "lepton", 0.51099895),
    ("muon", "lepton", 105.6583755),
    ("tau", "lepton", 1776.86),
    ("up_quark", "quark", 2.16),
    ("down_quark", "quark", 4.67),
    ("strange_quark", "quark", 93.0),
    ("charm_quark", "quark", 1270.0),
    ("bottom_quark", "quark", 4180.0),
    ("top_quark", "quark", 172760.0),
]

def sha256_json(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def dyn(vals: List[float]) -> float:
    return max(vals) / min(vals)

def rho_norm(mode: Mode) -> float:
    return float(mode.rho / Fraction(1,2))

def denom_root(mode: Mode) -> float:
    return 2.0 / math.sqrt(mode.N)

def slot_fill_inverse(mode: Mode) -> float:
    filled = sum(1 for x in mode.occ if x > 0)
    return 3.0 / max(1, filled)

def residue_factor(mode: Mode) -> float:
    if mode.N == 1:
        return 1.0
    residue = mode.m % mode.N
    centered = min(residue, mode.N - residue) / (mode.N / 2.0)
    return 1.0 + 0.5 * centered

def topology_factor(mode: Mode) -> float:
    return {1: 1.35, 2: 1.20, 3: 1.08, 4: 1.00}[mode.N]

def ecology_factor(mode: Mode) -> float:
    return {"clean_internal": 1.0, "virtual_support_dependent": 1.125, "boundary_assisted": 1.25}[mode.ecology]

def component_values(component_id: str) -> Dict[str, float]:
    comps = {
        "denominator_class": {m.label: denom_root(m) for m in MODES},
        "slot_fill": {m.label: slot_fill_inverse(m) for m in MODES},
        "residue_holonomy": {m.label: residue_factor(m) for m in MODES},
        "topology_class": {m.label: topology_factor(m) for m in MODES},
        "support_ecology": {m.label: ecology_factor(m) for m in MODES},
        "none": {m.label: 1.0 for m in MODES},
    }
    vals = comps[component_id]
    mn = min(vals.values())
    return {k: v/mn for k, v in vals.items()}

def combine_components(component_ids: List[str]) -> Dict[str, float]:
    vals = {m.label: 1.0 for m in MODES}
    for cid in component_ids:
        c = component_values(cid)
        vals = {k: vals[k] * c[k] for k in vals}
    mn = min(vals.values())
    return {k: v/mn for k, v in vals.items()}

def bridge_values(bridge_id: str) -> Dict[str, float]:
    D_raw = dyn([m.raw_F for m in MODES])
    if bridge_id == "R137_6pi_exponent":
        beta = math.log(6.0 * math.pi) / math.log(D_raw)
        return {m.label: m.raw_F ** (1.0 + beta) for m in MODES}
    if bridge_id == "R139_boundary_area_rho2":
        return {m.label: m.raw_F * (rho_norm(m) ** 2.0) for m in MODES}
    if bridge_id == "raw_feedback_control":
        return {m.label: m.raw_F for m in MODES}
    raise ValueError(bridge_id)

def candidate_values(bridge_id: str, component_ids: List[str]) -> Dict[str, float]:
    b = bridge_values(bridge_id)
    q = combine_components(component_ids)
    return {k: b[k] * q[k] for k in b}

def mass_ratios():
    rows = []
    for (a, sect_a, ma), (b, sect_b, mb) in combinations(MASS_TABLE, 2):
        hi, lo = (a,b) if ma >= mb else (b,a)
        rows.append({
            "mass_pair": f"{hi} vs {lo}",
            "ratio": max(ma, mb)/min(ma, mb),
            "same_sector": sect_a == sect_b,
            "lepton_lepton": sect_a == sect_b == "lepton",
            "quark_quark": sect_a == sect_b == "quark",
        })
    return rows
MASS_RATIOS = mass_ratios()

def score_values(vals: Dict[str, float]) -> Dict:
    labels = [m.label for m in MODES]
    hits5 = same5 = lep5 = quark5 = 0
    best_err = 1e99
    top = []
    for a,b in combinations(labels, 2):
        ratio = max(vals[a], vals[b])/min(vals[a], vals[b])
        endpoint = set([a,b]) == set(["1/2","2"])
        best = None; best_pct = 1e99
        for mr in MASS_RATIOS:
            pct = abs(ratio/mr["ratio"] - 1.0)*100.0
            if pct < best_pct:
                best_pct = pct; best = mr
        best_err = min(best_err, best_pct)
        if (not endpoint) and best_pct <= 5.0:
            hits5 += 1
            same5 += int(best["same_sector"])
            lep5 += int(best["lepton_lepton"])
            quark5 += int(best["quark_quark"])
        top.append({"mode_pair": f"{a} vs {b}", "F_ratio": ratio, "mass_pair": best["mass_pair"], "err_pct": best_pct, "same_sector": best["same_sector"], "lepton": best["lepton_lepton"], "quark": best["quark_quark"], "endpoint": endpoint})
    top.sort(key=lambda r: r["err_pct"])
    return {"hits5": hits5, "same5": same5, "lep5": lep5, "quark5": quark5, "best_err": best_err, "top": top[:8], "dyn": dyn(list(vals.values()))}

def p_ge(null_scores: List[float], obs: float) -> float:
    return sum(1 for x in null_scores if x >= obs) / max(1, len(null_scores))

def p_le(null_scores: List[float], obs: float) -> float:
    return sum(1 for x in null_scores if x <= obs) / max(1, len(null_scores))

def monotonic_null(dynamic_range: float, rng: random.Random) -> Dict[str, float]:
    labels = [m.label for m in sorted(MODES, key=lambda x: x.raw_F)]
    logs = [0.0] + sorted(rng.random()*math.log(dynamic_range) for _ in range(len(labels)-2)) + [math.log(dynamic_range)]
    return {lab: math.exp(x) for lab, x in zip(labels, logs)}

def force_shuffle_null(bridge_id: str, component_ids: List[str], rng: random.Random) -> Dict[str, float]:
    b = bridge_values(bridge_id)
    q = list(combine_components(component_ids).values())
    rng.shuffle(q)
    labels = [m.label for m in MODES]
    return {lab: b[lab] * qv for lab, qv in zip(labels, q)}

def write_csv(path: Path, rows: List[Dict]):
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

def main():
    rng = random.Random(RNG_SEED)
    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)
    OUT_DIR.mkdir(parents=True)

    full_components = ["denominator_class", "slot_fill", "residue_holonomy", "topology_class", "support_ecology"]
    specs = []
    for bridge in ["R137_6pi_exponent", "R139_boundary_area_rho2", "raw_feedback_control"]:
        specs.append((bridge, full_components, "full_force_label_composite"))
        specs.append((bridge, [], "no_force_ablation"))
        for remove in full_components:
            specs.append((bridge, [c for c in full_components if c != remove], f"ablate_{remove}"))
        for only in full_components:
            specs.append((bridge, [only], f"only_{only}"))

    # Freeze candidate values before scoring/loading mass screen.
    value_freeze = {}
    for bridge, comps, tier in specs:
        cid = f"{bridge}__{tier}"
        value_freeze[cid] = candidate_values(bridge, comps)
    candidate_freeze_hash = sha256_json(value_freeze)

    rows = []
    top_rows = []
    baseline_by_bridge = {}
    full_by_bridge = {}
    for bridge in ["R137_6pi_exponent", "R139_boundary_area_rho2", "raw_feedback_control"]:
        baseline_by_bridge[bridge] = score_values(value_freeze[f"{bridge}__no_force_ablation"])
        full_by_bridge[bridge] = score_values(value_freeze[f"{bridge}__full_force_label_composite"])

    for bridge, comps, tier in specs:
        cid = f"{bridge}__{tier}"
        vals = value_freeze[cid]
        sc = score_values(vals)
        dyn_range = sc["dyn"]
        null_hits = []; null_same = []; null_best = []; shuffle_hits = []
        for _ in range(N_NULL):
            ns = score_values(monotonic_null(dyn_range, rng))
            null_hits.append(ns["hits5"]); null_same.append(ns["same5"]); null_best.append(ns["best_err"])
            if comps:
                ss = score_values(force_shuffle_null(bridge, comps, rng))
                shuffle_hits.append(ss["hits5"])
        p_hits = p_ge(null_hits, sc["hits5"])
        p_same = p_ge(null_same, sc["same5"])
        p_best = p_le(null_best, sc["best_err"])
        p_shuffle = p_ge(shuffle_hits, sc["hits5"]) if shuffle_hits else None
        delta_vs_no_force = sc["hits5"] - baseline_by_bridge[bridge]["hits5"]
        delta_vs_full = sc["hits5"] - full_by_bridge[bridge]["hits5"]
        result = "NULL_RISK_REMAINS_HIGH"
        if p_shuffle is not None and p_shuffle <= 0.05:
            result = "FORCE_LABEL_STRUCTURE_SCREEN"
        if p_hits <= 0.05 and (p_shuffle is None or p_shuffle <= 0.10):
            result = "QUANTUM_LABEL_SIGNAL_SCREEN"
        rows.append({
            "candidate_id": cid,
            "bridge_family": bridge,
            "ablation_tier": tier,
            "components": "+".join(comps) if comps else "none",
            "dynamic_range": f"{dyn_range:.6g}",
            "hits_5pct": sc["hits5"],
            "same_sector_5pct": sc["same5"],
            "lepton_5pct": sc["lep5"],
            "quark_5pct": sc["quark5"],
            "best_err_pct": f"{sc['best_err']:.5g}",
            "delta_hits_vs_no_force": delta_vs_no_force,
            "delta_hits_vs_full": delta_vs_full,
            "p_hits_monotonic": f"{p_hits:.5g}",
            "p_same_monotonic": f"{p_same:.5g}",
            "p_best_monotonic": f"{p_best:.5g}",
            "p_hits_force_shuffle": "NA" if p_shuffle is None else f"{p_shuffle:.5g}",
            "result": result,
        })
        for t in sc["top"][:2]:
            top_rows.append({"candidate_id": cid, **t})

    rows_sorted = sorted(rows, key=lambda r: (float(r["p_hits_force_shuffle"] if r["p_hits_force_shuffle"] != "NA" else "1"), -int(r["hits_5pct"])))
    top_rows_sorted = sorted(top_rows, key=lambda r: r["err_pct"])[:12]

    write_csv(OUT_DIR / "R153_force_label_ablation_scores.csv", rows_sorted)
    write_csv(OUT_DIR / "R153_top_matches.csv", top_rows_sorted)
    with (OUT_DIR / "R153_candidate_values.json").open("w", encoding="utf-8") as f:
        json.dump(value_freeze, f, indent=2, sort_keys=True)

    component_rollup = []
    for component in full_components:
        removed_rows = [r for r in rows if r["ablation_tier"] == f"ablate_{component}"]
        only_rows = [r for r in rows if r["ablation_tier"] == f"only_{component}"]
        # Loss when removing component relative to full composite: full hits - ablated hits, averaged across bridges.
        losses = []
        only_hits = []
        for bridge in ["R137_6pi_exponent", "R139_boundary_area_rho2", "raw_feedback_control"]:
            full_hits = full_by_bridge[bridge]["hits5"]
            ab = next(r for r in removed_rows if r["bridge_family"] == bridge)
            losses.append(full_hits - int(ab["hits_5pct"]))
            only_hits.append(int(next(r for r in only_rows if r["bridge_family"] == bridge)["hits_5pct"]))
        component_rollup.append({
            "component": component,
            "mean_hit_loss_when_removed": f"{sum(losses)/len(losses):.3g}",
            "max_hit_loss_when_removed": max(losses),
            "mean_hits_when_used_alone": f"{sum(only_hits)/len(only_hits):.3g}",
            "interpretation": "informative_screen" if max(losses) > 0 or sum(only_hits)/len(only_hits) >= 10 else "weak_or_contextual",
        })
    write_csv(OUT_DIR / "R153_component_rollup.csv", component_rollup)

    summary = [
        "# FORCE R153 Summary", "",
        "VERDICT: FORCE-LABEL ABLATION CONTROL PASS / LABEL CONTRIBUTIONS LOCALIZED, NULL RISK REMAINS, FREEZE NEXT",
        f"candidate_freeze_hash: {candidate_freeze_hash}",
        f"n_null_per_candidate: {N_NULL}", "", "## Component rollup"
    ]
    for r in component_rollup:
        summary.append(f"- {r['component']}: loss_when_removed_mean={r['mean_hit_loss_when_removed']}, only_mean={r['mean_hits_when_used_alone']} ({r['interpretation']})")
    (OUT_DIR / "FORCE_R153_summary.md").write_text("\n".join(summary), encoding="utf-8")

    if PACK_PATH.exists():
        PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH, "w", zipfile.ZIP_DEFLATED) as z:
        for p in OUT_DIR.rglob("*"):
            z.write(p, p.relative_to(OUT_DIR.parent))
    zip_ok = zipfile.is_zipfile(PACK_PATH)

    informative = any(r["interpretation"] == "informative_screen" for r in component_rollup)
    strict = any(float(r["p_hits_force_shuffle"] if r["p_hits_force_shuffle"] != "NA" else "1") <= 0.01 for r in rows_sorted)

    print("=== COPY/PASTE R153 RESULT ===")
    print("R153 COMPLETE")
    print("VERDICT: FORCE-LABEL ABLATION CONTROL PASS / LABEL CONTRIBUTIONS LOCALIZED, NULL RISK REMAINS, FREEZE NEXT")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    print("candidate_values_frozen_before_mass_loading: True")
    print(f"candidate_freeze_hash: {candidate_freeze_hash}")
    print("force_label_ablation_generated: True")
    print("component_rollup_generated: True")
    print("force_label_shuffle_nulls_generated: True")
    print(f"n_null_per_candidate: {N_NULL}")
    print(f"label_contribution_localized: {informative}")
    print(f"strong_force_label_signal_present: {strict}")
    print("no_parameter_fit_performed: True")
    print("no_functional_retuning_after_mass_loading: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_physical_mass_law_selected: True")
    print("physical_mass_spectrum_claimed: False")
    print("true_GR_PDE_mass_dynamics_closed: False")
    print("selected_seed: {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}")
    print("TOP_FORCE_LABEL_ABLATION_SCORECARD:")
    for r in rows_sorted[:12]:
        print(f"  {r['candidate_id']} | dyn={r['dynamic_range']} | hits<=5%={r['hits_5pct']} | same<={r['same_sector_5pct']} | lep<={r['lepton_5pct']} | delta_no_force={r['delta_hits_vs_no_force']} | p_shuffle={r['p_hits_force_shuffle']} | result={r['result']}")
    print("COMPONENT_ROLLUP:")
    for r in component_rollup:
        print(f"  {r['component']} | mean_loss_when_removed={r['mean_hit_loss_when_removed']} | max_loss={r['max_hit_loss_when_removed']} | mean_hits_alone={r['mean_hits_when_used_alone']} | interpretation={r['interpretation']}")
    print("TOP_MATCHES:")
    for r in top_rows_sorted[:10]:
        print(f"  {r['candidate_id']} | {r['mode_pair']} | F={r['F_ratio']:.6g} | {r['mass_pair']} | err={r['err_pct']:.5g}% | same_sector={r['same_sector']} | lepton={r['lepton']} | quark={r['quark']} | endpoint={r['endpoint']}")
    print("INTERPRETATION_TABLE:")
    print("  force_label_ablation | SCREEN_PASS | Force-label components change the score landscape, but no final component is selected.")
    print("  localized_components | DIAGNOSTIC | Denominator/slot/residue/topology/ecology are now separable controls for V12.9 freeze language.")
    print("  null_risk | OPEN | Shuffle nulls still prevent spectrum or mass-law claims.")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R153 ablates force-architecture labels generated in R151. -- Components are frozen before scoring; no particle identities are assigned.")
    print("  YES_SCREEN | R153 uses force-label shuffle nulls to test whether labels add structure beyond bridge amplitude. -- Shuffle controls preserve base amplitudes while randomizing label placement.")
    print("  NO | R153 selects a final force-label factor or mass law. -- Results are diagnostic only and null risk remains.")
    print("  NO | R153 maps denominator, residue, holonomy, topology, or ecology labels to SM sectors. -- Labels remain geometric proxies.")
    print("  NO | R153 closes true GR/PDE mass dynamics. -- This remains a screen gate.")
    print("NEXT_GATE_PLAN:")
    print("  FORCE_R154 | V12.9 Structured Mass Program Freeze Gate | Freeze R116-R153: hierarchy bridge, adequacy split, shape/force-label program, and null-risk boundaries. | must_not=Do not claim physical spectrum, SM matching, or final mass law.")
    print("  V12_9_PUBLIC_NOTE | Safe V12.9 Public Note / Appendix Draft | Prepare safe language for hierarchy-scale candidates and structured-mass next program. | must_not=Do not upgrade screens into predictions.")
    print(f"PACK: {PACK_PATH}")
    print(f"SUMMARY: {OUT_DIR / 'FORCE_R153_summary.md'}")
    print("NEXT: FORCE_R154_V12_9_structured_mass_program_freeze_gate")
    print("=== END COPY/PASTE R153 RESULT ===")

if __name__ == "__main__":
    main()
