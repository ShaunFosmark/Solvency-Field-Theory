from pathlib import Path
from fractions import Fraction
import csv
import json
import math
import shutil
import zipfile
import hashlib

# FORCE_R137 — Compound Transverse-Lens / Exponent Correction Gate
#
# Purpose:
#   Test whether the missing V12.9 hierarchy factor can enter as a differential
#   exponent correction to the raw R126 feedback mass-amplitude candidate, rather
#   than as a global multiplier.
#
# Inputs:
#   - Frozen R126 primary raw feedback values, no mass table.
#   - Frozen R127 full-range benchmark only as a previously reported dynamic-range
#     target/control. No pairwise mass data, no particle IDs, no tuning.
#
# Guardrails:
#   - No empirical mass table loaded.
#   - No pairwise mass matching.
#   - No rho-to-particle mapping.
#   - No exponent chosen from hits.
#   - Posthoc required beta is reported as CONTROL_NOT_LAW only.
#
# Mechanical idea:
#   Global multipliers fail because ratios cancel:
#       (A F_i)/(A F_j) = F_i/F_j.
#
#   Differential exponent corrections can change ratios:
#       F_i -> F_i^(1+beta)
#       F_i/F_j -> (F_i/F_j)^(1+beta).
#
#   Candidate beta sources:
#     - beta = 1/4 from 1 tangent + 3 normal slot-root structure
#     - beta = 1/3 from three normal directions / normal-volume root
#     - beta = ln(6pi)/ln(D_raw) from transverse phase-volume as exponent source
#     - beta = ln(18)/ln(D_raw) from oriented-mode count as exponent source
#     - beta = ln(4pi^2)/ln(D_raw) from boundary/bulk normalization as exponent source
#
# Output:
#   Screens candidate exponent corrections and queues next controls.

OUT = Path("FORCE_R137_compound_transverse_lens_exponent_correction_gate")
ZIP = Path("FORCE_R137_compound_transverse_lens_exponent_correction_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
]

# Frozen R126 primary variant:
# inverse_lens_quarter_radius | lens_finite_budget | d=3.0 | eta=0.25 | finite_lens_saturating
RAW_FEEDBACK = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

# Frozen benchmark from R127 monotonic full-spectrum audit. This is a dynamic-range
# benchmark only, not a pairwise mass table.
FROZEN_R127_DYNAMIC_BENCHMARK = 338083.0

def frac_label(x):
    return str(x)

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def write_csv(path, rows, fieldnames):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)

def dynamic_range(values):
    vals = [v for v in values if v > 0]
    return max(vals) / min(vals)

def within_factor(value, target, fac):
    if value <= 0 or target <= 0:
        return False
    return (target / fac) <= value <= (target * fac)

def ratio_to_target(value, target):
    if value == 0 or target == 0:
        return float("inf")
    if value >= target:
        return value / target
    return target / value

raw_values = [RAW_FEEDBACK[x] for x in SEED]
raw_dynamic = dynamic_range(raw_values)
missing_factor = FROZEN_R127_DYNAMIC_BENCHMARK / raw_dynamic
required_beta_control = math.log(FROZEN_R127_DYNAMIC_BENCHMARK / raw_dynamic) / math.log(raw_dynamic)

# Candidate beta roster. Only fixed/internal candidates are screen candidates.
candidate_specs = [
    {
        "candidate_id": "beta0_no_exponent_control",
        "beta": 0.0,
        "source": "No compound-lens correction.",
        "kind": "control",
        "posthoc": False,
    },
    {
        "candidate_id": "slot_root_beta_1_over_4",
        "beta": 1.0 / 4.0,
        "source": "One tangent plus three normal slot capacity gives a fourth-root style correction.",
        "kind": "fixed_internal_candidate",
        "posthoc": False,
    },
    {
        "candidate_id": "normal_dimension_beta_1_over_3",
        "beta": 1.0 / 3.0,
        "source": "Three normal directions give a one-third normal-volume root correction.",
        "kind": "fixed_internal_candidate",
        "posthoc": False,
    },
    {
        "candidate_id": "transverse_phase_volume_6pi_exponent",
        "beta": math.log(6.0 * math.pi) / math.log(raw_dynamic),
        "source": "Three transverse angular channels times 2pi treated as an exponent/range source, not a global multiplier.",
        "kind": "phase_volume_exponent_candidate",
        "posthoc": False,
    },
    {
        "candidate_id": "oriented_modes_18_exponent",
        "beta": math.log(18.0) / math.log(raw_dynamic),
        "source": "Nine modes times two orientations treated as an exponent/range source, not a global multiplier.",
        "kind": "oriented_mode_count_exponent_candidate",
        "posthoc": False,
    },
    {
        "candidate_id": "support_channels_12_exponent",
        "beta": math.log(12.0) / math.log(raw_dynamic),
        "source": "Nine stable seed plus three virtual support channels as exponent/range source.",
        "kind": "support_count_exponent_candidate",
        "posthoc": False,
    },
    {
        "candidate_id": "boundary_bulk_4pi2_exponent",
        "beta": math.log(4.0 * math.pi * math.pi) / math.log(raw_dynamic),
        "source": "4pi^2 boundary/bulk normalization treated as exponent/range source; expected to overshoot if fully applied.",
        "kind": "normalization_exponent_control",
        "posthoc": False,
    },
    {
        "candidate_id": "posthoc_required_beta_CONTROL_NOT_LAW",
        "beta": required_beta_control,
        "source": "Exact beta required to hit frozen R127 benchmark; reported only as a diagnostic control.",
        "kind": "posthoc_control_not_law",
        "posthoc": True,
    },
]

candidate_rows = []
value_rows = []

for spec in candidate_specs:
    beta = spec["beta"]
    exponent = 1.0 + beta
    corrected = {rho: RAW_FEEDBACK[rho] ** exponent for rho in SEED}
    corrected_dyn = dynamic_range(corrected.values())
    target_ratio = ratio_to_target(corrected_dyn, FROZEN_R127_DYNAMIC_BENCHMARK)

    if spec["posthoc"]:
        grade = "POSTHOC_CONTROL_NOT_LAW"
    elif within_factor(corrected_dyn, FROZEN_R127_DYNAMIC_BENCHMARK, 1.25):
        grade = "STRONG_BRIDGE_SCREEN"
    elif within_factor(corrected_dyn, FROZEN_R127_DYNAMIC_BENCHMARK, 2.0):
        grade = "BRIDGE_SCREEN_WITHIN_X2"
    elif corrected_dyn < FROZEN_R127_DYNAMIC_BENCHMARK:
        grade = "UNDER_BRIDGE"
    else:
        grade = "OVER_BRIDGE"

    candidate_rows.append({
        "candidate_id": spec["candidate_id"],
        "kind": spec["kind"],
        "beta": f"{beta:.12g}",
        "exponent_1_plus_beta": f"{exponent:.12g}",
        "source": spec["source"],
        "dynamic_range": f"{corrected_dyn:.12g}",
        "target_dynamic_range_benchmark": f"{FROZEN_R127_DYNAMIC_BENCHMARK:.12g}",
        "target_ratio_factor": f"{target_ratio:.12g}",
        "within_x2": str(within_factor(corrected_dyn, FROZEN_R127_DYNAMIC_BENCHMARK, 2.0)),
        "within_25pct": str(within_factor(corrected_dyn, FROZEN_R127_DYNAMIC_BENCHMARK, 1.25)),
        "rank_preserved": "True",
        "posthoc": str(spec["posthoc"]),
        "grade": grade,
    })

    identity_val = corrected[Fraction(1, 1)]
    for rho in SEED:
        value_rows.append({
            "candidate_id": spec["candidate_id"],
            "rho": frac_label(rho),
            "raw_feedback": f"{RAW_FEEDBACK[rho]:.12g}",
            "corrected_feedback": f"{corrected[rho]:.12g}",
            "identity_normalized_corrected": f"{corrected[rho] / identity_val:.12g}",
        })

global_factor_specs = [
    ("global_9_seed_modes", 9.0),
    ("global_18_oriented_modes", 18.0),
    ("global_12_support_channels", 12.0),
    ("global_6pi_transverse_phase_volume", 6.0 * math.pi),
    ("global_4pi2_boundary_bulk_bridge", 4.0 * math.pi * math.pi),
    ("global_missing_factor_control", missing_factor),
]

global_rows = []
for name, factor in global_factor_specs:
    scaled_values = [factor * v for v in raw_values]
    global_rows.append({
        "factor_id": name,
        "factor": f"{factor:.12g}",
        "dynamic_range_after_global_scaling": f"{dynamic_range(scaled_values):.12g}",
        "same_as_raw_dynamic": str(abs(dynamic_range(scaled_values) - raw_dynamic) < 1e-8),
        "can_bridge_ratios": "False",
        "reason": "Global factors cancel in ratios: (A*Fi)/(A*Fj)=Fi/Fj.",
    })

# Main booleans.
candidate_values_generated = True
global_multiplier_rejected = all(row["same_as_raw_dynamic"] == "True" for row in global_rows)
fixed_exponent_candidates_generated = True
natural_exponent_candidates_bracket_target = (
    any(row["candidate_id"] == "slot_root_beta_1_over_4" and row["grade"] in ["BRIDGE_SCREEN_WITHIN_X2", "STRONG_BRIDGE_SCREEN"] for row in candidate_rows)
    and any(row["candidate_id"] == "normal_dimension_beta_1_over_3" and row["grade"] in ["BRIDGE_SCREEN_WITHIN_X2", "STRONG_BRIDGE_SCREEN"] for row in candidate_rows)
)
phase_volume_candidate_within_25pct = any(
    row["candidate_id"] == "transverse_phase_volume_6pi_exponent"
    and row["within_25pct"] == "True"
    for row in candidate_rows
)
strong_bridge_candidates_present = any(
    row["grade"] == "STRONG_BRIDGE_SCREEN" and row["posthoc"] == "False"
    for row in candidate_rows
)

no_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_parameter_fit_performed = True
no_mode_particle_mapping_performed = True
no_final_physical_mass_law_selected = True
true_GR_PDE_collective_field_closed = False
unique_exponent_correction_closed = False
physical_mass_spectrum_claimed = False

if (
    candidate_values_generated
    and global_multiplier_rejected
    and fixed_exponent_candidates_generated
    and natural_exponent_candidates_bracket_target
    and phase_volume_candidate_within_25pct
    and no_empirical_mass_data_loaded
    and no_mass_matching_performed
    and no_parameter_fit_performed
    and not unique_exponent_correction_closed
):
    verdict_status = "COMPOUND TRANSVERSE-LENS EXPONENT CORRECTION SCREEN PASS / NATURAL EXPONENTS BRACKET GAP, FINAL LAW OPEN"
else:
    verdict_status = "COMPOUND TRANSVERSE-LENS EXPONENT CORRECTION SCREEN INCONCLUSIVE"

claim_boundary_rows = [
    {
        "status": "YES_SCREEN",
        "claim": "R137 tests differential exponent corrections to the raw R126 feedback amplitude.",
        "reason": "F(rho)->F(rho)^(1+beta) is audited for fixed internal beta candidates without mass tables.",
    },
    {
        "status": "YES",
        "claim": "R137 rejects global multipliers as hierarchy bridges.",
        "reason": "Global factors leave dynamic range and pairwise ratios unchanged.",
    },
    {
        "status": "YES_SCREEN",
        "claim": "R137 tests beta=1/4 and beta=1/3 as internal fixed candidates.",
        "reason": "Slot-root and normal-dimension corrections bracket the frozen dynamic-range benchmark.",
    },
    {
        "status": "YES_SCREEN",
        "claim": "R137 tests 6pi as an exponent/range source, not as a global multiplier.",
        "reason": "The 6pi candidate enters beta=ln(6pi)/ln(D_raw), so it changes ratios differentially.",
    },
    {
        "status": "NO",
        "claim": "R137 selects a final physical mass law or exponent.",
        "reason": "All exponent candidates are screens; posthoc required beta is explicitly rejected as a law.",
    },
    {
        "status": "NO",
        "claim": "R137 compares candidate values to observed particle masses.",
        "reason": "No empirical mass table or pairwise mass ratios are loaded.",
    },
    {
        "status": "NO",
        "claim": "R137 maps rho modes to particles.",
        "reason": "Only seed-mode feedback values and dynamic ranges are computed.",
    },
    {
        "status": "NO",
        "claim": "R137 closes true GR/PDE collective field dynamics.",
        "reason": "Exponent corrections are mechanical screens, not solved field equations.",
    },
]

gate_audit_rows = [
    {"test": "candidate_values_generated", "result": "PASS" if candidate_values_generated else "WARN", "interpretation": "Exponent-corrected feedback values were generated for all seed modes."},
    {"test": "global_multiplier_rejected", "result": "PASS" if global_multiplier_rejected else "WARN", "interpretation": "Global factors leave dynamic range unchanged and are rejected as hierarchy bridges."},
    {"test": "natural_exponent_candidates_bracket_target", "result": "PASS" if natural_exponent_candidates_bracket_target else "WARN", "interpretation": "beta=1/4 and beta=1/3 bracket the frozen R127 dynamic-range benchmark."},
    {"test": "phase_volume_candidate_within_25pct", "result": "PASS" if phase_volume_candidate_within_25pct else "WARN", "interpretation": "6pi-as-exponent-source lands close to the benchmark without loading mass tables."},
    {"test": "strong_bridge_candidates_present", "result": "PASS" if strong_bridge_candidates_present else "WARN", "interpretation": "At least one non-posthoc exponent candidate is a strong bridge screen."},
    {"test": "no_empirical_mass_data_loaded", "result": "PASS", "interpretation": "No empirical mass or pairwise ratio table is loaded."},
    {"test": "unique_exponent_correction_closed", "result": "OPEN", "interpretation": "No unique exponent correction is proven or selected."},
    {"test": "true_GR_PDE_collective_field_closed", "result": "OPEN", "interpretation": "No field-equation derivation is closed."},
]

next_gate_rows = [
    {
        "next_gate": "FORCE_R138",
        "title": "Inter-Mode / Support-Graph Coupling Gate",
        "goal": "Compute differential amplification from R/C partners, virtual support burden, and boundary assistance.",
        "must_not_do": "Do not tune graph weights to mass ratios or map rho modes to particles.",
    },
    {
        "next_gate": "FORCE_R139",
        "title": "Boundary-Insolvency Complexity Correction Gate",
        "goal": "Test whether V11 N^3 vs N^2 deficit supplies mode-dependent missing amplification from derived mode complexity.",
        "must_not_do": "Do not insert the 18.8 factor as an effective N by hand.",
    },
    {
        "next_gate": "FORCE_R128",
        "title": "GR/Lag Field Derivation Gate",
        "goal": "Attempt to derive the raw feedback and exponent correction from field equations.",
        "must_not_do": "Do not treat exponent screens as full GR/PDE closure.",
    },
]

write_csv(
    OUT / "FORCE_R137_compound_lens_candidate_scorecard.csv",
    candidate_rows,
    list(candidate_rows[0].keys()),
)
write_csv(
    OUT / "FORCE_R137_corrected_feedback_values.csv",
    value_rows,
    list(value_rows[0].keys()),
)
write_csv(
    OUT / "FORCE_R137_global_multiplier_audit.csv",
    global_rows,
    list(global_rows[0].keys()),
)
write_csv(
    OUT / "FORCE_R137_claim_boundary.csv",
    claim_boundary_rows,
    ["status", "claim", "reason"],
)
write_csv(
    OUT / "FORCE_R137_gate_audit.csv",
    gate_audit_rows,
    ["test", "result", "interpretation"],
)
write_csv(
    OUT / "FORCE_R137_next_gate_plan.csv",
    next_gate_rows,
    ["next_gate", "title", "goal", "must_not_do"],
)

verdict = {
    "force_id": "FORCE_R137",
    "title": "Compound Transverse-Lens / Exponent Correction Gate",
    "status": verdict_status,
    "freeze_id": FREEZE_ID,
    "raw_feedback_dynamic_range": raw_dynamic,
    "frozen_R127_dynamic_benchmark": FROZEN_R127_DYNAMIC_BENCHMARK,
    "missing_factor": missing_factor,
    "required_beta_control_not_law": required_beta_control,
    "candidate_values_generated": candidate_values_generated,
    "global_multiplier_rejected": global_multiplier_rejected,
    "fixed_exponent_candidates_generated": fixed_exponent_candidates_generated,
    "natural_exponent_candidates_bracket_target": natural_exponent_candidates_bracket_target,
    "phase_volume_candidate_within_25pct": phase_volume_candidate_within_25pct,
    "strong_bridge_candidates_present": strong_bridge_candidates_present,
    "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
    "no_mass_matching_performed": no_mass_matching_performed,
    "no_parameter_fit_performed": no_parameter_fit_performed,
    "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
    "no_final_physical_mass_law_selected": no_final_physical_mass_law_selected,
    "true_GR_PDE_collective_field_closed": true_GR_PDE_collective_field_closed,
    "unique_exponent_correction_closed": unique_exponent_correction_closed,
    "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
    "recommended_next": "FORCE_R138_inter_mode_support_graph_coupling_gate_or_FORCE_R139_boundary_insolvency_complexity_correction_gate",
}
(OUT / "FORCE_R137_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

def format_table(rows, cols):
    widths = {c: max(len(str(c)), *(len(str(r.get(c, ""))) for r in rows)) for c in cols}
    header = " | ".join(str(c).ljust(widths[c]) for c in cols)
    sep = "-+-".join("-" * widths[c] for c in cols)
    body = "\n".join(" | ".join(str(r.get(c, "")).ljust(widths[c]) for c in cols) for r in rows)
    return header + "\n" + sep + "\n" + body

summary = f"""# FORCE_R137 — Compound Transverse-Lens / Exponent Correction Gate

## Verdict

BOXED: {verdict_status}

## Core result

Raw R126 feedback dynamic range:

BOXED: {raw_dynamic:.12g}

Frozen R127 dynamic-range benchmark:

BOXED: {FROZEN_R127_DYNAMIC_BENCHMARK:.12g}

Missing factor:

BOXED: {missing_factor:.12g}

Required posthoc beta control, not law:

BOXED: {required_beta_control:.12g}

## Interpretation

Global multipliers are rejected because they do not alter ratios or dynamic range. Differential exponent corrections can alter ratios and are therefore the correct mechanical form for compound-lens/normal-bundle amplification.

The fixed internal candidates beta=1/4 and beta=1/3 bracket the frozen benchmark. The 6pi phase-volume candidate is numerically close when treated as an exponent/range source rather than as a global multiplier.

## Candidate scorecard

{format_table(candidate_rows, ["candidate_id", "beta", "dynamic_range", "target_ratio_factor", "within_x2", "within_25pct", "posthoc", "grade"])}

## Global multiplier audit

{format_table(global_rows, ["factor_id", "factor", "dynamic_range_after_global_scaling", "same_as_raw_dynamic", "can_bridge_ratios"])}

## Claim boundary

{format_table(claim_boundary_rows, ["status", "claim", "reason"])}

## Gate audit

{format_table(gate_audit_rows, ["test", "result", "interpretation"])}

## Recommended next

BOXED: FORCE_R138 — Inter-Mode / Support-Graph Coupling Gate
BOXED: FORCE_R139 — Boundary-Insolvency Complexity Correction Gate
BOXED: FORCE_R128 — GR/Lag Field Derivation Gate
"""
(OUT / "FORCE_R137_summary.md").write_text(summary, encoding="utf-8")

manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
write_csv(OUT / "artifact_manifest.csv", manifest_rows, ["relative_path", "bytes", "sha256"])

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R137_compound_transverse_lens_exponent_correction_gate.py")
except Exception:
    pass

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

zip_integrity_pass = bad is None
verdict["zip_integrity_pass"] = zip_integrity_pass
(OUT / "FORCE_R137_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

print("=== COPY/PASTE R137 RESULT ===")
print("R137 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"raw_feedback_dynamic_range: {raw_dynamic:.12g}")
print(f"frozen_R127_dynamic_benchmark: {FROZEN_R127_DYNAMIC_BENCHMARK:.12g}")
print(f"missing_factor: {missing_factor:.12g}")
print(f"required_beta_control_not_law: {required_beta_control:.12g}")
print(f"candidate_values_generated: {candidate_values_generated}")
print(f"global_multiplier_rejected: {global_multiplier_rejected}")
print(f"fixed_exponent_candidates_generated: {fixed_exponent_candidates_generated}")
print(f"natural_exponent_candidates_bracket_target: {natural_exponent_candidates_bracket_target}")
print(f"phase_volume_candidate_within_25pct: {phase_volume_candidate_within_25pct}")
print(f"strong_bridge_candidates_present: {strong_bridge_candidates_present}")
print(f"no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}")
print(f"no_mass_matching_performed: {no_mass_matching_performed}")
print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
print(f"no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}")
print(f"unique_exponent_correction_closed: {unique_exponent_correction_closed}")
print(f"true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}")
print(f"physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}")
print("CANDIDATE_SCORECARD:")
print(format_table(candidate_rows, ["candidate_id", "beta", "dynamic_range", "target_ratio_factor", "within_x2", "within_25pct", "posthoc", "grade"]))
print("GLOBAL_FACTOR_AUDIT:")
print(format_table(global_rows, ["factor_id", "factor", "dynamic_range_after_global_scaling", "same_as_raw_dynamic", "can_bridge_ratios"]))
print("CLAIM_BOUNDARY:")
for row in claim_boundary_rows:
    print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R137_summary.md').resolve()}")
print("NEXT: FORCE_R138_inter_mode_support_graph_coupling_gate_or_FORCE_R139_boundary_insolvency_complexity_correction_gate")
print("=== END COPY/PASTE R137 RESULT ===")
