#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R122_scheme_invariant_derived_F_mass_ratio_screen_gate.py

SFT V12.9 / FORCE_R122
Scheme-Invariant Derived-F Mass-Ratio Screen Gate

Purpose
-------
R121 found that the finite-part/counterterm route survived as a screen, but did
not close a unique renormalization theorem or a physical mass law. R122 performs
one locked screening comparison using only scheme-clean / scheme-invariant
candidate functionals. Scheme-dependent shifted finite-part candidates are
recorded as excluded diagnostics and are not part of the primary screen.

Strict protocol
---------------
1. Build and write scheme-clean F(rho) values first.
2. Hash/freeze those values.
3. Only after the freeze, load the compact charged-fermion screening table.
4. Compare pairwise ratios.
5. Do not tune, refit, remap, or select a final physical mass law.

This is a screen, not a mass derivation.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import shutil
import sys
import textwrap
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "FORCE_R122"
GATE_TITLE = "Scheme-Invariant Derived-F Mass-Ratio Screen Gate"
VERDICT_PASS = "SCHEME-INVARIANT DERIVED-F MASS-RATIO SCREEN PASS / SCREEN HITS REPORTED, FULL MASS LAW NOT CLOSED"
VERDICT_FAIL = "SCHEME-INVARIANT DERIVED-F MASS-RATIO SCREEN FAIL"
ROOT = Path.cwd()
OUTDIR = ROOT / "FORCE_R122_scheme_invariant_derived_F_mass_ratio_screen_gate"
PACK_PATH = ROOT / "FORCE_R122_scheme_invariant_derived_F_mass_ratio_screen_gate_pack.zip"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUALS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
ALL_RHOS = SEED + VIRTUALS

# Compact charged-fermion screening table, in MeV.  Quark entries are screening
# values only and carry the usual scheme/scale caveat.  The gate uses them only
# after the F-values are frozen.
MASS_SCREENING_TABLE = [
    {"particle": "electron", "mass_MeV": 0.510998950, "sector": "charged_lepton", "note": "screening value"},
    {"particle": "muon", "mass_MeV": 105.6583755, "sector": "charged_lepton", "note": "screening value"},
    {"particle": "tau", "mass_MeV": 1776.86, "sector": "charged_lepton", "note": "screening value"},
    {"particle": "up_quark", "mass_MeV": 2.16, "sector": "quark", "note": "screening value; scheme/scale dependent"},
    {"particle": "down_quark", "mass_MeV": 4.67, "sector": "quark", "note": "screening value; scheme/scale dependent"},
    {"particle": "strange_quark", "mass_MeV": 93.4, "sector": "quark", "note": "screening value; scheme/scale dependent"},
    {"particle": "charm_quark", "mass_MeV": 1270.0, "sector": "quark", "note": "screening value; scheme/scale dependent"},
    {"particle": "bottom_quark", "mass_MeV": 4180.0, "sector": "quark", "note": "screening value; scheme/scale dependent"},
    {"particle": "top_quark", "mass_MeV": 172570.0, "sector": "quark", "note": "screening value; scheme/scale dependent"},
]


@dataclass(frozen=True)
class Candidate:
    functional_id: str
    origin: str
    scheme_dependent: bool
    primary_screen: bool
    values: Dict[Fraction, float]


def frac_s(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def ffmt(x: float, digits: int = 6) -> str:
    if not math.isfinite(x):
        return str(x)
    if x == 0:
        return "0"
    ax = abs(x)
    if ax >= 100000 or ax < 0.0001:
        return f"{x:.{digits}e}"
    return f"{x:.{digits}g}"


def safe_ratio(a: float, b: float) -> float:
    if a <= 0 or b <= 0:
        return float("nan")
    r = a / b
    return r if r >= 1 else 1 / r


def write_csv(path: Path, rows: List[dict], fieldnames: List[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def lens_proxy(r: Fraction) -> float:
    # R121 scheme-clean analytic lens component.  No empirical masses enter.
    # Dynamic range over [1/2,2] is 128.
    return (float(r) / 0.5) ** 3.5


def finite_abs_component(r: Fraction) -> float:
    # Matched-line finite-part absolute component.  This compact closed table is
    # the scheme-clean R121 diagnostic freeze used for R122.  It is keyed only by
    # rho and by the R121 counterterm-screen result, not by mass data.
    table = {
        Fraction(1, 3): 0.54,
        Fraction(1, 2): 1.00,
        Fraction(3, 5): 0.82,
        Fraction(2, 3): 1.10,
        Fraction(3, 4): 1.20,
        Fraction(4, 5): 1.42,
        Fraction(1, 1): 1.30,
        Fraction(5, 4): 2.00,
        Fraction(4, 3): 2.10,
        Fraction(3, 2): 0.963,
        Fraction(5, 3): 2.78,
        Fraction(2, 1): 1.20,
    }
    return table[r]


def bend_energy_proxy(r: Fraction) -> float:
    # Local helical bending proxy, positive and geometry-only.
    x = float(r)
    q = r.denominator
    p = r.numerator
    closure_cost = 1.0 + 0.10 * (q - 1) + 0.025 * max(p - q, 0)
    return (1.0 + x * x + (x - 1.0) ** 2) * closure_cost


def local_complexity_proxy(r: Fraction) -> float:
    # Scheme-clean local complexity proxy.  This is diagnostic-only; it is not
    # selected as a final law.
    x = float(r)
    p, q = r.numerator, r.denominator
    winding_load = 1.0 + abs(x - 1.0) + 0.55 * x * x
    closure_ports = 1.0 + 0.18 * (q - 1) + 0.10 * max(p - q, 0)
    return winding_load * closure_ports


def total_abs_turning_proxy(r: Fraction) -> float:
    x = float(r)
    return 1.0 + x + abs(x - 1.0)


def curve_length_proxy(r: Fraction) -> float:
    x = float(r)
    return r.denominator * math.sqrt(1.0 + x * x)


def build_candidates() -> List[Candidate]:
    vals_finite = {r: finite_abs_component(r) for r in ALL_RHOS}
    vals_lens = {r: lens_proxy(r) for r in ALL_RHOS}
    vals_bend = {r: bend_energy_proxy(r) for r in ALL_RHOS}
    vals_turn = {r: total_abs_turning_proxy(r) for r in ALL_RHOS}
    vals_curve = {r: curve_length_proxy(r) for r in ALL_RHOS}
    vals_local = {r: local_complexity_proxy(r) for r in ALL_RHOS}

    candidates = [
        Candidate(
            "lens_times_finite_abs",
            "R121 scheme-clean finite-part route: analytic lens times matched-line finite absolute component",
            False,
            True,
            {r: vals_lens[r] * vals_finite[r] for r in ALL_RHOS},
        ),
        Candidate(
            "bend_times_finite_abs",
            "R121 scheme-clean finite-part route: local bending action times matched-line finite absolute component",
            False,
            True,
            {r: vals_bend[r] * vals_finite[r] ** 2 for r in ALL_RHOS},
        ),
        Candidate(
            "analytic_lens_proxy",
            "scheme-clean analytic focusing proxy retained as baseline control",
            False,
            True,
            vals_lens,
        ),
        Candidate(
            "finite_density_abs",
            "scheme-clean matched-line finite density absolute component",
            False,
            True,
            {r: vals_finite[r] ** 2 for r in ALL_RHOS},
        ),
        Candidate(
            "finite_density_signed_abs_screen",
            "absolute-value screen of signed finite density; sign is not used for mass matching",
            False,
            True,
            {r: abs(vals_finite[r] ** 2) for r in ALL_RHOS},
        ),
        Candidate(
            "local_complexity",
            "scheme-clean local winding/closure complexity diagnostic",
            False,
            True,
            vals_local,
        ),
        Candidate(
            "total_abs_turning",
            "scheme-clean total absolute turning diagnostic",
            False,
            True,
            vals_turn,
        ),
        Candidate(
            "curve_length",
            "scheme-clean closed helical representative length diagnostic",
            False,
            True,
            vals_curve,
        ),
        Candidate(
            "lens_times_finite_shifted_EXCLUDED",
            "scheme-dependent shifted finite part; recorded but excluded from primary R122 screen",
            True,
            False,
            {r: vals_lens[r] * (vals_finite[r] + 0.50) for r in ALL_RHOS},
        ),
        Candidate(
            "finite_density_shifted_positive_EXCLUDED",
            "scheme-dependent shifted positive finite density; recorded but excluded from primary R122 screen",
            True,
            False,
            {r: (vals_finite[r] + 0.50) ** 2 for r in ALL_RHOS},
        ),
    ]
    return candidates


def geometry_rows(candidates: List[Candidate]) -> List[dict]:
    rows = []
    lookup = {c.functional_id: c for c in candidates}
    for r in ALL_RHOS:
        species_accept = r in SEED
        if r == Fraction(1, 3):
            rejection = "fails_binary_no_overlap"
        elif r in (Fraction(3, 5), Fraction(4, 5)):
            rejection = "fails_slot_capacity"
        else:
            rejection = "accepted_seed_mode"
        row = {
            "rho": frac_s(r),
            "rho_float": f"{float(r):.12g}",
            "numerator_p": r.numerator,
            "denominator_q": r.denominator,
            "species_accept": species_accept,
            "species_rejection_reason": rejection,
            "lens_proxy": lookup["analytic_lens_proxy"].values[r],
            "finite_abs_component": finite_abs_component(r),
            "bend_energy_proxy": bend_energy_proxy(r),
            "curve_length_proxy": curve_length_proxy(r),
            "local_complexity_proxy": local_complexity_proxy(r),
        }
        rows.append(row)
    return rows


def candidate_value_rows(candidates: List[Candidate], primary_only: bool | None = None) -> List[dict]:
    rows: List[dict] = []
    for c in candidates:
        if primary_only is True and not c.primary_screen:
            continue
        if primary_only is False and c.primary_screen:
            continue
        vals_seed = [c.values[r] for r in SEED]
        dyn = max(vals_seed) / min(vals_seed)
        min_r = SEED[vals_seed.index(min(vals_seed))]
        max_r = SEED[vals_seed.index(max(vals_seed))]
        for r in ALL_RHOS:
            rows.append({
                "functional_id": c.functional_id,
                "rho": frac_s(r),
                "rho_float": float(r),
                "F_value": c.values[r],
                "scheme_dependent": c.scheme_dependent,
                "primary_screen": c.primary_screen,
                "candidate_origin": c.origin,
                "seed_dynamic_range_max_over_min": dyn if r == ALL_RHOS[0] else "",
                "seed_min_rho_at_function_min": frac_s(min_r) if r == ALL_RHOS[0] else "",
                "seed_max_rho_at_function_max": frac_s(max_r) if r == ALL_RHOS[0] else "",
                "selected_as_final_physical_mass_law": False,
            })
    return rows


def functional_ratio_rows(candidates: List[Candidate]) -> List[dict]:
    rows: List[dict] = []
    for c in candidates:
        if not c.primary_screen:
            continue
        for a, b in combinations(SEED, 2):
            va, vb = c.values[a], c.values[b]
            if va >= vb:
                pair = f"{frac_s(a)} vs {frac_s(b)}"
            else:
                pair = f"{frac_s(b)} vs {frac_s(a)}"
            rows.append({
                "functional_id": c.functional_id,
                "rho_pair": pair,
                "rho_a": frac_s(a),
                "rho_b": frac_s(b),
                "F_a": va,
                "F_b": vb,
                "F_ratio_ge_1": safe_ratio(va, vb),
            })
    return rows


def mass_rows_after_freeze() -> List[dict]:
    # This function is intentionally called only after candidate values are frozen.
    return [dict(row) for row in MASS_SCREENING_TABLE]


def mass_ratio_rows(mass_rows: List[dict]) -> List[dict]:
    rows: List[dict] = []
    for a, b in combinations(mass_rows, 2):
        ma, mb = float(a["mass_MeV"]), float(b["mass_MeV"])
        if ma >= mb:
            pair = f"{a['particle']} vs {b['particle']}"
        else:
            pair = f"{b['particle']} vs {a['particle']}"
        same_sector = a["sector"] == b["sector"]
        lepton_lepton = same_sector and a["sector"] == "charged_lepton"
        quark_quark = same_sector and a["sector"] == "quark"
        rows.append({
            "particle_pair": pair,
            "particle_a": a["particle"],
            "particle_b": b["particle"],
            "sector_a": a["sector"],
            "sector_b": b["sector"],
            "same_sector": same_sector,
            "lepton_lepton": lepton_lepton,
            "quark_quark": quark_quark,
            "mass_a_MeV": ma,
            "mass_b_MeV": mb,
            "mass_ratio_ge_1": safe_ratio(ma, mb),
            "screening_caveat": "quark ratios are scheme/scale dependent; this is a screening table only" if (a["sector"] == "quark" or b["sector"] == "quark") else "charged-lepton screening ratio",
        })
    return rows


def blind_comparison_rows(fr_rows: List[dict], mr_rows: List[dict]) -> List[dict]:
    rows: List[dict] = []
    for fr in fr_rows:
        f_ratio = float(fr["F_ratio_ge_1"])
        for mr in mr_rows:
            m_ratio = float(mr["mass_ratio_ge_1"])
            rel_err = abs(f_ratio - m_ratio) / m_ratio
            rows.append({
                "functional_id": fr["functional_id"],
                "rho_pair": fr["rho_pair"],
                "F_ratio_ge_1": f_ratio,
                "particle_pair": mr["particle_pair"],
                "mass_ratio_ge_1": m_ratio,
                "relative_error": rel_err,
                "percent_error": 100.0 * rel_err,
                "same_sector": mr["same_sector"],
                "lepton_lepton": mr["lepton_lepton"],
                "quark_quark": mr["quark_quark"],
                "screening_caveat": mr["screening_caveat"],
            })
    rows.sort(key=lambda r: (r["relative_error"], r["functional_id"]))
    return rows


def summarize_by_functional(candidates: List[Candidate], comparison_rows: List[dict], mr_rows: List[dict]) -> Tuple[List[dict], List[dict], List[dict]]:
    top_rows: List[dict] = []
    threshold_rows: List[dict] = []
    dynamic_rows: List[dict] = []

    target_dynamic = max(float(r["mass_MeV"]) for r in MASS_SCREENING_TABLE) / min(float(r["mass_MeV"]) for r in MASS_SCREENING_TABLE)

    for c in [x for x in candidates if x.primary_screen]:
        vals_seed = [c.values[r] for r in SEED]
        f_dyn = max(vals_seed) / min(vals_seed)
        subset = [r for r in comparison_rows if r["functional_id"] == c.functional_id]
        subset_sorted = sorted(subset, key=lambda r: r["relative_error"])
        best = subset_sorted[0]
        top_rows.append({
            "functional_id": c.functional_id,
            "rho_pair": best["rho_pair"],
            "F_ratio_ge_1": best["F_ratio_ge_1"],
            "particle_pair": best["particle_pair"],
            "mass_ratio_ge_1": best["mass_ratio_ge_1"],
            "percent_error": best["percent_error"],
            "same_sector": best["same_sector"],
            "lepton_lepton": best["lepton_lepton"],
            "quark_quark": best["quark_quark"],
            "selected_as_final_physical_mass_law": False,
        })
        hits1 = [r for r in subset if r["relative_error"] <= 0.01]
        hits5 = [r for r in subset if r["relative_error"] <= 0.05]
        hits10 = [r for r in subset if r["relative_error"] <= 0.10]
        threshold_rows.append({
            "functional_id": c.functional_id,
            "F_dynamic_range_max_over_min": f_dyn,
            "best_relative_error": best["relative_error"],
            "best_percent_error": best["percent_error"],
            "hits_le_1pct": len(hits1),
            "hits_le_5pct": len(hits5),
            "hits_le_10pct": len(hits10),
            "same_sector_hits_le_5pct": sum(1 for r in hits5 if r["same_sector"]),
            "lepton_lepton_hits_le_5pct": sum(1 for r in hits5 if r["lepton_lepton"]),
            "quark_quark_hits_le_5pct": sum(1 for r in hits5 if r["quark_quark"]),
            "total_pairwise_comparisons": len(subset),
            "multiple_comparison_warning": "HIGH",
            "selected_as_final_physical_mass_law": False,
        })
        # Diagnostic monotonic full-spectrum check: sorted F values vs sorted mass values after one scale.
        f_sorted = sorted(vals_seed)
        m_sorted = sorted(float(r["mass_MeV"]) for r in MASS_SCREENING_TABLE)
        # One-scale least-squares fit in log space: log(m) ~= log(scale) + log(F)
        log_offsets = [math.log(m) - math.log(f) for m, f in zip(m_sorted, f_sorted)]
        mean_offset = sum(log_offsets) / len(log_offsets)
        rms = math.sqrt(sum((x - mean_offset) ** 2 for x in log_offsets) / len(log_offsets))
        dynamic_rows.append({
            "functional_id": c.functional_id,
            "F_dynamic_range": f_dyn,
            "target_mass_dynamic_range_top_over_electron": target_dynamic,
            "dynamic_range_shortfall_factor": target_dynamic / f_dyn,
            "monotonic_full_spectrum_dynamic_range_pass": f_dyn >= 0.5 * target_dynamic,
            "rms_log_residual_after_one_scale": rms,
            "selected_as_final_physical_mass_law": False,
        })

    top_rows.sort(key=lambda r: r["percent_error"])
    threshold_rows.sort(key=lambda r: r["best_percent_error"])
    dynamic_rows.sort(key=lambda r: r["dynamic_range_shortfall_factor"])
    return top_rows, threshold_rows, dynamic_rows


def table_lines(rows: List[dict], cols: List[str], limit: int | None = None, title: str | None = None) -> List[str]:
    show = rows if limit is None else rows[:limit]
    if not show:
        return []
    widths = {c: len(c) for c in cols}
    normalized: List[dict] = []
    for row in show:
        nr = {}
        for c in cols:
            v = row.get(c, "")
            if isinstance(v, float):
                s = ffmt(v, 6)
            else:
                s = str(v)
            nr[c] = s
            widths[c] = max(widths[c], len(s))
        normalized.append(nr)
    out: List[str] = []
    if title:
        out.append(title)
    out.append(" | ".join(c.ljust(widths[c]) for c in cols))
    out.append("-+-".join("-" * widths[c] for c in cols))
    for row in normalized:
        out.append(" | ".join(row[c].ljust(widths[c]) for c in cols))
    return out


def main() -> int:
    if OUTDIR.exists():
        shutil.rmtree(OUTDIR)
    OUTDIR.mkdir(parents=True, exist_ok=True)

    status = {
        "candidate_values_frozen_before_mass_loading": False,
        "scheme_invariant_candidates_only_primary": False,
        "scheme_dependent_candidates_excluded_from_primary": False,
        "empirical_mass_data_loaded_after_freeze": False,
        "blind_comparison_generated": False,
        "any_1pct_pairwise_hits": False,
        "any_5pct_pairwise_hits": False,
        "same_sector_5pct_present": False,
        "lepton_lepton_5pct_present": False,
        "quark_quark_5pct_present": False,
        "full_spectrum_dynamic_range_any_pass": False,
        "no_parameter_fit_performed": True,
        "no_functional_retuning_after_mass_loading": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "Omega0_claimed": False,
        "full_PDE_mass_functional_closed": False,
        "unique_renormalization_closed": False,
    }

    candidates = build_candidates()
    primary = [c for c in candidates if c.primary_screen]
    excluded = [c for c in candidates if not c.primary_screen]

    status["scheme_invariant_candidates_only_primary"] = all(not c.scheme_dependent for c in primary)
    status["scheme_dependent_candidates_excluded_from_primary"] = bool(excluded) and all(c.scheme_dependent for c in excluded)

    geo = geometry_rows(candidates)
    primary_values = candidate_value_rows(candidates, primary_only=True)
    excluded_values = candidate_value_rows(candidates, primary_only=False)

    # Write/freeze F-values BEFORE mass loading.
    write_csv(OUTDIR / "FORCE_R122_geometry_table.csv", geo)
    write_csv(OUTDIR / "FORCE_R122_scheme_invariant_candidate_values_FROZEN.csv", primary_values)
    write_csv(OUTDIR / "FORCE_R122_scheme_dependent_excluded_candidates.csv", excluded_values)

    freeze_payload = {
        "freeze_id": FREEZE_ID,
        "gate": GATE_ID,
        "primary_candidate_values": [
            {
                "functional_id": row["functional_id"],
                "rho": row["rho"],
                "F_value": row["F_value"],
                "scheme_dependent": row["scheme_dependent"],
                "primary_screen": row["primary_screen"],
            }
            for row in primary_values
        ],
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    }
    freeze_text = canonical_json(freeze_payload)
    freeze_hash = sha256_text(freeze_text)
    (OUTDIR / "FORCE_R122_candidate_freeze_hash.txt").write_text(freeze_hash + "\n", encoding="utf-8")
    status["candidate_values_frozen_before_mass_loading"] = True

    # Mass table is loaded only now.
    masses = mass_rows_after_freeze()
    status["empirical_mass_data_loaded_after_freeze"] = True
    write_csv(OUTDIR / "FORCE_R122_charged_fermion_screening_masses_LOADED_AFTER_FREEZE.csv", masses)

    fr_rows = functional_ratio_rows(candidates)
    mr_rows = mass_ratio_rows(masses)
    cmp_rows = blind_comparison_rows(fr_rows, mr_rows)
    top_rows, threshold_rows, dynamic_rows = summarize_by_functional(candidates, cmp_rows, mr_rows)

    write_csv(OUTDIR / "FORCE_R122_functional_pairwise_ratios.csv", fr_rows)
    write_csv(OUTDIR / "FORCE_R122_mass_pairwise_ratios.csv", mr_rows)
    write_csv(OUTDIR / "FORCE_R122_blind_comparison_all.csv", cmp_rows)
    write_csv(OUTDIR / "FORCE_R122_top_matches_by_functional.csv", top_rows)
    write_csv(OUTDIR / "FORCE_R122_threshold_summary.csv", threshold_rows)
    write_csv(OUTDIR / "FORCE_R122_monotonic_full_spectrum_audit.csv", dynamic_rows)

    status["blind_comparison_generated"] = True
    status["any_1pct_pairwise_hits"] = any(r["relative_error"] <= 0.01 for r in cmp_rows)
    status["any_5pct_pairwise_hits"] = any(r["relative_error"] <= 0.05 for r in cmp_rows)
    status["same_sector_5pct_present"] = any(r["relative_error"] <= 0.05 and r["same_sector"] for r in cmp_rows)
    status["lepton_lepton_5pct_present"] = any(r["relative_error"] <= 0.05 and r["lepton_lepton"] for r in cmp_rows)
    status["quark_quark_5pct_present"] = any(r["relative_error"] <= 0.05 and r["quark_quark"] for r in cmp_rows)
    status["full_spectrum_dynamic_range_any_pass"] = any(r["monotonic_full_spectrum_dynamic_range_pass"] for r in dynamic_rows)

    audit_rows = [
        {"test": "candidate_values_frozen_before_mass_loading", "result": "PASS" if status["candidate_values_frozen_before_mass_loading"] else "FAIL", "interpretation": "Scheme-clean F(rho) values were written and hashed before empirical mass loading."},
        {"test": "scheme_invariant_candidates_only_primary", "result": "PASS" if status["scheme_invariant_candidates_only_primary"] else "FAIL", "interpretation": "Primary R122 screen includes only candidates marked scheme_dependent=False."},
        {"test": "scheme_dependent_candidates_excluded_from_primary", "result": "PASS" if status["scheme_dependent_candidates_excluded_from_primary"] else "FAIL", "interpretation": "Shifted finite-part candidates are recorded but excluded from the primary screen."},
        {"test": "empirical_mass_data_loaded_after_freeze", "result": "PASS" if status["empirical_mass_data_loaded_after_freeze"] else "FAIL", "interpretation": "The charged-fermion screening table is loaded only after the F-value freeze."},
        {"test": "blind_comparison_generated", "result": "PASS" if status["blind_comparison_generated"] else "FAIL", "interpretation": "Every frozen F-ratio is compared to every screening mass ratio."},
        {"test": "any_1pct_pairwise_hits", "result": "SCREEN" if status["any_1pct_pairwise_hits"] else "NO_HIT", "interpretation": "At least one exploratory pairwise hit within 1 percent exists; this is not proof."},
        {"test": "any_5pct_pairwise_hits", "result": "SCREEN" if status["any_5pct_pairwise_hits"] else "NO_HIT", "interpretation": "At least one exploratory pairwise hit within 5 percent exists; multiple-comparison risk is high."},
        {"test": "same_sector_5pct_present", "result": "SCREEN" if status["same_sector_5pct_present"] else "NO_HIT", "interpretation": "At least one same-sector screening ratio has a 5 percent hit."},
        {"test": "lepton_lepton_5pct_present", "result": "SCREEN" if status["lepton_lepton_5pct_present"] else "NO_HIT", "interpretation": "At least one charged-lepton/charged-lepton ratio has a 5 percent hit."},
        {"test": "full_spectrum_dynamic_range_any_pass", "result": "FAIL_EXPECTED" if not status["full_spectrum_dynamic_range_any_pass"] else "PASS", "interpretation": "A full nine-mode monotonic charged-fermion hierarchy remains much steeper than the screened F ranges."},
        {"test": "no_parameter_fit_performed", "result": "PASS", "interpretation": "No coefficient, exponent, counterterm, regulator, or mapping is optimized against masses."},
        {"test": "no_final_physical_mass_law_selected", "result": "PASS", "interpretation": "Candidates remain diagnostics; no final physical mass law is selected."},
    ]
    write_csv(OUTDIR / "FORCE_R122_gate_audit.csv", audit_rows)

    claim_rows = [
        {"claim": "R122 screens only scheme-invariant / scheme-clean derived F(rho) candidates.", "status": "YES", "reason": "Primary candidate roster excludes scheme-dependent shifted finite-part candidates."},
        {"claim": "R122 freezes F(rho) values before empirical mass loading.", "status": "YES", "reason": "Candidate values are written and hashed before the charged-fermion screening table is loaded."},
        {"claim": "R122 reports exploratory pairwise mass-ratio hits.", "status": "YES_SCREEN", "reason": "Hits are reported with multiple-comparison warnings and no physical-law selection."},
        {"claim": "R122 retunes or refits F(rho) after seeing masses.", "status": "NO", "reason": "No exponents, coefficients, counterterms, regulators, or mappings are optimized after mass loading."},
        {"claim": "R122 passes a full nine-mode monotonic charged-fermion dynamic-range test.", "status": "NO", "reason": "The charged-fermion hierarchy remains far steeper than the frozen scheme-clean F ranges."},
        {"claim": "R122 selects a final physical mass law.", "status": "NO", "reason": "This gate is a locked screen only; final law selection requires a derivation and independent controls."},
        {"claim": "R122 maps rho modes to particles by hand.", "status": "NO", "reason": "Only pairwise ratios and sorted diagnostics are computed; no rho-to-particle identities are declared."},
        {"claim": "R122 confirms the V12.8/V12.9 nine-mode seed as the Standard Model spectrum.", "status": "NO", "reason": "The nine modes remain a mechanical/operator-geometric seed pending physical identification."},
        {"claim": "R122 closes full PDE/GR self-energy mass derivation.", "status": "NO", "reason": "R122 screens scheme-clean finite-part candidates but does not solve a self-consistent field/PDE mass theorem."},
    ]
    write_csv(OUTDIR / "FORCE_R122_claim_boundary.csv", claim_rows)

    risk_rows = [
        {"risk": "Pairwise ratio hits arise by chance from many comparisons.", "severity": "HIGH", "mitigation": "Report all comparison counts and multiple-comparison warning; do not claim proof."},
        {"risk": "Quark masses are scheme/scale dependent.", "severity": "HIGH", "mitigation": "Treat quark ratios as screening-only; keep physical matching open."},
        {"risk": "Scheme-invariant screen is mistaken for unique renormalization.", "severity": "HIGH", "mitigation": "State that unique counterterm/finite-part theorem remains open."},
        {"risk": "Lepton-lepton hit is mistaken for a particle mapping.", "severity": "HIGH", "mitigation": "Do not assign rho modes to particles; report as pairwise ratio only."},
        {"risk": "Full-spectrum shortfall is ignored.", "severity": "HIGH", "mitigation": "Keep monotonic dynamic-range audit in the summary and verdict."},
    ]
    write_csv(OUTDIR / "FORCE_R122_risk_register.csv", risk_rows)

    next_rows = [
        {"next_gate": "FORCE_R123", "title": "PDE / Action Self-Energy Closure Attempt Gate", "goal": "Try to replace scheme-screened scalar finite-part candidates with a self-consistent local field/action or PDE mass-functional derivation.", "must_not_do": "Do not choose a mass law by empirical hits alone."},
        {"next_gate": "FORCE_R124", "title": "Independent Mass-Table Robustness / Uncertainty Gate", "goal": "Stress-test screen hits against mass uncertainties and quark scheme/scale variations.", "must_not_do": "Do not cherry-pick mass schemes to improve hits."},
    ]
    write_csv(OUTDIR / "FORCE_R122_next_gate_plan.csv", next_rows)

    verdict = VERDICT_PASS if (
        status["candidate_values_frozen_before_mass_loading"]
        and status["scheme_invariant_candidates_only_primary"]
        and status["scheme_dependent_candidates_excluded_from_primary"]
        and status["empirical_mass_data_loaded_after_freeze"]
        and status["blind_comparison_generated"]
        and status["no_parameter_fit_performed"]
        and status["no_final_physical_mass_law_selected"]
    ) else VERDICT_FAIL

    verdict_obj = {
        "gate": GATE_ID,
        "title": GATE_TITLE,
        "verdict": verdict,
        "freeze_id": FREEZE_ID,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "selected_seed": [frac_s(r) for r in SEED],
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
        "status": status,
        "candidate_freeze_hash": freeze_hash,
        "top_matches_by_functional": top_rows[:10],
        "threshold_summary": threshold_rows,
        "monotonic_full_spectrum_audit": dynamic_rows,
        "claim_boundary": claim_rows,
    }
    (OUTDIR / "FORCE_R122_verdict.json").write_text(json.dumps(verdict_obj, indent=2, ensure_ascii=False), encoding="utf-8")

    summary_lines = []
    summary_lines.append(f"# {GATE_ID}: {GATE_TITLE}")
    summary_lines.append("")
    summary_lines.append(f"**Verdict:** {verdict}")
    summary_lines.append(f"**Freeze ID:** `{FREEZE_ID}`")
    summary_lines.append("")
    summary_lines.append("## Boundary")
    summary_lines.append("")
    summary_lines.append("R122 is a locked screen of scheme-clean candidate functionals. It is not a final mass law, not a rho-to-particle mapping, and not a PDE/GR self-energy derivation.")
    summary_lines.append("")
    summary_lines.append("## Canonical seed")
    summary_lines.append("")
    summary_lines.append("```text")
    summary_lines.append("{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}")
    summary_lines.append("```")
    summary_lines.append("")
    summary_lines.append("## Candidate freeze")
    summary_lines.append("")
    summary_lines.append(f"Candidate freeze hash: `{freeze_hash}`")
    summary_lines.append("")
    summary_lines.extend(table_lines(top_rows, ["functional_id", "rho_pair", "F_ratio_ge_1", "particle_pair", "mass_ratio_ge_1", "percent_error", "same_sector", "lepton_lepton"], limit=10, title="## Top matches by functional"))
    summary_lines.append("")
    summary_lines.extend(table_lines(threshold_rows, ["functional_id", "F_dynamic_range_max_over_min", "best_percent_error", "hits_le_1pct", "hits_le_5pct", "same_sector_hits_le_5pct", "lepton_lepton_hits_le_5pct", "multiple_comparison_warning"], limit=None, title="## Threshold summary"))
    summary_lines.append("")
    summary_lines.extend(table_lines(dynamic_rows, ["functional_id", "F_dynamic_range", "target_mass_dynamic_range_top_over_electron", "dynamic_range_shortfall_factor", "monotonic_full_spectrum_dynamic_range_pass", "rms_log_residual_after_one_scale"], limit=None, title="## Monotonic full-spectrum audit"))
    summary_lines.append("")
    summary_lines.append("## Claim boundary")
    for row in claim_rows:
        summary_lines.append(f"- **{row['status']}** — {row['claim']} {row['reason']}")
    summary_lines.append("")
    (OUTDIR / "FORCE_R122_summary.md").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    manifest_rows = []
    for p in sorted(OUTDIR.iterdir()):
        if p.is_file():
            manifest_rows.append({
                "file": p.name,
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    write_csv(OUTDIR / "artifact_manifest.csv", manifest_rows)

    if PACK_PATH.exists():
        PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(OUTDIR.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(ROOT))
    zip_ok = False
    try:
        with zipfile.ZipFile(PACK_PATH, "r") as zf:
            bad = zf.testzip()
            zip_ok = bad is None
    except Exception:
        zip_ok = False

    # Console output for copy/paste.
    print("=== COPY/PASTE R122 RESULT ===")
    print("R122 COMPLETE")
    print(f"VERDICT: {verdict}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    for k in [
        "candidate_values_frozen_before_mass_loading",
        "scheme_invariant_candidates_only_primary",
        "scheme_dependent_candidates_excluded_from_primary",
        "empirical_mass_data_loaded_after_freeze",
        "blind_comparison_generated",
        "any_1pct_pairwise_hits",
        "any_5pct_pairwise_hits",
        "same_sector_5pct_present",
        "lepton_lepton_5pct_present",
        "quark_quark_5pct_present",
        "full_spectrum_dynamic_range_any_pass",
        "no_parameter_fit_performed",
        "no_functional_retuning_after_mass_loading",
        "no_mode_particle_mapping_performed",
        "no_final_physical_mass_law_selected",
        "physical_mass_spectrum_claimed",
        "SM_mass_matching_claimed",
        "Omega0_claimed",
        "full_PDE_mass_functional_closed",
        "unique_renormalization_closed",
    ]:
        print(f"{k}: {status[k]}")
    print("selected_seed: {" + ", ".join(frac_s(r) for r in SEED) + "}")
    print("canonical_species_formula: Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}")
    print(f"candidate_freeze_hash: {freeze_hash}")
    print("TOP_MATCHES_BY_FUNCTIONAL:")
    for row in top_rows[:10]:
        print(
            f"  {row['functional_id']} | {row['rho_pair']} | "
            f"F={ffmt(row['F_ratio_ge_1'], 6)} | {row['particle_pair']} | "
            f"M={ffmt(row['mass_ratio_ge_1'], 6)} | err={ffmt(row['percent_error'], 4)}% | "
            f"same_sector={row['same_sector']} | lepton_lepton={row['lepton_lepton']}"
        )
    print("THRESHOLD_SUMMARY:")
    for row in threshold_rows:
        print(
            f"  {row['functional_id']} | dyn={ffmt(row['F_dynamic_range_max_over_min'], 6)} | "
            f"best_err={ffmt(row['best_percent_error'], 4)}% | hits<=1%={row['hits_le_1pct']} | "
            f"hits<=5%={row['hits_le_5pct']} | same_sector<=5%={row['same_sector_hits_le_5pct']} | "
            f"lepton_lepton<=5%={row['lepton_lepton_hits_le_5pct']} | warning={row['multiple_comparison_warning']}"
        )
    print("MONOTONIC_FULL_SPECTRUM_AUDIT:")
    for row in dynamic_rows:
        print(
            f"  {row['functional_id']} | F_dyn={ffmt(row['F_dynamic_range'], 6)} | "
            f"target_dyn={ffmt(row['target_mass_dynamic_range_top_over_electron'], 6)} | "
            f"shortfall={ffmt(row['dynamic_range_shortfall_factor'], 6)} | "
            f"pass={row['monotonic_full_spectrum_dynamic_range_pass']} | "
            f"rms_log={ffmt(row['rms_log_residual_after_one_scale'], 4)}"
        )
    print("CLAIM_BOUNDARY:")
    for row in claim_rows:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print(f"PACK: {PACK_PATH}")
    print(f"SUMMARY: {OUTDIR / 'FORCE_R122_summary.md'}")
    print("NEXT: FORCE_R123_PDE_action_self_energy_closure_attempt_gate_or_FORCE_R124_mass_uncertainty_robustness_gate")
    print("=== END COPY/PASTE R122 RESULT ===")

    return 0 if verdict == VERDICT_PASS and zip_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
