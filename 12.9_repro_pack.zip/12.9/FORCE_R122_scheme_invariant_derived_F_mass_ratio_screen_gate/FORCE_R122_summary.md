# FORCE_R122: Scheme-Invariant Derived-F Mass-Ratio Screen Gate

**Verdict:** SCHEME-INVARIANT DERIVED-F MASS-RATIO SCREEN PASS / SCREEN HITS REPORTED, FULL MASS LAW NOT CLOSED
**Freeze ID:** `SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM`

## Boundary

R122 is a locked screen of scheme-clean candidate functionals. It is not a final mass law, not a rho-to-particle mapping, and not a PDE/GR self-energy derivation.

## Canonical seed

```text
{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}
```

## Candidate freeze

Candidate freeze hash: `3c220b075936ff531b67d04065fdd77879260d2625c9d6231557cd2f8a2692aa`

## Top matches by functional
functional_id                    | rho_pair   | F_ratio_ge_1 | particle_pair          | mass_ratio_ge_1 | percent_error | same_sector | lepton_lepton
---------------------------------+------------+--------------+------------------------+-----------------+---------------+-------------+--------------
finite_density_abs               | 1 vs 2/3   | 1.39669      | tau vs charm_quark     | 1.3991          | 0.172121      | False       | False        
finite_density_signed_abs_screen | 1 vs 2/3   | 1.39669      | tau vs charm_quark     | 1.3991          | 0.172121      | False       | False        
bend_times_finite_abs            | 5/3 vs 1   | 12.0677      | charm_quark vs muon    | 12.0199         | 0.397801      | False       | False        
lens_times_finite_abs            | 2 vs 4/3   | 2.36201      | bottom_quark vs tau    | 2.35246         | 0.405681      | False       | False        
local_complexity                 | 2 vs 2/3   | 2.15307      | down_quark vs up_quark | 2.16204         | 0.41496       | True        | False        
total_abs_turning                | 3/2 vs 4/3 | 1.125        | muon vs strange_quark  | 1.13125         | 0.552134      | False       | False        
curve_length                     | 3/4 vs 3/2 | 1.38675      | tau vs charm_quark     | 1.3991          | 0.882843      | False       | False        
analytic_lens_proxy              | 5/4 vs 1   | 2.18366      | down_quark vs up_quark | 2.16204         | 1.00013       | True        | False        

## Threshold summary
functional_id                    | F_dynamic_range_max_over_min | best_percent_error | hits_le_1pct | hits_le_5pct | same_sector_hits_le_5pct | lepton_lepton_hits_le_5pct | multiple_comparison_warning
---------------------------------+------------------------------+--------------------+--------------+--------------+--------------------------+----------------------------+----------------------------
finite_density_abs               | 8.33368                      | 0.172121           | 3            | 11           | 1                        | 0                          | HIGH                       
finite_density_signed_abs_screen | 8.33368                      | 0.172121           | 3            | 11           | 1                        | 0                          | HIGH                       
bend_times_finite_abs            | 24.7205                      | 0.397801           | 2            | 12           | 2                        | 0                          | HIGH                       
lens_times_finite_abs            | 187.984                      | 0.405681           | 3            | 17           | 6                        | 1                          | HIGH                       
local_complexity                 | 3.21505                      | 0.41496            | 3            | 20           | 6                        | 0                          | HIGH                       
total_abs_turning                | 2                            | 0.552134           | 1            | 8            | 0                        | 0                          | HIGH                       
curve_length                     | 4.52769                      | 0.882843           | 4            | 16           | 4                        | 0                          | HIGH                       
analytic_lens_proxy              | 128                          | 1.00013            | 0            | 14           | 6                        | 2                          | HIGH                       

## Monotonic full-spectrum audit
functional_id                    | F_dynamic_range | target_mass_dynamic_range_top_over_electron | dynamic_range_shortfall_factor | monotonic_full_spectrum_dynamic_range_pass | rms_log_residual_after_one_scale
---------------------------------+-----------------+---------------------------------------------+--------------------------------+--------------------------------------------+---------------------------------
lens_times_finite_abs            | 187.984         | 3.377111e+05                                | 1796.49                        | False                                      | 2.26973                         
analytic_lens_proxy              | 128             | 3.377111e+05                                | 2638.37                        | False                                      | 2.40107                         
bend_times_finite_abs            | 24.7205         | 3.377111e+05                                | 13661.2                        | False                                      | 2.89372                         
finite_density_abs               | 8.33368         | 3.377111e+05                                | 40523.6                        | False                                      | 3.21194                         
finite_density_signed_abs_screen | 8.33368         | 3.377111e+05                                | 40523.6                        | False                                      | 3.21194                         
curve_length                     | 4.52769         | 3.377111e+05                                | 74587.9                        | False                                      | 3.39554                         
local_complexity                 | 3.21505         | 3.377111e+05                                | 1.050406e+05                   | False                                      | 3.49832                         
total_abs_turning                | 2               | 3.377111e+05                                | 1.688555e+05                   | False                                      | 3.63101                         

## Claim boundary
- **YES** — R122 screens only scheme-invariant / scheme-clean derived F(rho) candidates. Primary candidate roster excludes scheme-dependent shifted finite-part candidates.
- **YES** — R122 freezes F(rho) values before empirical mass loading. Candidate values are written and hashed before the charged-fermion screening table is loaded.
- **YES_SCREEN** — R122 reports exploratory pairwise mass-ratio hits. Hits are reported with multiple-comparison warnings and no physical-law selection.
- **NO** — R122 retunes or refits F(rho) after seeing masses. No exponents, coefficients, counterterms, regulators, or mappings are optimized after mass loading.
- **NO** — R122 passes a full nine-mode monotonic charged-fermion dynamic-range test. The charged-fermion hierarchy remains far steeper than the frozen scheme-clean F ranges.
- **NO** — R122 selects a final physical mass law. This gate is a locked screen only; final law selection requires a derivation and independent controls.
- **NO** — R122 maps rho modes to particles by hand. Only pairwise ratios and sorted diagnostics are computed; no rho-to-particle identities are declared.
- **NO** — R122 confirms the V12.8/V12.9 nine-mode seed as the Standard Model spectrum. The nine modes remain a mechanical/operator-geometric seed pending physical identification.
- **NO** — R122 closes full PDE/GR self-energy mass derivation. R122 screens scheme-clean finite-part candidates but does not solve a self-consistent field/PDE mass theorem.

