# FORCE_R135 — Locked Rent-Normalized Candidate Mass Screen Gate

## Verdict

BOXED: LOCKED RENT-NORMALIZED CANDIDATE MASS SCREEN PASS / SCREEN HITS REPORTED, FULL MASS LAW NOT CLOSED

## Freeze ID

BOXED: SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM

## Selected seed

BOXED: {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}

## Canonical species formula

BOXED: Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}

## Candidate freeze hash

BOXED: 3f687166f28e2753825774185216f1af66308d746c0bad8de3183fce64ec01a5

## Key booleans

- candidate_values_frozen_before_mass_loading: True
- empirical_mass_data_loaded_after_freeze: True
- blind_comparison_generated: True
- any_1pct_pairwise_hits: True
- any_5pct_pairwise_hits: True
- same_sector_5pct_present: True
- lepton_lepton_5pct_present: True
- quark_quark_5pct_present: True
- full_spectrum_dynamic_range_any_pass: False
- no_parameter_fit_performed: True
- no_functional_retuning_after_mass_loading: True
- no_mode_particle_mapping_performed: True
- no_final_physical_mass_law_selected: True

## Top primary matches

                                    functional_id rho_hi rho_lo   F_ratio   particle_hi   particle_lo  mass_ratio  percent_error  same_sector  lepton_lepton  quark_quark scheme_warning
 p5_quadratic_density_self_energy_rent_normalized    1/2    2/3  1.128490          muon strange_quark    1.131246       0.243620        False          False        False           HIGH
 p5_quadratic_density_self_energy_rent_normalized      2    2/3 19.836654 strange_quark    down_quark   20.000000       0.816728         True          False         True           HIGH
p6_curvature_weighted_self_energy_rent_normalized      2      1 12.138136   charm_quark          muon   12.019871       0.983912        False          False        False           HIGH
p6_curvature_weighted_self_energy_rent_normalized    1/2    3/2  1.142574          muon strange_quark    1.131246       1.001339        False          False        False           HIGH
 p5_quadratic_density_self_energy_rent_normalized      2    3/4 20.207492 strange_quark    down_quark   20.000000       1.037458         True          False         True           HIGH
p6_curvature_weighted_self_energy_rent_normalized    4/3    5/4  1.119475          muon strange_quark    1.131246       1.040511        False          False        False           HIGH
 p5_quadratic_density_self_energy_rent_normalized    1/2      1  1.381056           tau   charm_quark    1.399102       1.289853        False          False        False           HIGH
p6_curvature_weighted_self_energy_rent_normalized    2/3    3/4  1.146031          muon strange_quark    1.131246       1.306999        False          False        False           HIGH
 p5_quadratic_density_self_energy_rent_normalized    5/3    3/2  2.318305  bottom_quark           tau    2.352464       1.452069        False          False        False           HIGH
 p5_quadratic_density_self_energy_rent_normalized    1/2    3/4  1.149587          muon strange_quark    1.131246       1.621280        False          False        False           HIGH
p6_curvature_weighted_self_energy_rent_normalized      2    5/3  2.406477  bottom_quark           tau    2.352464       2.296016        False          False        False           HIGH
p6_curvature_weighted_self_energy_rent_normalized    5/3    5/4  3.375540  bottom_quark   charm_quark    3.291339       2.558265         True          False         True           HIGH
p6_curvature_weighted_self_energy_rent_normalized    3/2      1  2.417448  bottom_quark           tau    2.352464       2.762350        False          False        False           HIGH
p6_curvature_weighted_self_energy_rent_normalized    2/3    4/3  1.097396          muon strange_quark    1.131246       2.992281        False          False        False           HIGH
 p5_quadratic_density_self_energy_rent_normalized    4/3      1  2.230387    down_quark      up_quark    2.162037       3.161364         True          False         True           HIGH
p6_curvature_weighted_self_energy_rent_normalized    3/2    4/3  1.445159           tau   charm_quark    1.399102       3.291871        False          False        False           HIGH

## Threshold summary

                                    functional_id  power  primary_screen  dynamic_range  best_error_percent                                best_match  hits_le_1pct  hits_le_5pct  same_sector_le_5pct  lepton_lepton_le_5pct  quark_quark_le_5pct multiple_comparison_warning
 p5_quadratic_density_self_energy_rent_normalized    5.0            True      24.276271            0.243620       1/2 vs 2/3 -> muon vs strange_quark             2            11                    5                      1                    4                        HIGH
p6_curvature_weighted_self_energy_rent_normalized    6.0            True      12.138136            0.983912             2 vs 1 -> charm_quark vs muon             1            12                    3                      0                    3                        HIGH
        p4_write_density_rent_control_too_shallow    4.0           False      70.312199            0.280281 4/3 vs 3/4 -> bottom_quark vs charm_quark             4            16                    7                      2                    5                        HIGH
      p7_acceleration_weighted_high_order_control    7.0           False       6.069068            1.216612        3/4 vs 1 -> down_quark vs up_quark             0            11                    4                      0                    4                        HIGH

## Monotonic full-spectrum audit

                                    functional_id  F_dynamic_range  target_dynamic_range    shortfall  overshoot  dynamic_range_pass  rms_log_sorted_shape_error
        p4_write_density_rent_control_too_shallow        70.312199         338082.886472  4808.310509        0.0               False                    5.067571
 p5_quadratic_density_self_energy_rent_normalized        24.276271         338082.886472 13926.475129        0.0               False                    5.641038
p6_curvature_weighted_self_energy_rent_normalized        12.138136         338082.886472 27852.950257        0.0               False                    5.839467
      p7_acceleration_weighted_high_order_control         6.069068         338082.886472 55705.900514        0.0               False                    5.939605

## Claim boundary

    status                                                                                        claim                                                                                                                reason
YES_SCREEN R135 compares frozen p=5/p=6 rent-normalized F(rho) pairwise ratios to external mass ratios.                    Candidate values are written and hashed before the charged-fermion screening table is constructed.
        NO                                           R135 chooses p=5 or p=6 because of empirical hits.                                    p=5 and p=6 were generated before mass loading from R132/R133 power-count screens.
        NO                             R135 retunes, refits, or exponent-optimizes after seeing masses.       No exponents, coefficients, thresholds, regulators, counterterms, or mappings are optimized after mass loading.
YES_SCREEN                                           R135 reports exploratory pairwise mass-ratio hits.                                           Hits are reported with same-sector labels and multiple-comparison warnings.
        NO                   R135 passes a full nine-mode monotonic charged-fermion dynamic-range test.                               Rent-normalized adequacy candidates are screened; dynamic-range closure is not assumed.
        NO                                      R135 selects a final physical mass law or sector split.           The result is a locked blind screen only; final law selection requires derivation and independent controls.
        NO                         R135 maps rho modes to leptons, quarks, or Standard Model particles.                 Only pairwise ratios and sorted diagnostics are computed; no rho-to-particle identities are declared.
        NO                                           R135 closes true GR/PDE collective field dynamics. The rent-normalized feedback candidates are geometry/power-count screens, not solved self-consistent field equations.
