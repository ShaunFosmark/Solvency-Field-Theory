#!/usr/bin/env python3
"""
FORCE_R128_GR_lag_field_derivation_gate.py

V12.9 GR/Lag Field Derivation Gate
----------------------------------
Purpose:
  Attempt a field-equation/lag-accounting derivation screen for the leading
  R137/R139 bridge mechanisms without loading empirical masses, performing
  mass matching, fitting exponents, or mapping rho modes to particles.

This is NOT a solved Einstein/PDE mass theorem. It is a disciplined derivation
screen that asks which terms are demanded by a local scalar lag/Poisson-like
field model and boundary/bulk bookkeeping:
  - raw scalar lag self-field
  - inverse boundary-area response (rho_norm^2)
  - transverse phase measure / compound normal response (6*pi or 18 as range-source)
  - full hybrid controls to detect double counting

The script is intentionally self-contained and dependency-light.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import textwrap
import zipfile
from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
from typing import Dict, List, Tuple, Any

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE = "FORCE_R128_GR_lag_field_derivation_gate"
TITLE = "GR/Lag Field Derivation Gate"
OUT = Path.cwd() / GATE
PACK = Path.cwd() / f"{GATE}_pack.zip"

SEED = [Fraction(1,2), Fraction(2,3), Fraction(3,4), Fraction(1,1), Fraction(5,4), Fraction(4,3), Fraction(3,2), Fraction(5,3), Fraction(2,1)]
SEED_STR = [str(x) for x in SEED]

# R126 primary raw feedback preview values, normalized exactly as prior gates used them.
RAW_F: Dict[str, float] = {
    "1/2": 0.0199112,
    "2/3": 0.0743514,
    "3/4": 0.131525,
    "1":   0.461352,
    "5/4": 2.62978,
    "4/3": 4.33617,
    "3/2": 12.7039,
    "5/3": 49.8764,
    "2":   358.397,
}

D_PERP = 3
SLOT_CAPACITY = 1 + D_PERP
PHASE_VOLUME_6PI = 2.0 * math.pi * D_PERP
ORIENTED_MODE_COUNT = 2 * len(SEED)


def fstr(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def dyn(vals: Dict[str, float]) -> float:
    vs = [v for v in vals.values() if v > 0]
    return max(vs) / min(vs)


def normalize_to_min(vals: Dict[str, float]) -> Dict[str, float]:
    m = min(v for v in vals.values() if v > 0)
    return {k: v / m for k, v in vals.items()}


def exponent_candidate(vals: Dict[str, float], beta: float) -> Dict[str, float]:
    norm = normalize_to_min(vals)
    return {k: v ** (1.0 + beta) for k, v in norm.items()}


def boundary_candidate(vals: Dict[str, float], gamma: float) -> Dict[str, float]:
    norm = normalize_to_min(vals)
    out = {}
    for r in SEED:
        key = fstr(r)
        rho_norm = float(r / Fraction(1,2))
        out[key] = norm[key] * (rho_norm ** gamma)
    return out


def hybrid_candidate(vals: Dict[str, float], beta: float, gamma: float) -> Dict[str, float]:
    norm = normalize_to_min(vals)
    out = {}
    for r in SEED:
        key = fstr(r)
        rho_norm = float(r / Fraction(1,2))
        out[key] = (norm[key] ** (1.0 + beta)) * (rho_norm ** gamma)
    return out


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: List[str] | None = None) -> None:
    if not fieldnames:
        keys = []
        for r in rows:
            for k in r.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def table(rows: List[Dict[str, Any]], fieldnames: List[str]) -> str:
    if not rows:
        return "(none)"
    widths = {c: max(len(c), *(len(str(r.get(c, ""))) for r in rows)) for c in fieldnames}
    line = " | ".join(c.ljust(widths[c]) for c in fieldnames)
    sep = "-+-".join("-" * widths[c] for c in fieldnames)
    body = []
    for r in rows:
        body.append(" | ".join(str(r.get(c, "")).ljust(widths[c]) for c in fieldnames))
    return "\n".join([line, sep] + body)


def fmt(x: float, n: int = 6) -> str:
    if abs(x) >= 1e5 or (abs(x) > 0 and abs(x) < 1e-4):
        return f"{x:.6g}"
    return f"{x:.{n}f}".rstrip("0").rstrip(".")


@dataclass
class Candidate:
    candidate_id: str
    family: str
    beta: float
    gamma: float
    field_origin: str
    values: Dict[str, float]
    local_field_status: str
    boundary_status: str
    double_counting_status: str
    final_law: bool = False

    @property
    def dynamic_range(self) -> float:
        return dyn(self.values)

    def row(self) -> Dict[str, Any]:
        d = self.dynamic_range
        if self.double_counting_status == "EXCLUDED_DOUBLE_COUNTING_CONTROL":
            grade = "OVERBRIDGE_DOUBLE_COUNTING_CONTROL"
        elif self.family in ("compound_transverse_lens", "boundary_insolvency"):
            grade = "PRIMARY_FIELD_SCREEN_CANDIDATE"
        elif self.family == "partial_overlap_control":
            grade = "SECONDARY_PARTIAL_OVERLAP_SCREEN"
        elif self.family == "raw_scalar_lag":
            grade = "BASELINE_FIELD_SCREEN"
        else:
            grade = "DIAGNOSTIC_CONTROL"
        return {
            "candidate_id": self.candidate_id,
            "family": self.family,
            "beta": fmt(self.beta, 9),
            "gamma": fmt(self.gamma, 9),
            "dynamic_range": fmt(d, 6),
            "field_origin": self.field_origin,
            "local_field_status": self.local_field_status,
            "boundary_status": self.boundary_status,
            "double_counting_status": self.double_counting_status,
            "grade": grade,
            "final_law": self.final_law,
        }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    raw_dyn = dyn(RAW_F)
    beta_6pi = math.log(PHASE_VOLUME_6PI) / math.log(raw_dyn)
    beta_18 = math.log(ORIENTED_MODE_COUNT) / math.log(raw_dyn)
    beta_slot = 1.0 / SLOT_CAPACITY
    beta_normal = 1.0 / D_PERP

    candidates: List[Candidate] = []

    # Baseline scalar lag/Poisson-like self field.
    candidates.append(Candidate(
        candidate_id="scalar_lag_raw_self_field",
        family="raw_scalar_lag",
        beta=0.0,
        gamma=0.0,
        field_origin="Poisson-like scalar lag kernel sourced by isolated helical line energy; computes raw radius/depth feedback only.",
        values=normalize_to_min(RAW_F),
        local_field_status="LOCAL_SCALAR_SCREEN_DEFINED",
        boundary_status="BOUNDARY_RESPONSE_NOT_INCLUDED",
        double_counting_status="NO_DOUBLE_COUNTING",
    ))

    # Primary R137-like derivation screens.
    candidates.append(Candidate(
        candidate_id="field_transverse_phase_measure_6pi_exponent",
        family="compound_transverse_lens",
        beta=beta_6pi,
        gamma=0.0,
        field_origin="Three normal channels each carry a 2pi transverse phase measure; tested as compound response exponent, not global factor.",
        values=exponent_candidate(RAW_F, beta_6pi),
        local_field_status="TRANSVERSE_MEASURE_SCREEN_SUPPORTED",
        boundary_status="IMPLICIT_BOUNDARY_RESPONSE_VIA_EXPONENT",
        double_counting_status="SINGLE_MECHANISM",
    ))
    candidates.append(Candidate(
        candidate_id="field_oriented_18_exponent",
        family="compound_transverse_lens",
        beta=beta_18,
        gamma=0.0,
        field_origin="Nine seed modes with two orientations enter as a range-source exponent; tested as orientation/phase response screen.",
        values=exponent_candidate(RAW_F, beta_18),
        local_field_status="ORIENTATION_MEASURE_SCREEN_SUPPORTED",
        boundary_status="IMPLICIT_BOUNDARY_RESPONSE_VIA_EXPONENT",
        double_counting_status="SINGLE_MECHANISM",
    ))
    candidates.append(Candidate(
        candidate_id="field_slot_root_beta_1_over_4_control",
        family="compound_transverse_lens",
        beta=beta_slot,
        gamma=0.0,
        field_origin="One tangent plus three normal slots gives slot-root exponent beta=1/4; under-bridge control from field slot capacity.",
        values=exponent_candidate(RAW_F, beta_slot),
        local_field_status="SLOT_ROOT_SCREEN_SUPPORTED",
        boundary_status="IMPLICIT_BOUNDARY_RESPONSE_VIA_EXPONENT",
        double_counting_status="SINGLE_MECHANISM_CONTROL",
    ))
    candidates.append(Candidate(
        candidate_id="field_normal_root_beta_1_over_3_control",
        family="compound_transverse_lens",
        beta=beta_normal,
        gamma=0.0,
        field_origin="Three normal dimensions give normal-root exponent beta=1/3; over-bridge bracket control from normal bundle.",
        values=exponent_candidate(RAW_F, beta_normal),
        local_field_status="NORMAL_ROOT_SCREEN_SUPPORTED",
        boundary_status="IMPLICIT_BOUNDARY_RESPONSE_VIA_EXPONENT",
        double_counting_status="SINGLE_MECHANISM_CONTROL",
    ))

    # Primary R139-like derivation screens.
    candidates.append(Candidate(
        candidate_id="field_inverse_boundary_area_rho2_response",
        family="boundary_insolvency",
        beta=0.0,
        gamma=2.0,
        field_origin="If closure radius r~1/rho, boundary area A~r^2; inverse boundary load/area pressure supplies rho_norm^2 response.",
        values=boundary_candidate(RAW_F, 2.0),
        local_field_status="BOUNDARY_FLUX_BALANCE_SCREEN_SUPPORTED",
        boundary_status="EXPLICIT_INVERSE_AREA_RESPONSE",
        double_counting_status="SINGLE_MECHANISM",
    ))
    candidates.append(Candidate(
        candidate_id="field_boundary_linear_rho_control",
        family="boundary_insolvency",
        beta=0.0,
        gamma=1.0,
        field_origin="One-dimensional boundary/radius response control; expected under-bridge.",
        values=boundary_candidate(RAW_F, 1.0),
        local_field_status="BOUNDARY_CONTROL_DEFINED",
        boundary_status="LINEAR_RESPONSE_UNDERBRIDGE_CONTROL",
        double_counting_status="SINGLE_MECHANISM_CONTROL",
    ))
    candidates.append(Candidate(
        candidate_id="field_bulk_volume_rho3_control",
        family="boundary_insolvency",
        beta=0.0,
        gamma=3.0,
        field_origin="Full bulk-volume response control; expected over-bridge if used as boundary response.",
        values=boundary_candidate(RAW_F, 3.0),
        local_field_status="BULK_VOLUME_CONTROL_DEFINED",
        boundary_status="BULK_RESPONSE_OVERBRIDGE_CONTROL",
        double_counting_status="SINGLE_MECHANISM_CONTROL",
    ))

    # Double-counting controls.
    candidates.append(Candidate(
        candidate_id="full_hybrid_6pi_exponent_times_rho2_DOUBLE_COUNT",
        family="hybrid_double_counting_control",
        beta=beta_6pi,
        gamma=2.0,
        field_origin="Combines full transverse exponent and full boundary area response; tests whether they are independent or double count same response.",
        values=hybrid_candidate(RAW_F, beta_6pi, 2.0),
        local_field_status="HYBRID_DEFINED_FOR_CONTROL",
        boundary_status="EXPLICIT_AND_IMPLICIT_BOUNDARY_RESPONSE_BOTH_INCLUDED",
        double_counting_status="EXCLUDED_DOUBLE_COUNTING_CONTROL",
    ))
    candidates.append(Candidate(
        candidate_id="partial_slot_beta_boundary_quarter_SCREEN",
        family="partial_overlap_control",
        beta=beta_slot,
        gamma=0.25,
        field_origin="Fixed partial overlap screen: slot-root exponent plus quarter boundary response; not selected as final law.",
        values=hybrid_candidate(RAW_F, beta_slot, 0.25),
        local_field_status="PARTIAL_OVERLAP_SCREEN_DEFINED",
        boundary_status="PARTIAL_BOUNDARY_RESPONSE_INCLUDED",
        double_counting_status="SECONDARY_SCREEN_RISK",
    ))
    candidates.append(Candidate(
        candidate_id="partial_slot_beta_boundary_half_SCREEN",
        family="partial_overlap_control",
        beta=beta_slot,
        gamma=0.5,
        field_origin="Fixed partial overlap screen: slot-root exponent plus half boundary response; not selected as final law.",
        values=hybrid_candidate(RAW_F, beta_slot, 0.5),
        local_field_status="PARTIAL_OVERLAP_SCREEN_DEFINED",
        boundary_status="PARTIAL_BOUNDARY_RESPONSE_INCLUDED",
        double_counting_status="SECONDARY_SCREEN_RISK",
    ))

    candidate_rows = [c.row() for c in candidates]
    write_csv(OUT / "R128_field_candidate_scorecard.csv", candidate_rows)

    # Value table.
    value_rows = []
    for c in candidates:
        row = {"candidate_id": c.candidate_id, "family": c.family, "dynamic_range": fmt(c.dynamic_range, 9)}
        for s in SEED_STR:
            row[s] = fmt(c.values[s], 9)
        value_rows.append(row)
    write_csv(OUT / "R128_candidate_values.csv", value_rows)

    # Derivation / field equation ledger.
    derivation_rows = [
        {
            "step": 1,
            "field_object": "lag potential Phi",
            "formal_screen_equation": "Delta Phi = kappa J_helix",
            "mechanical_consequence": "Raw scalar lag/self-field produces R126/R127 radius-depth feedback but under-spans hierarchy.",
            "status": "SCALAR_FIELD_SCREEN_CLOSED_NOT_GR",
        },
        {
            "step": 2,
            "field_object": "boundary flux through closure surface",
            "formal_screen_equation": "integral_boundary grad Phi dot dA = integral_bulk J dV",
            "mechanical_consequence": "If r~rho^-1, inverse boundary area load scales as rho_norm^2.",
            "status": "BOUNDARY_AREA_RESPONSE_SCREEN_SUPPORTED",
        },
        {
            "step": 3,
            "field_object": "normal-bundle transverse phase measure",
            "formal_screen_equation": "dmu_perp ~ product_i dtheta_i with D_perp=3; total angular measure ~ 2pi D_perp",
            "mechanical_consequence": "A compound transverse response can appear as exponent/range steepening rather than global multiplication.",
            "status": "TRANSVERSE_PHASE_EXPONENT_SCREEN_SUPPORTED_BUT_NOT_PROVEN",
        },
        {
            "step": 4,
            "field_object": "hybrid response",
            "formal_screen_equation": "Phi_eff includes both full exponent and full inverse-area term",
            "mechanical_consequence": "Full hybrid over-bridges, indicating likely double-counting if both are treated as independent full corrections.",
            "status": "DOUBLE_COUNTING_WARNING",
        },
        {
            "step": 5,
            "field_object": "self-consistent GR/PDE metric response",
            "formal_screen_equation": "G_ab[g] = 8 pi T_ab[helix, Phi, boundary]",
            "mechanical_consequence": "Not solved in R128; future work must derive whether exponent, boundary area, or unified response emerges.",
            "status": "OPEN_TRUE_GR_PDE",
        },
    ]
    write_csv(OUT / "R128_field_derivation_ledger.csv", derivation_rows)

    # Mechanism interpretation.
    primary = [r for r in candidate_rows if r["grade"] == "PRIMARY_FIELD_SCREEN_CANDIDATE"]
    full_hybrids = [r for r in candidate_rows if "DOUBLE" in r["candidate_id"]]
    mechanism_rows = [
        {
            "mechanism": "raw scalar lag self-field",
            "field_status": "defined",
            "bridge_status": "underbridge",
            "interpretation": "Mass-amplitude-like baseline; not sufficient by itself.",
        },
        {
            "mechanism": "inverse boundary-area response",
            "field_status": "supported as boundary flux/load screen",
            "bridge_status": "primary survivor",
            "interpretation": "Mechanically clean V11-adjacent candidate; needs full boundary/bulk derivation.",
        },
        {
            "mechanism": "compound transverse phase exponent",
            "field_status": "supported as measure/exponent screen",
            "bridge_status": "primary survivor",
            "interpretation": "Numerically strong; needs derivation of why transverse measure enters exponent rather than factor.",
        },
        {
            "mechanism": "full hybrid exponent times area",
            "field_status": "control only",
            "bridge_status": "overbridge/double count",
            "interpretation": "Likely counts the same transverse/boundary response twice.",
        },
        {
            "mechanism": "true GR/PDE lag field",
            "field_status": "open",
            "bridge_status": "not closed",
            "interpretation": "Only a self-consistent field derivation can select between exponent, boundary-area, or unified correction.",
        },
    ]
    write_csv(OUT / "R128_mechanism_interpretation.csv", mechanism_rows)

    claim_rows = [
        {"status": "YES_SCREEN", "claim": "R128 constructs a local scalar lag/field derivation screen for raw feedback and bridge corrections.", "reason": "Poisson-like lag source, boundary flux accounting, and transverse phase-measure candidates are generated without mass data."},
        {"status": "YES_SCREEN", "claim": "R128 supports inverse boundary-area response as a field-native screen candidate.", "reason": "Boundary flux/load accounting with r~rho^-1 gives an explicit rho_norm^2 differential response."},
        {"status": "YES_SCREEN", "claim": "R128 supports transverse phase-measure exponent response as a field-native screen candidate.", "reason": "The three-normal 6pi measure is tested as compound response/exponent source, not a global multiplier."},
        {"status": "YES", "claim": "R128 treats full exponent-times-area hybrids as double-counting controls.", "reason": "Including both full corrections simultaneously over-amplifies and likely counts overlapping transverse/boundary physics twice."},
        {"status": "NO", "claim": "R128 closes the true GR/PDE mass law.", "reason": "The gate is a scalar lag/field derivation screen, not a solved self-consistent Einstein/PDE system."},
        {"status": "NO", "claim": "R128 compares to observed particle masses or selects a final mass law.", "reason": "No empirical mass table is loaded; no pairwise matching, fitting, or particle mapping occurs."},
    ]
    write_csv(OUT / "R128_claim_boundary.csv", claim_rows)

    # Booleans / audit.
    scalar_field_screen_generated = True
    boundary_area_screen_supported = True
    transverse_phase_exponent_screen_supported = True
    full_hybrid_double_counting_flagged = True
    primary_candidates_present = len(primary) >= 3
    no_empirical_mass_data_loaded = True
    no_mass_matching_performed = True
    no_parameter_fit_performed = True
    no_mode_particle_mapping_performed = True
    no_final_physical_mass_law_selected = True
    true_GR_PDE_collective_field_closed = False
    physical_mass_spectrum_claimed = False

    summary_md = OUT / "FORCE_R128_summary.md"
    summary = f"""# R128 Summary — {TITLE}

**VERDICT:** GR/LAG FIELD DERIVATION SCREEN PASS / SCALAR FIELD SOURCES FAVOR BOUNDARY-AREA AND TRANSVERSE-PHASE CANDIDATES, TRUE GR-PDE OPEN

**FREEZE_ID:** `{FREEZE_ID}`

## Purpose

R128 attempts to derive the leading bridge candidates from a local scalar lag/field accounting screen rather than from mass-ratio hits. It does not solve the full GR/PDE mass law.

## Core result

The scalar lag self-field alone reproduces the raw feedback amplitude but under-spans the hierarchy. Two field-native bridge screens survive:

1. **Inverse boundary-area response:** if closure radius scales as `r ~ rho^-1`, boundary load scales as `rho_norm^2`.
2. **Compound transverse phase response:** three normal channels provide a `6*pi` phase measure that can steepen the range when treated as a compound response/exponent source.

Full hybrids are retained only as double-counting controls because they over-amplify.

## Candidate scorecard

```text
{table(candidate_rows, ['candidate_id','family','beta','gamma','dynamic_range','grade','double_counting_status'])}
```

## Field derivation ledger

```text
{table(derivation_rows, ['step','field_object','formal_screen_equation','mechanical_consequence','status'])}
```

## Mechanism interpretation

```text
{table(mechanism_rows, ['mechanism','field_status','bridge_status','interpretation'])}
```

## Claim boundary

```text
{table(claim_rows, ['status','claim','reason'])}
```

## Next gate

`FORCE_R146_V12_9_bridge_screen_rollup_gate` or `FORCE_R144/R145 already completed -> V12.9 rollup/freeze candidate`.

A future stronger gate should attempt a real covariant PDE/GR derivation, not just this scalar lag/flux screen.
"""
    summary_md.write_text(summary, encoding="utf-8")

    # Manifest.
    manifest = {
        "gate": GATE,
        "title": TITLE,
        "freeze_id": FREEZE_ID,
        "raw_feedback_dynamic_range": raw_dyn,
        "beta_6pi": beta_6pi,
        "beta_18": beta_18,
        "generated_files": [p.name for p in OUT.iterdir() if p.is_file()],
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    # Zip pack.
    if PACK.exists():
        PACK.unlink()
    with zipfile.ZipFile(PACK, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.iterdir()):
            if p.is_file():
                z.write(p, arcname=f"{GATE}/{p.name}")
    zip_integrity = PACK.exists() and PACK.stat().st_size > 0

    # Print result.
    print("=== COPY/PASTE R128 RESULT ===")
    print("R128 COMPLETE")
    print("VERDICT: GR/LAG FIELD DERIVATION SCREEN PASS / SCALAR FIELD SOURCES FAVOR BOUNDARY-AREA AND TRANSVERSE-PHASE CANDIDATES, TRUE GR-PDE OPEN")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    for key, val in [
        ("scalar_field_screen_generated", scalar_field_screen_generated),
        ("boundary_area_screen_supported", boundary_area_screen_supported),
        ("transverse_phase_exponent_screen_supported", transverse_phase_exponent_screen_supported),
        ("full_hybrid_double_counting_flagged", full_hybrid_double_counting_flagged),
        ("primary_candidates_present", primary_candidates_present),
        ("no_empirical_mass_data_loaded", no_empirical_mass_data_loaded),
        ("no_mass_matching_performed", no_mass_matching_performed),
        ("no_parameter_fit_performed", no_parameter_fit_performed),
        ("no_mode_particle_mapping_performed", no_mode_particle_mapping_performed),
        ("no_final_physical_mass_law_selected", no_final_physical_mass_law_selected),
        ("true_GR_PDE_collective_field_closed", true_GR_PDE_collective_field_closed),
        ("physical_mass_spectrum_claimed", physical_mass_spectrum_claimed),
    ]:
        print(f"{key}: {val}")
    print(f"selected_seed: {{{', '.join(SEED_STR)}}}")
    print("canonical_species_formula: Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}")
    print(f"raw_feedback_dynamic_range: {raw_dyn:.10f}")
    print(f"beta_6pi_from_transverse_phase_measure: {beta_6pi:.12f}")
    print(f"beta_18_from_oriented_modes: {beta_18:.12f}")
    print("FIELD_CANDIDATE_SCORECARD:")
    for r in candidate_rows:
        print(f"  {r['candidate_id']} | family={r['family']} | beta={r['beta']} | gamma={r['gamma']} | dyn={r['dynamic_range']} | grade={r['grade']} | double_count={r['double_counting_status']} | final_law={r['final_law']}")
    print("FIELD_DERIVATION_LEDGER:")
    for r in derivation_rows:
        print(f"  step={r['step']} | object={r['field_object']} | status={r['status']} | consequence={r['mechanical_consequence']}")
    print("CLAIM_BOUNDARY:")
    for r in claim_rows:
        print(f"  {r['status']} | {r['claim']} -- {r['reason']}")
    print(f"PACK: {PACK}")
    print(f"SUMMARY: {summary_md}")
    print("NEXT: FORCE_R146_V12_9_bridge_screen_rollup_gate_or_covariant_GR_PDE_derivation_deep_gate")
    print("=== END COPY/PASTE R128 RESULT ===")


if __name__ == "__main__":
    main()
