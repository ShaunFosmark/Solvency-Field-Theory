# FORCE_R117 — Blind F(rho) Mass-Ratio Comparison Gate

## Verdict

BOXED: BLIND F(rho) MASS-RATIO SCREEN PASS / PAIRWISE HITS FOUND, FULL-SPECTRUM MASS LAW NOT CLOSED

## Frozen seed

BOXED: {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}

## Protocol boundary

- R116 candidate F(rho) values are frozen before empirical masses are loaded.
- No F(rho) parameter, exponent, coefficient, or expression is retuned after comparison.
- No rho-to-particle mapping is selected by hand.
- Pairwise ratio hits are screen signals only, not proof.
- A full PDE/GR self-energy derivation remains open.
- Physical spectrum identification remains open.

## Screening mass-table note

PDG-style screening table. Charged leptons are pole/rest masses; light and heavy quarks are quoted as conventional central-value quark-mass inputs and are scheme/scale dependent. This table is for blind ratio screening, not a final physical matching claim.

## Main results

- any_1pct_pairwise_hits: True
- any_5pct_pairwise_hits: True
- same_sector_5pct_present: True
- full_spectrum_dynamic_range_any_pass: False
- protocol_clean: True

## Best match by frozen functional

                 functional_id   rho_pair  F_ratio_ge_1          particle_pair  mass_ratio_ge_1  percent_error  same_sector
analytic_path_sqrt_1_plus_rho2   3/4 vs 1      1.131371  muon vs strange_quark         1.131246         0.0110        False
         self_overlap_eps_0p06 3/2 vs 5/3      2.164046 up_quark vs down_quark         2.162037         0.0929         True
     bend_energy_int_kappa2_ds 4/3 vs 3/2      1.400973     tau vs charm_quark         1.399102         0.1337        False
analytic_lens_proxy_recomputed 3/4 vs 4/3      4.213992   electron vs up_quark         4.227015         0.3081        False
           analytic_lens_proxy 3/4 vs 4/3      4.213991   electron vs up_quark         4.227015         0.3081        False
      analytic_curvature_proxy 5/4 vs 3/2      1.135385  muon vs strange_quark         1.131246         0.3658        False
                     rho_float 4/3 vs 3/2      1.125000  muon vs strange_quark         1.131246         0.5521        False
       analytic_pass_curvature 5/4 vs 4/3      1.137778  muon vs strange_quark         1.131246         0.5774        False
      overlap_density_eps_0p06   3/4 vs 1      1.410715     tau vs charm_quark         1.399102         0.8300        False
                  curve_length 2/3 vs 5/4      1.378440     tau vs charm_quark         1.399102         1.4768        False

## Threshold summary

                 functional_id  F_dynamic_range_max_over_min  best_relative_error  best_percent_error  hits_le_1pct  hits_le_5pct  hits_le_10pct  total_pairwise_comparisons multiple_comparison_warning
analytic_path_sqrt_1_plus_rho2                      2.000000             0.000110            0.011037             5            19             29                        1296                        HIGH
         self_overlap_eps_0p06                     11.692145             0.000929            0.092898             4            11             22                        1296                        HIGH
     bend_energy_int_kappa2_ds                      4.170643             0.001337            0.133725             2            10             27                        1296                        HIGH
analytic_lens_proxy_recomputed                     32.000000             0.003081            0.308085             2             7             24                        1296                        HIGH
           analytic_lens_proxy                     32.000116             0.003081            0.308100             2             7             24                        1296                        HIGH
      analytic_curvature_proxy                      4.000000             0.003658            0.365847             2            14             29                        1296                        HIGH
                     rho_float                      4.000000             0.005521            0.552109             2            12             29                        1296                        HIGH
       analytic_pass_curvature                     16.000000             0.005774            0.577398             1            15             25                        1296                        HIGH
      overlap_density_eps_0p06                      1.412293             0.008300            0.829980             2            14             31                        1296                        HIGH
                  curve_length                      4.063588             0.014768            1.476840             0             8             24                        1296                        HIGH

## Full-spectrum monotonic dynamic-range audit

                 functional_id  F_dynamic_range  target_mass_dynamic_range_top_over_electron  dynamic_range_shortfall_factor  monotonic_full_spectrum_dynamic_range_pass  rms_log_residual_after_one_scale
           analytic_lens_proxy        32.000116                                337711.065747                    10553.432457                                       False                          2.819363
analytic_lens_proxy_recomputed        32.000000                                337711.065747                    10553.470805                                       False                          2.819363
       analytic_pass_curvature        16.000000                                337711.065747                    21106.941609                                       False                          3.017756
         self_overlap_eps_0p06        11.692145                                337711.065747                    28883.585055                                       False                          3.079052
                  curve_length         4.063588                                337711.065747                    83106.620564                                       False                          3.413849
                     rho_float         4.000000                                337711.065747                    84427.766437                                       False                          3.436364
     bend_energy_int_kappa2_ds         4.170643                                337711.065747                    80973.386866                                       False                          3.445458
      analytic_curvature_proxy         4.000000                                337711.065747                    84427.766437                                       False                          3.451562
analytic_path_sqrt_1_plus_rho2         2.000000                                337711.065747                   168855.532873                                       False                          3.640568
      overlap_density_eps_0p06         1.412293                                337711.065747                   239122.544933                                       False                          3.752762

## Claim boundary

                                                                    claim status                                                                                                             reason
R117 compares frozen R116 F(rho) pairwise ratios to external mass ratios.    YES                     R116 functional values are frozen first; empirical masses are loaded only for blind screening.
                       R117 retunes or refits F(rho) after seeing masses.     NO                                     No functional exponents, coefficients, or mappings are optimized against data.
             R117 finds at least one pairwise ratio hit within 5 percent.    YES                         Pairwise hits are reported as exploratory signals only and carry multiple-comparison risk.
 R117 passes a full nine-mode monotonic mass-spectrum dynamic-range test.     NO                             The target charged-fermion range is far larger than the frozen R116 functional ranges.
                                  R117 selects a final physical mass law.     NO             Ranking is diagnostic only; final mass law selection requires R118/R119-level derivation and controls.
                                R117 maps rho modes to particles by hand.     NO Only pairwise ratios and sorted monotonic diagnostics are computed; no chosen rho-particle assignment is declared.
   R117 confirms the V12.8 nine-mode seed as the Standard Model spectrum.     NO            The result remains a mechanical/operator-geometric seed; physical spectrum identification remains open.
                     R117 closes full PDE/GR self-energy mass derivation.     NO        R116 functionals are toy/analytic geometry proxies; R118 is reserved for principled self-energy derivation.

## Gate audit

                                            test        result                                                                                    interpretation
candidate_functionals_frozen_before_mass_loading          PASS                                      R116 F(rho) values are frozen before empirical mass loading.
                      empirical_mass_data_loaded          PASS                       A nine charged-fermion screening mass table is loaded for blind comparison.
                functional_ratio_table_generated          PASS                                                  All frozen F(rho) pairwise ratios were computed.
                      mass_ratio_table_generated          PASS                                           All charged-fermion pairwise mass ratios were computed.
                      blind_comparison_generated          PASS                                            Every frozen F-ratio was compared to every mass ratio.
                          any_1pct_pairwise_hits        SCREEN                                                At least one pairwise hit within 1 percent exists.
                          any_5pct_pairwise_hits        SCREEN At least one pairwise hit within 5 percent exists; not proof because of multiple-comparison risk.
                        same_sector_5pct_present        SCREEN                                          At least one same-sector mass ratio has a 5 percent hit.
            full_spectrum_dynamic_range_any_pass FAIL_EXPECTED                                        No frozen R116 F spans the charged-fermion mass hierarchy.
                      no_parameter_fit_performed          PASS                                               No parameter was optimized against observed masses.
       no_functional_retuning_after_mass_loading          PASS                                             No F(rho) was altered after loading empirical masses.
              no_mode_particle_mapping_performed          PASS                                                   No rho mode was assigned to a particle by hand.
                  physical_mass_spectrum_claimed          OPEN                                                             No physical mass spectrum is claimed.
                 full_PDE_mass_functional_closed          OPEN                                             No full PDE/GR self-energy mass functional is closed.
