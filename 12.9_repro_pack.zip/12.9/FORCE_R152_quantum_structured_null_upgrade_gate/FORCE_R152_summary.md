# FORCE R152 Summary

VERDICT: QUANTUM-STRUCTURED NULL UPGRADE PASS / FORCE LABELS TESTED, NULL RISK REMAINS, FINAL LAW OPEN
candidate_freeze_hash: b8086fc25748f4c16b006a15d929f1c8407b829dfb349d7c45d0dfa9a126fe22
n_null_per_candidate: 1200

## Top candidate scores
- R139_boundary_area_rho2__Q_force_shape_topology_candidate | hits<5=15 | same=8 | lep=0 | p_hits=0.056667 | p_force_shuffle=0.105 | NULL_RISK_REMAINS_HIGH
- R137_6pi_exponent__Q_topology_class_proxy | hits<5=14 | same=6 | lep=2 | p_hits=0.11333 | p_force_shuffle=0.09 | NULL_RISK_REMAINS_HIGH
- raw_feedback_control__Q_force_shape_topology_candidate | hits<5=15 | same=8 | lep=0 | p_hits=0.125 | p_force_shuffle=0.13667 | NULL_RISK_REMAINS_HIGH
- R137_6pi_exponent__Q0_no_force_label_ablation | hits<5=13 | same=6 | lep=1 | p_hits=0.1875 | p_force_shuffle=NA | NULL_RISK_REMAINS_HIGH
- R137_6pi_exponent__Q_residue_holonomy_proxy | hits<5=13 | same=3 | lep=1 | p_hits=0.2025 | p_force_shuffle=0.16083 | NULL_RISK_REMAINS_HIGH
- R139_boundary_area_rho2__Q0_no_force_label_ablation | hits<5=11 | same=5 | lep=1 | p_hits=0.45083 | p_force_shuffle=NA | NULL_RISK_REMAINS_HIGH
- R139_boundary_area_rho2__Q_residue_holonomy_proxy | hits<5=9 | same=4 | lep=0 | p_hits=0.71833 | p_force_shuffle=0.82583 | NULL_RISK_REMAINS_HIGH
- R137_6pi_exponent__Q_force_shape_topology_candidate | hits<5=8 | same=5 | lep=3 | p_hits=0.81917 | p_force_shuffle=0.885 | NULL_RISK_REMAINS_HIGH