# R146: V12.9 Bridge Screen Rollup

**Freeze ID:** `SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM`  
**Verdict:** BRIDGE SCREEN ROLLUP PASS / HIERARCHY-SCALE CANDIDATES PRESERVED, PAIRWISE HITS DOWNGRADED, STRUCTURED MASS FUNCTIONAL NEXT

## Canonical seed

`{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}`

`Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}`

## Core result

R146 freezes the honest V12.9 state after R116-R145 plus R128.

The mass program now separates two objects:

```text
M(rho) = raw / bridge-corrected feedback amplitude
A(rho) = available focusing / required closure rent
```

`M(rho)` is mass-amplitude-like. `A(rho)` is closure-adequacy-like. They must not be confused.

## What survives

1. The raw radius/depth feedback baseline produces a large but insufficient dynamic range: `17999.8`.
2. R137/R139/R128 provide field-screen-supported bridge candidates near the hierarchy scale.
3. R141 freezes the primary candidates and excludes full hybrids as double-counting controls.
4. R145 downgrades pairwise hits: internal hit structure is not statistically unusual against the chosen random monotonic nulls.
5. Therefore the next step is not more one-dimensional ratio hunting; it is structured mass modeling using `(m,N)` and normal-bundle shape data.

## What does not survive as a claim

R146 does not claim a physical mass spectrum, a Standard Model mapping, a unique bridge law, a GR/PDE derivation, or empirical validation of the internal shape of `F(rho)`.

## Primary bridge candidates

candidate_id                              | family                   | dynamic_range | factor  | status         
------------------------------------------+--------------------------+---------------+---------+----------------
R137_transverse_phase_volume_6pi_exponent | compound_transverse_lens | 339288        | 1.00356 | FROZEN_SURVIVOR
R137_oriented_modes_18_exponent           | compound_transverse_lens | 323996        | 1.04348 | FROZEN_SURVIVOR
R139_boundary_area_rho2_candidate         | boundary_insolvency      | 287996        | 1.17391 | FROZEN_SURVIVOR

## Evidence status

evidence_item          | status                                | next_action                                                                         
-----------------------+---------------------------------------+-------------------------------------------------------------------------------------
dynamic_range_bridge   | SURVIVES_AS_SCREEN                    | Derive mechanism from field equations and/or structured winding data.               
pairwise_ratio_hits    | DOWNGRADED                            | Do not use hit counts as proof; use robustness/null controls in any public language.
endpoint_full_span_hit | LIMITED_EVIDENCE                      | Keep endpoint hits out of independent evidence counts.                              
quark_sector_hits      | SUPPORTIVE_WITH_CAVEAT                | Treat as screen-only until sector derivation exists.                                
lepton_internal_hit    | IMPORTANT_SCREEN_SIGNAL_BUT_NOT_PROOF | Preserve as a notable screen datum, not as validation.                              
one_dimensional_Frho   | INSUFFICIENT_RESOLUTION               | Move to structured M(rho,m,N,normal-bundle pattern).                                

## Claim boundary

claim                                                                                             | status           | safe_wording                                                                
--------------------------------------------------------------------------------------------------+------------------+-----------------------------------------------------------------------------
V12.9 identifies field-screen-supported bridge candidates for the mass-amplitude hierarchy scale. | YES_SCREEN       | V12.9 finds scalar-lag/geometry screens that can bridge the hierarchy scale.
V12.9 derives the physical charged-fermion mass spectrum.                                         | NO               | Physical mass-spectrum derivation remains open.                             
Pairwise mass-ratio hits prove the F(rho) shape.                                                  | NO               | Pairwise hits are exploratory and null-risk remains high.                   
The hierarchy-scale bridge is final.                                                              | NO               | Bridge candidates are frozen screens, not final laws.                       
Rent-normalized adequacy is the mass functional.                                                  | NO               | Rent-normalized adequacy is a closure/stability diagnostic.                 
The next mass program should include internal winding structure beyond rho.                       | YES_NEXT_PROGRAM | Next step is an (m,N)/shape-tensor mass-functional gate.                    

## Next gates

next_gate         | title                                            | goal                                                                                                                                
------------------+--------------------------------------------------+-------------------------------------------------------------------------------------------------------------------------------------
FORCE_R147        | (m,N) Shape-Tensor Mass Functional Gate          | Compute slot occupancy, normal-bundle shape/eccentricity, and support-ecology factors without masses.                               
FORCE_R148        | Structured Mass Screen / Null-Model Upgrade Gate | After shape factors are frozen, compare structured candidate against nulls that preserve dynamic range but not shape/slot structure.
DEEP_GR_PDE       | Covariant GR/Lag Field Derivation Deep Gate      | Derive whether inverse boundary-area, transverse exponent, or a unified correction emerges from a principled field equation.        
V12_9_PUBLIC_NOTE | Safe V12.9 Public Note / Appendix Draft          | Prepare safe language: hierarchy-scale bridge candidates and null-risk boundary.                                                    
