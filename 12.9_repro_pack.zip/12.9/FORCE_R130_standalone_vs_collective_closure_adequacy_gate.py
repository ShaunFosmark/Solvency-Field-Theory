#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R130_standalone_vs_collective_closure_adequacy_gate.py

SFT V12.9 / R130
Standalone vs Collective Closure Adequacy Gate

Purpose
-------
Test the mechanical question raised after R129:
    Which seed modes can pay closure rent as isolated helical/focusing modes,
    and which modes appear to require collective/support assistance?

Strict guardrails
-----------------
- No empirical particle masses are loaded.
- No mass ratios are compared.
- No rho-to-particle mapping is performed.
- No lepton/quark assignment is declared.
- No final physical mass law is selected.
- V12.8 species projection remains locked.

This is a mechanical adequacy screen only.
"""

from __future__ import annotations

import csv
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "FORCE_R130"
GATE_NAME = "standalone_vs_collective_closure_adequacy_gate"
OUTDIR = Path(f"{GATE_ID}_{GATE_NAME}")
PACK = Path(f"{GATE_ID}_{GATE_NAME}_pack.zip")

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUAL_SUPPORT = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
SPECIES_SET = set(SEED)
SUPPORT_SET = set(SEED + VIRTUAL_SUPPORT)

# R126 primary preview values. These are geometry-only feedback-screen outputs, not masses.
R126_PRIMARY = {
    Fraction(1, 2): dict(base_r=2.22945, fixed_r=2.17712, shrink=1.02403, depth=0.0982757, feedback_F=0.0199112),
    Fraction(2, 3): dict(base_r=1.73331, fixed_r=1.64811, shrink=1.05170, depth=0.2233780, feedback_F=0.0743514),
    Fraction(3, 4): dict(base_r=1.56357, fixed_r=1.45838, shrink=1.07213, depth=0.3218300, feedback_F=0.1315250),
    Fraction(1, 1): dict(base_r=1.21562, fixed_r=1.07352, shrink=1.13236, depth=0.7215580, feedback_F=0.4613520),
    Fraction(5, 4): dict(base_r=1.00000, fixed_r=0.724486, shrink=1.38029, depth=2.6297600, feedback_F=2.6297800),
    Fraction(4, 3): dict(base_r=0.945094, fixed_r=0.636210, shrink=1.48551, depth=3.8764800, feedback_F=4.3361700),
    Fraction(3, 2): dict(base_r=0.852543, fixed_r=0.476661, shrink=1.78857, depth=9.2335800, feedback_F=12.703900),
    Fraction(5, 3): dict(base_r=0.777461, fixed_r=0.327563, shrink=2.37347, depth=29.571500, feedback_F=49.876400),
    Fraction(2, 1): dict(base_r=0.662819, fixed_r=0.186493, shrink=3.55412, depth=156.35300, feedback_F=358.39700),
}

# Virtual support geometry values from earlier finite/self-energy screens are not needed for the primary split.
# They are intentionally not promoted to species.


def frac_s(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def R(x: Fraction) -> Fraction:
    return Fraction(2, 1) - x


def C(x: Fraction) -> Fraction:
    return Fraction(1, 1) / x


def partner_status(p: Fraction) -> str:
    if p in SPECIES_SET:
        return "species"
    if p in SUPPORT_SET:
        return "virtual_support"
    if p == 0:
        return "boundary_zero"
    if p > 0:
        return "outside_current_support"
    return "negative_or_invalid"


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        keys = []
        for row in rows:
            for key in row.keys():
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def table_print(rows: List[Dict[str, object]], columns: List[str], max_rows: int | None = None) -> str:
    if max_rows is not None:
        rows = rows[:max_rows]
    if not rows:
        return ""
    widths = {}
    for c in columns:
        widths[c] = max(len(c), max(len(str(r.get(c, ""))) for r in rows))
    lines = []
    lines.append(" | ".join(c.ljust(widths[c]) for c in columns))
    lines.append("-+-".join("-" * widths[c] for c in columns))
    for r in rows:
        lines.append(" | ".join(str(r.get(c, "")).ljust(widths[c]) for c in columns))
    return "\n".join(lines)


def build_support_dependency_table() -> List[Dict[str, object]]:
    rows = []
    for rho in SEED:
        partners = [("R", R(rho)), ("C", C(rho))]
        virtual_count = 0
        species_count = 0
        boundary_count = 0
        outside_count = 0
        for op, p in partners:
            st = partner_status(p)
            if st == "virtual_support":
                virtual_count += 1
            elif st == "species":
                species_count += 1
            elif st == "boundary_zero":
                boundary_count += 1
            else:
                outside_count += 1
            rows.append({
                "rho": frac_s(rho),
                "operator": op,
                "partner": frac_s(p) if p >= 0 else str(p),
                "partner_status": st,
                "species_partner_count_for_rho": "",
                "virtual_partner_count_for_rho": "",
                "boundary_partner_count_for_rho": "",
                "interpretation": "partner audit row",
            })
        rows.append({
            "rho": frac_s(rho),
            "operator": "SUMMARY",
            "partner": "",
            "partner_status": "",
            "species_partner_count_for_rho": species_count,
            "virtual_partner_count_for_rho": virtual_count,
            "boundary_partner_count_for_rho": boundary_count,
            "interpretation": (
                "fully internal species partners" if virtual_count == 0 and boundary_count == 0 and outside_count == 0 else
                "requires virtual support channel" if virtual_count > 0 else
                "touches projection boundary" if boundary_count > 0 else
                "has partner outside audited support"
            ),
        })
    return rows


def build_mode_adequacy_table() -> List[Dict[str, object]]:
    rows = []
    for rho in SEED:
        vals = R126_PRIMARY[rho]
        f = vals["feedback_F"]
        rent_ratio = f  # Unit closure-rent normalization screen; not a theorem.
        r_partner = R(rho)
        c_partner = C(rho)
        r_status = partner_status(r_partner)
        c_status = partner_status(c_partner)
        virtual_count = int(r_status == "virtual_support") + int(c_status == "virtual_support")
        boundary_count = int(r_status == "boundary_zero") + int(c_status == "boundary_zero")
        rent_pass = rent_ratio >= 1.0
        if not rent_pass:
            adequacy_class = "isolated_rent_fail_collective_candidate"
            interpretation = "isolated feedback is below unit closure-rent screen; collective/background support may be needed"
        elif virtual_count > 0:
            adequacy_class = "isolated_rent_pass_virtual_support_dependent"
            interpretation = "isolated feedback passes unit screen but V12.8 R/C closure uses support-only virtual channel(s)"
        elif boundary_count > 0:
            adequacy_class = "isolated_rent_pass_boundary_assisted"
            interpretation = "isolated feedback passes unit screen but one closure partner lies at the R-boundary"
        else:
            adequacy_class = "isolated_rent_pass_clean_internal"
            interpretation = "isolated feedback passes unit screen and R/C partners stay inside species seed"
        rows.append({
            "rho": frac_s(rho),
            "rho_float": round(float(rho), 12),
            "base_r": vals["base_r"],
            "fixed_r": vals["fixed_r"],
            "shrink": vals["shrink"],
            "depth": vals["depth"],
            "isolated_feedback_F": vals["feedback_F"],
            "unit_rent_ratio_screen": rent_ratio,
            "unit_rent_pass": rent_pass,
            "R_partner": frac_s(r_partner) if r_partner >= 0 else str(r_partner),
            "R_partner_status": r_status,
            "C_partner": frac_s(c_partner),
            "C_partner_status": c_status,
            "virtual_partner_count": virtual_count,
            "boundary_partner_count": boundary_count,
            "adequacy_class": adequacy_class,
            "interpretation": interpretation,
        })
    return rows


def build_collective_susceptibility_candidates(mode_rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    """Construct no-mass collective support screens.

    These are not laws. They test whether internal support features can define mode-dependent
    collective susceptibility factors without empirical masses.
    """
    out = []
    # Internal roots from R129-style natural exponents.
    normal_dim = 3
    slot_count = 4
    oriented_seed_count = 18
    for row in mode_rows:
        rho = Fraction(str(row["rho"])) if "/" not in str(row["rho"]) else Fraction(row["rho"])
        f = float(row["isolated_feedback_F"])
        r = float(row["fixed_r"])
        virtual_count = int(row["virtual_partner_count"])
        boundary_count = int(row["boundary_partner_count"])
        inv_radius = 1.0 / r
        # Normalize so rho=1 has factor 1 for radius-derived susceptibility.
        inv_radius_ref = 1.0 / R126_PRIMARY[Fraction(1, 1)]["fixed_r"]
        radius_sus = inv_radius / inv_radius_ref
        support_need = 1.0 + virtual_count + 0.5 * boundary_count
        factors = {
            "slot_root_radius_susceptibility_beta_1_over_4": radius_sus ** (1.0 / slot_count),
            "normal_volume_radius_susceptibility_beta_1_over_3": radius_sus ** (1.0 / normal_dim),
            "support_need_times_slot_root": support_need * (radius_sus ** (1.0 / slot_count)),
            "support_need_times_normal_root": support_need * (radius_sus ** (1.0 / normal_dim)),
            "oriented_seed_mean_field_root": oriented_seed_count ** (1.0 / slot_count),
        }
        for name, factor in factors.items():
            out.append({
                "rho": row["rho"],
                "adequacy_class": row["adequacy_class"],
                "candidate_factor_id": name,
                "factor": round(factor, 12),
                "collective_F_screen": round(f * factor, 12),
                "collective_unit_rent_pass": (f * factor) >= 1.0,
                "scheme": "no_mass_internal_structure_screen",
                "final_law": False,
            })
    return out


def summarize_split(mode_rows: List[Dict[str, object]], collective_rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    classes: Dict[str, int] = {}
    for r in mode_rows:
        classes[r["adequacy_class"]] = classes.get(r["adequacy_class"], 0) + 1
    rows = []
    for k in sorted(classes):
        rows.append({"split_component": k, "count": classes[k], "status": "REPORTED", "interpretation": "mechanical adequacy screen class"})

    # Count modes that fail isolated rent but pass at least one collective screen.
    by_rho: Dict[str, List[Dict[str, object]]] = {}
    for cr in collective_rows:
        by_rho.setdefault(str(cr["rho"]), []).append(cr)
    rescued = []
    for r in mode_rows:
        if r["adequacy_class"] == "isolated_rent_fail_collective_candidate":
            passes = [cr for cr in by_rho.get(str(r["rho"]), []) if cr["collective_unit_rent_pass"]]
            if passes:
                rescued.append(str(r["rho"]))
    rows.append({
        "split_component": "isolated_fail_but_collective_screen_pass",
        "count": len(rescued),
        "status": "YES_SCREEN" if rescued else "NO_SCREEN",
        "interpretation": ", ".join(rescued) if rescued else "none",
    })
    clean_internal = [str(r["rho"]) for r in mode_rows if r["adequacy_class"] == "isolated_rent_pass_clean_internal"]
    rows.append({
        "split_component": "clean_isolated_internal_candidates",
        "count": len(clean_internal),
        "status": "YES_SCREEN" if clean_internal else "NO_SCREEN",
        "interpretation": ", ".join(clean_internal) if clean_internal else "none",
    })
    return rows


def zip_dir(source_dir: Path, zip_path: Path) -> Tuple[bool, List[str]]:
    if zip_path.exists():
        zip_path.unlink()
    names = []
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(source_dir.rglob("*")):
            if path.is_file():
                arc = str(path.relative_to(source_dir.parent))
                z.write(path, arc)
                names.append(arc)
    try:
        with zipfile.ZipFile(zip_path, "r") as z:
            bad = z.testzip()
        return bad is None, names
    except Exception:
        return False, names


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)

    support_rows = build_support_dependency_table()
    mode_rows = build_mode_adequacy_table()
    collective_rows = build_collective_susceptibility_candidates(mode_rows)
    split_rows = summarize_split(mode_rows, collective_rows)

    no_empirical_mass_data_loaded = True
    no_mass_matching_performed = True
    no_parameter_fit_performed = True
    no_mode_particle_mapping_performed = True
    no_final_physical_mass_law_selected = True
    physical_mass_spectrum_claimed = False
    SM_mass_matching_claimed = False
    true_GR_PDE_collective_field_closed = False

    isolated_classes = {r["adequacy_class"] for r in mode_rows}
    standalone_candidates_present = any(r["adequacy_class"] == "isolated_rent_pass_clean_internal" for r in mode_rows)
    collective_needed_candidates_present = any(r["adequacy_class"] == "isolated_rent_fail_collective_candidate" for r in mode_rows)
    virtual_support_dependent_present = any(r["adequacy_class"] == "isolated_rent_pass_virtual_support_dependent" for r in mode_rows)
    boundary_assisted_present = any(r["adequacy_class"] == "isolated_rent_pass_boundary_assisted" for r in mode_rows)
    clean_two_family_split_closed = False

    verdict = "STANDALONE VS COLLECTIVE CLOSURE ADEQUACY SCREEN PASS / SPLIT CANDIDATES REPORTED, NO PARTICLE MAPPING"

    claim_boundary = [
        {"claim": "R130 tests standalone vs collective closure adequacy of V12.8/V12.9 seed modes.", "status": "YES_SCREEN", "reason": "Isolated feedback, R/C partner dependency, virtual support, and collective susceptibility screens are computed from internal geometry only."},
        {"claim": "R130 identifies modes that can pay isolated unit closure rent in the feedback screen.", "status": "YES_SCREEN", "reason": "Unit closure-rent normalization is used as a mechanical diagnostic, not as a theorem or physical mass law."},
        {"claim": "R130 proves a unique standalone/collective particle-sector split.", "status": "NO", "reason": "The split is diagnostic; no lepton/quark or physical sector assignment is declared."},
        {"claim": "R130 maps rho modes to leptons, quarks, or Standard Model particles.", "status": "NO", "reason": "No rho-to-particle mapping is performed."},
        {"claim": "R130 compares outputs to observed particle masses.", "status": "NO", "reason": "No empirical masses or target ratios are loaded."},
        {"claim": "R130 promotes virtual supports to stable species.", "status": "NO", "reason": "V12.8 species projection remains locked; virtual supports remain support-only."},
        {"claim": "R130 closes a true collective lag/GR/PDE field theorem.", "status": "NO", "reason": "Collective factors are mechanical screens, not a solved self-consistent field equation."},
    ]

    risk_register = [
        {"risk": "Unit closure-rent threshold is mistaken for a derived physical stability theorem.", "severity": "HIGH", "mitigation": "Label threshold as screen-only and keep unique closure theorem open."},
        {"risk": "Standalone/collective classes are read as lepton/quark assignments.", "severity": "HIGH", "mitigation": "No particle mapping is performed; use only mechanical class labels."},
        {"risk": "Collective susceptibility factors are treated as final vacuum/stator law.", "severity": "HIGH", "mitigation": "Report as candidates and reserve field derivation for later gates."},
        {"risk": "Virtual support dependency is mistaken for species promotion.", "severity": "MEDIUM", "mitigation": "Virtual supports stay species-inactive under the locked V12.8 projection."},
    ]

    files = {
        "mode_adequacy": OUTDIR / "R130_mode_adequacy_table.csv",
        "support_dependency": OUTDIR / "R130_support_dependency_table.csv",
        "collective_susceptibility": OUTDIR / "R130_collective_susceptibility_candidates.csv",
        "split_summary": OUTDIR / "R130_split_candidate_summary.csv",
        "claim_boundary": OUTDIR / "R130_claim_boundary.csv",
        "risk_register": OUTDIR / "R130_risk_register.csv",
        "verdict": OUTDIR / "R130_verdict.json",
        "summary": OUTDIR / "FORCE_R130_summary.md",
        "manifest": OUTDIR / "artifact_manifest.csv",
    }

    write_csv(files["mode_adequacy"], mode_rows)
    write_csv(files["support_dependency"], support_rows)
    write_csv(files["collective_susceptibility"], collective_rows)
    write_csv(files["split_summary"], split_rows)
    write_csv(files["claim_boundary"], claim_boundary)
    write_csv(files["risk_register"], risk_register)

    verdict_obj = {
        "gate": GATE_ID,
        "gate_name": GATE_NAME,
        "freeze_id": FREEZE_ID,
        "verdict": verdict,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "selected_seed": [frac_s(x) for x in SEED],
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
        "standalone_candidates_present": standalone_candidates_present,
        "collective_needed_candidates_present": collective_needed_candidates_present,
        "virtual_support_dependent_present": virtual_support_dependent_present,
        "boundary_assisted_present": boundary_assisted_present,
        "clean_two_family_split_closed": clean_two_family_split_closed,
        "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
        "no_mass_matching_performed": no_mass_matching_performed,
        "no_parameter_fit_performed": no_parameter_fit_performed,
        "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
        "no_final_physical_mass_law_selected": no_final_physical_mass_law_selected,
        "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
        "SM_mass_matching_claimed": SM_mass_matching_claimed,
        "true_GR_PDE_collective_field_closed": true_GR_PDE_collective_field_closed,
    }
    files["verdict"].write_text(json.dumps(verdict_obj, indent=2), encoding="utf-8")

    manifest_rows = []
    for k, path in files.items():
        if path.exists():
            manifest_rows.append({"artifact": path.name, "path": str(path), "bytes": path.stat().st_size})
    write_csv(files["manifest"], manifest_rows)

    summary_md = f"""# {GATE_ID}: Standalone vs Collective Closure Adequacy Gate

**Verdict:** {verdict}

**Freeze ID:** `{FREEZE_ID}`

## Purpose

R130 tests the mechanical split suggested after R129: whether some helical seed modes appear adequate as isolated closure/focusing modes while others require collective/support assistance.

No empirical masses are loaded, no mass matching is performed, and no rho-to-particle mapping is declared.

## Split summary

```text
{table_print(split_rows, ['split_component','count','status','interpretation'])}
```

## Mode adequacy preview

```text
{table_print(mode_rows, ['rho','isolated_feedback_F','unit_rent_pass','R_partner_status','C_partner_status','adequacy_class'], max_rows=12)}
```

## Claim boundary

```text
{table_print(claim_boundary, ['status','claim','reason'])}
```

## Next

`FORCE_R131_collective_susceptibility_derivation_gate` or `FORCE_R128_GR_lag_field_derivation_gate`.
"""
    files["summary"].write_text(summary_md, encoding="utf-8")

    zip_ok, zip_names = zip_dir(OUTDIR, PACK)
    verdict_obj["zip_integrity"] = "PASS" if zip_ok else "FAIL"
    verdict_obj["pack"] = str(PACK.resolve())
    files["verdict"].write_text(json.dumps(verdict_obj, indent=2), encoding="utf-8")

    # Console output for copy/paste.
    print("=== COPY/PASTE R130 RESULT ===")
    print("R130 COMPLETE")
    print(f"VERDICT: {verdict}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    for key in [
        "standalone_candidates_present",
        "collective_needed_candidates_present",
        "virtual_support_dependent_present",
        "boundary_assisted_present",
        "clean_two_family_split_closed",
        "no_empirical_mass_data_loaded",
        "no_mass_matching_performed",
        "no_parameter_fit_performed",
        "no_mode_particle_mapping_performed",
        "no_final_physical_mass_law_selected",
        "physical_mass_spectrum_claimed",
        "SM_mass_matching_claimed",
        "true_GR_PDE_collective_field_closed",
    ]:
        print(f"{key}: {verdict_obj[key]}")
    print("selected_seed: {" + ", ".join(frac_s(x) for x in SEED) + "}")
    print("canonical_species_formula: Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}")
    print("SPLIT_SUMMARY:")
    print(table_print(split_rows, ["split_component", "count", "status", "interpretation"]))
    print("MODE_ADEQUACY_PREVIEW:")
    print(table_print(mode_rows, ["rho", "isolated_feedback_F", "unit_rent_pass", "R_partner_status", "C_partner_status", "adequacy_class"]))
    print("CLAIM_BOUNDARY:")
    for row in claim_boundary:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print(f"PACK: {PACK.resolve()}")
    print(f"SUMMARY: {files['summary'].resolve()}")
    print("NEXT: FORCE_R131_collective_susceptibility_derivation_gate_or_FORCE_R128_GR_lag_field_derivation_gate")
    print("=== END COPY/PASTE R130 RESULT ===")


if __name__ == "__main__":
    main()
