#!/usr/bin/env python3
"""
FORCE_R148_structured_mass_screen_null_model_upgrade_gate.py

Structured Mass Screen / Null-Model Upgrade Gate

Purpose:
  After R147 generated geometry-only (m,N) / shape-tensor / support-ecology
  factors, this gate freezes structured candidate values first, then loads a
  compact charged-fermion screening table and compares pairwise ratios.

  It then runs upgraded null controls:
    1) random monotonic curves with the same dynamic range,
    2) shape-shuffle nulls that preserve the bridge baseline and the shape-factor
       distribution but randomize which mode receives which shape factor,
    3) one-dimensional ablation controls with no shape factor.

Hard boundaries:
  - no empirical mass data are loaded before candidate values are frozen/hash-logged
  - no fit, no retuning, no rho-to-particle mapping, no final law
  - endpoint/full-span hits are excluded from independent evidence metrics
  - quark hits are reported with caveat labels only
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import random
import statistics
import zipfile
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

GATE = "FORCE_R148_structured_mass_screen_null_model_upgrade_gate"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
OUT_DIR = Path.cwd() / GATE
PACK_PATH = Path.cwd() / f"{GATE}_pack.zip"
RNG_SEED = 147148
N_NULL = 1500

SEED_ORDER = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]

# R126 primary fixed-point feedback values, frozen as the mass-amplitude baseline.
RAW_FEEDBACK = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

# Frozen bridge definitions from R137/R139/R141.
D_RAW = RAW_FEEDBACK[Fraction(2, 1)] / RAW_FEEDBACK[Fraction(1, 2)]
BETA_6PI = math.log(6.0 * math.pi) / math.log(D_RAW)
BETA_18 = math.log(18.0) / math.log(D_RAW)


def fstr(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def safe_float(x: float) -> float:
    if abs(x) < 1e-15:
        return 0.0
    return float(x)


def sha256_obj(obj) -> str:
    s = json.dumps(obj, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


@dataclass
class ModeFeature:
    rho: Fraction
    m: int
    N: int
    denom_class: str
    occ: Tuple[int, int, int]
    eccentricity: float
    entropy_deficit: float
    ecology: str
    occupied_slots: int


def balanced_occupancy(m: int, N: int) -> Tuple[int, int, int]:
    """Distribute m writes over min(N,3) normal slots as evenly as possible."""
    k = min(max(N, 1), 3)
    q, r = divmod(m, k)
    vals = [q + (1 if i < r else 0) for i in range(k)]
    vals += [0] * (3 - k)
    vals.sort(reverse=True)
    return tuple(vals[:3])


def entropy_deficit(occ: Tuple[int, int, int]) -> float:
    total = sum(occ)
    if total <= 0:
        return 1.0
    probs = [v / total for v in occ if v > 0]
    H = -sum(p * math.log(p) for p in probs)
    return max(0.0, min(1.0, 1.0 - H / math.log(3.0)))


def eccentricity(occ: Tuple[int, int, int]) -> float:
    total = sum(occ)
    if total <= 0:
        return 0.0
    probs = [v / total for v in occ]
    # normalized distance from isotropic distribution (1/3,1/3,1/3)
    return math.sqrt(1.5 * sum((p - 1.0 / 3.0) ** 2 for p in probs))


def ecology_for_mode(rho: Fraction) -> str:
    if rho in {Fraction(5, 4), Fraction(5, 3)}:
        return "virtual_support_dependent"
    if rho == Fraction(2, 1):
        return "boundary_assisted"
    return "clean_internal"


def denom_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, "outside_seed_denominator_class")


def make_features() -> Dict[Fraction, ModeFeature]:
    features: Dict[Fraction, ModeFeature] = {}
    for rho in SEED_ORDER:
        m, N = rho.numerator, rho.denominator
        occ = balanced_occupancy(m, N)
        features[rho] = ModeFeature(
            rho=rho,
            m=m,
            N=N,
            denom_class=denom_class(N),
            occ=occ,
            eccentricity=eccentricity(occ),
            entropy_deficit=entropy_deficit(occ),
            ecology=ecology_for_mode(rho),
            occupied_slots=sum(1 for v in occ if v > 0),
        )
    return features


FEATURES = make_features()


def bridge_values(kind: str) -> Dict[Fraction, float]:
    if kind == "R137_6pi_exponent":
        return {rho: RAW_FEEDBACK[rho] ** (1.0 + BETA_6PI) for rho in SEED_ORDER}
    if kind == "R137_oriented18_exponent":
        return {rho: RAW_FEEDBACK[rho] ** (1.0 + BETA_18) for rho in SEED_ORDER}
    if kind == "R139_boundary_area_rho2":
        return {rho: RAW_FEEDBACK[rho] * (float(rho) / 0.5) ** 2 for rho in SEED_ORDER}
    if kind == "raw_feedback_control":
        return dict(RAW_FEEDBACK)
    raise ValueError(kind)


def normalize_geom_mean(factors: Dict[Fraction, float]) -> Dict[Fraction, float]:
    logs = [math.log(max(v, 1e-12)) for v in factors.values()]
    gm = math.exp(sum(logs) / len(logs))
    return {k: v / gm for k, v in factors.items()}


def shape_factors(kind: str) -> Dict[Fraction, float]:
    vals: Dict[Fraction, float] = {}
    for rho, ft in FEATURES.items():
        ecc = ft.eccentricity
        ent = ft.entropy_deficit
        fill = ft.occupied_slots / 3.0
        ecology_mult = {
            "clean_internal": 1.0,
            "virtual_support_dependent": 1.125,
            "boundary_assisted": 1.25,
        }[ft.ecology]
        if kind == "G0_no_shape_ablation":
            v = 1.0
        elif kind == "G_eccentricity_linear":
            v = 1.0 + ecc
        elif kind == "G_entropy_deficit_linear":
            v = 1.0 + ent
        elif kind == "G_slot_fill_inverse":
            v = 1.0 / max(fill, 1e-9)
        elif kind == "G_shape_ecology_composite":
            # Conservative geometry-only composite: anisotropy, entropy deficit, and support ecology.
            v = (1.0 + 0.45 * ecc + 0.30 * ent) * ecology_mult
        elif kind == "G_denominator_class_root":
            v = math.sqrt(ft.N)
        else:
            raise ValueError(kind)
        vals[rho] = v
    if kind == "G0_no_shape_ablation":
        return vals
    return normalize_geom_mean(vals)


PRIMARY_BRIDGES = [
    "R137_6pi_exponent",
    "R137_oriented18_exponent",
    "R139_boundary_area_rho2",
]
SHAPES = [
    "G0_no_shape_ablation",
    "G_shape_ecology_composite",
    "G_eccentricity_linear",
    "G_entropy_deficit_linear",
    "G_slot_fill_inverse",
    "G_denominator_class_root",
]


@dataclass
class Candidate:
    candidate_id: str
    bridge: str
    shape: str
    tier: str
    values: Dict[Fraction, float]


def make_candidates() -> List[Candidate]:
    cands: List[Candidate] = []
    for bridge in PRIMARY_BRIDGES:
        bvals = bridge_values(bridge)
        for shape in SHAPES:
            svals = shape_factors(shape)
            vals = {rho: bvals[rho] * svals[rho] for rho in SEED_ORDER}
            tier = "ablation" if shape == "G0_no_shape_ablation" else "structured"
            cands.append(Candidate(f"{bridge}__{shape}", bridge, shape, tier, vals))
    # keep raw as a range-fail control
    cands.append(Candidate("raw_feedback_control__G0_no_shape_ablation", "raw_feedback_control", "G0_no_shape_ablation", "control", bridge_values("raw_feedback_control")))
    return cands


# Empirical screening table loaded only after candidate freeze.
def load_mass_table_after_freeze() -> Dict[str, Tuple[float, str]]:
    # Compact PDG-style screening values in MeV. Quark masses are scheme/scale-sensitive.
    return {
        "electron": (0.51099895, "lepton"),
        "muon": (105.6583755, "lepton"),
        "tau": (1776.86, "lepton"),
        "up_quark": (2.16, "quark"),
        "down_quark": (4.67, "quark"),
        "strange_quark": (93.4, "quark"),
        "charm_quark": (1270.0, "quark"),
        "bottom_quark": (4180.0, "quark"),
        "top_quark": (172760.0, "quark"),
    }


def pair_ratios_from_values(values: Dict[Fraction, float]) -> List[dict]:
    rows = []
    for i, a in enumerate(SEED_ORDER):
        for b in SEED_ORDER[i + 1:]:
            va, vb = values[a], values[b]
            if va <= 0 or vb <= 0:
                continue
            if va >= vb:
                hi, lo = a, b
                ratio = va / vb
            else:
                hi, lo = b, a
                ratio = vb / va
            rows.append({
                "mode_hi": hi,
                "mode_lo": lo,
                "mode_pair": f"{fstr(hi)} vs {fstr(lo)}",
                "ratio": ratio,
                "endpoint": set([hi, lo]) == set([Fraction(2, 1), Fraction(1, 2)]),
            })
    return rows


def mass_ratios(masses: Dict[str, Tuple[float, str]]) -> List[dict]:
    keys = list(masses)
    rows = []
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            ma, sa = masses[a]
            mb, sb = masses[b]
            if ma >= mb:
                hi, lo = a, b
                ratio = ma / mb
                s_hi, s_lo = sa, sb
            else:
                hi, lo = b, a
                ratio = mb / ma
                s_hi, s_lo = sb, sa
            rows.append({
                "mass_hi": hi,
                "mass_lo": lo,
                "mass_pair": f"{hi} vs {lo}",
                "ratio": ratio,
                "same_sector": s_hi == s_lo,
                "lepton_lepton": s_hi == "lepton" and s_lo == "lepton",
                "quark_quark": s_hi == "quark" and s_lo == "quark",
            })
    return rows


def pct_error(a: float, b: float) -> float:
    return abs(math.log(a / b)) * 100.0  # symmetric log percent approx


def score_candidate(values: Dict[Fraction, float], mass_rows: List[dict]) -> Tuple[dict, List[dict]]:
    matches = []
    for pr in pair_ratios_from_values(values):
        for mr in mass_rows:
            err = pct_error(pr["ratio"], mr["ratio"])
            if err <= 5.0:
                matches.append({
                    **pr,
                    **mr,
                    "err_pct": err,
                    "independent": not pr["endpoint"],
                })
    independent = [m for m in matches if m["independent"]]
    same = [m for m in independent if m["same_sector"]]
    lep = [m for m in independent if m["lepton_lepton"]]
    quark = [m for m in independent if m["quark_quark"]]
    best_ind = min((m["err_pct"] for m in independent), default=999.0)
    score = {
        "ind_hits_5pct": len(independent),
        "same_sector_ind_5pct": len(same),
        "lepton_ind_5pct": len(lep),
        "quark_ind_5pct": len(quark),
        "best_err_ind_pct": best_ind,
        "endpoint_hits_5pct": sum(1 for m in matches if m["endpoint"]),
    }
    matches.sort(key=lambda x: x["err_pct"])
    return score, matches


def dynamic_range(values: Dict[Fraction, float]) -> float:
    vals = list(values.values())
    return max(vals) / min(vals)


def is_monotonic_by_rho(values: Dict[Fraction, float]) -> bool:
    vals = [values[rho] for rho in SEED_ORDER]
    return all(vals[i] <= vals[i+1] for i in range(len(vals)-1))


def random_monotonic_values(dynamic: float, rng: random.Random) -> Dict[Fraction, float]:
    # fixed endpoints, random ordered internal log-values
    logs = sorted(rng.random() * math.log(dynamic) for _ in range(len(SEED_ORDER) - 2))
    all_logs = [0.0] + logs + [math.log(dynamic)]
    return {rho: math.exp(x) for rho, x in zip(SEED_ORDER, all_logs)}


def shape_shuffle_values(bridge: str, shape: str, rng: random.Random) -> Dict[Fraction, float]:
    bvals = bridge_values(bridge)
    factors = list(shape_factors(shape).values())
    rng.shuffle(factors)
    return {rho: bvals[rho] * factors[i] for i, rho in enumerate(SEED_ORDER)}


def empirical_p_high(null_values: List[float], obs: float) -> float:
    return sum(1 for x in null_values if x >= obs) / max(len(null_values), 1)


def empirical_p_low(null_values: List[float], obs: float) -> float:
    return sum(1 for x in null_values if x <= obs) / max(len(null_values), 1)


def write_csv(path: Path, rows: List[dict], fields: List[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rng = random.Random(RNG_SEED)

    # Candidate generation and freeze happen before mass table loading.
    candidates = make_candidates()
    freeze_payload = {
        "seed_order": [fstr(x) for x in SEED_ORDER],
        "raw_feedback": {fstr(k): v for k, v in RAW_FEEDBACK.items()},
        "beta_6pi": BETA_6PI,
        "beta_18": BETA_18,
        "features": {
            fstr(r): {
                "m": ft.m, "N": ft.N, "occ": ft.occ,
                "eccentricity": ft.eccentricity,
                "entropy_deficit": ft.entropy_deficit,
                "ecology": ft.ecology,
                "denom_class": ft.denom_class,
            } for r, ft in FEATURES.items()
        },
        "candidates": {
            c.candidate_id: {fstr(rho): c.values[rho] for rho in SEED_ORDER}
            for c in candidates
        },
    }
    freeze_hash = sha256_obj(freeze_payload)
    (OUT_DIR / "R148_candidate_freeze.json").write_text(json.dumps(freeze_payload, indent=2, sort_keys=True), encoding="utf-8")

    masses = load_mass_table_after_freeze()
    mass_rows = mass_ratios(masses)
    mass_hash = sha256_obj(masses)

    # Score observed candidates.
    cand_rows = []
    all_match_rows = []
    for c in candidates:
        score, matches = score_candidate(c.values, mass_rows)
        row = {
            "candidate_id": c.candidate_id,
            "bridge": c.bridge,
            "shape": c.shape,
            "tier": c.tier,
            "dynamic_range": dynamic_range(c.values),
            "monotonic_by_rho": is_monotonic_by_rho(c.values),
            **score,
        }
        cand_rows.append(row)
        for m in matches[:20]:
            all_match_rows.append({"candidate_id": c.candidate_id, "tier": c.tier, **m})

    # Nulls.
    null_summary = []
    for row in cand_rows:
        cid = row["candidate_id"]
        c = next(x for x in candidates if x.candidate_id == cid)
        obs_hits = row["ind_hits_5pct"]
        obs_same = row["same_sector_ind_5pct"]
        obs_lep = row["lepton_ind_5pct"]
        obs_best = row["best_err_ind_pct"]
        dyn = row["dynamic_range"]

        null_hits = []
        null_same = []
        null_lep = []
        null_best = []
        for _ in range(N_NULL):
            vals = random_monotonic_values(dyn, rng)
            sc, _ = score_candidate(vals, mass_rows)
            null_hits.append(sc["ind_hits_5pct"])
            null_same.append(sc["same_sector_ind_5pct"])
            null_lep.append(sc["lepton_ind_5pct"])
            null_best.append(sc["best_err_ind_pct"])

        shape_null_available = c.shape != "G0_no_shape_ablation" and c.bridge in PRIMARY_BRIDGES
        sh_hits = sh_same = sh_lep = sh_best = []
        if shape_null_available:
            sh_hits, sh_same, sh_lep, sh_best = [], [], [], []
            for _ in range(N_NULL):
                vals = shape_shuffle_values(c.bridge, c.shape, rng)
                sc, _ = score_candidate(vals, mass_rows)
                sh_hits.append(sc["ind_hits_5pct"])
                sh_same.append(sc["same_sector_ind_5pct"])
                sh_lep.append(sc["lepton_ind_5pct"])
                sh_best.append(sc["best_err_ind_pct"])

        p_hits = empirical_p_high(null_hits, obs_hits)
        p_same = empirical_p_high(null_same, obs_same)
        p_lep = empirical_p_high(null_lep, obs_lep)
        p_best = empirical_p_low(null_best, obs_best)
        shape_p_hits = empirical_p_high(sh_hits, obs_hits) if shape_null_available else "NA"
        shape_p_same = empirical_p_high(sh_same, obs_same) if shape_null_available else "NA"
        shape_p_best = empirical_p_low(sh_best, obs_best) if shape_null_available else "NA"
        metrics_under = sum(1 for p in [p_hits, p_same, p_lep, p_best] if isinstance(p, float) and p <= 0.05)
        shape_metrics_under = 0
        if shape_null_available:
            shape_metrics_under = sum(1 for p in [shape_p_hits, shape_p_same, shape_p_best] if isinstance(p, float) and p <= 0.05)

        result = "NULL_RISK_REMAINS_HIGH"
        if metrics_under >= 2 or shape_metrics_under >= 2:
            result = "STRUCTURE_SIGNAL_SCREEN_PRESENT"
        elif metrics_under >= 1 or shape_metrics_under >= 1:
            result = "WEAK_STRUCTURE_SIGNAL_SCREEN"

        null_summary.append({
            "candidate_id": cid,
            "tier": row["tier"],
            "dynamic_range": dyn,
            "obs_ind_hits_5pct": obs_hits,
            "obs_same_sector_ind_5pct": obs_same,
            "obs_lepton_ind_5pct": obs_lep,
            "obs_best_err_ind_pct": obs_best,
            "monotonic_p_hits": p_hits,
            "monotonic_p_same": p_same,
            "monotonic_p_lepton": p_lep,
            "monotonic_p_best": p_best,
            "shape_shuffle_p_hits": shape_p_hits,
            "shape_shuffle_p_same": shape_p_same,
            "shape_shuffle_p_best": shape_p_best,
            "metrics_under_0p05": metrics_under,
            "shape_metrics_under_0p05": shape_metrics_under,
            "result": result,
        })

    # Feature tables.
    feat_rows = []
    for rho in SEED_ORDER:
        ft = FEATURES[rho]
        feat_rows.append({
            "rho": fstr(rho), "m": ft.m, "N": ft.N, "denom_class": ft.denom_class,
            "occ": str(ft.occ), "eccentricity": ft.eccentricity,
            "entropy_deficit": ft.entropy_deficit, "ecology": ft.ecology,
            "occupied_slots": ft.occupied_slots,
        })

    # Write artifacts.
    write_csv(OUT_DIR / "R148_shape_features.csv", feat_rows, list(feat_rows[0].keys()))
    write_csv(OUT_DIR / "R148_candidate_scores.csv", cand_rows, list(cand_rows[0].keys()))
    write_csv(OUT_DIR / "R148_top_matches.csv", all_match_rows, [
        "candidate_id", "tier", "mode_pair", "mass_pair", "ratio", "err_pct", "same_sector", "lepton_lepton", "quark_quark", "endpoint", "independent"
    ])
    write_csv(OUT_DIR / "R148_null_summary.csv", null_summary, list(null_summary[0].keys()))

    # Select headline rows.
    structured_rows = [r for r in cand_rows if r["tier"] == "structured"]
    any_structured_hits = any(r["ind_hits_5pct"] > 0 for r in structured_rows)
    any_same = any(r["same_sector_ind_5pct"] > 0 for r in structured_rows)
    any_lepton = any(r["lepton_ind_5pct"] > 0 for r in structured_rows)
    unusual_rows = [r for r in null_summary if r["result"] in {"STRUCTURE_SIGNAL_SCREEN_PRESENT", "WEAK_STRUCTURE_SIGNAL_SCREEN"}]
    strong_unusual = [r for r in null_summary if r["result"] == "STRUCTURE_SIGNAL_SCREEN_PRESENT"]

    top_by_hits = sorted(null_summary, key=lambda r: (-int(r["obs_ind_hits_5pct"]), float(r["obs_best_err_ind_pct"])))[:8]
    top_matches = sorted(all_match_rows, key=lambda r: float(r["err_pct"]))[:16]

    verdict = "STRUCTURED MASS SCREEN / NULL-MODEL UPGRADE PASS / STRUCTURE SIGNAL REPORTED, FINAL LAW OPEN"
    if not strong_unusual:
        verdict = "STRUCTURED MASS SCREEN / NULL-MODEL UPGRADE PASS / STRUCTURE TESTED, NULL RISK REMAINS, FINAL LAW OPEN"

    summary_lines = []
    summary_lines.append(f"# {GATE} summary")
    summary_lines.append("")
    summary_lines.append(f"VERDICT: {verdict}")
    summary_lines.append(f"FREEZE_ID: {FREEZE_ID}")
    summary_lines.append(f"candidate_freeze_hash: {freeze_hash}")
    summary_lines.append(f"mass_ratio_screen_table_hash: {mass_hash}")
    summary_lines.append("")
    summary_lines.append("## Top null summary rows")
    for r in top_by_hits:
        summary_lines.append(
            f"- {r['candidate_id']} | hits={r['obs_ind_hits_5pct']} | same={r['obs_same_sector_ind_5pct']} | "
            f"lep={r['obs_lepton_ind_5pct']} | best={float(r['obs_best_err_ind_pct']):.4g}% | "
            f"p_hits={float(r['monotonic_p_hits']):.4g} | p_same={float(r['monotonic_p_same']):.4g} | "
            f"shape_p_hits={r['shape_shuffle_p_hits']} | result={r['result']}"
        )
    summary_lines.append("")
    summary_lines.append("## Claim boundary")
    summary_lines.extend([
        "- YES_SCREEN: R148 freezes R147 structured shape candidates before loading mass ratios.",
        "- YES_SCREEN: R148 tests structured candidates against monotonic dynamic-range nulls and shape-shuffle nulls.",
        "- NO: R148 does not retune shape factors, exponents, bridge candidates, or mode mappings.",
        "- NO: R148 does not claim a final physical mass law or Standard Model spectrum.",
        "- NO: R148 does not close true GR/PDE mass dynamics.",
    ])
    (OUT_DIR / "FORCE_R148_summary.md").write_text("\n".join(summary_lines), encoding="utf-8")

    # Zip pack.
    if PACK_PATH.exists():
        PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT_DIR.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(OUT_DIR.parent))
    zip_ok = PACK_PATH.exists() and PACK_PATH.stat().st_size > 0

    # Print concise copy/paste result.
    print("=== COPY/PASTE R148 RESULT ===")
    print("R148 COMPLETE")
    print(f"VERDICT: {verdict}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    print(f"candidate_values_frozen_before_mass_loading: True")
    print(f"structured_shape_candidates_loaded: True")
    print(f"mass_ratio_screen_table_loaded_after_freeze: True")
    print(f"monotonic_nulls_generated: True")
    print(f"shape_shuffle_nulls_generated: True")
    print(f"n_null_per_candidate: {N_NULL}")
    print(f"candidate_freeze_hash: {freeze_hash}")
    print(f"mass_ratio_screen_table_hash: {mass_hash}")
    print(f"structured_internal_hits_present: {any_structured_hits}")
    print(f"structured_same_sector_hits_present: {any_same}")
    print(f"structured_lepton_hits_present: {any_lepton}")
    print(f"null_unusual_signal_present: {bool(unusual_rows)}")
    print(f"strong_null_unusual_signal_present: {bool(strong_unusual)}")
    print(f"no_parameter_fit_performed: True")
    print(f"no_functional_retuning_after_mass_loading: True")
    print(f"no_mode_particle_mapping_performed: True")
    print(f"no_final_physical_mass_law_selected: True")
    print(f"physical_mass_spectrum_claimed: False")
    print(f"true_GR_PDE_mass_dynamics_closed: False")
    print(f"selected_seed: {{{', '.join(fstr(x) for x in SEED_ORDER)}}}")
    print("TOP_STRUCTURED_NULL_SUMMARY:")
    for r in top_by_hits:
        print(
            f"  {r['candidate_id']} | tier={r['tier']} | dyn={float(r['dynamic_range']):.6g} | "
            f"hits<=5%={r['obs_ind_hits_5pct']} | same<={r['obs_same_sector_ind_5pct']} | "
            f"lep<={r['obs_lepton_ind_5pct']} | best={float(r['obs_best_err_ind_pct']):.4g}% | "
            f"p_hits={float(r['monotonic_p_hits']):.4g} | p_same={float(r['monotonic_p_same']):.4g} | "
            f"shape_p_hits={r['shape_shuffle_p_hits']} | result={r['result']}"
        )
    print("TOP_MATCHES:")
    for m in top_matches[:12]:
        print(
            f"  {m['candidate_id']} | {m['mode_pair']} | F={float(m['ratio']):.6g} | "
            f"{m['mass_pair']} | err={float(m['err_pct']):.4g}% | same_sector={m['same_sector']} | "
            f"lepton={m['lepton_lepton']} | quark={m['quark_quark']} | endpoint={m['endpoint']}"
        )
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R148 tests frozen structured (m,N)/shape candidates against mass-ratio and upgraded null screens. -- Candidate values are hashed before mass loading.")
    print("  YES_SCREEN | R148 runs monotonic dynamic-range nulls and shape-shuffle nulls. -- This tests whether structured features add evidence beyond one-dimensional range.")
    print("  NO | R148 retunes shape factors, bridge corrections, or mappings. -- All definitions are fixed before mass loading.")
    print("  NO | R148 selects a final physical mass law. -- This is a screen/null gate only.")
    print("  NO | R148 maps rho modes to particles. -- Pairwise ratios are compared without assignments.")
    print("  NO | R148 closes true GR/PDE dynamics. -- Field-equation derivation remains open.")
    print(f"PACK: {PACK_PATH}")
    print(f"SUMMARY: {OUT_DIR / 'FORCE_R148_summary.md'}")
    print("NEXT: FORCE_R149_shape_factor_ablation_denominator_class_control_gate_or_DEEP_GR_PDE")
    print("=== END COPY/PASTE R148 RESULT ===")


if __name__ == "__main__":
    main()
