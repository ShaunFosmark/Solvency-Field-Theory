#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R119_renormalization_embedding_invariance_closure_gate.py

SFT V12.9 / FORCE_R119
Renormalization / Embedding-Invariance Closure Gate

Purpose
-------
R118 produced candidate helical self-energy / focusing functionals from rho only,
but explicitly left the regulator/counterterm prescription and torus-embedding
choice open. R119 tests whether those candidate functionals are stable under
regulator and embedding variations, WITHOUT loading empirical particle masses,
WITHOUT doing mass matching, and WITHOUT selecting a final physical mass law.

This script is dependency-free: Python standard library only.

Outputs
-------
Creates:
  FORCE_R119_renormalization_embedding_invariance_closure_gate/
    FORCE_R119_summary.md
    FORCE_R119_verdict.json
    FORCE_R119_gate_audit.csv
    FORCE_R119_parameter_grid.csv
    FORCE_R119_mode_geometry_samples.csv
    FORCE_R119_kernel_regulator_samples.csv
    FORCE_R119_functional_value_samples.csv
    FORCE_R119_invariance_summary.csv
    FORCE_R119_rank_signature_summary.csv
    FORCE_R119_regularization_sensitivity.csv
    FORCE_R119_claim_boundary.csv
    FORCE_R119_risk_register.csv
    artifact_manifest.csv
  FORCE_R119_renormalization_embedding_invariance_closure_gate_pack.zip

Expected good verdict
---------------------
RENORMALIZATION / EMBEDDING-INVARIANCE SCREEN PASS / UNIQUE SELF-ENERGY MASS LAW NOT CLOSED
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import statistics
import sys
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

GATE_ID = "FORCE_R119"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
TITLE = "Renormalization / Embedding-Invariance Closure Gate"
VERDICT_PASS = "RENORMALIZATION / EMBEDDING-INVARIANCE SCREEN PASS / UNIQUE SELF-ENERGY MASS LAW NOT CLOSED"

ROOT = Path.cwd()
OUT_DIR = ROOT / "FORCE_R119_renormalization_embedding_invariance_closure_gate"
PACK_PATH = ROOT / "FORCE_R119_renormalization_embedding_invariance_closure_gate_pack.zip"

# V12.8 locked mechanical/operator-geometric seed.
SEED_RHOS = [
    Fraction(1, 2),
    Fraction(2, 3),
    Fraction(3, 4),
    Fraction(1, 1),
    Fraction(5, 4),
    Fraction(4, 3),
    Fraction(3, 2),
    Fraction(5, 3),
    Fraction(2, 1),
]

# Support-active but species-inactive controls from V12.8/R111/R118.
VIRTUAL_RHOS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

# A few non-support controls help keep the tables honest without affecting species claims.
CONTROL_RHOS = [Fraction(1, 4), Fraction(5, 6), Fraction(7, 4), Fraction(3, 1)]

ALL_RHOS = SEED_RHOS + VIRTUAL_RHOS + CONTROL_RHOS

# Embedding grid. R/a is varied deliberately; no value is chosen from data.
# Major radius R and minor/tube radius a define a closed toroidal helix representative.
EMBEDDINGS = [
    (2.25, 0.28),
    (2.25, 0.40),
    (2.25, 0.55),
    (2.75, 0.28),
    (2.75, 0.40),
    (2.75, 0.55),
    (3.50, 0.28),
    (3.50, 0.40),
    (3.50, 0.55),
    (4.50, 0.28),
    (4.50, 0.40),
    (4.50, 0.55),
]

# Regulator grid as a fraction of minor radius a.
EPS_REL_VALUES = [0.035, 0.055, 0.085, 0.130, 0.200]

# Sampling resolution for one full closed period u in [0, 2π].
N_SAMPLES = 120

CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}"


def frac_s(fr: Fraction) -> str:
    if fr.denominator == 1:
        return str(fr.numerator)
    return f"{fr.numerator}/{fr.denominator}"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_csv(path: Path, rows: Sequence[Dict[str, object]], fieldnames: Sequence[str] | None = None) -> None:
    ensure_dir(path.parent)
    if fieldnames is None:
        keys: List[str] = []
        seen = set()
        for row in rows:
            for k in row.keys():
                if k not in seen:
                    keys.append(k)
                    seen.add(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(fieldnames), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def mean(xs: Sequence[float]) -> float:
    return float(sum(xs) / len(xs)) if xs else float("nan")


def median(xs: Sequence[float]) -> float:
    if not xs:
        return float("nan")
    return float(statistics.median(xs))


def geometric_mean(xs: Sequence[float]) -> float:
    vals = [x for x in xs if x > 0 and math.isfinite(x)]
    if not vals:
        return float("nan")
    return math.exp(sum(math.log(x) for x in vals) / len(vals))


def spread_ratio(xs: Sequence[float]) -> float:
    vals = [x for x in xs if x > 0 and math.isfinite(x)]
    if not vals:
        return float("nan")
    mn = min(vals)
    mx = max(vals)
    return mx / mn if mn > 0 else float("inf")


def linfit_intercept(xs: Sequence[float], ys: Sequence[float]) -> Tuple[float, float]:
    """Fit y = a*x + b. Return (a,b)."""
    n = len(xs)
    if n != len(ys) or n < 2:
        return float("nan"), float("nan")
    xbar = mean(xs)
    ybar = mean(ys)
    denom = sum((x - xbar) ** 2 for x in xs)
    if denom == 0:
        return float("nan"), float("nan")
    a = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys)) / denom
    b = ybar - a * xbar
    return a, b


@dataclass(frozen=True)
class Embedding:
    major_R: float
    minor_a: float

    @property
    def ratio_R_over_a(self) -> float:
        return self.major_R / self.minor_a

    @property
    def key(self) -> str:
        return f"R{self.major_R:.2f}_a{self.minor_a:.2f}"


@dataclass
class GeometryMetrics:
    rho: Fraction
    major_R: float
    minor_a: float
    curve_length: float
    bend_energy_int_kappa2_ds: float
    mean_curvature: float
    rms_curvature: float
    max_curvature: float
    total_abs_turning: float
    local_complexity: float
    ds: List[float]
    positions: List[Tuple[float, float, float]]


def torus_point(u: float, p: int, q: int, R: float, a: float) -> Tuple[float, float, float]:
    # Closed toroidal helix: p normal/tube windings and q longitudinal/base windings.
    cu = math.cos(p * u)
    su = math.sin(p * u)
    cq = math.cos(q * u)
    sq = math.sin(q * u)
    radius = R + a * cu
    return (radius * cq, radius * sq, a * su)


def cross(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> Tuple[float, float, float]:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def norm(v: Tuple[float, float, float]) -> float:
    return math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])


def sub(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> Tuple[float, float, float]:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def compute_geometry(rho: Fraction, emb: Embedding, n: int = N_SAMPLES) -> GeometryMetrics:
    p, q = rho.numerator, rho.denominator
    R, a = emb.major_R, emb.minor_a
    du = 2.0 * math.pi / n
    pts = [torus_point(i * du, p, q, R, a) for i in range(n)]

    d1: List[Tuple[float, float, float]] = []
    d2: List[Tuple[float, float, float]] = []
    for i in range(n):
        prev = pts[(i - 1) % n]
        cur = pts[i]
        nxt = pts[(i + 1) % n]
        d1.append(((nxt[0] - prev[0]) / (2 * du), (nxt[1] - prev[1]) / (2 * du), (nxt[2] - prev[2]) / (2 * du)))
        d2.append(((nxt[0] - 2 * cur[0] + prev[0]) / (du * du), (nxt[1] - 2 * cur[1] + prev[1]) / (du * du), (nxt[2] - 2 * cur[2] + prev[2]) / (du * du)))

    speeds = [max(norm(v), 1e-15) for v in d1]
    ds = [s * du for s in speeds]
    kappas: List[float] = []
    for v1, v2, sp in zip(d1, d2, speeds):
        kappa = norm(cross(v1, v2)) / max(sp ** 3, 1e-15)
        kappas.append(kappa)

    curve_length = sum(ds)
    bend = sum((k * k) * dsi for k, dsi in zip(kappas, ds))
    mean_k = sum(k * dsi for k, dsi in zip(kappas, ds)) / max(curve_length, 1e-15)
    rms_k = math.sqrt(sum((k * k) * dsi for k, dsi in zip(kappas, ds)) / max(curve_length, 1e-15))
    max_k = max(kappas)
    total_abs_turning = sum(k * dsi for k, dsi in zip(kappas, ds))

    # Local complexity is a geometry-only candidate: path length × curvature budget × winding count.
    local_complexity = curve_length * (1.0 + total_abs_turning) * (1.0 + float(rho) ** 2)

    return GeometryMetrics(
        rho=rho,
        major_R=R,
        minor_a=a,
        curve_length=curve_length,
        bend_energy_int_kappa2_ds=bend,
        mean_curvature=mean_k,
        rms_curvature=rms_k,
        max_curvature=max_k,
        total_abs_turning=total_abs_turning,
        local_complexity=local_complexity,
        ds=ds,
        positions=pts,
    )


def green_kernel_density(geom: GeometryMetrics, eps: float) -> float:
    """Regularized off-diagonal 1/sqrt(|x-x'|^2+eps^2) density over the curve."""
    pts = geom.positions
    ds = geom.ds
    n = len(pts)
    total = 0.0
    # Exclude i == j only. The epsilon regulator controls near-neighbor terms.
    for i in range(n):
        xi = pts[i]
        dsi = ds[i]
        for j in range(i + 1, n):
            dx = xi[0] - pts[j][0]
            dy = xi[1] - pts[j][1]
            dz = xi[2] - pts[j][2]
            inv = 1.0 / math.sqrt(dx * dx + dy * dy + dz * dz + eps * eps)
            total += dsi * ds[j] * inv
    # Symmetric i<j doubled and normalized by L^2 to remove trivial length scaling.
    return (2.0 * total) / max(geom.curve_length ** 2, 1e-15)


def analytic_lens_proxy(rho: Fraction) -> float:
    # R118 steepened analytic lens proxy. It is not a self-energy law; it is an invariant reference.
    r = float(rho)
    return r ** 3.5


def species_class(rho: Fraction) -> Tuple[str, bool, str]:
    if rho in SEED_RHOS:
        return "v12_8_seed_species_candidate", True, "passes_v12_8_projection"
    if rho == Fraction(1, 3):
        return "virtual_support_not_species", False, "fails_binary_no_overlap"
    if rho in (Fraction(3, 5), Fraction(4, 5)):
        return "virtual_support_not_species", False, "fails_slot_capacity"
    return "control_not_species", False, "outside_locked_seed_or_support_control"


def rank_signature(values: Dict[str, float]) -> str:
    ordered = sorted(values.items(), key=lambda kv: (kv[1], kv[0]))
    return " < ".join(k for k, _ in ordered)


def dynamic_range(values: Dict[str, float]) -> float:
    vals = [v for v in values.values() if v > 0 and math.isfinite(v)]
    if not vals:
        return float("nan")
    return max(vals) / min(vals)


def main() -> int:
    ensure_dir(OUT_DIR)
    now = datetime.now(timezone.utc).isoformat()

    embeddings = [Embedding(R, a) for R, a in EMBEDDINGS]

    parameter_rows: List[Dict[str, object]] = []
    for emb_i, emb in enumerate(embeddings, 1):
        for eps_rel in EPS_REL_VALUES:
            parameter_rows.append(
                {
                    "embedding_index": emb_i,
                    "major_R": emb.major_R,
                    "minor_a": emb.minor_a,
                    "R_over_a": emb.ratio_R_over_a,
                    "eps_rel": eps_rel,
                    "eps_abs": eps_rel * emb.minor_a,
                    "chosen_from_mass_data": False,
                }
            )

    # Compute geometry and kernel tables.
    geometry_cache: Dict[Tuple[Fraction, str], GeometryMetrics] = {}
    mode_geometry_rows: List[Dict[str, object]] = []
    kernel_rows: List[Dict[str, object]] = []
    finite_part_by_mode_embedding: Dict[Tuple[Fraction, str], Dict[str, float]] = {}

    for rho in ALL_RHOS:
        mode_class, species_accept, rejection = species_class(rho)
        for emb in embeddings:
            geom = compute_geometry(rho, emb)
            geometry_cache[(rho, emb.key)] = geom
            mode_geometry_rows.append(
                {
                    "rho": frac_s(rho),
                    "rho_float": float(rho),
                    "numerator_p": rho.numerator,
                    "denominator_q": rho.denominator,
                    "mode_class": mode_class,
                    "species_accept": species_accept,
                    "species_rejection_reason": rejection,
                    "major_R": emb.major_R,
                    "minor_a": emb.minor_a,
                    "R_over_a": emb.ratio_R_over_a,
                    "curve_length": geom.curve_length,
                    "bend_energy_int_kappa2_ds": geom.bend_energy_int_kappa2_ds,
                    "mean_curvature": geom.mean_curvature,
                    "rms_curvature": geom.rms_curvature,
                    "max_curvature": geom.max_curvature,
                    "total_abs_turning": geom.total_abs_turning,
                    "local_complexity": geom.local_complexity,
                    "analytic_lens_proxy": analytic_lens_proxy(rho),
                }
            )

            xs: List[float] = []
            ys: List[float] = []
            for eps_rel in EPS_REL_VALUES:
                eps_abs = eps_rel * emb.minor_a
                density = green_kernel_density(geom, eps_abs)
                xs.append(math.log(1.0 / eps_abs))
                ys.append(density)
                kernel_rows.append(
                    {
                        "rho": frac_s(rho),
                        "rho_float": float(rho),
                        "mode_class": mode_class,
                        "species_accept": species_accept,
                        "major_R": emb.major_R,
                        "minor_a": emb.minor_a,
                        "R_over_a": emb.ratio_R_over_a,
                        "eps_rel": eps_rel,
                        "eps_abs": eps_abs,
                        "green_offdiag_density": density,
                        "chosen_from_mass_data": False,
                    }
                )
            slope, intercept = linfit_intercept(xs, ys)
            finite_part_by_mode_embedding[(rho, emb.key)] = {
                "green_log_slope": slope,
                "green_log_intercept": intercept,
                "finite_part_log_abs": abs(intercept) + 1e-15,
                "kernel_density_geomean": geometric_mean(ys),
                "kernel_density_spread_ratio": spread_ratio(ys),
            }

    # Build functional records by setting.
    functional_setting_values: Dict[str, List[Tuple[str, Dict[str, float]]]] = defaultdict(list)
    functional_value_rows: List[Dict[str, object]] = []

    # Local and finite-part functionals by embedding.
    for emb in embeddings:
        local_values: Dict[str, Dict[str, float]] = {
            "curve_length": {},
            "bend_energy_int_kappa2_ds": {},
            "mean_curvature": {},
            "rms_curvature": {},
            "total_abs_turning": {},
            "local_complexity": {},
            "finite_part_log_abs": {},
            "kernel_density_geomean": {},
            "bend_times_finite_part": {},
            "curvature_times_finite_part": {},
            "analytic_lens_proxy": {},
            "lens_times_bend": {},
            "lens_times_finite_part": {},
        }
        for rho in SEED_RHOS:
            rho_str = frac_s(rho)
            geom = geometry_cache[(rho, emb.key)]
            fp = finite_part_by_mode_embedding[(rho, emb.key)]
            lens = analytic_lens_proxy(rho)
            local_values["curve_length"][rho_str] = geom.curve_length
            local_values["bend_energy_int_kappa2_ds"][rho_str] = geom.bend_energy_int_kappa2_ds
            local_values["mean_curvature"][rho_str] = geom.mean_curvature
            local_values["rms_curvature"][rho_str] = geom.rms_curvature
            local_values["total_abs_turning"][rho_str] = geom.total_abs_turning
            local_values["local_complexity"][rho_str] = geom.local_complexity
            local_values["finite_part_log_abs"][rho_str] = fp["finite_part_log_abs"]
            local_values["kernel_density_geomean"][rho_str] = fp["kernel_density_geomean"]
            local_values["bend_times_finite_part"][rho_str] = geom.bend_energy_int_kappa2_ds * fp["finite_part_log_abs"]
            local_values["curvature_times_finite_part"][rho_str] = geom.rms_curvature * fp["finite_part_log_abs"]
            local_values["analytic_lens_proxy"][rho_str] = lens
            local_values["lens_times_bend"][rho_str] = lens * geom.bend_energy_int_kappa2_ds
            local_values["lens_times_finite_part"][rho_str] = lens * fp["finite_part_log_abs"]

        setting_key = f"embedding:{emb.key}"
        for fid, vals in local_values.items():
            functional_setting_values[fid].append((setting_key, vals))
            for rho_str, val in vals.items():
                functional_value_rows.append(
                    {
                        "functional_id": fid,
                        "setting_key": setting_key,
                        "rho": rho_str,
                        "value": val,
                        "major_R": emb.major_R,
                        "minor_a": emb.minor_a,
                        "R_over_a": emb.ratio_R_over_a,
                        "eps_rel": "",
                        "selected_as_final_physical_mass_law": False,
                    }
                )

    # Regulator-sensitive Green density values by embedding and eps.
    for emb in embeddings:
        for eps_rel in EPS_REL_VALUES:
            vals: Dict[str, float] = {}
            for rho in SEED_RHOS:
                rho_str = frac_s(rho)
                # Look up exact kernel row for this setting.
                found = None
                for row in kernel_rows:
                    if row["rho"] == rho_str and abs(float(row["major_R"]) - emb.major_R) < 1e-12 and abs(float(row["minor_a"]) - emb.minor_a) < 1e-12 and abs(float(row["eps_rel"]) - eps_rel) < 1e-12:
                        found = float(row["green_offdiag_density"])
                        break
                if found is None:
                    raise RuntimeError("internal kernel lookup failure")
                vals[rho_str] = found
            setting_key = f"embedding:{emb.key}:epsrel:{eps_rel:.3f}"
            functional_setting_values["green_offdiag_density"].append((setting_key, vals))
            for rho_str, val in vals.items():
                functional_value_rows.append(
                    {
                        "functional_id": "green_offdiag_density",
                        "setting_key": setting_key,
                        "rho": rho_str,
                        "value": val,
                        "major_R": emb.major_R,
                        "minor_a": emb.minor_a,
                        "R_over_a": emb.ratio_R_over_a,
                        "eps_rel": eps_rel,
                        "selected_as_final_physical_mass_law": False,
                    }
                )

    invariance_rows: List[Dict[str, object]] = []
    rank_rows: List[Dict[str, object]] = []
    regularization_rows: List[Dict[str, object]] = []

    for fid, setting_list in sorted(functional_setting_values.items()):
        sig_counter: Counter[str] = Counter()
        dyn_ranges: List[float] = []
        values_by_rho: Dict[str, List[float]] = defaultdict(list)
        for setting_key, vals in setting_list:
            sig = rank_signature(vals)
            sig_counter[sig] += 1
            dyn_ranges.append(dynamic_range(vals))
            for rho_str, val in vals.items():
                values_by_rho[rho_str].append(val)

        modal_sig, modal_count = sig_counter.most_common(1)[0]
        modal_frac = modal_count / max(len(setting_list), 1)
        rho_spreads = {rho: spread_ratio(vals) for rho, vals in values_by_rho.items()}
        max_spread = max(v for v in rho_spreads.values() if math.isfinite(v))
        median_spread = median([v for v in rho_spreads.values() if math.isfinite(v)])
        dyn_min = min(dyn_ranges)
        dyn_max = max(dyn_ranges)
        dyn_med = median(dyn_ranges)

        # Classification is diagnostic, not a mass-law selection.
        if fid == "analytic_lens_proxy":
            grade = "STABLE_BY_CONSTRUCTION_NOT_SELF_ENERGY"
            pass_for_next = True
        elif modal_frac >= 0.85 and max_spread <= 2.0 and dyn_max / max(dyn_min, 1e-15) <= 2.0:
            grade = "STRONG_SCREEN_CANDIDATE"
            pass_for_next = True
        elif modal_frac >= 0.85:
            grade = "RANK_STABLE_VALUE_SENSITIVE"
            pass_for_next = True
        elif modal_frac >= 0.60:
            grade = "PARTIAL_RANK_STABILITY"
            pass_for_next = False
        else:
            grade = "EMBEDDING_OR_REGULATOR_SENSITIVE"
            pass_for_next = False

        origin = "local_geometric"
        if "green" in fid or "finite" in fid:
            origin = "requires_regularization"
        if "lens" in fid:
            origin = "analytic_rho_invariant"

        invariance_rows.append(
            {
                "functional_id": fid,
                "candidate_origin": origin,
                "settings_count": len(setting_list),
                "distinct_rank_signatures": len(sig_counter),
                "modal_rank_signature_fraction": modal_frac,
                "modal_rank_signature": modal_sig,
                "seed_dynamic_range_min": dyn_min,
                "seed_dynamic_range_median": dyn_med,
                "seed_dynamic_range_max": dyn_max,
                "dynamic_range_spread_factor": dyn_max / max(dyn_min, 1e-15),
                "median_value_spread_across_settings": median_spread,
                "max_value_spread_across_settings": max_spread,
                "invariance_grade": grade,
                "screen_candidate_for_future_derived_F": pass_for_next,
                "selected_as_final_physical_mass_law": False,
                "mass_data_loaded": False,
            }
        )
        for sig, count in sig_counter.most_common(10):
            rank_rows.append(
                {
                    "functional_id": fid,
                    "rank_signature": sig,
                    "count": count,
                    "fraction": count / max(len(setting_list), 1),
                }
            )
        for rho_str, vals in sorted(values_by_rho.items(), key=lambda kv: Fraction(kv[0])):
            regularization_rows.append(
                {
                    "functional_id": fid,
                    "rho": rho_str,
                    "settings_count": len(vals),
                    "value_min": min(vals),
                    "value_median": median(vals),
                    "value_max": max(vals),
                    "spread_ratio_max_over_min": spread_ratio(vals),
                    "mass_data_loaded": False,
                }
            )

    # Audit booleans.
    stable_nonanalytic_candidates = [
        row for row in invariance_rows
        if row["screen_candidate_for_future_derived_F"] is True and row["functional_id"] != "analytic_lens_proxy"
    ]
    strong_nonanalytic_candidates = [
        row for row in stable_nonanalytic_candidates
        if row["invariance_grade"] == "STRONG_SCREEN_CANDIDATE"
    ]

    audit = {
        "parameter_grid_generated": True,
        "embedding_grid_varied": len(EMBEDDINGS) >= 6,
        "regulator_grid_varied": len(EPS_REL_VALUES) >= 4,
        "geometry_table_generated": len(mode_geometry_rows) > 0,
        "kernel_table_generated": len(kernel_rows) > 0,
        "seed_all_computed": all(frac_s(r) in {row["rho"] for row in mode_geometry_rows if row["species_accept"] is True} for r in SEED_RHOS),
        "virtuals_computed_not_promoted": all(
            any(row["rho"] == frac_s(r) and row["species_accept"] is False for row in mode_geometry_rows)
            for r in VIRTUAL_RHOS
        ),
        "invariance_summary_generated": len(invariance_rows) > 0,
        "rank_signatures_reported": len(rank_rows) > 0,
        "regularization_sensitivity_reported": len(regularization_rows) > 0,
        "nonanalytic_stable_screen_candidates_present": len(stable_nonanalytic_candidates) > 0,
        "strong_nonanalytic_screen_candidates_present": len(strong_nonanalytic_candidates) > 0,
        "no_empirical_mass_data_loaded": True,
        "no_mass_matching_performed": True,
        "no_parameter_fit_performed": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "unique_renormalization_closed": False,
        "embedding_invariance_theorem_closed": False,
        "dynamic_GR_self_energy_closed": False,
        "full_PDE_mass_functional_closed": False,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "Omega0_claimed": False,
    }

    gate_audit_rows = [
        {
            "test": k,
            "result": "PASS" if v is True else ("OPEN" if v is False and k in {
                "unique_renormalization_closed",
                "embedding_invariance_theorem_closed",
                "dynamic_GR_self_energy_closed",
                "full_PDE_mass_functional_closed",
                "physical_mass_spectrum_claimed",
                "SM_mass_matching_claimed",
                "Omega0_claimed",
            } else "SCREEN" if v is True else "FAIL"),
            "value": v,
            "interpretation": {
                "parameter_grid_generated": "Embedding and regulator parameter grid was generated before any empirical comparison.",
                "embedding_grid_varied": "Major/minor torus geometry was varied to test embedding dependence.",
                "regulator_grid_varied": "Epsilon regulator was varied to test counterterm sensitivity.",
                "geometry_table_generated": "Closed helical representative geometry was computed for seed, virtual, and control modes.",
                "kernel_table_generated": "Regularized kernel values were computed on the regulator grid.",
                "seed_all_computed": "All nine locked V12.8 seed modes were evaluated.",
                "virtuals_computed_not_promoted": "Virtual support values were computed without promoting them to species.",
                "invariance_summary_generated": "Rank-order, dynamic-range, and value-spread stability were summarized.",
                "rank_signatures_reported": "Rank signatures are reported rather than hidden.",
                "regularization_sensitivity_reported": "Regulator/embedding sensitivity is visible mode by mode.",
                "nonanalytic_stable_screen_candidates_present": "At least one non-analytic candidate has useful rank stability for future work.",
                "strong_nonanalytic_screen_candidates_present": "At least one non-analytic candidate is value-stable by the strict screen.",
                "no_empirical_mass_data_loaded": "No particle masses or Standard Model target ratios are loaded in R119.",
                "no_mass_matching_performed": "No comparison to empirical masses is performed in R119.",
                "no_parameter_fit_performed": "No exponent/coefficient/counterterm is optimized against data.",
                "no_mode_particle_mapping_performed": "No rho mode is mapped to a particle.",
                "no_final_physical_mass_law_selected": "R119 is a stability screen only.",
                "unique_renormalization_closed": "A unique counterterm/finite-part prescription remains open.",
                "embedding_invariance_theorem_closed": "A theorem proving embedding independence remains open.",
                "dynamic_GR_self_energy_closed": "A self-consistent GR/PDE self-energy remains open.",
                "full_PDE_mass_functional_closed": "No full physical mass functional is closed.",
                "physical_mass_spectrum_claimed": "No physical mass spectrum is claimed.",
                "SM_mass_matching_claimed": "No Standard Model mass matching is claimed.",
                "Omega0_claimed": "Omega0 remains outside this gate.",
            }.get(k, ""),
        }
        for k, v in audit.items()
    ]

    claim_rows = [
        {
            "claim": "R119 tests regulator and torus-embedding stability of R118-derived candidate F(rho) values.",
            "status": "YES",
            "reason": "Embedding R/a and epsilon regulator grids are varied without loading mass data.",
        },
        {
            "claim": "R119 compares candidate F(rho) values to observed particle masses.",
            "status": "NO",
            "reason": "No empirical masses or Standard Model target ratios are loaded.",
        },
        {
            "claim": "R119 closes a unique renormalized self-energy prescription.",
            "status": "NO",
            "reason": "Rank/value stability is audited, but no unique counterterm or finite-part theorem is derived.",
        },
        {
            "claim": "R119 proves torus-embedding independence.",
            "status": "NO",
            "reason": "The script screens embedding sensitivity; it does not prove embedding invariance from first principles.",
        },
        {
            "claim": "R119 selects a final physical mass law.",
            "status": "NO",
            "reason": "Candidate grades are diagnostic only and no mass data are loaded.",
        },
        {
            "claim": "R119 promotes virtual supports to species if their self-energy values are attractive.",
            "status": "NO",
            "reason": "V12.8 species projection remains locked; F-values do not override binary/slot admissibility.",
        },
        {
            "claim": "R119 confirms the nine seed modes as physical particles.",
            "status": "NO",
            "reason": "The nine modes remain mechanical/operator-geometric seed modes pending physical identification.",
        },
    ]

    risk_rows = [
        {
            "risk": "Rank stability is mistaken for a final physical mass law.",
            "severity": "HIGH",
            "mitigation": "Report stability as a screen only; reserve mass comparison for locked later gate.",
        },
        {
            "risk": "Counterterm choice is silently chosen to improve later mass hits.",
            "severity": "HIGH",
            "mitigation": "No mass data are loaded; all regulator/finite-part diagnostics are written before any later comparison.",
        },
        {
            "risk": "Torus embedding is treated as physically unique without proof.",
            "severity": "HIGH",
            "mitigation": "Vary R/a and mark embedding-invariance theorem open.",
        },
        {
            "risk": "Analytic rho proxy is favored because it is stable by construction.",
            "severity": "MEDIUM",
            "mitigation": "Label analytic_lens_proxy as invariant reference, not self-energy closure.",
        },
        {
            "risk": "Virtual support channels are promoted based on strong F-values.",
            "severity": "MEDIUM",
            "mitigation": "Virtuals remain species-inactive under the locked V12.8 projection.",
        },
        {
            "risk": "Positive pairwise hints from R117 bias R119 candidate grading.",
            "severity": "HIGH",
            "mitigation": "R119 loads no empirical masses and evaluates only stability under regulator/embedding choices.",
        },
    ]

    # Write output files.
    paths: List[Path] = []
    files_to_write = [
        (OUT_DIR / "FORCE_R119_gate_audit.csv", gate_audit_rows),
        (OUT_DIR / "FORCE_R119_parameter_grid.csv", parameter_rows),
        (OUT_DIR / "FORCE_R119_mode_geometry_samples.csv", mode_geometry_rows),
        (OUT_DIR / "FORCE_R119_kernel_regulator_samples.csv", kernel_rows),
        (OUT_DIR / "FORCE_R119_functional_value_samples.csv", functional_value_rows),
        (OUT_DIR / "FORCE_R119_invariance_summary.csv", invariance_rows),
        (OUT_DIR / "FORCE_R119_rank_signature_summary.csv", rank_rows),
        (OUT_DIR / "FORCE_R119_regularization_sensitivity.csv", regularization_rows),
        (OUT_DIR / "FORCE_R119_claim_boundary.csv", claim_rows),
        (OUT_DIR / "FORCE_R119_risk_register.csv", risk_rows),
    ]
    for pth, rows in files_to_write:
        write_csv(pth, rows)
        paths.append(pth)

    # Pick top diagnostic rows for console/summary.
    inv_sorted = sorted(
        invariance_rows,
        key=lambda r: (
            -float(r["modal_rank_signature_fraction"]),
            float(r["max_value_spread_across_settings"]),
            -float(r["seed_dynamic_range_median"]),
        ),
    )
    top_inv = inv_sorted[:10]

    next_gate_plan = [
        {
            "next_gate": "FORCE_R120",
            "title": "Locked Derived-F Mass-Ratio Screen Gate",
            "goal": "Only after freezing R119 stability outputs, compare chosen diagnostic candidates to the mass-ratio screen without retuning.",
            "must_not_do": "Do not choose regulator, embedding, or exponent by empirical hit quality.",
        },
        {
            "next_gate": "FORCE_R121",
            "title": "Counterterm / Finite-Part Derivation Gate",
            "goal": "Try to derive a unique renormalized finite-part prescription from action/PDE consistency rather than stability screening.",
            "must_not_do": "Do not use particle masses to pick the counterterm.",
        },
    ]

    verdict = {
        "gate": GATE_ID,
        "title": TITLE,
        "verdict": VERDICT_PASS,
        "timestamp_utc": now,
        "freeze_id": FREEZE_ID,
        "zip_integrity": "PENDING",
        "selected_seed": "{" + ", ".join(frac_s(r) for r in SEED_RHOS) + "}",
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        **audit,
        "top_invariance_candidates": top_inv,
        "next_gate_plan": next_gate_plan,
    }

    verdict_path = OUT_DIR / "FORCE_R119_verdict.json"
    verdict_path.write_text(json.dumps(verdict, indent=2, ensure_ascii=False), encoding="utf-8")
    paths.append(verdict_path)

    summary_lines = []
    summary_lines.append(f"# {GATE_ID}: {TITLE}\n")
    summary_lines.append(f"**Verdict:** {VERDICT_PASS}\n")
    summary_lines.append(f"**Freeze ID:** `{FREEZE_ID}`\n")
    summary_lines.append("\n## Claim Boundary\n")
    summary_lines.append("R119 is a regulator/embedding stability screen. It does not load mass data, does not compare to Standard Model masses, does not select a final physical mass law, and does not promote virtual supports to species.\n")
    summary_lines.append("\n## Locked Seed\n")
    summary_lines.append("`{" + ", ".join(frac_s(r) for r in SEED_RHOS) + "}`\n")
    summary_lines.append("\n## Canonical Species Formula\n")
    summary_lines.append(f"`{CANONICAL_SPECIES_FORMULA}`\n")
    summary_lines.append("\n## Parameter Grid\n")
    summary_lines.append(f"- Embeddings tested: {len(EMBEDDINGS)}\n")
    summary_lines.append(f"- Regulator values per embedding: {len(EPS_REL_VALUES)}\n")
    summary_lines.append(f"- Seed modes computed: {len(SEED_RHOS)}\n")
    summary_lines.append(f"- Virtual supports computed but not promoted: {len(VIRTUAL_RHOS)}\n")
    summary_lines.append("\n## Top Invariance Diagnostics\n")
    summary_lines.append("\n| functional | grade | modal rank fraction | max value spread | median dynamic range | selected as final law |\n")
    summary_lines.append("|---|---:|---:|---:|---:|---:|\n")
    for row in top_inv:
        summary_lines.append(
            f"| {row['functional_id']} | {row['invariance_grade']} | {float(row['modal_rank_signature_fraction']):.3f} | {float(row['max_value_spread_across_settings']):.3g} | {float(row['seed_dynamic_range_median']):.3g} | {row['selected_as_final_physical_mass_law']} |\n"
        )
    summary_lines.append("\n## Open Items\n")
    summary_lines.append("- Unique counterterm / finite-part derivation remains open.\n")
    summary_lines.append("- Torus-embedding invariance theorem remains open.\n")
    summary_lines.append("- Full GR/PDE self-energy closure remains open.\n")
    summary_lines.append("- Physical mass spectrum, SM matching, and Omega0 remain open.\n")
    summary_lines.append("\n## Next Gate\n")
    summary_lines.append("`FORCE_R120_locked_derived_F_mass_ratio_screen_gate` after freezing R119 outputs, or `FORCE_R121_counterterm_finite_part_derivation_gate` if the priority is deeper derivation before another comparison.\n")

    summary_path = OUT_DIR / "FORCE_R119_summary.md"
    summary_path.write_text("".join(summary_lines), encoding="utf-8")
    paths.append(summary_path)

    # Artifact manifest before zipping.
    manifest_rows: List[Dict[str, object]] = []
    for pth in sorted(paths):
        manifest_rows.append(
            {
                "file": str(pth.relative_to(ROOT)),
                "bytes": pth.stat().st_size,
                "sha256": sha256_file(pth),
            }
        )
    manifest_path = OUT_DIR / "artifact_manifest.csv"
    write_csv(manifest_path, manifest_rows)
    paths.append(manifest_path)

    # Zip pack.
    if PACK_PATH.exists():
        PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for pth in sorted(paths):
            zf.write(pth, arcname=str(pth.relative_to(ROOT)))
    zip_ok = PACK_PATH.exists() and PACK_PATH.stat().st_size > 0

    # Update verdict with final zip integrity and hash.
    verdict["zip_integrity"] = "PASS" if zip_ok else "FAIL"
    verdict["pack_path"] = str(PACK_PATH)
    verdict["pack_sha256"] = sha256_file(PACK_PATH) if zip_ok else ""
    verdict_path.write_text(json.dumps(verdict, indent=2, ensure_ascii=False), encoding="utf-8")

    # Console output.
    print("=== COPY/PASTE R119 RESULT ===")
    print("R119 COMPLETE")
    print(f"VERDICT: {VERDICT_PASS}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    for key in [
        "parameter_grid_generated",
        "embedding_grid_varied",
        "regulator_grid_varied",
        "geometry_table_generated",
        "kernel_table_generated",
        "seed_all_computed",
        "virtuals_computed_not_promoted",
        "invariance_summary_generated",
        "rank_signatures_reported",
        "regularization_sensitivity_reported",
        "nonanalytic_stable_screen_candidates_present",
        "strong_nonanalytic_screen_candidates_present",
        "no_empirical_mass_data_loaded",
        "no_mass_matching_performed",
        "no_parameter_fit_performed",
        "no_mode_particle_mapping_performed",
        "no_final_physical_mass_law_selected",
        "unique_renormalization_closed",
        "embedding_invariance_theorem_closed",
        "dynamic_GR_self_energy_closed",
        "full_PDE_mass_functional_closed",
        "physical_mass_spectrum_claimed",
        "SM_mass_matching_claimed",
        "Omega0_claimed",
    ]:
        print(f"{key}: {audit[key]}")
    print(f"selected_seed: {{{', '.join(frac_s(r) for r in SEED_RHOS)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("TOP_INVARIANCE_DIAGNOSTICS:")
    for row in top_inv:
        print(
            f"  {row['functional_id']} | grade={row['invariance_grade']} | "
            f"rank_frac={float(row['modal_rank_signature_fraction']):.3f} | "
            f"max_spread={float(row['max_value_spread_across_settings']):.3g} | "
            f"dyn_med={float(row['seed_dynamic_range_median']):.3g} | "
            f"final_law={row['selected_as_final_physical_mass_law']}"
        )
    print("CLAIM_BOUNDARY:")
    for row in claim_rows:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print(f"PACK: {PACK_PATH}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: FORCE_R120_locked_derived_F_mass_ratio_screen_gate_or_FORCE_R121_counterterm_finite_part_derivation_gate")
    print("=== END COPY/PASTE R119 RESULT ===")

    return 0 if zip_ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
