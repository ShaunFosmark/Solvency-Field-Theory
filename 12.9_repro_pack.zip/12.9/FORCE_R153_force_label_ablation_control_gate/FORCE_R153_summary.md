# FORCE R153 Summary

VERDICT: FORCE-LABEL ABLATION CONTROL PASS / LABEL CONTRIBUTIONS LOCALIZED, NULL RISK REMAINS, FREEZE NEXT
candidate_freeze_hash: 3f23a17f6fe6ef11c47ab65c893a8dab60282129bb55434bfd7c6248b34b3bd9
n_null_per_candidate: 800

## Component rollup
- denominator_class: loss_when_removed_mean=-0.333, only_mean=9.67 (informative_screen)
- slot_fill: loss_when_removed_mean=1.33, only_mean=13.7 (informative_screen)
- residue_holonomy: loss_when_removed_mean=1.33, only_mean=10.3 (informative_screen)
- topology_class: loss_when_removed_mean=1, only_mean=10 (informative_screen)
- support_ecology: loss_when_removed_mean=0.667, only_mean=11.7 (informative_screen)