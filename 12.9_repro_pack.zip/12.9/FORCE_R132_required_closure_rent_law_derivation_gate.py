from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import hashlib
import math
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R132_required_closure_rent_law_derivation_gate")
ZIP = Path("FORCE_R132_required_closure_rent_law_derivation_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
TITLE = "FORCE_R132 Required Closure-Rent Law Derivation Gate"

# R132 purpose:
#   R130 showed a reversal under flat unit rent: low modes looked collective-dependent.
#   R131 audited mode-normalized rent profiles but did not derive a unique rent law.
#
# R132 asks:
#   Can the required closure-rent shape be derived by power counting from the helical
#   radius/depth/focusing geometry, without using mass data or particle mapping?
#
# Key idea:
#   For radius r ~ 1/rho:
#     volume V ~ r^3 ~ rho^-3
#     write/cadence density n ~ rho / V ~ rho^4
#     self-energy-like density integral n^2 V ~ rho^5
#     curvature-weighted self-energy ~ rho^6
#     curvature^2/acceleration-weighted self-energy ~ rho^7
#
# Guardrail:
#   R132 does not select a final law. It only checks whether high-order rent profiles
#   can be derived naturally from power counting and whether they relieve the R130 low-mode reversal.

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
]
LOW_MODES = {Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1)}
CLEAN_INTERNAL_R130 = {Fraction(4, 3), Fraction(3, 2)}
VIRTUAL_DEPENDENT_R130 = {Fraction(5, 4), Fraction(5, 3)}
BOUNDARY_ASSISTED_R130 = {Fraction(2, 1)}
VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}

# R126 primary preview values. Geometry-only screen values; no empirical masses.
AVAILABLE_F = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

# Virtual support F values are not promoted to species; included only for boundary audit.
VIRTUAL_F = {
    Fraction(1, 3): 0.0025,
    Fraction(3, 5): 0.041,
    Fraction(4, 5): 0.18,
}


def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(x)


def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ffloat(x):
    return float(x.numerator) / float(x.denominator)


def R_map(x):
    return Fraction(2, 1) - x


def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x


def species_project(x):
    return x in SEED


# ---------------------------------------------------------------------
# 1. Power-count derivation ledger.
# ---------------------------------------------------------------------

power_count_steps = pd.DataFrame([
    {
        "step": 1,
        "component": "closure radius",
        "scaling": "r(rho) ~ rho^-1",
        "exponent_contribution": 0,
        "statement": "Higher cadence ratio means tighter winding and smaller closure radius.",
        "status": "GEOMETRIC_POWER_COUNT_INPUT",
    },
    {
        "step": 2,
        "component": "closure volume",
        "scaling": "V ~ r^3 ~ rho^-3",
        "exponent_contribution": 3,
        "statement": "Available write/energy density rises as inverse closure volume.",
        "status": "GEOMETRIC_POWER_COUNT",
    },
    {
        "step": 3,
        "component": "cadence/write density",
        "scaling": "n_write ~ rho / V ~ rho^4",
        "exponent_contribution": 4,
        "statement": "The mode writes rho times per base cycle into a volume shrinking as rho^-3.",
        "status": "DERIVED_POWER_COUNT",
    },
    {
        "step": 4,
        "component": "self-energy density integral",
        "scaling": "n_write^2 V ~ rho^5",
        "exponent_contribution": 5,
        "statement": "A quadratic self-energy-like cost integrated over volume gives rho^5.",
        "status": "DERIVED_POWER_COUNT_CANDIDATE",
    },
    {
        "step": 5,
        "component": "curvature-weighted self-energy",
        "scaling": "rho * n_write^2 V ~ rho^6",
        "exponent_contribution": 6,
        "statement": "Including one curvature/closure-turning factor gives rho^6.",
        "status": "DERIVED_COMPOSITE_CANDIDATE",
    },
    {
        "step": 6,
        "component": "acceleration-weighted self-energy",
        "scaling": "rho^2 * n_write^2 V ~ rho^7",
        "exponent_contribution": 7,
        "statement": "Including curvature-squared/acceleration weighting gives rho^7.",
        "status": "DERIVED_HIGH_ORDER_CONTROL",
    },
    {
        "step": 7,
        "component": "unique physical rent law",
        "scaling": "selected p = ?",
        "exponent_contribution": None,
        "statement": "A unique required-rent law is not derived at this gate.",
        "status": "OPEN",
    },
])

rent_laws = [
    {
        "law_id": "p1_linear_winding_rent",
        "power": 1.0,
        "origin": "rho cadence/winding count",
        "natural_status": "LOW_ORDER_CONTROL",
        "is_derived_candidate": True,
    },
    {
        "law_id": "p2_curvature_acceleration_rent",
        "power": 2.0,
        "origin": "curvature-squared / centripetal demand",
        "natural_status": "LOW_ORDER_CONTROL",
        "is_derived_candidate": True,
    },
    {
        "law_id": "p3_inverse_volume_density_rent",
        "power": 3.0,
        "origin": "inverse closure volume in 3D",
        "natural_status": "GEOMETRIC_CONTROL",
        "is_derived_candidate": True,
    },
    {
        "law_id": "p4_write_density_rent",
        "power": 4.0,
        "origin": "rho cadence times inverse 3D volume",
        "natural_status": "DERIVED_POWER_COUNT",
        "is_derived_candidate": True,
    },
    {
        "law_id": "p5_quadratic_density_self_energy_rent",
        "power": 5.0,
        "origin": "write-density squared integrated over closure volume",
        "natural_status": "DERIVED_SELF_ENERGY_CANDIDATE",
        "is_derived_candidate": True,
    },
    {
        "law_id": "p6_curvature_weighted_self_energy_rent",
        "power": 6.0,
        "origin": "rho curvature factor times quadratic density self-energy",
        "natural_status": "DERIVED_COMPOSITE_CANDIDATE",
        "is_derived_candidate": True,
    },
    {
        "law_id": "p7_acceleration_weighted_self_energy_rent",
        "power": 7.0,
        "origin": "rho^2 acceleration/curvature-squared factor times quadratic density self-energy",
        "natural_status": "HIGH_ORDER_DIAGNOSTIC_CONTROL",
        "is_derived_candidate": True,
    },
]

# ---------------------------------------------------------------------
# 2. Required exponent diagnostic.
# ---------------------------------------------------------------------

F_identity = AVAILABLE_F[Fraction(1, 1)]
required_exponent_rows = []
for rho in sorted(LOW_MODES):
    x = ffloat(rho)
    F = AVAILABLE_F[rho]
    if rho == Fraction(1, 1):
        p_req = 0.0
        note = "identity anchor normalization"
    else:
        # Need F / (F1 * rho^p) >= 1. For rho<1 this gives p >= log(F/F1)/log(rho).
        p_req = math.log(F / F_identity) / math.log(x)
        note = "minimum p for identity-normalized adequacy >= 1"
    required_exponent_rows.append({
        "rho": frac_label(rho),
        "rho_float": x,
        "available_F": F,
        "F_over_F_identity": F / F_identity,
        "required_power_lower_bound": p_req,
        "note": note,
    })

required_exponent_audit = pd.DataFrame(required_exponent_rows)
min_power_to_relieve_all_low_modes = max(required_exponent_audit["required_power_lower_bound"])

# ---------------------------------------------------------------------
# 3. Adequacy under derived rent profiles.
# ---------------------------------------------------------------------

adequacy_rows = []
profile_rows = []

for law in rent_laws:
    p = float(law["power"])
    surplus_modes_identity = []
    surplus_modes_unit = []
    low_surplus_identity = 0
    low_surplus_unit = 0
    clean_surplus_identity = 0
    clean_surplus_unit = 0

    adequacies_identity = []
    adequacies_unit = []

    for rho in SEED:
        x = ffloat(rho)
        F = AVAILABLE_F[rho]
        rent_identity = F_identity * (x ** p)
        rent_unit = 1.0 * (x ** p)
        adeq_identity = F / rent_identity if rent_identity > 0 else float("inf")
        adeq_unit = F / rent_unit if rent_unit > 0 else float("inf")

        pass_identity = adeq_identity >= 1.0
        pass_unit = adeq_unit >= 1.0

        if pass_identity:
            surplus_modes_identity.append(rho)
            if rho in LOW_MODES:
                low_surplus_identity += 1
            if rho in CLEAN_INTERNAL_R130:
                clean_surplus_identity += 1

        if pass_unit:
            surplus_modes_unit.append(rho)
            if rho in LOW_MODES:
                low_surplus_unit += 1
            if rho in CLEAN_INTERNAL_R130:
                clean_surplus_unit += 1

        adequacies_identity.append(adeq_identity)
        adequacies_unit.append(adeq_unit)

        adequacy_rows.append({
            "law_id": law["law_id"],
            "power": p,
            "rho": frac_label(rho),
            "rho_float": x,
            "available_F": F,
            "required_rent_identity_norm": rent_identity,
            "adequacy_identity_norm": adeq_identity,
            "pass_identity_norm": pass_identity,
            "required_rent_unit_norm": rent_unit,
            "adequacy_unit_norm": adeq_unit,
            "pass_unit_norm": pass_unit,
            "r130_class": (
                "low_unit_rent_fail_collective_candidate" if rho in LOW_MODES else
                "clean_internal_pass" if rho in CLEAN_INTERNAL_R130 else
                "virtual_support_dependent" if rho in VIRTUAL_DEPENDENT_R130 else
                "boundary_assisted" if rho in BOUNDARY_ASSISTED_R130 else
                "other"
            ),
        })

    dyn_identity = max(adequacies_identity) / min(a for a in adequacies_identity if a > 0)
    dyn_unit = max(adequacies_unit) / min(a for a in adequacies_unit if a > 0)
    all_low_relief_identity = LOW_MODES.issubset(set(surplus_modes_identity))
    all_low_relief_unit = LOW_MODES.issubset(set(surplus_modes_unit))

    if p >= min_power_to_relieve_all_low_modes and law["natural_status"].startswith("DERIVED"):
        interpretation = "Derived power-count law is steep enough to relieve the R130 low-mode reversal under identity-anchor normalization."
    elif p >= min_power_to_relieve_all_low_modes:
        interpretation = "High-order law is steep enough to relieve low modes, but uniqueness/physical status remains open."
    else:
        interpretation = "Low-mode reversal persists under this rent law; rent demand is too shallow."

    profile_rows.append({
        "law_id": law["law_id"],
        "power": p,
        "origin": law["origin"],
        "natural_status": law["natural_status"],
        "identity_norm_surplus_modes": label_set(surplus_modes_identity),
        "identity_norm_low_surplus_count": low_surplus_identity,
        "identity_norm_clean_surplus_count": clean_surplus_identity,
        "identity_norm_all_low_relief": all_low_relief_identity,
        "unit_norm_surplus_modes": label_set(surplus_modes_unit),
        "unit_norm_low_surplus_count": low_surplus_unit,
        "unit_norm_clean_surplus_count": clean_surplus_unit,
        "unit_norm_all_low_relief": all_low_relief_unit,
        "adequacy_dynamic_range_identity_norm": dyn_identity,
        "adequacy_dynamic_range_unit_norm": dyn_unit,
        "interpretation": interpretation,
        "selected_as_unique_rent_law": False,
    })

adequacy_table = pd.DataFrame(adequacy_rows)
rent_profile_scorecard = pd.DataFrame(profile_rows)

p5_relief = bool(rent_profile_scorecard[rent_profile_scorecard["law_id"] == "p5_quadratic_density_self_energy_rent"].iloc[0]["identity_norm_all_low_relief"])
p6_relief = bool(rent_profile_scorecard[rent_profile_scorecard["law_id"] == "p6_curvature_weighted_self_energy_rent"].iloc[0]["identity_norm_all_low_relief"])
p4_relief = bool(rent_profile_scorecard[rent_profile_scorecard["law_id"] == "p4_write_density_rent"].iloc[0]["identity_norm_all_low_relief"])

derived_low_mode_relief_present = bool(p5_relief or p6_relief)
derived_power_threshold_bracketed = bool(4.0 < min_power_to_relieve_all_low_modes < 5.5)
low_order_controls_fail_relief = bool(not p4_relief)

# ---------------------------------------------------------------------
# 4. Partner / support ecology audit is still preserved.
# ---------------------------------------------------------------------

support_rows = []
for rho in SEED:
    r = R_map(rho)
    c = C_map(rho)
    def partner_status(x):
        if x == 0:
            return "boundary_zero"
        if x in SEED:
            return "species"
        if x in VIRTUAL_SUPPORTS:
            return "virtual_support"
        return "not_supported_or_outside"

    support_rows.append({
        "rho": frac_label(rho),
        "R_partner": frac_label(r),
        "R_partner_status": partner_status(r),
        "C_partner": frac_label(c),
        "C_partner_status": partner_status(c),
        "virtual_support_dependent": partner_status(r) == "virtual_support" or partner_status(c) == "virtual_support",
        "boundary_assisted": partner_status(r) == "boundary_zero" or partner_status(c) == "boundary_zero",
    })
support_ecology_audit = pd.DataFrame(support_rows)

virtual_rows = []
for rho in sorted(VIRTUAL_SUPPORTS):
    virtual_rows.append({
        "rho": frac_label(rho),
        "class": "virtual_support_not_species",
        "species_accept": False,
        "geometric_F_computed": rho in VIRTUAL_F,
        "promoted_by_rent_law": False,
        "reason": (
            "fails_binary_no_overlap" if rho == Fraction(1, 3) else "fails_slot_capacity"
        ),
    })
virtual_support_status = pd.DataFrame(virtual_rows)

# ---------------------------------------------------------------------
# 5. Observation-awareness register. Notes only; not computation inputs.
# ---------------------------------------------------------------------

observation_awareness = pd.DataFrame([
    {
        "used_in_computation": False,
        "observation_context": "Some observed charged leptons can exist unconfined; electron is stable while muon/tau decay but are not confined.",
        "R132_use": "Sanity context only; no rho-to-lepton map is computed.",
    },
    {
        "used_in_computation": False,
        "observation_context": "Quarks are not observed as free isolated particles and have scheme-dependent mass concepts.",
        "R132_use": "Sanity context only; no rho-to-quark map is computed.",
    },
    {
        "used_in_computation": False,
        "observation_context": "R130/R131 made low modes look underpowered under shallow rent laws.",
        "R132_use": "Derive the power-count threshold needed to relieve that reversal without mass data.",
    },
])

# ---------------------------------------------------------------------
# 6. Verdict / claim boundary.
# ---------------------------------------------------------------------

no_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_parameter_fit_performed = True
no_mode_particle_mapping_performed = True
no_final_physical_rent_law_selected = True
unique_closure_rent_law_closed = False
clean_standalone_collective_split_closed = False
physical_mass_spectrum_claimed = False
SM_mass_matching_claimed = False
true_GR_PDE_collective_field_closed = False

parameter_grid_generated = True
power_count_derivation_generated = True
required_power_threshold_reported = True
rent_profiles_generated = True
mode_adequacy_table_generated = True
low_mode_reversal_explained_by_shallow_rent = bool(low_order_controls_fail_relief and derived_low_mode_relief_present)
derived_self_energy_rent_candidate_present = True

if (
    parameter_grid_generated
    and power_count_derivation_generated
    and required_power_threshold_reported
    and rent_profiles_generated
    and mode_adequacy_table_generated
    and derived_power_threshold_bracketed
    and derived_self_energy_rent_candidate_present
    and low_mode_reversal_explained_by_shallow_rent
    and no_empirical_mass_data_loaded
    and no_parameter_fit_performed
    and no_mode_particle_mapping_performed
    and not unique_closure_rent_law_closed
):
    verdict_status = "REQUIRED CLOSURE-RENT LAW DERIVATION SCREEN PASS / POWER-COUNT CANDIDATES RELIEVE REVERSAL, UNIQUE LAW OPEN"
else:
    verdict_status = "REQUIRED CLOSURE-RENT LAW DERIVATION SCREEN INCONCLUSIVE"

claim_boundary = pd.DataFrame([
    {
        "claim": "R132 derives power-count candidate closure-rent laws from helical radius/depth geometry.",
        "status": "YES_SCREEN",
        "reason": "Radius, volume, write-density, density-squared self-energy, and curvature-weighted demand profiles are generated without mass data.",
    },
    {
        "claim": "R132 explains why shallow rent laws preserve the R130 low-mode reversal.",
        "status": "YES_SCREEN",
        "reason": "The required exponent lower bound for low-mode relief is reported; p<=4 is too shallow under identity-anchor normalization.",
    },
    {
        "claim": "R132 proves a unique physical closure-rent law.",
        "status": "NO",
        "reason": "Several power-count candidates are screened; no unique law is selected or proven from PDE/GR dynamics.",
    },
    {
        "claim": "R132 uses observations or masses to choose p=5, p=6, or p=7.",
        "status": "NO",
        "reason": "Observation awareness is context only; no empirical mass table or particle mapping is loaded.",
    },
    {
        "claim": "R132 maps rho modes to leptons, quarks, or Standard Model particles.",
        "status": "NO",
        "reason": "No rho-to-particle assignment is performed.",
    },
    {
        "claim": "R132 promotes virtual supports to stable species.",
        "status": "NO",
        "reason": "The V12.8 species projection remains locked; virtual supports remain support-only.",
    },
    {
        "claim": "R132 closes true GR/PDE collective field dynamics.",
        "status": "NO",
        "reason": "Power counting is a derivation screen, not a solved self-consistent field theorem.",
    },
])

risk_register = pd.DataFrame([
    {
        "risk": "Choosing p=5 or p=6 because it relieves low modes.",
        "severity": "HIGH",
        "mitigation": "Report p=5/p=6 as derived power-count candidates, not selected laws; no mass or particle mapping is loaded.",
    },
    {
        "risk": "Identity-anchor normalization is mistaken for a physical threshold theorem.",
        "severity": "MEDIUM",
        "mitigation": "Mark normalization as an anchor convention and keep unique closure-rent law open.",
    },
    {
        "risk": "Power-count rent law is mistaken for PDE/GR closure.",
        "severity": "HIGH",
        "mitigation": "State that R132 is a screen and a future PDE/action derivation is required.",
    },
    {
        "risk": "Low-mode relief is interpreted as lepton mapping.",
        "severity": "HIGH",
        "mitigation": "No rho-to-particle map is declared; observations are sanity context only.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R133",
        "title": "Rent-Normalized Feedback Candidate Generation Gate",
        "goal": "Use the derived p=5/p=6 rent candidates to build rent-normalized feedback functionals without mass data.",
        "must_not_do": "Do not choose p by particle-mass hits or map rho modes to particles.",
    },
    {
        "next_gate": "FORCE_R134",
        "title": "Observation Sanity / Sector-Split Control Gate",
        "goal": "After rent law candidates are frozen, check whether standalone/collective classifications are observation-compatible without fitting.",
        "must_not_do": "Do not tune classifications to leptons/quarks.",
    },
    {
        "next_gate": "FORCE_R128",
        "title": "GR/Lag Field Derivation Gate",
        "goal": "Attempt to derive the radius/depth feedback and rent law from a more principled field equation.",
        "must_not_do": "Do not treat scalar power counting as full GR/PDE closure.",
    },
])

gate_audit = pd.DataFrame([
    {
        "test": "power_count_derivation_generated",
        "result": "PASS" if power_count_derivation_generated else "WARN",
        "interpretation": "Radius, volume, write-density, and self-energy rent scalings were generated.",
    },
    {
        "test": "required_power_threshold_reported",
        "result": "PASS" if required_power_threshold_reported else "WARN",
        "interpretation": f"Minimum identity-normalized power needed to relieve all low modes is p >= {min_power_to_relieve_all_low_modes:.6g}.",
    },
    {
        "test": "derived_power_threshold_bracketed",
        "result": "PASS" if derived_power_threshold_bracketed else "WARN",
        "interpretation": "The threshold lies between p=4 write-density and p=5 quadratic self-energy demand.",
    },
    {
        "test": "low_order_controls_fail_relief",
        "result": "PASS" if low_order_controls_fail_relief else "WARN",
        "interpretation": "Shallow rent laws p<=4 preserve the R130/R131 low-mode reversal.",
    },
    {
        "test": "derived_low_mode_relief_present",
        "result": "PASS" if derived_low_mode_relief_present else "WARN",
        "interpretation": "Derived self-energy-like rent laws p=5/p=6 relieve the low-mode reversal under identity-anchor normalization.",
    },
    {
        "test": "observations_used_in_computation",
        "result": "NO",
        "interpretation": "Observation awareness is recorded only as sanity context.",
    },
    {
        "test": "unique_closure_rent_law_closed",
        "result": "OPEN",
        "interpretation": "No unique closure-rent law is proven or selected.",
    },
])

# ---------------------------------------------------------------------
# 7. Save artifacts.
# ---------------------------------------------------------------------

power_count_steps.to_csv(OUT / "FORCE_R132_power_count_derivation_steps.csv", index=False)
required_exponent_audit.to_csv(OUT / "FORCE_R132_required_power_threshold_audit.csv", index=False)
rent_profile_scorecard.to_csv(OUT / "FORCE_R132_rent_profile_scorecard.csv", index=False)
adequacy_table.to_csv(OUT / "FORCE_R132_mode_adequacy_table.csv", index=False)
support_ecology_audit.to_csv(OUT / "FORCE_R132_support_ecology_audit.csv", index=False)
virtual_support_status.to_csv(OUT / "FORCE_R132_virtual_support_status.csv", index=False)
observation_awareness.to_csv(OUT / "FORCE_R132_observation_awareness_register.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R132_claim_boundary_matrix.csv", index=False)
risk_register.to_csv(OUT / "FORCE_R132_risk_register.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R132_next_gate_plan.csv", index=False)
gate_audit.to_csv(OUT / "FORCE_R132_gate_audit.csv", index=False)

verdict = {
    "force_id": "FORCE_R132",
    "title": TITLE,
    "freeze_id": FREEZE_ID,
    "status": verdict_status,
    "parameter_grid_generated": parameter_grid_generated,
    "power_count_derivation_generated": power_count_derivation_generated,
    "required_power_threshold_reported": required_power_threshold_reported,
    "min_power_to_relieve_all_low_modes": min_power_to_relieve_all_low_modes,
    "derived_power_threshold_bracketed": derived_power_threshold_bracketed,
    "low_order_controls_fail_relief": low_order_controls_fail_relief,
    "derived_low_mode_relief_present": derived_low_mode_relief_present,
    "p4_relief": p4_relief,
    "p5_relief": p5_relief,
    "p6_relief": p6_relief,
    "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
    "no_mass_matching_performed": no_mass_matching_performed,
    "no_parameter_fit_performed": no_parameter_fit_performed,
    "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
    "no_final_physical_rent_law_selected": no_final_physical_rent_law_selected,
    "unique_closure_rent_law_closed": unique_closure_rent_law_closed,
    "clean_standalone_collective_split_closed": clean_standalone_collective_split_closed,
    "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
    "selected_seed": [frac_label(x) for x in SEED],
    "recommended_next": "FORCE_R133_rent_normalized_feedback_candidate_generation_gate",
}
(OUT / "FORCE_R132_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R132 — Required Closure-Rent Law Derivation Gate

## Verdict

BOXED: {verdict_status}

## Central result

R132 asks whether the R130/R131 low-mode reversal is caused by shallow closure-rent laws.

The minimum identity-normalized power needed for all low modes to pay their own required rent is:

BOXED: p >= {min_power_to_relieve_all_low_modes:.12g}

This lies between:

BOXED: p=4 write-density demand

and

BOXED: p=5 quadratic density self-energy demand

Therefore shallow laws p<=4 preserve the reversal, while self-energy-like laws p>=5 can relieve it without loading masses.

## Key booleans

- power_count_derivation_generated: {power_count_derivation_generated}
- required_power_threshold_reported: {required_power_threshold_reported}
- derived_power_threshold_bracketed: {derived_power_threshold_bracketed}
- low_order_controls_fail_relief: {low_order_controls_fail_relief}
- derived_low_mode_relief_present: {derived_low_mode_relief_present}
- p4_relief: {p4_relief}
- p5_relief: {p5_relief}
- p6_relief: {p6_relief}
- no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}
- no_mass_matching_performed: {no_mass_matching_performed}
- no_parameter_fit_performed: {no_parameter_fit_performed}
- no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}
- unique_closure_rent_law_closed: {unique_closure_rent_law_closed}

## Gate audit

{gate_audit.to_string(index=False)}

## Power-count derivation steps

{power_count_steps.to_string(index=False)}

## Required exponent audit

{required_exponent_audit.to_string(index=False)}

## Rent profile scorecard

{rent_profile_scorecard.to_string(index=False)}

## Support ecology audit

{support_ecology_audit.to_string(index=False)}

## Observation awareness

{observation_awareness.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Risk register

{risk_register.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}
"""
(OUT / "FORCE_R132_summary.md").write_text(summary, encoding="utf-8")

# Plots.
plt.figure(figsize=(8, 5))
plt.bar(rent_profile_scorecard["power"].astype(str), rent_profile_scorecard["identity_norm_low_surplus_count"])
plt.axhline(len(LOW_MODES), linestyle="--")
plt.xlabel("rent law power p")
plt.ylabel("low-mode pass count")
plt.title("R132 low-mode relief by required-rent power")
plt.tight_layout()
plt.savefig(PLOTS / "low_mode_relief_by_power.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(required_exponent_audit["rho"], required_exponent_audit["required_power_lower_bound"])
plt.axhline(min_power_to_relieve_all_low_modes, linestyle="--")
plt.xlabel("low mode rho")
plt.ylabel("required p lower bound")
plt.title("R132 required power lower bound by low mode")
plt.tight_layout()
plt.savefig(PLOTS / "required_power_lower_bound.png", dpi=160)
plt.close()

# Manifest.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
manifest = pd.DataFrame(manifest_rows)
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Copy script.
try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R132_required_closure_rent_law_derivation_gate.py")
except Exception:
    pass

# Zip.
if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()
zip_integrity_pass = bad is None

verdict["zip_integrity_pass"] = zip_integrity_pass
(OUT / "FORCE_R132_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

print("\n=== COPY/PASTE R132 RESULT ===")
print("R132 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"parameter_grid_generated: {parameter_grid_generated}")
print(f"power_count_derivation_generated: {power_count_derivation_generated}")
print(f"required_power_threshold_reported: {required_power_threshold_reported}")
print(f"min_power_to_relieve_all_low_modes: {min_power_to_relieve_all_low_modes:.12g}")
print(f"derived_power_threshold_bracketed: {derived_power_threshold_bracketed}")
print(f"low_order_controls_fail_relief: {low_order_controls_fail_relief}")
print(f"derived_low_mode_relief_present: {derived_low_mode_relief_present}")
print(f"p4_relief: {p4_relief}")
print(f"p5_relief: {p5_relief}")
print(f"p6_relief: {p6_relief}")
print(f"no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}")
print(f"no_mass_matching_performed: {no_mass_matching_performed}")
print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
print(f"no_final_physical_rent_law_selected: {no_final_physical_rent_law_selected}")
print(f"unique_closure_rent_law_closed: {unique_closure_rent_law_closed}")
print(f"clean_standalone_collective_split_closed: {clean_standalone_collective_split_closed}")
print(f"physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}")
print(f"selected_seed: {{{label_set(SEED)}}}")
print("GATE_AUDIT:")
print(gate_audit.to_string(index=False))
print("POWER_COUNT_DERIVATION_STEPS:")
print(power_count_steps.to_string(index=False))
print("REQUIRED_EXPONENT_AUDIT:")
print(required_exponent_audit.to_string(index=False))
print("RENT_PROFILE_SCORECARD:")
compact = rent_profile_scorecard[[
    "law_id", "power", "natural_status", "identity_norm_low_surplus_count",
    "identity_norm_all_low_relief", "identity_norm_surplus_modes", "interpretation"
]]
print(compact.to_string(index=False))
print("SUPPORT_ECOLOGY_AUDIT:")
print(support_ecology_audit.to_string(index=False))
print("OBSERVATION_AWARENESS:")
print(observation_awareness.to_string(index=False))
print("CLAIM_BOUNDARY:")
for row in claim_boundary.itertuples(index=False):
    print(f"  {row.status} | {row.claim} -- {row.reason}")
print("RISK_REGISTER:")
print(risk_register.to_string(index=False))
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R132_summary.md').resolve()}")
print("NEXT: FORCE_R133_rent_normalized_feedback_candidate_generation_gate_or_FORCE_R128_GR_lag_field_derivation_gate")
print("=== END COPY/PASTE R132 RESULT ===\n")
