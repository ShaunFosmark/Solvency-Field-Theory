#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R131_mode_normalized_closure_rent_adequacy_gate.py

SFT V12.9 / FORCE_R131
Mode-Normalized Closure Rent Adequacy Gate

Purpose
-------
R130 used a flat unit-rent screen and classified low-rho modes as isolated-rent failures.
That is mechanically suspicious if low-rho modes are later expected to behave like
standalone/free-particle candidates, because low modes may also have lower required
closure rent. R131 audits that objection without loading masses, without tuning to
particle observations, and without mapping rho modes to particles.

It separates:
  available focusing/feedback A(rho)   (R126 primary feedback proxy)
from:
  required closure rent R_req(rho)      (geometry-only candidate demand profiles)

and computes scale-free adequacy profiles:

  adequacy(rho) = [A(rho)/median(A)] / [R_req(rho)/median(R_req)]

The gate also records a qualitative observation-awareness register, but does not use
observations to modify formulas, thresholds, or classifications.

Boundary
--------
No empirical mass table. No mass matching. No fitting. No rho-to-particle mapping.
No final physical mass law. No claim that a standalone/collective split is physical.
"""

from __future__ import annotations

import csv
import json
import math
import os
import statistics
import sys
import zipfile
from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
SCRIPT_NAME = "FORCE_R131_mode_normalized_closure_rent_adequacy_gate"
OUTDIR = Path.cwd() / SCRIPT_NAME
PACK = Path.cwd() / f"{SCRIPT_NAME}_pack.zip"

# V12.8/V12.9 selected seed order.
SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUALS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

# Embedded R126 primary feedback preview values. These are geometry-only screen values
# from the R126 fixed-point gate, not empirical masses.
R126_PRIMARY_FEEDBACK = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

# R130 mechanical support class labels. These are diagnostic and not particle mappings.
R130_CLASS = {
    Fraction(1, 2): "isolated_rent_fail_collective_candidate",
    Fraction(2, 3): "isolated_rent_fail_collective_candidate",
    Fraction(3, 4): "isolated_rent_fail_collective_candidate",
    Fraction(1, 1): "isolated_rent_fail_collective_candidate",
    Fraction(5, 4): "isolated_rent_pass_virtual_support_dependent",
    Fraction(4, 3): "isolated_rent_pass_clean_internal",
    Fraction(3, 2): "isolated_rent_pass_clean_internal",
    Fraction(5, 3): "isolated_rent_pass_virtual_support_dependent",
    Fraction(2, 1): "isolated_rent_pass_boundary_assisted",
}


def frac_s(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def ffloat(x: Fraction) -> float:
    return x.numerator / x.denominator


def median(xs: Iterable[float]) -> float:
    vals = list(xs)
    return statistics.median(vals)


def safe_ratio(a: float, b: float) -> float:
    return float("nan") if b == 0 else a / b


def write_csv(path: Path, rows: List[dict], fieldnames: List[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def r_partner(r: Fraction) -> Fraction:
    return Fraction(2, 1) - r


def c_partner(r: Fraction) -> Fraction | None:
    return None if r == 0 else Fraction(r.denominator, r.numerator)


def species_accept(r: Fraction) -> bool:
    return r in set(SEED)


def support_role(r: Fraction) -> str:
    if r in set(SEED):
        return "species"
    if r in set(VIRTUALS):
        return "virtual_support"
    if r == 0:
        return "boundary_zero"
    return "outside_screen"


def analytic_lens_proxy(r: Fraction) -> float:
    # Same style as earlier analytic lens proxy: grows nonlinearly with rho while
    # remaining pure geometry. Used only as a diagnostic rent-shape ingredient.
    rho = ffloat(r)
    return (rho ** 3) * math.sqrt(1.0 + rho * rho)


def closure_complexity(r: Fraction) -> float:
    # integer helical closure complexity from p/q representation.
    return math.sqrt(r.numerator * r.numerator + r.denominator * r.denominator)


def support_burden(r: Fraction) -> float:
    # Burden from R/C support ecology only, not observation.
    rp = r_partner(r)
    cp = c_partner(r)
    burden = 1.0
    for p in (rp, cp):
        role = support_role(p) if p is not None else "outside_screen"
        if role == "species":
            burden += 0.0
        elif role == "virtual_support":
            burden += 0.35
        elif role == "boundary_zero":
            burden += 0.20
        else:
            burden += 0.50
    if R130_CLASS[r] == "isolated_rent_fail_collective_candidate":
        burden += 0.15
    return burden


def required_rent_profiles() -> Dict[str, Dict[Fraction, float]]:
    profiles: Dict[str, Dict[Fraction, float]] = {}
    # Controls and natural-ish geometric demand laws. These are not fitted to masses.
    profiles["unit_rent_control"] = {r: 1.0 for r in SEED}
    for k, name in [
        (1.0, "rho_power_1_linear_winding_demand"),
        (2.0, "rho_power_2_curvature_demand"),
        (3.0, "rho_power_3_density_demand"),
        (4.0, "rho_power_4_depth_demand"),
        (5.0, "rho_power_5_strong_depth_control"),
        (6.0, "rho_power_6_high_order_control"),
        (7.0, "rho_power_7_posthoc_shape_control_not_law"),
    ]:
        profiles[name] = {r: ffloat(r) ** k for r in SEED}
    profiles["sqrt_p2_plus_q2_closure_complexity"] = {r: closure_complexity(r) for r in SEED}
    profiles["denominator_slot_demand"] = {r: float(r.denominator) for r in SEED}
    profiles["support_burden_R_C_ecology"] = {r: support_burden(r) for r in SEED}
    profiles["lens_proxy_required_demand"] = {r: analytic_lens_proxy(r) for r in SEED}
    profiles["lens_proxy_times_support_burden"] = {r: analytic_lens_proxy(r) * support_burden(r) for r in SEED}
    return profiles


def normalized_adequacy_rows() -> Tuple[List[dict], List[dict], List[dict]]:
    avail = R126_PRIMARY_FEEDBACK
    avail_med = median(avail.values())
    profiles = required_rent_profiles()
    rows: List[dict] = []
    summary: List[dict] = []
    split_rows: List[dict] = []

    low_set = {Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1)}
    clean_isolated_set = {Fraction(4, 3), Fraction(3, 2)}

    for pname, req in profiles.items():
        req_med = median(req.values())
        adequacy: Dict[Fraction, float] = {}
        for r in SEED:
            avail_norm = avail[r] / avail_med
            req_norm = req[r] / req_med if req_med else float("nan")
            adequacy[r] = safe_ratio(avail_norm, req_norm)
            rows.append({
                "rent_profile": pname,
                "rho": frac_s(r),
                "rho_float": f"{ffloat(r):.12g}",
                "available_feedback_R126_primary": f"{avail[r]:.12g}",
                "available_norm_median1": f"{avail_norm:.12g}",
                "required_rent_raw": f"{req[r]:.12g}",
                "required_rent_norm_median1": f"{req_norm:.12g}",
                "mode_normalized_adequacy": f"{adequacy[r]:.12g}",
                "relative_adequacy_class": "relative_surplus" if adequacy[r] >= 1.0 else "relative_deficit",
                "R130_unit_rent_class": R130_CLASS[r],
                "R_partner": frac_s(r_partner(r)),
                "R_partner_role": support_role(r_partner(r)),
                "C_partner": frac_s(c_partner(r)) if c_partner(r) is not None else "none",
                "C_partner_role": support_role(c_partner(r)) if c_partner(r) is not None else "none",
            })
        pass_modes = [frac_s(r) for r in SEED if adequacy[r] >= 1.0]
        deficit_modes = [frac_s(r) for r in SEED if adequacy[r] < 1.0]
        low_surplus_count = sum(1 for r in low_set if adequacy[r] >= 1.0)
        clean_surplus_count = sum(1 for r in clean_isolated_set if adequacy[r] >= 1.0)
        dyn = max(adequacy.values()) / min(adequacy.values())
        summary.append({
            "rent_profile": pname,
            "adequacy_dynamic_range": f"{dyn:.12g}",
            "relative_surplus_count": len(pass_modes),
            "relative_deficit_count": len(deficit_modes),
            "low_mode_surplus_count": low_surplus_count,
            "clean_isolated_surplus_count": clean_surplus_count,
            "relative_surplus_modes": ", ".join(pass_modes),
            "relative_deficit_modes": ", ".join(deficit_modes),
            "unit_reversal_persists_for_low_modes": str(low_surplus_count == 0),
            "interpretation": interpret_profile(pname, low_surplus_count, clean_surplus_count),
        })
        for label, subset in [
            ("low_modes_R130_unit_fail_set", low_set),
            ("clean_isolated_R130_set", clean_isolated_set),
        ]:
            vals = [adequacy[r] for r in subset]
            split_rows.append({
                "rent_profile": pname,
                "subset": label,
                "n_modes": len(subset),
                "median_adequacy": f"{median(vals):.12g}",
                "min_adequacy": f"{min(vals):.12g}",
                "max_adequacy": f"{max(vals):.12g}",
                "surplus_count": sum(1 for v in vals if v >= 1.0),
            })
    return rows, summary, split_rows


def interpret_profile(pname: str, low_surplus_count: int, clean_surplus_count: int) -> str:
    if "posthoc" in pname:
        return "High-order shape control; useful for diagnosing how steep required rent must be, not a law."
    if low_surplus_count == 0 and clean_surplus_count >= 1:
        return "R130 reversal persists under this rent shape; either mapping intuition is wrong or rent law still incomplete."
    if low_surplus_count > 0:
        return "Mode-normalized rent can relieve the low-mode unit-rent failure under this shape."
    return "Diagnostic only."


def observation_awareness_register() -> List[dict]:
    return [
        {
            "observation_or_expectation": "Some observed charged leptons can exist as unconfined particles; electron is stable, muon/tau are unstable but not confined.",
            "used_in_computation": False,
            "why_recorded": "Sanity check: a future rho-to-lepton mapping should not require neighbor support merely because of a flat unit-rent normalization.",
            "boundary": "No rho-to-lepton mapping is performed here.",
        },
        {
            "observation_or_expectation": "Quarks are not observed as isolated free particles and are treated through confined/scheme-dependent mass concepts.",
            "used_in_computation": False,
            "why_recorded": "Sanity check: collective-support classes may be relevant later, but should not be asserted from R130/R131 alone.",
            "boundary": "No rho-to-quark mapping is performed here.",
        },
        {
            "observation_or_expectation": "R130's flat unit threshold made low-feedback modes look collective-dependent.",
            "used_in_computation": False,
            "why_recorded": "This may be a normalization artifact because low modes may have lower required closure bills.",
            "boundary": "R131 audits mode-normalized rent profiles but does not select a physical threshold.",
        },
        {
            "observation_or_expectation": "Pairwise hits from R127 are interesting but multiple-comparison risk remains high.",
            "used_in_computation": False,
            "why_recorded": "Observation awareness helps identify missing physics without tuning formulas to hits.",
            "boundary": "No mass table or pairwise ratio table is loaded in R131.",
        },
    ]


def claim_boundary_rows(verdict: str) -> List[dict]:
    return [
        {"claim": "R131 tests whether R130's unit-rent reversal is sensitive to mode-normalized closure rent.", "status": "YES_SCREEN", "reason": "Available focusing is divided by geometry-only required-rent profiles, with all profiles reported."},
        {"claim": "R131 uses qualitative observation awareness as sanity context.", "status": "YES_CONTEXT", "reason": "Observation notes are recorded but not used to compute formulas, thresholds, or classifications."},
        {"claim": "R131 compares rho modes to observed particle masses.", "status": "NO", "reason": "No empirical mass table or mass-ratio table is loaded."},
        {"claim": "R131 maps rho modes to leptons, quarks, or Standard Model particles.", "status": "NO", "reason": "No physical particle identities are assigned."},
        {"claim": "R131 proves a unique closure-rent law.", "status": "NO", "reason": "Multiple rent profiles are screened; no unique physical threshold is derived."},
        {"claim": "R131 selects a final standalone/collective split.", "status": "NO", "reason": "Adequacy classes are normalization/rent-profile diagnostics only."},
        {"claim": "R131 promotes virtual supports to species.", "status": "NO", "reason": "V12.8 species projection remains locked."},
        {"claim": "R131 closes true GR/PDE collective field dynamics.", "status": "NO", "reason": "This is a closure-rent normalization audit, not a field-equation derivation."},
    ]


def make_summary(verdict: str, summary_rows: List[dict], verdict_data: dict) -> str:
    lines: List[str] = []
    lines.append(f"# FORCE_R131 Summary")
    lines.append("")
    lines.append(f"**Verdict:** {verdict}")
    lines.append(f"**Freeze ID:** `{FREEZE_ID}`")
    lines.append("")
    lines.append("## Core result")
    lines.append("")
    lines.append("R131 audits the objection that R130's standalone/collective split may be reversed because it used one flat unit-rent threshold. It computes mode-normalized adequacy by comparing available R126 feedback against candidate required closure-rent profiles.")
    lines.append("")
    lines.append("## Important boundary")
    lines.append("")
    lines.append("No masses, no matching, no fitting, no rho-to-particle mapping, and no final standalone/collective split are claimed.")
    lines.append("")
    lines.append("## Top rent-profile diagnostics")
    lines.append("")
    for row in summary_rows[:8]:
        lines.append(f"- `{row['rent_profile']}`: low_surplus={row['low_mode_surplus_count']}, surplus_modes={row['relative_surplus_modes']}")
    lines.append("")
    lines.append("## Interpretation")
    lines.append("")
    lines.append("If low modes fail under flat unit rent but pass under a sufficiently steep required-rent profile, the R130 reversal is a threshold-normalization artifact. If they fail under all natural rent profiles, then either the later physical mapping intuition is wrong or the closure-rent law still lacks a needed ingredient.")
    return "\n".join(lines)


def zip_dir(src: Path, dst: Path) -> bool:
    if dst.exists():
        dst.unlink()
    with zipfile.ZipFile(dst, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(src.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(src.parent))
    try:
        with zipfile.ZipFile(dst, "r") as z:
            bad = z.testzip()
        return bad is None
    except Exception:
        return False


def main() -> int:
    OUTDIR.mkdir(parents=True, exist_ok=True)

    adequacy_rows, rent_summary_rows, split_rows = normalized_adequacy_rows()

    # Sort summaries to surface the profiles that most directly address the low-mode objection.
    rent_summary_rows_sorted = sorted(
        rent_summary_rows,
        key=lambda r: (-int(r["low_mode_surplus_count"]), float(r["adequacy_dynamic_range"])),
    )

    # Determine key screens.
    unit_row = next(r for r in rent_summary_rows if r["rent_profile"] == "unit_rent_control")
    low_relief_profiles = [r for r in rent_summary_rows if int(r["low_mode_surplus_count"]) > 0]
    natural_low_relief_profiles = [
        r for r in low_relief_profiles
        if "posthoc" not in r["rent_profile"] and "high_order_control" not in r["rent_profile"]
    ]
    posthoc_control_profiles = [r for r in rent_summary_rows if "posthoc" in r["rent_profile"]]

    # Observational awareness exists but is not computational input.
    obs_rows = observation_awareness_register()

    verdict = "MODE-NORMALIZED CLOSURE RENT ADEQUACY SCREEN PASS / UNIT-RENT REVERSAL AUDITED, UNIQUE SPLIT OPEN"
    verdict_data = {
        "R131_COMPLETE": True,
        "VERDICT": verdict,
        "FREEZE_ID": FREEZE_ID,
        "parameter_grid_generated": True,
        "r126_feedback_values_loaded_as_geometry_screen_input": True,
        "mode_normalized_rent_profiles_generated": True,
        "adequacy_table_generated": True,
        "unit_rent_reversal_flagged": unit_row["unit_reversal_persists_for_low_modes"] == "True",
        "low_modes_relief_profiles_present": len(low_relief_profiles) > 0,
        "natural_low_modes_relief_profiles_present": len(natural_low_relief_profiles) > 0,
        "posthoc_shape_control_reported_not_used_as_law": len(posthoc_control_profiles) > 0,
        "observation_awareness_register_present": True,
        "observations_used_in_computation": False,
        "no_empirical_mass_data_loaded": True,
        "no_mass_matching_performed": True,
        "no_parameter_fit_performed": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "unique_closure_rent_law_closed": False,
        "clean_standalone_collective_split_closed": False,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "true_GR_PDE_collective_field_closed": False,
        "selected_seed": "{" + ", ".join(frac_s(r) for r in SEED) + "}",
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
        "next": "FORCE_R132_required_rent_law_derivation_gate_or_FORCE_R131B_observation_sanity_control_gate",
    }

    write_csv(OUTDIR / "R131_mode_normalized_adequacy.csv", adequacy_rows)
    write_csv(OUTDIR / "R131_rent_profile_summary.csv", rent_summary_rows_sorted)
    write_csv(OUTDIR / "R131_split_subset_diagnostics.csv", split_rows)
    write_csv(OUTDIR / "R131_observation_awareness_register.csv", obs_rows)
    cb_rows = claim_boundary_rows(verdict)
    write_csv(OUTDIR / "R131_claim_boundary.csv", cb_rows)

    summary_text = make_summary(verdict, rent_summary_rows_sorted, verdict_data)
    (OUTDIR / "FORCE_R131_summary.md").write_text(summary_text, encoding="utf-8")
    (OUTDIR / "FORCE_R131_verdict.json").write_text(json.dumps(verdict_data, indent=2), encoding="utf-8")

    manifest_rows = []
    for path in sorted(OUTDIR.rglob("*")):
        if path.is_file():
            manifest_rows.append({"file": str(path.relative_to(OUTDIR)), "bytes": path.stat().st_size})
    write_csv(OUTDIR / "artifact_manifest.csv", manifest_rows)
    zip_ok = zip_dir(OUTDIR, PACK)
    verdict_data["ZIP_INTEGRITY"] = "PASS" if zip_ok else "FAIL"
    (OUTDIR / "FORCE_R131_verdict.json").write_text(json.dumps(verdict_data, indent=2), encoding="utf-8")

    print("=== COPY/PASTE R131 RESULT ===")
    print("R131 COMPLETE")
    print(f"VERDICT: {verdict}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    for key in [
        "parameter_grid_generated",
        "r126_feedback_values_loaded_as_geometry_screen_input",
        "mode_normalized_rent_profiles_generated",
        "adequacy_table_generated",
        "unit_rent_reversal_flagged",
        "low_modes_relief_profiles_present",
        "natural_low_modes_relief_profiles_present",
        "posthoc_shape_control_reported_not_used_as_law",
        "observation_awareness_register_present",
        "observations_used_in_computation",
        "no_empirical_mass_data_loaded",
        "no_mass_matching_performed",
        "no_parameter_fit_performed",
        "no_mode_particle_mapping_performed",
        "no_final_physical_mass_law_selected",
        "unique_closure_rent_law_closed",
        "clean_standalone_collective_split_closed",
        "physical_mass_spectrum_claimed",
        "SM_mass_matching_claimed",
        "true_GR_PDE_collective_field_closed",
    ]:
        print(f"{key}: {verdict_data[key]}")
    print(f"selected_seed: {verdict_data['selected_seed']}")
    print(f"canonical_species_formula: {verdict_data['canonical_species_formula']}")
    print("TOP_RENT_PROFILE_DIAGNOSTICS:")
    for row in rent_summary_rows_sorted[:10]:
        print(
            f"  {row['rent_profile']} | low_surplus={row['low_mode_surplus_count']} | "
            f"clean_surplus={row['clean_isolated_surplus_count']} | dyn={row['adequacy_dynamic_range']} | "
            f"surplus={row['relative_surplus_modes']} | interpretation={row['interpretation']}"
        )
    print("OBSERVATION_AWARENESS:")
    for row in obs_rows:
        print(
            f"  used={row['used_in_computation']} | {row['observation_or_expectation']} -- {row['boundary']}"
        )
    print("CLAIM_BOUNDARY:")
    for row in cb_rows:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print(f"PACK: {PACK}")
    print(f"SUMMARY: {OUTDIR / 'FORCE_R131_summary.md'}")
    print(f"NEXT: {verdict_data['next']}")
    print("=== END COPY/PASTE R131 RESULT ===")
    return 0 if zip_ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
