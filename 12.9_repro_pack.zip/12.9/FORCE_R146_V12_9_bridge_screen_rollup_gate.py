#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R146_V12_9_bridge_screen_rollup_gate.py

V12.9 bridge-screen rollup gate.

Purpose
-------
Freeze the honest state after R116-R145 plus R128:
  * mass-amplitude and closure-adequacy are separate objects;
  * raw feedback is the lead mass-amplitude baseline;
  * R137/R139 bridge candidates survive as field-screen-supported hierarchy-scale candidates;
  * R142/R143/R144 ratio screens are exploratory only;
  * R145 null controls downgrade pairwise hits as empirical evidence;
  * next step is not more ratio hunting, but structured (m,N)/normal-bundle shape factors and/or deep GR/PDE derivation.

No empirical mass table is loaded in this gate. No matching, fitting, retuning, or rho-to-particle mapping is performed.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import shutil
import textwrap
import zipfile
from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, Iterable, List

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "R146"
GATE_TITLE = "V12.9 Bridge Screen Rollup"
SCRIPT_NAME = "FORCE_R146_V12_9_bridge_screen_rollup_gate.py"

SEED = [Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1), Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

# Frozen scalar diagnostics from the preceding gate chain. These are not recomputed from data here.
RAW_FEEDBACK_DYNAMIC_RANGE = 17999.7689742
FROZEN_R127_DYNAMIC_BENCHMARK = 338083.0
MISSING_FACTOR = FROZEN_R127_DYNAMIC_BENCHMARK / RAW_FEEDBACK_DYNAMIC_RANGE
REQUIRED_BETA_CONTROL_NOT_LAW = math.log(FROZEN_R127_DYNAMIC_BENCHMARK / RAW_FEEDBACK_DYNAMIC_RANGE) / math.log(RAW_FEEDBACK_DYNAMIC_RANGE)


@dataclass
class AuditItem:
    test: str
    result: str
    interpretation: str


@dataclass
class GateLedgerRow:
    gate: str
    title: str
    status: str
    contribution: str
    boundary: str


@dataclass
class ObjectRow:
    object_id: str
    plain_name: str
    question_answered: str
    dynamic_range: str
    status: str
    interpretation: str


@dataclass
class BridgeCandidateRow:
    candidate_id: str
    family: str
    beta: str
    gamma: str
    dynamic_range: float
    relation_to_benchmark: str
    factor: float
    tier: str
    status: str
    interpretation: str


@dataclass
class EvidenceRow:
    evidence_item: str
    status: str
    what_survives: str
    what_does_not_survive: str
    next_action: str


@dataclass
class ClaimBoundaryRow:
    claim: str
    status: str
    safe_wording: str
    reason: str


@dataclass
class NextGateRow:
    next_gate: str
    title: str
    goal: str
    must_not_do: str


def fmt_frac(fr: Fraction) -> str:
    return str(fr.numerator) if fr.denominator == 1 else f"{fr.numerator}/{fr.denominator}"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_csv(path: Path, rows: Iterable[Any]) -> None:
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    first = rows[0]
    if hasattr(first, "__dataclass_fields__"):
        fieldnames = list(asdict(first).keys())
        dict_rows = [asdict(r) for r in rows]
    else:
        fieldnames = list(first.keys())
        dict_rows = rows
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(dict_rows)


def table_text(headers: List[str], rows: List[List[Any]]) -> str:
    str_rows = [[str(x) for x in row] for row in rows]
    widths = [len(h) for h in headers]
    for row in str_rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))
    def line(row: List[str]) -> str:
        return " | ".join(cell.ljust(widths[i]) for i, cell in enumerate(row))
    sep = "-+-".join("-" * w for w in widths)
    return "\n".join([line(headers), sep] + [line(row) for row in str_rows])


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def zip_dir(src_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(src_dir.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(src_dir.parent))


def main() -> None:
    base_dir = Path.cwd()
    out_dir = base_dir / "FORCE_R146_V12_9_bridge_screen_rollup_gate"
    ensure_dir(out_dir)

    selected_seed = "{" + ", ".join(fmt_frac(x) for x in SEED) + "}"

    gate_ledger = [
        GateLedgerRow("R116-R120", "F(rho) proxy and self-energy screens", "PASS / SCREEN", "Geometry-native focusing candidates and first blind mass screens were generated.", "Toy/proxy F(rho) values are not final mass laws."),
        GateLedgerRow("R121-R124", "Finite-part, scheme-clean, PDE-scalar, and uncertainty screens", "PASS / SCREEN", "Finite-part route and scheme-clean screens survived as diagnostics.", "Unique renormalization and true PDE/GR mass law remain open."),
        GateLedgerRow("R125-R127", "Gravity-map and feedback fixed-point screens", "PASS / LEAD MASS-AMPLITUDE SCREEN", "Raw radius/depth feedback amplified dynamic range to about 18,000 and gave the lead mass-amplitude object.", "Raw feedback still under-spans full hierarchy by about 18.8x."),
        GateLedgerRow("R129-R135", "Collective, closure-rent, and adequacy screens", "PASS / CLARIFIED", "Mass amplitude and closure adequacy were separated; p=5/p=6 rent laws solve low-mode adequacy reversal.", "Rent-normalized adequacy is not the direct mass functional."),
        GateLedgerRow("R136-R141", "Bridge candidate triage and freeze", "PASS / FROZEN", "Global multipliers rejected; R137 exponent and R139 boundary-area bridge candidates survived; full hybrids excluded as double counting.", "No final bridge law selected."),
        GateLedgerRow("R142-R145", "Locked bridge screen, robustness, null models", "PASS / SOBERING", "Bridge candidates span the hierarchy scale and produce screen hits, but null models show pairwise hit structure is not statistically unusual.", "Pairwise hits are not proof and should be downgraded."),
        GateLedgerRow("R128", "GR/Lag field derivation screen", "PASS / FIELD-SCREEN", "Scalar lag screen supports inverse boundary-area and transverse phase-measure candidates as field-native screens.", "True self-consistent GR/PDE remains open."),
    ]

    object_rows = [
        ObjectRow("M_raw_feedback", "mass-amplitude baseline", "How much focusing/depth/energy does the mode trap?", f"{RAW_FEEDBACK_DYNAMIC_RANGE:.6g}", "LEAD_BASELINE", "Mass-like amplitude from raw radius/depth feedback; under-spans hierarchy alone."),
        ObjectRow("A_rent_normalized_p5", "closure adequacy p=5", "Can the mode pay its self-energy-like closure rent?", "24.276271", "STABILITY_DIAGNOSTIC", "Existence/viability ratio; not a direct mass magnitude."),
        ObjectRow("A_rent_normalized_p6", "closure adequacy p=6", "Can the mode pay curvature-weighted closure rent?", "12.138136", "STABILITY_DIAGNOSTIC", "Composite adequacy diagnostic; not a direct mass magnitude."),
        ObjectRow("M_bridge_candidates", "bridge-corrected mass-amplitude screens", "Can field-native transverse/boundary corrections bridge the missing hierarchy scale?", "~288k to ~339k", "PRIMARY_SCREEN_OBJECT", "R137/R139 candidates bridge dynamic range but remain screens until field derivation."),
        ObjectRow("G_shape_pending", "structured shape factor", "Does (m,N) and normal-bundle pattern add specific internal structure beyond one-dimensional rho?", "not yet computed", "NEXT_PROGRAM_OBJECT", "Needed because R145 showed 1D monotonic curves do not beat null models."),
    ]

    bridge_candidates = [
        BridgeCandidateRow("R137_transverse_phase_volume_6pi_exponent", "compound_transverse_lens", "ln(6pi)/ln(D_raw)", "0", 339287.651855, "overshoot", 1.003563, "PRIMARY", "FROZEN_SURVIVOR", "Numerically strongest single-mechanism bridge; field-screen supported but not final."),
        BridgeCandidateRow("R137_oriented_modes_18_exponent", "compound_transverse_lens", "ln(18)/ln(D_raw)", "0", 323995.841537, "shortfall", 1.043479, "PRIMARY", "FROZEN_SURVIVOR", "Near-target oriented-mode exponent source; field-screen supported but not final."),
        BridgeCandidateRow("R139_boundary_area_rho2_candidate", "boundary_insolvency", "0", "2", 287996.303588, "shortfall", 1.173914, "PRIMARY", "FROZEN_SURVIVOR", "Mechanically clean inverse boundary-area / V11-adjacent bridge screen."),
        BridgeCandidateRow("R140B_partial_slot_beta_boundary_quarter", "partial_hybrid_screen", "1/4", "1/4", 294848.322718, "shortfall", 1.146634, "SECONDARY", "QUEUED_NOT_SELECTED", "Partial hybrid is within 25%, but double-counting risk keeps it secondary."),
        BridgeCandidateRow("R140B_partial_slot_beta_boundary_half", "partial_hybrid_screen", "1/4", "1/2", 416978.496831, "overshoot", 1.233361, "SECONDARY", "QUEUED_NOT_SELECTED", "Partial hybrid is within 25%, but double-counting risk keeps it secondary."),
        BridgeCandidateRow("full_exponent_times_rho2_hybrids", "hybrid_double_counting_control", "various", "2", 5428602.42968, "overshoot", 16.057011, "EXCLUDED", "DOUBLE_COUNTING_CONTROL", "Full hybrids over-bridge badly and likely count overlapping transverse/boundary physics twice."),
        BridgeCandidateRow("R138_support_graph_coupling", "support_graph", "n/a", "n/a", 35999.5379485, "shortfall", 9.391315, "DIAGNOSTIC", "NOT_BRIDGE", "Useful closure ecology diagnostic, too weak as a hierarchy bridge."),
    ]

    evidence_rows = [
        EvidenceRow("dynamic_range_bridge", "SURVIVES_AS_SCREEN", "Primary bridge candidates span the charged-fermion hierarchy benchmark within about 25% without new mass loading at R141/R128.", "This is not a final mass law because candidates were screened for hierarchy-scale bridging.", "Derive mechanism from field equations and/or structured winding data."),
        EvidenceRow("pairwise_ratio_hits", "DOWNGRADED", "Bridge candidates produce many 1%/5% pairwise screen hits and at least one clean lepton-sector internal hit.", "R145 nulls show hit counts are not statistically unusual for monotonic curves with the same dynamic range.", "Do not use hit counts as proof; use robustness/null controls in any public language."),
        EvidenceRow("endpoint_full_span_hit", "LIMITED_EVIDENCE", "Endpoint dynamic range match is numerically close.", "Endpoint hits are range-selected and not independent evidence.", "Keep endpoint hits out of independent evidence counts."),
        EvidenceRow("quark_sector_hits", "SUPPORTIVE_WITH_CAVEAT", "Same-sector quark hits persist through uncertainty screens.", "Quark masses are scheme/scale dependent and uncertainty intervals can be wide.", "Treat as screen-only until sector derivation exists."),
        EvidenceRow("lepton_internal_hit", "IMPORTANT_SCREEN_SIGNAL_BUT_NOT_PROOF", "R139 boundary-area had a tau/muon-style internal lepton hit in the prior screen.", "R145 does not show lepton hit metrics are unusual versus nulls.", "Preserve as a notable screen datum, not as validation."),
        EvidenceRow("one_dimensional_Frho", "INSUFFICIENT_RESOLUTION", "F(rho) can produce hierarchy-scale curves.", "A one-variable monotonic curve is too easy to mimic with null models.", "Move to structured M(rho,m,N,normal-bundle pattern)."),
    ]

    claim_boundary = [
        ClaimBoundaryRow("V12.9 identifies field-screen-supported bridge candidates for the mass-amplitude hierarchy scale.", "YES_SCREEN", "V12.9 finds scalar-lag/geometry screens that can bridge the hierarchy scale.", "R137/R139/R128 support transverse phase and inverse boundary-area candidates as screens."),
        ClaimBoundaryRow("V12.9 derives the physical charged-fermion mass spectrum.", "NO", "Physical mass-spectrum derivation remains open.", "No rho-to-particle mapping, no full GR/PDE derivation, and R145 null risk remains high."),
        ClaimBoundaryRow("Pairwise mass-ratio hits prove the F(rho) shape.", "NO", "Pairwise hits are exploratory and null-risk remains high.", "R145 found no p-value metric below 0.05 against the chosen monotonic nulls."),
        ClaimBoundaryRow("The hierarchy-scale bridge is final.", "NO", "Bridge candidates are frozen screens, not final laws.", "R128 is scalar/lag screen only; true self-consistent GR/PDE remains open."),
        ClaimBoundaryRow("Rent-normalized adequacy is the mass functional.", "NO", "Rent-normalized adequacy is a closure/stability diagnostic.", "R135/R136 showed adequacy has much smaller range and answers whether a mode can pay rent, not how massive it is."),
        ClaimBoundaryRow("The next mass program should include internal winding structure beyond rho.", "YES_NEXT_PROGRAM", "Next step is an (m,N)/shape-tensor mass-functional gate.", "R145 indicates one-dimensional monotonic curves lack enough structure to beat nulls."),
    ]

    next_gates = [
        NextGateRow("FORCE_R147", "(m,N) Shape-Tensor Mass Functional Gate", "Compute slot occupancy, normal-bundle shape/eccentricity, and support-ecology factors without masses.", "Do not map modes to leptons/quarks or tune shape factors to ratio hits."),
        NextGateRow("FORCE_R148", "Structured Mass Screen / Null-Model Upgrade Gate", "After shape factors are frozen, compare structured candidate against nulls that preserve dynamic range but not shape/slot structure.", "Do not count one-dimensional dynamic-range endpoint hits as independent evidence."),
        NextGateRow("DEEP_GR_PDE", "Covariant GR/Lag Field Derivation Deep Gate", "Derive whether inverse boundary-area, transverse exponent, or a unified correction emerges from a principled field equation.", "Do not treat R128 scalar screen as full GR/PDE closure."),
        NextGateRow("V12_9_PUBLIC_NOTE", "Safe V12.9 Public Note / Appendix Draft", "Prepare safe language: hierarchy-scale bridge candidates and null-risk boundary.", "Do not claim physical spectrum, SM matching, masses, or final law."),
    ]

    audit = [
        AuditItem("mass_amplitude_adequacy_separated", "PASS", "Raw feedback/bridge candidates are mass-amplitude screens; p=5/p=6 rent ratios are closure-adequacy diagnostics."),
        AuditItem("bridge_candidates_frozen", "PASS", "R141 froze primary bridge candidates and excluded full hybrids as double-counting controls."),
        AuditItem("dynamic_range_bridge_survives", "PASS_SCREEN", "R137/R139/R128 primary bridge candidates span the benchmark scale within the intended screen boundary."),
        AuditItem("pairwise_hits_downgraded_by_nulls", "PASS_SOBERING", "R145 found primary hit structure is not unusual against random monotonic curves with the same dynamic range."),
        AuditItem("field_screen_support_present", "PASS_SCREEN", "R128 supports inverse boundary-area and transverse phase-measure candidates as scalar lag/field screens."),
        AuditItem("one_dimensional_Frho_limit_identified", "PASS", "R145 indicates F(rho) alone lacks internal structure to beat null models."),
        AuditItem("shape_tensor_next_program_queued", "PASS", "R147 is queued to include m, N, slot distribution, normal-bundle pattern, and support ecology."),
        AuditItem("no_new_empirical_mass_data_loaded", "PASS", "R146 performs rollup only and loads no mass table."),
        AuditItem("no_mass_matching_performed", "PASS", "R146 performs no pairwise mass comparison."),
        AuditItem("no_parameter_fit_performed", "PASS", "No exponents, thresholds, powers, or candidate values are optimized."),
        AuditItem("no_mode_particle_mapping_performed", "PASS", "No rho-to-particle assignments are made."),
        AuditItem("no_final_physical_mass_law_selected", "PASS", "All bridge and shape directions remain candidate programs."),
        AuditItem("true_GR_PDE_collective_field_closed", "OPEN", "Only scalar/lag screens exist; a full covariant self-consistent field derivation remains open."),
        AuditItem("physical_mass_spectrum_claimed", "NO", "The nine modes remain mechanical/operator-geometric seed modes, not confirmed Standard Model particles."),
    ]

    # Write artifacts.
    write_csv(out_dir / "R146_gate_ledger.csv", gate_ledger)
    write_csv(out_dir / "R146_object_separation.csv", object_rows)
    write_csv(out_dir / "R146_bridge_candidate_roster.csv", bridge_candidates)
    write_csv(out_dir / "R146_evidence_status.csv", evidence_rows)
    write_csv(out_dir / "R146_claim_boundary.csv", claim_boundary)
    write_csv(out_dir / "R146_next_gate_plan.csv", next_gates)
    write_csv(out_dir / "R146_audit.csv", audit)

    summary_md = f"""# {GATE_ID}: {GATE_TITLE}

**Freeze ID:** `{FREEZE_ID}`  
**Verdict:** BRIDGE SCREEN ROLLUP PASS / HIERARCHY-SCALE CANDIDATES PRESERVED, PAIRWISE HITS DOWNGRADED, STRUCTURED MASS FUNCTIONAL NEXT

## Canonical seed

`{selected_seed}`

`{CANONICAL_SPECIES_FORMULA}`

## Core result

R146 freezes the honest V12.9 state after R116-R145 plus R128.

The mass program now separates two objects:

```text
M(rho) = raw / bridge-corrected feedback amplitude
A(rho) = available focusing / required closure rent
```

`M(rho)` is mass-amplitude-like. `A(rho)` is closure-adequacy-like. They must not be confused.

## What survives

1. The raw radius/depth feedback baseline produces a large but insufficient dynamic range: `{RAW_FEEDBACK_DYNAMIC_RANGE:.6g}`.
2. R137/R139/R128 provide field-screen-supported bridge candidates near the hierarchy scale.
3. R141 freezes the primary candidates and excludes full hybrids as double-counting controls.
4. R145 downgrades pairwise hits: internal hit structure is not statistically unusual against the chosen random monotonic nulls.
5. Therefore the next step is not more one-dimensional ratio hunting; it is structured mass modeling using `(m,N)` and normal-bundle shape data.

## What does not survive as a claim

R146 does not claim a physical mass spectrum, a Standard Model mapping, a unique bridge law, a GR/PDE derivation, or empirical validation of the internal shape of `F(rho)`.

## Primary bridge candidates

{table_text(['candidate_id','family','dynamic_range','factor','status'], [[r.candidate_id, r.family, f'{r.dynamic_range:.6g}', f'{r.factor:.6g}', r.status] for r in bridge_candidates if r.tier == 'PRIMARY'])}

## Evidence status

{table_text(['evidence_item','status','next_action'], [[r.evidence_item, r.status, r.next_action] for r in evidence_rows])}

## Claim boundary

{table_text(['claim','status','safe_wording'], [[r.claim, r.status, r.safe_wording] for r in claim_boundary])}

## Next gates

{table_text(['next_gate','title','goal'], [[r.next_gate, r.title, r.goal] for r in next_gates])}
"""
    (out_dir / "FORCE_R146_summary.md").write_text(summary_md, encoding="utf-8")

    public_note = f"""# V12.9 Bridge Screen Rollup Note

The V12.9 bridge-screen program identifies candidate geometry/field-screen mechanisms that can bring the raw helical feedback dynamic range from about `{RAW_FEEDBACK_DYNAMIC_RANGE:.6g}` to the charged-fermion hierarchy-scale benchmark of about `{FROZEN_R127_DYNAMIC_BENCHMARK:.6g}`. The leading single-mechanism candidates are the transverse phase-measure exponent route and the inverse boundary-area response route.

This is a hierarchy-scale screen, not a physical mass-spectrum derivation. Pairwise ratio hits are exploratory only. R145 shows that the internal hit pattern is not yet statistically unusual against random monotonic null curves with the same dynamic range.

The next stage should move beyond a one-dimensional `F(rho)` model. The proposed next object is a structured mass-amplitude functional depending on `rho`, numerator `m`, denominator `N`, normal-bundle distribution/shape, and support ecology. This is necessary because a random monotonic curve can mimic many one-dimensional pairwise hits, while a structured winding-pattern model has sharper internal predictions.
"""
    (out_dir / "V12_9_bridge_screen_public_note_safe.md").write_text(public_note, encoding="utf-8")

    manifest = {
        "gate": GATE_ID,
        "title": GATE_TITLE,
        "freeze_id": FREEZE_ID,
        "selected_seed": selected_seed,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "raw_feedback_dynamic_range": RAW_FEEDBACK_DYNAMIC_RANGE,
        "frozen_R127_dynamic_benchmark": FROZEN_R127_DYNAMIC_BENCHMARK,
        "missing_factor": MISSING_FACTOR,
        "required_beta_control_not_law": REQUIRED_BETA_CONTROL_NOT_LAW,
        "claim_boundary_short": "Hierarchy-scale bridge candidates preserved; pairwise hits downgraded by nulls; structured (m,N) shape-tensor mass functional queued; no physical spectrum or final law claimed.",
        "files": sorted(p.name for p in out_dir.iterdir() if p.is_file()),
    }
    (out_dir / "R146_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    # Hash the freeze roster after writing.
    hash_payload = json.dumps({
        "object_rows": [asdict(x) for x in object_rows],
        "bridge_candidates": [asdict(x) for x in bridge_candidates],
        "evidence_rows": [asdict(x) for x in evidence_rows],
        "claim_boundary": [asdict(x) for x in claim_boundary],
        "next_gates": [asdict(x) for x in next_gates],
    }, sort_keys=True)
    freeze_hash = sha256_text(hash_payload)
    (out_dir / "R146_freeze_hash.txt").write_text(freeze_hash + "\n", encoding="utf-8")

    # Copy script into output directory when possible.
    src_script = Path(__file__).resolve()
    try:
        shutil.copy2(src_script, out_dir / SCRIPT_NAME)
    except Exception:
        pass

    zip_path = base_dir / "FORCE_R146_V12_9_bridge_screen_rollup_gate_pack.zip"
    zip_dir(out_dir, zip_path)
    zip_integrity = "PASS" if zip_path.exists() and zip_path.stat().st_size > 0 else "FAIL"

    # Console report.
    print("=== COPY/PASTE R146 RESULT ===")
    print("R146 COMPLETE")
    print("VERDICT: BRIDGE SCREEN ROLLUP PASS / HIERARCHY-SCALE CANDIDATES PRESERVED, PAIRWISE HITS DOWNGRADED, STRUCTURED MASS FUNCTIONAL NEXT")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {zip_integrity}")
    print("mass_amplitude_adequacy_separated: True")
    print("adequacy_not_mass_functional: True")
    print("raw_feedback_lead_mass_amplitude_baseline: True")
    print("primary_bridge_candidates_preserved: True")
    print("pairwise_hits_downgraded_by_null_model: True")
    print("field_screen_support_present: True")
    print("one_dimensional_Frho_limit_identified: True")
    print("shape_tensor_next_program_queued: True")
    print("global_multiplier_rejected: True")
    print("full_hybrids_excluded_as_double_counting: True")
    print("no_new_empirical_mass_data_loaded: True")
    print("no_mass_matching_performed: True")
    print("no_parameter_fit_performed: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_physical_mass_law_selected: True")
    print("true_GR_PDE_collective_field_closed: False")
    print("physical_mass_spectrum_claimed: False")
    print(f"candidate_freeze_hash: {freeze_hash}")
    print(f"selected_seed: {selected_seed}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print(f"raw_feedback_dynamic_range: {RAW_FEEDBACK_DYNAMIC_RANGE}")
    print(f"frozen_R127_dynamic_benchmark: {FROZEN_R127_DYNAMIC_BENCHMARK}")
    print(f"missing_factor: {MISSING_FACTOR}")
    print(f"required_beta_CONTROL_NOT_LAW: {REQUIRED_BETA_CONTROL_NOT_LAW}")
    print("OBJECT_SEPARATION:")
    print(table_text(["object_id", "plain_name", "dynamic_range", "status"], [[r.object_id, r.plain_name, r.dynamic_range, r.status] for r in object_rows]))
    print("PRIMARY_BRIDGE_CANDIDATES:")
    print(table_text(["candidate_id", "family", "dynamic_range", "factor", "status"], [[r.candidate_id, r.family, f"{r.dynamic_range:.6g}", f"{r.factor:.6g}", r.status] for r in bridge_candidates if r.tier == "PRIMARY"]))
    print("EVIDENCE_STATUS:")
    print(table_text(["evidence_item", "status", "what_survives", "what_does_not_survive"], [[r.evidence_item, r.status, r.what_survives, r.what_does_not_survive] for r in evidence_rows]))
    print("CLAIM_BOUNDARY:")
    for row in claim_boundary:
        print(f"  {row.status} | {row.claim} -- {row.reason}")
    print("NEXT_GATE_PLAN:")
    print(table_text(["next_gate", "title", "goal", "must_not_do"], [[r.next_gate, r.title, r.goal, r.must_not_do] for r in next_gates]))
    print(f"PACK: {zip_path}")
    print(f"SUMMARY: {out_dir / 'FORCE_R146_summary.md'}")
    print("NEXT: FORCE_R147_mn_shape_tensor_mass_functional_gate_or_V12_9_public_note")
    print("=== END COPY/PASTE R146 RESULT ===")


if __name__ == "__main__":
    main()
