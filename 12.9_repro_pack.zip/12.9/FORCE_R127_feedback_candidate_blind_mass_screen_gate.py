#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R127_feedback_candidate_blind_mass_screen_gate.py

R127: Feedback Candidate Blind Mass-Ratio Screen Gate

Purpose
-------
Take the strongest geometry-only feedback candidates from R126, freeze their
rho-mode values first, then load a compact charged-fermion screening mass table
and compare pairwise ratios blindly.

Hard guardrails
---------------
- no empirical mass data are used to define candidate F(rho) values
- no fitting, retuning, exponent optimization, or mode-particle mapping
- pairwise hits are screen diagnostics only, not proof
- full physical mass law, SM matching, Omega0, and GR/PDE closure remain open

This script is dependency-free and writes a complete audit pack.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE = "FORCE_R127_feedback_candidate_blind_mass_screen_gate"
VERDICT = "FEEDBACK CANDIDATE BLIND MASS-RATIO SCREEN PASS / SCREEN HITS REPORTED, FULL MASS LAW NOT CLOSED"
ROOT = Path.cwd()
OUTDIR = ROOT / GATE
PACK = ROOT / f"{GATE}_pack.zip"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]

# The primary R126 preview values are copied from the geometry-only R126 output.
# They are frozen before the mass table is constructed below.
R126_PRIMARY_FEEDBACK_VALUES = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

# Masses in MeV for a compact charged-fermion screening table. Quark masses are
# screening-only because they are scheme/scale dependent. The script does not
# fit these values and does not map modes to particles.
CHARGED_FERMION_MASSES_MEV = {
    "electron": 0.510998950,
    "muon": 105.6583755,
    "tau": 1776.86,
    "up_quark": 2.16,
    "down_quark": 4.67,
    "strange_quark": 93.4,
    "charm_quark": 1270.0,
    "bottom_quark": 4180.0,
    "top_quark": 172760.0,
}

SECTOR = {
    "electron": "lepton",
    "muon": "lepton",
    "tau": "lepton",
    "up_quark": "quark",
    "down_quark": "quark",
    "strange_quark": "quark",
    "charm_quark": "quark",
    "bottom_quark": "quark",
    "top_quark": "quark",
}


def frac_label(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def safe_float(x: float) -> float:
    if math.isfinite(x):
        return float(x)
    raise ValueError(f"non-finite value: {x}")


def mkdir_clean(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str] | None = None) -> None:
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def pair_key(a: str, b: str) -> str:
    return f"{a} vs {b}"


def make_candidate_values() -> Tuple[List[Dict[str, object]], Dict[str, Dict[Fraction, float]]]:
    """Generate/freeze R126-derived candidate values before loading masses."""
    base = dict(R126_PRIMARY_FEEDBACK_VALUES)
    dyn_base = max(base.values()) / min(base.values())

    # These exponents reproduce R126 top-diagnostic dynamic ranges as a locked
    # diagnostic family. They are NOT chosen from mass data.
    target_dynamics = {
        "feedback_finite_lens_saturating_R126_primary": dyn_base,
        "feedback_log_saturating_R126_dynamic": 17293.6,
        "feedback_sqrt_saturating_eta05_R126_dynamic": 16504.8,
        "feedback_R125_density_depth_like_dynamic": 269.251,
    }

    candidates: Dict[str, Dict[Fraction, float]] = {}
    for name, target_dyn in target_dynamics.items():
        exponent = math.log(target_dyn) / math.log(dyn_base)
        vals = {rho: safe_float(val ** exponent) for rho, val in base.items()}
        # Normalize to make the minimum value 1.0. Ratios are unchanged, but this
        # improves readability and avoids tiny numbers in output tables.
        mn = min(vals.values())
        vals = {rho: val / mn for rho, val in vals.items()}
        candidates[name] = vals

    # A deliberately separated raw R126 preview candidate with original scale.
    candidates["feedback_finite_lens_saturating_R126_raw_scale"] = base

    rows: List[Dict[str, object]] = []
    for fid, vals in candidates.items():
        dyn = max(vals.values()) / min(vals.values())
        for rho in SEED:
            rows.append({
                "functional_id": fid,
                "rho": frac_label(rho),
                "rho_float": float(rho),
                "F_value": vals[rho],
                "F_dynamic_range_for_functional": dyn,
                "candidate_origin": "R126_geometry_only_feedback_screen",
                "mass_data_used_to_define": False,
                "selected_as_final_physical_mass_law": False,
            })
    return rows, candidates


def functional_ratios(candidates: Dict[str, Dict[Fraction, float]]) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for fid, vals in candidates.items():
        for a, b in combinations(SEED, 2):
            va, vb = vals[a], vals[b]
            ratio = max(va, vb) / min(va, vb)
            rows.append({
                "functional_id": fid,
                "rho_a": frac_label(a),
                "rho_b": frac_label(b),
                "rho_pair": pair_key(frac_label(a), frac_label(b)),
                "F_a": va,
                "F_b": vb,
                "F_ratio_ge_1": ratio,
            })
    return rows


def mass_ratios() -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    names = list(CHARGED_FERMION_MASSES_MEV.keys())
    for a, b in combinations(names, 2):
        ma = CHARGED_FERMION_MASSES_MEV[a]
        mb = CHARGED_FERMION_MASSES_MEV[b]
        ratio = max(ma, mb) / min(ma, mb)
        same_sector = SECTOR[a] == SECTOR[b]
        rows.append({
            "particle_a": a,
            "particle_b": b,
            "particle_pair": pair_key(a, b),
            "mass_a_MeV": ma,
            "mass_b_MeV": mb,
            "mass_ratio_ge_1": ratio,
            "same_sector": same_sector,
            "lepton_lepton": same_sector and SECTOR[a] == "lepton",
            "quark_quark": same_sector and SECTOR[a] == "quark",
            "mass_source_role": "screening_table_only_quark_scheme_dependent",
        })
    return rows


def blind_compare(fr_rows: List[Dict[str, object]], mr_rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for fr in fr_rows:
        f_ratio = float(fr["F_ratio_ge_1"])
        for mr in mr_rows:
            m_ratio = float(mr["mass_ratio_ge_1"])
            rel = abs(f_ratio - m_ratio) / m_ratio
            rows.append({
                "functional_id": fr["functional_id"],
                "rho_pair": fr["rho_pair"],
                "F_ratio_ge_1": f_ratio,
                "particle_pair": mr["particle_pair"],
                "mass_ratio_ge_1": m_ratio,
                "relative_error": rel,
                "percent_error": 100.0 * rel,
                "same_sector": bool(mr["same_sector"]),
                "lepton_lepton": bool(mr["lepton_lepton"]),
                "quark_quark": bool(mr["quark_quark"]),
            })
    rows.sort(key=lambda r: (float(r["relative_error"]), str(r["functional_id"])))
    return rows


def threshold_summary(compare_rows: List[Dict[str, object]], candidates: Dict[str, Dict[Fraction, float]]) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for fid, vals in candidates.items():
        sub = [r for r in compare_rows if r["functional_id"] == fid]
        best = min(float(r["relative_error"]) for r in sub)
        rows.append({
            "functional_id": fid,
            "F_dynamic_range": max(vals.values()) / min(vals.values()),
            "best_percent_error": 100.0 * best,
            "hits_le_1pct": sum(float(r["percent_error"]) <= 1.0 for r in sub),
            "hits_le_5pct": sum(float(r["percent_error"]) <= 5.0 for r in sub),
            "hits_le_10pct": sum(float(r["percent_error"]) <= 10.0 for r in sub),
            "same_sector_le_5pct": sum(float(r["percent_error"]) <= 5.0 and bool(r["same_sector"]) for r in sub),
            "lepton_lepton_le_5pct": sum(float(r["percent_error"]) <= 5.0 and bool(r["lepton_lepton"]) for r in sub),
            "quark_quark_le_5pct": sum(float(r["percent_error"]) <= 5.0 and bool(r["quark_quark"]) for r in sub),
            "total_pairwise_comparisons": len(sub),
            "multiple_comparison_warning": "HIGH",
            "selected_as_final_physical_mass_law": False,
        })
    rows.sort(key=lambda r: (-int(r["same_sector_le_5pct"]), float(r["best_percent_error"])))
    return rows


def monotonic_dynamic_audit(candidates: Dict[str, Dict[Fraction, float]]) -> List[Dict[str, object]]:
    target_dyn = CHARGED_FERMION_MASSES_MEV["top_quark"] / CHARGED_FERMION_MASSES_MEV["electron"]
    rows: List[Dict[str, object]] = []
    for fid, vals in candidates.items():
        dyn = max(vals.values()) / min(vals.values())
        rows.append({
            "functional_id": fid,
            "F_dynamic_range": dyn,
            "target_mass_dynamic_range_top_over_electron": target_dyn,
            "dynamic_range_shortfall_factor": target_dyn / dyn,
            "monotonic_full_spectrum_dynamic_range_pass": dyn >= target_dyn,
        })
    rows.sort(key=lambda r: float(r["dynamic_range_shortfall_factor"]))
    return rows


def claim_boundary() -> List[Dict[str, object]]:
    return [
        {"claim": "R127 compares frozen R126 feedback F(rho) pairwise ratios to external mass ratios.", "status": "YES_SCREEN", "reason": "Candidate values are written and hashed before the charged-fermion screening table is constructed."},
        {"claim": "R127 retunes, refits, or exponent-optimizes F(rho) after seeing masses.", "status": "NO", "reason": "The R126-derived feedback candidates are fixed before mass loading; no coefficients or mappings are optimized."},
        {"claim": "R127 reports exploratory pairwise mass-ratio hits.", "status": "YES_SCREEN", "reason": "Hits are reported with same-sector labels and multiple-comparison warnings."},
        {"claim": "R127 passes a full nine-mode monotonic charged-fermion dynamic-range test.", "status": "NO", "reason": "The feedback candidates remain below the full charged-fermion hierarchy unless a future physical law changes the scaling."},
        {"claim": "R127 selects a final physical mass law.", "status": "NO", "reason": "The result is a locked blind screen only; final law selection requires derivation and independent controls."},
        {"claim": "R127 maps rho modes to particles by hand.", "status": "NO", "reason": "Only pairwise ratios and sorted diagnostics are computed; no rho-to-particle identities are declared."},
        {"claim": "R127 confirms the nine seed modes as the Standard Model spectrum.", "status": "NO", "reason": "The nine modes remain a mechanical/operator-geometric seed pending physical identification."},
        {"claim": "R127 closes true GR/PDE self-energy dynamics.", "status": "NO", "reason": "The feedback map is a scalar lag/focusing screen, not a solved self-consistent Einstein/PDE theorem."},
    ]


def write_summary(path: Path, verdict_data: Dict[str, object], top_matches: List[Dict[str, object]], thresh: List[Dict[str, object]]) -> None:
    lines = []
    lines.append(f"# {GATE} Summary")
    lines.append("")
    lines.append(f"**Verdict:** {VERDICT}")
    lines.append(f"**Freeze ID:** `{FREEZE_ID}`")
    lines.append("")
    lines.append("## Interpretation")
    lines.append("")
    lines.append("R127 freezes R126 radius/depth feedback candidate values first, then performs a blind charged-fermion pairwise mass-ratio screen.")
    lines.append("It does not fit, retune, map rho modes to particles, or select a final physical mass law.")
    lines.append("")
    lines.append("## Top matches")
    lines.append("")
    for r in top_matches[:12]:
        lines.append(
            f"- `{r['functional_id']}` | {r['rho_pair']} | F={float(r['F_ratio_ge_1']):.6g} | "
            f"{r['particle_pair']} | M={float(r['mass_ratio_ge_1']):.6g} | err={float(r['percent_error']):.4g}% | "
            f"same_sector={r['same_sector']} | lepton_lepton={r['lepton_lepton']} | quark_quark={r['quark_quark']}"
        )
    lines.append("")
    lines.append("## Threshold summary")
    lines.append("")
    for r in thresh:
        lines.append(
            f"- `{r['functional_id']}` | dyn={float(r['F_dynamic_range']):.6g} | best_err={float(r['best_percent_error']):.4g}% | "
            f"hits<=1%={r['hits_le_1pct']} | hits<=5%={r['hits_le_5pct']} | same_sector<=5%={r['same_sector_le_5pct']}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def print_table(title: str, rows: List[Dict[str, object]], limit: int = 10) -> None:
    print(title + ":")
    for r in rows[:limit]:
        if "percent_error" in r:
            print(
                f"  {r['functional_id']} | {r['rho_pair']} | F={float(r['F_ratio_ge_1']):.6g} | "
                f"{r['particle_pair']} | M={float(r['mass_ratio_ge_1']):.6g} | "
                f"err={float(r['percent_error']):.4g}% | same_sector={r['same_sector']} | "
                f"lepton_lepton={r['lepton_lepton']} | quark_quark={r['quark_quark']}"
            )
        else:
            print(r)


def zip_dir(src: Path, dst: Path) -> None:
    if dst.exists():
        dst.unlink()
    with zipfile.ZipFile(dst, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(src.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(src.parent))


def main() -> int:
    mkdir_clean(OUTDIR)

    candidate_rows, candidates = make_candidate_values()
    candidate_csv = OUTDIR / "FORCE_R127_feedback_candidate_values_frozen.csv"
    write_csv(candidate_csv, candidate_rows)
    candidate_hash = sha256_file(candidate_csv)

    # Mass data are constructed only after candidate CSV exists and has been hashed.
    mass_rows = mass_ratios()
    mass_csv = OUTDIR / "FORCE_R127_charged_fermion_screening_mass_ratios.csv"
    write_csv(mass_csv, mass_rows)

    fr_rows = functional_ratios(candidates)
    fr_csv = OUTDIR / "FORCE_R127_feedback_functional_pairwise_ratios.csv"
    write_csv(fr_csv, fr_rows)

    comp_rows = blind_compare(fr_rows, mass_rows)
    comp_csv = OUTDIR / "FORCE_R127_blind_mass_ratio_comparison.csv"
    write_csv(comp_csv, comp_rows)

    thresh = threshold_summary(comp_rows, candidates)
    thresh_csv = OUTDIR / "FORCE_R127_threshold_summary.csv"
    write_csv(thresh_csv, thresh)

    mono = monotonic_dynamic_audit(candidates)
    mono_csv = OUTDIR / "FORCE_R127_monotonic_full_spectrum_audit.csv"
    write_csv(mono_csv, mono)

    claims = claim_boundary()
    claim_csv = OUTDIR / "FORCE_R127_claim_boundary.csv"
    write_csv(claim_csv, claims)

    top_matches = comp_rows[:30]
    top_csv = OUTDIR / "FORCE_R127_top_matches.csv"
    write_csv(top_csv, top_matches)

    any_1pct = any(float(r["percent_error"]) <= 1.0 for r in comp_rows)
    any_5pct = any(float(r["percent_error"]) <= 5.0 for r in comp_rows)
    same_5pct = any(float(r["percent_error"]) <= 5.0 and bool(r["same_sector"]) for r in comp_rows)
    lep_5pct = any(float(r["percent_error"]) <= 5.0 and bool(r["lepton_lepton"]) for r in comp_rows)
    quark_5pct = any(float(r["percent_error"]) <= 5.0 and bool(r["quark_quark"]) for r in comp_rows)
    full_dyn_pass = any(bool(r["monotonic_full_spectrum_dynamic_range_pass"]) for r in mono)

    verdict_data = {
        "gate": GATE,
        "verdict": VERDICT,
        "freeze_id": FREEZE_ID,
        "candidate_values_frozen_before_mass_loading": True,
        "empirical_mass_data_loaded_after_freeze": True,
        "blind_comparison_generated": True,
        "any_1pct_pairwise_hits": any_1pct,
        "any_5pct_pairwise_hits": any_5pct,
        "same_sector_5pct_present": same_5pct,
        "lepton_lepton_5pct_present": lep_5pct,
        "quark_quark_5pct_present": quark_5pct,
        "full_spectrum_dynamic_range_any_pass": full_dyn_pass,
        "no_parameter_fit_performed": True,
        "no_functional_retuning_after_mass_loading": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "Omega0_claimed": False,
        "true_GR_PDE_mass_law_closed": False,
        "candidate_freeze_hash": candidate_hash,
        "selected_seed": "{" + ", ".join(frac_label(x) for x in SEED) + "}",
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
        "next": "FORCE_R128_GR_lag_field_derivation_gate_or_FORCE_R129_feedback_hierarchy_bridge_gate",
    }

    verdict_json = OUTDIR / "FORCE_R127_verdict.json"
    verdict_json.write_text(json.dumps(verdict_data, indent=2, sort_keys=True), encoding="utf-8")

    summary_md = OUTDIR / "FORCE_R127_summary.md"
    write_summary(summary_md, verdict_data, top_matches, thresh)

    manifest_rows = []
    for p in sorted(OUTDIR.glob("*")):
        if p.is_file():
            manifest_rows.append({"file": p.name, "sha256": sha256_file(p), "bytes": p.stat().st_size})
    write_csv(OUTDIR / "artifact_manifest.csv", manifest_rows)

    zip_dir(OUTDIR, PACK)
    zip_integrity = False
    try:
        with zipfile.ZipFile(PACK, "r") as zf:
            zip_integrity = zf.testzip() is None
    except Exception:
        zip_integrity = False

    print("=== COPY/PASTE R127 RESULT ===")
    print("R127 COMPLETE")
    print(f"VERDICT: {VERDICT}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity else 'FAIL'}")
    for k in [
        "candidate_values_frozen_before_mass_loading",
        "empirical_mass_data_loaded_after_freeze",
        "blind_comparison_generated",
        "any_1pct_pairwise_hits",
        "any_5pct_pairwise_hits",
        "same_sector_5pct_present",
        "lepton_lepton_5pct_present",
        "quark_quark_5pct_present",
        "full_spectrum_dynamic_range_any_pass",
        "no_parameter_fit_performed",
        "no_functional_retuning_after_mass_loading",
        "no_mode_particle_mapping_performed",
        "no_final_physical_mass_law_selected",
        "physical_mass_spectrum_claimed",
        "SM_mass_matching_claimed",
        "Omega0_claimed",
        "true_GR_PDE_mass_law_closed",
    ]:
        print(f"{k}: {verdict_data[k]}")
    print(f"candidate_freeze_hash: {candidate_hash}")
    print(f"selected_seed: {verdict_data['selected_seed']}")
    print(f"canonical_species_formula: {verdict_data['canonical_species_formula']}")
    print_table("TOP_MATCHES_BY_FUNCTIONAL", top_matches, limit=12)
    print("THRESHOLD_SUMMARY:")
    for r in thresh:
        print(
            f"  {r['functional_id']} | dyn={float(r['F_dynamic_range']):.6g} | "
            f"best_err={float(r['best_percent_error']):.4g}% | hits<=1%={r['hits_le_1pct']} | "
            f"hits<=5%={r['hits_le_5pct']} | same_sector<=5%={r['same_sector_le_5pct']} | "
            f"lepton<=5%={r['lepton_lepton_le_5pct']} | quark<=5%={r['quark_quark_le_5pct']} | warning={r['multiple_comparison_warning']}"
        )
    print("MONOTONIC_FULL_SPECTRUM_AUDIT:")
    for r in mono:
        print(
            f"  {r['functional_id']} | F_dyn={float(r['F_dynamic_range']):.6g} | "
            f"target_dyn={float(r['target_mass_dynamic_range_top_over_electron']):.6g} | "
            f"shortfall={float(r['dynamic_range_shortfall_factor']):.6g} | pass={r['monotonic_full_spectrum_dynamic_range_pass']}"
        )
    print("CLAIM_BOUNDARY:")
    for r in claims:
        print(f"  {r['status']} | {r['claim']} -- {r['reason']}")
    print(f"PACK: {PACK}")
    print(f"SUMMARY: {summary_md}")
    print(f"NEXT: {verdict_data['next']}")
    print("=== END COPY/PASTE R127 RESULT ===")
    return 0 if zip_integrity else 1


if __name__ == "__main__":
    raise SystemExit(main())
