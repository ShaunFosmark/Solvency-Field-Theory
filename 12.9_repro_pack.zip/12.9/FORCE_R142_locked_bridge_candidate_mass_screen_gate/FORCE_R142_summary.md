# FORCE_R142 — Locked Bridge-Candidate Mass Screen Gate

VERDICT: LOCKED BRIDGE-CANDIDATE MASS SCREEN PASS / SCREEN HITS REPORTED, FINAL LAW OPEN
FREEZE_ID: SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM
candidate_freeze_hash: 735d10d6faa080b5f54bd39f87bfcc6bb5386b593d3f1642e878d5e38c157ef8
candidate_dynamic_freeze_hash: c31ad25a071aa39f4c5f074665aeb2c127b235459bd5ea9c095383aac59156ed
selected_seed: {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}
canonical_species_formula: Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}

## Key booleans
- candidate_values_frozen_before_mass_loading: True
- empirical_mass_data_loaded_after_freeze: True
- blind_comparison_generated: True
- any_1pct_pairwise_hits: True
- any_5pct_pairwise_hits: True
- same_sector_5pct_present: True
- lepton_lepton_5pct_present: True
- quark_quark_5pct_present: True
- full_spectrum_dynamic_range_any_pass: True
- primary_dynamic_range_any_pass: True
- no_parameter_fit_performed: True
- no_functional_retuning_after_mass_loading: True
- no_mode_particle_mapping_performed: True
- no_final_physical_mass_law_selected: True

## Primary candidates
- R137_transverse_phase_volume_6pi_exponent: dyn=339288, overshoot factor=1.00356
- R137_oriented_modes_18_exponent: dyn=323996, shortfall factor=1.04348
- R139_boundary_area_rho2_candidate: dyn=287996, shortfall factor=1.17391

## Top primary/secondary matches
- R140B_partial_slot_beta_boundary_half | 3/4 vs 2/3 | F=2.16384 | down_quark vs up_quark | M=2.16204 | err=0.0834072% | same_sector=True | lepton=False | quark=True
- R137_transverse_phase_volume_6pi_exponent | 3/2 vs 3/4 | F=380.024 | tau vs down_quark | M=380.484 | err=0.120936% | same_sector=False | lepton=False | quark=False
- R140B_partial_slot_beta_boundary_half | 2 vs 5/4 | F=589.001 | charm_quark vs up_quark | M=587.963 | err=0.176581% | same_sector=True | lepton=False | quark=True
- R140B_partial_slot_beta_boundary_half | 1 vs 2/3 | F=11.9943 | charm_quark vs muon | M=12.0199 | err=0.212783% | same_sector=False | lepton=False | quark=False
- R137_transverse_phase_volume_6pi_exponent | 5/4 vs 3/4 | F=49.0674 | muon vs up_quark | M=48.9159 | err=0.309776% | same_sector=False | lepton=False | quark=False
- R139_boundary_area_rho2_candidate | 5/4 vs 1/2 | F=825.471 | tau vs up_quark | M=822.62 | err=0.346572% | same_sector=False | lepton=False | quark=False
- R137_transverse_phase_volume_6pi_exponent | 2 vs 1/2 | F=339288 | top_quark vs electron | M=338083 | err=0.356352% | same_sector=False | lepton=False | quark=False
- R140B_partial_slot_beta_boundary_half | 5/3 vs 3/4 | F=2494.61 | charm_quark vs electron | M=2485.33 | err=0.373372% | same_sector=False | lepton=False | quark=False
- R137_oriented_modes_18_exponent | 5/3 vs 5/4 | F=45.1824 | bottom_quark vs strange_quark | M=44.9462 | err=0.525396% | same_sector=True | lepton=False | quark=True
- R140B_partial_slot_beta_boundary_half | 4/3 vs 1 | F=19.0025 | tau vs strange_quark | M=19.106 | err=0.541599% | same_sector=False | lepton=False | quark=False
- R139_boundary_area_rho2_candidate | 4/3 vs 1 | F=16.709 | tau vs muon | M=16.817 | err=0.642173% | same_sector=True | lepton=True | quark=False
- R139_boundary_area_rho2_candidate | 5/3 vs 3/4 | F=1872.67 | top_quark vs strange_quark | M=1857.63 | err=0.809512% | same_sector=True | lepton=False | quark=True
- R140B_partial_slot_beta_boundary_quarter | 5/3 vs 4/3 | F=22.3982 | muon vs down_quark | M=22.6249 | err=1.00199% | same_sector=False | lepton=False | quark=False
- R137_oriented_modes_18_exponent | 5/4 vs 3/4 | F=48.3805 | muon vs up_quark | M=48.9159 | err=1.09457% | same_sector=False | lepton=False | quark=False
- R137_transverse_phase_volume_6pi_exponent | 2 vs 5/4 | F=594.48 | charm_quark vs up_quark | M=587.963 | err=1.10833% | same_sector=True | lepton=False | quark=True
- R137_oriented_modes_18_exponent | 2 vs 5/4 | F=580.886 | charm_quark vs up_quark | M=587.963 | err=1.20373% | same_sector=True | lepton=False | quark=True
- R140B_partial_slot_beta_boundary_quarter | 5/3 vs 5/4 | F=42.5309 | strange_quark vs up_quark | M=43.0556 | err=1.21862% | same_sector=True | lepton=False | quark=True
- R140B_partial_slot_beta_boundary_quarter | 2 vs 4/3 | F=275.801 | charm_quark vs down_quark | M=271.949 | err=1.41649% | same_sector=True | lepton=False | quark=True
- R139_boundary_area_rho2_candidate | 3/2 vs 3/4 | F=386.357 | tau vs down_quark | M=380.484 | err=1.54357% | same_sector=False | lepton=False | quark=False
- R140B_partial_slot_beta_boundary_half | 5/3 vs 5/4 | F=45.7024 | bottom_quark vs strange_quark | M=44.9462 | err=1.68236% | same_sector=True | lepton=False | quark=True
- R140B_partial_slot_beta_boundary_quarter | 5/4 vs 3/4 | F=48.0398 | muon vs up_quark | M=48.9159 | err=1.79109% | same_sector=False | lepton=False | quark=False
- R140B_partial_slot_beta_boundary_quarter | 5/4 vs 1 | F=9.31293 | down_quark vs electron | M=9.13896 | err=1.90357% | same_sector=False | lepton=False | quark=False
- R137_transverse_phase_volume_6pi_exponent | 5/3 vs 5/4 | F=45.8125 | bottom_quark vs strange_quark | M=44.9462 | err=1.9274% | same_sector=True | lepton=False | quark=True
- R139_boundary_area_rho2_candidate | 2 vs 4/3 | F=185.969 | strange_quark vs electron | M=181.996 | err=2.18276% | same_sector=False | lepton=False | quark=False
- R139_boundary_area_rho2_candidate | 1 vs 2/3 | F=13.9613 | charm_quark vs strange_quark | M=13.6559 | err=2.23627% | same_sector=True | lepton=False | quark=True
- R137_oriented_modes_18_exponent | 3/2 vs 3/4 | F=371.936 | tau vs down_quark | M=380.484 | err=2.24661% | same_sector=False | lepton=False | quark=False
- R140B_partial_slot_beta_boundary_quarter | 2 vs 5/3 | F=12.3135 | charm_quark vs muon | M=12.0199 | err=2.44296% | same_sector=False | lepton=False | quark=False
- R140B_partial_slot_beta_boundary_quarter | 3/4 vs 1/2 | F=11.7196 | charm_quark vs muon | M=12.0199 | err=2.49843% | same_sector=False | lepton=False | quark=False
- R139_boundary_area_rho2_candidate | 2 vs 3/2 | F=50.1539 | muon vs up_quark | M=48.9159 | err=2.53086% | same_sector=False | lepton=False | quark=False
- R139_boundary_area_rho2_candidate | 5/4 vs 1 | F=8.9065 | down_quark vs electron | M=9.13896 | err=2.54365% | same_sector=False | lepton=False | quark=False

## Threshold summary
- R137_transverse_phase_volume_6pi_exponent | tier=primary | dyn=339288 | best_err=0.120936% | hits<=1%=3 | hits<=5%=14 | same_sector<=5%=6 | lepton<=5%=1 | quark<=5%=5
- R139_boundary_area_rho2_candidate | tier=primary | dyn=287996 | best_err=0.346572% | hits<=1%=3 | hits<=5%=13 | same_sector<=5%=6 | lepton<=5%=1 | quark<=5%=5
- R137_oriented_modes_18_exponent | tier=primary | dyn=323996 | best_err=0.525396% | hits<=1%=1 | hits<=5%=14 | same_sector<=5%=4 | lepton<=5%=0 | quark<=5%=4
- R140B_partial_slot_beta_boundary_half | tier=secondary | dyn=416978 | best_err=0.0834072% | hits<=1%=5 | hits<=5%=10 | same_sector<=5%=5 | lepton<=5%=0 | quark<=5%=5
- raw_feedback_control | tier=control | dyn=17999.8 | best_err=0.185639% | hits<=1%=6 | hits<=5%=12 | same_sector<=5%=4 | lepton<=5%=0 | quark<=5%=4
- R140B_partial_slot_beta_boundary_quarter | tier=secondary | dyn=294848 | best_err=1.00199% | hits<=1%=0 | hits<=5%=12 | same_sector<=5%=5 | lepton<=5%=0 | quark<=5%=5

## Monotonic full-spectrum audit
- R137_transverse_phase_volume_6pi_exponent | tier=primary | F_dyn=339288 | target_dyn=338083 | overshoot=1.00356 | pass25=True
- R137_oriented_modes_18_exponent | tier=primary | F_dyn=323996 | target_dyn=338083 | shortfall=1.04348 | pass25=True
- R140B_partial_slot_beta_boundary_quarter | tier=secondary | F_dyn=294848 | target_dyn=338083 | shortfall=1.14663 | pass25=True
- R139_boundary_area_rho2_candidate | tier=primary | F_dyn=287996 | target_dyn=338083 | shortfall=1.17391 | pass25=True
- R140B_partial_slot_beta_boundary_half | tier=secondary | F_dyn=416978 | target_dyn=338083 | overshoot=1.23336 | pass25=True
- raw_feedback_control | tier=control | F_dyn=17999.8 | target_dyn=338083 | shortfall=18.7826 | pass25=False

## Claim boundary
- YES_SCREEN | R142 compares frozen R141 bridge candidates to an external mass-ratio screen. -- Candidate values are written and hashed before the charged-fermion screening table is constructed.
- NO | R142 retunes exponent, boundary correction, candidate values, or mappings after seeing masses. -- All candidate beta/gamma definitions are frozen before mass loading; no optimization is performed.
- YES_SCREEN | R142 reports exploratory pairwise hits. -- Hits carry multiple-comparison warnings and quark-scheme caveats.
- NO | R142 selects a final physical mass law. -- This is a locked screen only; final law selection requires a field derivation and independent controls.
- NO | R142 maps rho modes to particles. -- Only pairwise ratios and sorted diagnostics are computed; no rho-to-particle identities are assigned.
- NO | R142 confirms the nine seed modes as the Standard Model spectrum. -- The nine modes remain a mechanical/operator-geometric seed pending physical identification.
- NO | R142 closes true GR/PDE bridge dynamics. -- R137/R139/R141 bridge candidates are mechanical screens, not solved field equations.

NEXT: FORCE_R143_bridge_screen_interpretation_gate_or_FORCE_R128_GR_lag_field_derivation_gate