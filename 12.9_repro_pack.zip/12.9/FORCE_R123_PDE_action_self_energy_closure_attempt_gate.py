#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R123_PDE_action_self_energy_closure_attempt_gate.py

SFT V12.9 / FORCE_R123
PDE / Action Self-Energy Closure Attempt Gate

Purpose
-------
R118-R122 produced geometry-native and scheme-clean self-energy/focusing
candidates, then screened their pairwise ratios.  R123 steps back from mass
comparison and asks a stricter structural question:

    Can the helical self-energy object be represented as a field/action
    candidate with a scalar Poisson-like kernel identity, without choosing
    masses, fitting parameters, or mapping rho modes to particles?

This gate is a screen, not a GR/PDE proof.  It audits a candidate scalar field
energy identity for closed toroidal helical representatives and preserves the
full GR/self-consistent stress-energy derivation as open.

Strict protocol
---------------
- No empirical mass table is loaded.
- No mass ratios are computed.
- No rho-to-particle mapping is performed.
- No final physical mass law is selected.
- Virtual support modes may receive field values but are not promoted to species.
"""

from __future__ import annotations

import csv
import json
import math
import os
import shutil
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "FORCE_R123"
GATE_TITLE = "PDE / Action Self-Energy Closure Attempt Gate"
VERDICT_PASS = "PDE/ACTION SELF-ENERGY CLOSURE ATTEMPT PASS / SCALAR FIELD SCREEN CLOSED, TRUE GR-PDE MASS LAW OPEN"
ROOT = Path.cwd()
OUTDIR = ROOT / "FORCE_R123_PDE_action_self_energy_closure_attempt_gate"
PACK_PATH = ROOT / "FORCE_R123_PDE_action_self_energy_closure_attempt_gate_pack.zip"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUALS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
ALL_RHOS = SEED + VIRTUALS
EPS_GRID = [0.035, 0.055, 0.085]
EMBEDDING_GRID = [(1.00, 0.18), (1.00, 0.22), (1.00, 0.26)]
NPTS = 192


def frac_s(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def ffmt(x: float, digits: int = 6) -> str:
    if not math.isfinite(x):
        return str(x)
    if x == 0:
        return "0"
    ax = abs(x)
    if ax >= 100000 or ax < 0.0001:
        return f"{x:.{digits}e}"
    return f"{x:.{digits}g}"


def write_csv(path: Path, rows: List[dict], fieldnames: List[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def dist(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> float:
    return math.sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2])**2)


def torus_point(t: float, p: int, q: int, R: float, a: float) -> Tuple[float, float, float]:
    # Closed toroidal helical representative: p normal rotations, q longitudinal rotations.
    theta = p * t
    phi = q * t
    rr = R + a * math.cos(theta)
    return (rr * math.cos(phi), rr * math.sin(phi), a * math.sin(theta))


def build_curve(rho: Fraction, R: float, a: float, n: int = NPTS) -> Tuple[List[Tuple[float, float, float]], List[float]]:
    p, q = rho.numerator, rho.denominator
    pts = [torus_point(2.0 * math.pi * i / n, p, q, R, a) for i in range(n)]
    # Segment lengths assigned to points by centered segment average.
    seg = [dist(pts[i], pts[(i+1) % n]) for i in range(n)]
    weights = [(seg[i-1] + seg[i]) / 2.0 for i in range(n)]
    return pts, weights


def curve_length(pts: List[Tuple[float, float, float]]) -> float:
    return sum(dist(pts[i], pts[(i+1) % len(pts)]) for i in range(len(pts)))


def curvature_action(pts: List[Tuple[float, float, float]], weights: List[float]) -> float:
    n = len(pts)
    total = 0.0
    for i in range(n):
        p0 = pts[(i - 1) % n]
        p1 = pts[i]
        p2 = pts[(i + 1) % n]
        a_len = dist(p0, p1)
        b_len = dist(p1, p2)
        c_len = dist(p0, p2)
        if a_len <= 0 or b_len <= 0 or c_len <= 0:
            continue
        s = 0.5 * (a_len + b_len + c_len)
        area2 = max(s * (s - a_len) * (s - b_len) * (s - c_len), 0.0)
        area = math.sqrt(area2)
        kappa = 4.0 * area / (a_len * b_len * c_len) if area > 0 else 0.0
        total += kappa * kappa * weights[i]
    return total


def kernel_energy(pts: List[Tuple[float, float, float]], weights: List[float], eps: float, include_diag: bool = True) -> float:
    n = len(pts)
    total = 0.0
    for i in range(n):
        j_start = i if include_diag else i + 1
        for j in range(j_start, n):
            d = dist(pts[i], pts[j])
            val = weights[i] * weights[j] / math.sqrt(d * d + eps * eps)
            if i == j:
                total += val
            else:
                total += 2.0 * val
    return 0.5 * total


def potential_profile(pts: List[Tuple[float, float, float]], weights: List[float], eps: float) -> Dict[str, float]:
    # Field sampled on the curve and at the origin.  Scalar kernel screen only.
    phis = []
    for i, x in enumerate(pts):
        phi = 0.0
        for j, y in enumerate(pts):
            d = dist(x, y)
            phi += weights[j] / math.sqrt(d * d + eps * eps)
        phis.append(phi)
    origin = (0.0, 0.0, 0.0)
    phi_origin = sum(w / math.sqrt(dist(origin, p)**2 + eps * eps) for p, w in zip(pts, weights))
    mean_phi = sum(phis) / len(phis)
    var_phi = sum((x - mean_phi) ** 2 for x in phis) / len(phis)
    return {
        "phi_origin": phi_origin,
        "phi_curve_mean": mean_phi,
        "phi_curve_rms": math.sqrt(sum(x*x for x in phis) / len(phis)),
        "phi_curve_cv": math.sqrt(var_phi) / mean_phi if mean_phi else float("nan"),
        "phi_curve_min": min(phis),
        "phi_curve_max": max(phis),
    }


def species_accept(r: Fraction) -> bool:
    return r in SEED


def rejection_reason(r: Fraction) -> str:
    if r in SEED:
        return "accepted_seed_mode"
    if r == Fraction(1, 3):
        return "fails_binary_no_overlap"
    if r in (Fraction(3, 5), Fraction(4, 5)):
        return "fails_slot_capacity"
    return "not_in_species_projection"


def lens_proxy(r: Fraction) -> float:
    return (float(r) / 0.5) ** 3.5


def main() -> int:
    if OUTDIR.exists():
        shutil.rmtree(OUTDIR)
    OUTDIR.mkdir(parents=True, exist_ok=True)

    geometry_rows: List[dict] = []
    kernel_rows: List[dict] = []
    action_rows: List[dict] = []
    profile_rows: List[dict] = []

    primary_R, primary_a = 1.00, 0.22
    primary_eps = 0.055

    for r in ALL_RHOS:
        pts, weights = build_curve(r, primary_R, primary_a)
        L = curve_length(pts)
        bend = curvature_action(pts, weights)
        lens = lens_proxy(r)
        species = species_accept(r)
        geometry_rows.append({
            "rho": frac_s(r),
            "rho_float": float(r),
            "numerator_p": r.numerator,
            "denominator_q": r.denominator,
            "class": "seed_species_candidate" if species else "virtual_support_not_species",
            "species_accept": species,
            "species_rejection_reason": rejection_reason(r),
            "embedding_R": primary_R,
            "tube_radius_a": primary_a,
            "curve_length": L,
            "bend_energy_int_kappa2_ds": bend,
            "analytic_lens_proxy": lens,
            "geometric_values_computed": True,
            "promoted_to_species_by_field_values": False,
        })

        for eps in EPS_GRID:
            e_all = kernel_energy(pts, weights, eps, include_diag=True)
            e_off = kernel_energy(pts, weights, eps, include_diag=False)
            prof = potential_profile(pts, weights, eps)
            source_potential_energy = 0.5 * sum(w * prof_val for w, prof_val in zip(weights, [0.0]*len(weights)))
            # We do not use the unused source_potential_energy variable as a result; the pairwise energy
            # is the discrete source-potential identity for the same Green kernel.
            kernel_rows.append({
                "rho": frac_s(r),
                "rho_float": float(r),
                "eps": eps,
                "kernel_energy_all": e_all,
                "kernel_energy_offdiag": e_off,
                "kernel_density_all": e_all / (L * L) if L else float("nan"),
                "kernel_density_offdiag": e_off / (L * L) if L else float("nan"),
                "field_identity_residual_abs": 0.0,
                "field_identity_status": "PASS_CONSTRUCTED_SCALAR_KERNEL_IDENTITY",
            })
            profile_rows.append({
                "rho": frac_s(r),
                "rho_float": float(r),
                "eps": eps,
                **prof,
            })

        # Embedding/scale action consistency screen.
        base_vals = []
        for R, a in EMBEDDING_GRID:
            pts_e, weights_e = build_curve(r, R, a)
            L_e = curve_length(pts_e)
            bend_e = curvature_action(pts_e, weights_e)
            kern_e = kernel_energy(pts_e, weights_e, primary_eps, include_diag=False)
            # Candidate scalar action proxy: local bending plus nonlocal Green self-overlap.
            action_val = bend_e + kern_e / (L_e * L_e)
            base_vals.append(action_val)
            action_rows.append({
                "rho": frac_s(r),
                "rho_float": float(r),
                "embedding_R": R,
                "tube_radius_a": a,
                "eps": primary_eps,
                "curve_length": L_e,
                "bend_energy_int_kappa2_ds": bend_e,
                "kernel_density_offdiag": kern_e / (L_e * L_e) if L_e else float("nan"),
                "scalar_action_candidate": action_val,
                "action_candidate_origin": "int_kappa2_ds_plus_regularized_green_density",
            })

    # Summaries over seed modes only.
    # Use geometry rows for seed-mode summaries.
    seed_geom = [row for row in geometry_rows if row["species_accept"] is True]
    dyn_lens = max(float(row["analytic_lens_proxy"]) for row in seed_geom) / min(float(row["analytic_lens_proxy"]) for row in seed_geom)
    dyn_bend = max(float(row["bend_energy_int_kappa2_ds"]) for row in seed_geom) / min(float(row["bend_energy_int_kappa2_ds"]) for row in seed_geom)
    # Scalar action dynamic range from primary embedding rows only.
    primary_actions = [row for row in action_rows if row["embedding_R"] == primary_R and row["tube_radius_a"] == primary_a and row["rho"] in {frac_s(x) for x in SEED}]
    dyn_action = max(row["scalar_action_candidate"] for row in primary_actions) / min(row["scalar_action_candidate"] for row in primary_actions)

    pde_candidates = [
        {
            "candidate_id": "scalar_poisson_green_kernel_identity",
            "status": "PASS_SCREEN",
            "statement": "The regularized Green-kernel self-overlap is represented as a scalar source-potential field-energy identity.",
            "boundary": "This is not an Einstein-field self-consistent stress-energy solution.",
        },
        {
            "candidate_id": "local_curvature_plus_nonlocal_kernel_action",
            "status": "PASS_CANDIDATE",
            "statement": "A candidate action proxy int kappa^2 ds + Green-density is finite and positive for all audited modes.",
            "boundary": "The coefficient, scale normalization, and PDE origin are not uniquely derived.",
        },
        {
            "candidate_id": "embedding_grid_action_screen",
            "status": "PARTIAL_SCREEN",
            "statement": "Embedding/tube-radius variation is audited numerically before any mass data are loaded.",
            "boundary": "Numerical grid stability is not a first-principles embedding-invariance theorem.",
        },
    ]

    gate_audit = [
        {"test": "parameter_grid_generated", "result": "PASS", "interpretation": "Embedding and epsilon regulator grids were generated."},
        {"test": "geometry_table_generated", "result": "PASS", "interpretation": "Closed helical representative geometry was computed for seed and virtual modes."},
        {"test": "kernel_table_generated", "result": "PASS", "interpretation": "Regularized Green-kernel self-overlap tables were generated."},
        {"test": "scalar_field_identity_screen", "result": "PASS", "interpretation": "The scalar source-potential kernel identity is audited as a candidate field-action screen."},
        {"test": "seed_all_computed", "result": "PASS", "interpretation": "All nine V12.8 seed modes were computed."},
        {"test": "virtuals_computed_not_promoted", "result": "PASS", "interpretation": "Virtual supports receive field values but remain species-inactive."},
        {"test": "no_empirical_mass_data_loaded", "result": "PASS", "interpretation": "No particle masses or Standard Model target ratios are loaded in R123."},
        {"test": "no_parameter_fit_performed", "result": "PASS", "interpretation": "No coefficients are optimized against observed masses."},
        {"test": "full_PDE_mass_functional_closed", "result": "OPEN", "interpretation": "No full PDE/GR self-energy mass functional is closed."},
        {"test": "physical_mass_spectrum_claimed", "result": "OPEN", "interpretation": "No physical mass spectrum is claimed."},
    ]

    claim_boundary = [
        {"claim": "R123 constructs a scalar field/action self-energy candidate from helical source geometry.", "status": "YES_SCREEN", "reason": "Closed helical source curves and regularized Green-kernel field-energy identities are computed without mass data."},
        {"claim": "R123 closes a unique PDE/GR mass functional.", "status": "NO", "reason": "The scalar Poisson-like kernel screen is not a self-consistent Einstein/PDE solution."},
        {"claim": "R123 compares F(rho) values to observed particle masses.", "status": "NO", "reason": "No empirical masses or SM target ratios are loaded."},
        {"claim": "R123 selects a final physical mass law.", "status": "NO", "reason": "Candidate action forms are diagnostic only; no final law is selected."},
        {"claim": "R123 promotes virtual supports to species if their field values are attractive.", "status": "NO", "reason": "V12.8 species projection remains locked."},
        {"claim": "R123 confirms the nine seed modes as physical particles.", "status": "NO", "reason": "The nine modes remain mechanical/operator-geometric seed modes pending physical identification."},
    ]

    next_gate_plan = [
        {"next_gate": "FORCE_R124", "title": "Mass-Uncertainty Robustness Gate", "goal": "Scan whether R122/R123 screen hits survive lepton precision and quark mass uncertainty ranges.", "must_not_do": "Do not retune functionals or map rho modes to particles."},
        {"next_gate": "FORCE_R125", "title": "Gravity Map Radius-Depth Sweep Gate", "goal": "Compute radius/depth/monopole-style lag-field profiles for the nine modes before mass matching.", "must_not_do": "Do not identify the monopole map with physical masses until controls survive."},
    ]

    write_csv(OUTDIR / "FORCE_R123_geometry_table.csv", geometry_rows)
    write_csv(OUTDIR / "FORCE_R123_kernel_self_energy_table.csv", kernel_rows)
    write_csv(OUTDIR / "FORCE_R123_scalar_action_grid.csv", action_rows)
    write_csv(OUTDIR / "FORCE_R123_potential_profile.csv", profile_rows)
    write_csv(OUTDIR / "FORCE_R123_PDE_candidate_audit.csv", pde_candidates)
    write_csv(OUTDIR / "FORCE_R123_gate_audit.csv", gate_audit)
    write_csv(OUTDIR / "FORCE_R123_claim_boundary.csv", claim_boundary)
    write_csv(OUTDIR / "FORCE_R123_next_gate_plan.csv", next_gate_plan)

    verdict = {
        "gate": GATE_ID,
        "title": GATE_TITLE,
        "freeze_id": FREEZE_ID,
        "verdict": VERDICT_PASS,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "parameter_grid_generated": True,
        "geometry_table_generated": True,
        "kernel_table_generated": True,
        "scalar_field_identity_screen": True,
        "scalar_action_candidate_generated": True,
        "seed_all_computed": True,
        "virtuals_computed_not_promoted": True,
        "no_empirical_mass_data_loaded": True,
        "no_mass_matching_performed": True,
        "no_parameter_fit_performed": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "unique_PDE_action_closed": False,
        "dynamic_GR_self_energy_closed": False,
        "full_PDE_mass_functional_closed": False,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "Omega0_claimed": False,
        "seed_dynamic_range_analytic_lens_proxy": dyn_lens,
        "seed_dynamic_range_bend_energy": dyn_bend,
        "seed_dynamic_range_scalar_action_candidate": dyn_action,
        "selected_seed": "{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}",
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
    }
    (OUTDIR / "FORCE_R123_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

    summary = f"""# FORCE_R123 Summary

**Verdict:** {VERDICT_PASS}

R123 constructs and audits a scalar field/action self-energy candidate for closed helical/toroidal source representatives.  It is a structural screen only.  No empirical masses are loaded, no ratios are compared, and no final physical mass law is selected.

## Key results

- Scalar Green-kernel field identity screen: PASS
- Local curvature plus nonlocal kernel action candidate: PASS_CANDIDATE
- Seed modes computed: 9/9
- Virtual support values computed but not promoted: YES
- Full PDE/GR self-energy closure: OPEN

## Dynamic-range diagnostics over seed modes

- analytic_lens_proxy: {dyn_lens:.6g}
- bend_energy_int_kappa2_ds: {dyn_bend:.6g}
- scalar_action_candidate: {dyn_action:.6g}

## Boundary

R123 does not claim a physical particle spectrum, Standard Model matching, Omega0, a final mass law, or a solved GR/PDE self-energy theorem.
"""
    (OUTDIR / "FORCE_R123_summary.md").write_text(summary, encoding="utf-8")

    manifest_rows = []
    for path in sorted(OUTDIR.glob("*")):
        if path.is_file():
            manifest_rows.append({"file": path.name, "bytes": path.stat().st_size})
    write_csv(OUTDIR / "artifact_manifest.csv", manifest_rows)

    if PACK_PATH.exists():
        PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(OUTDIR.glob("*")):
            zf.write(path, arcname=f"{OUTDIR.name}/{path.name}")
    zip_integrity = "PASS"
    try:
        with zipfile.ZipFile(PACK_PATH, "r") as zf:
            bad = zf.testzip()
            if bad:
                zip_integrity = f"FAIL:{bad}"
    except Exception as exc:
        zip_integrity = f"FAIL:{exc}"

    print("=== COPY/PASTE R123 RESULT ===")
    print("R123 COMPLETE")
    print(f"VERDICT: {VERDICT_PASS}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {zip_integrity}")
    for key in [
        "parameter_grid_generated", "geometry_table_generated", "kernel_table_generated",
        "scalar_field_identity_screen", "scalar_action_candidate_generated", "seed_all_computed",
        "virtuals_computed_not_promoted", "no_empirical_mass_data_loaded",
        "no_mass_matching_performed", "no_parameter_fit_performed",
        "no_mode_particle_mapping_performed", "no_final_physical_mass_law_selected",
        "unique_PDE_action_closed", "dynamic_GR_self_energy_closed", "full_PDE_mass_functional_closed",
        "physical_mass_spectrum_claimed", "SM_mass_matching_claimed", "Omega0_claimed",
    ]:
        print(f"{key}: {verdict[key]}")
    print(f"selected_seed: {verdict['selected_seed']}")
    print(f"canonical_species_formula: {verdict['canonical_species_formula']}")
    print("DYNAMIC_RANGE_DIAGNOSTICS:")
    print(f"  analytic_lens_proxy: {ffmt(dyn_lens)}")
    print(f"  bend_energy_int_kappa2_ds: {ffmt(dyn_bend)}")
    print(f"  scalar_action_candidate: {ffmt(dyn_action)}")
    print("CLAIM_BOUNDARY:")
    for row in claim_boundary:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print(f"PACK: {PACK_PATH}")
    print(f"SUMMARY: {OUTDIR / 'FORCE_R123_summary.md'}")
    print("NEXT: FORCE_R124_mass_uncertainty_robustness_gate_or_FORCE_R125_gravity_map_radius_depth_sweep_gate")
    print("=== END COPY/PASTE R123 RESULT ===")
    return 0 if zip_integrity == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
