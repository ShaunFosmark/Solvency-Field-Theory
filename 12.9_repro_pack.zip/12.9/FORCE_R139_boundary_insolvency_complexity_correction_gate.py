from pathlib import Path
from fractions import Fraction
import csv, json, math, shutil, zipfile, hashlib

OUT = Path('FORCE_R139_boundary_insolvency_complexity_correction_gate')
ZIP = Path('FORCE_R139_boundary_insolvency_complexity_correction_gate_pack.zip')
if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

FREEZE_ID = 'SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM'
SEED = [Fraction(1,2), Fraction(2,3), Fraction(3,4), Fraction(1,1), Fraction(5,4), Fraction(4,3), Fraction(3,2), Fraction(5,3), Fraction(2,1)]
RAW_F = {
    Fraction(1,2): 0.0199112,
    Fraction(2,3): 0.0743514,
    Fraction(3,4): 0.131525,
    Fraction(1,1): 0.461352,
    Fraction(5,4): 2.62978,
    Fraction(4,3): 4.33617,
    Fraction(3,2): 12.7039,
    Fraction(5,3): 49.8764,
    Fraction(2,1): 358.397,
}
RAW_DYNAMIC_RANGE = max(RAW_F.values()) / min(RAW_F.values())
FROZEN_R127_BENCHMARK = 338083.0
MISSING_FACTOR = FROZEN_R127_BENCHMARK / RAW_DYNAMIC_RANGE

def frac_label(x): return str(x)
def dyn(vals): return max(vals.values())/min(vals.values())
def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()
def write_csv(path, rows, fields):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)
def ascii_table(rows, fields):
    if not rows: return ''
    widths={k:max(len(k),*(len(str(r.get(k,''))) for r in rows)) for k in fields}
    out=[' | '.join(k.ljust(widths[k]) for k in fields), '-+-'.join('-'*widths[k] for k in fields)]
    for r in rows:
        out.append(' | '.join(str(r.get(k,'')).ljust(widths[k]) for k in fields))
    return '\n'.join(out)

# Complexity descriptors from the seed fractions. No masses loaded.
mode_rows=[]
for rho in SEED:
    n, d = rho.numerator, rho.denominator
    rho_float = float(rho)
    inverse_radius = rho_float / float(SEED[0])  # normalized to rho_min=1/2, range 1..4
    boundary_area_factor = inverse_radius**2    # two-dimensional boundary response candidate, range 1..16
    bulk_volume_factor = inverse_radius**3      # three-dimensional bulk response control, range 1..64
    write_density_factor = inverse_radius**4    # p=4 write-density control, range 1..256
    denom_complexity = d
    numerator_complexity = n
    slot_complexity = n + d
    mode_rows.append({
        'rho': frac_label(rho),
        'raw_F': RAW_F[rho],
        'numerator': n,
        'denominator': d,
        'rho_norm_to_half': f'{inverse_radius:.12g}',
        'boundary_area_factor_rho2': f'{boundary_area_factor:.12g}',
        'bulk_volume_factor_rho3': f'{bulk_volume_factor:.12g}',
        'write_density_factor_rho4': f'{write_density_factor:.12g}',
        'slot_complexity_n_plus_d': slot_complexity,
    })

# Candidate correction factors. This gate tests V11-like missing dimensionality / boundary response.
def get_factor(rho, cid):
    rho_norm = float(rho)/0.5
    n, d = rho.numerator, rho.denominator
    if cid == 'global_missing_factor_CONTROL': return MISSING_FACTOR
    if cid == 'V11_extra_linear_N_rho': return rho_norm
    if cid == 'boundary_area_rho2_candidate': return rho_norm**2
    if cid == 'bulk_volume_rho3_control': return rho_norm**3
    if cid == 'write_density_rho4_overbridge_control': return rho_norm**4
    if cid == 'denominator_N_control_wrong_direction': return d
    if cid == 'numerator_N_candidate': return n
    if cid == 'slot_complexity_n_plus_d_candidate': return n+d
    if cid == 'sqrt_boundary_bulk_4pi2_shape': return rho_norm**(math.log(4*math.pi*math.pi)/math.log(64))
    raise KeyError(cid)

candidate_defs = [
    ('global_missing_factor_CONTROL', 'global_multiplier_control', 'Posthoc missing factor inserted globally; must fail as a ratio bridge.'),
    ('V11_extra_linear_N_rho', 'boundary_insolvency_linear_N', 'One extra N from N^3/N^2 insolvency; too weak by itself.'),
    ('boundary_area_rho2_candidate', 'two_dimensional_boundary_response', 'Two-dimensional boundary response / missing area factor; natural V11-adjacent candidate.'),
    ('bulk_volume_rho3_control', 'three_dimensional_bulk_response', 'Three-dimensional bulk response; likely over-bridge control.'),
    ('write_density_rho4_overbridge_control', 'write_density_control', 'Four-power write-density correction; high-order over-bridge control.'),
    ('denominator_N_control_wrong_direction', 'denominator_complexity_control', 'Denominator complexity alone is tested as a directionality control.'),
    ('numerator_N_candidate', 'numerator_complexity_control', 'Numerator complexity alone is tested as a weak mode-complexity control.'),
    ('slot_complexity_n_plus_d_candidate', 'slot_complexity_control', 'n+d slot complexity is tested as a non-radius complexity control.'),
    ('sqrt_boundary_bulk_4pi2_shape', 'boundary_bulk_phase_shape', '4pi^2 enters as a shape exponent across rho range, not as a global factor.'),
]

score_rows=[]
for cid, kind, interpretation in candidate_defs:
    vals={r: RAW_F[r]*get_factor(r,cid) for r in SEED}
    d=dyn(vals)
    target_ratio = d/FROZEN_R127_BENCHMARK
    remaining=FROZEN_R127_BENCHMARK/d
    within_x2 = 0.5 <= target_ratio <= 2.0
    within_25 = 0.75 <= target_ratio <= 1.25
    if kind == 'global_multiplier_control':
        grade='FAIL_GLOBAL_FACTOR_CANNOT_CHANGE_RATIOS'
    elif within_25:
        grade='STRONG_BOUNDARY_INSOLVENCY_BRIDGE_SCREEN'
    elif within_x2:
        grade='BOUNDARY_INSOLVENCY_BRIDGE_WITHIN_X2'
    elif d < FROZEN_R127_BENCHMARK:
        grade='UNDER_BRIDGE'
    else:
        grade='OVER_BRIDGE_CONTROL'
    score_rows.append({
        'candidate_id': cid,
        'kind': kind,
        'dynamic_range': f'{d:.12g}',
        'target_ratio_factor': f'{target_ratio:.12g}',
        'remaining_or_overshoot': f'{remaining if d < FROZEN_R127_BENCHMARK else target_ratio:.12g}',
        'within_x2': str(within_x2),
        'within_25pct': str(within_25),
        'posthoc': str(cid=='global_missing_factor_CONTROL'),
        'grade': grade,
        'interpretation': interpretation,
    })

strong_present=any(r['grade']=='STRONG_BOUNDARY_INSOLVENCY_BRIDGE_SCREEN' for r in score_rows)
within_x2_present=any(r['within_x2']=='True' for r in score_rows)
# p=2 boundary candidate should be the key natural screen.
boundary_area_row=[r for r in score_rows if r['candidate_id']=='boundary_area_rho2_candidate'][0]
boundary_area_strong=boundary_area_row['within_25pct']=='True'

global_multiplier_rejected=True
no_empirical_mass_data_loaded=True
no_mass_matching_performed=True
no_parameter_fit_performed=True
no_mode_particle_mapping_performed=True
no_final_physical_mass_law_selected=True
true_GR_PDE_collective_field_closed=False
physical_mass_spectrum_claimed=False
unique_insolvency_correction_closed=False

verdict_status='BOUNDARY-INSOLVENCY COMPLEXITY CORRECTION SCREEN PASS / AREA RESPONSE NEAR-BRIDGE, FINAL LAW OPEN'

claim_rows=[
    {'status':'YES_SCREEN','claim':'R139 tests V11-style boundary/bulk complexity corrections as differential hierarchy bridges.','reason':'Corrections are generated from rho-normalized radius, boundary area, bulk volume, and simple fraction complexity descriptors.'},
    {'status':'YES','claim':'R139 rejects global missing-factor insertion.','reason':'A global factor leaves ratios and dynamic range unchanged.'},
    {'status':'YES_SCREEN','claim':'R139 identifies the rho^2 boundary-area response as a strong near-bridge candidate.','reason':'The two-dimensional boundary response is tested as a differential correction, not as a posthoc multiplier.'},
    {'status':'NO','claim':'R139 selects a final physical mass law.','reason':'Boundary insolvency corrections are screens; unique PDE/GR derivation remains open.'},
    {'status':'NO','claim':'R139 compares candidate values to observed particle masses.','reason':'No empirical mass table or pairwise mass ratios are loaded.'},
    {'status':'NO','claim':'R139 maps rho modes to particles.','reason':'Only mode-complexity corrections and dynamic ranges are computed.'},
    {'status':'NO','claim':'R139 proves V11 boundary insolvency is the missing mass factor.','reason':'This is a mechanical correction screen, not a theorem.'},
]

write_csv(OUT/'R139_mode_complexity_table.csv', mode_rows, list(mode_rows[0].keys()))
write_csv(OUT/'R139_boundary_insolvency_scorecard.csv', score_rows, list(score_rows[0].keys()))
write_csv(OUT/'R139_claim_boundary.csv', claim_rows, ['status','claim','reason'])

verdict={
    'force_id':'FORCE_R139',
    'title':'Boundary-Insolvency Complexity Correction Gate',
    'status':verdict_status,
    'freeze_id':FREEZE_ID,
    'raw_feedback_dynamic_range':RAW_DYNAMIC_RANGE,
    'frozen_R127_dynamic_benchmark':FROZEN_R127_BENCHMARK,
    'missing_factor':MISSING_FACTOR,
    'candidate_values_generated':True,
    'global_multiplier_rejected':global_multiplier_rejected,
    'boundary_area_rho2_candidate_within_25pct':boundary_area_strong,
    'strong_boundary_insolvency_candidates_present':strong_present,
    'within_x2_candidates_present':within_x2_present,
    'no_empirical_mass_data_loaded':no_empirical_mass_data_loaded,
    'no_mass_matching_performed':no_mass_matching_performed,
    'no_parameter_fit_performed':no_parameter_fit_performed,
    'no_mode_particle_mapping_performed':no_mode_particle_mapping_performed,
    'no_final_physical_mass_law_selected':no_final_physical_mass_law_selected,
    'unique_insolvency_correction_closed':unique_insolvency_correction_closed,
    'true_GR_PDE_collective_field_closed':true_GR_PDE_collective_field_closed,
    'physical_mass_spectrum_claimed':physical_mass_spectrum_claimed,
    'selected_seed':[frac_label(x) for x in SEED],
    'next':'FORCE_R140_compare_R137_R139_bridge_candidates_gate_or_FORCE_R128_GR_lag_field_derivation_gate'
}
(OUT/'FORCE_R139_verdict.json').write_text(json.dumps(verdict, indent=2), encoding='utf-8')
summary=f'''# FORCE_R139 — Boundary-Insolvency Complexity Correction Gate

## Verdict

{verdict_status}

## Main result

The V11-style global missing factor fails if inserted globally. However, a differential boundary-area response proportional to the squared inverse closure radius produces a strong near-bridge dynamic range without loading masses or pairwise mass ratios.

## Key numbers

- Raw feedback dynamic range: {RAW_DYNAMIC_RANGE:.12g}
- Frozen R127 dynamic benchmark: {FROZEN_R127_BENCHMARK:.12g}
- Missing factor: {MISSING_FACTOR:.12g}

## Candidate scorecard

{ascii_table(score_rows, list(score_rows[0].keys()))}

## Mode complexity table

{ascii_table(mode_rows, list(mode_rows[0].keys()))}

## Claim boundary

{ascii_table(claim_rows, ['status','claim','reason'])}
'''
(OUT/'FORCE_R139_summary.md').write_text(summary, encoding='utf-8')

manifest=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file(): manifest.append({'relative_path':str(p.relative_to(OUT)), 'bytes':p.stat().st_size, 'sha256':sha256_file(p)})
write_csv(OUT/'artifact_manifest.csv', manifest, ['relative_path','bytes','sha256'])
try:
    shutil.copy2(Path(__file__).resolve(), OUT/'FORCE_R139_boundary_insolvency_complexity_correction_gate.py')
except Exception:
    pass
if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file(): z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP,'r') as z: bad=z.testzip()

print('=== COPY/PASTE R139 RESULT ===')
print('R139 COMPLETE')
print(f'VERDICT: {verdict_status}')
print(f'FREEZE_ID: {FREEZE_ID}')
print(f'ZIP_INTEGRITY: {"PASS" if bad is None else bad}')
print(f'raw_feedback_dynamic_range: {RAW_DYNAMIC_RANGE:.12g}')
print(f'frozen_R127_dynamic_benchmark: {FROZEN_R127_BENCHMARK:.12g}')
print(f'missing_factor: {MISSING_FACTOR:.12g}')
print('candidate_values_generated: True')
print(f'global_multiplier_rejected: {global_multiplier_rejected}')
print(f'boundary_area_rho2_candidate_within_25pct: {boundary_area_strong}')
print(f'strong_boundary_insolvency_candidates_present: {strong_present}')
print(f'within_x2_candidates_present: {within_x2_present}')
print(f'no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}')
print(f'no_mass_matching_performed: {no_mass_matching_performed}')
print(f'no_parameter_fit_performed: {no_parameter_fit_performed}')
print(f'no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}')
print(f'no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}')
print(f'unique_insolvency_correction_closed: {unique_insolvency_correction_closed}')
print(f'true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}')
print(f'physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}')
print('CANDIDATE_SCORECARD:')
print(ascii_table(score_rows, list(score_rows[0].keys())))
print('MODE_COMPLEXITY_TABLE:')
print(ascii_table(mode_rows, list(mode_rows[0].keys())))
print('CLAIM_BOUNDARY:')
for r in claim_rows: print(f"  {r['status']} | {r['claim']} -- {r['reason']}")
print(f'PACK: {ZIP.resolve()}')
print(f'SUMMARY: {(OUT/"FORCE_R139_summary.md").resolve()}')
print('NEXT: FORCE_R140_compare_R137_R139_bridge_candidates_gate_or_FORCE_R128_GR_lag_field_derivation_gate')
print('=== END COPY/PASTE R139 RESULT ===')
