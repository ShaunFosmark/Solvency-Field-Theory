from pathlib import Path
from fractions import Fraction
import itertools
import math
import json
import csv
import hashlib
import shutil
import zipfile
from datetime import datetime

# FORCE_R142_locked_bridge_candidate_mass_screen_gate.py
# Locked Bridge-Candidate Mass Screen Gate
#
# Purpose:
#   Freeze the R141 primary/secondary bridge candidate F(rho) values FIRST,
#   then load a compact charged-fermion screening mass table and compare all
#   pairwise ratios blindly.
#
# Guardrails:
#   - no retuning after mass loading
#   - no exponent fitting
#   - no coefficient fitting
#   - no rho-to-particle mapping
#   - no final physical mass law selected
#   - quark masses are screening inputs only and are scheme/scale dependent

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
OUT = Path("FORCE_R142_locked_bridge_candidate_mass_screen_gate")
PACK = Path("FORCE_R142_locked_bridge_candidate_mass_screen_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Canonical V12.8/V12.9 seed
# -----------------------------
SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]

VIRTUAL_SUPPORTS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"
SELECTED_SEED_TEXT = "{" + ", ".join(str(x) for x in SEED) + "}"

# R126 primary raw feedback preview values. These are geometry-screen values, not masses.
# They are used here as the frozen raw-amplitude base inherited by R137/R139/R141.
RAW_F = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

RAW_DYNAMIC_RANGE = max(RAW_F.values()) / min(RAW_F.values())
FROZEN_R127_DYNAMIC_BENCHMARK = 338083.0
MISSING_FACTOR = FROZEN_R127_DYNAMIC_BENCHMARK / RAW_DYNAMIC_RANGE
REQUIRED_BETA_CONTROL_NOT_LAW = math.log(FROZEN_R127_DYNAMIC_BENCHMARK) / math.log(RAW_DYNAMIC_RANGE) - 1.0

# R141 frozen bridge-candidate roster.
# Primary candidates are single-mechanism survivors. Secondary candidates are partial-hybrid screens.
CANDIDATE_DEFS = [
    {
        "candidate_id": "R137_transverse_phase_volume_6pi_exponent",
        "family": "compound_transverse_lens",
        "status": "PRIMARY_SINGLE_MECHANISM_SURVIVOR",
        "beta": math.log(6.0 * math.pi) / math.log(RAW_DYNAMIC_RANGE),
        "gamma": 0.0,
        "screen_tier": "primary",
        "notes": "6pi enters as beta=ln(6pi)/ln(D_raw), not as a global multiplier.",
    },
    {
        "candidate_id": "R137_oriented_modes_18_exponent",
        "family": "compound_transverse_lens",
        "status": "PRIMARY_SINGLE_MECHANISM_SURVIVOR",
        "beta": math.log(18.0) / math.log(RAW_DYNAMIC_RANGE),
        "gamma": 0.0,
        "screen_tier": "primary",
        "notes": "18 oriented modes enter as an exponent/range source, not as a global multiplier.",
    },
    {
        "candidate_id": "R139_boundary_area_rho2_candidate",
        "family": "boundary_insolvency",
        "status": "PRIMARY_SINGLE_MECHANISM_SURVIVOR",
        "beta": 0.0,
        "gamma": 2.0,
        "screen_tier": "primary",
        "notes": "V11-adjacent inverse boundary-area response; rho_norm^2 differential correction.",
    },
    {
        "candidate_id": "R140B_partial_slot_beta_boundary_quarter",
        "family": "partial_hybrid_screen",
        "status": "SECONDARY_PARTIAL_HYBRID_SCREEN",
        "beta": 0.25,
        "gamma": 0.25,
        "screen_tier": "secondary",
        "notes": "Fixed partial hybrid screen. Not selected as a law.",
    },
    {
        "candidate_id": "R140B_partial_slot_beta_boundary_half",
        "family": "partial_hybrid_screen",
        "status": "SECONDARY_PARTIAL_HYBRID_SCREEN",
        "beta": 0.25,
        "gamma": 0.5,
        "screen_tier": "secondary",
        "notes": "Fixed partial hybrid screen. Not selected as a law.",
    },
    {
        "candidate_id": "raw_feedback_control",
        "family": "baseline",
        "status": "BASELINE_UNDERBRIDGE_CONTROL",
        "beta": 0.0,
        "gamma": 0.0,
        "screen_tier": "control",
        "notes": "Raw feedback amplitude from R126/R127 before bridge corrections.",
    },
]

# Excluded double-counting controls are listed but not screened as primary.
EXCLUDED_CONTROLS = [
    "R140B_full_6pi_exponent_times_rho2",
    "R140B_full_18_exponent_times_rho2",
    "R140B_full_slot_beta_times_rho2",
    "R140B_full_normal_beta_times_rho2",
]

# -----------------------------
# Utility functions
# -----------------------------

def rho_label(rho):
    return str(rho)


def rho_float(rho):
    return float(rho.numerator) / float(rho.denominator)


def rho_norm(rho):
    # Normalize to the lowest seed mode rho=1/2.
    return rho_float(rho) / 0.5


def candidate_value(raw, rn, beta, gamma):
    # Differential bridge candidate: F_raw^(1+beta) * rho_norm^gamma.
    return (raw ** (1.0 + beta)) * (rn ** gamma)


def write_csv(path, rows, fieldnames=None):
    rows = list(rows)
    if fieldnames is None:
        keys = []
        for row in rows:
            for k in row.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def pct_error(a, b):
    if b == 0:
        return float("inf")
    return abs(a - b) / abs(b) * 100.0

# -----------------------------
# STEP 1: Generate and freeze candidate values BEFORE mass loading.
# -----------------------------

candidate_rows = []
for c in CANDIDATE_DEFS:
    vals = []
    for rho in SEED:
        v = candidate_value(RAW_F[rho], rho_norm(rho), c["beta"], c["gamma"])
        vals.append(v)
        candidate_rows.append({
            "candidate_id": c["candidate_id"],
            "family": c["family"],
            "status": c["status"],
            "screen_tier": c["screen_tier"],
            "beta": c["beta"],
            "gamma": c["gamma"],
            "rho": rho_label(rho),
            "rho_float": rho_float(rho),
            "rho_norm": rho_norm(rho),
            "raw_feedback_F": RAW_F[rho],
            "bridge_candidate_F": v,
            "notes": c["notes"],
        })

candidate_values_path = OUT / "R142_candidate_values_FROZEN_BEFORE_MASS_LOADING.csv"
write_csv(candidate_values_path, candidate_rows)
candidate_freeze_hash = file_sha256(candidate_values_path)

# Candidate dynamic ranges are also frozen before mass loading.
candidate_dynamic_rows = []
for c in CANDIDATE_DEFS:
    rows = [r for r in candidate_rows if r["candidate_id"] == c["candidate_id"]]
    vals = [r["bridge_candidate_F"] for r in rows]
    dyn = max(vals) / min(vals)
    factor = dyn / FROZEN_R127_DYNAMIC_BENCHMARK
    if factor >= 1:
        relation = "overshoot"
        remaining_or_overshoot = factor
    else:
        relation = "shortfall"
        remaining_or_overshoot = 1.0 / factor
    candidate_dynamic_rows.append({
        "candidate_id": c["candidate_id"],
        "family": c["family"],
        "status": c["status"],
        "screen_tier": c["screen_tier"],
        "beta": c["beta"],
        "gamma": c["gamma"],
        "dynamic_range": dyn,
        "benchmark_dynamic_range": FROZEN_R127_DYNAMIC_BENCHMARK,
        "relation": relation,
        "remaining_or_overshoot_factor": remaining_or_overshoot,
        "within_25pct": remaining_or_overshoot <= 1.25,
        "within_x2": remaining_or_overshoot <= 2.0,
    })

candidate_dynamic_path = OUT / "R142_candidate_dynamic_ranges_FROZEN_BEFORE_MASS_LOADING.csv"
write_csv(candidate_dynamic_path, candidate_dynamic_rows)
candidate_dynamic_freeze_hash = file_sha256(candidate_dynamic_path)

candidate_values_frozen_before_mass_loading = True

# -----------------------------
# STEP 2: Load mass screening table AFTER freeze.
# -----------------------------
# Compact charged-fermion screening values in MeV.
# Leptons are direct mass screens; quarks are screening-only because quoted values are scheme/scale dependent.
MASS_TABLE = [
    {"particle": "electron", "sector": "lepton", "mass_MeV": 0.51099895, "scheme_note": "direct lepton mass"},
    {"particle": "muon", "sector": "lepton", "mass_MeV": 105.6583755, "scheme_note": "direct lepton mass"},
    {"particle": "tau", "sector": "lepton", "mass_MeV": 1776.86, "scheme_note": "direct lepton mass"},
    {"particle": "up_quark", "sector": "quark", "mass_MeV": 2.16, "scheme_note": "screening value; quark masses are scheme/scale dependent"},
    {"particle": "down_quark", "sector": "quark", "mass_MeV": 4.67, "scheme_note": "screening value; quark masses are scheme/scale dependent"},
    {"particle": "strange_quark", "sector": "quark", "mass_MeV": 93.0, "scheme_note": "screening value; quark masses are scheme/scale dependent"},
    {"particle": "charm_quark", "sector": "quark", "mass_MeV": 1270.0, "scheme_note": "screening value; quark masses are scheme/scale dependent"},
    {"particle": "bottom_quark", "sector": "quark", "mass_MeV": 4180.0, "scheme_note": "screening value; quark masses are scheme/scale dependent"},
    {"particle": "top_quark", "sector": "quark", "mass_MeV": 172760.0, "scheme_note": "screening value; quark masses are scheme/scale dependent"},
]

mass_table_loaded_after_freeze = candidate_values_frozen_before_mass_loading
write_csv(OUT / "R142_mass_screening_table_LOADED_AFTER_FREEZE.csv", MASS_TABLE)

mass_ratio_rows = []
for a, b in itertools.combinations(MASS_TABLE, 2):
    hi, lo = (a, b) if a["mass_MeV"] >= b["mass_MeV"] else (b, a)
    mass_ratio_rows.append({
        "particle_hi": hi["particle"],
        "particle_lo": lo["particle"],
        "sector_hi": hi["sector"],
        "sector_lo": lo["sector"],
        "mass_ratio": hi["mass_MeV"] / lo["mass_MeV"],
        "same_sector": hi["sector"] == lo["sector"],
        "lepton_lepton": hi["sector"] == "lepton" and lo["sector"] == "lepton",
        "quark_quark": hi["sector"] == "quark" and lo["sector"] == "quark",
    })

# -----------------------------
# STEP 3: Blind pairwise comparison.
# -----------------------------

comparison_rows = []
for c in CANDIDATE_DEFS:
    # Controls can be included in separate diagnostics, but top verdict focuses on primary/secondary screens.
    c_rows = [r for r in candidate_rows if r["candidate_id"] == c["candidate_id"]]
    for r1, r2 in itertools.combinations(c_rows, 2):
        F1, F2 = r1["bridge_candidate_F"], r2["bridge_candidate_F"]
        hi, lo = (r1, r2) if F1 >= F2 else (r2, r1)
        f_ratio = hi["bridge_candidate_F"] / lo["bridge_candidate_F"]
        for mr in mass_ratio_rows:
            err = pct_error(f_ratio, mr["mass_ratio"])
            comparison_rows.append({
                "candidate_id": c["candidate_id"],
                "family": c["family"],
                "status": c["status"],
                "screen_tier": c["screen_tier"],
                "beta": c["beta"],
                "gamma": c["gamma"],
                "rho_hi": hi["rho"],
                "rho_lo": lo["rho"],
                "F_ratio": f_ratio,
                "particle_hi": mr["particle_hi"],
                "particle_lo": mr["particle_lo"],
                "mass_ratio": mr["mass_ratio"],
                "pct_error": err,
                "same_sector": mr["same_sector"],
                "lepton_lepton": mr["lepton_lepton"],
                "quark_quark": mr["quark_quark"],
                "warning": "HIGH_MULTIPLE_COMPARISON_AND_QUARK_SCHEME_RISK",
            })

# Sort by percent error.
comparison_rows_sorted = sorted(comparison_rows, key=lambda x: x["pct_error"])
write_csv(OUT / "R142_all_pairwise_mass_ratio_comparisons.csv", comparison_rows_sorted)

# Primary/secondary only top matches, leaving baseline control separate.
screen_rows = [r for r in comparison_rows_sorted if r["screen_tier"] in {"primary", "secondary"}]
control_rows = [r for r in comparison_rows_sorted if r["screen_tier"] == "control"]
write_csv(OUT / "R142_primary_secondary_top_matches.csv", screen_rows[:200])
write_csv(OUT / "R142_control_top_matches.csv", control_rows[:100])

# Per-candidate threshold summary.
threshold_rows = []
for c in CANDIDATE_DEFS:
    rows = [r for r in comparison_rows if r["candidate_id"] == c["candidate_id"]]
    if not rows:
        continue
    dyn_row = next(d for d in candidate_dynamic_rows if d["candidate_id"] == c["candidate_id"])
    best = min(rows, key=lambda x: x["pct_error"])
    threshold_rows.append({
        "candidate_id": c["candidate_id"],
        "family": c["family"],
        "screen_tier": c["screen_tier"],
        "beta": c["beta"],
        "gamma": c["gamma"],
        "dynamic_range": dyn_row["dynamic_range"],
        "best_pct_error": best["pct_error"],
        "best_match": f"{best['rho_hi']} vs {best['rho_lo']} -> {best['particle_hi']} vs {best['particle_lo']}",
        "hits_le_1pct": sum(1 for r in rows if r["pct_error"] <= 1.0),
        "hits_le_5pct": sum(1 for r in rows if r["pct_error"] <= 5.0),
        "same_sector_le_5pct": sum(1 for r in rows if r["pct_error"] <= 5.0 and r["same_sector"]),
        "lepton_lepton_le_5pct": sum(1 for r in rows if r["pct_error"] <= 5.0 and r["lepton_lepton"]),
        "quark_quark_le_5pct": sum(1 for r in rows if r["pct_error"] <= 5.0 and r["quark_quark"]),
        "warning": "HIGH",
    })

threshold_rows_sorted = sorted(threshold_rows, key=lambda x: (x["screen_tier"] != "primary", x["best_pct_error"]))
write_csv(OUT / "R142_threshold_summary_by_candidate.csv", threshold_rows_sorted)

# Full-spectrum monotonic dynamic-range audit.
target_dynamic = max(m["mass_MeV"] for m in MASS_TABLE) / min(m["mass_MeV"] for m in MASS_TABLE)
monotonic_rows = []
for d in candidate_dynamic_rows:
    f_dyn = d["dynamic_range"]
    if f_dyn >= target_dynamic:
        relation = "overshoot"
        shortfall_or_overshoot = f_dyn / target_dynamic
    else:
        relation = "shortfall"
        shortfall_or_overshoot = target_dynamic / f_dyn
    monotonic_rows.append({
        "candidate_id": d["candidate_id"],
        "family": d["family"],
        "screen_tier": d["screen_tier"],
        "F_dynamic_range": f_dyn,
        "target_charged_fermion_dynamic_range": target_dynamic,
        "relation": relation,
        "shortfall_or_overshoot": shortfall_or_overshoot,
        "pass_within_25pct": shortfall_or_overshoot <= 1.25,
        "pass_within_x2": shortfall_or_overshoot <= 2.0,
        "full_spectrum_dynamic_range_pass": shortfall_or_overshoot <= 1.25,
    })
monotonic_rows_sorted = sorted(monotonic_rows, key=lambda x: x["shortfall_or_overshoot"])
write_csv(OUT / "R142_monotonic_full_spectrum_dynamic_range_audit.csv", monotonic_rows_sorted)

# Claim boundary and audit.
any_1pct_pairwise_hits = any(r["pct_error"] <= 1.0 and r["screen_tier"] in {"primary", "secondary"} for r in comparison_rows)
any_5pct_pairwise_hits = any(r["pct_error"] <= 5.0 and r["screen_tier"] in {"primary", "secondary"} for r in comparison_rows)
same_sector_5pct_present = any(r["pct_error"] <= 5.0 and r["same_sector"] and r["screen_tier"] in {"primary", "secondary"} for r in comparison_rows)
lepton_lepton_5pct_present = any(r["pct_error"] <= 5.0 and r["lepton_lepton"] and r["screen_tier"] in {"primary", "secondary"} for r in comparison_rows)
quark_quark_5pct_present = any(r["pct_error"] <= 5.0 and r["quark_quark"] and r["screen_tier"] in {"primary", "secondary"} for r in comparison_rows)
full_spectrum_dynamic_range_any_pass = any(r["full_spectrum_dynamic_range_pass"] and r["screen_tier"] in {"primary", "secondary"} for r in monotonic_rows)
primary_dynamic_range_any_pass = any(r["full_spectrum_dynamic_range_pass"] and r["screen_tier"] == "primary" for r in monotonic_rows)

primary_best_rows = [r for r in screen_rows if r["screen_tier"] == "primary"]
secondary_best_rows = [r for r in screen_rows if r["screen_tier"] == "secondary"]

claim_boundary_rows = [
    {
        "status": "YES_SCREEN",
        "claim": "R142 compares frozen R141 bridge candidates to an external mass-ratio screen.",
        "reason": "Candidate values are written and hashed before the charged-fermion screening table is constructed.",
    },
    {
        "status": "NO",
        "claim": "R142 retunes exponent, boundary correction, candidate values, or mappings after seeing masses.",
        "reason": "All candidate beta/gamma definitions are frozen before mass loading; no optimization is performed.",
    },
    {
        "status": "YES_SCREEN",
        "claim": "R142 reports exploratory pairwise hits.",
        "reason": "Hits carry multiple-comparison warnings and quark-scheme caveats.",
    },
    {
        "status": "NO",
        "claim": "R142 selects a final physical mass law.",
        "reason": "This is a locked screen only; final law selection requires a field derivation and independent controls.",
    },
    {
        "status": "NO",
        "claim": "R142 maps rho modes to particles.",
        "reason": "Only pairwise ratios and sorted diagnostics are computed; no rho-to-particle identities are assigned.",
    },
    {
        "status": "NO",
        "claim": "R142 confirms the nine seed modes as the Standard Model spectrum.",
        "reason": "The nine modes remain a mechanical/operator-geometric seed pending physical identification.",
    },
    {
        "status": "NO",
        "claim": "R142 closes true GR/PDE bridge dynamics.",
        "reason": "R137/R139/R141 bridge candidates are mechanical screens, not solved field equations.",
    },
]
write_csv(OUT / "R142_claim_boundary.csv", claim_boundary_rows)

# Verdict.
if candidate_values_frozen_before_mass_loading and mass_table_loaded_after_freeze and any_5pct_pairwise_hits:
    verdict = "LOCKED BRIDGE-CANDIDATE MASS SCREEN PASS / SCREEN HITS REPORTED, FINAL LAW OPEN"
else:
    verdict = "LOCKED BRIDGE-CANDIDATE MASS SCREEN INCONCLUSIVE"

# Summary text.
summary_lines = []
summary_lines.append("# FORCE_R142 — Locked Bridge-Candidate Mass Screen Gate")
summary_lines.append("")
summary_lines.append(f"VERDICT: {verdict}")
summary_lines.append(f"FREEZE_ID: {FREEZE_ID}")
summary_lines.append(f"candidate_freeze_hash: {candidate_freeze_hash}")
summary_lines.append(f"candidate_dynamic_freeze_hash: {candidate_dynamic_freeze_hash}")
summary_lines.append(f"selected_seed: {SELECTED_SEED_TEXT}")
summary_lines.append(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
summary_lines.append("")
summary_lines.append("## Key booleans")
for key, val in [
    ("candidate_values_frozen_before_mass_loading", candidate_values_frozen_before_mass_loading),
    ("empirical_mass_data_loaded_after_freeze", mass_table_loaded_after_freeze),
    ("blind_comparison_generated", True),
    ("any_1pct_pairwise_hits", any_1pct_pairwise_hits),
    ("any_5pct_pairwise_hits", any_5pct_pairwise_hits),
    ("same_sector_5pct_present", same_sector_5pct_present),
    ("lepton_lepton_5pct_present", lepton_lepton_5pct_present),
    ("quark_quark_5pct_present", quark_quark_5pct_present),
    ("full_spectrum_dynamic_range_any_pass", full_spectrum_dynamic_range_any_pass),
    ("primary_dynamic_range_any_pass", primary_dynamic_range_any_pass),
    ("no_parameter_fit_performed", True),
    ("no_functional_retuning_after_mass_loading", True),
    ("no_mode_particle_mapping_performed", True),
    ("no_final_physical_mass_law_selected", True),
]:
    summary_lines.append(f"- {key}: {val}")
summary_lines.append("")
summary_lines.append("## Primary candidates")
for r in candidate_dynamic_rows:
    if r["screen_tier"] == "primary":
        summary_lines.append(f"- {r['candidate_id']}: dyn={r['dynamic_range']:.6g}, {r['relation']} factor={r['remaining_or_overshoot_factor']:.6g}")
summary_lines.append("")
summary_lines.append("## Top primary/secondary matches")
for r in screen_rows[:30]:
    summary_lines.append(
        f"- {r['candidate_id']} | {r['rho_hi']} vs {r['rho_lo']} | F={r['F_ratio']:.6g} | "
        f"{r['particle_hi']} vs {r['particle_lo']} | M={r['mass_ratio']:.6g} | "
        f"err={r['pct_error']:.6g}% | same_sector={r['same_sector']} | lepton={r['lepton_lepton']} | quark={r['quark_quark']}"
    )
summary_lines.append("")
summary_lines.append("## Threshold summary")
for r in threshold_rows_sorted:
    summary_lines.append(
        f"- {r['candidate_id']} | tier={r['screen_tier']} | dyn={r['dynamic_range']:.6g} | "
        f"best_err={r['best_pct_error']:.6g}% | hits<=1%={r['hits_le_1pct']} | "
        f"hits<=5%={r['hits_le_5pct']} | same_sector<=5%={r['same_sector_le_5pct']} | "
        f"lepton<=5%={r['lepton_lepton_le_5pct']} | quark<=5%={r['quark_quark_le_5pct']}"
    )
summary_lines.append("")
summary_lines.append("## Monotonic full-spectrum audit")
for r in monotonic_rows_sorted:
    summary_lines.append(
        f"- {r['candidate_id']} | tier={r['screen_tier']} | F_dyn={r['F_dynamic_range']:.6g} | "
        f"target_dyn={r['target_charged_fermion_dynamic_range']:.6g} | {r['relation']}={r['shortfall_or_overshoot']:.6g} | "
        f"pass25={r['pass_within_25pct']}"
    )
summary_lines.append("")
summary_lines.append("## Claim boundary")
for r in claim_boundary_rows:
    summary_lines.append(f"- {r['status']} | {r['claim']} -- {r['reason']}")
summary_lines.append("")
summary_lines.append("NEXT: FORCE_R143_bridge_screen_interpretation_gate_or_FORCE_R128_GR_lag_field_derivation_gate")

summary_path = OUT / "FORCE_R142_summary.md"
summary_path.write_text("\n".join(summary_lines), encoding="utf-8")

# Verdict JSON.
verdict_json = {
    "force_id": "R142",
    "verdict": verdict,
    "freeze_id": FREEZE_ID,
    "candidate_freeze_hash": candidate_freeze_hash,
    "candidate_dynamic_freeze_hash": candidate_dynamic_freeze_hash,
    "candidate_values_frozen_before_mass_loading": candidate_values_frozen_before_mass_loading,
    "empirical_mass_data_loaded_after_freeze": mass_table_loaded_after_freeze,
    "blind_comparison_generated": True,
    "any_1pct_pairwise_hits": any_1pct_pairwise_hits,
    "any_5pct_pairwise_hits": any_5pct_pairwise_hits,
    "same_sector_5pct_present": same_sector_5pct_present,
    "lepton_lepton_5pct_present": lepton_lepton_5pct_present,
    "quark_quark_5pct_present": quark_quark_5pct_present,
    "full_spectrum_dynamic_range_any_pass": full_spectrum_dynamic_range_any_pass,
    "primary_dynamic_range_any_pass": primary_dynamic_range_any_pass,
    "no_parameter_fit_performed": True,
    "no_functional_retuning_after_mass_loading": True,
    "no_mode_particle_mapping_performed": True,
    "no_final_physical_mass_law_selected": True,
    "physical_mass_spectrum_claimed": False,
    "SM_mass_matching_claimed": False,
    "Omega0_claimed": False,
    "true_GR_PDE_collective_field_closed": False,
    "selected_seed": [str(x) for x in SEED],
    "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
    "raw_feedback_dynamic_range": RAW_DYNAMIC_RANGE,
    "benchmark_dynamic_range": FROZEN_R127_DYNAMIC_BENCHMARK,
    "required_beta_CONTROL_NOT_LAW": REQUIRED_BETA_CONTROL_NOT_LAW,
    "pack": str(PACK.resolve()),
    "summary": str(summary_path.resolve()),
    "next": "FORCE_R143_bridge_screen_interpretation_gate_or_FORCE_R128_GR_lag_field_derivation_gate",
}
(OUT / "FORCE_R142_verdict.json").write_text(json.dumps(verdict_json, indent=2), encoding="utf-8")

# Manifest.
manifest_rows = []
for path in sorted(OUT.rglob("*")):
    if path.is_file():
        manifest_rows.append({
            "relative_path": str(path.relative_to(OUT)),
            "bytes": path.stat().st_size,
            "sha256": file_sha256(path),
        })
write_csv(OUT / "artifact_manifest.csv", manifest_rows)

# Copy script for reproducibility.
try:
    script_path = Path(__file__).resolve()
    shutil.copy2(script_path, OUT / script_path.name)
except Exception:
    pass

# Build zip pack.
if PACK.exists():
    PACK.unlink()
with zipfile.ZipFile(PACK, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for path in sorted(OUT.rglob("*")):
        if path.is_file():
            zf.write(path, path.relative_to(OUT.parent))

with zipfile.ZipFile(PACK, "r") as zf:
    zip_bad_file = zf.testzip()
zip_integrity_pass = zip_bad_file is None

# Render console tables compactly without pandas.
def print_table(rows, columns, max_rows=None):
    rows = list(rows)
    if max_rows is not None:
        rows = rows[:max_rows]
    widths = []
    for col in columns:
        widths.append(max(len(str(col)), *(len(str(r.get(col, ""))) for r in rows)) if rows else len(str(col)))
    header = " | ".join(str(col).ljust(w) for col, w in zip(columns, widths))
    sep = "-+-".join("-" * w for w in widths)
    print(header)
    print(sep)
    for r in rows:
        print(" | ".join(str(r.get(col, "")).ljust(w) for col, w in zip(columns, widths)))

print("\n=== COPY/PASTE R142 RESULT ===")
print("R142 COMPLETE")
print(f"VERDICT: {verdict}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else 'FAIL: ' + str(zip_bad_file)}")
print(f"candidate_values_frozen_before_mass_loading: {candidate_values_frozen_before_mass_loading}")
print(f"empirical_mass_data_loaded_after_freeze: {mass_table_loaded_after_freeze}")
print("blind_comparison_generated: True")
print(f"candidate_freeze_hash: {candidate_freeze_hash}")
print(f"candidate_dynamic_freeze_hash: {candidate_dynamic_freeze_hash}")
print(f"any_1pct_pairwise_hits: {any_1pct_pairwise_hits}")
print(f"any_5pct_pairwise_hits: {any_5pct_pairwise_hits}")
print(f"same_sector_5pct_present: {same_sector_5pct_present}")
print(f"lepton_lepton_5pct_present: {lepton_lepton_5pct_present}")
print(f"quark_quark_5pct_present: {quark_quark_5pct_present}")
print(f"full_spectrum_dynamic_range_any_pass: {full_spectrum_dynamic_range_any_pass}")
print(f"primary_dynamic_range_any_pass: {primary_dynamic_range_any_pass}")
print("no_parameter_fit_performed: True")
print("no_functional_retuning_after_mass_loading: True")
print("no_mode_particle_mapping_performed: True")
print("no_final_physical_mass_law_selected: True")
print("physical_mass_spectrum_claimed: False")
print("SM_mass_matching_claimed: False")
print("Omega0_claimed: False")
print("true_GR_PDE_collective_field_closed: False")
print(f"selected_seed: {SELECTED_SEED_TEXT}")
print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
print("PRIMARY_DYNAMIC_RANGES:")
print_table([r for r in candidate_dynamic_rows if r["screen_tier"] == "primary"], ["candidate_id", "family", "dynamic_range", "relation", "remaining_or_overshoot_factor", "within_25pct"], max_rows=10)
print("SECONDARY_DYNAMIC_RANGES:")
print_table([r for r in candidate_dynamic_rows if r["screen_tier"] == "secondary"], ["candidate_id", "family", "dynamic_range", "relation", "remaining_or_overshoot_factor", "within_25pct"], max_rows=10)
print("TOP_MATCHES_BY_FUNCTIONAL:")
for r in screen_rows[:20]:
    print(
        f"  {r['candidate_id']} | {r['rho_hi']} vs {r['rho_lo']} | F={r['F_ratio']:.6g} | "
        f"{r['particle_hi']} vs {r['particle_lo']} | M={r['mass_ratio']:.6g} | "
        f"err={r['pct_error']:.6g}% | same_sector={r['same_sector']} | "
        f"lepton_lepton={r['lepton_lepton']} | quark_quark={r['quark_quark']} | warning=HIGH"
    )
print("THRESHOLD_SUMMARY:")
for r in threshold_rows_sorted:
    print(
        f"  {r['candidate_id']} | tier={r['screen_tier']} | dyn={r['dynamic_range']:.6g} | "
        f"best_err={r['best_pct_error']:.6g}% | hits<=1%={r['hits_le_1pct']} | "
        f"hits<=5%={r['hits_le_5pct']} | same_sector<=5%={r['same_sector_le_5pct']} | "
        f"lepton<=5%={r['lepton_lepton_le_5pct']} | quark<=5%={r['quark_quark_le_5pct']} | warning=HIGH"
    )
print("MONOTONIC_FULL_SPECTRUM_AUDIT:")
for r in monotonic_rows_sorted:
    print(
        f"  {r['candidate_id']} | tier={r['screen_tier']} | F_dyn={r['F_dynamic_range']:.6g} | "
        f"target_dyn={r['target_charged_fermion_dynamic_range']:.6g} | "
        f"{r['relation']}={r['shortfall_or_overshoot']:.6g} | pass25={r['pass_within_25pct']} | passx2={r['pass_within_x2']}"
    )
print("CLAIM_BOUNDARY:")
for r in claim_boundary_rows:
    print(f"  {r['status']} | {r['claim']} -- {r['reason']}")
print(f"PACK: {PACK.resolve()}")
print(f"SUMMARY: {summary_path.resolve()}")
print("NEXT: FORCE_R143_bridge_screen_interpretation_gate_or_FORCE_R128_GR_lag_field_derivation_gate")
print("=== END COPY/PASTE R142 RESULT ===\n")
