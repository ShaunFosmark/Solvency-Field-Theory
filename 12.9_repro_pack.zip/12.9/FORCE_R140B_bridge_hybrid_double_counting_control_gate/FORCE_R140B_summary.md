# FORCE_R140B — Bridge Hybrid / Double-Counting Control Gate

## Verdict

BRIDGE HYBRID / DOUBLE-COUNTING CONTROL PASS / FULL HYBRIDS OVERBRIDGE, SINGLE-MECHANISM SURVIVORS PRESERVED

## Key Inputs

- raw_feedback_dynamic_range: 17999.7689742
- frozen_R127_dynamic_benchmark: 338083
- missing_factor: 18.7826299596
- required_beta_CONTROL_NOT_LAW: 0.299336427801

## Gate Booleans

- candidate_values_generated: True
- naive_full_hybrids_generated: True
- naive_full_hybrids_overbridge: True
- partial_hybrids_generated: True
- partial_hybrid_within_25pct_present: True
- equivalence_audit_generated: True
- double_counting_risk_detected: True
- single_mechanism_primary_survivors_present: True
- global_multiplier_rejected: True
- no_empirical_mass_data_loaded: True
- no_mass_matching_performed: True
- no_parameter_fit_performed: True
- no_mode_particle_mapping_performed: True
- no_final_physical_mass_law_selected: True
- true_GR_PDE_collective_field_closed: False

## Candidate Scorecard

candidate_id                               | family                              | beta           | gamma | dynamic_range | remaining_or_overshoot_factor | relation  | within_25pct | grade                             
-------------------------------------------+-------------------------------------+----------------+-------+---------------+-------------------------------+-----------+--------------+-----------------------------------
raw_feedback_control                       | baseline                            | 0              | 0     | 17999.7689742 | 18.7826299595                 | shortfall | False        | UNDERBRIDGE_CONTROL               
R137_6pi_exponent_primary                  | single_mechanism_R137               | 0.2996994416   | 0     | 339287.651855 | 1.00356318376                 | overshoot | True         | PRIMARY_SINGLE_MECHANISM_SURVIVOR 
R137_oriented_18_exponent_primary          | single_mechanism_R137               | 0.294992658618 | 0     | 323995.841537 | 1.04347944219                 | shortfall | True         | PRIMARY_SINGLE_MECHANISM_SURVIVOR 
R137_slot_beta_1_over_4_secondary          | single_mechanism_R137               | 0.25           | 0     | 208489.248416 | 1.62158481825                 | shortfall | False        | WITHIN_X2_SCREEN                  
R137_normal_beta_1_over_3_secondary        | single_mechanism_R137               | 0.333333333333 | 0     | 471725.378191 | 1.39529458207                 | overshoot | False        | WITHIN_X2_SCREEN                  
R139_boundary_area_rho2_primary            | single_mechanism_R139               | 0              | 2     | 287996.303588 | 1.17391437247                 | shortfall | True         | PRIMARY_SINGLE_MECHANISM_SURVIVOR 
R139_boundary_linear_rho_control           | single_mechanism_R139               | 0              | 1     | 71999.075897  | 4.69565748988                 | shortfall | False        | UNDERBRIDGE_CONTROL               
R139_bulk_volume_rho3_overbridge_control   | single_mechanism_R139               | 0              | 3     | 1151985.21435 | 3.40740354987                 | overshoot | False        | OVERBRIDGE_CONTROL                
HYBRID_full_6pi_exponent_times_rho2        | full_hybrid_double_counting_control | 0.2996994416   | 2     | 5428602.42968 | 16.0570109402                 | overshoot | False        | OVERBRIDGE_DOUBLE_COUNTING_WARNING
HYBRID_full_18_exponent_times_rho2         | full_hybrid_double_counting_control | 0.294992658618 | 2     | 5183933.46459 | 15.3333159744                 | overshoot | False        | OVERBRIDGE_DOUBLE_COUNTING_WARNING
HYBRID_full_slot_beta_times_rho2           | full_hybrid_double_counting_control | 0.25           | 2     | 3335827.97465 | 9.8668905998                  | overshoot | False        | OVERBRIDGE_DOUBLE_COUNTING_WARNING
HYBRID_full_normal_beta_times_rho2         | full_hybrid_double_counting_control | 0.333333333333 | 2     | 7547606.05106 | 22.3247133132                 | overshoot | False        | OVERBRIDGE_DOUBLE_COUNTING_WARNING
PARTIAL_slot_beta_times_boundary_quarter   | fixed_partial_hybrid_screen         | 0.25           | 0.25  | 294848.322718 | 1.14663362126                 | shortfall | True         | PARTIAL_HYBRID_WITHIN_25PCT_SCREEN
PARTIAL_slot_beta_times_boundary_half      | fixed_partial_hybrid_screen         | 0.25           | 0.5   | 416978.496831 | 1.23336132497                 | overshoot | True         | PARTIAL_HYBRID_WITHIN_25PCT_SCREEN
PARTIAL_slot_beta_times_boundary_linear    | fixed_partial_hybrid_screen         | 0.25           | 1     | 833956.993663 | 2.46672264995                 | overshoot | False        | OVERBRIDGE_CONTROL                
PARTIAL_normal_beta_times_boundary_quarter | fixed_partial_hybrid_screen         | 0.333333333333 | 0.25  | 667120.427554 | 1.97324452148                 | overshoot | False        | WITHIN_X2_SCREEN                  
PARTIAL_support12_beta_times_boundary_half | fixed_partial_hybrid_screen         | 0.253610704933 | 0.5   | 431994.455382 | 1.2777763312                  | overshoot | False        | WITHIN_X2_SCREEN                  

## Equivalence Audit

source                      | gamma | equivalent_beta_over_seed_range | distance_to_required_beta | distance_to_beta_6pi | interpretation                                                                            
----------------------------+-------+---------------------------------+---------------------------+----------------------+-------------------------------------------------------------------------------------------
boundary_linear_rho_gamma_1 | 1     | 0.141485834165                  | 0.157850593636            | 0.158213607434       | Range-shape equivalence control.                                                          
boundary_area_rho2_gamma_2  | 2     | 0.28297166833                   | 0.0163647594705           | 0.0167277732692      | Boundary factor can mimic exponent steepening over the seed range; beware double counting.
boundary_bulk_rho3_gamma_3  | 3     | 0.424457502496                  | 0.125121074695            | 0.124758060896       | Range-shape equivalence control.                                                          
boundary_quarter_gamma_0p25 | 0.25  | 0.0353714585413                 | 0.26396496926             | 0.264327983058       | Range-shape equivalence control.                                                          
boundary_half_gamma_0p5     | 0.5   | 0.0707429170826                 | 0.228593510718            | 0.228956524517       | Range-shape equivalence control.                                                          

## Beta Source Audit

beta_source                           | beta           | distance_to_required_beta | posthoc
--------------------------------------+----------------+---------------------------+--------
slot_root_beta_1_over_4               | 0.25           | 0.0493364278009           | False  
normal_dimension_beta_1_over_3        | 0.333333333333 | 0.0339969055324           | False  
transverse_phase_volume_6pi_beta      | 0.2996994416   | 0.000363013798727         | False  
oriented_modes_18_beta                | 0.294992658618 | 0.00434376918322          | False  
support_channels_12_beta              | 0.253610704933 | 0.0457257228682           | False  
boundary_area_equivalent_beta         | 0.28297166833  | 0.0163647594705           | False  
posthoc_required_beta_CONTROL_NOT_LAW | 0.299336427801 | 0                         | True   

## Claim Boundary

status     | claim                                                                              | reason                                                                                                                
-----------+------------------------------------------------------------------------------------+-----------------------------------------------------------------------------------------------------------------------
YES_SCREEN | R140B tests hybrid bridge candidates and double-counting controls.                 | R137 exponent and R139 boundary responses are combined only as screens, without mass tables.                          
YES        | Full naive hybrids are tested as double-counting controls.                         | If R137 and R139 encode overlapping transverse/boundary physics, multiplying full corrections should overbridge.      
YES_SCREEN | Boundary-area rho^2 is translated into an equivalent exponent over the seed range. | This checks whether the area correction and exponent correction are two parameterizations of similar range steepening.
NO         | R140B selects a final physical bridge law.                                         | Candidates remain screens; single-mechanism survivors and partial hybrids are queued for synthesis only.              
NO         | R140B compares candidates to observed particle masses.                             | No empirical mass table or pairwise mass ratios are loaded.                                                           
NO         | R140B maps rho modes to particles.                                                 | No rho-to-particle identities are assigned.                                                                           
NO         | R140B closes true GR/PDE field dynamics.                                           | The field-equation derivation remains open.                                                                           
