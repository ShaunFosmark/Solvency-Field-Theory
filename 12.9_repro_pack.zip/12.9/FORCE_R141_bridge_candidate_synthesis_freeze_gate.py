from pathlib import Path
from fractions import Fraction
import hashlib
import json
import math
import shutil
import zipfile
import pandas as pd

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "FORCE_R141"
TITLE = "Bridge Candidate Synthesis / Freeze Gate"
OUT = Path("FORCE_R141_bridge_candidate_synthesis_freeze_gate")
ZIP = Path("FORCE_R141_bridge_candidate_synthesis_freeze_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True, exist_ok=True)

# Frozen constants from R126/R127/R137/R139/R140B screens.
RAW_FEEDBACK_DYNAMIC_RANGE = 17999.7689742
FROZEN_R127_DYNAMIC_BENCHMARK = 338083.0
MISSING_FACTOR = FROZEN_R127_DYNAMIC_BENCHMARK / RAW_FEEDBACK_DYNAMIC_RANGE
REQUIRED_BETA_CONTROL_NOT_LAW = math.log(FROZEN_R127_DYNAMIC_BENCHMARK / RAW_FEEDBACK_DYNAMIC_RANGE) / math.log(RAW_FEEDBACK_DYNAMIC_RANGE)

SEED = [Fraction(1,2), Fraction(2,3), Fraction(3,4), Fraction(1,1), Fraction(5,4), Fraction(4,3), Fraction(3,2), Fraction(5,3), Fraction(2,1)]
RAW_F = {
    Fraction(1,2): 0.0199112,
    Fraction(2,3): 0.0743514,
    Fraction(3,4): 0.131525,
    Fraction(1,1): 0.461352,
    Fraction(5,4): 2.62978,
    Fraction(4,3): 4.33617,
    Fraction(3,2): 12.7039,
    Fraction(5,3): 49.8764,
    Fraction(2,1): 358.397,
}

def flabel(x):
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def candidate_transform(raw, rho, beta=0.0, gamma=0.0):
    # beta exponent correction: raw^(1+beta)
    # gamma boundary response: (rho/(1/2))^gamma = (2 rho)^gamma
    return (raw ** (1.0 + beta)) * ((2.0 * float(rho)) ** gamma)

def dynamic_range(values):
    vals = list(values.values())
    return max(vals) / min(vals)

def factor_relation(dynamic):
    ratio = dynamic / FROZEN_R127_DYNAMIC_BENCHMARK
    if ratio >= 1:
        return "overshoot", ratio
    return "shortfall", 1.0 / ratio

# Candidate freeze roster. Primary = single-mechanism survivors. Secondary = partial screens.
# Excluded controls document double counting and over/under controls.
roster_defs = [
    {
        "candidate_id": "R137_transverse_phase_volume_6pi_exponent",
        "family": "compound_transverse_lens",
        "beta": math.log(6.0 * math.pi) / math.log(RAW_FEEDBACK_DYNAMIC_RANGE),
        "gamma": 0.0,
        "freeze_tier": "PRIMARY",
        "mechanical_story": "Three transverse normal phase channels enter as an exponent/range source, not as a global multiplier.",
        "status": "PRIMARY_SINGLE_MECHANISM_SURVIVOR",
    },
    {
        "candidate_id": "R137_oriented_modes_18_exponent",
        "family": "compound_transverse_lens",
        "beta": math.log(18.0) / math.log(RAW_FEEDBACK_DYNAMIC_RANGE),
        "gamma": 0.0,
        "freeze_tier": "PRIMARY",
        "mechanical_story": "Eighteen oriented seed contributions enter as an exponent/range source, not as a global multiplier.",
        "status": "PRIMARY_SINGLE_MECHANISM_SURVIVOR",
    },
    {
        "candidate_id": "R139_boundary_area_rho2_candidate",
        "family": "boundary_insolvency",
        "beta": 0.0,
        "gamma": 2.0,
        "freeze_tier": "PRIMARY",
        "mechanical_story": "Inverse two-dimensional boundary-area response: correction scales as rho_norm^2.",
        "status": "PRIMARY_SINGLE_MECHANISM_SURVIVOR",
    },
    {
        "candidate_id": "R140B_partial_slot_beta_boundary_quarter",
        "family": "partial_hybrid_screen",
        "beta": 0.25,
        "gamma": 0.25,
        "freeze_tier": "SECONDARY",
        "mechanical_story": "Fixed partial hybrid using slot-root exponent and quarter boundary response; queued as screen only.",
        "status": "PARTIAL_HYBRID_WITHIN_25PCT_SCREEN",
    },
    {
        "candidate_id": "R140B_partial_slot_beta_boundary_half",
        "family": "partial_hybrid_screen",
        "beta": 0.25,
        "gamma": 0.5,
        "freeze_tier": "SECONDARY",
        "mechanical_story": "Fixed partial hybrid using slot-root exponent and half boundary response; queued as screen only.",
        "status": "PARTIAL_HYBRID_WITHIN_25PCT_SCREEN",
    },
    {
        "candidate_id": "raw_feedback_control",
        "family": "baseline",
        "beta": 0.0,
        "gamma": 0.0,
        "freeze_tier": "CONTROL",
        "mechanical_story": "Raw radius/depth feedback before bridge correction.",
        "status": "UNDERBRIDGE_CONTROL",
    },
    {
        "candidate_id": "R137_slot_beta_1_over_4_secondary",
        "family": "compound_transverse_lens",
        "beta": 0.25,
        "gamma": 0.0,
        "freeze_tier": "CONTROL_SECONDARY",
        "mechanical_story": "Fixed slot-root exponent bracket from below.",
        "status": "WITHIN_X2_SCREEN",
    },
    {
        "candidate_id": "R137_normal_beta_1_over_3_secondary",
        "family": "compound_transverse_lens",
        "beta": 1.0/3.0,
        "gamma": 0.0,
        "freeze_tier": "CONTROL_SECONDARY",
        "mechanical_story": "Fixed normal-dimension exponent bracket from above.",
        "status": "WITHIN_X2_SCREEN",
    },
    {
        "candidate_id": "R139_bulk_volume_rho3_overbridge_control",
        "family": "boundary_insolvency",
        "beta": 0.0,
        "gamma": 3.0,
        "freeze_tier": "EXCLUDED_CONTROL",
        "mechanical_story": "Three-dimensional bulk response control; over-bridges.",
        "status": "OVERBRIDGE_CONTROL",
    },
    {
        "candidate_id": "R140B_full_6pi_exponent_times_rho2",
        "family": "full_hybrid_double_counting_control",
        "beta": math.log(6.0 * math.pi) / math.log(RAW_FEEDBACK_DYNAMIC_RANGE),
        "gamma": 2.0,
        "freeze_tier": "EXCLUDED_DOUBLE_COUNTING_CONTROL",
        "mechanical_story": "Full R137 x R139 hybrid; expected double counting if mechanisms overlap.",
        "status": "OVERBRIDGE_DOUBLE_COUNTING_WARNING",
    },
    {
        "candidate_id": "R140B_full_18_exponent_times_rho2",
        "family": "full_hybrid_double_counting_control",
        "beta": math.log(18.0) / math.log(RAW_FEEDBACK_DYNAMIC_RANGE),
        "gamma": 2.0,
        "freeze_tier": "EXCLUDED_DOUBLE_COUNTING_CONTROL",
        "mechanical_story": "Full oriented-18 exponent x R139 hybrid; expected double counting if mechanisms overlap.",
        "status": "OVERBRIDGE_DOUBLE_COUNTING_WARNING",
    },
]

candidate_rows = []
value_rows = []
for spec in roster_defs:
    values = {rho: candidate_transform(RAW_F[rho], rho, spec["beta"], spec["gamma"]) for rho in SEED}
    dyn = dynamic_range(values)
    relation, factor = factor_relation(dyn)
    within_x2 = factor <= 2.0
    within_25pct = factor <= 1.25
    candidate_rows.append({
        **spec,
        "dynamic_range": dyn,
        "relation_to_benchmark": relation,
        "remaining_or_overshoot_factor": factor,
        "within_x2": within_x2,
        "within_25pct": within_25pct,
        "final_law": False,
    })
    for rho in SEED:
        value_rows.append({
            "candidate_id": spec["candidate_id"],
            "freeze_tier": spec["freeze_tier"],
            "rho": flabel(rho),
            "rho_float": float(rho),
            "raw_feedback_F": RAW_F[rho],
            "beta": spec["beta"],
            "gamma": spec["gamma"],
            "candidate_F": values[rho],
        })

candidate_roster = pd.DataFrame(candidate_rows)
candidate_values = pd.DataFrame(value_rows)

primary = candidate_roster[candidate_roster["freeze_tier"] == "PRIMARY"].copy()
secondary = candidate_roster[candidate_roster["freeze_tier"] == "SECONDARY"].copy()
excluded = candidate_roster[candidate_roster["freeze_tier"].str.startswith("EXCLUDED")].copy()

primary_candidates_present = len(primary) >= 3
primary_all_within_25pct = bool(primary["within_25pct"].all())
secondary_candidates_present = len(secondary) >= 2
full_hybrid_controls_excluded = bool((excluded["status"] == "OVERBRIDGE_DOUBLE_COUNTING_WARNING").any())
primary_single_mechanism_survivors_frozen = primary_candidates_present and primary_all_within_25pct
partial_hybrid_screens_queued_not_selected = secondary_candidates_present

mechanism_synthesis = pd.DataFrame([
    {
        "mechanism": "compound_transverse_lens_exponent",
        "status": "PRIMARY_SURVIVOR",
        "representative_candidate": "R137_transverse_phase_volume_6pi_exponent",
        "interpretation": "Numerically strongest single-mechanism bridge; requires derivation of exponent entry from transverse phase response.",
        "next_test": "Locked bridge-candidate mass screen only after freeze; GR/lag derivation later.",
    },
    {
        "mechanism": "boundary_insolvency_area_response",
        "status": "PRIMARY_SURVIVOR",
        "representative_candidate": "R139_boundary_area_rho2_candidate",
        "interpretation": "Mechanically clean V11-adjacent inverse boundary-area response; near-bridge without global multiplication.",
        "next_test": "Locked bridge-candidate mass screen only after freeze; boundary/bulk derivation later.",
    },
    {
        "mechanism": "support_graph_coupling",
        "status": "DIAGNOSTIC_NOT_PRIMARY_BRIDGE",
        "representative_candidate": "R138 support graph diagnostics",
        "interpretation": "Useful for closure ecology; too weak as a hierarchy bridge.",
        "next_test": "Keep as sector/ecology diagnostic, not a lead mass-amplification route.",
    },
    {
        "mechanism": "full_hybrid_corrections",
        "status": "EXCLUDED_AS_DOUBLE_COUNTING_CONTROLS",
        "representative_candidate": "R140B full exponent times rho2 hybrids",
        "interpretation": "Full hybrids over-bridge, suggesting R137 and R139 encode overlapping transverse/boundary structure.",
        "next_test": "Do not use full hybrids as primary mass screens unless a field derivation proves independence.",
    },
    {
        "mechanism": "partial_hybrid_corrections",
        "status": "SECONDARY_SCREEN_ONLY",
        "representative_candidate": "R140B partial slot-beta/boundary candidates",
        "interpretation": "Fixed partial hybrids can bracket the benchmark but risk hidden double counting; queue as secondary only.",
        "next_test": "Report separately in R142, never select by hit count.",
    },
])

claim_boundary = pd.DataFrame([
    {"status": "YES_SCREEN", "claim": "R141 freezes a bridge-candidate roster for future locked screening.", "reason": "Primary and secondary candidates are written and hashed before any new mass screen."},
    {"status": "YES", "claim": "R141 preserves single-mechanism R137/R139 primary survivors.", "reason": "6pi exponent, oriented-18 exponent, and rho^2 boundary-area candidates are kept as primary screens."},
    {"status": "YES", "claim": "R141 excludes full hybrids as double-counting controls.", "reason": "R140B showed full hybrids over-bridge and likely count the same transverse/boundary physics twice."},
    {"status": "NO", "claim": "R141 selects a final physical bridge law.", "reason": "All candidates remain screens; final derivation remains open."},
    {"status": "NO", "claim": "R141 compares candidates to observed particle masses.", "reason": "No empirical mass table or pairwise mass ratios are loaded."},
    {"status": "NO", "claim": "R141 maps rho modes to particles.", "reason": "No rho-to-particle assignment is performed."},
    {"status": "NO", "claim": "R141 closes true GR/PDE field dynamics.", "reason": "Field-equation derivation remains R128/future work."},
])

risk_register = pd.DataFrame([
    {
        "risk": "Treating R137 6pi exponent as a proven law because it nearly matches the benchmark.",
        "severity": "HIGH",
        "mitigation": "Freeze it as a primary screen only; require field/geometry derivation before selecting it.",
    },
    {
        "risk": "Treating R139 rho^2 boundary-area correction as proven V11 insolvency closure.",
        "severity": "HIGH",
        "mitigation": "Label it V11-adjacent and mechanically clean, but keep unique law open.",
    },
    {
        "risk": "Using full hybrids to improve fits despite R140B overbridge warning.",
        "severity": "HIGH",
        "mitigation": "Exclude full hybrids from primary/secondary screens unless a future derivation proves independence.",
    },
    {
        "risk": "Choosing candidates by future mass hit count.",
        "severity": "HIGH",
        "mitigation": "R142 must report hits without retuning or selection; R128 must derive the law.",
    },
])

# Write files before hashing freeze roster.
candidate_roster.to_csv(OUT / "R141_bridge_candidate_roster.csv", index=False)
candidate_values.to_csv(OUT / "R141_bridge_candidate_values_frozen.csv", index=False)
primary.to_csv(OUT / "R141_primary_bridge_candidates.csv", index=False)
secondary.to_csv(OUT / "R141_secondary_bridge_candidates.csv", index=False)
excluded.to_csv(OUT / "R141_excluded_double_counting_controls.csv", index=False)
mechanism_synthesis.to_csv(OUT / "R141_mechanism_synthesis.csv", index=False)
claim_boundary.to_csv(OUT / "R141_claim_boundary.csv", index=False)
risk_register.to_csv(OUT / "R141_risk_register.csv", index=False)

# Hash the frozen values and roster.
hash_source = (OUT / "R141_bridge_candidate_values_frozen.csv").read_bytes() + (OUT / "R141_bridge_candidate_roster.csv").read_bytes()
candidate_freeze_hash = hashlib.sha256(hash_source).hexdigest()

candidate_values_frozen = True
candidate_roster_frozen = True
no_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_parameter_fit_performed = True
no_mode_particle_mapping_performed = True
no_final_physical_mass_law_selected = True
unique_bridge_law_closed = False
true_GR_PDE_collective_field_closed = False
physical_mass_spectrum_claimed = False

verdict_status = "BRIDGE CANDIDATE SYNTHESIS / FREEZE PASS / PRIMARY CANDIDATES FROZEN, FINAL LAW OPEN"

gate_audit = pd.DataFrame([
    {"test": "candidate_values_frozen", "result": "PASS" if candidate_values_frozen else "WARN", "interpretation": "Mode-level bridge-candidate values were written before any future mass screen."},
    {"test": "primary_single_mechanism_survivors_frozen", "result": "PASS" if primary_single_mechanism_survivors_frozen else "WARN", "interpretation": "R137/R139 primary single-mechanism candidates are present and within 25 percent of the frozen benchmark."},
    {"test": "partial_hybrid_screens_queued_not_selected", "result": "PASS" if partial_hybrid_screens_queued_not_selected else "WARN", "interpretation": "Partial hybrids are queued as secondary screens only."},
    {"test": "full_hybrid_controls_excluded", "result": "PASS" if full_hybrid_controls_excluded else "WARN", "interpretation": "Naive full hybrids are excluded as double-counting controls."},
    {"test": "global_multiplier_rejected", "result": "PASS", "interpretation": "Global multipliers remain rejected as ratio/dynamic-range bridges."},
    {"test": "no_empirical_mass_data_loaded", "result": "PASS", "interpretation": "No mass table or pairwise mass ratios are loaded."},
    {"test": "unique_bridge_law_closed", "result": "OPEN", "interpretation": "No final bridge law is selected."},
])

gate_audit.to_csv(OUT / "R141_gate_audit.csv", index=False)

summary = f"""# R141 Bridge Candidate Synthesis / Freeze Gate

## Verdict

{verdict_status}

## Freeze ID

{FREEZE_ID}

## Frozen benchmark inputs

- raw_feedback_dynamic_range: {RAW_FEEDBACK_DYNAMIC_RANGE}
- frozen_R127_dynamic_benchmark: {FROZEN_R127_DYNAMIC_BENCHMARK}
- missing_factor: {MISSING_FACTOR}
- required_beta_CONTROL_NOT_LAW: {REQUIRED_BETA_CONTROL_NOT_LAW}

## Candidate freeze hash

{candidate_freeze_hash}

## Interpretation

R141 freezes the primary bridge-candidate roster for future locked screening. It preserves single-mechanism R137/R139 survivors, queues fixed partial hybrids as secondary screens, and excludes naive full hybrids as double-counting controls. No empirical masses, pairwise mass ratios, or rho-to-particle mappings are loaded.

## Primary candidates

{primary.to_string(index=False)}

## Secondary candidates

{secondary.to_string(index=False)}

## Excluded double-counting controls

{excluded.to_string(index=False)}

## Mechanism synthesis

{mechanism_synthesis.to_string(index=False)}

## Gate audit

{gate_audit.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Risk register

{risk_register.to_string(index=False)}
"""
(OUT / "FORCE_R141_summary.md").write_text(summary, encoding="utf-8")

verdict = {
    "force_id": GATE_ID,
    "title": TITLE,
    "status": verdict_status,
    "freeze_id": FREEZE_ID,
    "candidate_freeze_hash": candidate_freeze_hash,
    "raw_feedback_dynamic_range": RAW_FEEDBACK_DYNAMIC_RANGE,
    "frozen_R127_dynamic_benchmark": FROZEN_R127_DYNAMIC_BENCHMARK,
    "missing_factor": MISSING_FACTOR,
    "required_beta_CONTROL_NOT_LAW": REQUIRED_BETA_CONTROL_NOT_LAW,
    "candidate_values_frozen": candidate_values_frozen,
    "primary_single_mechanism_survivors_frozen": primary_single_mechanism_survivors_frozen,
    "partial_hybrid_screens_queued_not_selected": partial_hybrid_screens_queued_not_selected,
    "full_hybrid_controls_excluded": full_hybrid_controls_excluded,
    "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
    "no_mass_matching_performed": no_mass_matching_performed,
    "no_parameter_fit_performed": no_parameter_fit_performed,
    "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
    "no_final_physical_mass_law_selected": no_final_physical_mass_law_selected,
    "unique_bridge_law_closed": unique_bridge_law_closed,
    "true_GR_PDE_collective_field_closed": true_GR_PDE_collective_field_closed,
    "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
    "recommended_next": "FORCE_R142_locked_bridge_candidate_mass_screen_gate_or_FORCE_R128_GR_lag_field_derivation_gate",
}
(OUT / "FORCE_R141_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

# Manifest and zip.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({"relative_path": str(p.relative_to(OUT)), "bytes": p.stat().st_size, "sha256": sha256_file(p)})
manifest = pd.DataFrame(manifest_rows)
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R141_bridge_candidate_synthesis_freeze_gate.py")
except Exception:
    pass

if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()
zip_integrity_pass = bad is None

print("\n=== COPY/PASTE R141 RESULT ===")
print("R141 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"raw_feedback_dynamic_range: {RAW_FEEDBACK_DYNAMIC_RANGE}")
print(f"frozen_R127_dynamic_benchmark: {FROZEN_R127_DYNAMIC_BENCHMARK}")
print(f"missing_factor: {MISSING_FACTOR}")
print(f"required_beta_CONTROL_NOT_LAW: {REQUIRED_BETA_CONTROL_NOT_LAW}")
print(f"candidate_freeze_hash: {candidate_freeze_hash}")
print(f"candidate_values_frozen: {candidate_values_frozen}")
print(f"primary_single_mechanism_survivors_frozen: {primary_single_mechanism_survivors_frozen}")
print(f"partial_hybrid_screens_queued_not_selected: {partial_hybrid_screens_queued_not_selected}")
print(f"full_hybrid_controls_excluded: {full_hybrid_controls_excluded}")
print(f"no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}")
print(f"no_mass_matching_performed: {no_mass_matching_performed}")
print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
print(f"no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}")
print(f"unique_bridge_law_closed: {unique_bridge_law_closed}")
print(f"true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}")
print("PRIMARY_CANDIDATES:")
print(primary[["candidate_id", "family", "beta", "gamma", "dynamic_range", "remaining_or_overshoot_factor", "within_25pct", "status"]].to_string(index=False))
print("SECONDARY_CANDIDATES:")
print(secondary[["candidate_id", "family", "beta", "gamma", "dynamic_range", "remaining_or_overshoot_factor", "within_25pct", "status"]].to_string(index=False))
print("EXCLUDED_CONTROLS:")
print(excluded[["candidate_id", "family", "beta", "gamma", "dynamic_range", "remaining_or_overshoot_factor", "status"]].to_string(index=False))
print("MECHANISM_SYNTHESIS:")
print(mechanism_synthesis.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R141_summary.md').resolve()}")
print("NEXT: FORCE_R142_locked_bridge_candidate_mass_screen_gate_or_FORCE_R128_GR_lag_field_derivation_gate")
print("=== END COPY/PASTE R141 RESULT ===\n")
