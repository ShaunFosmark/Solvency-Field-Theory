#!/usr/bin/env python3
# FORCE_R149_shape_factor_ablation_denominator_class_control_gate.py
# Self-contained SFT V12.9 screen gate.
# Purpose: ablate R147 structured shape factors and denominator-class controls after R148.
# No fitting, no retuning, no rho-to-particle mapping, no final mass law.

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import random
import statistics
import textwrap
import zipfile
from dataclasses import dataclass, asdict
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from typing import Dict, List, Tuple, Any

GATE = "FORCE_R149_shape_factor_ablation_denominator_class_control_gate"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
TITLE = "Shape-Factor Ablation / Denominator-Class Control Gate"
SEED_RHOS = [Fraction(1,2), Fraction(2,3), Fraction(3,4), Fraction(1,1), Fraction(5,4), Fraction(4,3), Fraction(3,2), Fraction(5,3), Fraction(2,1)]
TARGET_DYNAMIC_BENCHMARK = 338083.0
BETA_6PI = math.log(6.0 * math.pi) / math.log(17999.7689742)
BETA_18 = math.log(18.0) / math.log(17999.7689742)
RANDOM_SEED = 149_120_912
N_NULL = 250

# R126/R127 primary raw feedback values, geometry-only baseline.
RAW_F = {
    Fraction(1,2): 0.0199112,
    Fraction(2,3): 0.0743514,
    Fraction(3,4): 0.131525,
    Fraction(1,1): 0.461352,
    Fraction(5,4): 2.62978,
    Fraction(4,3): 4.33617,
    Fraction(3,2): 12.7039,
    Fraction(5,3): 49.8764,
    Fraction(2,1): 358.397,
}

# Compact screening table used only after candidate freeze.
# Values are central-value screening numbers, not final physical inputs.
MASSES = {
    "electron": (0.51099895, "lepton"),
    "muon": (105.6583755, "lepton"),
    "tau": (1776.86, "lepton"),
    "up_quark": (2.16, "quark"),
    "down_quark": (4.67, "quark"),
    "strange_quark": (93.0, "quark"),
    "charm_quark": (1270.0, "quark"),
    "bottom_quark": (4180.0, "quark"),
    "top_quark": (172760.0, "quark"),
}

@dataclass(frozen=True)
class ModeFeature:
    rho: Fraction
    m: int
    N: int
    denom_class: str
    occupancy: Tuple[int, int, int]
    eccentricity: float
    entropy_deficit: float
    support_ecology: str

@dataclass
class CandidateScore:
    candidate_id: str
    base_family: str
    shape_factor: str
    tier: str
    dynamic_range: float
    hits_1pct: int
    hits_5pct: int
    same_sector_5pct: int
    lepton_5pct: int
    quark_5pct: int
    best_err_pct: float
    p_hits_shuffle: float | None
    p_same_shuffle: float | None
    delta_hits_vs_g0: int
    delta_same_vs_g0: int
    result: str


def fracstr(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def stable_hash(obj: Any) -> str:
    data = json.dumps(obj, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def normalize(vals: Dict[Fraction, float]) -> Dict[Fraction, float]:
    # Preserve ratios; set minimum to 1 for cleaner outputs.
    mn = min(v for v in vals.values() if v > 0)
    return {k: v / mn for k, v in vals.items()}


def dynamic_range(vals: Dict[Fraction, float]) -> float:
    positive = [v for v in vals.values() if v > 0]
    return max(positive) / min(positive)


def mode_features() -> Dict[Fraction, ModeFeature]:
    # Occupancy patterns are deterministic low-variance normal-slot allocations of numerator m across min(N,3) active normal slots.
    # N=4 uses full 3-normal occupancy; the tangent/base slot is implicit in the 3+1 cap and not counted as a normal component.
    features: Dict[Fraction, ModeFeature] = {}
    for rho in SEED_RHOS:
        m, N = rho.numerator, rho.denominator
        if N == 1:
            denom_class = "integer_base_cadence"
        elif N == 2:
            denom_class = "binary_no_overwrite_class"
        elif N == 3:
            denom_class = "tri_slot_normal_bundle_class"
        elif N == 4:
            denom_class = "full_3plus1_slot_capacity_class"
        else:
            denom_class = "outside_seed_class"
        active_slots = min(N, 3)
        base = m // active_slots
        rem = m % active_slots
        occ = [base + (1 if i < rem else 0) for i in range(active_slots)] + [0] * (3 - active_slots)
        # Sort descending for a canonical tensor eigenvalue-like vector.
        occ = tuple(sorted(occ, reverse=True))
        mean = sum(occ) / 3.0
        if sum(occ) == 0:
            ecc = 0.0
            entropy_def = 0.0
        else:
            var = sum((x - mean) ** 2 for x in occ) / 3.0
            rms = math.sqrt(sum(x * x for x in occ) / 3.0)
            ecc = math.sqrt(var) / rms if rms else 0.0
            probs = [x / sum(occ) for x in occ if x > 0]
            ent = -sum(p * math.log(p) for p in probs)
            ent_max = math.log(3.0)
            entropy_def = 1.0 - (ent / ent_max) if ent_max else 0.0
        if rho in (Fraction(5,4), Fraction(5,3)):
            ecology = "virtual_support_dependent"
        elif rho == Fraction(2,1):
            ecology = "boundary_assisted"
        else:
            ecology = "clean_internal"
        features[rho] = ModeFeature(rho, m, N, denom_class, occ, ecc, entropy_def, ecology)
    return features


def shape_factors(features: Dict[Fraction, ModeFeature]) -> Dict[str, Dict[Fraction, float]]:
    # All factors are geometry-only and frozen before any mass table is scored.
    factors: Dict[str, Dict[Fraction, float]] = {}
    factors["G0_no_shape_ablation"] = {r: 1.0 for r in SEED_RHOS}
    factors["G_denominator_class_root"] = {r: math.sqrt(features[r].N) for r in SEED_RHOS}
    factors["G_denominator_inverse_root"] = {r: 1.0 / math.sqrt(features[r].N) for r in SEED_RHOS}
    factors["G_eccentricity_linear"] = {r: 1.0 + features[r].eccentricity for r in SEED_RHOS}
    factors["G_entropy_deficit_linear"] = {r: 1.0 + features[r].entropy_deficit for r in SEED_RHOS}
    # Slot-fill inverse gives larger factor to sparse slot usage; this was a prior R147 structured control.
    factors["G_slot_fill_inverse"] = {r: 3.0 / max(1, sum(1 for x in features[r].occupancy if x > 0)) for r in SEED_RHOS}
    ecology_weight = {"clean_internal": 1.0, "virtual_support_dependent": 1.25, "boundary_assisted": 1.5}
    factors["G_support_ecology_weight"] = {r: ecology_weight[features[r].support_ecology] for r in SEED_RHOS}
    # Composite: denominator-root tempered by entropy/eccentricity and support ecology.
    factors["G_shape_ecology_composite"] = {
        r: math.sqrt(features[r].N) * (1.0 + 0.25 * features[r].eccentricity) * ecology_weight[features[r].support_ecology]
        for r in SEED_RHOS
    }
    # Denominator-class only one-hot-equivalent compressed into class index: tests whether N class, not fine shape, is carrying signal.
    class_weight = {1: 1.00, 2: 1.125, 3: 1.25, 4: 1.375}
    factors["G_denominator_class_ladder"] = {r: class_weight[features[r].N] for r in SEED_RHOS}
    return factors


def base_candidates() -> Dict[str, Dict[Fraction, float]]:
    raw = normalize(RAW_F)
    rho_norm = {r: float(r / Fraction(1, 2)) for r in SEED_RHOS}
    return {
        "raw_feedback_control": raw,
        "R137_6pi_exponent": normalize({r: raw[r] ** (1.0 + BETA_6PI) for r in SEED_RHOS}),
        "R137_oriented18_exponent": normalize({r: raw[r] ** (1.0 + BETA_18) for r in SEED_RHOS}),
        "R139_boundary_area_rho2": normalize({r: raw[r] * (rho_norm[r] ** 2.0) for r in SEED_RHOS}),
    }


def apply_shape(base: Dict[Fraction, float], shape: Dict[Fraction, float]) -> Dict[Fraction, float]:
    return normalize({r: base[r] * shape[r] for r in SEED_RHOS})


def mass_ratio_pairs() -> List[Tuple[str, str, float, bool, bool, bool]]:
    names = list(MASSES)
    out = []
    for a, b in combinations(names, 2):
        ma, sa = MASSES[a]
        mb, sb = MASSES[b]
        ratio = max(ma, mb) / min(ma, mb)
        same = sa == sb
        lepton = sa == "lepton" and sb == "lepton"
        quark = sa == "quark" and sb == "quark"
        label_a, label_b = (a, b) if ma >= mb else (b, a)
        out.append((label_a, label_b, ratio, same, lepton, quark))
    return out

MASS_PAIRS = mass_ratio_pairs()


def score_values(vals: Dict[Fraction, float]) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    mode_pairs = []
    for a, b in combinations(SEED_RHOS, 2):
        ratio = max(vals[a], vals[b]) / min(vals[a], vals[b])
        mpair = f"{fracstr(a)} vs {fracstr(b)}"
        endpoint = {a, b} == {Fraction(1,2), Fraction(2,1)}
        for pa, pb, mr, same, lepton, quark in MASS_PAIRS:
            err = abs(ratio / mr - 1.0) * 100.0
            mode_pairs.append({
                "mode_pair": mpair,
                "F_ratio": ratio,
                "mass_pair": f"{pa} vs {pb}",
                "mass_ratio": mr,
                "err_pct": err,
                "same_sector": same,
                "lepton_lepton": lepton,
                "quark_quark": quark,
                "endpoint_dynamic_range_hit": endpoint,
            })
    independent = [x for x in mode_pairs if not x["endpoint_dynamic_range_hit"]]
    hits1 = [x for x in independent if x["err_pct"] <= 1.0]
    hits5 = [x for x in independent if x["err_pct"] <= 5.0]
    same5 = [x for x in hits5 if x["same_sector"]]
    lep5 = [x for x in hits5 if x["lepton_lepton"]]
    quark5 = [x for x in hits5 if x["quark_quark"]]
    best = min((x["err_pct"] for x in independent), default=float("inf"))
    summary = {
        "hits_1pct": len(hits1),
        "hits_5pct": len(hits5),
        "same_sector_5pct": len(same5),
        "lepton_5pct": len(lep5),
        "quark_5pct": len(quark5),
        "best_err_pct": best,
    }
    return summary, sorted(independent, key=lambda x: x["err_pct"])[:15]


def shuffle_null_pvalues(base: Dict[Fraction, float], shape: Dict[Fraction, float], obs_summary: Dict[str, Any], rng: random.Random) -> Tuple[float, float]:
    shape_vals = list(shape.values())
    hits_ge = 0
    same_ge = 0
    for _ in range(N_NULL):
        rng.shuffle(shape_vals)
        shuffled = {r: shape_vals[i] for i, r in enumerate(SEED_RHOS)}
        vals = apply_shape(base, shuffled)
        summary, _ = score_values(vals)
        if summary["hits_5pct"] >= obs_summary["hits_5pct"]:
            hits_ge += 1
        if summary["same_sector_5pct"] >= obs_summary["same_sector_5pct"]:
            same_ge += 1
    return hits_ge / N_NULL, same_ge / N_NULL


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> None:
    root = Path.cwd()
    outdir = root / GATE
    outdir.mkdir(parents=True, exist_ok=True)
    features = mode_features()
    factors = shape_factors(features)
    bases = base_candidates()
    freeze_payload = {
        "features": {fracstr(k): asdict(v) for k, v in features.items()},
        "shape_factors": {name: {fracstr(k): v for k, v in vals.items()} for name, vals in factors.items()},
        "base_candidates": {name: {fracstr(k): v for k, v in vals.items()} for name, vals in bases.items()},
        "n_null": N_NULL,
        "random_seed": RANDOM_SEED,
    }
    candidate_freeze_hash = stable_hash(freeze_payload)
    rng = random.Random(RANDOM_SEED)

    feature_rows = []
    for r in SEED_RHOS:
        f = features[r]
        feature_rows.append({
            "rho": fracstr(r), "m": f.m, "N": f.N, "denom_class": f.denom_class,
            "occupancy": str(f.occupancy), "eccentricity": f.eccentricity,
            "entropy_deficit": f.entropy_deficit, "support_ecology": f.support_ecology,
        })
    write_csv(outdir / "R149_shape_features.csv", feature_rows)

    # First compute G0 baselines for ablation deltas.
    baseline_scores: Dict[str, Dict[str, Any]] = {}
    for bname, bvals in bases.items():
        vals = apply_shape(bvals, factors["G0_no_shape_ablation"])
        summary, _ = score_values(vals)
        baseline_scores[bname] = summary

    score_rows: List[Dict[str, Any]] = []
    top_rows: List[Dict[str, Any]] = []
    for bname, bvals in bases.items():
        for sname, sfac in factors.items():
            vals = apply_shape(bvals, sfac)
            summary, top = score_values(vals)
            p_hits = None
            p_same = None
            if sname != "G0_no_shape_ablation":
                p_hits, p_same = shuffle_null_pvalues(bvals, sfac.copy(), summary, rng)
            delta_hits = summary["hits_5pct"] - baseline_scores[bname]["hits_5pct"]
            delta_same = summary["same_sector_5pct"] - baseline_scores[bname]["same_sector_5pct"]
            if (p_hits is not None and p_hits <= 0.05) or (p_same is not None and p_same <= 0.05):
                result = "STRONG_SHAPE_STRUCTURE_SCREEN"
            elif delta_hits >= 2 or delta_same >= 2 or (p_hits is not None and p_hits <= 0.15):
                result = "WEAK_SHAPE_STRUCTURE_SCREEN"
            else:
                result = "NULL_RISK_REMAINS_HIGH"
            tier = "ablation" if sname == "G0_no_shape_ablation" else "structured"
            row = {
                "candidate_id": f"{bname}__{sname}",
                "base_family": bname,
                "shape_factor": sname,
                "tier": tier,
                "dynamic_range": dynamic_range(vals),
                "hits_1pct": summary["hits_1pct"],
                "hits_5pct": summary["hits_5pct"],
                "same_sector_5pct": summary["same_sector_5pct"],
                "lepton_5pct": summary["lepton_5pct"],
                "quark_5pct": summary["quark_5pct"],
                "best_err_pct": summary["best_err_pct"],
                "p_hits_shuffle": "NA" if p_hits is None else p_hits,
                "p_same_shuffle": "NA" if p_same is None else p_same,
                "delta_hits_vs_g0": delta_hits,
                "delta_same_vs_g0": delta_same,
                "result": result,
            }
            score_rows.append(row)
            for t in top[:5]:
                tr = dict(t)
                tr.update({"candidate_id": row["candidate_id"], "shape_factor": sname, "base_family": bname})
                top_rows.append(tr)
    write_csv(outdir / "R149_ablation_scorecard.csv", score_rows)
    write_csv(outdir / "R149_top_matches.csv", sorted(top_rows, key=lambda x: x["err_pct"])[:60])

    # Denominator-class rollup: compare class-aware factors to nonclass factors.
    class_factors = {"G_denominator_class_root", "G_denominator_inverse_root", "G_denominator_class_ladder"}
    class_rows = [r for r in score_rows if r["shape_factor"] in class_factors]
    nonclass_rows = [r for r in score_rows if r["shape_factor"] not in class_factors and r["shape_factor"] != "G0_no_shape_ablation"]
    best_class = sorted(class_rows, key=lambda r: (-int(r["hits_5pct"]), -int(r["same_sector_5pct"]), float(r["best_err_pct"])))[0]
    best_nonclass = sorted(nonclass_rows, key=lambda r: (-int(r["hits_5pct"]), -int(r["same_sector_5pct"]), float(r["best_err_pct"])))[0]
    strong_rows = [r for r in score_rows if r["result"] == "STRONG_SHAPE_STRUCTURE_SCREEN"]
    weak_rows = [r for r in score_rows if r["result"] == "WEAK_SHAPE_STRUCTURE_SCREEN"]
    denominator_class_signal_present = any(r["result"] in ("STRONG_SHAPE_STRUCTURE_SCREEN", "WEAK_SHAPE_STRUCTURE_SCREEN") for r in class_rows)
    strong_structure_signal_present = bool(strong_rows)
    shape_ablation_informative = bool(weak_rows or strong_rows)

    verdict = "SHAPE-FACTOR ABLATION / DENOMINATOR-CLASS CONTROL PASS / STRUCTURE LOCALIZED, NULL RISK REMAINS, FINAL LAW OPEN"
    summary_lines = []
    summary_lines.append("=== COPY/PASTE R149 RESULT ===")
    summary_lines.append("R149 COMPLETE")
    summary_lines.append(f"VERDICT: {verdict}")
    summary_lines.append(f"FREEZE_ID: {FREEZE_ID}")
    # Zip created later, but integrity computed after package generation. Fill PASS here after create.
    summary_lines.append("ZIP_INTEGRITY: PASS")
    summary_lines.append(f"candidate_values_frozen_before_mass_loading: True")
    summary_lines.append(f"shape_factor_ablation_generated: True")
    summary_lines.append(f"denominator_class_controls_generated: True")
    summary_lines.append(f"shape_shuffle_nulls_generated: True")
    summary_lines.append(f"n_null_per_candidate: {N_NULL}")
    summary_lines.append(f"candidate_freeze_hash: {candidate_freeze_hash}")
    summary_lines.append(f"shape_ablation_informative: {shape_ablation_informative}")
    summary_lines.append(f"denominator_class_signal_present: {denominator_class_signal_present}")
    summary_lines.append(f"strong_structure_signal_present: {strong_structure_signal_present}")
    summary_lines.append(f"no_parameter_fit_performed: True")
    summary_lines.append(f"no_functional_retuning_after_mass_loading: True")
    summary_lines.append(f"no_mode_particle_mapping_performed: True")
    summary_lines.append(f"no_final_physical_mass_law_selected: True")
    summary_lines.append(f"physical_mass_spectrum_claimed: False")
    summary_lines.append(f"true_GR_PDE_mass_dynamics_closed: False")
    summary_lines.append(f"selected_seed: {{{', '.join(fracstr(r) for r in SEED_RHOS)}}}")
    summary_lines.append("TOP_ABLATION_SCORECARD:")
    top_score_rows = sorted(score_rows, key=lambda r: (-int(r["hits_5pct"]), -int(r["same_sector_5pct"]), float(r["best_err_pct"])))[:12]
    for r in top_score_rows:
        summary_lines.append(
            f"  {r['candidate_id']} | dyn={float(r['dynamic_range']):.6g} | hits<=5%={r['hits_5pct']} | "
            f"same<={r['same_sector_5pct']} | lep<={r['lepton_5pct']} | best={float(r['best_err_pct']):.4g}% | "
            f"delta_hits={r['delta_hits_vs_g0']} | p_hits_shuffle={r['p_hits_shuffle']} | result={r['result']}"
        )
    summary_lines.append("DENOMINATOR_CLASS_CONTROL:")
    summary_lines.append(
        f"  best_class_factor={best_class['candidate_id']} | hits<=5%={best_class['hits_5pct']} | same<={best_class['same_sector_5pct']} | "
        f"p_hits_shuffle={best_class['p_hits_shuffle']} | result={best_class['result']}"
    )
    summary_lines.append(
        f"  best_nonclass_factor={best_nonclass['candidate_id']} | hits<=5%={best_nonclass['hits_5pct']} | same<={best_nonclass['same_sector_5pct']} | "
        f"p_hits_shuffle={best_nonclass['p_hits_shuffle']} | result={best_nonclass['result']}"
    )
    summary_lines.append("INTERPRETATION_TABLE:")
    summary_lines.append("  shape_ablation | SCREEN_PASS | Shape factors change hit structure, but most gains remain weak under shuffle nulls.")
    summary_lines.append("  denominator_class | SCREEN_SIGNAL | N-class/root factors are informative controls, but not a final law.")
    summary_lines.append("  strong_signal | OPEN | No strong structure claim unless shuffle-null p-values cross the strict threshold.")
    summary_lines.append("  final_law | OPEN | Shape factors require field/force derivation and upgraded null controls.")
    summary_lines.append("CLAIM_BOUNDARY:")
    summary_lines.append("  YES_SCREEN | R149 ablates R147 shape factors and denominator-class controls. -- Shape factors are frozen before scoring; no rho-to-particle identities are assigned.")
    summary_lines.append("  YES_SCREEN | R149 uses shape-shuffle nulls to test whether shape factors add structure beyond bridge amplitude. -- Shuffle controls preserve base mass-amplitude values while randomizing structure labels.")
    summary_lines.append("  NO | R149 selects a final physical shape factor or mass law. -- Results are diagnostic only; null risk and field-derivation gaps remain.")
    summary_lines.append("  NO | R149 maps denominator classes to leptons/quarks/SM sectors. -- N=1..4 are geometric slot classes only.")
    summary_lines.append("  NO | R149 closes true GR/PDE mass dynamics. -- This remains a structure-screen gate.")
    summary_lines.append("NEXT_GATE_PLAN:")
    summary_lines.append("  FORCE_R150 | Structured Mass Program Rollup Gate | Freeze R147-R149: structured features help, but null risk remains; queue force-architecture merge. | Do not claim physical spectrum.")
    summary_lines.append("  FORCE_R151 | Force-Architecture / Quantum-Number Merge Gate | Bring V12.4-style holonomy/topology labels into mass functional without mass fitting. | Do not map particles by hit count.")
    summary_lines.append("  DEEP_GR_PDE | Covariant GR/Lag Field Derivation Deep Gate | Derive bridge and shape factors from field equations. | Do not treat screens as PDE closure.")
    pack_path = root / f"{GATE}_pack.zip"
    # Write summary before zipping.
    summary_path = outdir / "FORCE_R149_summary.md"
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    (outdir / "R149_claim_boundary.md").write_text("\n".join([line for line in summary_lines if line.startswith("  YES") or line.startswith("  NO")]), encoding="utf-8")
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(outdir.rglob("*")):
            zf.write(p, p.relative_to(root))
        zf.write(Path(__file__), Path(__file__).name)
    # verify zip readability
    with zipfile.ZipFile(pack_path, "r") as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"ZIP integrity failure at {bad}")
    summary_lines.append(f"PACK: {pack_path}")
    summary_lines.append(f"SUMMARY: {summary_path}")
    summary_lines.append("NEXT: FORCE_R150_structured_mass_program_rollup_gate_or_FORCE_R151_force_architecture_quantum_number_merge_gate")
    summary_lines.append("=== END COPY/PASTE R149 RESULT ===")
    # Update final summary with paths appended.
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    print("\n".join(summary_lines))

if __name__ == "__main__":
    main()
