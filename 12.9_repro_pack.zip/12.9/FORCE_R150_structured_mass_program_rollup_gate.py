#!/usr/bin/env python3
"""
FORCE_R150_structured_mass_program_rollup_gate.py

Self-contained V12.9 structured mass program rollup gate.
It freezes the honest interpretation of R147-R149:
  - structured (m,N)/shape features were generated,
  - shape factors are informative screens,
  - slot-fill and denominator-class signals are the strongest current structure hints,
  - null risk remains,
  - no physical spectrum, particle map, mass law, or GR/PDE closure is claimed.

No empirical mass table is loaded. No fitting. No mapping.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import textwrap
import zipfile
from datetime import datetime
from pathlib import Path

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE = "FORCE_R150_structured_mass_program_rollup_gate"
VERDICT = "STRUCTURED MASS PROGRAM ROLLUP PASS / SHAPE STRUCTURE HELPS, NULL RISK REMAINS, FORCE-ARCHITECTURE MERGE NEXT"
SELECTED_SEED = "{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}"
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

# Frozen screen facts from R146-R149. These are not recomputed mass screens here.
PROGRAM_ROLLUP = [
    {
        "gate": "R146",
        "result": "PASS",
        "main_result": "Bridge-screen rollup froze hierarchy-scale candidates and downgraded pairwise hits after R145 null risk.",
        "boundary": "No physical spectrum, no particle mapping, no final mass law.",
    },
    {
        "gate": "R147",
        "result": "PASS",
        "main_result": "Generated (m,N), denominator class, slot occupancy, eccentricity, entropy-deficit, and support-ecology features.",
        "boundary": "Feature generation only; no mass table loaded.",
    },
    {
        "gate": "R148",
        "result": "PASS",
        "main_result": "Structured candidates produced hits and upgraded null tests, but strong null-unusual signal did not close.",
        "boundary": "Null risk remains; no final law selected.",
    },
    {
        "gate": "R149",
        "result": "PASS",
        "main_result": "Shape-factor ablation localized useful structure: slot-fill and denominator-class factors are most informative screens.",
        "boundary": "Shape evidence remains diagnostic; force/quantum-number merge queued.",
    },
]

STRUCTURE_EVIDENCE_LEDGER = [
    {
        "evidence_item": "one_dimensional_Frho_limit",
        "status": "CONFIRMED_LIMIT",
        "what_survives": "F(rho) can generate hierarchy-scale mass-amplitude screens.",
        "what_fails_or_remains_open": "One-dimensional monotonic curves are too easy for null models to mimic internally.",
    },
    {
        "evidence_item": "shape_tensor_features",
        "status": "GENERATED",
        "what_survives": "(m,N), slot occupancy, eccentricity, entropy-deficit, and ecology labels exist for all nine modes.",
        "what_fails_or_remains_open": "These are feature screens, not physical quantum-number assignments.",
    },
    {
        "evidence_item": "slot_fill_inverse",
        "status": "STRONGEST_CURRENT_SHAPE_SCREEN",
        "what_survives": "R149 found the strongest shape-shuffle signal in slot-fill inverse on raw-feedback controls.",
        "what_fails_or_remains_open": "Raw-feedback range still fails the hierarchy; this proves structure matters, not a full mass law.",
    },
    {
        "evidence_item": "denominator_class_root",
        "status": "IMPORTANT_NEAR_SIGNAL",
        "what_survives": "N-class/root factors improved structured candidates and approached shuffle-null significance.",
        "what_fails_or_remains_open": "Denominator class alone is not a final physical sector split.",
    },
    {
        "evidence_item": "eccentricity_entropy_ecology",
        "status": "DIAGNOSTIC_SUPPORT",
        "what_survives": "These factors change hit structure and support a richer mass-functional schema.",
        "what_fails_or_remains_open": "They are not isolated winners yet and need force/field derivation.",
    },
]

R149_SIGNAL_LEDGER = [
    {
        "candidate": "raw_feedback_control__G_slot_fill_inverse",
        "tier": "shape_ablation_control",
        "dynamic_range": "17999.8",
        "hits_5pct": 20,
        "same_sector_hits": 7,
        "lepton_hits": 0,
        "p_hits_shuffle": "0.032",
        "interpretation": "Strongest shape-factor signal, but on raw range-failing baseline; structure matters, mass law not closed.",
    },
    {
        "candidate": "R137_6pi_exponent__G_denominator_class_root",
        "tier": "bridge_plus_shape",
        "dynamic_range": "239913",
        "hits_5pct": 17,
        "same_sector_hits": 11,
        "lepton_hits": 2,
        "p_hits_shuffle": "0.060",
        "interpretation": "Best bridge-plus-denominator-class near-signal; close but not strict significance.",
    },
    {
        "candidate": "raw_feedback_control__G_denominator_class_root",
        "tier": "shape_ablation_control",
        "dynamic_range": "12727.8",
        "hits_5pct": 21,
        "same_sector_hits": 9,
        "lepton_hits": 3,
        "p_hits_shuffle": "0.052",
        "interpretation": "Denominator-class structure is informative, but the dynamic range remains inadequate.",
    },
    {
        "candidate": "R139_boundary_area_rho2__G_eccentricity_linear",
        "tier": "bridge_plus_shape",
        "dynamic_range": "287996",
        "hits_5pct": 15,
        "same_sector_hits": 9,
        "lepton_hits": 5,
        "p_hits_shuffle": "0.200",
        "interpretation": "Many lepton/same-sector screens, but not unusual against shape-shuffle nulls.",
    },
]

CLAIM_BOUNDARY = [
    {
        "status": "YES_SCREEN",
        "claim": "R150 freezes the structured mass-program status after R147-R149.",
        "reason": "It preserves feature-generation and ablation results without loading new masses or tuning candidates.",
    },
    {
        "status": "YES_SCREEN",
        "claim": "Structured features help relative to a featureless one-dimensional F(rho) program.",
        "reason": "R149 localized informative slot-fill and denominator-class factors.",
    },
    {
        "status": "NO",
        "claim": "R150 proves a physical mass spectrum or Standard Model mapping.",
        "reason": "No rho-to-particle identities, no sector assignment, and null risk remains.",
    },
    {
        "status": "NO",
        "claim": "R150 selects a final shape factor or mass law.",
        "reason": "Shape factors remain diagnostic screens pending force-architecture and field-equation derivation.",
    },
    {
        "status": "YES_NEXT_PROGRAM",
        "claim": "The next gate should merge force/quantum-number architecture into the mass functional.",
        "reason": "One-dimensional curves and simple shape factors do not yet provide enough specificity.",
    },
]

NEXT_GATE_PLAN = [
    {
        "next_gate": "FORCE_R151",
        "title": "Force-Architecture / Quantum-Number Merge Gate",
        "goal": "Bring V12.4-style holonomy/topology/charge-color-generation proxy labels into the mass functional without mass fitting.",
        "must_not_do": "Do not map rho modes to particles or choose labels by hit count.",
    },
    {
        "next_gate": "FORCE_R152",
        "title": "Quantum-Structured Null Upgrade Gate",
        "goal": "After force-architecture labels are frozen, compare structured candidates against nulls that preserve dynamic range and shape but randomize quantum labels.",
        "must_not_do": "Do not use particle identities as inputs.",
    },
    {
        "next_gate": "DEEP_GR_PDE",
        "title": "Covariant GR/Lag Field Derivation Deep Gate",
        "goal": "Derive bridge and shape/force factors from field equations.",
        "must_not_do": "Do not treat screens as PDE closure.",
    },
]


def stable_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def table_text(rows: list[dict], max_width: int = 120) -> str:
    if not rows:
        return "(none)"
    headers = list(rows[0].keys())
    str_rows = [{k: str(row.get(k, "")) for k in headers} for row in rows]
    widths = {}
    for h in headers:
        widths[h] = min(max(len(h), *(len(r[h]) for r in str_rows)), max_width)
    def clip(s: str, w: int) -> str:
        return s if len(s) <= w else s[: max(0, w - 3)] + "..."
    out = []
    out.append(" | ".join(clip(h, widths[h]).ljust(widths[h]) for h in headers))
    out.append("-+-".join("-" * widths[h] for h in headers))
    for r in str_rows:
        out.append(" | ".join(clip(r[h], widths[h]).ljust(widths[h]) for h in headers))
    return "\n".join(out)


def zip_dir(src_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(src_dir.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(src_dir.parent))


def zip_integrity(zip_path: Path) -> bool:
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            return zf.testzip() is None
    except Exception:
        return False


def main() -> None:
    root = Path.cwd()
    out_dir = root / GATE
    out_dir.mkdir(parents=True, exist_ok=True)

    freeze_payload = {
        "freeze_id": FREEZE_ID,
        "gate": GATE,
        "verdict": VERDICT,
        "program_rollup": PROGRAM_ROLLUP,
        "structure_evidence_ledger": STRUCTURE_EVIDENCE_LEDGER,
        "r149_signal_ledger": R149_SIGNAL_LEDGER,
        "claim_boundary": CLAIM_BOUNDARY,
    }
    candidate_freeze_hash = sha256_text(stable_json(freeze_payload))

    write_csv(out_dir / "R150_program_rollup.csv", PROGRAM_ROLLUP)
    write_csv(out_dir / "R150_structure_evidence_ledger.csv", STRUCTURE_EVIDENCE_LEDGER)
    write_csv(out_dir / "R150_R149_signal_ledger.csv", R149_SIGNAL_LEDGER)
    write_csv(out_dir / "R150_claim_boundary.csv", CLAIM_BOUNDARY)
    write_csv(out_dir / "R150_next_gate_plan.csv", NEXT_GATE_PLAN)

    summary = f"""# {GATE} Summary

VERDICT: {VERDICT}
FREEZE_ID: {FREEZE_ID}
Generated: {datetime.now().isoformat(timespec='seconds')}

## Selected seed
{SELECTED_SEED}

## Canonical species formula
{CANONICAL_SPECIES_FORMULA}

## Freeze hash
`{candidate_freeze_hash}`

## Program rollup

{table_text(PROGRAM_ROLLUP)}

## Structure evidence ledger

{table_text(STRUCTURE_EVIDENCE_LEDGER)}

## R149 signal ledger

{table_text(R149_SIGNAL_LEDGER)}

## Claim boundary

{table_text(CLAIM_BOUNDARY)}

## Next gate plan

{table_text(NEXT_GATE_PLAN)}
"""
    (out_dir / "FORCE_R150_summary.md").write_text(summary, encoding="utf-8")

    pack = root / f"{GATE}_pack.zip"
    zip_dir(out_dir, pack)
    zip_ok = zip_integrity(pack)

    flags = {
        "mass_amplitude_adequacy_boundary_preserved": True,
        "one_dimensional_Frho_limit_preserved": True,
        "structured_features_help": True,
        "shape_ablation_informative": True,
        "slot_fill_signal_present": True,
        "denominator_class_signal_present": True,
        "strong_null_risk_closed": False,
        "force_architecture_merge_queued": True,
        "no_new_empirical_mass_data_loaded": True,
        "no_mass_matching_performed": True,
        "no_parameter_fit_performed": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "physical_mass_spectrum_claimed": False,
        "true_GR_PDE_mass_dynamics_closed": False,
    }

    print("=== COPY/PASTE R150 RESULT ===")
    print("R150 COMPLETE")
    print(f"VERDICT: {VERDICT}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    print(f"candidate_freeze_hash: {candidate_freeze_hash}")
    for k, v in flags.items():
        print(f"{k}: {v}")
    print(f"selected_seed: {SELECTED_SEED}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("PROGRAM_ROLLUP:")
    print(table_text(PROGRAM_ROLLUP))
    print("STRUCTURE_EVIDENCE_LEDGER:")
    print(table_text(STRUCTURE_EVIDENCE_LEDGER))
    print("R149_SIGNAL_LEDGER:")
    print(table_text(R149_SIGNAL_LEDGER))
    print("CLAIM_BOUNDARY:")
    for row in CLAIM_BOUNDARY:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print("NEXT_GATE_PLAN:")
    print(table_text(NEXT_GATE_PLAN))
    print(f"PACK: {pack}")
    print(f"SUMMARY: {out_dir / 'FORCE_R150_summary.md'}")
    print("NEXT: FORCE_R151_force_architecture_quantum_number_merge_gate")
    print("=== END COPY/PASTE R150 RESULT ===")


if __name__ == "__main__":
    main()
