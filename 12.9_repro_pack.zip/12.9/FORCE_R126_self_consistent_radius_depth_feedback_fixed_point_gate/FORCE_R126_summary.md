# FORCE_R126: Self-Consistent Radius/Depth Feedback Fixed-Point Gate
**Freeze ID:** `SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM`
**Verdict:** `SELF-CONSISTENT RADIUS/DEPTH FEEDBACK SCREEN PASS / FEEDBACK DYNAMIC RANGE REPORTED, TRUE GR-PDE MASS LAW OPEN`

## Claim boundary
- **YES_SCREEN** — R126 tests self-consistent radius/depth feedback maps for helical rho modes. Radius, depth, feedback gain, and fixed-point mass proxies are computed from geometry-only candidate maps.
- **NO** — R126 compares feedback outputs to observed particle masses. No empirical masses or Standard Model target ratios are loaded.
- **NO** — R126 selects a final physical mass law. Feedback grades are diagnostic only; no candidate is selected as a final mass law.
- **NO** — R126 proves the feedback map is a true GR/PDE self-consistent solution. The map is a scalar lag/focusing fixed-point screen, not a solved Einstein/PDE self-energy theorem.
- **NO** — R126 promotes virtual supports to species if their feedback values are interesting. The V12.8 species projection remains locked; F-values and feedback values do not override binary/slot admissibility.
- **YES_SCREEN** — R126 tests whether radius/depth feedback can steepen dynamic range beyond R125. Dynamic ranges, convergence, saturation, and depth-vs-inverse-radius slopes are reported across the seed modes.

## Top diagnostics
- `inverse_lens_quarter_radius | lens_finite_budget | d=3.0 | eta=0.25 | finite_lens_saturating`: dyn=17999.7, slope=3.015, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_rho_radius | lens_finite_budget | d=3.0 | eta=0.25 | finite_lens_saturating`: dyn=17999.7, slope=2.818, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_sqrt_rho_radius | lens_finite_budget | d=3.0 | eta=0.25 | finite_lens_saturating`: dyn=17999.7, slope=3.792, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_lens_eighth_radius | lens_finite_budget | d=3.0 | eta=0.25 | finite_lens_saturating`: dyn=17999.7, slope=3.957, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_sqrt_rho_radius | lens_finite_budget | d=3.0 | eta=0.25 | log_saturating`: dyn=17293.6, slope=3.803, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_rho_radius | lens_finite_budget | d=3.0 | eta=0.25 | log_saturating`: dyn=17293.6, slope=2.816, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_lens_quarter_radius | lens_finite_budget | d=3.0 | eta=0.25 | log_saturating`: dyn=17293.6, slope=3.015, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_lens_eighth_radius | lens_finite_budget | d=3.0 | eta=0.25 | log_saturating`: dyn=17293.6, slope=3.972, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_rho_radius | lens_finite_budget | d=3.0 | eta=0.5 | sqrt_saturating`: dyn=16504.8, slope=2.812, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_sqrt_rho_radius | lens_finite_budget | d=3.0 | eta=0.5 | sqrt_saturating`: dyn=16504.8, slope=3.825, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_lens_quarter_radius | lens_finite_budget | d=3.0 | eta=0.5 | sqrt_saturating`: dyn=16504.8, slope=3.013, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN
- `inverse_lens_eighth_radius | lens_finite_budget | d=3.0 | eta=0.5 | sqrt_saturating`: dyn=16504.8, slope=4.002, conv=1.000, sat=0.000, cap=0.000, grade=STRONG_FEEDBACK_SCREEN

## Boundary
No empirical masses are loaded. No matching, fitting, particle mapping, final mass law, physical spectrum, Standard Model matching, Omega0, or true GR/PDE closure is claimed.
