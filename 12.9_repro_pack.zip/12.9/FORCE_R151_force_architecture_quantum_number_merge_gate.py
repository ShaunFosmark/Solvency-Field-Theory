#!/usr/bin/env python3
"""
FORCE_R151_force_architecture_quantum_number_merge_gate.py

Self-contained V12.9 force-architecture / quantum-number merge gate.
It brings V12.4-style internal labels into the mass-functional schema without
loading masses, fitting, or assigning Standard Model particles.

The goal is to stop treating each mode as just rho and generate a frozen
feature vector:
  (rho, m, N, denominator class, residue/holonomy proxy, topology proxy,
   chirality/orientation proxy, slot occupancy, shape tensor features,
   support ecology)

No empirical masses. No rho-to-particle mapping. No final law.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import zipfile
from datetime import datetime
from fractions import Fraction
from pathlib import Path

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE = "FORCE_R151_force_architecture_quantum_number_merge_gate"
VERDICT = "FORCE-ARCHITECTURE / QUANTUM-NUMBER MERGE SCREEN PASS / INTERNAL LABELS GENERATED, PHYSICAL MAPPING OPEN"
SELECTED_SEED = "{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}"
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

MODES = [Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1), Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)]


def frac_str(x: Fraction | int | str) -> str:
    if isinstance(x, str):
        return x
    if isinstance(x, int):
        return str(x)
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def denom_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, "outside_v12_8_slot_capacity")


def occupancy_vector(m: int, N: int, dims: int = 3) -> tuple[int, int, int]:
    # Distribute m writes as evenly as possible across min(N,3) normal slots.
    active = max(1, min(N, dims))
    base = m // active
    rem = m % active
    occ = [base + (1 if i < rem else 0) for i in range(active)]
    while len(occ) < dims:
        occ.append(0)
    return tuple(occ[:dims])


def entropy_deficit(occ: tuple[int, int, int]) -> float:
    total = sum(occ)
    if total <= 0:
        return 1.0
    active = [x for x in occ if x > 0]
    if len(active) <= 1:
        return 1.0
    probs = [x / total for x in active]
    H = -sum(p * math.log(p) for p in probs)
    Hmax = math.log(len(active))
    return max(0.0, min(1.0, 1.0 - H / Hmax)) if Hmax > 0 else 1.0


def eccentricity(occ: tuple[int, int, int]) -> float:
    total = sum(occ)
    if total <= 0:
        return 0.0
    mean = total / 3.0
    var = sum((x - mean) ** 2 for x in occ) / 3.0
    rms = math.sqrt(var)
    # Normalize by total/dim so values stay readable.
    return rms / mean if mean else 0.0


def support_ecology(rho: Fraction) -> str:
    if rho in {Fraction(5, 4), Fraction(5, 3)}:
        return "virtual_support_dependent"
    if rho == Fraction(2, 1):
        return "boundary_assisted"
    return "clean_internal"


def partner_status(x: Fraction | str) -> str:
    if isinstance(x, str):
        return "boundary_zero"
    if x in MODES:
        return "species"
    # Known virtual supports from V12.8/V12.9 logs.
    if x in {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}:
        return "virtual_support"
    return "outside_support_screen"


def residue_label(m: int, N: int) -> tuple[int, str, float]:
    if N == 1:
        return 0, "integer_residue_zero", 0.0
    residue = m % N
    # Centered residue as a signed holonomy proxy in [-1,1].
    centered = (2.0 * residue / N) - 1.0
    if residue == 0:
        label = "closed_integer_residue"
    elif N == 2:
        label = "binary_odd_holonomy_proxy"
    elif N == 3:
        label = f"tri_residue_{residue}_mod3_proxy"
    elif N == 4:
        label = f"quad_residue_{residue}_mod4_proxy"
    else:
        label = f"residue_{residue}_mod{N}_proxy"
    return residue, label, centered


def topology_label(N: int, residue: int, ecology: str) -> str:
    if N == 1:
        return "integer_base_loop_topology"
    if N == 2:
        return "binary_two_phase_write_topology"
    if N == 3:
        return "tri_normal_bundle_residue_topology"
    if N == 4:
        return "full_slot_capacity_topology"
    return "outside_capacity_topology"


def force_arch_role(N: int, residue: int) -> str:
    # These are force-architecture proxy labels only, not particle/SM assignments.
    if N == 1:
        return "base_cadence_or_boundary_integer_proxy"
    if N == 2:
        return "binary_holonomy_proxy"
    if N == 3:
        return "triadic_bundle_fractional_residue_proxy"
    if N == 4:
        return "max_slot_capacity_shape_proxy"
    return "outside_seed_proxy"


def shape_factor_slot_fill_inverse(occ: tuple[int, int, int]) -> float:
    active = sum(1 for x in occ if x > 0)
    # Inverse fill proxy: sparse occupancy carries a larger shape factor.
    return 3.0 / max(1, active)


def shape_factor_denominator_root(N: int) -> float:
    # Root-normalized denominator class screen. Not a final law.
    return math.sqrt(4.0 / N)


def topology_shape_factor(row: dict) -> float:
    # A frozen geometry-only candidate factor. It is intentionally modest.
    slot = float(row["G_slot_fill_inverse"])
    den = float(row["G_denominator_class_root"])
    ecc = 1.0 + 0.25 * float(row["eccentricity"])
    ecology = row["support_ecology"]
    eco = {"clean_internal": 1.0, "virtual_support_dependent": 1.125, "boundary_assisted": 1.25}.get(ecology, 1.0)
    return slot * den * ecc * eco


def build_rows() -> list[dict]:
    rows: list[dict] = []
    for rho in MODES:
        m, N = rho.numerator, rho.denominator
        occ = occupancy_vector(m, N)
        ent = entropy_deficit(occ)
        ecc = eccentricity(occ)
        residue, residue_lbl, centered = residue_label(m, N)
        R_partner = Fraction(2, 1) - rho
        R_partner_display: str | Fraction = "0_boundary" if R_partner == 0 else R_partner
        C_partner = Fraction(rho.denominator, rho.numerator)
        ecology = support_ecology(rho)
        row = {
            "rho": frac_str(rho),
            "rho_float": f"{float(rho):.12g}",
            "m": m,
            "N": N,
            "denominator_class": denom_class(N),
            "residue_mod_N": residue,
            "holonomy_proxy_label": residue_lbl,
            "centered_holonomy_proxy": f"{centered:.12g}",
            "topology_proxy_label": topology_label(N, residue, ecology),
            "force_arch_role_proxy": force_arch_role(N, residue),
            "occupancy_vector": str(occ),
            "active_slots": sum(1 for x in occ if x > 0),
            "slot_fill_fraction": f"{sum(1 for x in occ if x > 0)/3.0:.12g}",
            "eccentricity": f"{ecc:.12g}",
            "entropy_deficit": f"{ent:.12g}",
            "support_ecology": ecology,
            "R_partner": frac_str(R_partner_display),
            "R_partner_status": partner_status(R_partner_display),
            "C_partner": frac_str(C_partner),
            "C_partner_status": partner_status(C_partner),
            "G_slot_fill_inverse": f"{shape_factor_slot_fill_inverse(occ):.12g}",
            "G_denominator_class_root": f"{shape_factor_denominator_root(N):.12g}",
        }
        row["G_force_shape_topology_candidate"] = f"{topology_shape_factor(row):.12g}"
        rows.append(row)
    return rows


def class_rollup(rows: list[dict]) -> list[dict]:
    out: list[dict] = []
    for N in sorted({int(r["N"]) for r in rows}):
        group = [r for r in rows if int(r["N"]) == N]
        roles = sorted(set(r["force_arch_role_proxy"] for r in group))
        ecologies = sorted(set(r["support_ecology"] for r in group))
        residues = sorted(set(str(r["residue_mod_N"]) for r in group))
        out.append({
            "N": N,
            "denominator_class": denom_class(N),
            "count": len(group),
            "modes": ", ".join(r["rho"] for r in group),
            "residues_present": ", ".join(residues),
            "force_arch_roles": ", ".join(roles),
            "ecologies": ", ".join(ecologies),
            "mean_G_slot_fill_inverse": f"{sum(float(r['G_slot_fill_inverse']) for r in group)/len(group):.6g}",
            "mean_G_denominator_root": f"{sum(float(r['G_denominator_class_root']) for r in group)/len(group):.6g}",
        })
    return out


MASS_FUNCTIONAL_SCHEMA = [
    {
        "object": "M_bridge(rho)",
        "role": "mass-amplitude baseline",
        "inputs": "rho plus field-screen-supported bridge candidate",
        "status": "INHERITED_FROM_R146",
    },
    {
        "object": "G_shape(m,N)",
        "role": "shape/slot correction",
        "inputs": "slot occupancy, denominator class, eccentricity, entropy deficit",
        "status": "GENERATED_R147_R149",
    },
    {
        "object": "Q_force(m,N,residue,topology)",
        "role": "force-architecture label vector",
        "inputs": "residue mod N, holonomy proxy, topology proxy, support ecology",
        "status": "GENERATED_R151_SCREEN",
    },
    {
        "object": "M_structured",
        "role": "future structured mass-amplitude schema",
        "inputs": "M_bridge(rho) * G_shape(m,N) * Q_force(...)",
        "status": "SCHEMA_ONLY_NO_FINAL_LAW",
    },
]

CLAIM_BOUNDARY = [
    {
        "status": "YES_SCREEN",
        "claim": "R151 generates force-architecture proxy labels for each V12.8/V12.9 seed mode.",
        "reason": "Residue, holonomy proxy, topology proxy, denominator class, and support ecology are computed from internal mode data only.",
    },
    {
        "status": "YES_SCREEN",
        "claim": "R151 merges internal label vectors with the structured mass-functional schema.",
        "reason": "The output is a schema for future testing, not a mass fit.",
    },
    {
        "status": "NO",
        "claim": "R151 maps modes to leptons, quarks, colors, generations, or Standard Model particles.",
        "reason": "Labels are geometric/force-architecture proxies only; no particle identities are assigned.",
    },
    {
        "status": "NO",
        "claim": "R151 compares to masses or selects a final law.",
        "reason": "No empirical mass table is loaded and no screening is performed.",
    },
    {
        "status": "NO",
        "claim": "R151 closes true GR/PDE mass dynamics.",
        "reason": "This is an internal label-generation gate, not a field-equation derivation.",
    },
]

NEXT_GATE_PLAN = [
    {
        "next_gate": "FORCE_R152",
        "title": "Quantum-Structured Null Upgrade Gate",
        "goal": "Freeze R151 labels, then test whether structured candidates beat nulls that preserve range and shape while randomizing force labels.",
        "must_not_do": "Do not assign physical particles or tune label weights to hits.",
    },
    {
        "next_gate": "FORCE_R153",
        "title": "Force-Label Ablation Control Gate",
        "goal": "Ablate residue, holonomy, topology, denominator class, and ecology labels to identify which labels actually add structure.",
        "must_not_do": "Do not select a label because it gives a desired particle mapping.",
    },
    {
        "next_gate": "DEEP_GR_PDE",
        "title": "Covariant GR/Lag Field Derivation Deep Gate",
        "goal": "Derive whether shape and force-label factors enter the self-energy from field equations.",
        "must_not_do": "Do not treat label screens as PDE closure.",
    },
]


def stable_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def table_text(rows: list[dict], max_width: int = 120) -> str:
    if not rows:
        return "(none)"
    headers = list(rows[0].keys())
    str_rows = [{k: str(row.get(k, "")) for k in headers} for row in rows]
    widths = {h: min(max(len(h), *(len(r[h]) for r in str_rows)), max_width) for h in headers}
    def clip(s: str, w: int) -> str:
        return s if len(s) <= w else s[: max(0, w - 3)] + "..."
    out = [" | ".join(clip(h, widths[h]).ljust(widths[h]) for h in headers)]
    out.append("-+-".join("-" * widths[h] for h in headers))
    for r in str_rows:
        out.append(" | ".join(clip(r[h], widths[h]).ljust(widths[h]) for h in headers))
    return "\n".join(out)


def zip_dir(src_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(src_dir.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(src_dir.parent))


def zip_integrity(zip_path: Path) -> bool:
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            return zf.testzip() is None
    except Exception:
        return False


def main() -> None:
    rows = build_rows()
    rollup = class_rollup(rows)

    payload = {
        "freeze_id": FREEZE_ID,
        "gate": GATE,
        "verdict": VERDICT,
        "mode_feature_rows": rows,
        "denominator_rollup": rollup,
        "schema": MASS_FUNCTIONAL_SCHEMA,
        "claim_boundary": CLAIM_BOUNDARY,
    }
    candidate_freeze_hash = sha256_text(stable_json(payload))

    root = Path.cwd()
    out_dir = root / GATE
    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(out_dir / "R151_mode_force_architecture_features.csv", rows)
    write_csv(out_dir / "R151_denominator_force_rollup.csv", rollup)
    write_csv(out_dir / "R151_mass_functional_schema.csv", MASS_FUNCTIONAL_SCHEMA)
    write_csv(out_dir / "R151_claim_boundary.csv", CLAIM_BOUNDARY)
    write_csv(out_dir / "R151_next_gate_plan.csv", NEXT_GATE_PLAN)

    summary = f"""# {GATE} Summary

VERDICT: {VERDICT}
FREEZE_ID: {FREEZE_ID}
Generated: {datetime.now().isoformat(timespec='seconds')}

## Selected seed
{SELECTED_SEED}

## Canonical species formula
{CANONICAL_SPECIES_FORMULA}

## Freeze hash
`{candidate_freeze_hash}`

## Mode force-architecture feature preview

{table_text(rows)}

## Denominator/force rollup

{table_text(rollup)}

## Mass functional schema

{table_text(MASS_FUNCTIONAL_SCHEMA)}

## Claim boundary

{table_text(CLAIM_BOUNDARY)}

## Next gate plan

{table_text(NEXT_GATE_PLAN)}
"""
    (out_dir / "FORCE_R151_summary.md").write_text(summary, encoding="utf-8")

    pack = root / f"{GATE}_pack.zip"
    zip_dir(out_dir, pack)
    zip_ok = zip_integrity(pack)

    flags = {
        "force_architecture_labels_generated": True,
        "residue_holonomy_proxies_generated": True,
        "topology_proxy_labels_generated": True,
        "denominator_classes_preserved": True,
        "support_ecology_preserved": True,
        "mass_functional_schema_generated": True,
        "quantum_structured_null_gate_queued": True,
        "no_empirical_mass_data_loaded": True,
        "no_mass_matching_performed": True,
        "no_parameter_fit_performed": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "SM_sector_mapping_claimed": False,
        "physical_mass_spectrum_claimed": False,
        "true_GR_PDE_mass_dynamics_closed": False,
    }

    print("=== COPY/PASTE R151 RESULT ===")
    print("R151 COMPLETE")
    print(f"VERDICT: {VERDICT}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    print(f"candidate_freeze_hash: {candidate_freeze_hash}")
    for k, v in flags.items():
        print(f"{k}: {v}")
    print(f"selected_seed: {SELECTED_SEED}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("MODE_FORCE_ARCHITECTURE_PREVIEW:")
    preview_cols = ["rho", "m", "N", "denominator_class", "residue_mod_N", "holonomy_proxy_label", "topology_proxy_label", "force_arch_role_proxy", "occupancy_vector", "support_ecology", "G_force_shape_topology_candidate"]
    preview = [{k: r[k] for k in preview_cols} for r in rows]
    print(table_text(preview))
    print("DENOMINATOR_FORCE_ROLLUP:")
    print(table_text(rollup))
    print("MASS_FUNCTIONAL_SCHEMA:")
    print(table_text(MASS_FUNCTIONAL_SCHEMA))
    print("CLAIM_BOUNDARY:")
    for row in CLAIM_BOUNDARY:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print("NEXT_GATE_PLAN:")
    print(table_text(NEXT_GATE_PLAN))
    print(f"PACK: {pack}")
    print(f"SUMMARY: {out_dir / 'FORCE_R151_summary.md'}")
    print("NEXT: FORCE_R152_quantum_structured_null_upgrade_gate")
    print("=== END COPY/PASTE R151 RESULT ===")


if __name__ == "__main__":
    main()
