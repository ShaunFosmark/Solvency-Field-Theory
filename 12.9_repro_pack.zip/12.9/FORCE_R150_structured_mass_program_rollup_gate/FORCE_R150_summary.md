# FORCE_R150_structured_mass_program_rollup_gate Summary

VERDICT: STRUCTURED MASS PROGRAM ROLLUP PASS / SHAPE STRUCTURE HELPS, NULL RISK REMAINS, FORCE-ARCHITECTURE MERGE NEXT
FREEZE_ID: SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM
Generated: 2026-06-08T12:58:17

## Selected seed
{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}

## Canonical species formula
Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}

## Freeze hash
`05a9901683a7b1eb359d29258b228d979694c42412ac7661ff31005879af0f4b`

## Program rollup

gate | result | main_result                                                                                                             | boundary                                                             
-----+--------+-------------------------------------------------------------------------------------------------------------------------+----------------------------------------------------------------------
R146 | PASS   | Bridge-screen rollup froze hierarchy-scale candidates and downgraded pairwise hits after R145 null risk.                | No physical spectrum, no particle mapping, no final mass law.        
R147 | PASS   | Generated (m,N), denominator class, slot occupancy, eccentricity, entropy-deficit, and support-ecology features.        | Feature generation only; no mass table loaded.                       
R148 | PASS   | Structured candidates produced hits and upgraded null tests, but strong null-unusual signal did not close.              | Null risk remains; no final law selected.                            
R149 | PASS   | Shape-factor ablation localized useful structure: slot-fill and denominator-class factors are most informative screens. | Shape evidence remains diagnostic; force/quantum-number merge queued.

## Structure evidence ledger

evidence_item                | status                         | what_survives                                                                                      | what_fails_or_remains_open                                                                       
-----------------------------+--------------------------------+----------------------------------------------------------------------------------------------------+--------------------------------------------------------------------------------------------------
one_dimensional_Frho_limit   | CONFIRMED_LIMIT                | F(rho) can generate hierarchy-scale mass-amplitude screens.                                        | One-dimensional monotonic curves are too easy for null models to mimic internally.               
shape_tensor_features        | GENERATED                      | (m,N), slot occupancy, eccentricity, entropy-deficit, and ecology labels exist for all nine modes. | These are feature screens, not physical quantum-number assignments.                              
slot_fill_inverse            | STRONGEST_CURRENT_SHAPE_SCREEN | R149 found the strongest shape-shuffle signal in slot-fill inverse on raw-feedback controls.       | Raw-feedback range still fails the hierarchy; this proves structure matters, not a full mass law.
denominator_class_root       | IMPORTANT_NEAR_SIGNAL          | N-class/root factors improved structured candidates and approached shuffle-null significance.      | Denominator class alone is not a final physical sector split.                                    
eccentricity_entropy_ecology | DIAGNOSTIC_SUPPORT             | These factors change hit structure and support a richer mass-functional schema.                    | They are not isolated winners yet and need force/field derivation.                               

## R149 signal ledger

candidate                                      | tier                   | dynamic_range | hits_5pct | same_sector_hits | lepton_hits | p_hits_shuffle | interpretation                                                                                           
-----------------------------------------------+------------------------+---------------+-----------+------------------+-------------+----------------+----------------------------------------------------------------------------------------------------------
raw_feedback_control__G_slot_fill_inverse      | shape_ablation_control | 17999.8       | 20        | 7                | 0           | 0.032          | Strongest shape-factor signal, but on raw range-failing baseline; structure matters, mass law not closed.
R137_6pi_exponent__G_denominator_class_root    | bridge_plus_shape      | 239913        | 17        | 11               | 2           | 0.060          | Best bridge-plus-denominator-class near-signal; close but not strict significance.                       
raw_feedback_control__G_denominator_class_root | shape_ablation_control | 12727.8       | 21        | 9                | 3           | 0.052          | Denominator-class structure is informative, but the dynamic range remains inadequate.                    
R139_boundary_area_rho2__G_eccentricity_linear | bridge_plus_shape      | 287996        | 15        | 9                | 5           | 0.200          | Many lepton/same-sector screens, but not unusual against shape-shuffle nulls.                            

## Claim boundary

status           | claim                                                                                  | reason                                                                                               
-----------------+----------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------
YES_SCREEN       | R150 freezes the structured mass-program status after R147-R149.                       | It preserves feature-generation and ablation results without loading new masses or tuning candidates.
YES_SCREEN       | Structured features help relative to a featureless one-dimensional F(rho) program.     | R149 localized informative slot-fill and denominator-class factors.                                  
NO               | R150 proves a physical mass spectrum or Standard Model mapping.                        | No rho-to-particle identities, no sector assignment, and null risk remains.                          
NO               | R150 selects a final shape factor or mass law.                                         | Shape factors remain diagnostic screens pending force-architecture and field-equation derivation.    
YES_NEXT_PROGRAM | The next gate should merge force/quantum-number architecture into the mass functional. | One-dimensional curves and simple shape factors do not yet provide enough specificity.               

## Next gate plan

next_gate   | title                                          | goal                                                                                                                     | must_not_do                                                     
------------+------------------------------------------------+--------------------------------------------------------------------------------------------------------------------------+-----------------------------------------------------------------
FORCE_R151  | Force-Architecture / Quantum-Number Merge Gate | Bring V12.4-style holonomy/topology/charge-color-generation proxy labels into the mass functional without mass fitting.  | Do not map rho modes to particles or choose labels by hit count.
FORCE_R152  | Quantum-Structured Null Upgrade Gate           | After force-architecture labels are frozen, compare structured candidates against nulls that preserve dynamic range a... | Do not use particle identities as inputs.                       
DEEP_GR_PDE | Covariant GR/Lag Field Derivation Deep Gate    | Derive bridge and shape/force factors from field equations.                                                              | Do not treat screens as PDE closure.                            
