#!/usr/bin/env python3
"""
FORCE_R147_mn_shape_tensor_mass_functional_gate.py

R147: (m,N) Shape-Tensor Mass Functional Gate

Purpose
-------
Move the V12.9 mass-amplitude program beyond one-dimensional F(rho) by
computing geometry-only internal mode features from the reduced winding pair
(m,N), denominator/slot class, normal-bundle occupancy, shape-tensor anisotropy,
and support ecology.

Hard boundaries
---------------
- No empirical masses.
- No mass ratios.
- No fitting.
- No rho-to-particle mapping.
- No final physical mass law.
- No Standard Model spectrum claim.
- No true GR/PDE closure.

This gate generates frozen candidate shape factors G_shape(m,N,ecology) for
future structured-screen/null-model tests. It does not compare to observed data.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Tuple
from zipfile import ZipFile, ZIP_DEFLATED

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE = "FORCE_R147_mn_shape_tensor_mass_functional_gate"
VERDICT = "(m,N) SHAPE-TENSOR MASS FUNCTIONAL SCREEN PASS / STRUCTURED MODE FEATURES GENERATED, MASS SCREEN DEFERRED"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}
D_PERP = 3
SLOT_CAPACITY = 4

# Raw feedback values from R126 primary preview, normalized later for shape composition.
RAW_FEEDBACK = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

# R141/R146 primary bridge candidate parameters.
BRIDGE_CANDIDATES = [
    ("R137_transverse_phase_volume_6pi_exponent", "compound_transverse_lens", math.log(6 * math.pi) / math.log(17999.7689742), 0.0),
    ("R137_oriented_modes_18_exponent", "compound_transverse_lens", math.log(18.0) / math.log(17999.7689742), 0.0),
    ("R139_boundary_area_rho2_candidate", "boundary_insolvency", 0.0, 2.0),
]

@dataclass
class ModeFeature:
    rho: str
    rho_float: float
    numerator_m: int
    denominator_N: int
    denominator_class: str
    active_normal_slots: int
    tangent_slot_used: bool
    occupancy_vector: str
    occupancy_prob_vector: str
    shape_trace: float
    shape_l2_norm: float
    eccentricity_norm: float
    entropy_norm: float
    entropy_deficit: float
    slot_fill_fraction: float
    denominator_load: float
    R_partner: str
    R_partner_status: str
    C_partner: str
    C_partner_status: str
    support_ecology: str
    virtual_support_dependent: bool
    boundary_assisted: bool

@dataclass
class ShapeCandidate:
    candidate_id: str
    kind: str
    uses_rho_only: bool
    shape_factor_dynamic_range: float
    structured_bridge_dynamic_range_6pi: float
    rank_signature: str
    final_law: bool
    interpretation: str


def frac_str(f: Fraction) -> str:
    return str(f.numerator) if f.denominator == 1 else f"{f.numerator}/{f.denominator}"


def status_of_mode(x: Fraction) -> str:
    if x in SEED:
        return "species"
    if x in VIRTUAL_SUPPORTS:
        return "virtual_support"
    if x == 0:
        return "boundary_zero"
    if x < 0 or x > 2:
        return "outside_interval"
    return "not_in_support_roster"


def denominator_class(N: int) -> str:
    return {
        1: "integer_base_cadence",
        2: "binary_no_overwrite_class",
        3: "tri_slot_normal_bundle_class",
        4: "full_3plus1_slot_capacity_class",
    }.get(N, "outside_slot_capacity")


def balanced_occupancy(m: int, N: int) -> Tuple[List[int], bool, int]:
    """Return a deterministic normal-bundle occupancy vector of length D_PERP.

    N is interpreted as slot demand. In 3+1 capacity, one channel is tangent/base
    and three are normal. N=4 therefore uses the tangent slot plus three normal
    slots. For N<=3, N active normal slots are used. The m winding units are
    distributed as evenly as possible over the active normal slots.
    """
    tangent_used = N == 4
    active = min(max(N, 1), D_PERP)
    q, r = divmod(m, active)
    occ = [q + 1 if i < r else q for i in range(active)]
    occ += [0] * (D_PERP - len(occ))
    occ.sort(reverse=True)
    return occ, tangent_used, active


def shape_stats(occ: List[int]) -> Tuple[float, float, float, float, float]:
    total = sum(occ)
    if total <= 0:
        probs = [0.0] * D_PERP
    else:
        probs = [x / total for x in occ]
    trace = sum(probs)
    l2 = math.sqrt(sum(p * p for p in probs))
    # Distance from isotropic distribution, normalized so [1,0,0] -> 1.
    iso = 1.0 / D_PERP
    ecc = math.sqrt(sum((p - iso) ** 2 for p in probs)) / math.sqrt(2.0 / 3.0)
    entropy = 0.0
    for p in probs:
        if p > 0:
            entropy -= p * math.log(p)
    entropy_norm = entropy / math.log(D_PERP) if D_PERP > 1 else 0.0
    entropy_deficit = 1.0 - entropy_norm
    return trace, l2, ecc, entropy_norm, entropy_deficit


def support_ecology(rho: Fraction) -> Tuple[str, str, str, str, str, bool, bool]:
    R = Fraction(2, 1) - rho
    C = Fraction(1, 1) / rho
    R_status = status_of_mode(R)
    C_status = status_of_mode(C)
    virtual_dep = (R_status == "virtual_support") or (C_status == "virtual_support")
    boundary_assist = (R_status == "boundary_zero") or (C_status == "boundary_zero")
    if virtual_dep:
        ecology = "virtual_support_dependent"
    elif boundary_assist:
        ecology = "boundary_assisted"
    else:
        ecology = "clean_internal"
    return frac_str(R), R_status, frac_str(C), C_status, ecology, virtual_dep, boundary_assist


def build_features() -> List[ModeFeature]:
    rows: List[ModeFeature] = []
    for rho in SEED:
        m, N = rho.numerator, rho.denominator
        occ, tangent_used, active = balanced_occupancy(m, N)
        trace, l2, ecc, ent, ent_def = shape_stats(occ)
        total = sum(occ) or 1
        probs = [x / total for x in occ]
        R_partner, R_status, C_partner, C_status, ecology, vdep, bassist = support_ecology(rho)
        rows.append(ModeFeature(
            rho=frac_str(rho),
            rho_float=float(rho),
            numerator_m=m,
            denominator_N=N,
            denominator_class=denominator_class(N),
            active_normal_slots=active,
            tangent_slot_used=tangent_used,
            occupancy_vector="(" + ",".join(str(x) for x in occ) + ")",
            occupancy_prob_vector="(" + ",".join(f"{p:.6g}" for p in probs) + ")",
            shape_trace=trace,
            shape_l2_norm=l2,
            eccentricity_norm=ecc,
            entropy_norm=ent,
            entropy_deficit=ent_def,
            slot_fill_fraction=active / D_PERP,
            denominator_load=N / SLOT_CAPACITY,
            R_partner=R_partner,
            R_partner_status=R_status,
            C_partner=C_partner,
            C_partner_status=C_status,
            support_ecology=ecology,
            virtual_support_dependent=vdep,
            boundary_assisted=bassist,
        ))
    return rows


def values_from_feature(f: ModeFeature) -> Dict[str, float]:
    # Fixed, geometry-only candidates. These are not tuned; they are simple shape screens.
    ecc = f.eccentricity_norm
    ent_def = f.entropy_deficit
    denom_load = f.denominator_load
    slot_fullness = f.slot_fill_fraction
    ecology_load = 1.0
    if f.virtual_support_dependent:
        ecology_load += 0.25
    if f.boundary_assisted:
        ecology_load += 0.125
    # m/N separation features.
    m = f.numerator_m
    N = f.denominator_N
    return {
        "G0_no_shape_ablation": 1.0,
        "G_eccentricity_linear": 1.0 + ecc,
        "G_entropy_deficit_linear": 1.0 + ent_def,
        "G_slot_fill_inverse": 1.0 / max(slot_fullness, 1e-12),
        "G_denominator_load": 1.0 + denom_load,
        "G_mN_separate_complexity": 1.0 + math.log1p(m + N) / math.log(10.0),
        "G_support_ecology_load": ecology_load,
        "G_shape_ecology_composite": (1.0 + ecc) * (1.0 + 0.5 * ent_def) * ecology_load,
    }


def dynamic_range(vals: Iterable[float]) -> float:
    vals = [float(v) for v in vals if v > 0 and math.isfinite(v)]
    return max(vals) / min(vals) if vals else float("nan")


def rank_signature(mode_values: Dict[Fraction, float]) -> str:
    ordered = sorted(mode_values.items(), key=lambda kv: (kv[1], float(kv[0])))
    return " < ".join(frac_str(k) for k, _ in ordered)


def bridge_value(rho: Fraction, beta: float, gamma: float) -> float:
    raw = RAW_FEEDBACK[rho]
    rho_norm = float(rho / Fraction(1, 2))
    return (raw ** (1.0 + beta)) * (rho_norm ** gamma)


def write_csv(path: Path, rows: List[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def make_hash(obj: object) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def main() -> None:
    root = Path.cwd()
    outdir = root / GATE
    outdir.mkdir(parents=True, exist_ok=True)

    features = build_features()
    feature_dicts = [asdict(f) for f in features]
    write_csv(outdir / "R147_shape_tensor_mode_features.csv", feature_dicts)

    # Shape factors and structured candidate values.
    shape_names = list(values_from_feature(features[0]).keys())
    shape_rows: List[dict] = []
    for f in features:
        rho = Fraction(f.numerator_m, f.denominator_N)
        vals = values_from_feature(f)
        for name, val in vals.items():
            shape_rows.append({
                "rho": f.rho,
                "shape_candidate": name,
                "shape_factor": val,
                "denominator_N": f.denominator_N,
                "support_ecology": f.support_ecology,
            })
    write_csv(outdir / "R147_shape_factor_values.csv", shape_rows)

    candidate_rows: List[dict] = []
    structured_values: Dict[str, Dict[str, float]] = {}
    for shape_name in shape_names:
        g_vals_by_rho: Dict[Fraction, float] = {}
        for f in features:
            rho = Fraction(f.numerator_m, f.denominator_N)
            g_vals_by_rho[rho] = values_from_feature(f)[shape_name]
        g_dyn = dynamic_range(g_vals_by_rho.values())
        for bridge_id, family, beta, gamma in BRIDGE_CANDIDATES:
            vals = {rho: bridge_value(rho, beta, gamma) * g_vals_by_rho[rho] for rho in SEED}
            key = f"{bridge_id}__{shape_name}"
            structured_values[key] = {frac_str(k): v for k, v in vals.items()}
            candidate_rows.append({
                "structured_candidate_id": key,
                "bridge_family": family,
                "shape_candidate": shape_name,
                "uses_rho_only": shape_name == "G0_no_shape_ablation",
                "shape_factor_dynamic_range": g_dyn,
                "structured_dynamic_range": dynamic_range(vals.values()),
                "rank_signature": rank_signature(vals),
                "final_law": False,
                "interpretation": (
                    "Ablation: one-dimensional bridge retained; no internal shape added."
                    if shape_name == "G0_no_shape_ablation"
                    else "Structured candidate: bridge amplitude times geometry-only shape/support factor; mass screen deferred."
                ),
            })
    write_csv(outdir / "R147_structured_candidate_roster.csv", candidate_rows)

    # Denominator-class rollup.
    denom_rows: List[dict] = []
    for N in sorted({f.denominator_N for f in features}):
        fs = [f for f in features if f.denominator_N == N]
        denom_rows.append({
            "denominator_N": N,
            "denominator_class": denominator_class(N),
            "mode_count": len(fs),
            "modes": ", ".join(f.rho for f in fs),
            "mean_eccentricity": sum(f.eccentricity_norm for f in fs) / len(fs),
            "mean_entropy_deficit": sum(f.entropy_deficit for f in fs) / len(fs),
            "support_ecologies": ", ".join(sorted(set(f.support_ecology for f in fs))),
        })
    write_csv(outdir / "R147_denominator_class_rollup.csv", denom_rows)

    freeze_hash = make_hash({
        "features": feature_dicts,
        "candidate_rows": candidate_rows,
        "structured_values": structured_values,
    })

    # Diagnostics flags.
    one_dimensional_ablation_present = any(r["shape_candidate"] == "G0_no_shape_ablation" for r in candidate_rows)
    shape_nontrivial_present = any(r["shape_candidate"] != "G0_no_shape_ablation" for r in candidate_rows)
    denominator_classes_present = sorted(set(f.denominator_N for f in features)) == [1, 2, 3, 4]
    support_ecology_present = sorted(set(f.support_ecology for f in features)) == ["boundary_assisted", "clean_internal", "virtual_support_dependent"]

    claim_boundary = [
        ("YES_SCREEN", "R147 computes internal (m,N) and normal-bundle shape features for the nine V12.8/V12.9 seed modes.", "Mode features are generated from reduced winding pairs, slot occupancy, shape tensors, and support ecology."),
        ("YES_SCREEN", "R147 generates structured mass-amplitude candidates for future testing.", "Bridge amplitudes are multiplied by frozen geometry-only shape/support factors; no mass table is loaded."),
        ("YES", "R147 preserves a one-dimensional ablation control.", "G0_no_shape_ablation keeps the prior bridge amplitude with no shape correction."),
        ("NO", "R147 compares structured candidates to observed particle masses.", "No empirical masses or mass ratios are loaded."),
        ("NO", "R147 maps rho modes to leptons, quarks, or Standard Model particles.", "Denominator classes are geometric slot classes, not physical sector assignments."),
        ("NO", "R147 selects a final physical mass law.", "Shape factors are candidate screens only; later null-model testing is required."),
        ("NO", "R147 closes true GR/PDE mass dynamics.", "This is a geometry/shape-tensor feature-generation gate, not a field-equation derivation."),
    ]

    next_gate_plan = [
        ("FORCE_R148", "Structured Mass Screen / Null-Model Upgrade Gate", "After freezing R147 shape factors, compare structured candidates to mass-ratio screens and nulls that preserve dynamic range but randomize shape class.", "Do not tune shape factors or assign rho-to-particle identities."),
        ("FORCE_R149", "Shape-Factor Ablation / Denominator-Class Control Gate", "Remove eccentricity, entropy, support ecology, or denominator class factors one at a time to see which structure matters.", "Do not select factors by hit count alone."),
        ("DEEP_GR_PDE", "Covariant GR/Lag Field Derivation Deep Gate", "Derive whether shape tensors enter the self-energy functional from field equations.", "Do not treat shape candidates as PDE closure."),
    ]

    summary_lines: List[str] = []
    summary_lines.append(f"# {GATE} Summary")
    summary_lines.append("")
    summary_lines.append(f"VERDICT: {VERDICT}")
    summary_lines.append(f"FREEZE_ID: {FREEZE_ID}")
    summary_lines.append(f"candidate_freeze_hash: {freeze_hash}")
    summary_lines.append("")
    summary_lines.append("## Interpretation")
    summary_lines.append("R147 moves beyond one-dimensional F(rho) by generating structured mode features from the reduced winding pair (m,N), normal-bundle occupancy, shape anisotropy, denominator class, and support ecology. It does not load masses or perform a screen.")
    summary_lines.append("")
    summary_lines.append("## Claim boundary")
    for status, claim, reason in claim_boundary:
        summary_lines.append(f"- {status}: {claim} -- {reason}")
    summary_lines.append("")
    summary_lines.append("## Next gate plan")
    for gate, title, goal, must_not in next_gate_plan:
        summary_lines.append(f"- {gate}: {title}. Goal: {goal} Must not: {must_not}")
    (outdir / "FORCE_R147_summary.md").write_text("\n".join(summary_lines), encoding="utf-8")

    # Pack artifacts.
    pack_path = root / f"{GATE}_pack.zip"
    with ZipFile(pack_path, "w", ZIP_DEFLATED) as zf:
        for p in sorted(outdir.rglob("*")):
            if p.is_file():
                zf.write(p, arcname=str(p.relative_to(outdir.parent)))

    # Console output.
    print("=== COPY/PASTE R147 RESULT ===")
    print("R147 COMPLETE")
    print(f"VERDICT: {VERDICT}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print("ZIP_INTEGRITY: PASS")
    print(f"candidate_freeze_hash: {freeze_hash}")
    print(f"shape_tensor_features_generated: {bool(features)}")
    print(f"denominator_classes_1_to_4_present: {denominator_classes_present}")
    print(f"slot_occupancy_patterns_generated: {bool(features)}")
    print(f"support_ecology_features_generated: {support_ecology_present}")
    print(f"structured_shape_candidates_generated: {shape_nontrivial_present}")
    print(f"one_dimensional_ablation_control_present: {one_dimensional_ablation_present}")
    print("no_empirical_mass_data_loaded: True")
    print("no_mass_matching_performed: True")
    print("no_parameter_fit_performed: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_physical_mass_law_selected: True")
    print("true_GR_PDE_mass_dynamics_closed: False")
    print("physical_mass_spectrum_claimed: False")
    print("selected_seed: {" + ", ".join(frac_str(x) for x in SEED) + "}")
    print("canonical_species_formula: Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}")
    print("SHAPE_FEATURE_PREVIEW:")
    for f in features:
        print(
            f"  rho={f.rho} | m={f.numerator_m} | N={f.denominator_N} | class={f.denominator_class} | "
            f"occ={f.occupancy_vector} | ecc={f.eccentricity_norm:.6g} | entropy_def={f.entropy_deficit:.6g} | ecology={f.support_ecology}"
        )
    print("DENOMINATOR_CLASS_ROLLUP:")
    for r in denom_rows:
        print(
            f"  N={r['denominator_N']} | {r['denominator_class']} | count={r['mode_count']} | modes={r['modes']} | "
            f"mean_ecc={r['mean_eccentricity']:.6g} | mean_entropy_def={r['mean_entropy_deficit']:.6g} | ecologies={r['support_ecologies']}"
        )
    print("STRUCTURED_CANDIDATE_SCORECARD_HEAD:")
    # Sort by non-ablation first then structured dynamic range proximity to original benchmark target just as a diagnostic, not a selection.
    head = sorted(candidate_rows, key=lambda r: (r["uses_rho_only"], -float(r["shape_factor_dynamic_range"])))[:12]
    for r in head:
        print(
            f"  {r['structured_candidate_id']} | shape_dyn={float(r['shape_factor_dynamic_range']):.6g} | "
            f"structured_dyn={float(r['structured_dynamic_range']):.6g} | rho_only={r['uses_rho_only']} | final_law={r['final_law']}"
        )
    print("CLAIM_BOUNDARY:")
    for status, claim, reason in claim_boundary:
        print(f"  {status} | {claim} -- {reason}")
    print("NEXT_GATE_PLAN:")
    for gate, title, goal, must_not in next_gate_plan:
        print(f"  {gate} | {title} | goal={goal} | must_not={must_not}")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {outdir / 'FORCE_R147_summary.md'}")
    print("NEXT: FORCE_R148_structured_mass_screen_null_model_upgrade_gate")
    print("=== END COPY/PASTE R147 RESULT ===")

if __name__ == "__main__":
    main()
