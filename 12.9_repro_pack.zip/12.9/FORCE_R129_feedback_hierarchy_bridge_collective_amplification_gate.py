#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R129_feedback_hierarchy_bridge_collective_amplification_gate.py

SFT V12.9 / R129
Feedback Hierarchy Bridge / Collective Amplification Gate

Purpose
-------
R127 showed that the self-consistent radius/depth feedback route can reach a
~18,000x dynamic range and produce sharp blind ratio contacts, but still falls
short of the charged-fermion screening hierarchy by ~18.8x.

R129 asks a narrow mechanical question:

    Is the remaining hierarchy gap compatible with an internally derived
    collective/stator amplification, without fitting to particle masses?

Important correction tested here
--------------------------------
A *global* multiplier cannot fix a mass-ratio/dynamic-range shortfall.  If all
modes are multiplied by the same collective vacuum/stator factor, every pairwise
ratio is unchanged. Therefore R129 separates:

    1. global collective factors: useful for absolute scale, but fail as a
       hierarchy/dynamic-range bridge;
    2. differential collective susceptibility factors: mode-dependent factors
       derived from the feedback geometry and fixed SFT structural exponents.

Guardrails
----------
- No empirical particle mass table is loaded.
- No pairwise particle matching is performed.
- No rho-to-particle mapping is performed.
- No final physical mass law is selected.
- Target dynamic range is used only as the frozen R127 hierarchy benchmark,
  not to fit a candidate. A post-hoc required exponent is reported as a control
  and explicitly rejected as a law.

Outputs
-------
Directory:
    FORCE_R129_feedback_hierarchy_bridge_collective_amplification_gate/

Files:
    FORCE_R129_summary.md
    FORCE_R129_verdict.json
    FORCE_R129_base_feedback.csv
    FORCE_R129_global_collective_factors.csv
    FORCE_R129_differential_collective_candidates.csv
    FORCE_R129_posthoc_exponent_control.csv
    FORCE_R129_claim_boundary.csv
    FORCE_R129_next_gate_plan.csv
    artifact_manifest.csv

ZIP:
    FORCE_R129_feedback_hierarchy_bridge_collective_amplification_gate_pack.zip
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import sys
import textwrap
import zipfile
from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "R129"
GATE_TITLE = "Feedback Hierarchy Bridge / Collective Amplification Gate"
ROOT = Path.cwd()
OUTDIR = ROOT / "FORCE_R129_feedback_hierarchy_bridge_collective_amplification_gate"
PACK = ROOT / "FORCE_R129_feedback_hierarchy_bridge_collective_amplification_gate_pack.zip"

SEED = [Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1), Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)]
VIRTUAL_SUPPORTS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

# R126 primary preview values for the converged feedback functional.  These were
# produced without empirical masses and then screened blind in R127.
R126_PRIMARY_F = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

# R127 monotonic full-spectrum benchmark, copied as a frozen scalar benchmark.
# This is not used to tune any candidate.  It is used only to report whether
# a candidate bridges the already-reported R127 dynamic-range gap.
TARGET_CHARGED_FERMION_DYN_R127 = 338083.0

D_PERP = 3
N_SLOT = 4
N_SEED = 9
N_VIRTUAL = 3
N_SUPPORT = N_SEED + N_VIRTUAL
N_ORIENTED_SEED = 2 * N_SEED
N_CHARGED_SPECIES_WITH_COLOR = 3 + 6 * 3  # charged leptons + colored quark states
N_ORIENTED_CHARGED_WITH_COLOR = 2 * N_CHARGED_SPECIES_WITH_COLOR


def rho_label(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dynamic_range(values: Iterable[float]) -> float:
    vals = [float(v) for v in values if float(v) > 0 and math.isfinite(float(v))]
    return max(vals) / min(vals)


def normalize_min(values: Dict[Fraction, float]) -> Dict[Fraction, float]:
    mn = min(values.values())
    return {k: v / mn for k, v in values.items()}


def power_candidate(base_norm: Dict[Fraction, float], beta: float, n_eff: float = 0.0, style: str = "pure_power") -> Dict[Fraction, float]:
    """Return a mode-dependent collective susceptibility factor.

    style='pure_power': C = base_norm**beta
    style='one_plus_N_power': C = 1 + n_eff * (base_norm**beta - 1)

    Dynamic-range behavior is what matters here; a constant global part cancels.
    """
    out = {}
    for r, x in base_norm.items():
        if style == "pure_power":
            out[r] = x ** beta
        elif style == "one_plus_N_power":
            out[r] = 1.0 + n_eff * (x ** beta - 1.0)
        else:
            raise ValueError(style)
    return out


def multiplied(base: Dict[Fraction, float], factor: Dict[Fraction, float]) -> Dict[Fraction, float]:
    return {k: base[k] * factor[k] for k in base}


def rank_signature(values: Dict[Fraction, float]) -> str:
    return " > ".join(rho_label(k) for k, _ in sorted(values.items(), key=lambda kv: kv[1], reverse=True))


def support_graph_degree() -> Dict[Fraction, int]:
    """Small structural support graph using R(rho)=2-rho and C(rho)=1/rho.

    The degree is intentionally crude and geometry-internal. It is not tuned to
    masses. It asks how many direct closure links a seed mode has inside
    seed+virtual support channels.
    """
    domain = set(SEED + VIRTUAL_SUPPORTS)
    deg: Dict[Fraction, int] = {}
    for r in SEED:
        links = set()
        rr = Fraction(2, 1) - r
        cc = Fraction(1, 1) / r
        if rr in domain:
            links.add(rr)
        if cc in domain:
            links.add(cc)
        # reverse incoming R/C links
        for s in domain:
            if Fraction(2, 1) - s == r:
                links.add(s)
            if Fraction(1, 1) / s == r:
                links.add(s)
        deg[r] = len(links)
    return deg


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)

    base_dyn = dynamic_range(R126_PRIMARY_F.values())
    missing_factor = TARGET_CHARGED_FERMION_DYN_R127 / base_dyn
    base_min_rho = min(R126_PRIMARY_F, key=lambda k: R126_PRIMARY_F[k])
    base_max_rho = max(R126_PRIMARY_F, key=lambda k: R126_PRIMARY_F[k])
    base_norm = normalize_min(R126_PRIMARY_F)

    # Base feedback table.
    base_rows = []
    for r in SEED:
        base_rows.append({
            "rho": rho_label(r),
            "rho_float": float(r),
            "R126_primary_feedback_F": R126_PRIMARY_F[r],
            "normalized_to_min": base_norm[r],
            "is_min": r == base_min_rho,
            "is_max": r == base_max_rho,
        })

    # Global factors: these cannot alter dynamic range.
    global_factor_specs = [
        ("N_seed_modes", N_SEED, "number of V12.8 selected seed modes"),
        ("N_oriented_seed_modes", N_ORIENTED_SEED, "seed modes times orientation/anti-orientation"),
        ("N_support_channels_seed_plus_virtual", N_SUPPORT, "seed plus virtual support channels"),
        ("N_charged_species_with_color", N_CHARGED_SPECIES_WITH_COLOR, "3 charged leptons plus 6 quarks times 3 colors"),
        ("N_oriented_charged_species_with_color", N_ORIENTED_CHARGED_WITH_COLOR, "charged color-expanded states times orientation"),
        ("missing_factor_control_from_R127", missing_factor, "post-screen hierarchy shortfall; reported as control only"),
    ]
    global_rows = []
    for name, factor, interp in global_factor_specs:
        global_rows.append({
            "factor_id": name,
            "factor_value": factor,
            "base_dynamic_range": base_dyn,
            "post_global_factor_dynamic_range": base_dyn,
            "changes_pairwise_ratios": False,
            "hierarchy_bridge_pass": False,
            "interpretation": interp + "; global factors cannot change ratios/dynamic range.",
        })

    # Differential candidates: fixed internal exponents and support-graph effects.
    candidates: List[Tuple[str, str, Dict[Fraction, float], bool, str]] = []

    # Pure geometry/dimensional exponents.
    fixed_betas = [
        ("binary_square_root_beta_1_over_2", 1/2, "binary/no-overwrite square-root susceptibility"),
        ("normal_volume_beta_1_over_3", 1/3, "three-normal-volume susceptibility"),
        ("slot_capacity_beta_1_over_4", 1/4, "four-slot root susceptibility"),
        ("base_tangent_plus_normals_beta_1_over_4", 1/4, "same as N_slot=4 root"),
        ("normal_pair_beta_2_over_3", 2/3, "two-of-three normal-pair susceptibility"),
        ("weak_beta_1_over_6", 1/6, "control: shallow fractional susceptibility"),
    ]
    for cid, beta, origin in fixed_betas:
        fac = power_candidate(base_norm, beta, style="pure_power")
        candidates.append((cid, origin, fac, False, f"fixed_beta={beta}"))

    # Participant-weighted versions.  These are still not fitted to masses; n_eff
    # is chosen from internal counts.  For large dynamic ranges these mostly
    # approach the pure-power dynamic range, but the table shows the effect.
    for n_id, n_eff in [
        ("N_seed", N_SEED),
        ("N_oriented_seed", N_ORIENTED_SEED),
        ("N_support", N_SUPPORT),
        ("N_charged_color", N_CHARGED_SPECIES_WITH_COLOR),
    ]:
        for beta in [1/4, 1/3]:
            cid = f"collective_{n_id}_one_plus_power_beta_{str(beta).replace('.', 'p')}"
            fac = power_candidate(base_norm, beta, n_eff=float(n_eff), style="one_plus_N_power")
            candidates.append((cid, f"mode susceptibility weighted by {n_id}; beta fixed internally", fac, False, f"n_eff={n_eff}; fixed_beta={beta}"))

    # Support graph degree candidates. These are differential but likely too mild.
    deg = support_graph_degree()
    deg_min = min(deg.values())
    deg_fac = {r: float(deg[r] + 1) / float(deg_min + 1) for r in SEED}
    candidates.append(("support_graph_degree_factor", "direct R/C support graph degree inside seed+virtual domain", deg_fac, False, "degree+1 normalized"))
    deg_lens_fac = {r: deg_fac[r] * (base_norm[r] ** 0.25) for r in SEED}
    candidates.append(("support_graph_degree_times_slot_root", "support degree times N_slot root susceptibility", deg_lens_fac, False, "degree factor * beta=1/4"))

    # Forbidden/posthoc control: the beta that would exactly bridge the dynamic range.
    # This is computed for audit only and must not be selected as a law.
    posthoc_required_beta = math.log(missing_factor) / math.log(base_dyn)
    posthoc_fac = power_candidate(base_norm, posthoc_required_beta, style="pure_power")
    candidates.append(("POSTHOC_REQUIRED_BETA_CONTROL_NOT_A_LAW", "computed from target shortfall after R127; forbidden as derivation", posthoc_fac, True, f"required_beta={posthoc_required_beta}"))

    candidate_rows = []
    strong_candidates_present = False
    bracket_candidates_present = False
    closest_gap = None
    closest_id = None

    for cid, origin, fac, posthoc, note in candidates:
        F2 = multiplied(R126_PRIMARY_F, fac)
        fac_dyn = dynamic_range(fac.values())
        total_dyn = dynamic_range(F2.values())
        ratio_to_target = total_dyn / TARGET_CHARGED_FERMION_DYN_R127
        shortfall = TARGET_CHARGED_FERMION_DYN_R127 / total_dyn if total_dyn > 0 else float("inf")
        overshoot = total_dyn / TARGET_CHARGED_FERMION_DYN_R127 if total_dyn > TARGET_CHARGED_FERMION_DYN_R127 else 1.0
        within_factor_2 = 0.5 <= ratio_to_target <= 2.0
        within_factor_25pct = 0.75 <= ratio_to_target <= 1.25
        if within_factor_2 and not posthoc:
            bracket_candidates_present = True
        if total_dyn >= 100000 and not posthoc:
            strong_candidates_present = True
        gap = abs(math.log(total_dyn / TARGET_CHARGED_FERMION_DYN_R127))
        if closest_gap is None or gap < closest_gap:
            closest_gap = gap
            closest_id = cid
        candidate_rows.append({
            "candidate_id": cid,
            "candidate_origin": origin,
            "note": note,
            "posthoc_control_not_law": posthoc,
            "collective_factor_dynamic_range": fac_dyn,
            "post_bridge_dynamic_range": total_dyn,
            "target_dynamic_range_R127": TARGET_CHARGED_FERMION_DYN_R127,
            "shortfall_if_below_target": shortfall if total_dyn < TARGET_CHARGED_FERMION_DYN_R127 else 1.0,
            "overshoot_if_above_target": overshoot,
            "within_factor_2_of_target": within_factor_2,
            "within_25pct_of_target": within_factor_25pct,
            "min_rho": rho_label(min(F2, key=lambda k: F2[k])),
            "max_rho": rho_label(max(F2, key=lambda k: F2[k])),
            "rank_signature_high_to_low": rank_signature(F2),
            "selected_as_final_mass_law": False,
        })

    # Posthoc control table.
    posthoc_rows = [{
        "control": "required_power_beta_to_exactly_bridge_R127_dynamic_range",
        "base_dynamic_range": base_dyn,
        "target_dynamic_range_R127": TARGET_CHARGED_FERMION_DYN_R127,
        "missing_differential_factor": missing_factor,
        "required_beta": posthoc_required_beta,
        "status": "FORBIDDEN_POSTHOC_CONTROL_NOT_A_DERIVATION",
        "reason": "computed using the external target dynamic range; may guide future derivation but cannot be selected as a law",
    }]

    # Claim boundary.
    claim_rows = [
        {"claim": "R129 tests whether a global collective multiplier can bridge the R127 hierarchy shortfall.", "status": "YES_SCREEN", "reason": "Global factors are explicitly audited and shown not to change pairwise ratios or dynamic range."},
        {"claim": "A constant vacuum/stator factor alone closes the hierarchy gap.", "status": "NO", "reason": "Constant factors multiply all modes equally and therefore cannot change mass ratios/dynamic range."},
        {"claim": "R129 generates differential collective susceptibility candidates from internal structure.", "status": "YES_SCREEN", "reason": "Fixed exponents from binary/slot/normal dimension plus support graph degree are tested without mass fitting."},
        {"claim": "R129 derives a final collective amplification mass law.", "status": "NO", "reason": "Candidates are bridge screens only; the posthoc required exponent is reported and rejected as a law."},
        {"claim": "R129 compares pairwise F(rho) values to observed particle masses.", "status": "NO", "reason": "No particle mass table or pairwise mass ratios are loaded; only the R127 target dynamic-range benchmark is reported."},
        {"claim": "R129 maps rho modes to leptons or quarks.", "status": "NO", "reason": "No rho-to-particle assignment is performed."},
        {"claim": "R129 proves a collective lag/stator field from GR/PDE dynamics.", "status": "NO", "reason": "Collective factors are mechanical screens, not a solved self-consistent field theorem."},
        {"claim": "R129 promotes virtual supports to species.", "status": "NO", "reason": "V12.8 species projection remains locked; virtual channels are not promoted by amplification."},
    ]

    next_rows = [
        {"next_gate": "FORCE_R130", "title": "Standalone vs Collective Closure Adequacy Gate", "goal": "Classify modes by whether isolated feedback is sufficient or whether collective/stator support is mechanically required.", "must_not_do": "Do not map standalone/collective classes to particles by hand."},
        {"next_gate": "FORCE_R128", "title": "GR/Lag Field Derivation Gate", "goal": "Try to derive the collective susceptibility from a field/lag equation rather than from screening candidates.", "must_not_do": "Do not select beta or participant count by mass agreement."},
        {"next_gate": "FORCE_R131", "title": "Collective Bridge Blind Mass Screen", "goal": "Only after R130/R128 narrows one candidate, freeze it and run a blind mass-ratio screen.", "must_not_do": "Do not retune the bridge after seeing masses."},
    ]

    # Verdict logic.
    global_multiplier_dynamic_range_bridge_pass = False
    differential_collective_candidates_generated = True
    natural_exponent_candidates_bracket_target = bracket_candidates_present
    posthoc_required_exponent_reported_not_used = True
    no_empirical_mass_data_loaded = True
    no_mass_matching_performed = True
    no_parameter_fit_performed = True
    no_mode_particle_mapping_performed = True
    no_final_physical_mass_law_selected = True
    physical_mass_spectrum_claimed = False
    true_GR_PDE_collective_field_closed = False

    if natural_exponent_candidates_bracket_target:
        verdict = "FEEDBACK HIERARCHY BRIDGE SCREEN PASS / GLOBAL MULTIPLIER FAILS, DIFFERENTIAL COLLECTIVE CANDIDATES BRACKET TARGET, FINAL LAW OPEN"
    else:
        verdict = "FEEDBACK HIERARCHY BRIDGE SCREEN PASS / GLOBAL MULTIPLIER FAILS, DIFFERENTIAL COLLECTIVE GAP REPORTED, FINAL LAW OPEN"

    # Write files.
    write_csv(OUTDIR / "FORCE_R129_base_feedback.csv", base_rows)
    write_csv(OUTDIR / "FORCE_R129_global_collective_factors.csv", global_rows)
    write_csv(OUTDIR / "FORCE_R129_differential_collective_candidates.csv", candidate_rows)
    write_csv(OUTDIR / "FORCE_R129_posthoc_exponent_control.csv", posthoc_rows)
    write_csv(OUTDIR / "FORCE_R129_claim_boundary.csv", claim_rows)
    write_csv(OUTDIR / "FORCE_R129_next_gate_plan.csv", next_rows)

    # Sort top candidates by closeness to target, excluding posthoc.
    nonpost = [r for r in candidate_rows if str(r["posthoc_control_not_law"]) == "False"]
    top_by_closeness = sorted(nonpost, key=lambda r: abs(math.log(float(r["post_bridge_dynamic_range"]) / TARGET_CHARGED_FERMION_DYN_R127)))[:10]
    top_by_range = sorted(nonpost, key=lambda r: float(r["post_bridge_dynamic_range"]), reverse=True)[:10]

    summary = f"""
# {GATE_ID}: {GATE_TITLE}

**Freeze ID:** `{FREEZE_ID}`

## Verdict

`{verdict}`

## Core correction

A global collective/stator multiplier cannot solve a dynamic-range or mass-ratio shortfall:

```text
F_i -> A * F_i
F_j -> A * F_j
(F_i/F_j) unchanged
```

Therefore R129 separates global amplification from differential collective susceptibility.

## Base feedback hierarchy

- R126 primary feedback dynamic range: `{base_dyn:.12g}`
- R127 charged-fermion screening target range: `{TARGET_CHARGED_FERMION_DYN_R127:.12g}`
- Remaining differential hierarchy factor: `{missing_factor:.12g}`
- Base min rho: `{rho_label(base_min_rho)}`
- Base max rho: `{rho_label(base_max_rho)}`

## Best non-posthoc bridge candidates by closeness to target

| candidate | post-bridge dyn | shortfall/overshoot | within x2 | note |
|---|---:|---:|---:|---|
""".lstrip()

    for r in top_by_closeness:
        dyn = float(r["post_bridge_dynamic_range"])
        if dyn < TARGET_CHARGED_FERMION_DYN_R127:
            gap_s = f"shortfall {TARGET_CHARGED_FERMION_DYN_R127/dyn:.6g}x"
        else:
            gap_s = f"overshoot {dyn/TARGET_CHARGED_FERMION_DYN_R127:.6g}x"
        summary += f"| `{r['candidate_id']}` | {dyn:.6g} | {gap_s} | {r['within_factor_2_of_target']} | {r['note']} |\n"

    summary += """

## Strongest dynamic-range candidates

| candidate | post-bridge dyn | min rho | max rho | note |
|---|---:|---:|---:|---|
"""
    for r in top_by_range:
        summary += f"| `{r['candidate_id']}` | {float(r['post_bridge_dynamic_range']):.6g} | `{r['min_rho']}` | `{r['max_rho']}` | {r['note']} |\n"

    summary += f"""

## Posthoc control

The exponent that would exactly bridge the R127 dynamic-range shortfall is:

```text
beta_required = {posthoc_required_beta:.12g}
```

This is **not** selected as a law, because it is computed using the external target range. It is only a diagnostic target for future derivation.

## Claim boundary

- Differential collective screening: yes.
- Global multiplier as hierarchy bridge: no.
- Final physical mass law: no.
- Pairwise mass comparison: no.
- Particle mapping: no.
- GR/PDE collective-field derivation: no.

## Next

`FORCE_R130_standalone_vs_collective_closure_adequacy_gate`
"""

    (OUTDIR / "FORCE_R129_summary.md").write_text(summary, encoding="utf-8")

    verdict_payload = {
        "gate": GATE_ID,
        "title": GATE_TITLE,
        "verdict": verdict,
        "freeze_id": FREEZE_ID,
        "base_feedback_dynamic_range": base_dyn,
        "target_dynamic_range_R127": TARGET_CHARGED_FERMION_DYN_R127,
        "missing_differential_factor": missing_factor,
        "global_multiplier_dynamic_range_bridge_pass": global_multiplier_dynamic_range_bridge_pass,
        "differential_collective_candidates_generated": differential_collective_candidates_generated,
        "natural_exponent_candidates_bracket_target": natural_exponent_candidates_bracket_target,
        "strong_feedback_bridge_candidates_present": strong_candidates_present,
        "posthoc_required_exponent_reported_not_used": posthoc_required_exponent_reported_not_used,
        "posthoc_required_beta": posthoc_required_beta,
        "closest_nonposthoc_candidate": top_by_closeness[0]["candidate_id"] if top_by_closeness else None,
        "closest_nonposthoc_dynamic_range": float(top_by_closeness[0]["post_bridge_dynamic_range"]) if top_by_closeness else None,
        "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
        "no_mass_matching_performed": no_mass_matching_performed,
        "no_parameter_fit_performed": no_parameter_fit_performed,
        "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
        "no_final_physical_mass_law_selected": no_final_physical_mass_law_selected,
        "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
        "true_GR_PDE_collective_field_closed": true_GR_PDE_collective_field_closed,
        "selected_seed": "{" + ", ".join(rho_label(r) for r in SEED) + "}",
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
    }
    (OUTDIR / "FORCE_R129_verdict.json").write_text(json.dumps(verdict_payload, indent=2), encoding="utf-8")

    # Artifact manifest before zipping.
    manifest_rows = []
    for path in sorted(OUTDIR.glob("*")):
        if path.is_file():
            manifest_rows.append({
                "file": path.name,
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    write_csv(OUTDIR / "artifact_manifest.csv", manifest_rows)

    if PACK.exists():
        PACK.unlink()
    with zipfile.ZipFile(PACK, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(OUTDIR.glob("*")):
            if path.is_file():
                zf.write(path, arcname=f"{OUTDIR.name}/{path.name}")
    zip_integrity = "PASS"
    try:
        with zipfile.ZipFile(PACK, "r") as zf:
            bad = zf.testzip()
            if bad is not None:
                zip_integrity = f"FAIL:{bad}"
    except Exception as e:
        zip_integrity = f"FAIL:{e}"

    # Console output.
    print("=== COPY/PASTE R129 RESULT ===")
    print("R129 COMPLETE")
    print(f"VERDICT: {verdict}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {zip_integrity}")
    for k in [
        "global_multiplier_dynamic_range_bridge_pass",
        "differential_collective_candidates_generated",
        "natural_exponent_candidates_bracket_target",
        "strong_feedback_bridge_candidates_present",
        "posthoc_required_exponent_reported_not_used",
        "no_empirical_mass_data_loaded",
        "no_mass_matching_performed",
        "no_parameter_fit_performed",
        "no_mode_particle_mapping_performed",
        "no_final_physical_mass_law_selected",
        "physical_mass_spectrum_claimed",
        "true_GR_PDE_collective_field_closed",
    ]:
        print(f"{k}: {verdict_payload[k]}")
    print(f"selected_seed: {verdict_payload['selected_seed']}")
    print(f"base_feedback_dynamic_range: {base_dyn:.12g}")
    print(f"target_dynamic_range_R127: {TARGET_CHARGED_FERMION_DYN_R127:.12g}")
    print(f"missing_differential_factor: {missing_factor:.12g}")
    print(f"posthoc_required_beta_CONTROL_NOT_LAW: {posthoc_required_beta:.12g}")
    print("GLOBAL_FACTOR_AUDIT:")
    for row in global_rows:
        print(f"  {row['factor_id']} | factor={float(row['factor_value']):.6g} | post_dyn={float(row['post_global_factor_dynamic_range']):.6g} | bridge={row['hierarchy_bridge_pass']}")
    print("TOP_BRIDGE_CANDIDATES:")
    for r in top_by_closeness[:8]:
        dyn = float(r["post_bridge_dynamic_range"])
        if dyn < TARGET_CHARGED_FERMION_DYN_R127:
            gap_s = f"shortfall={TARGET_CHARGED_FERMION_DYN_R127/dyn:.6g}"
        else:
            gap_s = f"overshoot={dyn/TARGET_CHARGED_FERMION_DYN_R127:.6g}"
        print(f"  {r['candidate_id']} | dyn={dyn:.6g} | {gap_s} | within_x2={r['within_factor_2_of_target']} | posthoc={r['posthoc_control_not_law']}")
    print("CLAIM_BOUNDARY:")
    for r in claim_rows:
        print(f"  {r['status']} | {r['claim']} -- {r['reason']}")
    print(f"PACK: {PACK}")
    print(f"SUMMARY: {OUTDIR / 'FORCE_R129_summary.md'}")
    print("NEXT: FORCE_R130_standalone_vs_collective_closure_adequacy_gate")
    print("=== END COPY/PASTE R129 RESULT ===")


if __name__ == "__main__":
    main()
