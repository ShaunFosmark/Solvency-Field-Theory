from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from textwrap import dedent

try:
    import pandas as pd
except Exception as e:
    raise SystemExit(f"R143 requires pandas. Import failed: {e}")

try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception:
    HAS_MPL = False

ROOT = Path.cwd()
OUT = ROOT / "FORCE_R143_bridge_screen_interpretation_gate"
PACK = ROOT / "FORCE_R143_bridge_screen_interpretation_gate_pack.zip"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
SELECTED_SEED = "{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}"
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
(OUT / "plots").mkdir(exist_ok=True)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(df, name):
    p = OUT / name
    df.to_csv(p, index=False)
    return p

# -----------------------------------------------------------------------------
# Frozen R142 interpretation inputs only.
# No new mass table is loaded in R143. These values are copied from the R142
# copy/paste result and are interpreted/classified here.
# -----------------------------------------------------------------------------
raw_feedback_dynamic_range = 17999.7689742
frozen_R127_dynamic_benchmark = 338083.0
missing_factor = 18.782629959561806

candidate_dynamic_rows = [
    dict(candidate_id="R137_transverse_phase_volume_6pi_exponent", tier="primary", family="compound_transverse_lens", dynamic_range=339287.6518548214, relation="overshoot", factor=1.003563183759081, within_25pct=True),
    dict(candidate_id="R137_oriented_modes_18_exponent", tier="primary", family="compound_transverse_lens", dynamic_range=323995.84153642174, relation="shortfall", factor=1.0434794421952316, within_25pct=True),
    dict(candidate_id="R139_boundary_area_rho2_candidate", tier="primary", family="boundary_insolvency", dynamic_range=287996.3035879304, relation="shortfall", factor=1.1739143724696357, within_25pct=True),
    dict(candidate_id="R140B_partial_slot_beta_boundary_quarter", tier="secondary", family="partial_hybrid_screen", dynamic_range=294848.32271843025, relation="shortfall", factor=1.1466336212563684, within_25pct=True),
    dict(candidate_id="R140B_partial_slot_beta_boundary_half", tier="secondary", family="partial_hybrid_screen", dynamic_range=416978.4968313632, relation="overshoot", factor=1.2333613249745274, within_25pct=True),
    dict(candidate_id="raw_feedback_control", tier="control", family="raw_feedback", dynamic_range=raw_feedback_dynamic_range, relation="shortfall", factor=missing_factor, within_25pct=False),
]

dynamic_df = pd.DataFrame(candidate_dynamic_rows)

# Top R142 matches as reported. R143 classifies them; it does not recompute them.
match_rows = [
    dict(candidate_id="R140B_partial_slot_beta_boundary_half", tier="secondary", mode_pair="3/4 vs 2/3", F_ratio=2.16384, mass_pair="down_quark vs up_quark", M_ratio=2.16204, err_pct=0.0834072, same_sector=True, lepton_lepton=False, quark_quark=True),
    dict(candidate_id="R137_transverse_phase_volume_6pi_exponent", tier="primary", mode_pair="3/2 vs 3/4", F_ratio=380.024, mass_pair="tau vs down_quark", M_ratio=380.484, err_pct=0.120936, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R140B_partial_slot_beta_boundary_half", tier="secondary", mode_pair="2 vs 5/4", F_ratio=589.001, mass_pair="charm_quark vs up_quark", M_ratio=587.963, err_pct=0.176581, same_sector=True, lepton_lepton=False, quark_quark=True),
    dict(candidate_id="R140B_partial_slot_beta_boundary_half", tier="secondary", mode_pair="1 vs 2/3", F_ratio=11.9943, mass_pair="charm_quark vs muon", M_ratio=12.0199, err_pct=0.212783, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R137_transverse_phase_volume_6pi_exponent", tier="primary", mode_pair="5/4 vs 3/4", F_ratio=49.0674, mass_pair="muon vs up_quark", M_ratio=48.9159, err_pct=0.309776, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R139_boundary_area_rho2_candidate", tier="primary", mode_pair="5/4 vs 1/2", F_ratio=825.471, mass_pair="tau vs up_quark", M_ratio=822.62, err_pct=0.346572, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R137_transverse_phase_volume_6pi_exponent", tier="primary", mode_pair="2 vs 1/2", F_ratio=339288, mass_pair="top_quark vs electron", M_ratio=338083, err_pct=0.356352, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R140B_partial_slot_beta_boundary_half", tier="secondary", mode_pair="5/3 vs 3/4", F_ratio=2494.61, mass_pair="charm_quark vs electron", M_ratio=2485.33, err_pct=0.373372, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R137_oriented_modes_18_exponent", tier="primary", mode_pair="5/3 vs 5/4", F_ratio=45.1824, mass_pair="bottom_quark vs strange_quark", M_ratio=44.9462, err_pct=0.525396, same_sector=True, lepton_lepton=False, quark_quark=True),
    dict(candidate_id="R140B_partial_slot_beta_boundary_half", tier="secondary", mode_pair="4/3 vs 1", F_ratio=19.0025, mass_pair="tau vs strange_quark", M_ratio=19.106, err_pct=0.541599, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R139_boundary_area_rho2_candidate", tier="primary", mode_pair="4/3 vs 1", F_ratio=16.709, mass_pair="tau vs muon", M_ratio=16.817, err_pct=0.642173, same_sector=True, lepton_lepton=True, quark_quark=False),
    dict(candidate_id="R139_boundary_area_rho2_candidate", tier="primary", mode_pair="5/3 vs 3/4", F_ratio=1872.67, mass_pair="top_quark vs strange_quark", M_ratio=1857.63, err_pct=0.809512, same_sector=True, lepton_lepton=False, quark_quark=True),
    dict(candidate_id="R140B_partial_slot_beta_boundary_quarter", tier="secondary", mode_pair="5/3 vs 4/3", F_ratio=22.3982, mass_pair="muon vs down_quark", M_ratio=22.6249, err_pct=1.00199, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R137_oriented_modes_18_exponent", tier="primary", mode_pair="5/4 vs 3/4", F_ratio=48.3805, mass_pair="muon vs up_quark", M_ratio=48.9159, err_pct=1.09457, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R137_transverse_phase_volume_6pi_exponent", tier="primary", mode_pair="2 vs 5/4", F_ratio=594.48, mass_pair="charm_quark vs up_quark", M_ratio=587.963, err_pct=1.10833, same_sector=True, lepton_lepton=False, quark_quark=True),
    dict(candidate_id="R137_oriented_modes_18_exponent", tier="primary", mode_pair="2 vs 5/4", F_ratio=580.886, mass_pair="charm_quark vs up_quark", M_ratio=587.963, err_pct=1.20373, same_sector=True, lepton_lepton=False, quark_quark=True),
    dict(candidate_id="R140B_partial_slot_beta_boundary_quarter", tier="secondary", mode_pair="5/3 vs 5/4", F_ratio=42.5309, mass_pair="strange_quark vs up_quark", M_ratio=43.0556, err_pct=1.21862, same_sector=True, lepton_lepton=False, quark_quark=True),
    dict(candidate_id="R140B_partial_slot_beta_boundary_quarter", tier="secondary", mode_pair="2 vs 4/3", F_ratio=275.801, mass_pair="charm_quark vs down_quark", M_ratio=271.949, err_pct=1.41649, same_sector=True, lepton_lepton=False, quark_quark=True),
    dict(candidate_id="R139_boundary_area_rho2_candidate", tier="primary", mode_pair="3/2 vs 3/4", F_ratio=386.357, mass_pair="tau vs down_quark", M_ratio=380.484, err_pct=1.54357, same_sector=False, lepton_lepton=False, quark_quark=False),
    dict(candidate_id="R140B_partial_slot_beta_boundary_half", tier="secondary", mode_pair="5/3 vs 5/4", F_ratio=45.7024, mass_pair="bottom_quark vs strange_quark", M_ratio=44.9462, err_pct=1.68236, same_sector=True, lepton_lepton=False, quark_quark=True),
]

matches_df = pd.DataFrame(match_rows)

threshold_rows = [
    dict(candidate_id="R137_transverse_phase_volume_6pi_exponent", tier="primary", dynamic_range=339288, best_err_pct=0.120936, hits_1pct=3, hits_5pct=14, same_sector_5pct=6, lepton_5pct=1, quark_5pct=5),
    dict(candidate_id="R139_boundary_area_rho2_candidate", tier="primary", dynamic_range=287996, best_err_pct=0.346572, hits_1pct=3, hits_5pct=13, same_sector_5pct=6, lepton_5pct=1, quark_5pct=5),
    dict(candidate_id="R137_oriented_modes_18_exponent", tier="primary", dynamic_range=323996, best_err_pct=0.525396, hits_1pct=1, hits_5pct=14, same_sector_5pct=4, lepton_5pct=0, quark_5pct=4),
    dict(candidate_id="R140B_partial_slot_beta_boundary_half", tier="secondary", dynamic_range=416978, best_err_pct=0.0834072, hits_1pct=5, hits_5pct=10, same_sector_5pct=5, lepton_5pct=0, quark_5pct=5),
    dict(candidate_id="raw_feedback_control", tier="control", dynamic_range=17999.8, best_err_pct=0.185639, hits_1pct=6, hits_5pct=12, same_sector_5pct=4, lepton_5pct=0, quark_5pct=4),
    dict(candidate_id="R140B_partial_slot_beta_boundary_quarter", tier="secondary", dynamic_range=294848, best_err_pct=1.00199, hits_1pct=0, hits_5pct=12, same_sector_5pct=5, lepton_5pct=0, quark_5pct=5),
]
threshold_df = pd.DataFrame(threshold_rows)

# -----------------------------------------------------------------------------
# Classification logic.
# -----------------------------------------------------------------------------
endpoint_mode_pairs = {"2 vs 1/2", "1/2 vs 2"}

def classify_hit(row):
    endpoint = row["mode_pair"] in endpoint_mode_pairs
    primary = row["tier"] == "primary"
    secondary = row["tier"] == "secondary"
    if endpoint:
        return "RANGE_ENDPOINT_NOT_INDEPENDENT"
    if secondary:
        if row["same_sector"]:
            return "SECONDARY_SAME_SECTOR_SCREEN"
        return "SECONDARY_CROSS_SECTOR_SCREEN"
    if row["lepton_lepton"] and row["err_pct"] <= 1.0:
        return "CLEAN_LEPTON_INTERNAL_HIT"
    if row["quark_quark"] and row["err_pct"] <= 1.0:
        return "QUARK_INTERNAL_HIT_SCHEME_CAVEAT"
    if primary and row["same_sector"] and row["err_pct"] <= 5.0:
        return "PRIMARY_SAME_SECTOR_SUPPORTIVE"
    if primary:
        return "PRIMARY_CROSS_SECTOR_NUMERIC_ONLY"
    return "UNCLASSIFIED"

matches_df["endpoint_dynamic_range_hit"] = matches_df["mode_pair"].isin(endpoint_mode_pairs)
matches_df["evidence_class"] = matches_df.apply(classify_hit, axis=1)
matches_df["independent_of_range_selection"] = ~matches_df["endpoint_dynamic_range_hit"]
matches_df["scheme_caveat"] = matches_df["quark_quark"] | matches_df["mass_pair"].str.contains("quark", regex=False)
matches_df["clean_lepton_hit"] = matches_df["lepton_lepton"] & (~matches_df["endpoint_dynamic_range_hit"])

# Candidate-level evidence summary.
summary_rows = []
for cid, grp in matches_df.groupby("candidate_id"):
    row = dict(
        candidate_id=cid,
        tier=grp["tier"].iloc[0],
        reported_top_hits=len(grp),
        endpoint_hits=int(grp["endpoint_dynamic_range_hit"].sum()),
        independent_top_hits=int((~grp["endpoint_dynamic_range_hit"]).sum()),
        same_sector_top_hits=int(grp["same_sector"].sum()),
        clean_lepton_top_hits=int(grp["clean_lepton_hit"].sum()),
        quark_top_hits=int(grp["quark_quark"].sum()),
        cross_sector_top_hits=int((~grp["same_sector"]).sum()),
        best_top_err_pct=float(grp["err_pct"].min()),
    )
    if cid in set(threshold_df["candidate_id"]):
        t = threshold_df[threshold_df["candidate_id"] == cid].iloc[0]
        row.update(dict(
            total_hits_5pct=int(t["hits_5pct"]),
            total_same_sector_5pct=int(t["same_sector_5pct"]),
            total_lepton_5pct=int(t["lepton_5pct"]),
            total_quark_5pct=int(t["quark_5pct"]),
        ))
    else:
        row.update(dict(total_hits_5pct=None, total_same_sector_5pct=None, total_lepton_5pct=None, total_quark_5pct=None))
    summary_rows.append(row)

evidence_summary_df = pd.DataFrame(summary_rows).sort_values(["tier", "best_top_err_pct"])

# Interpretation table.
interpretation_rows = [
    dict(item="dynamic_range_closure", status="SCREEN_PASS", interpretation="Primary bridge candidates now span the charged-fermion dynamic range benchmark within 25%, but this was expected from bridge-candidate selection and is not independent mass-law proof."),
    dict(item="endpoint_hit", status="LIMITED_EVIDENCE", interpretation="The 2 vs 1/2 top/electron-style endpoint hit is range-selected evidence and should not be counted as an independent pairwise surprise."),
    dict(item="clean_lepton_internal_hit", status="IMPORTANT_SCREEN_SIGNAL", interpretation="R139 boundary-area gives an internal lepton-sector tau/muon-style hit at 0.642%; this is cleaner than quark hits because it avoids quark mass scheme dependence."),
    dict(item="quark_internal_hits", status="SUPPORTIVE_WITH_SCHEME_CAVEAT", interpretation="Primary candidates show several same-sector quark hits, but quark masses are scheme/scale dependent and multiple-comparison risk remains high."),
    dict(item="secondary_partial_hybrids", status="DIAGNOSTIC_ONLY", interpretation="Secondary partial hybrids produce sharp hits but remain secondary due to double-counting risk; they should not be selected by hit count."),
    dict(item="raw_feedback_control", status="PAIRWISE_SIGNAL_WITH_RANGE_FAIL", interpretation="Raw feedback still has pairwise hits but fails the full dynamic-range benchmark, supporting the bridge-correction program without proving it."),
    dict(item="final_law", status="OPEN", interpretation="R142/R143 do not select a final mass law; a field/lag derivation is needed to decide between exponent and boundary-area mechanisms."),
]
interpretation_df = pd.DataFrame(interpretation_rows)

# Gate audit booleans.
primary_dynamic_range_pass = bool((dynamic_df[(dynamic_df["tier"] == "primary")]["within_25pct"]).any())
clean_lepton_internal_present = bool(((matches_df["tier"] == "primary") & matches_df["clean_lepton_hit"] & (matches_df["err_pct"] <= 1.0)).any())
primary_quark_internal_present = bool(((matches_df["tier"] == "primary") & matches_df["quark_quark"] & (~matches_df["endpoint_dynamic_range_hit"]) & (matches_df["err_pct"] <= 1.0)).any())
endpoint_hits_separated = bool(matches_df["endpoint_dynamic_range_hit"].any())
secondary_hits_separated = bool((matches_df["tier"] == "secondary").any())
range_selected_evidence_flagged = endpoint_hits_separated
independent_evidence_present = clean_lepton_internal_present or primary_quark_internal_present

claim_rows = [
    dict(status="YES_SCREEN", claim="R143 interprets the locked R142 bridge screen without recomputing or retuning candidates.", reason="Only frozen R142 top-hit, dynamic-range, and threshold summaries are classified."),
    dict(status="YES", claim="R143 separates endpoint/range-selected hits from internal pairwise hits.", reason="Endpoint hits such as 2 vs 1/2 are flagged as limited evidence because the candidates were selected to bridge dynamic range."),
    dict(status="YES_SCREEN", claim="R143 identifies clean lepton and same-sector quark screen signals.", reason="Lepton-lepton hits are separated from quark-quark hits with scheme caveats."),
    dict(status="NO", claim="R143 selects a final physical mass law.", reason="This is an interpretation gate; final selection requires field derivation and independent controls."),
    dict(status="NO", claim="R143 maps rho modes to particles.", reason="Only ratio-hit classes are discussed; no rho-to-particle identities are assigned."),
    dict(status="NO", claim="R143 closes true GR/PDE bridge dynamics.", reason="The field-equation derivation remains open."),
    dict(status="NO", claim="R143 treats multiple-comparison hits as proof.", reason="All hit classes retain screening-only status and warning labels."),
]
claim_df = pd.DataFrame(claim_rows)

next_gate_rows = [
    dict(next_gate="FORCE_R128", title="GR/Lag Field Derivation Gate", goal="Attempt to derive whether the real field structure produces the R137 exponent correction, the R139 boundary-area response, or an equivalent unified correction.", must_not_do="Do not treat R142/R143 mass-screen contact as a field-equation derivation."),
    dict(next_gate="FORCE_R144", title="Bridge Candidate Robustness / Uncertainty Gate", goal="Stress-test R142 primary hits under mass uncertainty and quark scheme ranges.", must_not_do="Do not tune candidate exponents, boundary powers, or mappings."),
    dict(next_gate="FORCE_R145", title="Primary Candidate Ablation / Null Model Gate", goal="Compare R142 hit structure against shuffled-mode and random-monotonic null candidates with the same dynamic range.", must_not_do="Do not count dynamic-range endpoint hits as independent success."),
]
next_df = pd.DataFrame(next_gate_rows)

# CSV outputs.
write_csv(dynamic_df, "R143_candidate_dynamic_ranges.csv")
write_csv(matches_df, "R143_classified_R142_top_matches.csv")
write_csv(threshold_df, "R143_threshold_summary_inputs.csv")
write_csv(evidence_summary_df, "R143_candidate_evidence_summary.csv")
write_csv(interpretation_df, "R143_interpretation_table.csv")
write_csv(claim_df, "R143_claim_boundary.csv")
write_csv(next_df, "R143_next_gate_plan.csv")

# Optional plots.
if HAS_MPL:
    plt.figure(figsize=(10, 5))
    plot_df = dynamic_df[dynamic_df["tier"].isin(["primary", "secondary", "control"])]
    plt.bar(plot_df["candidate_id"], plot_df["dynamic_range"])
    plt.axhline(frozen_R127_dynamic_benchmark, linestyle="--")
    plt.xticks(rotation=75, ha="right", fontsize=8)
    plt.ylabel("dynamic range")
    plt.title("R143 bridge candidate dynamic ranges")
    plt.tight_layout()
    plt.savefig(OUT / "plots" / "dynamic_ranges.png", dpi=180)
    plt.close()

    class_counts = matches_df["evidence_class"].value_counts()
    plt.figure(figsize=(10, 5))
    plt.bar(class_counts.index, class_counts.values)
    plt.xticks(rotation=75, ha="right", fontsize=8)
    plt.ylabel("reported top-hit count")
    plt.title("R143 evidence-class counts")
    plt.tight_layout()
    plt.savefig(OUT / "plots" / "evidence_class_counts.png", dpi=180)
    plt.close()

# Summary.
verdict = "BRIDGE SCREEN INTERPRETATION PASS / INDEPENDENT HITS SEPARATED FROM RANGE-SELECTED HITS, FINAL LAW OPEN"
summary = f"""
# FORCE_R143 — Bridge Screen Interpretation Gate

## Verdict

{verdict}

## Core interpretation

R143 separates three distinct things in the R142 result:

1. **Dynamic-range closure:** primary bridge candidates span the frozen benchmark range.
2. **Range-selected endpoint evidence:** endpoint hits are expected to improve when range is selected and are not independent proof.
3. **Internal pairwise evidence:** same-sector and lepton-sector internal hits remain interesting screen signals.

## Key booleans

- primary_dynamic_range_pass: {primary_dynamic_range_pass}
- endpoint_hits_separated: {endpoint_hits_separated}
- clean_lepton_internal_present: {clean_lepton_internal_present}
- primary_quark_internal_present: {primary_quark_internal_present}
- secondary_hits_separated: {secondary_hits_separated}
- range_selected_evidence_flagged: {range_selected_evidence_flagged}
- independent_evidence_present: {independent_evidence_present}
- no_new_empirical_mass_data_loaded: True
- no_mass_matching_performed: True
- no_parameter_fit_performed: True
- no_mode_particle_mapping_performed: True
- no_final_physical_mass_law_selected: True

## Candidate dynamic ranges

{dynamic_df.to_string(index=False)}

## Evidence summary

{evidence_summary_df.to_string(index=False)}

## Interpretation table

{interpretation_df.to_string(index=False)}

## Claim boundary

{claim_df.to_string(index=False)}

## Next gates

{next_df.to_string(index=False)}
""".strip()

summary_path = OUT / "FORCE_R143_summary.md"
summary_path.write_text(summary, encoding="utf-8")

verdict_obj = dict(
    gate="R143",
    verdict=verdict,
    freeze_id=FREEZE_ID,
    selected_seed=SELECTED_SEED,
    canonical_species_formula=CANONICAL_SPECIES_FORMULA,
    primary_dynamic_range_pass=primary_dynamic_range_pass,
    endpoint_hits_separated=endpoint_hits_separated,
    clean_lepton_internal_present=clean_lepton_internal_present,
    primary_quark_internal_present=primary_quark_internal_present,
    secondary_hits_separated=secondary_hits_separated,
    range_selected_evidence_flagged=range_selected_evidence_flagged,
    independent_evidence_present=independent_evidence_present,
    no_new_empirical_mass_data_loaded=True,
    no_mass_matching_performed=True,
    no_parameter_fit_performed=True,
    no_mode_particle_mapping_performed=True,
    no_final_physical_mass_law_selected=True,
    physical_mass_spectrum_claimed=False,
    true_GR_PDE_collective_field_closed=False,
)
(OUT / "FORCE_R143_verdict.json").write_text(json.dumps(verdict_obj, indent=2), encoding="utf-8")

# Copy script into pack if possible.
try:
    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, OUT / this_file.name)
except Exception:
    pass

# Manifest.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append(dict(relative_path=str(p.relative_to(OUT)), bytes=p.stat().st_size, sha256=sha256_file(p)))
manifest_df = pd.DataFrame(manifest_rows)
write_csv(manifest_df, "artifact_manifest.csv")

# Zip pack.
if PACK.exists():
    PACK.unlink()
with zipfile.ZipFile(PACK, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(ROOT)))

with zipfile.ZipFile(PACK, "r") as z:
    bad = z.testzip()
zip_integrity = "PASS" if bad is None else f"FAIL:{bad}"

# Pretty printing helper.
def print_table(title, df, max_rows=None):
    print(title + ":")
    if max_rows is not None:
        df = df.head(max_rows)
    print(df.to_string(index=False))

print("\n=== COPY/PASTE R143 RESULT ===")
print("R143 COMPLETE")
print(f"VERDICT: {verdict}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {zip_integrity}")
print(f"primary_dynamic_range_pass: {primary_dynamic_range_pass}")
print(f"endpoint_hits_separated: {endpoint_hits_separated}")
print(f"clean_lepton_internal_present: {clean_lepton_internal_present}")
print(f"primary_quark_internal_present: {primary_quark_internal_present}")
print(f"secondary_hits_separated: {secondary_hits_separated}")
print(f"range_selected_evidence_flagged: {range_selected_evidence_flagged}")
print(f"independent_evidence_present: {independent_evidence_present}")
print("no_new_empirical_mass_data_loaded: True")
print("no_mass_matching_performed: True")
print("no_parameter_fit_performed: True")
print("no_mode_particle_mapping_performed: True")
print("no_final_physical_mass_law_selected: True")
print("physical_mass_spectrum_claimed: False")
print("true_GR_PDE_collective_field_closed: False")
print(f"selected_seed: {SELECTED_SEED}")
print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
print_table("CANDIDATE_DYNAMIC_RANGES", dynamic_df)
print_table("CLASSIFIED_TOP_MATCHES", matches_df[["candidate_id", "tier", "mode_pair", "mass_pair", "err_pct", "same_sector", "lepton_lepton", "quark_quark", "endpoint_dynamic_range_hit", "evidence_class"]], max_rows=25)
print_table("CANDIDATE_EVIDENCE_SUMMARY", evidence_summary_df)
print_table("INTERPRETATION_TABLE", interpretation_df)
print_table("CLAIM_BOUNDARY", claim_df)
print_table("NEXT_GATE_PLAN", next_df)
print(f"PACK: {PACK.resolve()}")
print(f"SUMMARY: {summary_path.resolve()}")
print("NEXT: FORCE_R128_GR_lag_field_derivation_gate_or_FORCE_R144_bridge_candidate_robustness_uncertainty_gate")
print("=== END COPY/PASTE R143 RESULT ===\n")
