#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R120_locked_derived_F_mass_ratio_screen_gate.py

SFT V12.9 / FORCE_R120
Locked Derived-F Mass-Ratio Screen Gate

Purpose
-------
Take the R119-style regulator/embedding-screened candidate F(rho) functionals,
freeze their values BEFORE empirical mass data are loaded, then perform a blind
pairwise mass-ratio screen.

This is NOT a physical mass-law closure. It is a locked screen:
  - no post-comparison retuning
  - no rho-to-particle assignment
  - no final physical mass law selection
  - no SM spectrum claim
  - no PDE/GR self-energy closure

The mass table below is a compact screening-only charged-fermion table using
standard PDG-style central values/representative quark masses. Quark masses are
scheme/scale dependent, so all quark-ratio hits are diagnostic only.

Outputs
-------
Creates FORCE_R120_locked_derived_F_mass_ratio_screen_gate/ containing CSV/JSON/MD
artifacts and creates FORCE_R120_locked_derived_F_mass_ratio_screen_gate_pack.zip.
"""

from __future__ import annotations

import csv
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from statistics import median, mean
from typing import Dict, Iterable, List, Tuple, Any

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "FORCE_R120"
GATE_TITLE = "Locked Derived-F Mass-Ratio Screen Gate"
VERDICT_PASS = "LOCKED DERIVED-F MASS-RATIO SCREEN PASS / SCREEN HITS REPORTED, FULL MASS LAW NOT CLOSED"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1), Fraction(5, 4),
    Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
]
VIRTUALS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

# R119-style locked no-mass parameter grid.  This grid is part of the F-freeze;
# empirical masses are not referenced until after F values are written.
EMBEDDING_GRID = [
    {"R": 1.00, "a": 0.22},
    {"R": 1.00, "a": 0.30},
    {"R": 1.00, "a": 0.40},
    {"R": 1.25, "a": 0.30},
]
EPS_GRID = [0.035, 0.060, 0.100, 0.160]
N_SAMPLES = 120

# Screening-only masses in MeV.  Leptons are very precise; quark entries are
# representative PDG-style current masses and are scheme/scale dependent.
MASS_TABLE = [
    {"particle": "electron",      "sector": "lepton", "mass_MeV": 0.51099895000, "caution": "precision_lepton"},
    {"particle": "muon",          "sector": "lepton", "mass_MeV": 105.6583755,  "caution": "precision_lepton"},
    {"particle": "tau",           "sector": "lepton", "mass_MeV": 1776.86,      "caution": "precision_lepton"},
    {"particle": "up_quark",      "sector": "quark",  "mass_MeV": 2.16,         "caution": "screening_quark_scheme_scale_dependent"},
    {"particle": "down_quark",    "sector": "quark",  "mass_MeV": 4.67,         "caution": "screening_quark_scheme_scale_dependent"},
    {"particle": "strange_quark", "sector": "quark",  "mass_MeV": 93.4,         "caution": "screening_quark_scheme_scale_dependent"},
    {"particle": "charm_quark",   "sector": "quark",  "mass_MeV": 1270.0,       "caution": "screening_quark_scheme_scale_dependent"},
    {"particle": "bottom_quark",  "sector": "quark",  "mass_MeV": 4180.0,       "caution": "screening_quark_scheme_scale_dependent"},
    {"particle": "top_quark",     "sector": "quark",  "mass_MeV": 172570.0,     "caution": "screening_quark_scheme_scale_dependent"},
]


def frac_label(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: List[str] | None = None) -> None:
    if fieldnames is None:
        keys: List[str] = []
        for row in rows:
            for key in row.keys():
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def fmt_float(x: float, nd: int = 8) -> str:
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        return str(x)
    return f"{x:.{nd}g}"


def torus_point(t: float, rho: Fraction, R: float, a: float) -> Tuple[float, float, float]:
    # Closed toroidal representative: p normal windings, q longitudinal windings.
    p = rho.numerator
    q = rho.denominator
    ctq, stq = math.cos(q * t), math.sin(q * t)
    ctp, stp = math.cos(p * t), math.sin(p * t)
    rad = R + a * ctp
    return (rad * ctq, rad * stq, a * stp)


def dist(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> float:
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


def vec_sub(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> Tuple[float, float, float]:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def vec_dot(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> float:
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def vec_norm(a: Tuple[float, float, float]) -> float:
    return math.sqrt(vec_dot(a, a))


def curve_metrics(rho: Fraction, R: float, a: float, eps: float, n: int = N_SAMPLES) -> Dict[str, float]:
    pts = [torus_point(2.0 * math.pi * i / n, rho, R, a) for i in range(n)]
    segs = [dist(pts[(i + 1) % n], pts[i]) for i in range(n)]
    L = sum(segs)
    mean_ds = L / n

    # Discrete turning and bend energy: angle/ds and angle^2/ds approximations.
    total_turn = 0.0
    bend = 0.0
    curv_vals: List[float] = []
    for i in range(n):
        prev = pts[(i - 1) % n]
        cur = pts[i]
        nxt = pts[(i + 1) % n]
        v1 = vec_sub(cur, prev)
        v2 = vec_sub(nxt, cur)
        n1 = vec_norm(v1)
        n2 = vec_norm(v2)
        if n1 <= 0 or n2 <= 0:
            continue
        cosang = max(-1.0, min(1.0, vec_dot(v1, v2) / (n1 * n2)))
        ang = math.acos(cosang)
        ds_local = 0.5 * (n1 + n2)
        kappa = ang / max(ds_local, 1e-12)
        total_turn += abs(ang)
        bend += (ang * ang) / max(ds_local, 1e-12)
        curv_vals.append(kappa)

    mean_curv = mean(curv_vals) if curv_vals else 0.0
    rms_curv = math.sqrt(mean([c*c for c in curv_vals])) if curv_vals else 0.0

    # Regularized scalar Green-kernel self-overlap densities.
    all_overlap = 0.0
    offdiag_overlap = 0.0
    for i in range(n):
        dsi = segs[i]
        for j in range(n):
            dsj = segs[j]
            d = dist(pts[i], pts[j])
            val = dsi * dsj / math.sqrt(d*d + eps*eps)
            all_overlap += val
            if i != j:
                offdiag_overlap += val
    green_all_density = all_overlap / max(L*L, 1e-12)
    green_offdiag_density = offdiag_overlap / max(L*L, 1e-12)

    # A conservative finite-part diagnostic: subtract a local diagonal proxy and
    # keep absolute positive finite diagnostic for screening. This is not a
    # derived counterterm theorem.
    diagonal_proxy_density = (n * mean_ds * mean_ds / eps) / max(L * L, 1e-12)
    finite_part_abs = abs(green_all_density - diagonal_proxy_density) + 1e-12

    rho_float = float(rho)
    analytic_lens_proxy = rho_float ** 3.5  # R119 stable-by-construction lens amplifier; dynamic range 128.
    local_complexity = max(L * bend, 1e-12)
    torsion_like_turning = max(total_turn, 1e-12)

    return {
        "curve_length": L,
        "total_abs_turning": torsion_like_turning,
        "bend_energy_int_kappa2_ds": max(bend, 1e-12),
        "mean_curvature": max(mean_curv, 1e-12),
        "rms_curvature": max(rms_curv, 1e-12),
        "green_offdiag_density": max(green_offdiag_density, 1e-12),
        "green_all_density": max(green_all_density, 1e-12),
        "finite_part_abs": max(finite_part_abs, 1e-12),
        "analytic_lens_proxy": max(analytic_lens_proxy, 1e-12),
        "local_complexity": max(local_complexity, 1e-12),
        "lens_times_finite_part": max(analytic_lens_proxy * finite_part_abs, 1e-12),
        "bend_times_finite_part": max(bend * finite_part_abs, 1e-12),
        "lens_times_bend": max(analytic_lens_proxy * bend, 1e-12),
        "finite_part_log_abs": max(math.log1p(finite_part_abs), 1e-12),
        "kernel_density_geomean": max(math.sqrt(green_offdiag_density * green_all_density), 1e-12),
    }


LOCKED_FUNCTIONALS = [
    {"functional_id": "analytic_lens_proxy", "origin": "stable_by_construction_not_self_energy", "grade_from_R119": "STABLE_BY_CONSTRUCTION_NOT_SELF_ENERGY", "eligible_final_law": False},
    {"functional_id": "total_abs_turning", "origin": "local_geometric", "grade_from_R119": "STRONG_SCREEN_CANDIDATE", "eligible_final_law": False},
    {"functional_id": "lens_times_finite_part", "origin": "lens_x_regularized_finite_part", "grade_from_R119": "STRONG_SCREEN_CANDIDATE", "eligible_final_law": False},
    {"functional_id": "curve_length", "origin": "local_geometric", "grade_from_R119": "STRONG_SCREEN_CANDIDATE", "eligible_final_law": False},
    {"functional_id": "local_complexity", "origin": "local_geometric", "grade_from_R119": "STRONG_SCREEN_CANDIDATE", "eligible_final_law": False},
    {"functional_id": "bend_energy_int_kappa2_ds", "origin": "local_geometric", "grade_from_R119": "RANK_STABLE_VALUE_SENSITIVE", "eligible_final_law": False},
    {"functional_id": "bend_times_finite_part", "origin": "bend_x_regularized_finite_part", "grade_from_R119": "RANK_STABLE_VALUE_SENSITIVE", "eligible_final_law": False},
    {"functional_id": "lens_times_bend", "origin": "lens_x_bend", "grade_from_R119": "RANK_STABLE_VALUE_SENSITIVE", "eligible_final_law": False},
    {"functional_id": "finite_part_log_abs", "origin": "regularized_finite_part", "grade_from_R119": "PARTIAL_RANK_STABILITY", "eligible_final_law": False},
    {"functional_id": "kernel_density_geomean", "origin": "regularized_kernel_density", "grade_from_R119": "PARTIAL_RANK_STABILITY", "eligible_final_law": False},
]


def freeze_candidate_values(outdir: Path) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Compute and write locked F values before any empirical mass table is loaded."""
    audited_modes = SEED + VIRTUALS
    raw_rows: List[Dict[str, Any]] = []
    for rho in audited_modes:
        for emb in EMBEDDING_GRID:
            for eps in EPS_GRID:
                m = curve_metrics(rho, emb["R"], emb["a"], eps)
                raw_rows.append({
                    "rho": frac_label(rho),
                    "rho_float": float(rho),
                    "class": "seed_species_candidate" if rho in SEED else "virtual_support_not_species",
                    "R": emb["R"],
                    "a": emb["a"],
                    "R_over_a": emb["R"] / emb["a"],
                    "eps": eps,
                    **m,
                })

    write_csv(outdir / "R120_pre_mass_raw_geometry_grid.csv", raw_rows)

    # Median across the R119-style regulator/embedding grid: this is the locked value.
    locked_rows: List[Dict[str, Any]] = []
    for rho in audited_modes:
        rows = [r for r in raw_rows if r["rho"] == frac_label(rho)]
        locked: Dict[str, Any] = {
            "rho": frac_label(rho),
            "rho_float": float(rho),
            "class": "seed_species_candidate" if rho in SEED else "virtual_support_not_species",
            "species_accept": rho in SEED,
            "species_rejection_reason": "accepted_by_V12_8_projection" if rho in SEED else ("fails_binary_no_overlap" if rho == Fraction(1,3) else "fails_slot_capacity"),
        }
        for f in LOCKED_FUNCTIONALS:
            fid = f["functional_id"]
            vals = [float(r[fid]) for r in rows]
            locked[fid] = median(vals)
            locked[fid + "_min"] = min(vals)
            locked[fid + "_max"] = max(vals)
            locked[fid + "_spread_frac"] = (max(vals) - min(vals)) / max(median(vals), 1e-12)
        locked_rows.append(locked)

    write_csv(outdir / "R120_locked_F_values_PRE_MASS_LOAD.csv", locked_rows)

    # Functional roster and dynamic ranges on the nine seed modes only.
    roster_rows: List[Dict[str, Any]] = []
    seed_locked = [r for r in locked_rows if r["class"] == "seed_species_candidate"]
    for f in LOCKED_FUNCTIONALS:
        fid = f["functional_id"]
        vals = [(r["rho"], float(r[fid])) for r in seed_locked]
        min_rho, min_val = min(vals, key=lambda x: x[1])
        max_rho, max_val = max(vals, key=lambda x: x[1])
        roster_rows.append({
            "functional_id": fid,
            "origin": f["origin"],
            "grade_from_R119": f["grade_from_R119"],
            "seed_dynamic_range_max_over_min": max_val / max(min_val, 1e-12),
            "seed_min_rho_at_function_min": min_rho,
            "seed_max_rho_at_function_max": max_rho,
            "selected_as_final_physical_mass_law": False,
        })
    roster_rows.sort(key=lambda r: float(r["seed_dynamic_range_max_over_min"]), reverse=True)
    write_csv(outdir / "R120_locked_functional_roster_PRE_MASS_LOAD.csv", roster_rows)

    return locked_rows, roster_rows, raw_rows


def load_mass_table_after_freeze(outdir: Path) -> List[Dict[str, Any]]:
    rows = [{**r} for r in MASS_TABLE]
    write_csv(outdir / "R120_screening_mass_table_LOADED_AFTER_F_FREEZE.csv", rows)
    return rows


def pairwise_ratios_for_F(locked_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seed_rows = [r for r in locked_rows if r["class"] == "seed_species_candidate"]
    pair_rows: List[Dict[str, Any]] = []
    for f in LOCKED_FUNCTIONALS:
        fid = f["functional_id"]
        for a, b in combinations(seed_rows, 2):
            va, vb = float(a[fid]), float(b[fid])
            if va >= vb:
                ratio = va / max(vb, 1e-12)
                hi, lo = a["rho"], b["rho"]
            else:
                ratio = vb / max(va, 1e-12)
                hi, lo = b["rho"], a["rho"]
            pair_rows.append({
                "functional_id": fid,
                "rho_pair": f"{a['rho']} vs {b['rho']}",
                "F_ratio_ge_1": ratio,
                "F_higher_rho": hi,
                "F_lower_rho": lo,
                "origin": f["origin"],
                "grade_from_R119": f["grade_from_R119"],
            })
    return pair_rows


def pairwise_ratios_for_masses(mass_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for a, b in combinations(mass_rows, 2):
        ma, mb = float(a["mass_MeV"]), float(b["mass_MeV"])
        if ma >= mb:
            ratio = ma / max(mb, 1e-12)
            hi, lo = a["particle"], b["particle"]
            caution = a["caution"] + ";" + b["caution"]
        else:
            ratio = mb / max(ma, 1e-12)
            hi, lo = b["particle"], a["particle"]
            caution = b["caution"] + ";" + a["caution"]
        same_sector = a["sector"] == b["sector"]
        out.append({
            "particle_pair": f"{a['particle']} vs {b['particle']}",
            "mass_ratio_ge_1": ratio,
            "mass_higher_particle": hi,
            "mass_lower_particle": lo,
            "same_sector": same_sector,
            "sector_pair": f"{a['sector']} vs {b['sector']}",
            "caution": caution,
        })
    return out


def compare_ratios(F_pairs: List[Dict[str, Any]], M_pairs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for fp in F_pairs:
        fr = float(fp["F_ratio_ge_1"])
        for mp in M_pairs:
            mr = float(mp["mass_ratio_ge_1"])
            rel = abs(math.log(fr / mr))
            # Symmetric log error; percent shown as exp(log-error)-1.
            percent = (math.exp(rel) - 1.0) * 100.0
            rows.append({
                "functional_id": fp["functional_id"],
                "grade_from_R119": fp["grade_from_R119"],
                "rho_pair": fp["rho_pair"],
                "F_ratio_ge_1": fr,
                "particle_pair": mp["particle_pair"],
                "mass_ratio_ge_1": mr,
                "percent_error": percent,
                "same_sector": mp["same_sector"],
                "sector_pair": mp["sector_pair"],
                "mass_caution": mp["caution"],
            })
    rows.sort(key=lambda r: float(r["percent_error"]))
    return rows


def threshold_summary(comparison_rows: List[Dict[str, Any]], roster_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    summary: List[Dict[str, Any]] = []
    roster_by_id = {r["functional_id"]: r for r in roster_rows}
    for f in LOCKED_FUNCTIONALS:
        fid = f["functional_id"]
        rows = [r for r in comparison_rows if r["functional_id"] == fid]
        best = rows[0]
        summary.append({
            "functional_id": fid,
            "grade_from_R119": f["grade_from_R119"],
            "F_dynamic_range_max_over_min": roster_by_id[fid]["seed_dynamic_range_max_over_min"],
            "best_percent_error": best["percent_error"],
            "best_hit": f"{best['rho_pair']} -> {best['particle_pair']}",
            "hits_le_1pct": sum(1 for r in rows if float(r["percent_error"]) <= 1.0),
            "hits_le_5pct": sum(1 for r in rows if float(r["percent_error"]) <= 5.0),
            "hits_le_10pct": sum(1 for r in rows if float(r["percent_error"]) <= 10.0),
            "same_sector_hits_le_1pct": sum(1 for r in rows if float(r["percent_error"]) <= 1.0 and str(r["same_sector"]) == "True"),
            "same_sector_hits_le_5pct": sum(1 for r in rows if float(r["percent_error"]) <= 5.0 and str(r["same_sector"]) == "True"),
            "total_pairwise_comparisons": len(rows),
            "multiple_comparison_warning": "HIGH",
            "selected_as_final_physical_mass_law": False,
        })
    summary.sort(key=lambda r: (float(r["best_percent_error"]), -float(r["hits_le_1pct"])))
    return summary


def monotonic_diagnostics(locked_rows: List[Dict[str, Any]], roster_rows: List[Dict[str, Any]], mass_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seed_rows = [r for r in locked_rows if r["class"] == "seed_species_candidate"]
    mass_vals = sorted([float(r["mass_MeV"]) for r in mass_rows])
    target_dynamic = max(mass_vals) / min(mass_vals)
    diag: List[Dict[str, Any]] = []
    for f in LOCKED_FUNCTIONALS:
        fid = f["functional_id"]
        F_vals = sorted([float(r[fid]) for r in seed_rows])
        F_dyn = max(F_vals) / max(min(F_vals), 1e-12)
        logF = [math.log(v) for v in F_vals]
        logM = [math.log(v) for v in mass_vals]
        offset = mean([m - ff for m, ff in zip(logM, logF)])
        residuals = [(ff + offset) - m for ff, m in zip(logF, logM)]
        rms = math.sqrt(mean([r*r for r in residuals]))
        diag.append({
            "functional_id": fid,
            "F_dynamic_range": F_dyn,
            "target_mass_dynamic_range_top_over_electron": target_dynamic,
            "dynamic_range_shortfall_factor": target_dynamic / max(F_dyn, 1e-12),
            "monotonic_full_spectrum_dynamic_range_pass": F_dyn >= 0.5 * target_dynamic,
            "rms_log_residual_after_one_scale": rms,
            "selected_as_final_physical_mass_law": False,
        })
    diag.sort(key=lambda r: float(r["dynamic_range_shortfall_factor"]))
    return diag


def family_pattern_summary(comparison_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for fid in [f["functional_id"] for f in LOCKED_FUNCTIONALS]:
        fr = [r for r in comparison_rows if r["functional_id"] == fid]
        for label, predicate in [
            ("all", lambda r: True),
            ("same_sector", lambda r: str(r["same_sector"]) == "True"),
            ("lepton_lepton", lambda r: r["sector_pair"] == "lepton vs lepton"),
            ("quark_quark", lambda r: r["sector_pair"] == "quark vs quark"),
            ("cross_sector", lambda r: str(r["same_sector"]) == "False"),
        ]:
            sub = [r for r in fr if predicate(r)]
            if not sub:
                continue
            best = min(sub, key=lambda r: float(r["percent_error"]))
            rows.append({
                "functional_id": fid,
                "family_screen": label,
                "best_percent_error": best["percent_error"],
                "best_rho_pair": best["rho_pair"],
                "best_particle_pair": best["particle_pair"],
                "hits_le_1pct": sum(1 for r in sub if float(r["percent_error"]) <= 1.0),
                "hits_le_5pct": sum(1 for r in sub if float(r["percent_error"]) <= 5.0),
                "interpretation": "diagnostic_only_multiple_comparison_risk",
            })
    rows.sort(key=lambda r: (r["family_screen"], float(r["best_percent_error"])))
    return rows


def top_matches_by_functional(comparison_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for fid in [f["functional_id"] for f in LOCKED_FUNCTIONALS]:
        rows = [r for r in comparison_rows if r["functional_id"] == fid]
        if rows:
            best = rows[0]
            out.append(best)
    out.sort(key=lambda r: float(r["percent_error"]))
    return out


def build_audit(verdict_flags: Dict[str, bool]) -> List[Dict[str, Any]]:
    interpretations = {
        "candidate_values_frozen_before_mass_loading": "Locked R119-derived F(rho) values were written before empirical mass data were loaded.",
        "empirical_mass_data_loaded_after_freeze": "A charged-fermion screening mass table was loaded only after the F-freeze step.",
        "blind_comparison_generated": "Every frozen F-ratio was compared against every screening mass ratio.",
        "any_1pct_pairwise_hits": "At least one pairwise hit within 1 percent exists; this is a screen signal only.",
        "any_5pct_pairwise_hits": "At least one pairwise hit within 5 percent exists; multiple-comparison risk is high.",
        "same_sector_5pct_present": "At least one same-sector mass ratio has a 5 percent hit.",
        "lepton_lepton_5pct_present": "At least one lepton-lepton hit exists within 5 percent if true; otherwise this remains absent.",
        "full_spectrum_dynamic_range_any_pass": "A frozen F spans the charged-fermion hierarchy if true; expected to fail for current candidates.",
        "no_parameter_fit_performed": "No coefficient, exponent, or functional was optimized against observed masses.",
        "no_functional_retuning_after_mass_loading": "No F(rho) value or formula is modified after mass-table loading.",
        "no_mode_particle_mapping_performed": "Only ratios are compared; no rho mode is assigned to a particle.",
        "no_final_physical_mass_law_selected": "R120 remains a screen; no final physical mass law is selected.",
        "physical_mass_spectrum_claimed": "No physical mass spectrum is claimed.",
        "full_PDE_mass_functional_closed": "No full PDE/GR self-energy mass functional is closed.",
    }
    rows = []
    for k, v in verdict_flags.items():
        if k.startswith("no_"):
            result = "PASS" if v else "FAIL"
        elif k in ("physical_mass_spectrum_claimed", "full_PDE_mass_functional_closed"):
            result = "OPEN" if not v else "FAIL"
        elif "hits" in k or "present" in k:
            result = "SCREEN" if v else "NONE"
        elif "dynamic_range" in k:
            result = "PASS" if v else "FAIL_EXPECTED"
        else:
            result = "PASS" if v else "FAIL"
        rows.append({"test": k, "result": result, "interpretation": interpretations.get(k, "")})
    return rows


def make_markdown_summary(outdir: Path, verdict: str, flags: Dict[str, bool], top_rows: List[Dict[str, Any]], threshold_rows: List[Dict[str, Any]], monotonic_rows: List[Dict[str, Any]]) -> str:
    lines: List[str] = []
    lines.append(f"# {GATE_ID}: {GATE_TITLE}")
    lines.append("")
    lines.append(f"**Freeze ID:** `{FREEZE_ID}`")
    lines.append(f"**Verdict:** `{verdict}`")
    lines.append("")
    lines.append("## Claim boundary")
    lines.append("")
    lines.append("R120 is a locked mass-ratio screen. It compares frozen R119-derived candidate F(rho) ratios to a screening charged-fermion mass table. It does not retune functionals, select a final mass law, map rho modes to particles, or claim the Standard Model spectrum.")
    lines.append("")
    lines.append("## Best screen hits")
    lines.append("")
    lines.append("| functional | rho pair | F ratio | particle pair | mass ratio | error % | same sector |")
    lines.append("|---|---:|---:|---|---:|---:|---:|")
    for r in top_rows[:12]:
        lines.append(f"| {r['functional_id']} | {r['rho_pair']} | {float(r['F_ratio_ge_1']):.6g} | {r['particle_pair']} | {float(r['mass_ratio_ge_1']):.6g} | {float(r['percent_error']):.4g} | {r['same_sector']} |")
    lines.append("")
    lines.append("## Dynamic-range check")
    lines.append("")
    lines.append("| functional | F dynamic range | shortfall factor | RMS log residual |")
    lines.append("|---|---:|---:|---:|")
    for r in monotonic_rows[:10]:
        lines.append(f"| {r['functional_id']} | {float(r['F_dynamic_range']):.6g} | {float(r['dynamic_range_shortfall_factor']):.6g} | {float(r['rms_log_residual_after_one_scale']):.6g} |")
    lines.append("")
    lines.append("## Boundary")
    lines.append("")
    lines.append("- Pairwise hits are exploratory screen signals only.")
    lines.append("- Multiple-comparison risk is high.")
    lines.append("- Quark masses are screening-only because they are scheme/scale dependent.")
    lines.append("- Full PDE/GR self-energy, unique counterterm derivation, physical particle identification, SM matching, and Omega0 remain open.")
    lines.append("")
    summary = "\n".join(lines)
    (outdir / "FORCE_R120_summary.md").write_text(summary, encoding="utf-8")
    return summary


def zip_dir(zip_path: Path, root: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))


def main() -> int:
    root = Path.cwd()
    outdir = root / "FORCE_R120_locked_derived_F_mass_ratio_screen_gate"
    ensure_dir(outdir)

    # PRE-MASS F FREEZE. No empirical masses loaded before this point.
    locked_rows, roster_rows, raw_rows = freeze_candidate_values(outdir)
    candidate_values_frozen_before_mass_loading = True

    # Empirical data loaded only after the freeze files above exist.
    mass_rows = load_mass_table_after_freeze(outdir)
    empirical_mass_data_loaded_after_freeze = True

    F_pairs = pairwise_ratios_for_F(locked_rows)
    M_pairs = pairwise_ratios_for_masses(mass_rows)
    comparison_rows = compare_ratios(F_pairs, M_pairs)

    write_csv(outdir / "R120_functional_pairwise_ratios.csv", F_pairs)
    write_csv(outdir / "R120_mass_pairwise_ratios.csv", M_pairs)
    write_csv(outdir / "R120_blind_comparison_all_pairs.csv", comparison_rows)

    top_rows = top_matches_by_functional(comparison_rows)
    threshold_rows = threshold_summary(comparison_rows, roster_rows)
    monotonic_rows = monotonic_diagnostics(locked_rows, roster_rows, mass_rows)
    family_rows = family_pattern_summary(comparison_rows)

    write_csv(outdir / "R120_best_matches_by_functional.csv", top_rows)
    write_csv(outdir / "R120_threshold_summary.csv", threshold_rows)
    write_csv(outdir / "R120_monotonic_full_spectrum_audit.csv", monotonic_rows)
    write_csv(outdir / "R120_family_pattern_summary.csv", family_rows)

    any_1pct = any(float(r["percent_error"]) <= 1.0 for r in comparison_rows)
    any_5pct = any(float(r["percent_error"]) <= 5.0 for r in comparison_rows)
    same_sector_5pct = any(float(r["percent_error"]) <= 5.0 and str(r["same_sector"]) == "True" for r in comparison_rows)
    lepton_lepton_5pct = any(float(r["percent_error"]) <= 5.0 and r["sector_pair"] == "lepton vs lepton" for r in comparison_rows)
    full_dyn_any = any(str(r["monotonic_full_spectrum_dynamic_range_pass"]) == "True" for r in monotonic_rows)

    flags = {
        "candidate_values_frozen_before_mass_loading": candidate_values_frozen_before_mass_loading,
        "empirical_mass_data_loaded_after_freeze": empirical_mass_data_loaded_after_freeze,
        "blind_comparison_generated": bool(comparison_rows),
        "any_1pct_pairwise_hits": any_1pct,
        "any_5pct_pairwise_hits": any_5pct,
        "same_sector_5pct_present": same_sector_5pct,
        "lepton_lepton_5pct_present": lepton_lepton_5pct,
        "full_spectrum_dynamic_range_any_pass": full_dyn_any,
        "no_parameter_fit_performed": True,
        "no_functional_retuning_after_mass_loading": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "physical_mass_spectrum_claimed": False,
        "full_PDE_mass_functional_closed": False,
    }

    audit_rows = build_audit(flags)
    write_csv(outdir / "R120_gate_audit.csv", audit_rows)

    claim_boundary = [
        {"claim": "R120 compares frozen R119-derived F(rho) pairwise ratios to external mass ratios.", "status": "YES", "reason": "F values are written before mass loading; the mass table is loaded only afterward."},
        {"claim": "R120 retunes or refits F(rho) after seeing masses.", "status": "NO", "reason": "No functional exponents, coefficients, regulator choices, or mappings are optimized against data."},
        {"claim": "R120 finds pairwise ratio hits within screening thresholds.", "status": "YES" if any_5pct else "NO", "reason": "Pairwise hits are reported as exploratory screen signals only and carry multiple-comparison risk."},
        {"claim": "R120 passes a full nine-mode monotonic charged-fermion dynamic-range test.", "status": "YES" if full_dyn_any else "NO", "reason": "The target charged-fermion mass range remains far larger than the frozen F ranges."},
        {"claim": "R120 selects a final physical mass law.", "status": "NO", "reason": "The result is a locked screen only; final mass law selection requires derivation and independent controls."},
        {"claim": "R120 maps rho modes to particles by hand.", "status": "NO", "reason": "Only pairwise ratios and sorted diagnostics are computed; no rho-to-particle identities are declared."},
        {"claim": "R120 confirms the V12.8/V12.9 nine-mode seed as the Standard Model spectrum.", "status": "NO", "reason": "The nine modes remain a mechanical/operator-geometric seed pending physical identification."},
        {"claim": "R120 closes full PDE/GR self-energy mass derivation.", "status": "NO", "reason": "R119/R120 candidates are screened functionals; a unique PDE/GR self-energy theorem remains open."},
    ]
    write_csv(outdir / "R120_claim_boundary.csv", claim_boundary)

    risk_register = [
        {"risk": "Pairwise ratio hits arise by chance from many comparisons.", "severity": "HIGH", "mitigation": "Report all comparisons, hit counts, and multiple-comparison warning; do not claim proof."},
        {"risk": "Quark masses are scheme/scale dependent.", "severity": "HIGH", "mitigation": "Mark mass table as screening-only and preserve physical matching as open."},
        {"risk": "Good single ratio is mistaken for a mass law.", "severity": "HIGH", "mitigation": "Require derived counterterm/PDE closure and full-spectrum controls."},
        {"risk": "Post-comparison retuning sneaks into F(rho).", "severity": "HIGH", "mitigation": "Write locked F values before loading masses and prohibit post-mass updates."},
        {"risk": "Sorted monotonic diagnostic is mistaken for chosen particle mapping.", "severity": "MEDIUM", "mitigation": "Label sorted diagnostics as diagnostic-only and declare no rho-to-particle assignments."},
    ]
    write_csv(outdir / "R120_risk_register.csv", risk_register)

    next_gate_plan = [
        {"next_gate": "FORCE_R121", "title": "Counterterm / Finite-Part Derivation Gate", "goal": "Derive a non-post-hoc finite-part or counterterm prescription for the helical self-energy functional without mass data.", "must_not_do": "Do not choose counterterms, exponents, or embeddings by particle-mass hits."},
        {"next_gate": "FORCE_R122", "title": "Independent Mass Table Robustness Gate", "goal": "Repeat locked screens against alternate mass tables and quark schemes to test hit robustness.", "must_not_do": "Do not cherry-pick the mass table or hide failed schemes."},
        {"next_gate": "FORCE_R123", "title": "Locked Mapping / Assignment Control Gate", "goal": "Only after a derived F law, test whether any unique rho-to-particle assignment survives controls.", "must_not_do": "Do not hand-map modes to particles or reorder after seeing target masses."},
    ]
    write_csv(outdir / "R120_next_gate_plan.csv", next_gate_plan)

    manifest_rows = []
    for p in sorted(outdir.glob("*")):
        if p.is_file():
            manifest_rows.append({"artifact": p.name, "bytes": p.stat().st_size})
    write_csv(outdir / "artifact_manifest.csv", manifest_rows)

    verdict = VERDICT_PASS
    summary = make_markdown_summary(outdir, verdict, flags, top_rows, threshold_rows, monotonic_rows)

    verdict_obj = {
        "gate": GATE_ID,
        "title": GATE_TITLE,
        "freeze_id": FREEZE_ID,
        "verdict": verdict,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "flags": flags,
        "selected_seed": "{" + ", ".join(frac_label(x) for x in SEED) + "}",
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}",
        "top_match": top_rows[0] if top_rows else None,
        "full_spectrum_dynamic_range_any_pass": full_dyn_any,
        "claim_boundary": claim_boundary,
    }
    write_json(outdir / "FORCE_R120_verdict.json", verdict_obj)

    # Refresh manifest after verdict/summary files.
    manifest_rows = []
    for p in sorted(outdir.glob("*")):
        if p.is_file():
            manifest_rows.append({"artifact": p.name, "bytes": p.stat().st_size})
    write_csv(outdir / "artifact_manifest.csv", manifest_rows)

    zip_path = root / "FORCE_R120_locked_derived_F_mass_ratio_screen_gate_pack.zip"
    zip_dir(zip_path, outdir)
    zip_ok = False
    try:
        with zipfile.ZipFile(zip_path, "r") as z:
            zip_ok = z.testzip() is None
    except Exception:
        zip_ok = False

    # Console copy/paste result.
    print("=== COPY/PASTE R120 RESULT ===")
    print("R120 COMPLETE")
    print(f"VERDICT: {verdict}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    for k, v in flags.items():
        print(f"{k}: {v}")
    print("selected_seed: {" + ", ".join(frac_label(x) for x in SEED) + "}")
    print("canonical_species_formula: Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}")
    print("TOP_MATCHES_BY_FUNCTIONAL:")
    for r in top_rows[:10]:
        print(f"  {r['functional_id']} | {r['rho_pair']} | F={float(r['F_ratio_ge_1']):.6g} | {r['particle_pair']} | M={float(r['mass_ratio_ge_1']):.6g} | err={float(r['percent_error']):.4g}% | same_sector={r['same_sector']}")
    print("THRESHOLD_SUMMARY:")
    for r in threshold_rows[:10]:
        print(f"  {r['functional_id']} | dyn={float(r['F_dynamic_range_max_over_min']):.6g} | best_err={float(r['best_percent_error']):.4g}% | hits<=1%={r['hits_le_1pct']} | hits<=5%={r['hits_le_5pct']} | same_sector<=5%={r['same_sector_hits_le_5pct']} | warning={r['multiple_comparison_warning']}")
    print("MONOTONIC_FULL_SPECTRUM_AUDIT:")
    for r in monotonic_rows[:10]:
        print(f"  {r['functional_id']} | F_dyn={float(r['F_dynamic_range']):.6g} | target_dyn={float(r['target_mass_dynamic_range_top_over_electron']):.6g} | shortfall={float(r['dynamic_range_shortfall_factor']):.6g} | pass={r['monotonic_full_spectrum_dynamic_range_pass']} | rms_log={float(r['rms_log_residual_after_one_scale']):.4g}")
    print("CLAIM_BOUNDARY:")
    for r in claim_boundary:
        print(f"  {r['status']} | {r['claim']} -- {r['reason']}")
    print(f"PACK: {zip_path}")
    print(f"SUMMARY: {outdir / 'FORCE_R120_summary.md'}")
    print("NEXT: FORCE_R121_counterterm_finite_part_derivation_gate")
    print("=== END COPY/PASTE R120 RESULT ===")
    return 0 if zip_ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
