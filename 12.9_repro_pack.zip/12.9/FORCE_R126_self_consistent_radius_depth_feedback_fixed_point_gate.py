#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R126_self_consistent_radius_depth_feedback_fixed_point_gate.py

SFT V12.9 / FORCE_R126
Self-Consistent Radius/Depth Feedback Fixed-Point Gate

Purpose
-------
R125 found scalar lag/gravity-map radius/depth diagnostics where depth grows
nonlinearly with inverse radius, but it did not test feedback. R126 tests a
geometry-only fixed-point feedback screen:

    smaller radius -> larger depth -> stronger focusing -> smaller closure radius

No empirical masses are loaded. No particle mapping is performed. No final
physical mass law is selected. This is a numerical screen of whether the
radius/depth feedback idea can steepen geometry-native dynamic ranges.

Outputs
-------
Creates:
  FORCE_R126_self_consistent_radius_depth_feedback_fixed_point_gate/
    FORCE_R126_summary.md
    FORCE_R126_feedback_fixed_point_table.csv
    FORCE_R126_top_feedback_diagnostics.csv
    FORCE_R126_seed_preview_best_candidate.csv
    FORCE_R126_virtual_support_status.csv
    FORCE_R126_claim_boundary.csv
    FORCE_R126_risk_register.csv
    FORCE_R126_verdict.json
  FORCE_R126_self_consistent_radius_depth_feedback_fixed_point_gate_pack.zip

Run
---
  python FORCE_R126_self_consistent_radius_depth_feedback_fixed_point_gate.py
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import sys
import zipfile
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "FORCE_R126"
GATE_TITLE = "Self-Consistent Radius/Depth Feedback Fixed-Point Gate"
OUTDIR_NAME = "FORCE_R126_self_consistent_radius_depth_feedback_fixed_point_gate"
PACK_NAME = "FORCE_R126_self_consistent_radius_depth_feedback_fixed_point_gate_pack.zip"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUALS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
ALL_AUDITED = SEED + VIRTUALS

# Conservative numerical caps; values beyond these are screen-runaway, not a selected law.
LOG_CAP = 40.0  # exp(40) ~ 2.35e17, safely below overflow and enough to flag runaway.
MIN_LOG_RADIUS = -20.0
MAX_LOG_RADIUS = 20.0
CONVERGENCE_TOL = 2.5e-7
MAX_ITER = 300
RELAX = 0.22


def frac_s(f: Fraction) -> str:
    return str(f.numerator) if f.denominator == 1 else f"{f.numerator}/{f.denominator}"


def safe_exp(x: float) -> float:
    if x > LOG_CAP:
        return math.exp(LOG_CAP)
    if x < -LOG_CAP:
        return math.exp(-LOG_CAP)
    return math.exp(x)


def median(vals: List[float]) -> float:
    vals = sorted(vals)
    n = len(vals)
    if n == 0:
        return float("nan")
    if n % 2:
        return vals[n // 2]
    return 0.5 * (vals[n // 2 - 1] + vals[n // 2])


def percentile(vals: List[float], q: float) -> float:
    vals = sorted(vals)
    if not vals:
        return float("nan")
    idx = (len(vals) - 1) * q
    lo = int(math.floor(idx))
    hi = int(math.ceil(idx))
    if lo == hi:
        return vals[lo]
    return vals[lo] * (hi - idx) + vals[hi] * (idx - lo)


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        keys: List[str] = []
        for row in rows:
            for k in row.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclass(frozen=True)
class ModeGeom:
    rho: Fraction
    rho_s: str
    rho_float: float
    numerator_p: int
    denominator_q: int
    support_role: str
    species_accept: bool
    rejection_reason: str
    curve_length_proxy: float
    local_complexity_proxy: float
    analytic_lens_proxy: float
    finite_abs_proxy: float
    turning_proxy: float


def base_mode_geometry(rho: Fraction) -> ModeGeom:
    x = float(rho)
    p, q = rho.numerator, rho.denominator
    rho_s = frac_s(rho)
    support_role = "species_seed" if rho in SEED else "support_only"
    species_accept = rho in SEED
    if species_accept:
        rejection = "accepted_by_V12_8_projection"
    elif rho == Fraction(1, 3):
        rejection = "fails_binary_no_overlap"
    else:
        rejection = "fails_slot_capacity"

    # Geometry-native proxies, deliberately not fitted to masses.
    # Curve length proxy: closed torus-helical p/q path length normalized by a unit torus scale.
    curve_length = math.sqrt((2.0 * math.pi * q) ** 2 + (2.0 * math.pi * p) ** 2) / (2.0 * math.pi)

    # Local complexity: finite p/q winding combinatorics; favors nontrivial closed windings.
    local_complexity = (p + q + abs(p - q) + 1.0) / (1.0 + math.gcd(p, q))

    # Analytic lens proxy inherited from R121/R122 family: steep but geometry-only.
    # Dynamic range across 1/2..2 is exactly 128 for rho^(7/2).
    analytic_lens = x ** 3.5

    # Scheme-clean finite-absolute proxy: non-shifted, positive, built from p/q closure texture.
    # This is not the R121 exact finite integral; it is a portable R126 proxy for feedback screening.
    winding_texture = 1.0 + abs(p - q) / (p + q) + (p * q) / ((p + q) ** 2)
    finite_abs = winding_texture * (1.0 + 0.15 * math.log1p(p + q))

    # Total turning proxy: how many frame/base turns are present in the closed representative.
    turning = (p + q) / max(1.0, q)

    return ModeGeom(
        rho=rho,
        rho_s=rho_s,
        rho_float=x,
        numerator_p=p,
        denominator_q=q,
        support_role=support_role,
        species_accept=species_accept,
        rejection_reason=rejection,
        curve_length_proxy=curve_length,
        local_complexity_proxy=local_complexity,
        analytic_lens_proxy=analytic_lens,
        finite_abs_proxy=finite_abs,
        turning_proxy=turning,
    )


GEOMS = {rho: base_mode_geometry(rho) for rho in ALL_AUDITED}


def normalized(values: Dict[Fraction, float], reference: Iterable[Fraction] = SEED) -> Dict[Fraction, float]:
    ref_vals = [values[r] for r in reference]
    m = median(ref_vals)
    if not math.isfinite(m) or m <= 0:
        m = 1.0
    return {k: max(v / m, 1e-12) for k, v in values.items()}


BASE_LENS = normalized({r: GEOMS[r].analytic_lens_proxy for r in ALL_AUDITED})
BASE_FINITE = normalized({r: GEOMS[r].finite_abs_proxy for r in ALL_AUDITED})
BASE_LENGTH = normalized({r: GEOMS[r].curve_length_proxy for r in ALL_AUDITED})
BASE_COMPLEXITY = normalized({r: GEOMS[r].local_complexity_proxy for r in ALL_AUDITED})
BASE_TURNING = normalized({r: GEOMS[r].turning_proxy for r in ALL_AUDITED})


def base_radius(rho: Fraction, radius_law: str) -> float:
    x = float(rho)
    lens = BASE_LENS[rho]
    if radius_law == "inverse_rho_radius":
        return 1.0 / max(x, 1e-12)
    if radius_law == "inverse_sqrt_rho_radius":
        return 1.0 / math.sqrt(max(x, 1e-12))
    if radius_law == "inverse_lens_quarter_radius":
        return 1.0 / (lens ** 0.25)
    if radius_law == "inverse_lens_eighth_radius":
        return 1.0 / (lens ** 0.125)
    raise ValueError(radius_law)


def budget_factor(rho: Fraction, budget_mode: str) -> float:
    if budget_mode == "unit_budget":
        return 1.0
    if budget_mode == "path_length_budget":
        return BASE_LENGTH[rho]
    if budget_mode == "finite_abs_budget":
        return BASE_FINITE[rho]
    if budget_mode == "complexity_budget":
        return BASE_COMPLEXITY[rho]
    if budget_mode == "lens_finite_budget":
        # composite screen from the two surviving toolsets; not selected as final law.
        return math.sqrt(BASE_LENS[rho] * BASE_FINITE[rho])
    raise ValueError(budget_mode)


def feedback_fixed_point(
    rho: Fraction,
    radius_law: str,
    budget_mode: str,
    depth_power: float,
    feedback_eta: float,
    feedback_style: str,
) -> Dict[str, object]:
    """Compute a stable log-space feedback fixed point for one mode.

    The map is intentionally a screen, not a physical law. It asks whether a
    geometry-only feedback relation can amplify radius/depth nonlinearity.
    """
    r0 = max(base_radius(rho, radius_law), 1e-9)
    b = max(budget_factor(rho, budget_mode), 1e-12)
    lens = max(BASE_LENS[rho], 1e-12)
    finite = max(BASE_FINITE[rho], 1e-12)

    # Start at the no-feedback radius.
    log_r = math.log(r0)
    converged = False
    saturated = False
    log_cap_hit = False
    last_delta = float("inf")

    for it in range(1, MAX_ITER + 1):
        shrink = math.log(r0) - log_r  # positive means radius has shrunk from base
        # Depth amplitude grows when radius shrinks. depth = b * lens^(1/4) * (r0/r)^depth_power.
        log_depth_uncapped = math.log(b) + 0.25 * math.log(lens) + depth_power * shrink
        if log_depth_uncapped > LOG_CAP or log_depth_uncapped < -LOG_CAP:
            log_cap_hit = True
        log_depth = min(max(log_depth_uncapped, -LOG_CAP), LOG_CAP)
        depth = safe_exp(log_depth)

        if feedback_style == "log_saturating":
            # Mild, guaranteed finite feedback.
            target_log_r = math.log(r0) - feedback_eta * math.log1p(depth)
        elif feedback_style == "sqrt_saturating":
            target_log_r = math.log(r0) - feedback_eta * math.log1p(math.sqrt(depth))
        elif feedback_style == "finite_lens_saturating":
            # Uses scheme-clean finite texture as an extra geometry gate.
            target_log_r = math.log(r0) - feedback_eta * math.log1p(depth * math.sqrt(finite))
        else:
            raise ValueError(feedback_style)

        new_log_r = (1.0 - RELAX) * log_r + RELAX * target_log_r
        if new_log_r < MIN_LOG_RADIUS:
            new_log_r = MIN_LOG_RADIUS
            saturated = True
        elif new_log_r > MAX_LOG_RADIUS:
            new_log_r = MAX_LOG_RADIUS
            saturated = True

        last_delta = abs(new_log_r - log_r)
        log_r = new_log_r
        if last_delta < CONVERGENCE_TOL:
            converged = True
            break
    else:
        it = MAX_ITER

    shrink = math.log(r0) - log_r
    log_radius = log_r
    radius = safe_exp(log_radius)
    log_depth_final_uncapped = math.log(b) + 0.25 * math.log(lens) + depth_power * shrink
    if log_depth_final_uncapped > LOG_CAP or log_depth_final_uncapped < -LOG_CAP:
        log_cap_hit = True
    log_depth_final = min(max(log_depth_final_uncapped, -LOG_CAP), LOG_CAP)
    depth_final = safe_exp(log_depth_final)
    focusing_gain = max(r0 / radius, 1e-12)

    # Feedback mass proxy: depth times geometry lens times finite clean texture.
    # This is screen-only and never selected as a physical law here.
    log_mass_proxy_uncapped = log_depth_final + 0.5 * math.log(lens) + 0.25 * math.log(finite)
    if log_mass_proxy_uncapped > LOG_CAP or log_mass_proxy_uncapped < -LOG_CAP:
        log_cap_hit = True
    log_mass_proxy = min(max(log_mass_proxy_uncapped, -LOG_CAP), LOG_CAP)
    mass_proxy = safe_exp(log_mass_proxy)

    return {
        "rho": frac_s(rho),
        "rho_float": float(rho),
        "support_role": GEOMS[rho].support_role,
        "species_accept": GEOMS[rho].species_accept,
        "species_rejection_reason": GEOMS[rho].rejection_reason,
        "radius_law": radius_law,
        "budget_mode": budget_mode,
        "depth_power": depth_power,
        "feedback_eta": feedback_eta,
        "feedback_style": feedback_style,
        "base_radius": r0,
        "fixed_radius": radius,
        "radius_shrink_gain": focusing_gain,
        "fixed_depth_proxy": depth_final,
        "feedback_mass_proxy": mass_proxy,
        "log_feedback_mass_proxy": log_mass_proxy,
        "iterations": it,
        "converged": converged,
        "saturated": saturated,
        "log_cap_hit": log_cap_hit,
        "last_delta": last_delta,
        "base_lens_norm": lens,
        "finite_abs_norm": finite,
        "budget_factor": b,
    }


def run_grid() -> Tuple[List[Dict[str, object]], List[Dict[str, object]], List[Dict[str, object]]]:
    radius_laws = [
        "inverse_rho_radius",
        "inverse_sqrt_rho_radius",
        "inverse_lens_quarter_radius",
        "inverse_lens_eighth_radius",
    ]
    budget_modes = [
        "unit_budget",
        "path_length_budget",
        "finite_abs_budget",
        "complexity_budget",
        "lens_finite_budget",
    ]
    depth_powers = [3.0, 4.0]
    feedback_etas = [0.25, 0.5, 0.75]
    feedback_styles = ["sqrt_saturating", "log_saturating", "finite_lens_saturating"]

    fixed_rows: List[Dict[str, object]] = []
    diag_rows: List[Dict[str, object]] = []

    for radius_law in radius_laws:
        for budget_mode in budget_modes:
            for depth_power in depth_powers:
                for feedback_eta in feedback_etas:
                    for feedback_style in feedback_styles:
                        rows = [feedback_fixed_point(r, radius_law, budget_mode, depth_power, feedback_eta, feedback_style) for r in ALL_AUDITED]
                        fixed_rows.extend(rows)
                        seed_rows = [r for r in rows if r["support_role"] == "species_seed"]
                        logs = [float(r["log_feedback_mass_proxy"]) for r in seed_rows]
                        dyn_log = max(logs) - min(logs)
                        dyn = safe_exp(dyn_log)
                        rho_min = seed_rows[logs.index(min(logs))]["rho"]
                        rho_max = seed_rows[logs.index(max(logs))]["rho"]
                        conv_frac = sum(1 for r in seed_rows if r["converged"]) / len(seed_rows)
                        sat_frac = sum(1 for r in seed_rows if r["saturated"]) / len(seed_rows)
                        cap_frac = sum(1 for r in seed_rows if r.get("log_cap_hit")) / len(seed_rows)
                        radius_logs = [math.log(float(r["fixed_radius"])) for r in seed_rows]
                        depth_logs = [math.log(float(r["fixed_depth_proxy"])) for r in seed_rows]
                        inv_radius_logs = [-x for x in radius_logs]
                        slope = linear_slope(inv_radius_logs, depth_logs)
                        if cap_frac > 0:
                            grade = "RUNAWAY_CAP_DIAGNOSTIC"
                        elif conv_frac >= 0.99 and sat_frac == 0 and dyn >= 1e4:
                            grade = "STRONG_FEEDBACK_SCREEN"
                        elif conv_frac >= 0.99 and dyn >= 500:
                            grade = "NONLINEAR_FEEDBACK_SCREEN"
                        elif conv_frac >= 0.80 and dyn >= 250:
                            grade = "PARTIAL_FEEDBACK_SCREEN"
                        else:
                            grade = "DIAGNOSTIC_ONLY"
                        diag_rows.append({
                            "radius_law": radius_law,
                            "budget_mode": budget_mode,
                            "depth_power": depth_power,
                            "feedback_eta": feedback_eta,
                            "feedback_style": feedback_style,
                            "seed_dynamic_range_max_over_min": dyn,
                            "seed_dynamic_range_log": dyn_log,
                            "rho_at_min": rho_min,
                            "rho_at_max": rho_max,
                            "converged_seed_fraction": conv_frac,
                            "saturated_seed_fraction": sat_frac,
                            "log_cap_hit_seed_fraction": cap_frac,
                            "depth_vs_inverse_radius_slope": slope,
                            "grade": grade,
                            "selected_as_final_physical_mass_law": False,
                        })

    diag_rows.sort(key=lambda r: (grade_rank(str(r["grade"])), float(r["seed_dynamic_range_max_over_min"])), reverse=True)
    top = diag_rows[:16]

    # Best non-saturated candidate preferred for preview; fall back to best diagnostic.
    preview_candidate = None
    for d in diag_rows:
        if str(d["grade"]) in ("STRONG_FEEDBACK_SCREEN", "NONLINEAR_FEEDBACK_SCREEN") and float(d["saturated_seed_fraction"]) == 0.0:
            preview_candidate = d
            break
    if preview_candidate is None:
        preview_candidate = diag_rows[0]

    preview_rows = [r for r in fixed_rows
                    if r["radius_law"] == preview_candidate["radius_law"]
                    and r["budget_mode"] == preview_candidate["budget_mode"]
                    and float(r["depth_power"]) == float(preview_candidate["depth_power"])
                    and float(r["feedback_eta"]) == float(preview_candidate["feedback_eta"])
                    and r["feedback_style"] == preview_candidate["feedback_style"]
                    and r["support_role"] == "species_seed"]
    preview_rows.sort(key=lambda r: float(r["rho_float"]))

    return fixed_rows, diag_rows, preview_rows


def grade_rank(g: str) -> int:
    return {
        "STRONG_FEEDBACK_SCREEN": 5,
        "RUNAWAY_CAP_DIAGNOSTIC": 4,
        "NONLINEAR_FEEDBACK_SCREEN": 3,
        "PARTIAL_FEEDBACK_SCREEN": 2,
        "DIAGNOSTIC_ONLY": 1,
    }.get(g, 0)


def linear_slope(xs: List[float], ys: List[float]) -> float:
    n = len(xs)
    if n < 2:
        return float("nan")
    mx = sum(xs) / n
    my = sum(ys) / n
    denom = sum((x - mx) ** 2 for x in xs)
    if denom <= 1e-20:
        return float("nan")
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / denom


def main() -> None:
    root = Path.cwd()
    outdir = root / OUTDIR_NAME
    outdir.mkdir(parents=True, exist_ok=True)

    fixed_rows, diag_rows, preview_rows = run_grid()

    virtual_rows = []
    # Use the same preview candidate settings for virtual status without promoting them.
    if preview_rows:
        p0 = preview_rows[0]
        for v in VIRTUALS:
            virtual_rows.append(feedback_fixed_point(
                v,
                str(p0["radius_law"]),
                str(p0["budget_mode"]),
                float(p0["depth_power"]),
                float(p0["feedback_eta"]),
                str(p0["feedback_style"]),
            ))

    claim_boundary = [
        {
            "claim": "R126 tests self-consistent radius/depth feedback maps for helical rho modes.",
            "status": "YES_SCREEN",
            "reason": "Radius, depth, feedback gain, and fixed-point mass proxies are computed from geometry-only candidate maps.",
        },
        {
            "claim": "R126 compares feedback outputs to observed particle masses.",
            "status": "NO",
            "reason": "No empirical masses or Standard Model target ratios are loaded.",
        },
        {
            "claim": "R126 selects a final physical mass law.",
            "status": "NO",
            "reason": "Feedback grades are diagnostic only; no candidate is selected as a final mass law.",
        },
        {
            "claim": "R126 proves the feedback map is a true GR/PDE self-consistent solution.",
            "status": "NO",
            "reason": "The map is a scalar lag/focusing fixed-point screen, not a solved Einstein/PDE self-energy theorem.",
        },
        {
            "claim": "R126 promotes virtual supports to species if their feedback values are interesting.",
            "status": "NO",
            "reason": "The V12.8 species projection remains locked; F-values and feedback values do not override binary/slot admissibility.",
        },
        {
            "claim": "R126 tests whether radius/depth feedback can steepen dynamic range beyond R125.",
            "status": "YES_SCREEN",
            "reason": "Dynamic ranges, convergence, saturation, and depth-vs-inverse-radius slopes are reported across the seed modes.",
        },
    ]

    risk_register = [
        {
            "risk": "Feedback map is mistaken for a physical GR/PDE derivation.",
            "severity": "HIGH",
            "mitigation": "Label as scalar fixed-point screen and keep true GR/PDE mass law open.",
        },
        {
            "risk": "Large dynamic range is mistaken for a mass-spectrum solution.",
            "severity": "HIGH",
            "mitigation": "No masses are loaded; no final law is selected; future locked comparison required.",
        },
        {
            "risk": "Runaway/collapse behavior is hidden.",
            "severity": "HIGH",
            "mitigation": "Report convergence and saturation fractions for each candidate.",
        },
        {
            "risk": "Virtual support channels are promoted by attractive feedback values.",
            "severity": "MEDIUM",
            "mitigation": "Virtual supports are computed but remain species-inactive by the V12.8 projection.",
        },
        {
            "risk": "Feedback exponents are treated as derived constants.",
            "severity": "MEDIUM",
            "mitigation": "Treat exponent grid as dimensional screen only; no exponent is fit to masses.",
        },
    ]

    # CSV outputs
    write_csv(outdir / "FORCE_R126_feedback_fixed_point_table.csv", fixed_rows)
    write_csv(outdir / "FORCE_R126_top_feedback_diagnostics.csv", diag_rows)
    write_csv(outdir / "FORCE_R126_seed_preview_best_candidate.csv", preview_rows)
    write_csv(outdir / "FORCE_R126_virtual_support_status.csv", virtual_rows)
    write_csv(outdir / "FORCE_R126_claim_boundary.csv", claim_boundary)
    write_csv(outdir / "FORCE_R126_risk_register.csv", risk_register)

    strong_present = any(str(r["grade"]) == "STRONG_FEEDBACK_SCREEN" for r in diag_rows)
    nonlinear_present = any(str(r["grade"]) in ("STRONG_FEEDBACK_SCREEN", "NONLINEAR_FEEDBACK_SCREEN", "RUNAWAY_CAP_DIAGNOSTIC") for r in diag_rows)
    runaway_present = any(str(r["grade"]) == "RUNAWAY_CAP_DIAGNOSTIC" for r in diag_rows)
    conv_reported = all("converged_seed_fraction" in r for r in diag_rows)
    sat_reported = all("saturated_seed_fraction" in r and "log_cap_hit_seed_fraction" in r for r in diag_rows)

    verdict = "SELF-CONSISTENT RADIUS/DEPTH FEEDBACK SCREEN PASS / FEEDBACK DYNAMIC RANGE REPORTED, TRUE GR-PDE MASS LAW OPEN"

    verdict_obj = {
        "gate": GATE_ID,
        "title": GATE_TITLE,
        "freeze_id": FREEZE_ID,
        "verdict": verdict,
        "parameter_grid_generated": True,
        "feedback_grid_generated": True,
        "fixed_point_table_generated": True,
        "seed_all_computed": all(any(row["rho"] == frac_s(r) for row in fixed_rows) for r in SEED),
        "virtuals_computed_not_promoted": all(not row["species_accept"] for row in virtual_rows),
        "feedback_convergence_reported": conv_reported,
        "runaway_or_collapse_flags_reported": sat_reported,
        "runaway_cap_diagnostics_present": runaway_present,
        "nonlinear_feedback_candidates_present": nonlinear_present,
        "strong_feedback_dynamic_range_candidates_present": strong_present,
        "no_empirical_mass_data_loaded": True,
        "no_mass_matching_performed": True,
        "no_parameter_fit_performed": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "unique_feedback_law_closed": False,
        "true_GR_PDE_mass_law_closed": False,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "Omega0_claimed": False,
        "selected_seed": "{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}",
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
    }

    # Write summary MD
    summary = []
    summary.append(f"# {GATE_ID}: {GATE_TITLE}\n")
    summary.append(f"**Freeze ID:** `{FREEZE_ID}`\n")
    summary.append(f"**Verdict:** `{verdict}`\n")
    summary.append("\n## Claim boundary\n")
    for row in claim_boundary:
        summary.append(f"- **{row['status']}** — {row['claim']} {row['reason']}\n")
    summary.append("\n## Top diagnostics\n")
    for row in diag_rows[:12]:
        summary.append(
            f"- `{row['radius_law']} | {row['budget_mode']} | d={row['depth_power']} | eta={row['feedback_eta']} | {row['feedback_style']}`: "
            f"dyn={float(row['seed_dynamic_range_max_over_min']):.6g}, "
            f"slope={float(row['depth_vs_inverse_radius_slope']):.4g}, "
            f"conv={float(row['converged_seed_fraction']):.3f}, "
            f"sat={float(row['saturated_seed_fraction']):.3f}, "
            f"cap={float(row.get('log_cap_hit_seed_fraction',0.0)):.3f}, "
            f"grade={row['grade']}\n"
        )
    summary.append("\n## Boundary\n")
    summary.append("No empirical masses are loaded. No matching, fitting, particle mapping, final mass law, physical spectrum, Standard Model matching, Omega0, or true GR/PDE closure is claimed.\n")
    (outdir / "FORCE_R126_summary.md").write_text("".join(summary), encoding="utf-8")

    (outdir / "FORCE_R126_verdict.json").write_text(json.dumps(verdict_obj, indent=2), encoding="utf-8")

    # Zip pack
    pack_path = root / PACK_NAME
    if pack_path.exists():
        pack_path.unlink()
    with zipfile.ZipFile(pack_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(outdir.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root))

    # Verify zip
    zip_ok = True
    try:
        with zipfile.ZipFile(pack_path, "r") as z:
            bad = z.testzip()
            zip_ok = bad is None
    except Exception:
        zip_ok = False

    verdict_obj["zip_integrity"] = "PASS" if zip_ok else "FAIL"
    verdict_obj["pack_sha256"] = sha256_file(pack_path) if pack_path.exists() else ""
    (outdir / "FORCE_R126_verdict.json").write_text(json.dumps(verdict_obj, indent=2), encoding="utf-8")

    # Print copy/paste result
    print("=== COPY/PASTE R126 RESULT ===")
    print("R126 COMPLETE")
    print(f"VERDICT: {verdict}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    for key in [
        "parameter_grid_generated",
        "feedback_grid_generated",
        "fixed_point_table_generated",
        "seed_all_computed",
        "virtuals_computed_not_promoted",
        "feedback_convergence_reported",
        "runaway_or_collapse_flags_reported",
        "nonlinear_feedback_candidates_present",
        "runaway_cap_diagnostics_present",
        "strong_feedback_dynamic_range_candidates_present",
        "no_empirical_mass_data_loaded",
        "no_mass_matching_performed",
        "no_parameter_fit_performed",
        "no_mode_particle_mapping_performed",
        "no_final_physical_mass_law_selected",
        "unique_feedback_law_closed",
        "true_GR_PDE_mass_law_closed",
        "physical_mass_spectrum_claimed",
        "SM_mass_matching_claimed",
        "Omega0_claimed",
    ]:
        print(f"{key}: {verdict_obj[key]}")
    print(f"selected_seed: {verdict_obj['selected_seed']}")
    print(f"canonical_species_formula: {verdict_obj['canonical_species_formula']}")
    print("TOP_FEEDBACK_DIAGNOSTICS:")
    for row in diag_rows[:10]:
        print(
            f"  {row['radius_law']} | {row['budget_mode']} | d={row['depth_power']} | eta={row['feedback_eta']} | {row['feedback_style']} "
            f"| dyn={float(row['seed_dynamic_range_max_over_min']):.6g} "
            f"| min={row['rho_at_min']} | max={row['rho_at_max']} "
            f"| slope={float(row['depth_vs_inverse_radius_slope']):.4g} "
            f"| conv={float(row['converged_seed_fraction']):.3f} "
            f"| sat={float(row['saturated_seed_fraction']):.3f} "
            f"| cap={float(row.get('log_cap_hit_seed_fraction',0.0)):.3f} "
            f"| grade={row['grade']} | final_law=False"
        )
    if preview_rows:
        p0 = preview_rows[0]
        print("SEED_FEEDBACK_PREVIEW_VARIANT:")
        print(
            f"  radius_law={p0['radius_law']} | budget_mode={p0['budget_mode']} | depth_power={p0['depth_power']} | "
            f"feedback_eta={p0['feedback_eta']} | feedback_style={p0['feedback_style']}"
        )
        for row in preview_rows:
            print(
                f"  rho={row['rho']} | base_r={float(row['base_radius']):.6g} | fixed_r={float(row['fixed_radius']):.6g} "
                f"| shrink={float(row['radius_shrink_gain']):.6g} | depth={float(row['fixed_depth_proxy']):.6g} "
                f"| feedback_F={float(row['feedback_mass_proxy']):.6g} | converged={row['converged']} | saturated={row['saturated']} | log_cap_hit={row.get('log_cap_hit')}"
            )
    print("CLAIM_BOUNDARY:")
    for row in claim_boundary:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {outdir / 'FORCE_R126_summary.md'}")
    print("NEXT: FORCE_R127_feedback_candidate_blind_mass_screen_gate_or_FORCE_R128_GR_lag_field_derivation_gate")
    print("=== END COPY/PASTE R126 RESULT ===")


if __name__ == "__main__":
    main()
