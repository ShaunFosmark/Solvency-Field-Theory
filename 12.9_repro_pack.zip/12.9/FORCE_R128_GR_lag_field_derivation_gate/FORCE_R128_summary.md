# R128 Summary — GR/Lag Field Derivation Gate

**VERDICT:** GR/LAG FIELD DERIVATION SCREEN PASS / SCALAR FIELD SOURCES FAVOR BOUNDARY-AREA AND TRANSVERSE-PHASE CANDIDATES, TRUE GR-PDE OPEN

**FREEZE_ID:** `SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM`

## Purpose

R128 attempts to derive the leading bridge candidates from a local scalar lag/field accounting screen rather than from mass-ratio hits. It does not solve the full GR/PDE mass law.

## Core result

The scalar lag self-field alone reproduces the raw feedback amplitude but under-spans the hierarchy. Two field-native bridge screens survive:

1. **Inverse boundary-area response:** if closure radius scales as `r ~ rho^-1`, boundary load scales as `rho_norm^2`.
2. **Compound transverse phase response:** three normal channels provide a `6*pi` phase measure that can steepen the range when treated as a compound response/exponent source.

Full hybrids are retained only as double-counting controls because they over-amplify.

## Candidate scorecard

```text
candidate_id                                     | family                         | beta        | gamma | dynamic_range | grade                              | double_counting_status          
-------------------------------------------------+--------------------------------+-------------+-------+---------------+------------------------------------+---------------------------------
scalar_lag_raw_self_field                        | raw_scalar_lag                 | 0           | 0     | 17999.768974  | BASELINE_FIELD_SCREEN              | NO_DOUBLE_COUNTING              
field_transverse_phase_measure_6pi_exponent      | compound_transverse_lens       | 0.299699442 | 0     | 339288        | PRIMARY_FIELD_SCREEN_CANDIDATE     | SINGLE_MECHANISM                
field_oriented_18_exponent                       | compound_transverse_lens       | 0.294992659 | 0     | 323996        | PRIMARY_FIELD_SCREEN_CANDIDATE     | SINGLE_MECHANISM                
field_slot_root_beta_1_over_4_control            | compound_transverse_lens       | 0.25        | 0     | 208489        | PRIMARY_FIELD_SCREEN_CANDIDATE     | SINGLE_MECHANISM_CONTROL        
field_normal_root_beta_1_over_3_control          | compound_transverse_lens       | 0.333333333 | 0     | 471725        | PRIMARY_FIELD_SCREEN_CANDIDATE     | SINGLE_MECHANISM_CONTROL        
field_inverse_boundary_area_rho2_response        | boundary_insolvency            | 0           | 2     | 287996        | PRIMARY_FIELD_SCREEN_CANDIDATE     | SINGLE_MECHANISM                
field_boundary_linear_rho_control                | boundary_insolvency            | 0           | 1     | 71999.075897  | PRIMARY_FIELD_SCREEN_CANDIDATE     | SINGLE_MECHANISM_CONTROL        
field_bulk_volume_rho3_control                   | boundary_insolvency            | 0           | 3     | 1.15199e+06   | PRIMARY_FIELD_SCREEN_CANDIDATE     | SINGLE_MECHANISM_CONTROL        
full_hybrid_6pi_exponent_times_rho2_DOUBLE_COUNT | hybrid_double_counting_control | 0.299699442 | 2     | 5.4286e+06    | OVERBRIDGE_DOUBLE_COUNTING_CONTROL | EXCLUDED_DOUBLE_COUNTING_CONTROL
partial_slot_beta_boundary_quarter_SCREEN        | partial_overlap_control        | 0.25        | 0.25  | 294848        | SECONDARY_PARTIAL_OVERLAP_SCREEN   | SECONDARY_SCREEN_RISK           
partial_slot_beta_boundary_half_SCREEN           | partial_overlap_control        | 0.25        | 0.5   | 416978        | SECONDARY_PARTIAL_OVERLAP_SCREEN   | SECONDARY_SCREEN_RISK           
```

## Field derivation ledger

```text
step | field_object                           | formal_screen_equation                                                          | mechanical_consequence                                                                                           | status                                                   
-----+----------------------------------------+---------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------+----------------------------------------------------------
1    | lag potential Phi                      | Delta Phi = kappa J_helix                                                       | Raw scalar lag/self-field produces R126/R127 radius-depth feedback but under-spans hierarchy.                    | SCALAR_FIELD_SCREEN_CLOSED_NOT_GR                        
2    | boundary flux through closure surface  | integral_boundary grad Phi dot dA = integral_bulk J dV                          | If r~rho^-1, inverse boundary area load scales as rho_norm^2.                                                    | BOUNDARY_AREA_RESPONSE_SCREEN_SUPPORTED                  
3    | normal-bundle transverse phase measure | dmu_perp ~ product_i dtheta_i with D_perp=3; total angular measure ~ 2pi D_perp | A compound transverse response can appear as exponent/range steepening rather than global multiplication.        | TRANSVERSE_PHASE_EXPONENT_SCREEN_SUPPORTED_BUT_NOT_PROVEN
4    | hybrid response                        | Phi_eff includes both full exponent and full inverse-area term                  | Full hybrid over-bridges, indicating likely double-counting if both are treated as independent full corrections. | DOUBLE_COUNTING_WARNING                                  
5    | self-consistent GR/PDE metric response | G_ab[g] = 8 pi T_ab[helix, Phi, boundary]                                       | Not solved in R128; future work must derive whether exponent, boundary area, or unified response emerges.        | OPEN_TRUE_GR_PDE                                         
```

## Mechanism interpretation

```text
mechanism                          | field_status                           | bridge_status           | interpretation                                                                                            
-----------------------------------+----------------------------------------+-------------------------+-----------------------------------------------------------------------------------------------------------
raw scalar lag self-field          | defined                                | underbridge             | Mass-amplitude-like baseline; not sufficient by itself.                                                   
inverse boundary-area response     | supported as boundary flux/load screen | primary survivor        | Mechanically clean V11-adjacent candidate; needs full boundary/bulk derivation.                           
compound transverse phase exponent | supported as measure/exponent screen   | primary survivor        | Numerically strong; needs derivation of why transverse measure enters exponent rather than factor.        
full hybrid exponent times area    | control only                           | overbridge/double count | Likely counts the same transverse/boundary response twice.                                                
true GR/PDE lag field              | open                                   | not closed              | Only a self-consistent field derivation can select between exponent, boundary-area, or unified correction.
```

## Claim boundary

```text
status     | claim                                                                                               | reason                                                                                                                        
-----------+-----------------------------------------------------------------------------------------------------+-------------------------------------------------------------------------------------------------------------------------------
YES_SCREEN | R128 constructs a local scalar lag/field derivation screen for raw feedback and bridge corrections. | Poisson-like lag source, boundary flux accounting, and transverse phase-measure candidates are generated without mass data.   
YES_SCREEN | R128 supports inverse boundary-area response as a field-native screen candidate.                    | Boundary flux/load accounting with r~rho^-1 gives an explicit rho_norm^2 differential response.                               
YES_SCREEN | R128 supports transverse phase-measure exponent response as a field-native screen candidate.        | The three-normal 6pi measure is tested as compound response/exponent source, not a global multiplier.                         
YES        | R128 treats full exponent-times-area hybrids as double-counting controls.                           | Including both full corrections simultaneously over-amplifies and likely counts overlapping transverse/boundary physics twice.
NO         | R128 closes the true GR/PDE mass law.                                                               | The gate is a scalar lag/field derivation screen, not a solved self-consistent Einstein/PDE system.                           
NO         | R128 compares to observed particle masses or selects a final mass law.                              | No empirical mass table is loaded; no pairwise matching, fitting, or particle mapping occurs.                                 
```

## Next gate

`FORCE_R146_V12_9_bridge_screen_rollup_gate` or `FORCE_R144/R145 already completed -> V12.9 rollup/freeze candidate`.

A future stronger gate should attempt a real covariant PDE/GR derivation, not just this scalar lag/flux screen.
