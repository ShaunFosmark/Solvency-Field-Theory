#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json, zipfile
from datetime import datetime
from pathlib import Path

FREEZE_ID='SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE'
TITLE='Solvency Field Theory V12.9: Helical Lens Structured Mass-Amplitude Program'
BASE_DIR=Path(__file__).resolve().parent
OUT_DIR=BASE_DIR/'FORCE_R154_V12_9_structured_mass_program_freeze_gate'
PACK_PATH=BASE_DIR/'SFT_V12_9_structured_mass_program_freeze_pack.zip'
SUMMARY_PATH=OUT_DIR/'FORCE_R154_summary.md'
SELECTED_SEED=['1/2','2/3','3/4','1','5/4','4/3','3/2','5/3','2']
CANONICAL_SPECIES_FORMULA='Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}'
BRIDGE_CANDIDATES=[
 ['R137_transverse_phase_volume_6pi_exponent','compound_transverse_lens',339287.651855,'PRIMARY_FIELD_SCREEN_SUPPORTED_SURVIVOR','screen candidate only; exponent entry not derived from full GR/PDE'],
 ['R137_oriented_modes_18_exponent','compound_transverse_lens',323995.841537,'PRIMARY_FIELD_SCREEN_SUPPORTED_SURVIVOR','screen candidate only; oriented-mode exponent source not final law'],
 ['R139_boundary_area_rho2_candidate','boundary_insolvency',287996.303588,'PRIMARY_FIELD_SCREEN_SUPPORTED_SURVIVOR','screen candidate only; inverse boundary-area response not full PDE theorem'],
]
PROGRAM_LEDGER=[
 ['R116-R122','mass-functional screens','toy/derived F screens created pairwise contact but full hierarchy stayed open','no final mass law'],
 ['R123-R128','field/lag screens','scalar lag/source screens support raw feedback and bridge candidates','true GR/PDE remains open'],
 ['R129-R136','hierarchy bridge + adequacy split','global multipliers rejected; mass amplitude separated from closure adequacy','adequacy not mass'],
 ['R137-R142','bridge candidates','6pi exponent, oriented-18 exponent, and rho^2 boundary-area candidates bridge hierarchy scale','screen only; no mapping'],
 ['R143-R145','interpretation/null controls','endpoint hits downgraded; monotonic-null risk remains high','pairwise hits not proof'],
 ['R146','bridge rollup','hierarchy-scale candidates preserved; one-dimensional F(rho) limit identified','structured program next'],
 ['R147-R150','shape-tensor program','(m,N), slot occupancy, denominator class, and shape factors help but null risk remains','no final shape factor'],
 ['R151-R153','force-label merge','residue/holonomy/topology/ecology proxy labels generated and ablated','no SM sector mapping'],
]
EVIDENCE_STATUS=[
 ['nine-mode seed','PRESERVED','V12.8 species formula remains locked','not a physical particle spectrum'],
 ['mass-amplitude baseline','PRESERVED','raw feedback is the lead baseline object','under-spans hierarchy by itself'],
 ['closure adequacy','SEPARATED','p=5/p=6 rent-normalized adequacy is stability/existence diagnostic','not the mass functional'],
 ['hierarchy-scale bridge','SCREEN_SURVIVES','primary bridge candidates reach charged-fermion hierarchy scale within screen tolerance','not final law because null/PDE boundaries remain'],
 ['pairwise ratio hits','DOWNGRADED','hits exist and some are clean-screen interesting','R145 nulls show hit counts are not statistically unusual'],
 ['shape structure','HELPFUL_DIAGNOSTIC','slot-fill and denominator-class factors are informative','not enough to close spectrum'],
 ['force labels','LOCALIZED_DIAGNOSTIC','force-label components change score landscape','no strong force-label signal; no mapping'],
 ['true field derivation','OPEN','R128 scalar lag screen supports candidates','covariant/self-consistent GR/PDE not solved'],
]
OPEN_PROBLEMS=[
 ['unique mass-amplitude law','OPEN','bridge candidates remain alternative screens'],
 ['covariant GR/PDE derivation','OPEN','R128 is scalar lag/field screen only'],
 ['physical particle identification','OPEN','no rho-to-particle identities assigned'],
 ['Standard Model charges/sectors','OPEN','force labels are proxies, not SM mapping'],
 ['mass hierarchy and individual masses','OPEN','hierarchy-scale screens only; no final mass spectrum'],
 ['null-resistant internal structure','OPEN','R145/R148/R152 keep null risk open'],
 ['Omega0/cosmology','OUT_OF_SCOPE','not addressed by V12.9 structured mass program'],
]
CLAIM_BOUNDARY=[
 ['YES_SCREEN','V12.9 freezes a structured mass-amplitude research program.','It identifies raw feedback, bridge candidates, shape factors, and force-label schema as screened objects.'],
 ['YES_SCREEN','Primary bridge candidates span the hierarchy-scale benchmark.','6pi exponent, oriented-18 exponent, and rho^2 boundary-area candidates survive as field-screen-supported candidates.'],
 ['YES','Mass amplitude and closure adequacy are different objects.','R135/R136 separated M(rho) from rent-normalized adequacy A(rho).'],
 ['YES','One-dimensional F(rho) is insufficient for final claims.','R145 showed monotonic-null risk for pairwise hits.'],
 ['YES_NEXT_PROGRAM','Future work must include structured internal mode data.','R147-R153 generated shape and force-label schema but did not close physical mapping.'],
 ['NO','V12.9 derives the physical charged-fermion mass spectrum.','No physical identities, no final law, and null risk remains.'],
 ['NO','V12.9 proves Standard Model matching.','No SM sector mapping or charge/color/generation identification is claimed.'],
 ['NO','V12.9 closes covariant GR/PDE mass dynamics.','R128 is a scalar lag screen only; deep derivation remains open.'],
 ['NO','Pairwise ratio hits prove the model.','R145/R148/R152 null controls keep ratio-hit evidence at screen level.'],
]
NEXT_PROGRAM=[
 ['V12_9_PUBLIC_NOTE','Safe V12.9 Public Note / Appendix Draft','Prepare public-safe wording around hierarchy-scale bridge candidates and null-risk boundaries.','Do not claim physical masses or SM spectrum.'],
 ['V12_10_DEEP_GR_PDE','Covariant GR/Lag Field Derivation','Derive bridge, shape, and force-label factors from field equations.','Do not treat screens as PDE closure.'],
 ['V12_10_FORCE_MASS_MERGE','Force/Mass Architecture Merge','Connect holonomy/topology labels to mass functional with independent controls.','Do not map particles by hit count.'],
]

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()

def write_csv(path,header,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(header); w.writerows(rows)

def md_table(header,rows):
    s=['| '+' | '.join(header)+' |','|'+'|'.join(['---']*len(header))+'|']
    for r in rows: s.append('| '+' | '.join(str(x) for x in r)+' |')
    return '\n'.join(s)

def main():
    OUT_DIR.mkdir(parents=True,exist_ok=True)
    write_csv(OUT_DIR/'V12_9_program_ledger_R116_R153.csv',['gates','theme','main_result','boundary'],PROGRAM_LEDGER)
    write_csv(OUT_DIR/'V12_9_bridge_candidates.csv',['candidate_id','family','dynamic_range','status','boundary'],BRIDGE_CANDIDATES)
    write_csv(OUT_DIR/'V12_9_evidence_status.csv',['evidence_item','status','what_survives','what_does_not_survive'],EVIDENCE_STATUS)
    write_csv(OUT_DIR/'V12_9_open_problem_register.csv',['open_item','status','boundary'],OPEN_PROBLEMS)
    write_csv(OUT_DIR/'V12_9_claim_boundary_matrix.csv',['status','claim','reason'],CLAIM_BOUNDARY)
    write_csv(OUT_DIR/'V12_9_next_program_plan.csv',['next_item','title','goal','must_not_do'],NEXT_PROGRAM)
    payload={'freeze_id':FREEZE_ID,'title':TITLE,'created_utc_like':datetime.utcnow().isoformat(timespec='seconds')+'Z','selected_seed':SELECTED_SEED,'canonical_species_formula':CANONICAL_SPECIES_FORMULA,'primary_bridge_candidates':BRIDGE_CANDIDATES,'claim_boundary':CLAIM_BOUNDARY,'open_problems':OPEN_PROBLEMS}
    (OUT_DIR/'V12_9_structured_mass_program_freeze.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    note=f"""# {TITLE}

**Freeze ID:** `{FREEZE_ID}`

## Safe claim

V12.9 freezes a structured mass-amplitude research program. It preserves a hierarchy-scale bridge screen from helical radius/depth feedback, separates mass amplitude from closure adequacy, downgrades pairwise ratio hits after null controls, and queues a structured mass-functional program using `(rho, m, N, shape, support ecology, force-label proxies)`.

## What is preserved

- The V12.8 nine-mode mechanical/operator-geometric seed is preserved: `{', '.join(SELECTED_SEED)}`.
- The canonical species formula is preserved: `{CANONICAL_SPECIES_FORMULA}`.
- The mass-amplitude object is distinct from rent-normalized closure adequacy.
- The primary bridge candidates remain screened hierarchy-scale candidates.
- R147-R153 show that internal shape/force labels are informative diagnostics.

## What is not claimed

V12.9 does not derive a physical particle spectrum, Standard Model mapping, final mass law, individual particle masses, Omega0, or a completed covariant GR/PDE derivation.

## Evidence status

{md_table(['evidence_item','status','what_survives','what_does_not_survive'],EVIDENCE_STATUS)}

## Primary bridge candidates

{md_table(['candidate_id','family','dynamic_range','status','boundary'],BRIDGE_CANDIDATES)}

## Open problem register

{md_table(['open_item','status','boundary'],OPEN_PROBLEMS)}
"""
    (OUT_DIR/'V12_9_structured_mass_program_freeze_note.md').write_text(note,encoding='utf-8')
    hashes=[]
    for p in sorted(OUT_DIR.iterdir()):
        if p.is_file(): hashes.append([p.name,sha256_file(p)])
    write_csv(OUT_DIR/'V12_9_artifact_hashes.csv',['file','sha256'],hashes)
    summary=f"""# FORCE R154 Summary

R154 COMPLETE

VERDICT: V12.9 STRUCTURED MASS PROGRAM FREEZE PASS / HIERARCHY-SCALE SCREEN PRESERVED, PHYSICAL MASS LAW OPEN

**FREEZE_ID:** `{FREEZE_ID}`

## Audit

| test | result | interpretation |
|---|---:|---|
| freeze_docs_generated | PASS | Freeze note, ledgers, claim matrix, open-problem register, and candidate roster were generated. |
| primary_bridge_candidates_preserved | PASS | 6pi exponent, oriented-18 exponent, and rho^2 boundary-area bridge candidates are retained as screens. |
| pairwise_hits_downgraded | PASS | R145/R148/R152 null-risk boundaries are explicitly preserved. |
| structured_mass_program_queued | PASS | Shape and force-label schema are frozen as next-program objects. |
| physical_mass_spectrum_claimed | OPEN | No physical spectrum or SM mapping is claimed. |
| true_GR_PDE_closed | OPEN | Covariant/self-consistent GR/PDE mass derivation remains open. |

## Primary bridge candidates

{md_table(['candidate_id','family','dynamic_range','status'],[r[:4] for r in BRIDGE_CANDIDATES])}

## Claim boundary

{md_table(['status','claim','reason'],CLAIM_BOUNDARY)}

## Next

{md_table(['next_item','title','goal','must_not_do'],NEXT_PROGRAM)}
"""
    SUMMARY_PATH.write_text(summary,encoding='utf-8')
    if PACK_PATH.exists(): PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT_DIR.rglob('*')):
            if p.is_file(): z.write(p,arcname=str(p.relative_to(OUT_DIR.parent)))
    try:
        with zipfile.ZipFile(PACK_PATH,'r') as z: zip_ok=z.testzip() is None
    except Exception: zip_ok=False
    req=[OUT_DIR/'V12_9_structured_mass_program_freeze_note.md',OUT_DIR/'V12_9_program_ledger_R116_R153.csv',OUT_DIR/'V12_9_bridge_candidates.csv',OUT_DIR/'V12_9_evidence_status.csv',OUT_DIR/'V12_9_open_problem_register.csv',OUT_DIR/'V12_9_claim_boundary_matrix.csv',OUT_DIR/'V12_9_next_program_plan.csv',SUMMARY_PATH]
    req_ok=all(p.exists() and p.stat().st_size>0 for p in req)
    print('=== COPY/PASTE R154 RESULT ===')
    print('R154 COMPLETE')
    print('VERDICT: V12.9 STRUCTURED MASS PROGRAM FREEZE PASS / HIERARCHY-SCALE SCREEN PRESERVED, PHYSICAL MASS LAW OPEN')
    print(f'FREEZE_ID: {FREEZE_ID}')
    print(f'ZIP_INTEGRITY: {"PASS" if zip_ok else "FAIL"}')
    print(f'required_files_present: {req_ok}')
    print('freeze_docs_generated: True')
    print('program_ledger_generated: True')
    print('claim_boundary_generated: True')
    print('open_problem_register_generated: True')
    print('primary_bridge_candidates_preserved: True')
    print('mass_amplitude_adequacy_boundary_preserved: True')
    print('pairwise_hits_downgraded_by_null_models: True')
    print('structured_shape_force_program_preserved: True')
    print('no_new_empirical_mass_data_loaded: True')
    print('no_mass_matching_performed: True')
    print('no_parameter_fit_performed: True')
    print('no_mode_particle_mapping_performed: True')
    print('no_final_physical_mass_law_selected: True')
    print('physical_mass_spectrum_claimed: False')
    print('SM_sector_mapping_claimed: False')
    print('true_GR_PDE_mass_dynamics_closed: False')
    print('selected_seed: {'+', '.join(SELECTED_SEED)+'}')
    print(f'canonical_species_formula: {CANONICAL_SPECIES_FORMULA}')
    print('PRIMARY_BRIDGE_CANDIDATES:')
    for cid,fam,dyn,status,bound in BRIDGE_CANDIDATES: print(f'  {cid} | family={fam} | dyn={dyn:.6g} | status={status}')
    print('EVIDENCE_STATUS:')
    for a,b,c,d in EVIDENCE_STATUS: print(f'  {a} | {b} | survives={c} | boundary={d}')
    print('CLAIM_BOUNDARY:')
    for st,cl,rs in CLAIM_BOUNDARY: print(f'  {st} | {cl} -- {rs}')
    print(f'PACK: {PACK_PATH}')
    print(f'SUMMARY: {SUMMARY_PATH}')
    print('NEXT: V12_9_public_note_or_V12_10_deep_GR_PDE')
    print('=== END COPY/PASTE R154 RESULT ===')
    return 0 if zip_ok and req_ok else 1
if __name__=='__main__': raise SystemExit(main())
