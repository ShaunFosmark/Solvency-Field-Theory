# FORCE_R144 - Bridge Candidate Robustness / Uncertainty Gate

VERDICT: BRIDGE CANDIDATE ROBUSTNESS / UNCERTAINTY SCREEN PASS / ROBUST HITS REPORTED, FINAL LAW OPEN

FREEZE_ID: SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM

candidate_freeze_hash: 621c0428aa796f871811316fd3a90b59976caebfac9deb05441c20db0b0180e9

## Candidate dynamic ranges

                             candidate_id      tier                   family     beta  gamma  dynamic_range  relation    factor  within_25pct endpoint_mode_pair
R137_transverse_phase_volume_6pi_exponent   primary compound_transverse_lens 0.299699   0.00  339287.651855 overshoot  1.003563          True           2 vs 1/2
          R137_oriented_modes_18_exponent   primary compound_transverse_lens 0.294993   0.00  323995.841536 shortfall  1.043479          True           2 vs 1/2
        R139_boundary_area_rho2_candidate   primary      boundary_insolvency 0.000000   2.00  287996.303588 shortfall  1.173914          True           2 vs 1/2
 R140B_partial_slot_beta_boundary_quarter secondary    partial_hybrid_screen 0.250000   0.25  294848.322718 shortfall  1.146634          True           2 vs 1/2
    R140B_partial_slot_beta_boundary_half secondary    partial_hybrid_screen 0.250000   0.50  416978.496831 overshoot  1.233361          True           2 vs 1/2
                     raw_feedback_control   control             raw_feedback 0.000000   0.00   17999.768974 shortfall 18.782630         False           2 vs 1/2


## Top robust matches

                             candidate_id    tier  mode_pair     F_ratio                     mass_pair  interval_low  interval_high  distance_pct  same_sector  lepton_lepton  quark_quark  endpoint_dynamic_range_hit
R137_transverse_phase_volume_6pi_exponent primary 3/4 vs 1/2   11.631553  charm_quark vs strange_quark     10.545455      16.750000           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary   1 vs 1/2   59.429930     strange_quark vs up_quark     28.571429      70.967742           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 5/4 vs 1/2  570.730586       charm_quark vs up_quark    414.285714     864.516129           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 3/4 vs 2/3    2.098749        down_quark vs up_quark      1.464286       3.419355           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary   1 vs 2/3   10.723288  charm_quark vs strange_quark     10.545455      16.750000           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 3/2 vs 2/3  797.574481       charm_quark vs up_quark    414.285714     864.516129           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 3/2 vs 2/3  797.574481    bottom_quark vs down_quark    779.245283    1065.853659           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 5/4 vs 3/4   49.067445     strange_quark vs up_quark     28.571429      70.967742           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 5/4 vs 3/4   49.067445 bottom_quark vs strange_quark     37.545455      54.625000           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 5/3 vs 3/4 2247.903789      bottom_quark vs up_quark   1475.000000    2819.354839           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary   4/3 vs 1   18.395161   strange_quark vs down_quark     15.094340      26.829268           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary   5/3 vs 1  439.956972       charm_quark vs up_quark    414.285714     864.516129           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 4/3 vs 5/4    1.915480        down_quark vs up_quark      1.464286       3.419355           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 5/3 vs 5/4   45.812530     strange_quark vs up_quark     28.571429      70.967742           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 5/3 vs 5/4   45.812530 bottom_quark vs strange_quark     37.545455      54.625000           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary   2 vs 5/4  594.479532       charm_quark vs up_quark    414.285714     864.516129           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary 5/3 vs 4/3   23.916995   strange_quark vs down_quark     15.094340      26.829268           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary   2 vs 4/3  310.355350     charm_quark vs down_quark    218.867925     326.829268           0.0         True          False         True                       False
R137_transverse_phase_volume_6pi_exponent primary   2 vs 5/3   12.976352  charm_quark vs strange_quark     10.545455      16.750000           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary 3/4 vs 1/2   11.528653  charm_quark vs strange_quark     10.545455      16.750000           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary   1 vs 1/2   58.557263     strange_quark vs up_quark     28.571429      70.967742           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary 5/4 vs 1/2  557.761969       charm_quark vs up_quark    414.285714     864.516129           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary 3/4 vs 2/3    2.093122        down_quark vs up_quark      1.464286       3.419355           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary   1 vs 2/3   10.631553  charm_quark vs strange_quark     10.545455      16.750000           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary 3/2 vs 2/3  778.507248       charm_quark vs up_quark    414.285714     864.516129           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary 5/4 vs 3/4   48.380498     strange_quark vs up_quark     28.571429      70.967742           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary 5/4 vs 3/4   48.380498 bottom_quark vs strange_quark     37.545455      54.625000           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary 5/3 vs 3/4 2185.946149      bottom_quark vs up_quark   1475.000000    2819.354839           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary   4/3 vs 1   18.202186   strange_quark vs down_quark     15.094340      26.829268           0.0         True          False         True                       False
          R137_oriented_modes_18_exponent primary   5/3 vs 1  430.365307       charm_quark vs up_quark    414.285714     864.516129           0.0         True          False         True                       False


## Threshold summary

                             candidate_id      tier                   family  dynamic_range  inside_interval  inside_interval_independent  robust_1pct  robust_1pct_independent  robust_5pct  robust_5pct_independent  same_sector_5pct_independent  lepton_5pct_independent  quark_5pct_independent  best_distance_pct_independent warning
                     raw_feedback_control   control             raw_feedback   17999.768974               36                           36           39                       39           51                       51                            27                        0                      27                            0.0    HIGH
        R139_boundary_area_rho2_candidate   primary      boundary_insolvency  287996.303588               35                           35           38                       38           46                       46                            29                        1                      28                            0.0    HIGH
R137_transverse_phase_volume_6pi_exponent   primary compound_transverse_lens  339287.651855               33                           32           35                       34           46                       45                            24                        1                      23                            0.0    HIGH
          R137_oriented_modes_18_exponent   primary compound_transverse_lens  323995.841536               32                           32           36                       36           46                       45                            23                        0                      23                            0.0    HIGH
 R140B_partial_slot_beta_boundary_quarter secondary    partial_hybrid_screen  294848.322718               35                           35           37                       37           49                       49                            25                        0                      25                            0.0    HIGH
    R140B_partial_slot_beta_boundary_half secondary    partial_hybrid_screen  416978.496831               31                           31           33                       33           40                       40                            23                        0                      23                            0.0    HIGH


## Claim boundary

    status                                                                                  claim                                                                                          reason
YES_SCREEN R144 stress-tests frozen R141/R142 bridge candidates under mass uncertainty intervals.                            Candidate values are hashed before uncertainty intervals are loaded.
        NO                        R144 retunes candidate exponents, boundary powers, or mappings.                                All beta/gamma definitions are fixed before uncertainty loading.
YES_SCREEN                         R144 reports robust interval hits and separates endpoint hits. Inside-interval and 1%/5% robust hits are reported separately from full-span endpoint evidence.
        NO                                                R144 selects a final physical mass law.    Robustness evidence is screening-only and retains multiple-comparison/quark-scheme warnings.
        NO                                       R144 maps rho modes to Standard Model particles.                                  Only pairwise ratios are compared; no identities are assigned.
        NO                                               R144 closes true GR/PDE bridge dynamics.                                                     The field-equation derivation remains open.