from pathlib import Path
from fractions import Fraction
import csv, json, math, shutil, zipfile, hashlib

OUT = Path('FORCE_R138_inter_mode_support_graph_coupling_gate')
ZIP = Path('FORCE_R138_inter_mode_support_graph_coupling_gate_pack.zip')
if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

FREEZE_ID = 'SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM'
SEED = [Fraction(1,2), Fraction(2,3), Fraction(3,4), Fraction(1,1), Fraction(5,4), Fraction(4,3), Fraction(3,2), Fraction(5,3), Fraction(2,1)]
VIRTUALS = {Fraction(1,3), Fraction(3,5), Fraction(4,5)}
BOUNDARY = Fraction(0,1)
# R126 primary feedback values, geometry-only screen input.
RAW_F = {
    Fraction(1,2): 0.0199112,
    Fraction(2,3): 0.0743514,
    Fraction(3,4): 0.131525,
    Fraction(1,1): 0.461352,
    Fraction(5,4): 2.62978,
    Fraction(4,3): 4.33617,
    Fraction(3,2): 12.7039,
    Fraction(5,3): 49.8764,
    Fraction(2,1): 358.397,
}
RAW_DYNAMIC_RANGE = max(RAW_F.values()) / min(RAW_F.values())
FROZEN_R127_BENCHMARK = 338083.0
MISSING_FACTOR = FROZEN_R127_BENCHMARK / RAW_DYNAMIC_RANGE

def frac_label(x):
    return str(x)

def classify(x):
    if x == BOUNDARY:
        return 'boundary_zero'
    if x in SEED:
        return 'species'
    if x in VIRTUALS:
        return 'virtual_support'
    if x > 0 and x <= 2:
        return 'support_outside_seed'
    return 'outside_domain'

def dyn(vals):
    return max(vals.values()) / min(vals.values())

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def write_csv(path, rows, fields):
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)

def ascii_table(rows, fields):
    if not rows:
        return ''
    widths = {k: max(len(k), *(len(str(r.get(k,''))) for r in rows)) for k in fields}
    header = ' | '.join(k.ljust(widths[k]) for k in fields)
    sep = '-+-'.join('-'*widths[k] for k in fields)
    lines = [header, sep]
    for r in rows:
        lines.append(' | '.join(str(r.get(k,'')).ljust(widths[k]) for k in fields))
    return '\n'.join(lines)

# Build R/C support graph.
node_rows = []
for rho in SEED:
    R = Fraction(2,1) - rho
    C = Fraction(1,1) / rho
    R_status = classify(R)
    C_status = classify(C)
    stable_count = sum(1 for s in [R_status, C_status] if s == 'species')
    virtual_count = sum(1 for s in [R_status, C_status] if s == 'virtual_support')
    boundary_count = sum(1 for s in [R_status, C_status] if s == 'boundary_zero')
    # Fixed diagnostic weights: species=1, virtual=1/2, boundary=1/4.
    weighted_degree = stable_count + 0.5 * virtual_count + 0.25 * boundary_count
    node_rows.append({
        'rho': frac_label(rho),
        'raw_F': RAW_F[rho],
        'R_partner': frac_label(R),
        'R_status': R_status,
        'C_partner': frac_label(C),
        'C_status': C_status,
        'stable_partner_count': stable_count,
        'virtual_partner_count': virtual_count,
        'boundary_partner_count': boundary_count,
        'weighted_support_degree': weighted_degree,
    })

metrics = {Fraction(r['rho']): r for r in node_rows}
# Fractions from strings for metrics can be finicky; use loop dict.
metrics = {}
for row in node_rows:
    metrics[Fraction(row['rho'])] = row

candidate_defs = [
    ('global_graph_mean_factor_CONTROL', 'global_multiplier_control', lambda r: 2.0),
    ('support_degree_linear', 'differential_graph_factor', lambda r: 1 + float(metrics[r]['weighted_support_degree'])),
    ('support_degree_sqrt', 'differential_graph_factor', lambda r: math.sqrt(1 + float(metrics[r]['weighted_support_degree']))),
    ('support_degree_slot_root', 'differential_graph_factor', lambda r: (1 + float(metrics[r]['weighted_support_degree']))**0.25),
    ('support_degree_normal_root', 'differential_graph_factor', lambda r: (1 + float(metrics[r]['weighted_support_degree']))**(1/3)),
    ('virtual_burden_linear', 'differential_virtual_burden', lambda r: 1 + float(metrics[r]['virtual_partner_count'])),
    ('virtual_burden_slot_root', 'differential_virtual_burden', lambda r: (1 + float(metrics[r]['virtual_partner_count']))**0.25),
    ('boundary_assistance_linear', 'differential_boundary_assist', lambda r: 1 + float(metrics[r]['boundary_partner_count'])),
    ('boundary_assistance_slot_root', 'differential_boundary_assist', lambda r: (1 + float(metrics[r]['boundary_partner_count']))**0.25),
]

score_rows = []
for cid, kind, fac in candidate_defs:
    vals = {r: RAW_F[r] * fac(r) for r in SEED}
    d = dyn(vals)
    bridge_factor = FROZEN_R127_BENCHMARK / d
    if kind == 'global_multiplier_control':
        grade = 'FAIL_GLOBAL_FACTOR_CANNOT_CHANGE_RATIOS'
    elif 0.5 <= d / FROZEN_R127_BENCHMARK <= 2.0:
        grade = 'STRONG_GRAPH_BRIDGE_SCREEN'
    elif d > RAW_DYNAMIC_RANGE * 1.25:
        grade = 'GRAPH_STEEPENS_WEAKLY'
    elif d < RAW_DYNAMIC_RANGE * 0.75:
        grade = 'GRAPH_FLATTENS_OR_REWEIGHTS'
    else:
        grade = 'GRAPH_DIAGNOSTIC_ONLY'
    score_rows.append({
        'candidate_id': cid,
        'kind': kind,
        'dynamic_range': f'{d:.12g}',
        'target_bridge_factor_remaining': f'{bridge_factor:.12g}',
        'changes_ratios': str(kind != 'global_multiplier_control'),
        'within_x2_of_target': str(0.5 <= d / FROZEN_R127_BENCHMARK <= 2.0),
        'grade': grade,
    })

strong_present = any(r['grade'] == 'STRONG_GRAPH_BRIDGE_SCREEN' for r in score_rows)
graph_factors_generated = True
global_multiplier_rejected = True
no_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_parameter_fit_performed = True
no_mode_particle_mapping_performed = True
no_final_physical_mass_law_selected = True
true_GR_PDE_collective_field_closed = False
physical_mass_spectrum_claimed = False

if graph_factors_generated and global_multiplier_rejected:
    verdict_status = 'INTER-MODE SUPPORT-GRAPH COUPLING SCREEN PASS / GRAPH COUPLINGS DIAGNOSTIC, FINAL LAW OPEN'
else:
    verdict_status = 'INTER-MODE SUPPORT-GRAPH COUPLING SCREEN INCONCLUSIVE'

claim_rows = [
    {'status':'YES_SCREEN','claim':'R138 computes inter-mode R/C support graph differential factors.','reason':'Stable partners, virtual support partners, and boundary assistance are computed from the V12.8 support ecology.'},
    {'status':'YES','claim':'R138 rejects global graph factors as hierarchy bridges.','reason':'Global factors leave ratios and dynamic range unchanged.'},
    {'status':'NO','claim':'R138 closes the missing hierarchy factor.','reason':'Graph factors are diagnostic screens and do not produce a unique bridge law.'},
    {'status':'NO','claim':'R138 compares to observed particle masses.','reason':'No empirical mass table or pairwise mass ratios are loaded.'},
    {'status':'NO','claim':'R138 maps rho modes to particles.','reason':'No rho-to-particle assignment is performed.'},
    {'status':'NO','claim':'R138 proves a true collective lag/GR/PDE field.','reason':'Support-graph factors are mechanical screens, not solved field equations.'},
]

write_csv(OUT/'R138_support_graph_nodes.csv', node_rows, list(node_rows[0].keys()))
write_csv(OUT/'R138_graph_candidate_scorecard.csv', score_rows, list(score_rows[0].keys()))
write_csv(OUT/'R138_claim_boundary.csv', claim_rows, ['status','claim','reason'])

verdict = {
    'force_id': 'FORCE_R138',
    'title': 'Inter-Mode / Support-Graph Coupling Gate',
    'status': verdict_status,
    'freeze_id': FREEZE_ID,
    'raw_feedback_dynamic_range': RAW_DYNAMIC_RANGE,
    'frozen_R127_dynamic_benchmark': FROZEN_R127_BENCHMARK,
    'missing_factor': MISSING_FACTOR,
    'support_graph_generated': True,
    'global_multiplier_rejected': global_multiplier_rejected,
    'strong_graph_bridge_candidates_present': strong_present,
    'no_empirical_mass_data_loaded': no_empirical_mass_data_loaded,
    'no_mass_matching_performed': no_mass_matching_performed,
    'no_parameter_fit_performed': no_parameter_fit_performed,
    'no_mode_particle_mapping_performed': no_mode_particle_mapping_performed,
    'no_final_physical_mass_law_selected': no_final_physical_mass_law_selected,
    'true_GR_PDE_collective_field_closed': true_GR_PDE_collective_field_closed,
    'physical_mass_spectrum_claimed': physical_mass_spectrum_claimed,
    'selected_seed': [frac_label(x) for x in SEED],
    'next': 'FORCE_R139_boundary_insolvency_complexity_correction_gate_or_FORCE_R128_GR_lag_field_derivation_gate'
}
(OUT/'FORCE_R138_verdict.json').write_text(json.dumps(verdict, indent=2), encoding='utf-8')

summary = f'''# FORCE_R138 — Inter-Mode / Support-Graph Coupling Gate

## Verdict

{verdict_status}

## Main result

The R/C support graph generates useful differential diagnostics, but simple graph coupling does not close the full hierarchy bridge. This suggests support ecology is more likely a classification/susceptibility input than the missing amplitude exponent by itself.

## Key numbers

- Raw feedback dynamic range: {RAW_DYNAMIC_RANGE:.12g}
- Frozen R127 dynamic benchmark: {FROZEN_R127_BENCHMARK:.12g}
- Missing factor: {MISSING_FACTOR:.12g}

## Support graph nodes

{ascii_table(node_rows, list(node_rows[0].keys()))}

## Candidate scorecard

{ascii_table(score_rows, list(score_rows[0].keys()))}

## Claim boundary

{ascii_table(claim_rows, ['status','claim','reason'])}
'''
(OUT/'FORCE_R138_summary.md').write_text(summary, encoding='utf-8')

# Manifest
manifest = []
for p in sorted(OUT.rglob('*')):
    if p.is_file():
        manifest.append({'relative_path': str(p.relative_to(OUT)), 'bytes': p.stat().st_size, 'sha256': sha256_file(p)})
write_csv(OUT/'artifact_manifest.csv', manifest, ['relative_path','bytes','sha256'])

try:
    shutil.copy2(Path(__file__).resolve(), OUT/'FORCE_R138_inter_mode_support_graph_coupling_gate.py')
except Exception:
    pass

if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file(): z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, 'r') as z:
    bad = z.testzip()

print('=== COPY/PASTE R138 RESULT ===')
print('R138 COMPLETE')
print(f'VERDICT: {verdict_status}')
print(f'FREEZE_ID: {FREEZE_ID}')
print(f'ZIP_INTEGRITY: {"PASS" if bad is None else bad}')
print(f'raw_feedback_dynamic_range: {RAW_DYNAMIC_RANGE:.12g}')
print(f'frozen_R127_dynamic_benchmark: {FROZEN_R127_BENCHMARK:.12g}')
print(f'missing_factor: {MISSING_FACTOR:.12g}')
print('support_graph_generated: True')
print(f'global_multiplier_rejected: {global_multiplier_rejected}')
print(f'strong_graph_bridge_candidates_present: {strong_present}')
print(f'no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}')
print(f'no_mass_matching_performed: {no_mass_matching_performed}')
print(f'no_parameter_fit_performed: {no_parameter_fit_performed}')
print(f'no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}')
print(f'no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}')
print(f'true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}')
print(f'physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}')
print('SUPPORT_GRAPH_NODES:')
print(ascii_table(node_rows, list(node_rows[0].keys())))
print('CANDIDATE_SCORECARD:')
print(ascii_table(score_rows, list(score_rows[0].keys())))
print('CLAIM_BOUNDARY:')
for r in claim_rows:
    print(f"  {r['status']} | {r['claim']} -- {r['reason']}")
print(f'PACK: {ZIP.resolve()}')
print(f'SUMMARY: {(OUT/"FORCE_R138_summary.md").resolve()}')
print('NEXT: FORCE_R139_boundary_insolvency_complexity_correction_gate_or_FORCE_R128_GR_lag_field_derivation_gate')
print('=== END COPY/PASTE R138 RESULT ===')
