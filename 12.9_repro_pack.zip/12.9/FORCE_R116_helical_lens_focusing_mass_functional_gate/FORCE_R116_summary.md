# FORCE_R116 — Helical Lens / Focusing Mass Functional Gate

## Verdict

BOXED: HELICAL LENS FOCUSING FUNCTIONAL CANDIDATE PASS / MASS MATCHING, PDE SELF-ENERGY, AND PHYSICAL SPECTRUM OPEN

## V12.9-style conceptual seed

BOXED:
Mass is treated as a candidate focusing functional of a stable one-speed closure mode.

BOXED:
Gravity is interpreted as the macroscopic gradient of that focusing/concentration.

BOXED:
The V12.8 nine-mode set remains a mechanical/operator-geometric seed, not a confirmed physical spectrum.

## V12.8 inherited species formula

BOXED:
Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}

## Selected seed under audit

BOXED:
{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}

## What R116 closes

BOXED:
A geometry-only candidate F(rho) roster and blind ratio tables were generated before any empirical mass comparison.

## What R116 does not close

BOXED:
No physical mass spectrum is claimed.

BOXED:
No Standard Model mass matching is performed.

BOXED:
No GR/PDE self-energy derivation is closed.

BOXED:
No virtual support is promoted to stable species.

## Key booleans

- candidate_functional_roster_closed: True
- geometry_table_generated: True
- seed_all_computed: True
- virtuals_computed_not_promoted: True
- all_functionals_finite_positive: True
- blind_ratios_generated: True
- no_empirical_mass_data_loaded: True
- no_parameter_fit_performed: True
- dynamic_GR_self_energy_closed: False
- physical_mass_spectrum_claimed: False

## Gate audit

                               test result                                                                                        interpretation
           geometry_table_generated   PASS Seed, virtual support, and control modes were assigned geometry-native helical/toroidal lens metrics.
                  seed_all_computed   PASS                                                             All nine V12.8 seed modes were evaluated.
     virtuals_computed_not_promoted   PASS                            Virtual support channels receive F-values but are not promoted to species.
    all_functionals_finite_positive   PASS                      All candidate focusing functionals are finite and positive on the audited modes.
             blind_ratios_generated   PASS                            Blind relative ratios were generated before any empirical mass comparison.
regularization_sensitivity_reported   PASS                                 Regularized self-overlap sensitivity was reported for the seed modes.
      no_empirical_mass_data_loaded   PASS                            No particle mass table or Standard Model target ratios are loaded in R116.
         no_parameter_fit_performed   PASS                                                    No parameter is optimized against observed masses.
 candidate_functional_roster_closed   PASS                      R116 closes a candidate geometry-only F(rho) roster, not a physical mass theory.
      dynamic_GR_self_energy_closed   OPEN                                                    A true GR/PDE self-energy derivation remains open.
     physical_mass_spectrum_claimed   OPEN                                                                 No physical mass spectrum is claimed.
           SM_mass_matching_claimed   OPEN                                                           No Standard Model mass matching is claimed.

## Seed focusing preview

rho  rho_float  numerator_p  denominator_q  curve_length  bend_energy_int_kappa2_ds  self_overlap_eps_0p06  overlap_density_eps_0p06  analytic_lens_proxy
1/2   0.500000            1              2     12.664702                  12.600922              92.807182                  0.578618             0.111803
2/3   0.666667            2              3     19.108809                  18.625845             196.207662                  0.537339             0.246533
3/4   0.750000            3              4     25.562845                  24.706949             340.907999                  0.521698             0.337500
  1   1.000000            1              1      6.482041                   6.161693              30.923023                  0.735967             0.707107
5/4   1.250000            5              4     26.340344                  25.698220             361.556470                  0.521115             1.220108
4/3   1.333333            4              3     19.886852                  19.748082             211.713494                  0.535324             1.422222
3/2   1.500000            3              2     13.440635                  14.095973             103.182880                  0.571174             1.872113
5/3   1.666667            5              3     20.447655                  23.202292             223.292450                  0.534056             2.381925
  2   2.000000            2              1      7.042176                   9.804633              34.910386                  0.703949             3.577709

## Candidate functional preview

                 functional_id  seed_dynamic_range_max_over_min seed_min_rho_at_function_min seed_max_rho_at_function_max  selected_as_physical_mass_law
                     rho_float                         4.000000                          1/2                            2                          False
                  curve_length                         4.063588                            1                          5/4                          False
                mean_curvature                         1.178741                            1                            2                          False
     bend_energy_int_kappa2_ds                         4.170643                            1                          5/4                          False
         self_overlap_eps_0p03                        10.677463                            1                          5/4                          False
         self_overlap_eps_0p06                        11.692145                            1                          5/4                          False
         self_overlap_eps_0p12                        12.938239                            1                          5/4                          False
      overlap_density_eps_0p03                         1.546505                          5/4                            1                          False
      overlap_density_eps_0p06                         1.412294                          5/4                            1                          False
      overlap_density_eps_0p12                         1.276325                          3/4                            1                          False
analytic_path_sqrt_1_plus_rho2                         2.000000                          1/2                            2                          False
      analytic_curvature_proxy                         4.000000                          1/2                            2                          False
       analytic_pass_curvature                        16.000000                          1/2                            2                          False
           analytic_lens_proxy                        32.000000                          1/2                            2                          False

## Virtual support status

rho                       class support_role  species_accept  geometric_F_values_computed  promoted_to_species_by_F species_rejection_reason                                                                                                   interpretation
1/3 virtual_support_not_species support_only           False                         True                     False  fails_binary_no_overlap Focusing values may be computed for support channels, but support-only modes are not promoted to stable species.
3/5 virtual_support_not_species support_only           False                         True                     False      fails_slot_capacity Focusing values may be computed for support channels, but support-only modes are not promoted to stable species.
4/5 virtual_support_not_species support_only           False                         True                     False      fails_slot_capacity Focusing values may be computed for support channels, but support-only modes are not promoted to stable species.

## Claim boundary

                                                                               claim status                                                                                                           reason
                 R116 defines geometry-native candidate focusing functionals F(rho).    YES               Analytic helical proxies and regularized toroidal self-overlap metrics are computed from rho only.
                                   R116 compares F(rho) to observed particle masses.     NO                                                              No empirical masses or SM target ratios are loaded.
                                             R116 selects a final physical mass law.     NO                                           The candidate roster is geometry-only; no candidate is chosen by data.
R116 promotes virtual supports to stable species if their F-values look interesting.     NO                       Species projection remains inherited from V12.8; virtual supports remain species-inactive.
                                  R116 closes a true GR/PDE self-energy calculation.     NO The self-overlap integral is a toy geometry/focusing proxy, not a solved Einstein-field self-energy calculation.
                                 R116 claims the nine modes are confirmed particles.     NO                                                      The nine modes remain a mechanical/operator-geometric seed.

## Next gate plan

 next_gate                                        title                                                                                                                  goal                                                                                          must_not_do
FORCE_R117      Blind F(rho) Mass-Ratio Comparison Gate Freeze candidate F(rho) functions first, then compare blind ratios to external particle-mass ratios without retuning.     Do not modify F(rho) after seeing mass-ratio comparisons; do not map modes to particles by hand.
FORCE_R118 Analytic Helical Self-Energy Derivation Gate     Try to replace toy regularized self-overlap with a principled action/PDE or GR-compatible self-energy derivation. Do not claim physical masses until the field/action derivation and mass comparison survive controls.
