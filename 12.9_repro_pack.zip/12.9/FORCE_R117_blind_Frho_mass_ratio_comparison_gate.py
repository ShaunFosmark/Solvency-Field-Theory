# -*- coding: utf-8 -*-
"""
FORCE_R117 — Blind F(rho) Mass-Ratio Comparison Gate

Purpose
-------
Freeze the R116 geometry-native focusing functionals first, then compare their
blind pairwise ratios against an external nine charged-fermion mass table.

Strict boundaries
-----------------
- Loads empirical masses only after the R116 F(rho) roster is frozen in this file.
- Does not retune, refit, exponent-adjust, or remap F(rho) after seeing masses.
- Does not select a final physical mass law.
- Does not map individual rho modes to particles by hand.
- Does not claim a confirmed physical spectrum.
- Does not claim full PDE/GR self-energy closure.

Interpretation
--------------
This is a falsification/screening gate. Pairwise ratio hits are interesting
signals only. They are not proof, especially because many pairwise comparisons
create multiple-comparison risk. A full-spectrum monotonic dynamic-range audit
is included as a hard sanity check.
"""

from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import hashlib
import itertools
import json
import math
import shutil
import textwrap
import zipfile
from typing import Dict, Iterable, List, Tuple

import pandas as pd

try:
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except Exception:
    HAVE_MPL = False

ROOT = Path.cwd()
OUT = Path("FORCE_R117_blind_Frho_mass_ratio_comparison_gate")
ZIP = Path("FORCE_R117_blind_Frho_mass_ratio_comparison_gate_pack.zip")
PLOTS = OUT / "plots"

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS.mkdir(parents=True)

FORCE_ID = "FORCE_R117"
TITLE = "Blind F(rho) Mass-Ratio Comparison Gate"
R116_STATUS_REQUIRED = "HELICAL LENS FOCUSING FUNCTIONAL CANDIDATE PASS"

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def frac_label(x) -> str:
    if isinstance(x, Fraction):
        return str(x)
    return str(x)


def label_set(xs: Iterable[Fraction]) -> str:
    return "{" + ", ".join(frac_label(x) for x in xs) + "}"


def safe_ratio(a: float, b: float) -> float:
    a = float(a)
    b = float(b)
    if a <= 0 or b <= 0:
        raise ValueError("Ratios require positive values")
    return max(a, b) / min(a, b)


def rel_error(pred: float, target: float) -> float:
    return abs(pred - target) / target


def log_error(pred: float, target: float) -> float:
    return abs(math.log(pred / target))


def bool_status(x: bool) -> str:
    return "PASS" if x else "WARN"


def write_table(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False)


def find_optional_r116_artifacts() -> pd.DataFrame:
    """Fast, shallow optional inventory for nearby R116 artifacts.

    Avoids deep recursive scans because ChatGPT/container sandboxes and some
    Windows work folders may contain many nested packs. This inventory is
    optional: R117 is self-contained because the frozen R116 F-values are
    embedded above.
    """
    rows = []
    seen = set()
    bases = [ROOT]
    try:
        bases.extend([x for x in ROOT.iterdir() if x.is_dir() and ("R116" in x.name or "12.9" in x.name or "12_9" in x.name)])
    except Exception:
        pass

    patterns = [
        "FORCE_R116*",
        "*R116*summary.md",
        "*R116*verdict.json",
        "*R116*pack.zip",
        "*R116*.csv",
    ]

    for base in bases:
        for pattern in patterns:
            for p in base.glob(pattern):
                if not p.is_file():
                    continue
                if p in seen:
                    continue
                try:
                    if OUT in p.parents:
                        continue
                except Exception:
                    pass
                seen.add(p)
                rows.append({
                    "path": str(p),
                    "name": p.name,
                    "bytes": p.stat().st_size,
                    "sha256": sha256_file(p),
                })
    return pd.DataFrame(rows)


def simple_pdf_from_text(title: str, text: str, path: Path) -> None:
    """Dependency-free plain PDF writer for the report preview."""
    replacements = {
        "rho": "rho",
        "ρ": "rho",
        "∩": " intersection ",
        "≤": "<=",
        "≥": ">=",
        "Ω": "Omega",
        "—": "-",
        "–": "-",
        "“": '"',
        "”": '"',
        "’": "'",
        "‘": "'",
        "×": "x",
    }
    raw = title + "\n" + "=" * min(80, len(title)) + "\n\n" + text
    for k, v in replacements.items():
        raw = raw.replace(k, v)
    raw = raw.encode("latin-1", "replace").decode("latin-1")
    lines: List[str] = []
    for line in raw.splitlines():
        if not line.strip():
            lines.append("")
        else:
            lines.extend(textwrap.wrap(line, width=90, replace_whitespace=False) or [""])
    max_lines = 58
    pages = [lines[i:i + max_lines] for i in range(0, len(lines), max_lines)] or [["Empty"]]

    def esc(s: str) -> str:
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")

    objects: Dict[int, bytes] = {}
    objects[1] = b"<< /Type /Catalog /Pages 2 0 R >>"
    objects[3] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
    page_ids = []
    for i, page_lines in enumerate(pages):
        content_id = 4 + 2 * i
        page_id = 5 + 2 * i
        page_ids.append(page_id)
        content = ["BT", "/F1 10 Tf", "12 TL", "54 748 Td"]
        for line in page_lines:
            content.append(f"({esc(line)}) Tj")
            content.append("T*")
        content.append("ET")
        stream = "\n".join(content).encode("latin-1", "replace")
        objects[content_id] = (
            f"<< /Length {len(stream)} >>\nstream\n".encode("latin-1")
            + stream
            + b"\nendstream"
        )
        objects[page_id] = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
            f"/Resources << /Font << /F1 3 0 R >> >> "
            f"/Contents {content_id} 0 R >>"
        ).encode("latin-1")
    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects[2] = f"<< /Type /Pages /Kids [ {kids} ] /Count {len(page_ids)} >>".encode("latin-1")
    max_id = max(objects)
    pdf = bytearray(b"%PDF-1.4\n")
    offsets = [0] * (max_id + 1)
    for obj_id in range(1, max_id + 1):
        offsets[obj_id] = len(pdf)
        pdf.extend(f"{obj_id} 0 obj\n".encode("latin-1"))
        pdf.extend(objects[obj_id])
        pdf.extend(b"\nendobj\n")
    xref_offset = len(pdf)
    pdf.extend(f"xref\n0 {max_id + 1}\n".encode("latin-1"))
    pdf.extend(b"0000000000 65535 f \n")
    for obj_id in range(1, max_id + 1):
        pdf.extend(f"{offsets[obj_id]:010d} 00000 n \n".encode("latin-1"))
    pdf.extend(
        f"trailer\n<< /Size {max_id + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_offset}\n%%EOF\n".encode("latin-1")
    )
    path.write_bytes(bytes(pdf))


# -----------------------------------------------------------------------------
# 1. Frozen R116 candidate focusing functionals.
#    These values are copied from the R116 output and must not be edited after
#    loading the empirical mass table below.
# -----------------------------------------------------------------------------

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUAL_SUPPORTS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

# R116 seed focusing preview columns.
R116_SEED_ROWS = [
    {"rho": Fraction(1, 2), "rho_float": 0.500000, "curve_length": 12.664702, "bend_energy_int_kappa2_ds": 12.600922, "self_overlap_eps_0p06": 92.807182, "overlap_density_eps_0p06": 0.578618, "analytic_lens_proxy": 0.111803},
    {"rho": Fraction(2, 3), "rho_float": 0.666667, "curve_length": 19.108809, "bend_energy_int_kappa2_ds": 18.625845, "self_overlap_eps_0p06": 196.207662, "overlap_density_eps_0p06": 0.537339, "analytic_lens_proxy": 0.246533},
    {"rho": Fraction(3, 4), "rho_float": 0.750000, "curve_length": 25.562845, "bend_energy_int_kappa2_ds": 24.706949, "self_overlap_eps_0p06": 340.907999, "overlap_density_eps_0p06": 0.521698, "analytic_lens_proxy": 0.337500},
    {"rho": Fraction(1, 1), "rho_float": 1.000000, "curve_length": 6.482041, "bend_energy_int_kappa2_ds": 6.161693, "self_overlap_eps_0p06": 30.923023, "overlap_density_eps_0p06": 0.735967, "analytic_lens_proxy": 0.707107},
    {"rho": Fraction(5, 4), "rho_float": 1.250000, "curve_length": 26.340344, "bend_energy_int_kappa2_ds": 25.698220, "self_overlap_eps_0p06": 361.556470, "overlap_density_eps_0p06": 0.521115, "analytic_lens_proxy": 1.220108},
    {"rho": Fraction(4, 3), "rho_float": 1.333333, "curve_length": 19.886852, "bend_energy_int_kappa2_ds": 19.748082, "self_overlap_eps_0p06": 211.713494, "overlap_density_eps_0p06": 0.535324, "analytic_lens_proxy": 1.422222},
    {"rho": Fraction(3, 2), "rho_float": 1.500000, "curve_length": 13.440635, "bend_energy_int_kappa2_ds": 14.095973, "self_overlap_eps_0p06": 103.182880, "overlap_density_eps_0p06": 0.571174, "analytic_lens_proxy": 1.872113},
    {"rho": Fraction(5, 3), "rho_float": 1.666667, "curve_length": 20.447655, "bend_energy_int_kappa2_ds": 23.202292, "self_overlap_eps_0p06": 223.292450, "overlap_density_eps_0p06": 0.534056, "analytic_lens_proxy": 2.381925},
    {"rho": Fraction(2, 1), "rho_float": 2.000000, "curve_length": 7.042176, "bend_energy_int_kappa2_ds": 9.804633, "self_overlap_eps_0p06": 34.910386, "overlap_density_eps_0p06": 0.703949, "analytic_lens_proxy": 3.577709},
]

frozen_rows = []
for row in R116_SEED_ROWS:
    rho = row["rho"]
    x = float(rho)
    enriched = dict(row)
    # Additional analytic proxies from the R116 analytic family.
    enriched["analytic_path_sqrt_1_plus_rho2"] = math.sqrt(1.0 + x * x)
    enriched["analytic_curvature_proxy"] = (x * x) / (1.0 + x * x)
    enriched["analytic_pass_curvature"] = x * x
    # Same closed form as the R116 analytic_lens_proxy preview.
    enriched["analytic_lens_proxy_recomputed"] = (x ** 3) / math.sqrt(1.0 + x * x)
    frozen_rows.append(enriched)

frozen_functional_values = pd.DataFrame(frozen_rows)
frozen_functional_values["rho"] = frozen_functional_values["rho"].map(frac_label)

FROZEN_FUNCTIONALS = [
    "rho_float",
    "curve_length",
    "bend_energy_int_kappa2_ds",
    "self_overlap_eps_0p06",
    "overlap_density_eps_0p06",
    "analytic_path_sqrt_1_plus_rho2",
    "analytic_curvature_proxy",
    "analytic_pass_curvature",
    "analytic_lens_proxy",
    "analytic_lens_proxy_recomputed",
]

candidate_functionals_frozen_before_mass_loading = True

# -----------------------------------------------------------------------------
# 2. External screening mass table.
#    Values are central-value screening inputs only. Light-quark masses are
#    scheme/scale dependent; no physical claim is made from this table alone.
# -----------------------------------------------------------------------------

MASS_TABLE_SOURCE_NOTE = (
    "PDG-style screening table. Charged leptons are pole/rest masses; light and "
    "heavy quarks are quoted as conventional central-value quark-mass inputs "
    "and are scheme/scale dependent. This table is for blind ratio screening, "
    "not a final physical matching claim."
)

particle_mass_rows = [
    {"particle": "electron", "symbol": "e", "sector": "charged_lepton", "mass_MeV": 0.510998950, "mass_type": "rest/pole", "screening_note": "high precision charged lepton"},
    {"particle": "muon", "symbol": "mu", "sector": "charged_lepton", "mass_MeV": 105.6583755, "mass_type": "rest/pole", "screening_note": "high precision charged lepton"},
    {"particle": "tau", "symbol": "tau", "sector": "charged_lepton", "mass_MeV": 1776.86, "mass_type": "rest/pole", "screening_note": "charged lepton"},
    {"particle": "up_quark", "symbol": "u", "sector": "quark", "mass_MeV": 2.16, "mass_type": "MSbar-ish screening central", "screening_note": "scheme/scale dependent light quark"},
    {"particle": "down_quark", "symbol": "d", "sector": "quark", "mass_MeV": 4.67, "mass_type": "MSbar-ish screening central", "screening_note": "scheme/scale dependent light quark"},
    {"particle": "strange_quark", "symbol": "s", "sector": "quark", "mass_MeV": 93.4, "mass_type": "MSbar-ish screening central", "screening_note": "scheme/scale dependent light quark"},
    {"particle": "charm_quark", "symbol": "c", "sector": "quark", "mass_MeV": 1270.0, "mass_type": "MSbar-ish screening central", "screening_note": "scheme/scale dependent heavy quark"},
    {"particle": "bottom_quark", "symbol": "b", "sector": "quark", "mass_MeV": 4180.0, "mass_type": "MSbar-ish screening central", "screening_note": "scheme/scale dependent heavy quark"},
    {"particle": "top_quark", "symbol": "t", "sector": "quark", "mass_MeV": 172570.0, "mass_type": "mass parameter screening central", "screening_note": "top mass interpretation is subtle"},
]
particle_mass_table = pd.DataFrame(particle_mass_rows)
empirical_mass_data_loaded = True

# -----------------------------------------------------------------------------
# 3. Ratio tables.
# -----------------------------------------------------------------------------

functional_ratio_rows = []
for fid in FROZEN_FUNCTIONALS:
    vals = frozen_functional_values[["rho", fid]].copy()
    for a, b in itertools.combinations(vals.to_dict("records"), 2):
        ra, rb = a["rho"], b["rho"]
        fa, fb = float(a[fid]), float(b[fid])
        ratio = safe_ratio(fa, fb)
        high_rho = ra if fa >= fb else rb
        low_rho = rb if fa >= fb else ra
        functional_ratio_rows.append({
            "functional_id": fid,
            "rho_a": ra,
            "rho_b": rb,
            "F_a": fa,
            "F_b": fb,
            "ratio_ge_1": ratio,
            "higher_F_rho": high_rho,
            "lower_F_rho": low_rho,
        })
functional_ratio_table = pd.DataFrame(functional_ratio_rows)

mass_ratio_rows = []
for a, b in itertools.combinations(particle_mass_table.to_dict("records"), 2):
    pa, pb = a["particle"], b["particle"]
    ma, mb = float(a["mass_MeV"]), float(b["mass_MeV"])
    ratio = safe_ratio(ma, mb)
    mass_ratio_rows.append({
        "particle_a": pa,
        "particle_b": pb,
        "sector_a": a["sector"],
        "sector_b": b["sector"],
        "mass_a_MeV": ma,
        "mass_b_MeV": mb,
        "mass_ratio_ge_1": ratio,
        "heavier_particle": pa if ma >= mb else pb,
        "lighter_particle": pb if ma >= mb else pa,
        "same_sector": a["sector"] == b["sector"],
    })
mass_ratio_table = pd.DataFrame(mass_ratio_rows)

match_rows = []
for frow in functional_ratio_table.to_dict("records"):
    pred = float(frow["ratio_ge_1"])
    for mrow in mass_ratio_table.to_dict("records"):
        target = float(mrow["mass_ratio_ge_1"])
        re = rel_error(pred, target)
        le = log_error(pred, target)
        match_rows.append({
            "functional_id": frow["functional_id"],
            "rho_pair": frow["rho_a"] + " vs " + frow["rho_b"],
            "higher_F_rho": frow["higher_F_rho"],
            "lower_F_rho": frow["lower_F_rho"],
            "F_ratio_ge_1": pred,
            "particle_pair": mrow["particle_a"] + " vs " + mrow["particle_b"],
            "heavier_particle": mrow["heavier_particle"],
            "lighter_particle": mrow["lighter_particle"],
            "mass_ratio_ge_1": target,
            "same_sector": mrow["same_sector"],
            "relative_error": re,
            "percent_error": 100.0 * re,
            "abs_log_error": le,
            "hit_1pct": re <= 0.01,
            "hit_5pct": re <= 0.05,
            "hit_10pct": re <= 0.10,
        })
blind_ratio_matches = pd.DataFrame(match_rows)
blind_ratio_matches = blind_ratio_matches.sort_values(["relative_error", "functional_id"]).reset_index(drop=True)

best_matches_by_functional = (
    blind_ratio_matches.sort_values("relative_error")
    .groupby("functional_id", as_index=False)
    .first()
    .sort_values("relative_error")
)

threshold_rows = []
for fid, group in blind_ratio_matches.groupby("functional_id"):
    fvals = frozen_functional_values[fid].astype(float)
    threshold_rows.append({
        "functional_id": fid,
        "F_dynamic_range_max_over_min": float(fvals.max() / fvals.min()),
        "best_relative_error": float(group["relative_error"].min()),
        "best_percent_error": float(100.0 * group["relative_error"].min()),
        "hits_le_1pct": int(group["hit_1pct"].sum()),
        "hits_le_5pct": int(group["hit_5pct"].sum()),
        "hits_le_10pct": int(group["hit_10pct"].sum()),
        "total_pairwise_comparisons": int(len(group)),
        "multiple_comparison_warning": "HIGH" if int(group["hit_5pct"].sum()) > 0 else "LOW",
    })
threshold_summary = pd.DataFrame(threshold_rows).sort_values("best_relative_error")

# -----------------------------------------------------------------------------
# 4. Full-spectrum monotonic diagnostic.
#    This tests whether the sorted F-values can span the sorted nine-fermion mass
#    range without changing the functional. No mode-to-particle hand mapping.
# -----------------------------------------------------------------------------

sorted_masses = particle_mass_table.sort_values("mass_MeV").reset_index(drop=True)
target_mass_range = float(sorted_masses["mass_MeV"].max() / sorted_masses["mass_MeV"].min())

monotonic_rows = []
for fid in FROZEN_FUNCTIONALS:
    ftab = frozen_functional_values[["rho", fid]].copy()
    ftab[fid] = ftab[fid].astype(float)
    ftab_sorted = ftab.sort_values(fid).reset_index(drop=True)
    f_range = float(ftab_sorted[fid].max() / ftab_sorted[fid].min())
    dynamic_range_ratio = f_range / target_mass_range

    # Shape-only log diagnostic: after allowing one arbitrary scale, how far are
    # sorted log masses from sorted log F? This is not used to choose a mass law;
    # it simply reports how badly a monotonic one-to-one assignment would fail.
    logF = ftab_sorted[fid].map(math.log)
    logM = sorted_masses["mass_MeV"].map(math.log)
    scale_log = float((logM - logF).mean())
    residuals = logM - (logF + scale_log)
    rms_log_residual = float(math.sqrt((residuals ** 2).mean()))
    max_abs_log_residual = float(abs(residuals).max())

    monotonic_rows.append({
        "functional_id": fid,
        "F_dynamic_range": f_range,
        "target_mass_dynamic_range_top_over_electron": target_mass_range,
        "dynamic_range_ratio_F_over_target": dynamic_range_ratio,
        "dynamic_range_shortfall_factor": target_mass_range / f_range,
        "monotonic_full_spectrum_dynamic_range_pass": f_range >= 0.25 * target_mass_range,
        "sorted_rho_order_by_F": ", ".join(ftab_sorted["rho"].tolist()),
        "sorted_particle_order_by_mass": ", ".join(sorted_masses["particle"].tolist()),
        "rms_log_residual_after_one_scale": rms_log_residual,
        "max_abs_log_residual_after_one_scale": max_abs_log_residual,
    })
monotonic_full_spectrum_audit = pd.DataFrame(monotonic_rows).sort_values("rms_log_residual_after_one_scale")
full_spectrum_dynamic_range_any_pass = bool(monotonic_full_spectrum_audit["monotonic_full_spectrum_dynamic_range_pass"].any())

# -----------------------------------------------------------------------------
# 5. Controls and claim boundary.
# -----------------------------------------------------------------------------

r116_artifact_inventory = find_optional_r116_artifacts()
r116_artifacts_found = len(r116_artifact_inventory) > 0

no_parameter_fit_performed = True
no_functional_retuning_after_mass_loading = True
no_mode_particle_mapping_performed = True
no_final_physical_mass_law_selected = True
physical_mass_spectrum_claimed = False
SM_mass_matching_claimed = False
Omega0_claimed = False
full_PDE_mass_functional_closed = False

any_5pct_hits = bool(threshold_summary["hits_le_5pct"].sum() > 0)
any_1pct_hits = bool(threshold_summary["hits_le_1pct"].sum() > 0)

# A stricter screen: ratio hit plus same-sector target. Still not proof.
same_sector_hits_5pct = blind_ratio_matches[
    (blind_ratio_matches["hit_5pct"]) & (blind_ratio_matches["same_sector"])
]
same_sector_5pct_present = len(same_sector_hits_5pct) > 0

claim_boundary = pd.DataFrame([
    {
        "claim": "R117 compares frozen R116 F(rho) pairwise ratios to external mass ratios.",
        "status": "YES",
        "reason": "R116 functional values are frozen first; empirical masses are loaded only for blind screening.",
    },
    {
        "claim": "R117 retunes or refits F(rho) after seeing masses.",
        "status": "NO",
        "reason": "No functional exponents, coefficients, or mappings are optimized against data.",
    },
    {
        "claim": "R117 finds at least one pairwise ratio hit within 5 percent.",
        "status": "YES" if any_5pct_hits else "NO",
        "reason": "Pairwise hits are reported as exploratory signals only and carry multiple-comparison risk.",
    },
    {
        "claim": "R117 passes a full nine-mode monotonic mass-spectrum dynamic-range test.",
        "status": "YES" if full_spectrum_dynamic_range_any_pass else "NO",
        "reason": "The target charged-fermion range is far larger than the frozen R116 functional ranges." if not full_spectrum_dynamic_range_any_pass else "At least one frozen functional spans a nontrivial fraction of the target range.",
    },
    {
        "claim": "R117 selects a final physical mass law.",
        "status": "NO",
        "reason": "Ranking is diagnostic only; final mass law selection requires R118/R119-level derivation and controls.",
    },
    {
        "claim": "R117 maps rho modes to particles by hand.",
        "status": "NO",
        "reason": "Only pairwise ratios and sorted monotonic diagnostics are computed; no chosen rho-particle assignment is declared.",
    },
    {
        "claim": "R117 confirms the V12.8 nine-mode seed as the Standard Model spectrum.",
        "status": "NO",
        "reason": "The result remains a mechanical/operator-geometric seed; physical spectrum identification remains open.",
    },
    {
        "claim": "R117 closes full PDE/GR self-energy mass derivation.",
        "status": "NO",
        "reason": "R116 functionals are toy/analytic geometry proxies; R118 is reserved for principled self-energy derivation.",
    },
])

risk_register = pd.DataFrame([
    {
        "risk": "Pairwise ratio hits arise by chance from many comparisons.",
        "severity": "HIGH",
        "mitigation": "Report all comparisons, hit counts, and multiple-comparison warning; do not claim proof.",
    },
    {
        "risk": "Quark masses are scheme/scale dependent.",
        "severity": "HIGH",
        "mitigation": "Mark the mass table as screening-only and preserve physical matching as open.",
    },
    {
        "risk": "A good single ratio is mistaken for a mass law.",
        "severity": "HIGH",
        "mitigation": "Require future derivation, independent validation, and full-spectrum controls.",
    },
    {
        "risk": "Post-comparison retuning sneaks into F(rho).",
        "severity": "HIGH",
        "mitigation": "Freeze F-values before loading masses and write them to immutable R117 outputs.",
    },
    {
        "risk": "Sorted monotonic diagnostic is mistaken for a chosen particle mapping.",
        "severity": "MEDIUM",
        "mitigation": "Label it diagnostic-only and do not declare rho-to-particle identities.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R118",
        "title": "Analytic Helical Self-Energy Derivation Gate",
        "goal": "Replace R116 toy/analytic focusing proxies with a principled action/PDE or GR-compatible self-energy derivation.",
        "must_not_do": "Do not choose a physical mass law by best empirical hit alone.",
    },
    {
        "next_gate": "FORCE_R119",
        "title": "Locked Mapping / Assignment Control Gate",
        "goal": "Only after a derived F(rho), test whether any unique rho-to-particle assignment survives controls.",
        "must_not_do": "Do not hand-map modes to particles or reorder after seeing target masses.",
    },
])

# -----------------------------------------------------------------------------
# 6. Verdict.
# -----------------------------------------------------------------------------

mass_ratio_table_generated = len(mass_ratio_table) == 36
functional_ratio_table_generated = len(functional_ratio_table) == 36 * len(FROZEN_FUNCTIONALS)
blind_comparison_generated = len(blind_ratio_matches) == len(functional_ratio_table) * len(mass_ratio_table)
best_match_tables_generated = len(best_matches_by_functional) == len(FROZEN_FUNCTIONALS)
full_spectrum_audit_generated = len(monotonic_full_spectrum_audit) == len(FROZEN_FUNCTIONALS)

protocol_clean = bool(
    candidate_functionals_frozen_before_mass_loading
    and empirical_mass_data_loaded
    and mass_ratio_table_generated
    and functional_ratio_table_generated
    and blind_comparison_generated
    and best_match_tables_generated
    and full_spectrum_audit_generated
    and no_parameter_fit_performed
    and no_functional_retuning_after_mass_loading
    and no_mode_particle_mapping_performed
    and no_final_physical_mass_law_selected
    and not physical_mass_spectrum_claimed
    and not SM_mass_matching_claimed
    and not Omega0_claimed
    and not full_PDE_mass_functional_closed
)

if protocol_clean and any_5pct_hits and not full_spectrum_dynamic_range_any_pass:
    verdict_status = "BLIND F(rho) MASS-RATIO SCREEN PASS / PAIRWISE HITS FOUND, FULL-SPECTRUM MASS LAW NOT CLOSED"
elif protocol_clean and any_5pct_hits and full_spectrum_dynamic_range_any_pass:
    verdict_status = "BLIND F(rho) MASS-RATIO SCREEN PASS / PAIRWISE HITS AND RANGE SIGNAL FOUND, PHYSICAL CLAIM STILL OPEN"
elif protocol_clean and not any_5pct_hits:
    verdict_status = "BLIND F(rho) MASS-RATIO SCREEN PASS / NO 5PCT PAIRWISE HITS FOR FROZEN R116 CANDIDATES"
else:
    verdict_status = "BLIND F(rho) MASS-RATIO COMPARISON INCONCLUSIVE"

gate_audit = pd.DataFrame([
    {"test": "candidate_functionals_frozen_before_mass_loading", "result": bool_status(candidate_functionals_frozen_before_mass_loading), "interpretation": "R116 F(rho) values are frozen before empirical mass loading."},
    {"test": "empirical_mass_data_loaded", "result": bool_status(empirical_mass_data_loaded), "interpretation": "A nine charged-fermion screening mass table is loaded for blind comparison."},
    {"test": "functional_ratio_table_generated", "result": bool_status(functional_ratio_table_generated), "interpretation": "All frozen F(rho) pairwise ratios were computed."},
    {"test": "mass_ratio_table_generated", "result": bool_status(mass_ratio_table_generated), "interpretation": "All charged-fermion pairwise mass ratios were computed."},
    {"test": "blind_comparison_generated", "result": bool_status(blind_comparison_generated), "interpretation": "Every frozen F-ratio was compared to every mass ratio."},
    {"test": "any_1pct_pairwise_hits", "result": "SCREEN" if any_1pct_hits else "NO", "interpretation": "At least one pairwise hit within 1 percent exists." if any_1pct_hits else "No pairwise hit within 1 percent."},
    {"test": "any_5pct_pairwise_hits", "result": "SCREEN" if any_5pct_hits else "NO", "interpretation": "At least one pairwise hit within 5 percent exists; not proof because of multiple-comparison risk." if any_5pct_hits else "No pairwise hit within 5 percent."},
    {"test": "same_sector_5pct_present", "result": "SCREEN" if same_sector_5pct_present else "NO", "interpretation": "At least one same-sector mass ratio has a 5 percent hit." if same_sector_5pct_present else "No same-sector 5 percent hit."},
    {"test": "full_spectrum_dynamic_range_any_pass", "result": "PASS" if full_spectrum_dynamic_range_any_pass else "FAIL_EXPECTED", "interpretation": "At least one F spans a nontrivial fraction of the charged-fermion range." if full_spectrum_dynamic_range_any_pass else "No frozen R116 F spans the charged-fermion mass hierarchy."},
    {"test": "no_parameter_fit_performed", "result": bool_status(no_parameter_fit_performed), "interpretation": "No parameter was optimized against observed masses."},
    {"test": "no_functional_retuning_after_mass_loading", "result": bool_status(no_functional_retuning_after_mass_loading), "interpretation": "No F(rho) was altered after loading empirical masses."},
    {"test": "no_mode_particle_mapping_performed", "result": bool_status(no_mode_particle_mapping_performed), "interpretation": "No rho mode was assigned to a particle by hand."},
    {"test": "physical_mass_spectrum_claimed", "result": "OPEN", "interpretation": "No physical mass spectrum is claimed."},
    {"test": "full_PDE_mass_functional_closed", "result": "OPEN", "interpretation": "No full PDE/GR self-energy mass functional is closed."},
])

# -----------------------------------------------------------------------------
# 7. Save artifacts.
# -----------------------------------------------------------------------------

write_table(frozen_functional_values, OUT / "FORCE_R117_frozen_R116_functional_values.csv")
write_table(particle_mass_table, OUT / "FORCE_R117_particle_mass_screening_table.csv")
write_table(functional_ratio_table, OUT / "FORCE_R117_functional_pairwise_ratios.csv")
write_table(mass_ratio_table, OUT / "FORCE_R117_mass_pairwise_ratios.csv")
write_table(blind_ratio_matches, OUT / "FORCE_R117_blind_ratio_matches_all.csv")
write_table(best_matches_by_functional, OUT / "FORCE_R117_best_matches_by_functional.csv")
write_table(threshold_summary, OUT / "FORCE_R117_threshold_summary.csv")
write_table(monotonic_full_spectrum_audit, OUT / "FORCE_R117_monotonic_full_spectrum_audit.csv")
write_table(claim_boundary, OUT / "FORCE_R117_claim_boundary.csv")
write_table(risk_register, OUT / "FORCE_R117_risk_register.csv")
write_table(next_gate_plan, OUT / "FORCE_R117_next_gate_plan.csv")
write_table(gate_audit, OUT / "FORCE_R117_gate_audit.csv")
write_table(r116_artifact_inventory, OUT / "FORCE_R117_optional_R116_artifact_inventory.csv")

# Compact tables for console output.
best_preview = best_matches_by_functional[[
    "functional_id", "rho_pair", "F_ratio_ge_1", "particle_pair", "mass_ratio_ge_1", "percent_error", "same_sector"
]].copy()
best_preview["F_ratio_ge_1"] = best_preview["F_ratio_ge_1"].map(lambda x: round(float(x), 6))
best_preview["mass_ratio_ge_1"] = best_preview["mass_ratio_ge_1"].map(lambda x: round(float(x), 6))
best_preview["percent_error"] = best_preview["percent_error"].map(lambda x: round(float(x), 4))

threshold_preview = threshold_summary.copy()
for col in ["F_dynamic_range_max_over_min", "best_relative_error", "best_percent_error"]:
    threshold_preview[col] = threshold_preview[col].map(lambda x: round(float(x), 6))

monotonic_preview = monotonic_full_spectrum_audit[[
    "functional_id", "F_dynamic_range", "target_mass_dynamic_range_top_over_electron",
    "dynamic_range_shortfall_factor", "monotonic_full_spectrum_dynamic_range_pass",
    "rms_log_residual_after_one_scale"
]].copy()
for col in ["F_dynamic_range", "target_mass_dynamic_range_top_over_electron", "dynamic_range_shortfall_factor", "rms_log_residual_after_one_scale"]:
    monotonic_preview[col] = monotonic_preview[col].map(lambda x: round(float(x), 6))

report_md = f"""# FORCE_R117 — Blind F(rho) Mass-Ratio Comparison Gate

## Verdict

BOXED: {verdict_status}

## Frozen seed

BOXED: {label_set(SEED)}

## Protocol boundary

- R116 candidate F(rho) values are frozen before empirical masses are loaded.
- No F(rho) parameter, exponent, coefficient, or expression is retuned after comparison.
- No rho-to-particle mapping is selected by hand.
- Pairwise ratio hits are screen signals only, not proof.
- A full PDE/GR self-energy derivation remains open.
- Physical spectrum identification remains open.

## Screening mass-table note

{MASS_TABLE_SOURCE_NOTE}

## Main results

- any_1pct_pairwise_hits: {any_1pct_hits}
- any_5pct_pairwise_hits: {any_5pct_hits}
- same_sector_5pct_present: {same_sector_5pct_present}
- full_spectrum_dynamic_range_any_pass: {full_spectrum_dynamic_range_any_pass}
- protocol_clean: {protocol_clean}

## Best match by frozen functional

{best_preview.to_string(index=False)}

## Threshold summary

{threshold_preview.to_string(index=False)}

## Full-spectrum monotonic dynamic-range audit

{monotonic_preview.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Gate audit

{gate_audit.to_string(index=False)}
"""
(OUT / "FORCE_R117_summary.md").write_text(report_md, encoding="utf-8")
simple_pdf_from_text("FORCE_R117 Blind F(rho) Mass-Ratio Comparison Gate", report_md, OUT / "FORCE_R117_summary.pdf")

verdict = {
    "force_id": FORCE_ID,
    "title": TITLE,
    "status": verdict_status,
    "candidate_functionals_frozen_before_mass_loading": candidate_functionals_frozen_before_mass_loading,
    "empirical_mass_data_loaded": empirical_mass_data_loaded,
    "no_parameter_fit_performed": no_parameter_fit_performed,
    "no_functional_retuning_after_mass_loading": no_functional_retuning_after_mass_loading,
    "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
    "no_final_physical_mass_law_selected": no_final_physical_mass_law_selected,
    "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
    "SM_mass_matching_claimed": SM_mass_matching_claimed,
    "Omega0_claimed": Omega0_claimed,
    "full_PDE_mass_functional_closed": full_PDE_mass_functional_closed,
    "any_1pct_pairwise_hits": any_1pct_hits,
    "any_5pct_pairwise_hits": any_5pct_hits,
    "same_sector_5pct_present": same_sector_5pct_present,
    "full_spectrum_dynamic_range_any_pass": full_spectrum_dynamic_range_any_pass,
    "protocol_clean": protocol_clean,
    "r116_artifacts_found_optional": r116_artifacts_found,
    "target_mass_dynamic_range_top_over_electron": target_mass_range,
    "selected_seed": [frac_label(x) for x in SEED],
    "recommended_next": "FORCE_R118_analytic_helical_self_energy_derivation_gate",
}
(OUT / "FORCE_R117_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

# Plots.
if HAVE_MPL:
    try:
        plt.figure(figsize=(10, 5))
        plt.bar(threshold_summary["functional_id"], threshold_summary["hits_le_5pct"])
        plt.xticks(rotation=35, ha="right")
        plt.ylabel("count")
        plt.title("R117 pairwise hits <= 5 percent by functional")
        plt.tight_layout()
        plt.savefig(PLOTS / "hits_5pct_by_functional.png", dpi=160)
        plt.close()

        plt.figure(figsize=(10, 5))
        plt.bar(monotonic_full_spectrum_audit["functional_id"], monotonic_full_spectrum_audit["F_dynamic_range"])
        plt.axhline(target_mass_range, linestyle="--")
        plt.yscale("log")
        plt.xticks(rotation=35, ha="right")
        plt.ylabel("dynamic range max/min, log scale")
        plt.title("R117 F dynamic ranges versus charged-fermion target range")
        plt.tight_layout()
        plt.savefig(PLOTS / "dynamic_range_vs_target.png", dpi=160)
        plt.close()

        top_hits = blind_ratio_matches.head(50).copy()
        plt.figure(figsize=(10, 5))
        plt.hist(top_hits["percent_error"], bins=20)
        plt.xlabel("percent error")
        plt.ylabel("count among top 50")
        plt.title("R117 top-50 blind ratio match errors")
        plt.tight_layout()
        plt.savefig(PLOTS / "top50_match_error_hist.png", dpi=160)
        plt.close()
    except Exception as e:
        (OUT / "plot_error.txt").write_text(str(e), encoding="utf-8")

# Manifest before zipping.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
manifest = pd.DataFrame(manifest_rows)
write_table(manifest, OUT / "artifact_manifest.csv")

# Copy script into output.
try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R117_blind_Frho_mass_ratio_comparison_gate.py")
except Exception:
    pass

# Zip output.
if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()
zip_integrity_pass = bad is None

verdict["zip_integrity_pass"] = zip_integrity_pass
(OUT / "FORCE_R117_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

# Console print.
print("\n=== COPY/PASTE R117 RESULT ===")
print("R117 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"candidate_functionals_frozen_before_mass_loading: {candidate_functionals_frozen_before_mass_loading}")
print(f"empirical_mass_data_loaded: {empirical_mass_data_loaded}")
print(f"functional_ratio_table_generated: {functional_ratio_table_generated}")
print(f"mass_ratio_table_generated: {mass_ratio_table_generated}")
print(f"blind_comparison_generated: {blind_comparison_generated}")
print(f"any_1pct_pairwise_hits: {any_1pct_hits}")
print(f"any_5pct_pairwise_hits: {any_5pct_hits}")
print(f"same_sector_5pct_present: {same_sector_5pct_present}")
print(f"full_spectrum_dynamic_range_any_pass: {full_spectrum_dynamic_range_any_pass}")
print(f"target_mass_dynamic_range_top_over_electron: {target_mass_range:.6f}")
print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
print(f"no_functional_retuning_after_mass_loading: {no_functional_retuning_after_mass_loading}")
print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
print(f"no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}")
print(f"physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}")
print(f"SM_mass_matching_claimed: {SM_mass_matching_claimed}")
print(f"Omega0_claimed: {Omega0_claimed}")
print(f"full_PDE_mass_functional_closed: {full_PDE_mass_functional_closed}")
print(f"selected_seed: {label_set(SEED)}")
print("AUDIT:")
print(gate_audit.to_string(index=False))
print("BEST_MATCHES_BY_FUNCTIONAL:")
print(best_preview.to_string(index=False))
print("THRESHOLD_SUMMARY:")
print(threshold_preview.to_string(index=False))
print("MONOTONIC_FULL_SPECTRUM_AUDIT:")
print(monotonic_preview.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("RISK_REGISTER:")
print(risk_register.to_string(index=False))
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R117_summary.md').resolve()}")
print("NEXT: FORCE_R118_analytic_helical_self_energy_derivation_gate")
print("=== END COPY/PASTE R117 RESULT ===\n")
