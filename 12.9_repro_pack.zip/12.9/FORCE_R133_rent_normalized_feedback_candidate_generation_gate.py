from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import hashlib
import math
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R133_rent_normalized_feedback_candidate_generation_gate")
ZIP = Path("FORCE_R133_rent_normalized_feedback_candidate_generation_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
TITLE = "FORCE_R133 — Rent-Normalized Feedback Candidate Generation Gate"

# ---------------------------------------------------------------------
# FORCE_R133
# ---------------------------------------------------------------------
# Purpose:
#   Build rent-normalized feedback candidates using the R132 derived
#   closure-rent power-count candidates p=5 and p=6.
#
# Inputs intentionally kept internal / geometry-only:
#   - V12.8 nine-mode seed.
#   - R126 isolated feedback screen values for the primary feedback variant.
#   - R132 derived rent-law candidates p=5 and p=6.
#
# No empirical masses, no mass ratios, no particle mapping, no fitting.
#
# Main diagnostic:
#   available_norm(rho) = F_feedback(rho) / F_feedback(1)
#   rent_p(rho)         = rho^p
#   adequacy_p(rho)     = available_norm(rho) / rent_p(rho)
#
# R132 found p_min ~= 4.534 for low-mode relief under identity-anchor
# normalization. Therefore p=5 is the first derived self-energy-like
# candidate above the threshold, and p=6 is a curvature-weighted composite
# candidate. R133 does not select a unique physical rent law.

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
]

VIRTUAL_SUPPORTS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

# R126 primary feedback preview values:
# radius_law=inverse_lens_quarter_radius | budget_mode=lens_finite_budget
# depth_power=3.0 | feedback_eta=0.25 | feedback_style=finite_lens_saturating
R126_FEEDBACK_F = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

R132_MIN_POWER = 4.53421583436
RENT_POWERS = [
    (4.0, "p4_write_density_control", "LOW_ORDER_CONTROL", "R132 says this is too shallow; included as a fail control."),
    (5.0, "p5_quadratic_density_self_energy", "DERIVED_SELF_ENERGY_CANDIDATE", "First derived power-count candidate above p_min; n_write^2 V."),
    (6.0, "p6_curvature_weighted_self_energy", "DERIVED_COMPOSITE_CANDIDATE", "Curvature/closure-turning weighted self-energy candidate."),
    (7.0, "p7_acceleration_weighted_control", "HIGH_ORDER_DIAGNOSTIC_CONTROL", "High-order diagnostic; not selected as a law."),
]


def frac_label(x):
    if x == 0:
        return "0_boundary"
    return str(x) if isinstance(x, Fraction) else str(x)


def label_set(xs):
    xs = list(xs)
    if not xs:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(xs))


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def R_map(x):
    return Fraction(2, 1) - x


def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x


def partner_status(x):
    if x == 0:
        return "boundary_zero"
    if x in SEED:
        return "species"
    if x in VIRTUAL_SUPPORTS:
        return "virtual_support"
    return "outside_support_catalog"


def support_ecology(x):
    r = R_map(x)
    c = C_map(x)
    r_status = partner_status(r)
    c_status = partner_status(c)
    if r_status == "boundary_zero" or c_status == "boundary_zero":
        return "boundary_assisted"
    if r_status == "virtual_support" or c_status == "virtual_support":
        return "virtual_support_dependent"
    return "clean_internal"


def table_to_text(df, cols=None, max_rows=None):
    if cols is not None:
        df = df[cols]
    if max_rows is not None:
        df = df.head(max_rows)
    if df.empty:
        return "none"
    return df.to_string(index=False)

# ---------------------------------------------------------------------
# 1. Candidate generation.
# ---------------------------------------------------------------------

F_identity = R126_FEEDBACK_F[Fraction(1, 1)]
mode_rows = []
for rho in SEED:
    F = R126_FEEDBACK_F[rho]
    available_norm = F / F_identity
    mode_rows.append({
        "rho": frac_label(rho),
        "rho_float": float(rho),
        "feedback_F_R126_primary": F,
        "available_norm_to_identity": available_norm,
        "R_partner": frac_label(R_map(rho)),
        "R_partner_status": partner_status(R_map(rho)),
        "C_partner": frac_label(C_map(rho)),
        "C_partner_status": partner_status(C_map(rho)),
        "support_ecology": support_ecology(rho),
    })
base_mode_table = pd.DataFrame(mode_rows)

candidate_rows = []
mode_adequacy_rows = []
classification_rows = []

low_modes = {Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1)}

for p, law_id, natural_status, interpretation in RENT_POWERS:
    adequacy_values = {}
    rent_values = {}
    available_values = {}
    surplus_modes = []
    deficit_modes = []
    low_surplus = []
    low_deficit = []

    for rho in SEED:
        F = R126_FEEDBACK_F[rho]
        available_norm = F / F_identity
        required_rent = float(rho) ** p
        adequacy = available_norm / required_rent
        adequacy_values[rho] = adequacy
        rent_values[rho] = required_rent
        available_values[rho] = available_norm

        if adequacy >= 1.0:
            surplus_modes.append(rho)
            if rho in low_modes:
                low_surplus.append(rho)
        else:
            deficit_modes.append(rho)
            if rho in low_modes:
                low_deficit.append(rho)

        if adequacy >= 2.0:
            adequacy_class = "surplus_strong"
        elif adequacy >= 1.0:
            adequacy_class = "surplus_marginal"
        elif adequacy >= 0.5:
            adequacy_class = "deficit_near"
        else:
            adequacy_class = "deficit_strong"

        ecology = support_ecology(rho)
        if adequacy >= 1.0 and ecology == "clean_internal":
            closure_class = "standalone_clean_internal_screen"
        elif adequacy >= 1.0 and ecology == "virtual_support_dependent":
            closure_class = "adequate_but_virtual_support_dependent"
        elif adequacy >= 1.0 and ecology == "boundary_assisted":
            closure_class = "adequate_but_boundary_assisted"
        elif adequacy < 1.0:
            closure_class = "mode_normalized_deficit_collective_candidate"
        else:
            closure_class = "unclassified"

        mode_adequacy_rows.append({
            "law_id": law_id,
            "power": p,
            "rho": frac_label(rho),
            "rho_float": float(rho),
            "available_norm": available_norm,
            "required_rent": required_rent,
            "adequacy": adequacy,
            "adequacy_class": adequacy_class,
            "support_ecology": ecology,
            "closure_class": closure_class,
            "R_partner": frac_label(R_map(rho)),
            "R_partner_status": partner_status(R_map(rho)),
            "C_partner": frac_label(C_map(rho)),
            "C_partner_status": partner_status(C_map(rho)),
        })

    vals = list(adequacy_values.values())
    dyn = max(vals) / min(vals)
    low_mode_relief = all(rho in surplus_modes for rho in low_modes)
    all_modes_surplus = len(deficit_modes) == 0
    threshold_margin = p - R132_MIN_POWER

    candidate_rows.append({
        "law_id": law_id,
        "power": p,
        "natural_status": natural_status,
        "above_R132_pmin": p >= R132_MIN_POWER,
        "threshold_margin_vs_pmin": threshold_margin,
        "rent_normalized_dynamic_range": dyn,
        "surplus_count": len(surplus_modes),
        "deficit_count": len(deficit_modes),
        "surplus_modes": label_set(surplus_modes),
        "deficit_modes": label_set(deficit_modes),
        "low_mode_relief": low_mode_relief,
        "low_surplus_count": len(low_surplus),
        "low_deficit_modes": label_set(low_deficit),
        "all_modes_surplus": all_modes_surplus,
        "selected_as_final_physical_rent_law": False,
        "interpretation": interpretation,
    })

    # Closure class summary per candidate.
    temp_df = pd.DataFrame([r for r in mode_adequacy_rows if r["law_id"] == law_id])
    for closure_class, count in temp_df["closure_class"].value_counts().items():
        modes = temp_df[temp_df["closure_class"] == closure_class]["rho"].tolist()
        classification_rows.append({
            "law_id": law_id,
            "power": p,
            "closure_class": closure_class,
            "count": int(count),
            "modes": ", ".join(modes) if modes else "none",
        })

candidate_roster = pd.DataFrame(candidate_rows)
mode_adequacy_table = pd.DataFrame(mode_adequacy_rows)
classification_summary = pd.DataFrame(classification_rows)

# ---------------------------------------------------------------------
# 2. R130/R131/R132 audit synthesis.
# ---------------------------------------------------------------------

history_rows = [
    {
        "gate": "R130",
        "input_problem": "Flat unit-rent threshold made low modes look collective-dependent.",
        "result": "unit rent reversal flagged",
        "R133_use": "Do not trust flat F>=1 as a physical closure threshold.",
    },
    {
        "gate": "R131",
        "input_problem": "Mode-normalized rent profiles were screened but no unique rent law was known.",
        "result": "ordinary shallow profiles did not naturally relieve low modes",
        "R133_use": "Generate candidates only from R132-derived rent power counts, not from desired particle behavior.",
    },
    {
        "gate": "R132",
        "input_problem": "Derive what power law would relieve the reversal from geometry, not observations.",
        "result": "p_min=4.534; p=5 first derived self-energy-like relief candidate; p=6 composite candidate",
        "R133_use": "Use p=5 and p=6 as primary derived candidates; p=4 fail control; p=7 high-order control.",
    },
]
history_audit = pd.DataFrame(history_rows)

# ---------------------------------------------------------------------
# 3. Observation awareness register.
# ---------------------------------------------------------------------

observation_awareness = pd.DataFrame([
    {
        "used_in_computation": False,
        "observation_context": "Some observed charged leptons can exist unconfined; electron is stable while muon/tau decay but are not confined.",
        "R133_use": "Sanity context only; no rho-to-lepton assignment is computed.",
    },
    {
        "used_in_computation": False,
        "observation_context": "Quarks are not observed as free isolated particles and have scheme-dependent mass concepts.",
        "R133_use": "Sanity context only; no rho-to-quark assignment is computed.",
    },
    {
        "used_in_computation": False,
        "observation_context": "R132 found that p=5/p=6 relieve the low-mode reversal without observation input.",
        "R133_use": "Generate rent-normalized candidates; do not select a physical sector split.",
    },
])

# ---------------------------------------------------------------------
# 4. Verdict booleans.
# ---------------------------------------------------------------------

p4_row = candidate_roster[candidate_roster["law_id"] == "p4_write_density_control"].iloc[0]
p5_row = candidate_roster[candidate_roster["law_id"] == "p5_quadratic_density_self_energy"].iloc[0]
p6_row = candidate_roster[candidate_roster["law_id"] == "p6_curvature_weighted_self_energy"].iloc[0]
p7_row = candidate_roster[candidate_roster["law_id"] == "p7_acceleration_weighted_control"].iloc[0]

rent_normalized_candidates_generated = not candidate_roster.empty
p5_candidate_generated = bool(p5_row["low_mode_relief"])
p6_candidate_generated = bool(p6_row["low_mode_relief"])
p4_control_fails_relief = not bool(p4_row["low_mode_relief"])
p7_high_order_control_reported = True
primary_candidates_relieve_reversal = p5_candidate_generated and p6_candidate_generated
low_order_control_fails = p4_control_fails_relief
unique_rent_law_closed = False
clean_standalone_collective_split_closed = False
observations_used_in_computation = False
no_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_parameter_fit_performed = True
no_mode_particle_mapping_performed = True
no_final_physical_rent_law_selected = True
physical_mass_spectrum_claimed = False
true_GR_PDE_collective_field_closed = False
virtuals_promoted_to_species = False

# Candidate quality label.
def candidate_grade(row):
    if row["law_id"] == "p5_quadratic_density_self_energy":
        return "PRIMARY_DERIVED_RENT_CANDIDATE"
    if row["law_id"] == "p6_curvature_weighted_self_energy":
        return "PRIMARY_COMPOSITE_RENT_CANDIDATE"
    if row["law_id"] == "p4_write_density_control":
        return "FAIL_CONTROL_TOO_SHALLOW"
    if row["law_id"] == "p7_acceleration_weighted_control":
        return "HIGH_ORDER_CONTROL_NOT_LAW"
    return "SCREEN"

candidate_roster["candidate_grade"] = candidate_roster.apply(candidate_grade, axis=1)

if (
    rent_normalized_candidates_generated
    and primary_candidates_relieve_reversal
    and low_order_control_fails
    and p7_high_order_control_reported
    and no_empirical_mass_data_loaded
    and no_mass_matching_performed
    and no_parameter_fit_performed
    and no_mode_particle_mapping_performed
    and no_final_physical_rent_law_selected
    and not unique_rent_law_closed
):
    verdict_status = "RENT-NORMALIZED FEEDBACK CANDIDATE GENERATION PASS / P5-P6 RELIEVE REVERSAL, UNIQUE LAW OPEN"
else:
    verdict_status = "RENT-NORMALIZED FEEDBACK CANDIDATE GENERATION INCONCLUSIVE"

# ---------------------------------------------------------------------
# 5. Gate audit / claim boundary / risks / next.
# ---------------------------------------------------------------------

gate_audit = pd.DataFrame([
    {
        "test": "rent_normalized_candidates_generated",
        "result": "PASS" if rent_normalized_candidates_generated else "WARN",
        "interpretation": "Rent-normalized feedback candidates are generated from R132-derived power counts.",
    },
    {
        "test": "p4_control_fails_relief",
        "result": "PASS" if p4_control_fails_relief else "WARN",
        "interpretation": "The p=4 write-density control remains too shallow and does not relieve all low modes.",
    },
    {
        "test": "p5_candidate_relief",
        "result": "PASS" if p5_candidate_generated else "WARN",
        "interpretation": "The p=5 quadratic density self-energy candidate relieves the low-mode reversal.",
    },
    {
        "test": "p6_candidate_relief",
        "result": "PASS" if p6_candidate_generated else "WARN",
        "interpretation": "The p=6 curvature-weighted self-energy candidate relieves the low-mode reversal.",
    },
    {
        "test": "p7_high_order_control_reported",
        "result": "PASS" if p7_high_order_control_reported else "WARN",
        "interpretation": "The p=7 high-order control is reported but not selected as a law.",
    },
    {
        "test": "observations_used_in_computation",
        "result": "NO" if not observations_used_in_computation else "WARN",
        "interpretation": "Observation awareness is recorded only as sanity context.",
    },
    {
        "test": "no_empirical_mass_data_loaded",
        "result": "PASS" if no_empirical_mass_data_loaded else "WARN",
        "interpretation": "No empirical particle masses or mass ratios are loaded.",
    },
    {
        "test": "unique_rent_law_closed",
        "result": "OPEN",
        "interpretation": "R133 generates candidates but does not prove a unique physical closure-rent law.",
    },
    {
        "test": "clean_standalone_collective_split_closed",
        "result": "OPEN",
        "interpretation": "R133 reports adequacy classes but does not select a physical standalone/collective sector split.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R133 generates rent-normalized feedback candidates from R132-derived power-count rent laws.",
        "status": "YES_SCREEN",
        "reason": "p=5 and p=6 are generated as geometry-derived candidates, with p=4 and p=7 controls retained.",
    },
    {
        "claim": "R133 selects p=5 or p=6 as the final physical closure-rent law.",
        "status": "NO",
        "reason": "p=5 and p=6 are primary candidates only; unique rent law and PDE/GR derivation remain open.",
    },
    {
        "claim": "R133 uses observations or masses to choose a rent profile.",
        "status": "NO",
        "reason": "Observation awareness is context only; no empirical mass table, mass ratios, or particle mapping are loaded.",
    },
    {
        "claim": "R133 compares the generated candidates to observed particle masses.",
        "status": "NO",
        "reason": "This is a candidate-generation gate; mass screens are deferred until candidates are frozen.",
    },
    {
        "claim": "R133 maps rho modes to leptons, quarks, or Standard Model particles.",
        "status": "NO",
        "reason": "No rho-to-particle identities are assigned.",
    },
    {
        "claim": "R133 promotes virtual supports to stable species.",
        "status": "NO",
        "reason": "The V12.8 species projection remains locked; virtual supports remain support-only.",
    },
    {
        "claim": "R133 closes true GR/PDE collective field dynamics.",
        "status": "NO",
        "reason": "R133 is a geometry/power-count candidate-generation screen, not a solved field-equation derivation.",
    },
])

risk_register = pd.DataFrame([
    {
        "risk": "p=5 or p=6 is mistaken for a selected law because it relieves the reversal.",
        "severity": "HIGH",
        "mitigation": "Label p=5/p=6 as candidates only and defer selection to derivation/controls.",
    },
    {
        "risk": "Rent-normalized adequacy is mistaken for particle-sector mapping.",
        "severity": "HIGH",
        "mitigation": "No rho-to-lepton/quark/SM mapping is declared.",
    },
    {
        "risk": "Identity-anchor normalization is mistaken for a physical theorem.",
        "severity": "MEDIUM",
        "mitigation": "Keep normalization as an anchor convention and leave unique rent threshold open.",
    },
    {
        "risk": "Power-count candidate generation is mistaken for GR/PDE closure.",
        "severity": "HIGH",
        "mitigation": "State explicitly that R133 is not a field-equation derivation.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R134",
        "title": "Observation Sanity / Sector-Split Control Gate",
        "goal": "After p=5/p=6 candidates are frozen, test whether adequacy classes are qualitatively compatible with standalone/confined observations without tuning.",
        "must_not_do": "Do not tune classifications to leptons/quarks or load masses.",
    },
    {
        "next_gate": "FORCE_R135",
        "title": "Locked Rent-Normalized Candidate Mass Screen Gate",
        "goal": "Only after R134, freeze p=5/p=6 rent-normalized candidates and compare blindly to mass-ratio screens.",
        "must_not_do": "Do not retune p or choose p based on hits.",
    },
    {
        "next_gate": "FORCE_R128",
        "title": "GR/Lag Field Derivation Gate",
        "goal": "Attempt to derive feedback and rent laws from a more principled lag/field equation.",
        "must_not_do": "Do not treat power counting as full GR/PDE closure.",
    },
])

# ---------------------------------------------------------------------
# 6. Save artifacts.
# ---------------------------------------------------------------------

base_mode_table.to_csv(OUT / "FORCE_R133_base_mode_table.csv", index=False)
candidate_roster.to_csv(OUT / "FORCE_R133_candidate_roster.csv", index=False)
mode_adequacy_table.to_csv(OUT / "FORCE_R133_mode_adequacy_table.csv", index=False)
classification_summary.to_csv(OUT / "FORCE_R133_classification_summary.csv", index=False)
history_audit.to_csv(OUT / "FORCE_R133_history_audit.csv", index=False)
observation_awareness.to_csv(OUT / "FORCE_R133_observation_awareness.csv", index=False)
gate_audit.to_csv(OUT / "FORCE_R133_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R133_claim_boundary.csv", index=False)
risk_register.to_csv(OUT / "FORCE_R133_risk_register.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R133_next_gate_plan.csv", index=False)

# Candidate freeze file and hash.
freeze_payload = {
    "force_id": "FORCE_R133",
    "freeze_id": FREEZE_ID,
    "candidate_source": "R126 primary feedback values plus R132 power-count rent laws",
    "selected_seed": [frac_label(x) for x in SEED],
    "r126_feedback_primary": {frac_label(k): v for k, v in R126_FEEDBACK_F.items()},
    "r132_min_power": R132_MIN_POWER,
    "rent_power_candidates": [
        {
            "power": p,
            "law_id": law_id,
            "natural_status": status,
            "interpretation": interp,
        }
        for p, law_id, status, interp in RENT_POWERS
    ],
    "final_physical_rent_law_selected": False,
    "mass_data_loaded": False,
}
freeze_path = OUT / "FORCE_R133_candidate_freeze.json"
freeze_path.write_text(json.dumps(freeze_payload, indent=2), encoding="utf-8")
candidate_freeze_hash = sha256_file(freeze_path)

verdict = {
    "force_id": "FORCE_R133",
    "title": "Rent-Normalized Feedback Candidate Generation Gate",
    "freeze_id": FREEZE_ID,
    "status": verdict_status,
    "candidate_freeze_hash": candidate_freeze_hash,
    "rent_normalized_candidates_generated": rent_normalized_candidates_generated,
    "p4_control_fails_relief": p4_control_fails_relief,
    "p5_candidate_generated": p5_candidate_generated,
    "p6_candidate_generated": p6_candidate_generated,
    "primary_candidates_relieve_reversal": primary_candidates_relieve_reversal,
    "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
    "no_mass_matching_performed": no_mass_matching_performed,
    "no_parameter_fit_performed": no_parameter_fit_performed,
    "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
    "no_final_physical_rent_law_selected": no_final_physical_rent_law_selected,
    "unique_rent_law_closed": unique_rent_law_closed,
    "clean_standalone_collective_split_closed": clean_standalone_collective_split_closed,
    "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
    "true_GR_PDE_collective_field_closed": true_GR_PDE_collective_field_closed,
    "recommended_next": "FORCE_R134_observation_sanity_sector_split_control_gate",
}
(OUT / "FORCE_R133_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# {TITLE}

## Verdict

BOXED: {verdict_status}

## Central formula

available_norm(rho) = F_feedback(rho) / F_feedback(1)

required_rent_p(rho) = rho^p

adequacy_p(rho) = available_norm(rho) / required_rent_p(rho)

## R132 inheritance

R132 reported p_min ~= {R132_MIN_POWER:.6f}.

Therefore p=5 and p=6 are tested as derived rent candidates, while p=4 is retained as a low-order fail control and p=7 as a high-order diagnostic control.

## Key booleans

- rent_normalized_candidates_generated: {rent_normalized_candidates_generated}
- p4_control_fails_relief: {p4_control_fails_relief}
- p5_candidate_generated: {p5_candidate_generated}
- p6_candidate_generated: {p6_candidate_generated}
- primary_candidates_relieve_reversal: {primary_candidates_relieve_reversal}
- no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}
- no_mass_matching_performed: {no_mass_matching_performed}
- no_parameter_fit_performed: {no_parameter_fit_performed}
- no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}
- no_final_physical_rent_law_selected: {no_final_physical_rent_law_selected}
- unique_rent_law_closed: {unique_rent_law_closed}
- clean_standalone_collective_split_closed: {clean_standalone_collective_split_closed}

## Candidate freeze hash

{candidate_freeze_hash}

## Candidate roster

{candidate_roster.to_string(index=False)}

## Mode adequacy table

{mode_adequacy_table.to_string(index=False)}

## Classification summary

{classification_summary.to_string(index=False)}

## Gate audit

{gate_audit.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Observation awareness

{observation_awareness.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}
"""
(OUT / "FORCE_R133_summary.md").write_text(summary, encoding="utf-8")

# Plots.
plt.figure(figsize=(9, 5))
plt.bar(candidate_roster["law_id"], candidate_roster["rent_normalized_dynamic_range"])
plt.xticks(rotation=35, ha="right")
plt.ylabel("rent-normalized dynamic range")
plt.title("R133 rent-normalized candidate dynamic ranges")
plt.tight_layout()
plt.savefig(PLOTS / "candidate_dynamic_ranges.png", dpi=160)
plt.close()

plt.figure(figsize=(9, 5))
for law_id in ["p4_write_density_control", "p5_quadratic_density_self_energy", "p6_curvature_weighted_self_energy"]:
    sub = mode_adequacy_table[mode_adequacy_table["law_id"] == law_id]
    plt.plot(sub["rho"], sub["adequacy"], marker="o", label=law_id)
plt.axhline(1.0, linestyle="--")
plt.xticks(rotation=30)
plt.ylabel("adequacy")
plt.title("R133 mode adequacy by rent law")
plt.legend(fontsize=7)
plt.tight_layout()
plt.savefig(PLOTS / "mode_adequacy_by_rent_law.png", dpi=160)
plt.close()

# Manifest and zip.
try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R133_rent_normalized_feedback_candidate_generation_gate.py")
except Exception:
    pass

manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
manifest = pd.DataFrame(manifest_rows)
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()
zip_integrity_pass = bad is None

# Print compact tables.
compact_roster = candidate_roster[[
    "law_id", "power", "candidate_grade", "rent_normalized_dynamic_range",
    "low_mode_relief", "surplus_count", "deficit_count", "surplus_modes", "deficit_modes"
]]

p5_table = mode_adequacy_table[mode_adequacy_table["law_id"] == "p5_quadratic_density_self_energy"][[
    "rho", "available_norm", "required_rent", "adequacy", "closure_class", "support_ecology"
]]
p6_table = mode_adequacy_table[mode_adequacy_table["law_id"] == "p6_curvature_weighted_self_energy"][[
    "rho", "available_norm", "required_rent", "adequacy", "closure_class", "support_ecology"
]]

print("\n=== COPY/PASTE R133 RESULT ===")
print("R133 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"candidate_freeze_hash: {candidate_freeze_hash}")
print(f"rent_normalized_candidates_generated: {rent_normalized_candidates_generated}")
print(f"p4_control_fails_relief: {p4_control_fails_relief}")
print(f"p5_candidate_generated: {p5_candidate_generated}")
print(f"p6_candidate_generated: {p6_candidate_generated}")
print(f"primary_candidates_relieve_reversal: {primary_candidates_relieve_reversal}")
print(f"no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}")
print(f"no_mass_matching_performed: {no_mass_matching_performed}")
print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
print(f"no_final_physical_rent_law_selected: {no_final_physical_rent_law_selected}")
print(f"unique_rent_law_closed: {unique_rent_law_closed}")
print(f"clean_standalone_collective_split_closed: {clean_standalone_collective_split_closed}")
print(f"physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}")
print(f"true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}")
print(f"selected_seed: {{{label_set(SEED)}}}")
print("CANDIDATE_ROSTER:")
print(table_to_text(compact_roster))
print("P5_MODE_ADEQUACY_TABLE:")
print(table_to_text(p5_table))
print("P6_MODE_ADEQUACY_TABLE:")
print(table_to_text(p6_table))
print("CLASSIFICATION_SUMMARY:")
print(table_to_text(classification_summary))
print("GATE_AUDIT:")
print(table_to_text(gate_audit))
print("CLAIM_BOUNDARY:")
for _, row in claim_boundary.iterrows():
    print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
print("OBSERVATION_AWARENESS:")
for _, row in observation_awareness.iterrows():
    print(f"  used={row['used_in_computation']} | {row['observation_context']} -- {row['R133_use']}")
print("NEXT_GATE_PLAN:")
print(table_to_text(next_gate_plan))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R133_summary.md').resolve()}")
print("NEXT: FORCE_R134_observation_sanity_sector_split_control_gate")
print("=== END COPY/PASTE R133 RESULT ===\n")
