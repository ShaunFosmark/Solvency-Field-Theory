# FORCE_R138 — Inter-Mode / Support-Graph Coupling Gate

## Verdict

INTER-MODE SUPPORT-GRAPH COUPLING SCREEN PASS / GRAPH COUPLINGS DIAGNOSTIC, FINAL LAW OPEN

## Main result

The R/C support graph generates useful differential diagnostics, but simple graph coupling does not close the full hierarchy bridge. This suggests support ecology is more likely a classification/susceptibility input than the missing amplitude exponent by itself.

## Key numbers

- Raw feedback dynamic range: 17999.7689742
- Frozen R127 dynamic benchmark: 338083
- Missing factor: 18.7826299595

## Support graph nodes

rho | raw_F     | R_partner | R_status        | C_partner | C_status        | stable_partner_count | virtual_partner_count | boundary_partner_count | weighted_support_degree
----+-----------+-----------+-----------------+-----------+-----------------+----------------------+-----------------------+------------------------+------------------------
1/2 | 0.0199112 | 3/2       | species         | 2         | species         | 2                    | 0                     | 0                      | 2.0                    
2/3 | 0.0743514 | 4/3       | species         | 3/2       | species         | 2                    | 0                     | 0                      | 2.0                    
3/4 | 0.131525  | 5/4       | species         | 4/3       | species         | 2                    | 0                     | 0                      | 2.0                    
1   | 0.461352  | 1         | species         | 1         | species         | 2                    | 0                     | 0                      | 2.0                    
5/4 | 2.62978   | 3/4       | species         | 4/5       | virtual_support | 1                    | 1                     | 0                      | 1.5                    
4/3 | 4.33617   | 2/3       | species         | 3/4       | species         | 2                    | 0                     | 0                      | 2.0                    
3/2 | 12.7039   | 1/2       | species         | 2/3       | species         | 2                    | 0                     | 0                      | 2.0                    
5/3 | 49.8764   | 1/3       | virtual_support | 3/5       | virtual_support | 0                    | 2                     | 0                      | 1.0                    
2   | 358.397   | 0         | boundary_zero   | 1/2       | species         | 1                    | 0                     | 1                      | 1.25                   

## Candidate scorecard

candidate_id                     | kind                         | dynamic_range | target_bridge_factor_remaining | changes_ratios | within_x2_of_target | grade                                  
---------------------------------+------------------------------+---------------+--------------------------------+----------------+---------------------+----------------------------------------
global_graph_mean_factor_CONTROL | global_multiplier_control    | 17999.7689742 | 18.7826299595                  | False          | False               | FAIL_GLOBAL_FACTOR_CANNOT_CHANGE_RATIOS
support_degree_linear            | differential_graph_factor    | 13499.8267307 | 25.0435066127                  | True           | False               | GRAPH_DIAGNOSTIC_ONLY                  
support_degree_sqrt              | differential_graph_factor    | 15588.2571939 | 21.6883129264                  | True           | False               | GRAPH_DIAGNOSTIC_ONLY                  
support_degree_slot_root         | differential_graph_factor    | 16750.6724701 | 20.1832493951                  | True           | False               | GRAPH_DIAGNOSTIC_ONLY                  
support_degree_normal_root       | differential_graph_factor    | 16353.8754347 | 20.6729592231                  | True           | False               | GRAPH_DIAGNOSTIC_ONLY                  
virtual_burden_linear            | differential_virtual_burden  | 17999.7689742 | 18.7826299595                  | True           | False               | GRAPH_DIAGNOSTIC_ONLY                  
virtual_burden_slot_root         | differential_virtual_burden  | 17999.7689742 | 18.7826299595                  | True           | False               | GRAPH_DIAGNOSTIC_ONLY                  
boundary_assistance_linear       | differential_boundary_assist | 35999.5379485 | 9.39131497976                  | True           | False               | GRAPH_STEEPENS_WEAKLY                  
boundary_assistance_slot_root    | differential_boundary_assist | 21405.4533326 | 15.794246202                   | True           | False               | GRAPH_DIAGNOSTIC_ONLY                  

## Claim boundary

status     | claim                                                            | reason                                                                                                         
-----------+------------------------------------------------------------------+----------------------------------------------------------------------------------------------------------------
YES_SCREEN | R138 computes inter-mode R/C support graph differential factors. | Stable partners, virtual support partners, and boundary assistance are computed from the V12.8 support ecology.
YES        | R138 rejects global graph factors as hierarchy bridges.          | Global factors leave ratios and dynamic range unchanged.                                                       
NO         | R138 closes the missing hierarchy factor.                        | Graph factors are diagnostic screens and do not produce a unique bridge law.                                   
NO         | R138 compares to observed particle masses.                       | No empirical mass table or pairwise mass ratios are loaded.                                                    
NO         | R138 maps rho modes to particles.                                | No rho-to-particle assignment is performed.                                                                    
NO         | R138 proves a true collective lag/GR/PDE field.                  | Support-graph factors are mechanical screens, not solved field equations.                                      
