from pathlib import Path
import json
import math
import zipfile
import shutil
import hashlib
import pandas as pd

try:
    import matplotlib.pyplot as plt
    HAS_MPL = True
except Exception:
    HAS_MPL = False

OUT = Path("FORCE_R140_compare_R137_R139_bridge_candidates_gate")
ZIP = Path("FORCE_R140_compare_R137_R139_bridge_candidates_gate_pack.zip")
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

RAW_DYNAMIC = 17999.7689742
FROZEN_BENCHMARK = 338083.0
MISSING_FACTOR = FROZEN_BENCHMARK / RAW_DYNAMIC
SEED = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dyn_status(dynamic_range: float):
    if dynamic_range <= 0:
        return "INVALID", None, False, False
    if dynamic_range < FROZEN_BENCHMARK:
        ratio = FROZEN_BENCHMARK / dynamic_range
        direction = "shortfall"
    else:
        ratio = dynamic_range / FROZEN_BENCHMARK
        direction = "overshoot"
    within_x2 = ratio <= 2.0
    within_25pct = ratio <= 1.25
    return direction, ratio, within_x2, within_25pct


def candidate_row(candidate_id, family, mechanism, dynamic_range, operation, source_gate,
                  native_status, posthoc=False, mass_loaded=False, notes=""):
    direction, ratio, within_x2, within_25pct = dyn_status(dynamic_range)
    can_change_ratios = "global" not in operation.lower()
    if posthoc:
        grade = "POSTHOC_CONTROL_NOT_LAW"
    elif not can_change_ratios:
        grade = "FAIL_GLOBAL_FACTOR_CANNOT_CHANGE_RATIOS"
    elif within_25pct and native_status in ["native_strong", "native_candidate"]:
        grade = "PRIMARY_BRIDGE_CANDIDATE"
    elif within_x2 and native_status in ["native_strong", "native_candidate"]:
        grade = "SECONDARY_BRIDGE_CANDIDATE"
    elif within_x2:
        grade = "NUMERIC_NEAR_BRIDGE_DIAGNOSTIC"
    elif dynamic_range < FROZEN_BENCHMARK:
        grade = "UNDER_BRIDGE_CONTROL"
    else:
        grade = "OVER_BRIDGE_CONTROL"
    return {
        "candidate_id": candidate_id,
        "family": family,
        "source_gate": source_gate,
        "mechanism": mechanism,
        "operation": operation,
        "dynamic_range": dynamic_range,
        "target_dynamic_range": FROZEN_BENCHMARK,
        "direction_vs_target": direction,
        "remaining_or_overshoot_factor": ratio,
        "within_x2": within_x2,
        "within_25pct": within_25pct,
        "can_change_ratios": can_change_ratios,
        "native_status": native_status,
        "posthoc": posthoc,
        "mass_loaded": mass_loaded,
        "grade": grade,
        "notes": notes,
    }


# R137/R139/R138 values imported as frozen benchmark outputs, not recomputed from masses.
beta_6pi = math.log(6 * math.pi) / math.log(RAW_DYNAMIC)
beta_18 = math.log(18) / math.log(RAW_DYNAMIC)
beta_12 = math.log(12) / math.log(RAW_DYNAMIC)
beta_4pi2 = math.log(4 * math.pi * math.pi) / math.log(RAW_DYNAMIC)
beta_required = math.log(FROZEN_BENCHMARK / RAW_DYNAMIC) / math.log(RAW_DYNAMIC)

rows = []
rows.append(candidate_row(
    "raw_feedback_no_bridge_control", "raw_feedback", "scalar lag/radius-depth feedback only",
    RAW_DYNAMIC, "identity_no_correction", "R126/R127", "native_strong",
    notes="Lead raw mass-amplitude candidate before missing-factor bridge."
))
rows.append(candidate_row(
    "R137_slot_root_beta_1_over_4", "compound_transverse_lens", "1 tangent + 3 normal slot-root exponent",
    RAW_DYNAMIC ** (1 + 0.25), "exponent_differential", "R137", "native_candidate",
    notes="Fixed beta=1/4 from slot-capacity root; brackets target from below."
))
rows.append(candidate_row(
    "R137_normal_dimension_beta_1_over_3", "compound_transverse_lens", "three-normal-dimension exponent",
    RAW_DYNAMIC ** (1 + (1/3)), "exponent_differential", "R137", "native_candidate",
    notes="Fixed beta=1/3 from three transverse normals; brackets target from above."
))
rows.append(candidate_row(
    "R137_transverse_phase_volume_6pi_exponent", "compound_transverse_lens", "three transverse angular channels, 6pi as exponent source",
    RAW_DYNAMIC ** (1 + beta_6pi), "exponent_differential", "R137", "native_candidate",
    notes="6pi enters as beta=ln(6pi)/ln(D_raw), not as global multiplier."
))
rows.append(candidate_row(
    "R137_oriented_modes_18_exponent", "compound_transverse_lens", "18 oriented seed channels as exponent source",
    RAW_DYNAMIC ** (1 + beta_18), "exponent_differential", "R137", "native_candidate",
    notes="18 enters as exponent/range source; numerically near target."
))
rows.append(candidate_row(
    "R137_support_channels_12_exponent", "compound_transverse_lens", "12 support channels as exponent source",
    RAW_DYNAMIC ** (1 + beta_12), "exponent_differential", "R137", "native_candidate",
    notes="Support-channel exponent source; under target but within factor two."
))
rows.append(candidate_row(
    "R137_boundary_bulk_4pi2_exponent", "compound_transverse_lens", "4pi^2 phase/boundary bridge as exponent source",
    RAW_DYNAMIC ** (1 + beta_4pi2), "exponent_differential", "R137", "native_candidate",
    notes="Over-bridges; useful upper diagnostic."
))
rows.append(candidate_row(
    "R137_posthoc_required_beta_control", "compound_transverse_lens", "required beta computed from target benchmark",
    FROZEN_BENCHMARK, "exponent_differential", "R137", "posthoc_control", posthoc=True,
    notes="Reported only as control; cannot be used as law."
))

# R139 boundary/insolvency screen values.
rows.append(candidate_row(
    "R139_V11_extra_linear_N_rho", "boundary_insolvency", "one extra N from N^3/N^2 boundary insolvency",
    71999.075897, "differential_factor_rho", "R139", "native_candidate",
    notes="Too weak by itself; useful lower control."
))
rows.append(candidate_row(
    "R139_boundary_area_rho2_candidate", "boundary_insolvency", "two-dimensional inverse boundary-area response",
    287996.303588, "differential_factor_rho2", "R139", "native_strong",
    notes="Strong V11-adjacent near-bridge candidate; clean mechanical interpretation."
))
rows.append(candidate_row(
    "R139_bulk_volume_rho3_control", "boundary_insolvency", "three-dimensional bulk-volume response",
    1151985.21435, "differential_factor_rho3", "R139", "native_candidate",
    notes="Over-bridge control; suggests rho^2 boundary area is closer than rho^3 bulk volume."
))
rows.append(candidate_row(
    "R139_write_density_rho4_overbridge_control", "boundary_insolvency", "four-power write-density correction",
    4607940.85741, "differential_factor_rho4", "R139", "native_candidate",
    notes="High-order over-bridge control."
))
rows.append(candidate_row(
    "R139_denominator_complexity_wrong_direction", "boundary_insolvency", "denominator complexity control",
    8999.88448712, "fraction_complexity_differential", "R139", "diagnostic",
    notes="Wrong-direction/under-bridge complexity control."
))
rows.append(candidate_row(
    "R139_numerator_complexity_control", "boundary_insolvency", "numerator complexity control",
    35999.5379485, "fraction_complexity_differential", "R139", "diagnostic",
    notes="Weak complexity control, not bridge."
))
rows.append(candidate_row(
    "R139_sqrt_boundary_bulk_4pi2_shape", "boundary_insolvency", "4pi^2 shape exponent control",
    61289.6079388, "shape_exponent_differential", "R139", "diagnostic",
    notes="Under-bridge; not a primary route."
))

# R138 best graph diagnostics for completeness.
rows.append(candidate_row(
    "R138_boundary_assistance_linear", "support_graph", "boundary-assistance graph differential",
    35999.5379485, "graph_differential", "R138", "diagnostic",
    notes="Best graph steepener but far below target."
))
rows.append(candidate_row(
    "R138_support_degree_slot_root", "support_graph", "R/C support degree slot-root differential",
    16750.6724701, "graph_differential", "R138", "diagnostic",
    notes="Graph ecology diagnostic; not bridge."
))
rows.append(candidate_row(
    "global_missing_factor_control", "global_multiplier", "posthoc missing factor inserted globally",
    RAW_DYNAMIC, "global_multiplier", "R136/R139", "posthoc_control", posthoc=True,
    notes="Must fail because global factors do not change ratios or dynamic range."
))

scorecard = pd.DataFrame(rows)
scorecard = scorecard.sort_values(
    by=["within_25pct", "within_x2", "remaining_or_overshoot_factor"],
    ascending=[False, False, True]
).reset_index(drop=True)

primary = scorecard[(scorecard["grade"] == "PRIMARY_BRIDGE_CANDIDATE") & (~scorecard["posthoc"])]
secondary = scorecard[(scorecard["grade"] == "SECONDARY_BRIDGE_CANDIDATE") & (~scorecard["posthoc"])]
global_failures = scorecard[scorecard["operation"].str.contains("global", case=False, na=False)]

primary_candidates_present = len(primary) > 0
r137_primary_present = any(primary["source_gate"].eq("R137"))
r139_primary_present = any(primary["source_gate"].eq("R139"))
r138_bridge_present = any((scorecard["source_gate"] == "R138") & (scorecard["within_x2"]))
global_multiplier_rejected = bool(len(global_failures) > 0 and not global_failures["can_change_ratios"].any())
no_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_parameter_fit_performed = True
no_mode_particle_mapping_performed = True
no_final_physical_mass_law_selected = True
unique_bridge_law_closed = False
true_GR_PDE_collective_field_closed = False
physical_mass_spectrum_claimed = False

# Mechanism rollup.
family_rollup = scorecard.groupby("family").agg(
    candidates=("candidate_id", "count"),
    best_dynamic=("dynamic_range", "max"),
    best_factor=("remaining_or_overshoot_factor", "min"),
    any_within_x2=("within_x2", "any"),
    any_within_25pct=("within_25pct", "any"),
).reset_index()

mechanism_interpretation = pd.DataFrame([
    {
        "mechanism": "compound_transverse_lens_exponent",
        "status": "PRIMARY_SURVIVOR",
        "interpretation": "Numerically strongest. 6pi-as-exponent source nearly matches frozen benchmark, but exponent entry needs derivation.",
        "next_test": "Derive why transverse phase volume enters as exponent rather than factor.",
    },
    {
        "mechanism": "boundary_insolvency_area_response",
        "status": "PRIMARY_SURVIVOR",
        "interpretation": "Mechanically cleanest. rho^2 inverse boundary-area response is V11-adjacent and near target.",
        "next_test": "Derive inverse boundary-area response from boundary/bulk accounting or lag field equation.",
    },
    {
        "mechanism": "support_graph_coupling",
        "status": "DIAGNOSTIC_NOT_BRIDGE",
        "interpretation": "Useful for closure ecology but too weak for hierarchy bridge.",
        "next_test": "Keep as sector/ecology diagnostic, not lead mass amplification route.",
    },
    {
        "mechanism": "global_multiplier",
        "status": "REJECTED",
        "interpretation": "Global factors do not change ratios or dynamic range.",
        "next_test": "Do not use global missing-factor patches.",
    },
])

claim_boundary = pd.DataFrame([
    {"status": "YES_SCREEN", "claim": "R140 compares R137/R138/R139 bridge candidates without loading masses.", "reason": "Only frozen dynamic-range benchmark and candidate values from prior gates are used."},
    {"status": "YES", "claim": "Global multipliers are rejected as hierarchy bridges.", "reason": "They leave ratios and dynamic range unchanged."},
    {"status": "YES_SCREEN", "claim": "R137 exponent and R139 boundary-area candidates survive as primary bridge screens.", "reason": "Both are differential, non-posthoc, and within 25% of the frozen benchmark."},
    {"status": "YES_SCREEN", "claim": "R138 support-graph coupling remains diagnostic but not primary bridge.", "reason": "Graph factors do not reach factor-two proximity to the benchmark."},
    {"status": "NO", "claim": "R140 selects a final physical mass law.", "reason": "Candidate comparison is not a derivation or mass fit."},
    {"status": "NO", "claim": "R140 compares candidates to observed particle masses.", "reason": "No empirical mass table or pairwise mass ratios are loaded."},
    {"status": "NO", "claim": "R140 maps rho modes to particles.", "reason": "No rho-to-particle assignments are made."},
    {"status": "NO", "claim": "R140 closes GR/PDE collective field dynamics.", "reason": "Field-equation derivation remains open."},
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R141",
        "title": "Bridge Candidate Synthesis / Freeze Gate",
        "goal": "Freeze the primary bridge candidates from R137/R139 and prepare a no-overclaim candidate roster.",
        "must_not_do": "Do not select a final law or choose by mass hits.",
    },
    {
        "next_gate": "FORCE_R142",
        "title": "Locked Bridge-Candidate Mass Screen Gate",
        "goal": "Only after R141 freeze, compare primary bridge candidates blindly against mass-ratio screens.",
        "must_not_do": "Do not retune exponent, rho^2 correction, or mappings after seeing hits.",
    },
    {
        "next_gate": "FORCE_R128",
        "title": "GR/Lag Field Derivation Gate",
        "goal": "Attempt to derive exponent and boundary-area response from a principled lag/field equation.",
        "must_not_do": "Do not treat dynamic-range screens as field-equation closure.",
    },
])

# Save artifacts.
scorecard.to_csv(OUT / "FORCE_R140_candidate_scorecard.csv", index=False)
primary.to_csv(OUT / "FORCE_R140_primary_bridge_candidates.csv", index=False)
secondary.to_csv(OUT / "FORCE_R140_secondary_bridge_candidates.csv", index=False)
family_rollup.to_csv(OUT / "FORCE_R140_family_rollup.csv", index=False)
mechanism_interpretation.to_csv(OUT / "FORCE_R140_mechanism_interpretation.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R140_claim_boundary.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R140_next_gate_plan.csv", index=False)

if HAS_MPL:
    try:
        plot_df = scorecard[~scorecard["posthoc"]].copy().head(14)
        plt.figure(figsize=(12, 7))
        plt.barh(plot_df["candidate_id"], plot_df["dynamic_range"])
        plt.axvline(FROZEN_BENCHMARK, linestyle="--")
        plt.xscale("log")
        plt.xlabel("dynamic range (log scale)")
        plt.title("R140 bridge candidate dynamic ranges")
        plt.tight_layout()
        plt.savefig(PLOTS / "bridge_candidate_dynamic_ranges.png", dpi=160)
        plt.close()
    except Exception as e:
        (OUT / "plot_error.txt").write_text(str(e), encoding="utf-8")

verdict_status = "BRIDGE CANDIDATE COMPARISON PASS / R137-R139 PRIMARY CANDIDATES SURVIVE, FINAL LAW OPEN"

if not (primary_candidates_present and r137_primary_present and r139_primary_present and global_multiplier_rejected):
    verdict_status = "BRIDGE CANDIDATE COMPARISON INCONCLUSIVE"

verdict = {
    "force_id": "FORCE_R140",
    "title": "Compare R137/R139 Bridge Candidates Gate",
    "status": verdict_status,
    "freeze_id": FREEZE_ID,
    "raw_feedback_dynamic_range": RAW_DYNAMIC,
    "frozen_R127_dynamic_benchmark": FROZEN_BENCHMARK,
    "missing_factor": MISSING_FACTOR,
    "required_beta_control_not_law": beta_required,
    "candidate_values_generated": True,
    "primary_candidates_present": primary_candidates_present,
    "r137_primary_present": r137_primary_present,
    "r139_primary_present": r139_primary_present,
    "r138_bridge_present": r138_bridge_present,
    "global_multiplier_rejected": global_multiplier_rejected,
    "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
    "no_mass_matching_performed": no_mass_matching_performed,
    "no_parameter_fit_performed": no_parameter_fit_performed,
    "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
    "no_final_physical_mass_law_selected": no_final_physical_mass_law_selected,
    "unique_bridge_law_closed": unique_bridge_law_closed,
    "true_GR_PDE_collective_field_closed": true_GR_PDE_collective_field_closed,
    "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
    "selected_seed": SEED,
    "recommended_next": "FORCE_R141_bridge_candidate_synthesis_freeze_gate_or_FORCE_R128_GR_lag_field_derivation_gate",
}

(OUT / "FORCE_R140_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R140 — Compare R137/R139 Bridge Candidates Gate

## Verdict

BOXED: {verdict_status}

## Frozen inputs

- raw_feedback_dynamic_range: {RAW_DYNAMIC}
- frozen_R127_dynamic_benchmark: {FROZEN_BENCHMARK}
- missing_factor: {MISSING_FACTOR}
- required_beta_control_not_law: {beta_required}

## Interpretation

R140 compares the leading bridge routes after R137/R138/R139. It does not load masses, does not perform pairwise matching, does not tune parameters, and does not select a final physical law.

The primary survivors are:

1. R137 compound transverse-lens exponent candidates, especially 6pi-as-exponent and 18-oriented-channel exponent screens.
2. R139 boundary-area rho^2 inverse-area response.

R138 support-graph coupling remains useful for closure ecology but is not a leading hierarchy bridge.

## Candidate scorecard

{scorecard.to_string(index=False)}

## Mechanism interpretation

{mechanism_interpretation.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}
"""
(OUT / "FORCE_R140_summary.md").write_text(summary, encoding="utf-8")

# Manifest last.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({"relative_path": str(p.relative_to(OUT)), "bytes": p.stat().st_size, "sha256": sha256_file(p)})
manifest = pd.DataFrame(manifest_rows)
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Copy script if possible.
try:
    shutil.copy2(Path(__file__).resolve(), OUT / Path(__file__).name)
except Exception:
    pass

if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()
zip_ok = bad is None

# Compact ASCII print helper.
def print_table(df, cols=None, max_rows=30):
    if cols:
        df = df[cols]
    if len(df) > max_rows:
        df = df.head(max_rows)
    print(df.to_string(index=False))

print("\n=== COPY/PASTE R140 RESULT ===")
print("R140 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else bad}")
print(f"raw_feedback_dynamic_range: {RAW_DYNAMIC}")
print(f"frozen_R127_dynamic_benchmark: {FROZEN_BENCHMARK:g}")
print(f"missing_factor: {MISSING_FACTOR}")
print(f"required_beta_control_not_law: {beta_required}")
print(f"candidate_values_generated: {True}")
print(f"primary_candidates_present: {primary_candidates_present}")
print(f"r137_primary_present: {r137_primary_present}")
print(f"r139_primary_present: {r139_primary_present}")
print(f"r138_bridge_present: {r138_bridge_present}")
print(f"global_multiplier_rejected: {global_multiplier_rejected}")
print(f"no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}")
print(f"no_mass_matching_performed: {no_mass_matching_performed}")
print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
print(f"no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}")
print(f"unique_bridge_law_closed: {unique_bridge_law_closed}")
print(f"true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}")
print(f"physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}")
print("PRIMARY_BRIDGE_CANDIDATES:")
print_table(primary, ["candidate_id", "family", "dynamic_range", "remaining_or_overshoot_factor", "within_25pct", "grade", "notes"], max_rows=20)
print("SECONDARY_BRIDGE_CANDIDATES:")
print_table(secondary, ["candidate_id", "family", "dynamic_range", "remaining_or_overshoot_factor", "within_x2", "grade", "notes"], max_rows=20)
print("FAMILY_ROLLUP:")
print_table(family_rollup, max_rows=20)
print("MECHANISM_INTERPRETATION:")
print_table(mechanism_interpretation, max_rows=20)
print("CLAIM_BOUNDARY:")
print_table(claim_boundary, max_rows=20)
print("NEXT_GATE_PLAN:")
print_table(next_gate_plan, max_rows=20)
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R140_summary.md').resolve()}")
print("NEXT: FORCE_R141_bridge_candidate_synthesis_freeze_gate_or_FORCE_R128_GR_lag_field_derivation_gate")
print("=== END COPY/PASTE R140 RESULT ===\n")
