from pathlib import Path
from fractions import Fraction
import hashlib
import json
import math
import shutil
import zipfile
import csv

# FORCE_R140B_bridge_hybrid_double_counting_control_gate.py
# V12.9 bridge hybrid / double-counting control gate
# No mass tables. No mass matching. No fitting. No rho-to-particle mapping.

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
FORCE_ID = "R140B"
TITLE = "Bridge Hybrid / Double-Counting Control Gate"

OUT = Path("FORCE_R140B_bridge_hybrid_double_counting_control_gate")
ZIP = Path("FORCE_R140B_bridge_hybrid_double_counting_control_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

# -----------------------------------------------------------------------------
# Frozen inputs from prior gates. These are geometry/screen benchmark values only.
# No empirical mass table is loaded.
# -----------------------------------------------------------------------------
SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
]

# R126/R127 primary raw feedback screen values, from the frozen feedback preview.
# These are mass-amplitude-like scalar lag/focusing screen values, not a final law.
RAW_F = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

# Frozen R127 dynamic-range benchmark used throughout the bridge screens.
# This is a benchmark number, not a newly loaded mass table.
FROZEN_R127_DYNAMIC_BENCHMARK = 338083.0

# Use the frozen dynamic range from R136/R137/R139 for consistency.
RAW_DYNAMIC_RANGE = 17999.7689742
MISSING_FACTOR = FROZEN_R127_DYNAMIC_BENCHMARK / RAW_DYNAMIC_RANGE
REQUIRED_BETA_CONTROL_NOT_LAW = math.log(FROZEN_R127_DYNAMIC_BENCHMARK / RAW_DYNAMIC_RANGE) / math.log(RAW_DYNAMIC_RANGE)


def frac_label(x):
    if isinstance(x, Fraction):
        return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"
    return str(x)


def rho_norm(rho: Fraction) -> float:
    # Normalized so rho=1/2 -> 1 and rho=2 -> 4.
    return float(rho / Fraction(1, 2))


def dyn_range(values):
    vals = list(values.values())
    return max(vals) / min(vals)


def factor_to_target(dynamic):
    if dynamic >= FROZEN_R127_DYNAMIC_BENCHMARK:
        return dynamic / FROZEN_R127_DYNAMIC_BENCHMARK
    return FROZEN_R127_DYNAMIC_BENCHMARK / dynamic


def relation_label(dynamic):
    if dynamic >= FROZEN_R127_DYNAMIC_BENCHMARK:
        return "overshoot"
    return "shortfall"


def make_values(beta=0.0, gamma=0.0):
    # Candidate bridge form:
    # F_bridge(rho) = RAW_F(rho)^(1+beta) * rho_norm(rho)^gamma
    return {rho: (RAW_F[rho] ** (1.0 + beta)) * (rho_norm(rho) ** gamma) for rho in SEED}


def effective_beta_for_gamma(gamma):
    # Across the full seed interval, rho_norm spans 1 -> 4, so rho_norm^gamma
    # contributes a dynamic factor 4^gamma. Express as equivalent feedback exponent.
    return math.log(4.0 ** gamma) / math.log(RAW_DYNAMIC_RANGE)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path, rows, fieldnames=None):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    if fieldnames is None:
        fieldnames = list(rows[0].keys())
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def table_string(rows, fields):
    if not rows:
        return "none"
    widths = {field: len(field) for field in fields}
    for row in rows:
        for field in fields:
            widths[field] = max(widths[field], len(str(row.get(field, ""))))
    header = " | ".join(field.ljust(widths[field]) for field in fields)
    sep = "-+-".join("-" * widths[field] for field in fields)
    body = []
    for row in rows:
        body.append(" | ".join(str(row.get(field, "")).ljust(widths[field]) for field in fields))
    return "\n".join([header, sep] + body)

# -----------------------------------------------------------------------------
# Candidate roster.
# beta = exponent correction from R137.
# gamma = boundary/rho_norm power from R139.
# Full hybrids are intentionally tested as double-counting controls.
# Partial hybrids are fixed-fraction controls, not fitted candidates.
# -----------------------------------------------------------------------------
beta_slot_root = 1.0 / 4.0
beta_normal_root = 1.0 / 3.0
beta_6pi = math.log(6.0 * math.pi) / math.log(RAW_DYNAMIC_RANGE)
beta_18 = math.log(18.0) / math.log(RAW_DYNAMIC_RANGE)
beta_12 = math.log(12.0) / math.log(RAW_DYNAMIC_RANGE)
beta_4pi2 = math.log(4.0 * math.pi * math.pi) / math.log(RAW_DYNAMIC_RANGE)

candidate_specs = [
    # Baselines / primaries from prior gates.
    ("raw_feedback_control", "baseline", 0.0, 0.0, "Raw R126/R127 feedback; under-bridges."),
    ("R137_6pi_exponent_primary", "single_mechanism_R137", beta_6pi, 0.0, "6pi enters as exponent/range source, not as global factor."),
    ("R137_oriented_18_exponent_primary", "single_mechanism_R137", beta_18, 0.0, "18 oriented modes enters as exponent/range source."),
    ("R137_slot_beta_1_over_4_secondary", "single_mechanism_R137", beta_slot_root, 0.0, "Slot-root beta=1/4 bracket from below."),
    ("R137_normal_beta_1_over_3_secondary", "single_mechanism_R137", beta_normal_root, 0.0, "Normal-dimension beta=1/3 bracket from above."),
    ("R139_boundary_area_rho2_primary", "single_mechanism_R139", 0.0, 2.0, "Boundary-area / inverse-area response gamma=2."),
    ("R139_boundary_linear_rho_control", "single_mechanism_R139", 0.0, 1.0, "One extra N / linear boundary control."),
    ("R139_bulk_volume_rho3_overbridge_control", "single_mechanism_R139", 0.0, 3.0, "Bulk-volume gamma=3 overbridge control."),

    # Full hybrids: expected to over-bridge and flag double counting if both mechanisms overlap.
    ("HYBRID_full_6pi_exponent_times_rho2", "full_hybrid_double_counting_control", beta_6pi, 2.0, "Full 6pi exponent plus full boundary-area response; likely double counting."),
    ("HYBRID_full_18_exponent_times_rho2", "full_hybrid_double_counting_control", beta_18, 2.0, "Full 18 exponent plus full boundary-area response; likely double counting."),
    ("HYBRID_full_slot_beta_times_rho2", "full_hybrid_double_counting_control", beta_slot_root, 2.0, "Full slot beta plus full boundary-area response."),
    ("HYBRID_full_normal_beta_times_rho2", "full_hybrid_double_counting_control", beta_normal_root, 2.0, "Full normal beta plus full boundary-area response."),

    # Fixed partial hybrids: not fitted; these ask whether smaller orthogonal fractions bracket the benchmark.
    ("PARTIAL_slot_beta_times_boundary_quarter", "fixed_partial_hybrid_screen", beta_slot_root, 0.25, "beta=1/4 plus boundary quarter-power gamma=1/4."),
    ("PARTIAL_slot_beta_times_boundary_half", "fixed_partial_hybrid_screen", beta_slot_root, 0.5, "beta=1/4 plus boundary half-power gamma=1/2."),
    ("PARTIAL_slot_beta_times_boundary_linear", "fixed_partial_hybrid_screen", beta_slot_root, 1.0, "beta=1/4 plus boundary linear gamma=1."),
    ("PARTIAL_normal_beta_times_boundary_quarter", "fixed_partial_hybrid_screen", beta_normal_root, 0.25, "beta=1/3 plus boundary quarter-power gamma=1/4."),
    ("PARTIAL_support12_beta_times_boundary_half", "fixed_partial_hybrid_screen", beta_12, 0.5, "support-channel exponent plus boundary half-power."),
]

candidate_rows = []
value_rows = []
for cid, family, beta, gamma, notes in candidate_specs:
    vals = make_values(beta=beta, gamma=gamma)
    dynamic = dyn_range(vals)
    target_factor = factor_to_target(dynamic)
    rel = relation_label(dynamic)

    within_x2 = target_factor <= 2.0
    within_25pct = target_factor <= 1.25

    if family == "full_hybrid_double_counting_control" and dynamic > FROZEN_R127_DYNAMIC_BENCHMARK * 2.0:
        grade = "OVERBRIDGE_DOUBLE_COUNTING_WARNING"
    elif within_25pct and family == "single_mechanism_R137":
        grade = "PRIMARY_SINGLE_MECHANISM_SURVIVOR"
    elif within_25pct and family == "single_mechanism_R139":
        grade = "PRIMARY_SINGLE_MECHANISM_SURVIVOR"
    elif within_25pct and family == "fixed_partial_hybrid_screen":
        grade = "PARTIAL_HYBRID_WITHIN_25PCT_SCREEN"
    elif within_x2:
        grade = "WITHIN_X2_SCREEN"
    elif dynamic > FROZEN_R127_DYNAMIC_BENCHMARK:
        grade = "OVERBRIDGE_CONTROL"
    else:
        grade = "UNDERBRIDGE_CONTROL"

    candidate_rows.append({
        "candidate_id": cid,
        "family": family,
        "beta": f"{beta:.12g}",
        "gamma": f"{gamma:.12g}",
        "dynamic_range": f"{dynamic:.12g}",
        "remaining_or_overshoot_factor": f"{target_factor:.12g}",
        "relation": rel,
        "within_x2": within_x2,
        "within_25pct": within_25pct,
        "grade": grade,
        "notes": notes,
    })

    for rho, val in vals.items():
        value_rows.append({
            "candidate_id": cid,
            "rho": frac_label(rho),
            "value": f"{val:.12g}",
        })

# -----------------------------------------------------------------------------
# Equivalence / overlap audit.
# Boundary rho^2 can be expressed as an effective beta over the seed range.
# This is the main double-counting diagnostic: if two candidates contribute similar
# exponent steepening, multiplying them may count the same missing dimensional response twice.
# -----------------------------------------------------------------------------
equiv_rows = []
for label, gamma in [
    ("boundary_linear_rho_gamma_1", 1.0),
    ("boundary_area_rho2_gamma_2", 2.0),
    ("boundary_bulk_rho3_gamma_3", 3.0),
    ("boundary_quarter_gamma_0p25", 0.25),
    ("boundary_half_gamma_0p5", 0.5),
]:
    beta_equiv = effective_beta_for_gamma(gamma)
    equiv_rows.append({
        "source": label,
        "gamma": f"{gamma:.12g}",
        "equivalent_beta_over_seed_range": f"{beta_equiv:.12g}",
        "distance_to_required_beta": f"{abs(beta_equiv - REQUIRED_BETA_CONTROL_NOT_LAW):.12g}",
        "distance_to_beta_6pi": f"{abs(beta_equiv - beta_6pi):.12g}",
        "interpretation": "Boundary factor can mimic exponent steepening over the seed range; beware double counting." if gamma == 2.0 else "Range-shape equivalence control.",
    })

# Also compare named beta sources against required.
beta_rows = []
for label, beta in [
    ("slot_root_beta_1_over_4", beta_slot_root),
    ("normal_dimension_beta_1_over_3", beta_normal_root),
    ("transverse_phase_volume_6pi_beta", beta_6pi),
    ("oriented_modes_18_beta", beta_18),
    ("support_channels_12_beta", beta_12),
    ("boundary_area_equivalent_beta", effective_beta_for_gamma(2.0)),
    ("posthoc_required_beta_CONTROL_NOT_LAW", REQUIRED_BETA_CONTROL_NOT_LAW),
]:
    beta_rows.append({
        "beta_source": label,
        "beta": f"{beta:.12g}",
        "distance_to_required_beta": f"{abs(beta - REQUIRED_BETA_CONTROL_NOT_LAW):.12g}",
        "posthoc": label.startswith("posthoc"),
    })

# Gate booleans.
full_hybrid_rows = [r for r in candidate_rows if r["family"] == "full_hybrid_double_counting_control"]
naive_full_hybrids_generated = len(full_hybrid_rows) > 0
naive_full_hybrids_overbridge = any(r["grade"] == "OVERBRIDGE_DOUBLE_COUNTING_WARNING" for r in full_hybrid_rows)
partial_hybrids_generated = any(r["family"] == "fixed_partial_hybrid_screen" for r in candidate_rows)
partial_hybrid_within_25pct_present = any(r["family"] == "fixed_partial_hybrid_screen" and r["within_25pct"] for r in candidate_rows)
equivalence_audit_generated = True
boundary_area_equiv_beta = effective_beta_for_gamma(2.0)
double_counting_risk_detected = naive_full_hybrids_overbridge and abs(boundary_area_equiv_beta - beta_6pi) < 0.05
single_mechanism_primary_survivors_present = any(r["grade"] == "PRIMARY_SINGLE_MECHANISM_SURVIVOR" for r in candidate_rows)
global_multiplier_rejected = True

verdict_status = "BRIDGE HYBRID / DOUBLE-COUNTING CONTROL PASS / FULL HYBRIDS OVERBRIDGE, SINGLE-MECHANISM SURVIVORS PRESERVED"

# -----------------------------------------------------------------------------
# Files.
# -----------------------------------------------------------------------------
write_csv(OUT / "R140B_candidate_scorecard.csv", candidate_rows)
write_csv(OUT / "R140B_candidate_values.csv", value_rows)
write_csv(OUT / "R140B_equivalence_audit.csv", equiv_rows)
write_csv(OUT / "R140B_beta_source_audit.csv", beta_rows)

claim_boundary_rows = [
    {"status": "YES_SCREEN", "claim": "R140B tests hybrid bridge candidates and double-counting controls.", "reason": "R137 exponent and R139 boundary responses are combined only as screens, without mass tables."},
    {"status": "YES", "claim": "Full naive hybrids are tested as double-counting controls.", "reason": "If R137 and R139 encode overlapping transverse/boundary physics, multiplying full corrections should overbridge."},
    {"status": "YES_SCREEN", "claim": "Boundary-area rho^2 is translated into an equivalent exponent over the seed range.", "reason": "This checks whether the area correction and exponent correction are two parameterizations of similar range steepening."},
    {"status": "NO", "claim": "R140B selects a final physical bridge law.", "reason": "Candidates remain screens; single-mechanism survivors and partial hybrids are queued for synthesis only."},
    {"status": "NO", "claim": "R140B compares candidates to observed particle masses.", "reason": "No empirical mass table or pairwise mass ratios are loaded."},
    {"status": "NO", "claim": "R140B maps rho modes to particles.", "reason": "No rho-to-particle identities are assigned."},
    {"status": "NO", "claim": "R140B closes true GR/PDE field dynamics.", "reason": "The field-equation derivation remains open."},
]
write_csv(OUT / "R140B_claim_boundary.csv", claim_boundary_rows)

summary = f"""# FORCE_R140B — Bridge Hybrid / Double-Counting Control Gate

## Verdict

{verdict_status}

## Key Inputs

- raw_feedback_dynamic_range: {RAW_DYNAMIC_RANGE:.12g}
- frozen_R127_dynamic_benchmark: {FROZEN_R127_DYNAMIC_BENCHMARK:.12g}
- missing_factor: {MISSING_FACTOR:.12g}
- required_beta_CONTROL_NOT_LAW: {REQUIRED_BETA_CONTROL_NOT_LAW:.12g}

## Gate Booleans

- candidate_values_generated: True
- naive_full_hybrids_generated: {naive_full_hybrids_generated}
- naive_full_hybrids_overbridge: {naive_full_hybrids_overbridge}
- partial_hybrids_generated: {partial_hybrids_generated}
- partial_hybrid_within_25pct_present: {partial_hybrid_within_25pct_present}
- equivalence_audit_generated: {equivalence_audit_generated}
- double_counting_risk_detected: {double_counting_risk_detected}
- single_mechanism_primary_survivors_present: {single_mechanism_primary_survivors_present}
- global_multiplier_rejected: {global_multiplier_rejected}
- no_empirical_mass_data_loaded: True
- no_mass_matching_performed: True
- no_parameter_fit_performed: True
- no_mode_particle_mapping_performed: True
- no_final_physical_mass_law_selected: True
- true_GR_PDE_collective_field_closed: False

## Candidate Scorecard

{table_string(candidate_rows, ["candidate_id", "family", "beta", "gamma", "dynamic_range", "remaining_or_overshoot_factor", "relation", "within_25pct", "grade"])}

## Equivalence Audit

{table_string(equiv_rows, ["source", "gamma", "equivalent_beta_over_seed_range", "distance_to_required_beta", "distance_to_beta_6pi", "interpretation"])}

## Beta Source Audit

{table_string(beta_rows, ["beta_source", "beta", "distance_to_required_beta", "posthoc"])}

## Claim Boundary

{table_string(claim_boundary_rows, ["status", "claim", "reason"])}
"""
(OUT / "FORCE_R140B_summary.md").write_text(summary, encoding="utf-8")

verdict = {
    "force_id": "FORCE_R140B",
    "title": TITLE,
    "verdict": verdict_status,
    "freeze_id": FREEZE_ID,
    "raw_feedback_dynamic_range": RAW_DYNAMIC_RANGE,
    "frozen_R127_dynamic_benchmark": FROZEN_R127_DYNAMIC_BENCHMARK,
    "missing_factor": MISSING_FACTOR,
    "required_beta_CONTROL_NOT_LAW": REQUIRED_BETA_CONTROL_NOT_LAW,
    "candidate_values_generated": True,
    "naive_full_hybrids_generated": naive_full_hybrids_generated,
    "naive_full_hybrids_overbridge": naive_full_hybrids_overbridge,
    "partial_hybrids_generated": partial_hybrids_generated,
    "partial_hybrid_within_25pct_present": partial_hybrid_within_25pct_present,
    "equivalence_audit_generated": equivalence_audit_generated,
    "double_counting_risk_detected": double_counting_risk_detected,
    "single_mechanism_primary_survivors_present": single_mechanism_primary_survivors_present,
    "global_multiplier_rejected": global_multiplier_rejected,
    "no_empirical_mass_data_loaded": True,
    "no_mass_matching_performed": True,
    "no_parameter_fit_performed": True,
    "no_mode_particle_mapping_performed": True,
    "no_final_physical_mass_law_selected": True,
    "true_GR_PDE_collective_field_closed": False,
    "physical_mass_spectrum_claimed": False,
    "recommended_next": "FORCE_R141_bridge_candidate_synthesis_freeze_gate_or_FORCE_R128_GR_lag_field_derivation_gate",
}
(OUT / "FORCE_R140B_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

# Manifest.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
write_csv(OUT / "artifact_manifest.csv", manifest_rows)

# Copy script if possible.
try:
    shutil.copy2(Path(__file__).resolve(), OUT / Path(__file__).name)
except Exception:
    pass

# Zip pack.
if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()
zip_integrity_pass = bad is None

print("\n=== COPY/PASTE R140B RESULT ===")
print("R140B COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"raw_feedback_dynamic_range: {RAW_DYNAMIC_RANGE:.12g}")
print(f"frozen_R127_dynamic_benchmark: {FROZEN_R127_DYNAMIC_BENCHMARK:.12g}")
print(f"missing_factor: {MISSING_FACTOR:.12g}")
print(f"required_beta_CONTROL_NOT_LAW: {REQUIRED_BETA_CONTROL_NOT_LAW:.12g}")
print(f"candidate_values_generated: {True}")
print(f"naive_full_hybrids_generated: {naive_full_hybrids_generated}")
print(f"naive_full_hybrids_overbridge: {naive_full_hybrids_overbridge}")
print(f"partial_hybrids_generated: {partial_hybrids_generated}")
print(f"partial_hybrid_within_25pct_present: {partial_hybrid_within_25pct_present}")
print(f"equivalence_audit_generated: {equivalence_audit_generated}")
print(f"double_counting_risk_detected: {double_counting_risk_detected}")
print(f"single_mechanism_primary_survivors_present: {single_mechanism_primary_survivors_present}")
print(f"global_multiplier_rejected: {global_multiplier_rejected}")
print("no_empirical_mass_data_loaded: True")
print("no_mass_matching_performed: True")
print("no_parameter_fit_performed: True")
print("no_mode_particle_mapping_performed: True")
print("no_final_physical_mass_law_selected: True")
print("true_GR_PDE_collective_field_closed: False")
print("physical_mass_spectrum_claimed: False")
print("CANDIDATE_SCORECARD:")
print(table_string(candidate_rows, ["candidate_id", "family", "beta", "gamma", "dynamic_range", "remaining_or_overshoot_factor", "relation", "within_25pct", "grade"]))
print("EQUIVALENCE_AUDIT:")
print(table_string(equiv_rows, ["source", "gamma", "equivalent_beta_over_seed_range", "distance_to_required_beta", "distance_to_beta_6pi", "interpretation"]))
print("BETA_SOURCE_AUDIT:")
print(table_string(beta_rows, ["beta_source", "beta", "distance_to_required_beta", "posthoc"]))
print("CLAIM_BOUNDARY:")
print(table_string(claim_boundary_rows, ["status", "claim", "reason"]))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R140B_summary.md').resolve()}")
print("NEXT: FORCE_R141_bridge_candidate_synthesis_freeze_gate_or_FORCE_R128_GR_lag_field_derivation_gate")
print("=== END COPY/PASTE R140B RESULT ===\n")
