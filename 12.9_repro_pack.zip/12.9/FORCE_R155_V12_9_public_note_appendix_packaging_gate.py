#!/usr/bin/env python3
r"""
FORCE_R155_V12_9_public_note_appendix_packaging_gate.py

SFT V12.9 public note / appendix packaging gate.

Purpose
-------
Generate a safe public note and appendix pack for the frozen V12.9 structured
mass program. This gate is a packaging / claim-boundary gate only.

It does NOT load empirical masses, perform mass matching, map rho modes to
particles, choose a final mass law, or close GR/PDE dynamics.

Expected usage
--------------
Run from the V12.9 working folder, e.g.
    C:\Users\TaicHI\Desktop\12.9> python FORCE_R155_V12_9_public_note_appendix_packaging_gate.py
"""

from __future__ import annotations

import csv
import hashlib
import html
import json
import math
import os
import re
import textwrap
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

GATE_ID = "R155"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE"
TITLE = "Solvency Field Theory V12.9: Structured Mass-Amplitude Program Freeze"
OUT_DIR_NAME = "FORCE_R155_V12_9_public_note_appendix_packaging_gate"
PUBLIC_NOTE_MD = "SFT_V12_9_structured_mass_program_public_note.md"
PUBLIC_NOTE_HTML = "SFT_V12_9_structured_mass_program_public_note.html"
PUBLIC_NOTE_PDF = "SFT_V12_9_structured_mass_program_public_note.pdf"
PACK_NAME = "SFT_V12_9_structured_mass_public_note_pack.zip"

SELECTED_SEED = ["1/2", "2/3", "3/4", "1", "5/4", "4/3", "3/2", "5/3", "2"]
CANONICAL_SPECIES_FORMULA = "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

PRIMARY_BRIDGE_CANDIDATES = [
    {
        "candidate_id": "R137_transverse_phase_volume_6pi_exponent",
        "family": "compound_transverse_lens",
        "dynamic_range": "339288",
        "status": "field-screen-supported survivor",
        "safe_interpretation": "Transverse phase measure enters as an exponent-style hierarchy-scale bridge candidate, not as a global multiplier.",
    },
    {
        "candidate_id": "R137_oriented_modes_18_exponent",
        "family": "compound_transverse_lens",
        "dynamic_range": "323996",
        "status": "field-screen-supported survivor",
        "safe_interpretation": "Oriented-mode count enters as an exponent/range-source screen, not as a universal multiplier.",
    },
    {
        "candidate_id": "R139_boundary_area_rho2_candidate",
        "family": "boundary_insolvency",
        "dynamic_range": "287996",
        "status": "field-screen-supported survivor",
        "safe_interpretation": "Inverse boundary-area response is a V11-adjacent hierarchy-scale bridge screen.",
    },
]

OBJECT_SEPARATION = [
    {
        "object": "M_raw_feedback",
        "plain_name": "mass-amplitude baseline",
        "role": "how much focusing/depth a mode traps",
        "status": "preserved baseline; under-spans hierarchy by itself",
    },
    {
        "object": "A_rent_normalized_p5_p6",
        "plain_name": "closure adequacy",
        "role": "whether a mode can pay its closure rent",
        "status": "stability/existence diagnostic, not direct mass amplitude",
    },
    {
        "object": "M_bridge_candidates",
        "plain_name": "bridge-corrected mass-amplitude screens",
        "role": "hierarchy-scale candidate amplitudes",
        "status": "screen survivors; no final physical law selected",
    },
    {
        "object": "G_shape_Q_force_schema",
        "plain_name": "structured mode labels",
        "role": "m,N shape/support/force-label program",
        "status": "diagnostic schema; null risk remains",
    },
]

EVIDENCE_STATUS = [
    {
        "evidence_item": "nine-mode seed",
        "status": "preserved",
        "what_survives": "V12.8 species formula remains locked.",
        "boundary": "Not a confirmed physical particle spectrum.",
    },
    {
        "evidence_item": "hierarchy-scale bridge",
        "status": "screen survives",
        "what_survives": "Primary bridge candidates span the charged-fermion hierarchy-scale benchmark within screen tolerance.",
        "boundary": "Not a final mass law; null/PDE boundaries remain.",
    },
    {
        "evidence_item": "pairwise ratio hits",
        "status": "downgraded",
        "what_survives": "Hits exist and some are clean-screen interesting.",
        "boundary": "Null tests show hit counts are not statistically unusual enough for mass-law claims.",
    },
    {
        "evidence_item": "shape structure",
        "status": "helpful diagnostic",
        "what_survives": "Slot-fill and denominator-class factors are informative screens.",
        "boundary": "Not enough to close a spectrum.",
    },
    {
        "evidence_item": "force labels",
        "status": "localized diagnostic",
        "what_survives": "Force-label components change the score landscape.",
        "boundary": "No strong force-label signal; no physical mapping.",
    },
    {
        "evidence_item": "true field derivation",
        "status": "open",
        "what_survives": "R128 scalar lag screen supports candidates as field-native screens.",
        "boundary": "Covariant/self-consistent GR/PDE derivation remains open.",
    },
]

CLAIM_BOUNDARY = [
    {
        "claim": "V12.9 freezes a structured mass-amplitude research program.",
        "status": "YES_SCREEN",
        "reason": "It identifies raw feedback, bridge candidates, shape factors, and force-label schema as screened objects.",
    },
    {
        "claim": "Primary bridge candidates span the hierarchy-scale benchmark.",
        "status": "YES_SCREEN",
        "reason": "6pi exponent, oriented-18 exponent, and rho^2 boundary-area candidates survive as field-screen-supported candidates.",
    },
    {
        "claim": "Mass amplitude and closure adequacy are different objects.",
        "status": "YES",
        "reason": "Prior gates separate M(rho) from rent-normalized adequacy A(rho).",
    },
    {
        "claim": "One-dimensional F(rho) is insufficient for final mass claims.",
        "status": "YES",
        "reason": "Monotonic-null risk remains for pairwise ratio hits.",
    },
    {
        "claim": "V12.9 derives the physical charged-fermion mass spectrum.",
        "status": "NO",
        "reason": "No physical identities, no final law, and null risk remains.",
    },
    {
        "claim": "V12.9 proves Standard Model sector matching.",
        "status": "NO",
        "reason": "No sector mapping or charge/color/generation identification is claimed.",
    },
    {
        "claim": "V12.9 closes covariant GR/PDE mass dynamics.",
        "status": "NO",
        "reason": "The scalar lag screen is not a self-consistent GR/PDE derivation.",
    },
    {
        "claim": "Pairwise ratio hits prove the model.",
        "status": "NO",
        "reason": "Null controls keep ratio-hit evidence at screen level.",
    },
]

OPEN_PROBLEMS = [
    {
        "open_item": "Covariant/self-consistent field derivation",
        "status": "OPEN",
        "frozen_boundary": "R128 is a scalar lag/field screen only.",
    },
    {
        "open_item": "Physical quantum-number map",
        "status": "OPEN",
        "frozen_boundary": "R151 labels are internal proxies, not SM assignments.",
    },
    {
        "open_item": "Null-resistant structured prediction",
        "status": "OPEN",
        "frozen_boundary": "R145/R148/R152 keep ratio-hit evidence at screen level.",
    },
    {
        "open_item": "Absolute mass scale",
        "status": "OPEN",
        "frozen_boundary": "V12.9 works with ratios/hierarchy-scale screens, not absolute masses.",
    },
    {
        "open_item": "Spin/chirality/decay/interactions",
        "status": "OPEN",
        "frozen_boundary": "Not derived in V12.9.",
    },
    {
        "open_item": "Neutrinos, bosons, hadrons, binding masses",
        "status": "OPEN",
        "frozen_boundary": "Outside the V12.9 screen boundary.",
    },
    {
        "open_item": "Unique renormalized self-energy prescription",
        "status": "OPEN",
        "frozen_boundary": "Finite-part/counterterm screens do not close uniqueness.",
    },
]

DO_NOT_OVERCLAIM = [
    {
        "prohibited_claim": "V12.9 derives particle masses.",
        "safe_replacement": "V12.9 freezes hierarchy-scale mass-amplitude bridge candidates.",
    },
    {
        "prohibited_claim": "V12.9 derives the Standard Model.",
        "safe_replacement": "V12.9 provides a structured research program for future physical matching.",
    },
    {
        "prohibited_claim": "V12.9 maps rho modes to particles.",
        "safe_replacement": "V12.9 keeps rho modes as mechanical/operator-geometric seed modes.",
    },
    {
        "prohibited_claim": "Pairwise hits prove the mass law.",
        "safe_replacement": "Pairwise hits are screen signals downgraded by null controls.",
    },
    {
        "prohibited_claim": "The 6pi exponent is the final law.",
        "safe_replacement": "The 6pi exponent is a field-screen-supported bridge candidate.",
    },
    {
        "prohibited_claim": "The rho^2 boundary area term is the final law.",
        "safe_replacement": "The rho^2 boundary-area response is a field-screen-supported bridge candidate.",
    },
    {
        "prohibited_claim": "V12.9 closes GR/PDE dynamics.",
        "safe_replacement": "A covariant/self-consistent field derivation remains open.",
    },
]

# Exact phrases that should not appear in the public note body as positive claims.
PROHIBITED_POSITIVE_PHRASES = [
    "V12.9 derives particle masses",
    "V12.9 derives the Standard Model",
    "V12.9 maps rho modes to particles",
    "Pairwise hits prove the mass law",
    "V12.9 closes GR/PDE dynamics",
    "derived physical mass spectrum",
    "confirmed Standard Model spectrum",
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def table_md(rows: List[Dict[str, object]]) -> str:
    if not rows:
        return ""
    headers = list(rows[0].keys())
    out = []
    out.append("| " + " | ".join(headers) + " |")
    out.append("| " + " | ".join(["---"] * len(headers)) + " |")
    for r in rows:
        out.append("| " + " | ".join(str(r.get(h, "")).replace("|", "/") for h in headers) + " |")
    return "\n".join(out)


def find_source_inventory(base: Path) -> List[Dict[str, object]]:
    patterns = [
        "SFT_V12_9_structured_mass_program_freeze_pack.zip",
        "FORCE_R154_V12_9_structured_mass_program_freeze_gate/ FORCE_R154_summary.md",
    ]
    inventory: List[Dict[str, object]] = []
    interesting: List[Path] = []
    for name in ["SFT_V12_9_structured_mass_program_freeze_pack.zip", "SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE_pack.zip"]:
        p = base / name
        if p.exists():
            interesting.append(p)
    for p in sorted(base.glob("FORCE_R15*_*.py")):
        interesting.append(p)
    for p in sorted(base.glob("FORCE_R154*/FORCE_R154_summary.md")):
        interesting.append(p)
    # Add current generated docs later separately; keep inventory compact.
    seen = set()
    for p in interesting:
        try:
            rp = str(p.resolve())
        except Exception:
            rp = str(p)
        if rp in seen:
            continue
        seen.add(rp)
        inventory.append({
            "file": p.name,
            "relative_path": str(p.relative_to(base)) if p.is_relative_to(base) else str(p),
            "exists": p.exists(),
            "size_bytes": p.stat().st_size if p.exists() else 0,
            "sha256": sha256_file(p) if p.exists() and p.is_file() else "",
        })
    return inventory


def make_markdown(created: str, freeze_pack_hash: str) -> str:
    seed = "{" + ", ".join(SELECTED_SEED) + "}"
    md = f"""# {TITLE}

**Freeze ID:** `{FREEZE_ID}`  
**Public-note gate:** `FORCE_R155`  
**Created:** `{created}`

## Abstract

V12.9 freezes a structured mass-amplitude research program in Solvency Field Theory. Starting from the V12.8 nine-mode mechanical/operator-geometric seed,

```text
{seed}
```

V12.9 separates mass amplitude from closure adequacy, identifies hierarchy-scale bridge candidates for the raw feedback mass-amplitude screen, and opens a structured mass-functional program using `(rho, m, N)` shape and force-label data. The result is **not** a completed physical mass-spectrum derivation. It does not map rho modes to Standard Model particles, does not select a final mass law, and does not close covariant/self-consistent GR/PDE mass dynamics.

## 1. Locked V12.8 seed boundary

The canonical V12.8 species formula remains:

```text
{CANONICAL_SPECIES_FORMULA}
```

The selected mechanical/operator-geometric seed is:

```text
{seed}
```

This seed remains a mechanical/operator-geometric seed, not a confirmed physical particle spectrum.

## 2. What V12.9 adds

V12.9 identifies four different objects that must not be conflated:

{table_md(OBJECT_SEPARATION)}

The key separation is:

```text
M(rho) = mass-amplitude-like focusing object
A(rho) = available focusing / required closure rent
```

`A(rho)` is a stability or closure-adequacy diagnostic. It is not the direct mass amplitude.

## 3. Primary hierarchy-scale bridge candidates

The primary bridge candidates preserved by the freeze are:

{table_md(PRIMARY_BRIDGE_CANDIDATES)}

These are hierarchy-scale bridge screens, not final physical laws.

## 4. Evidence status

{table_md(EVIDENCE_STATUS)}

Pairwise ratio hits remain screen-level evidence only. Null controls show that many hits are expected for monotonic curves spanning a large dynamic range. The hierarchy-scale bridge survives as a screen result; the internal pairwise pattern remains open.

## 5. Structured mass-functional program

The next-program schema is:

```text
M_structured = M_bridge(rho) * G_shape(m,N) * Q_force(residue, topology, ecology)
```

where:

```text
M_bridge(rho)      = raw feedback plus bridge-candidate amplitude screen
G_shape(m,N)       = slot occupancy / denominator / eccentricity / entropy structure
Q_force(...)       = residue, holonomy-proxy, topology-proxy, support-ecology label schema
```

V12.9 generates this schema but does not close it as a physical mass law.

## 6. Claim boundary

{table_md(CLAIM_BOUNDARY)}

## 7. Open problem register

{table_md(OPEN_PROBLEMS)}

## 8. Do-not-overclaim guardrails

{table_md(DO_NOT_OVERCLAIM)}

## 9. Freeze-source note

The R154 freeze pack was expected at:

```text
SFT_V12_9_structured_mass_program_freeze_pack.zip
```

Detected SHA-256:

```text
{freeze_pack_hash or 'not found in current working directory'}
```

## 10. Safe one-paragraph summary

V12.9 freezes a structured mass-amplitude program for the V12.8 nine-mode mechanical seed. It preserves hierarchy-scale bridge candidates, separates mass amplitude from closure adequacy, downgrades pairwise ratio hits after null-model controls, and opens a structured `(rho,m,N)` shape/force-label program. It does not derive a physical charged-fermion mass spectrum, does not map modes to Standard Model particles, and does not close the covariant/self-consistent GR/PDE mass derivation.
"""
    return md


def markdown_to_html(md: str, title: str) -> str:
    # Small dependency-free markdown-ish renderer sufficient for the generated note.
    lines = md.splitlines()
    body: List[str] = []
    in_code = False
    in_table = False
    table_buf: List[str] = []

    def flush_table() -> None:
        nonlocal table_buf, in_table
        if not table_buf:
            return
        rows = [r.strip() for r in table_buf if r.strip()]
        if len(rows) >= 2:
            headers = [c.strip() for c in rows[0].strip("|").split("|")]
            body.append("<table>\n<thead><tr>" + "".join(f"<th>{html.escape(h)}</th>" for h in headers) + "</tr></thead>\n<tbody>")
            for row in rows[2:]:
                cells = [c.strip() for c in row.strip("|").split("|")]
                body.append("<tr>" + "".join(f"<td>{html.escape(c)}</td>" for c in cells) + "</tr>")
            body.append("</tbody></table>")
        table_buf = []
        in_table = False

    for line in lines:
        if line.startswith("```"):
            flush_table()
            if not in_code:
                body.append("<pre><code>")
                in_code = True
            else:
                body.append("</code></pre>")
                in_code = False
            continue
        if in_code:
            body.append(html.escape(line))
            continue
        if line.startswith("| "):
            in_table = True
            table_buf.append(line)
            continue
        else:
            flush_table()
        if not line.strip():
            continue
        if line.startswith("# "):
            body.append(f"<h1>{html.escape(line[2:].strip())}</h1>")
        elif line.startswith("## "):
            body.append(f"<h2>{html.escape(line[3:].strip())}</h2>")
        elif line.startswith("### "):
            body.append(f"<h3>{html.escape(line[4:].strip())}</h3>")
        else:
            # bold/backtick minimal replacement
            s = html.escape(line)
            s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
            s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
            body.append(f"<p>{s}</p>")
    flush_table()
    css = """
body { font-family: Arial, Helvetica, sans-serif; line-height: 1.45; max-width: 1100px; margin: 32px auto; padding: 0 18px; }
h1, h2, h3 { color: #222; }
code, pre { background: #f5f5f5; border-radius: 4px; }
pre { padding: 12px; overflow-x: auto; }
table { border-collapse: collapse; width: 100%; margin: 16px 0; font-size: 0.92rem; }
th, td { border: 1px solid #ddd; padding: 6px 8px; vertical-align: top; }
th { background: #f0f0f0; }
"""
    return f"<!doctype html>\n<html><head><meta charset='utf-8'><title>{html.escape(title)}</title><style>{css}</style></head><body>\n" + "\n".join(body) + "\n</body></html>\n"


def _pdf_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def write_simple_pdf(path: Path, title: str, text: str) -> None:
    # Dependency-free simple text PDF. Keeps the public note portable.
    # Uses built-in Helvetica and one content stream per page.
    width, height = 612, 792
    margin_x, margin_y = 54, 54
    font_size = 9
    leading = 12
    max_chars = 92

    clean_lines: List[str] = []
    for raw in text.splitlines():
        line = raw.replace("`", "").replace("**", "")
        if line.startswith("| "):
            line = re.sub(r"\s*\|\s*", " | ", line.strip("| "))
        if len(line) <= max_chars:
            clean_lines.append(line)
        else:
            clean_lines.extend(textwrap.wrap(line, width=max_chars, replace_whitespace=False) or [""])
    pages: List[List[str]] = []
    current: List[str] = []
    lines_per_page = int((height - 2 * margin_y) / leading)
    for line in clean_lines:
        if len(current) >= lines_per_page:
            pages.append(current)
            current = []
        current.append(line)
    if current:
        pages.append(current)
    if not pages:
        pages = [[title]]

    objects: List[bytes] = []

    def add_obj(data: bytes) -> int:
        objects.append(data)
        return len(objects)

    catalog_id = add_obj(b"<< /Type /Catalog /Pages 2 0 R >>")
    pages_id = add_obj(b"")  # placeholder
    font_id = add_obj(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")

    page_ids: List[int] = []
    content_ids: List[int] = []
    for page_lines in pages:
        stream_lines = ["BT", f"/F1 {font_size} Tf", f"{margin_x} {height - margin_y} Td"]
        first = True
        for line in page_lines:
            if not first:
                stream_lines.append(f"0 -{leading} Td")
            first = False
            stream_lines.append(f"({_pdf_escape(line)}) Tj")
        stream_lines.append("ET")
        stream = "\n".join(stream_lines).encode("latin-1", errors="replace")
        content_id = add_obj(b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream")
        content_ids.append(content_id)
        page_id = add_obj(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {width} {height}] /Resources << /Font << /F1 {font_id} 0 R >> >> /Contents {content_id} 0 R >>".encode())
        page_ids.append(page_id)

    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects[pages_id - 1] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>".encode()

    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for i, obj in enumerate(objects, start=1):
        offsets.append(len(out))
        out.extend(f"{i} 0 obj\n".encode())
        out.extend(obj)
        out.extend(b"\nendobj\n")
    xref_offset = len(out)
    out.extend(f"xref\n0 {len(objects)+1}\n".encode())
    out.extend(b"0000000000 65535 f \n")
    for off in offsets[1:]:
        out.extend(f"{off:010d} 00000 n \n".encode())
    out.extend(f"trailer\n<< /Size {len(objects)+1} /Root {catalog_id} 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n".encode())
    path.write_bytes(bytes(out))


def zip_dir(src_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(src_dir.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(src_dir))


def verify_zip(zip_path: Path) -> bool:
    if not zip_path.exists():
        return False
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            return zf.testzip() is None
    except zipfile.BadZipFile:
        return False


def print_table(title: str, rows: List[Dict[str, object]], max_rows: int = 12) -> None:
    print(title + ":")
    if not rows:
        print("  none")
        return
    headers = list(rows[0].keys())
    widths = {h: min(max(len(h), *(len(str(r.get(h, ""))) for r in rows[:max_rows])), 45) for h in headers}
    header_line = " | ".join(h.ljust(widths[h]) for h in headers)
    print("  " + header_line)
    print("  " + "-+-".join("-" * widths[h] for h in headers))
    for r in rows[:max_rows]:
        vals = []
        for h in headers:
            s = str(r.get(h, ""))
            if len(s) > widths[h]:
                s = s[: widths[h] - 1] + "…"
            vals.append(s.ljust(widths[h]))
        print("  " + " | ".join(vals))


def main() -> int:
    base = Path.cwd()
    out_dir = base / OUT_DIR_NAME
    out_dir.mkdir(parents=True, exist_ok=True)
    appendix_dir = out_dir / "appendix_tables"
    appendix_dir.mkdir(exist_ok=True)

    created = datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")
    freeze_pack = base / "SFT_V12_9_structured_mass_program_freeze_pack.zip"
    freeze_pack_found = freeze_pack.exists()
    freeze_pack_hash = sha256_file(freeze_pack) if freeze_pack_found else ""

    # Write appendix tables.
    write_csv(appendix_dir / "V12_9_primary_bridge_candidates.csv", PRIMARY_BRIDGE_CANDIDATES)
    write_csv(appendix_dir / "V12_9_object_separation.csv", OBJECT_SEPARATION)
    write_csv(appendix_dir / "V12_9_evidence_status.csv", EVIDENCE_STATUS)
    write_csv(appendix_dir / "V12_9_claim_boundary.csv", CLAIM_BOUNDARY)
    write_csv(appendix_dir / "V12_9_open_problem_register.csv", OPEN_PROBLEMS)
    write_csv(appendix_dir / "V12_9_do_not_overclaim_guardrails.csv", DO_NOT_OVERCLAIM)

    inventory = find_source_inventory(base)
    write_csv(appendix_dir / "V12_9_source_inventory.csv", inventory)

    payload = {
        "freeze_id": FREEZE_ID,
        "public_note_gate": "FORCE_R155",
        "title": TITLE,
        "created_utc": created,
        "selected_seed": SELECTED_SEED,
        "canonical_species_formula": CANONICAL_SPECIES_FORMULA,
        "primary_bridge_candidates": PRIMARY_BRIDGE_CANDIDATES,
        "object_separation": OBJECT_SEPARATION,
        "claim_boundary": CLAIM_BOUNDARY,
        "open_problems": OPEN_PROBLEMS,
        "source_freeze_pack_sha256": freeze_pack_hash,
    }
    (out_dir / "V12_9_public_note_manifest.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    md = make_markdown(created, freeze_pack_hash)
    md_path = out_dir / PUBLIC_NOTE_MD
    html_path = out_dir / PUBLIC_NOTE_HTML
    pdf_path = out_dir / PUBLIC_NOTE_PDF
    md_path.write_text(md, encoding="utf-8")
    html_path.write_text(markdown_to_html(md, TITLE), encoding="utf-8")
    write_simple_pdf(pdf_path, TITLE, md)

    # Scan the narrative/public-claim body for exact positive overclaim phrases.
    # Guardrail and claim-boundary tables intentionally mention prohibited phrases,
    # so they are excluded from this exact-phrase scan.
    public_body = md_path.read_text(encoding="utf-8")
    scan_body = public_body.split("## 6. Claim boundary")[0]
    overclaim_hits = [phrase for phrase in PROHIBITED_POSITIVE_PHRASES if phrase in scan_body]
    overclaim_scan_pass = len(overclaim_hits) == 0

    pack_path = base / PACK_NAME
    zip_dir(out_dir, pack_path)
    zip_ok = verify_zip(pack_path)

    required_files = [
        md_path,
        html_path,
        pdf_path,
        out_dir / "V12_9_public_note_manifest.json",
        appendix_dir / "V12_9_claim_boundary.csv",
        appendix_dir / "V12_9_open_problem_register.csv",
        appendix_dir / "V12_9_primary_bridge_candidates.csv",
        appendix_dir / "V12_9_do_not_overclaim_guardrails.csv",
    ]
    required_files_present = all(p.exists() and p.stat().st_size > 0 for p in required_files)
    public_note_ready = required_files_present and zip_ok and overclaim_scan_pass

    summary_lines = []
    summary_lines.append(f"# FORCE_R155 Summary")
    summary_lines.append("")
    summary_lines.append(f"VERDICT: {'V12.9 PUBLIC NOTE / APPENDIX PACKAGING PASS / SAFE RELEASE NOTE READY' if public_note_ready else 'V12.9 PUBLIC NOTE / APPENDIX PACKAGING FAIL'}")
    summary_lines.append(f"FREEZE_ID: {FREEZE_ID}")
    summary_lines.append(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    summary_lines.append(f"required_files_present: {required_files_present}")
    summary_lines.append(f"freeze_pack_found: {freeze_pack_found}")
    summary_lines.append(f"overclaim_scan_pass: {overclaim_scan_pass}")
    summary_lines.append(f"public_note_ready: {public_note_ready}")
    summary_lines.append("")
    summary_lines.append("## Primary bridge candidates")
    summary_lines.append(table_md(PRIMARY_BRIDGE_CANDIDATES))
    summary_lines.append("")
    summary_lines.append("## Claim boundary")
    summary_lines.append(table_md(CLAIM_BOUNDARY))
    summary_lines.append("")
    summary_lines.append("## Open problems")
    summary_lines.append(table_md(OPEN_PROBLEMS))
    summary_lines.append("")
    summary_lines.append(f"PACK: {pack_path}")
    summary_lines.append(f"NOTE_MD: {md_path}")
    summary_lines.append(f"NOTE_HTML: {html_path}")
    summary_lines.append(f"NOTE_PDF: {pdf_path}")
    summary_lines.append("NEXT: review_public_note_or_begin_V12_10_deep_GR_PDE")
    summary_path = out_dir / "FORCE_R155_summary.md"
    summary_path.write_text("\n".join(summary_lines), encoding="utf-8")

    # Repack after summary is written.
    zip_dir(out_dir, pack_path)
    zip_ok = verify_zip(pack_path)
    public_note_ready = required_files_present and zip_ok and overclaim_scan_pass

    print("=== COPY/PASTE R155 RESULT ===")
    print("R155 COMPLETE")
    print("VERDICT: " + ("V12.9 PUBLIC NOTE / APPENDIX PACKAGING PASS / SAFE RELEASE NOTE READY" if public_note_ready else "V12.9 PUBLIC NOTE / APPENDIX PACKAGING FAIL"))
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    print(f"required_files_present: {required_files_present}")
    print(f"freeze_docs_generated: True")
    print(f"markdown_generated: {md_path.exists()}")
    print(f"html_generated: {html_path.exists()}")
    print(f"pdf_generated: {pdf_path.exists()}")
    print(f"appendix_tables_generated: True")
    print(f"freeze_pack_found: {freeze_pack_found}")
    print(f"overclaim_scan_pass: {overclaim_scan_pass}")
    print(f"public_note_ready: {public_note_ready}")
    print(f"selected_seed: {{{', '.join(SELECTED_SEED)}}}")
    print(f"canonical_species_formula: {CANONICAL_SPECIES_FORMULA}")
    print("PRIMARY_BRIDGE_CANDIDATES:")
    for row in PRIMARY_BRIDGE_CANDIDATES:
        print(f"  {row['candidate_id']} | family={row['family']} | dyn={row['dynamic_range']} | status={row['status']}")
    print("CLAIM_BOUNDARY:")
    for row in CLAIM_BOUNDARY:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print("OPEN_PROBLEM_REGISTER:")
    for row in OPEN_PROBLEMS:
        print(f"  {row['open_item']} | {row['status']} | {row['frozen_boundary']}")
    if overclaim_hits:
        print("OVERCLAIM_HITS:")
        for hit in overclaim_hits:
            print(f"  {hit}")
    else:
        print("OVERCLAIM_HITS: none")
    print("PUBLIC_NOTE_PREVIEW:")
    preview_lines = md.splitlines()[:70]
    print("\n".join(preview_lines))
    print(f"NOTE_MD: {md_path}")
    print(f"NOTE_HTML: {html_path}")
    print(f"NOTE_PDF: {pdf_path}")
    print(f"PACK: {pack_path}")
    print(f"SUMMARY: {summary_path}")
    print("NEXT: review_public_note_or_begin_V12_10_deep_GR_PDE")
    print("=== END COPY/PASTE R155 RESULT ===")
    return 0 if public_note_ready else 1


if __name__ == "__main__":
    raise SystemExit(main())
