# FORCE_R148_structured_mass_screen_null_model_upgrade_gate summary

VERDICT: STRUCTURED MASS SCREEN / NULL-MODEL UPGRADE PASS / STRUCTURE TESTED, NULL RISK REMAINS, FINAL LAW OPEN
FREEZE_ID: SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM
candidate_freeze_hash: 37af27788c50ef8eebf34b15f9c200e13ec98d0105391ba31c4082c7fe521f1b
mass_ratio_screen_table_hash: 798d4ffb666c7a1aff0ac7fd4dadac692bd225705392ba4778b2939f41b16d4d

## Top null summary rows
- R137_oriented18_exponent__G_denominator_class_root | hits=16 | same=8 | lep=1 | best=0.1363% | p_hits=0.09467 | p_same=0.1827 | shape_p_hits=0.10133333333333333 | result=NULL_RISK_REMAINS_HIGH
- R137_6pi_exponent__G_denominator_class_root | hits=16 | same=10 | lep=2 | best=0.2861% | p_hits=0.1047 | p_same=0.06333 | shape_p_hits=0.10733333333333334 | result=NULL_RISK_REMAINS_HIGH
- R139_boundary_area_rho2__G_eccentricity_linear | hits=15 | same=8 | lep=3 | best=0.053% | p_hits=0.14 | p_same=0.1847 | shape_p_hits=0.16266666666666665 | result=NULL_RISK_REMAINS_HIGH
- R139_boundary_area_rho2__G_entropy_deficit_linear | hits=15 | same=7 | lep=0 | best=0.2776% | p_hits=0.1487 | p_same=0.318 | shape_p_hits=0.24533333333333332 | result=NULL_RISK_REMAINS_HIGH
- R137_6pi_exponent__G_slot_fill_inverse | hits=14 | same=6 | lep=0 | best=0.004537% | p_hits=0.2453 | p_same=0.4633 | shape_p_hits=0.4033333333333333 | result=WEAK_STRUCTURE_SIGNAL_SCREEN
- R137_6pi_exponent__G0_no_shape_ablation | hits=14 | same=6 | lep=1 | best=0.121% | p_hits=0.2267 | p_same=0.458 | shape_p_hits=NA | result=NULL_RISK_REMAINS_HIGH
- R139_boundary_area_rho2__G0_no_shape_ablation | hits=13 | same=6 | lep=1 | best=0.346% | p_hits=0.3173 | p_same=0.4493 | shape_p_hits=NA | result=NULL_RISK_REMAINS_HIGH
- R137_6pi_exponent__G_eccentricity_linear | hits=12 | same=5 | lep=1 | best=0.004537% | p_hits=0.432 | p_same=0.634 | shape_p_hits=0.4073333333333333 | result=WEAK_STRUCTURE_SIGNAL_SCREEN

## Claim boundary
- YES_SCREEN: R148 freezes R147 structured shape candidates before loading mass ratios.
- YES_SCREEN: R148 tests structured candidates against monotonic dynamic-range nulls and shape-shuffle nulls.
- NO: R148 does not retune shape factors, exponents, bridge candidates, or mode mappings.
- NO: R148 does not claim a final physical mass law or Standard Model spectrum.
- NO: R148 does not close true GR/PDE mass dynamics.