# FORCE_R120: Locked Derived-F Mass-Ratio Screen Gate

**Freeze ID:** `SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM`
**Verdict:** `LOCKED DERIVED-F MASS-RATIO SCREEN PASS / SCREEN HITS REPORTED, FULL MASS LAW NOT CLOSED`

## Claim boundary

R120 is a locked mass-ratio screen. It compares frozen R119-derived candidate F(rho) ratios to a screening charged-fermion mass table. It does not retune functionals, select a final mass law, map rho modes to particles, or claim the Standard Model spectrum.

## Best screen hits

| functional | rho pair | F ratio | particle pair | mass ratio | error % | same sector |
|---|---:|---:|---|---:|---:|---:|
| local_complexity | 2/3 vs 5/3 | 1.39898 | tau vs charm_quark | 1.3991 | 0.008777 | False |
| bend_times_finite_part | 3/4 vs 5/4 | 1.13279 | muon vs strange_quark | 1.13125 | 0.1369 | False |
| curve_length | 2/3 vs 5/3 | 1.13319 | muon vs strange_quark | 1.13125 | 0.1717 | False |
| total_abs_turning | 1 vs 3/2 | 2.15719 | up_quark vs down_quark | 2.16204 | 0.2245 | True |
| lens_times_bend | 1 vs 5/4 | 9.16115 | electron vs down_quark | 9.13896 | 0.2427 | False |
| bend_energy_int_kappa2_ds | 5/3 vs 2 | 2.34368 | tau vs bottom_quark | 2.35246 | 0.375 | False |
| lens_times_finite_part | 1/2 vs 3/2 | 45.0323 | strange_quark vs bottom_quark | 44.7537 | 0.6225 | True |
| analytic_lens_proxy | 1 vs 5/4 | 2.18366 | up_quark vs down_quark | 2.16204 | 1 | True |
| finite_part_log_abs | 1/2 vs 2 | 1.11818 | muon vs strange_quark | 1.13125 | 1.168 | False |
| kernel_density_geomean | 3/4 vs 1 | 1.37293 | tau vs charm_quark | 1.3991 | 1.906 | False |

## Dynamic-range check

| functional | F dynamic range | shortfall factor | RMS log residual |
|---|---:|---:|---:|
| lens_times_finite_part | 149.853 | 2253.61 | 2.35953 |
| analytic_lens_proxy | 128 | 2638.37 | 2.40107 |
| lens_times_bend | 127.114 | 2656.77 | 2.45079 |
| local_complexity | 17.1407 | 19702.2 | 3.01299 |
| bend_energy_int_kappa2_ds | 4.19532 | 80497.2 | 3.44705 |
| curve_length | 4.11774 | 82013.7 | 3.41351 |
| total_abs_turning | 4.09889 | 82390.9 | 3.43181 |
| bend_times_finite_part | 3.15663 | 106985 | 3.53198 |
| kernel_density_geomean | 1.37293 | 245978 | 3.7619 |
| finite_part_log_abs | 1.27557 | 264754 | 3.78438 |

## Boundary

- Pairwise hits are exploratory screen signals only.
- Multiple-comparison risk is high.
- Quark masses are screening-only because they are scheme/scale dependent.
- Full PDE/GR self-energy, unique counterterm derivation, physical particle identification, SM matching, and Omega0 remain open.
