=== COPY/PASTE R149 RESULT ===
R149 COMPLETE
VERDICT: SHAPE-FACTOR ABLATION / DENOMINATOR-CLASS CONTROL PASS / STRUCTURE LOCALIZED, NULL RISK REMAINS, FINAL LAW OPEN
FREEZE_ID: SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM
ZIP_INTEGRITY: PASS
candidate_values_frozen_before_mass_loading: True
shape_factor_ablation_generated: True
denominator_class_controls_generated: True
shape_shuffle_nulls_generated: True
n_null_per_candidate: 250
candidate_freeze_hash: d5508ee85a8364b5b39c1c93af112e1240b82446e6de42ca050a19dde0ea2197
shape_ablation_informative: True
denominator_class_signal_present: True
strong_structure_signal_present: True
no_parameter_fit_performed: True
no_functional_retuning_after_mass_loading: True
no_mode_particle_mapping_performed: True
no_final_physical_mass_law_selected: True
physical_mass_spectrum_claimed: False
true_GR_PDE_mass_dynamics_closed: False
selected_seed: {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}
TOP_ABLATION_SCORECARD:
  raw_feedback_control__G_denominator_class_root | dyn=12727.8 | hits<=5%=21 | same<=9 | lep<=3 | best=0.172% | delta_hits=9 | p_hits_shuffle=0.052 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  raw_feedback_control__G_slot_fill_inverse | dyn=17999.8 | hits<=5%=20 | same<=7 | lep<=0 | best=0.06421% | delta_hits=8 | p_hits_shuffle=0.032 | result=STRONG_SHAPE_STRUCTURE_SCREEN
  R137_6pi_exponent__G_denominator_class_root | dyn=239913 | hits<=5%=17 | same<=11 | lep<=2 | best=0.2865% | delta_hits=4 | p_hits_shuffle=0.06 | result=STRONG_SHAPE_STRUCTURE_SCREEN
  raw_feedback_control__G_entropy_deficit_linear | dyn=17999.8 | hits<=5%=17 | same<=10 | lep<=0 | best=0.1436% | delta_hits=5 | p_hits_shuffle=0.192 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  raw_feedback_control__G_denominator_inverse_root | dyn=25455.5 | hits<=5%=17 | same<=7 | lep<=1 | best=0.2278% | delta_hits=5 | p_hits_shuffle=0.22 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  R139_boundary_area_rho2__G_entropy_deficit_linear | dyn=287996 | hits<=5%=16 | same<=8 | lep<=0 | best=0.05564% | delta_hits=3 | p_hits_shuffle=0.16 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  R137_oriented18_exponent__G_denominator_class_root | dyn=229100 | hits<=5%=16 | same<=8 | lep<=1 | best=0.1841% | delta_hits=3 | p_hits_shuffle=0.108 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  R139_boundary_area_rho2__G_eccentricity_linear | dyn=287996 | hits<=5%=15 | same<=9 | lep<=5 | best=0.01537% | delta_hits=2 | p_hits_shuffle=0.2 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  R137_6pi_exponent__G_shape_ecology_composite | dyn=359869 | hits<=5%=15 | same<=8 | lep<=0 | best=0.0199% | delta_hits=2 | p_hits_shuffle=0.104 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  R137_oriented18_exponent__G_shape_ecology_composite | dyn=343649 | hits<=5%=15 | same<=6 | lep<=0 | best=0.1841% | delta_hits=2 | p_hits_shuffle=0.12 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  raw_feedback_control__G_shape_ecology_composite | dyn=19091.6 | hits<=5%=14 | same<=9 | lep<=5 | best=0.1567% | delta_hits=2 | p_hits_shuffle=0.364 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  R137_6pi_exponent__G_slot_fill_inverse | dyn=339288 | hits<=5%=14 | same<=6 | lep<=0 | best=0.004537% | delta_hits=1 | p_hits_shuffle=0.38 | result=NULL_RISK_REMAINS_HIGH
DENOMINATOR_CLASS_CONTROL:
  best_class_factor=raw_feedback_control__G_denominator_class_root | hits<=5%=21 | same<=9 | p_hits_shuffle=0.052 | result=WEAK_SHAPE_STRUCTURE_SCREEN
  best_nonclass_factor=raw_feedback_control__G_slot_fill_inverse | hits<=5%=20 | same<=7 | p_hits_shuffle=0.032 | result=STRONG_SHAPE_STRUCTURE_SCREEN
INTERPRETATION_TABLE:
  shape_ablation | SCREEN_PASS | Shape factors change hit structure, but most gains remain weak under shuffle nulls.
  denominator_class | SCREEN_SIGNAL | N-class/root factors are informative controls, but not a final law.
  strong_signal | OPEN | No strong structure claim unless shuffle-null p-values cross the strict threshold.
  final_law | OPEN | Shape factors require field/force derivation and upgraded null controls.
CLAIM_BOUNDARY:
  YES_SCREEN | R149 ablates R147 shape factors and denominator-class controls. -- Shape factors are frozen before scoring; no rho-to-particle identities are assigned.
  YES_SCREEN | R149 uses shape-shuffle nulls to test whether shape factors add structure beyond bridge amplitude. -- Shuffle controls preserve base mass-amplitude values while randomizing structure labels.
  NO | R149 selects a final physical shape factor or mass law. -- Results are diagnostic only; null risk and field-derivation gaps remain.
  NO | R149 maps denominator classes to leptons/quarks/SM sectors. -- N=1..4 are geometric slot classes only.
  NO | R149 closes true GR/PDE mass dynamics. -- This remains a structure-screen gate.
NEXT_GATE_PLAN:
  FORCE_R150 | Structured Mass Program Rollup Gate | Freeze R147-R149: structured features help, but null risk remains; queue force-architecture merge. | Do not claim physical spectrum.
  FORCE_R151 | Force-Architecture / Quantum-Number Merge Gate | Bring V12.4-style holonomy/topology labels into mass functional without mass fitting. | Do not map particles by hit count.
  DEEP_GR_PDE | Covariant GR/Lag Field Derivation Deep Gate | Derive bridge and shape factors from field equations. | Do not treat screens as PDE closure.
PACK: C:\Users\TaicHI\Desktop\12.9\FORCE_R149_shape_factor_ablation_denominator_class_control_gate_pack.zip
SUMMARY: C:\Users\TaicHI\Desktop\12.9\FORCE_R149_shape_factor_ablation_denominator_class_control_gate\FORCE_R149_summary.md
NEXT: FORCE_R150_structured_mass_program_rollup_gate_or_FORCE_R151_force_architecture_quantum_number_merge_gate
=== END COPY/PASTE R149 RESULT ===
