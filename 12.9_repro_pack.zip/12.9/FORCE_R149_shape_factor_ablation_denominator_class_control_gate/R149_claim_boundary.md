  YES_SCREEN | R149 ablates R147 shape factors and denominator-class controls. -- Shape factors are frozen before scoring; no rho-to-particle identities are assigned.
  YES_SCREEN | R149 uses shape-shuffle nulls to test whether shape factors add structure beyond bridge amplitude. -- Shuffle controls preserve base mass-amplitude values while randomizing structure labels.
  NO | R149 selects a final physical shape factor or mass law. -- Results are diagnostic only; null risk and field-derivation gaps remain.
  NO | R149 maps denominator classes to leptons/quarks/SM sectors. -- N=1..4 are geometric slot classes only.
  NO | R149 closes true GR/PDE mass dynamics. -- This remains a structure-screen gate.