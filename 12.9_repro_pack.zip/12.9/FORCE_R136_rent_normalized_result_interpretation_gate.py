from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import hashlib
import math
import pandas as pd

OUT = Path('FORCE_R136_rent_normalized_result_interpretation_gate')
ZIP = Path('FORCE_R136_rent_normalized_result_interpretation_gate_pack.zip')

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

FREEZE_ID = 'SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM'
SEED = [Fraction(1,2), Fraction(2,3), Fraction(3,4), Fraction(1,1), Fraction(5,4), Fraction(4,3), Fraction(3,2), Fraction(5,3), Fraction(2,1)]
SELECTED_SEED = '{' + ', '.join(str(x) for x in SEED) + '}'
CANONICAL_SPECIES_FORMULA = 'Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}'

# Frozen prior-gate diagnostics. These are not reloaded from a mass table here.
# They are prior screen outputs used for interpretation only.
RAW_FEEDBACK_DYN = 17999.7689742            # R126/R127 lead feedback dynamic range
R125_GRAVITY_MAP_DYN = 269.251              # R125 density-depth-like dynamic range
SCHEME_CLEAN_DYN = 187.984                  # R122 lens_times_finite_abs dynamic range
TARGET_DYN_BENCHMARK_FROM_R127 = 338083.0   # prior R127 benchmark, not recomputed here
MISSING_FACTOR_FROM_R127 = TARGET_DYN_BENCHMARK_FROM_R127 / RAW_FEEDBACK_DYN
REQUIRED_EXPONENT_EPS = math.log(TARGET_DYN_BENCHMARK_FROM_R127) / math.log(RAW_FEEDBACK_DYN) - 1.0

RENT_DYNS = {
    'p4_write_density_control_too_shallow': 70.3122,
    'p5_quadratic_density_self_energy_rent_normalized': 24.276271,
    'p6_curvature_weighted_self_energy_rent_normalized': 12.138136,
    'p7_acceleration_weighted_high_order_control': 6.069068,
}

# -----------------------------------------------------------------------------
# 1. Separate the two objects.
# -----------------------------------------------------------------------------
object_rows = [
    {
        'object_id': 'M_raw_feedback_amplitude',
        'plain_name': 'mass-amplitude candidate',
        'mechanical_question': 'How much energy/focusing/depth does the mode trap?',
        'primary_inputs': 'radius-depth feedback, raw scalar lag/focusing map',
        'representative_dynamic_range': RAW_FEEDBACK_DYN,
        'best_prior_role': 'R126/R127 lead mass-screen object',
        'should_be_used_as_mass_proxy': True,
        'should_be_used_as_existence_threshold': False,
        'interpretation': 'Mass-like amplitude; still not a final mass law or GR/PDE result.',
    },
    {
        'object_id': 'A_rent_normalized_adequacy_p5',
        'plain_name': 'closure-adequacy ratio p=5',
        'mechanical_question': 'Can the mode pay its required closure rent?',
        'primary_inputs': 'available focusing divided by p=5 self-energy rent demand',
        'representative_dynamic_range': RENT_DYNS['p5_quadratic_density_self_energy_rent_normalized'],
        'best_prior_role': 'R132/R133/R134 stability/ecology object',
        'should_be_used_as_mass_proxy': False,
        'should_be_used_as_existence_threshold': True,
        'interpretation': 'Adequacy-like viability ratio; it divides out too much information to be the mass amplitude.',
    },
    {
        'object_id': 'A_rent_normalized_adequacy_p6',
        'plain_name': 'closure-adequacy ratio p=6',
        'mechanical_question': 'Can the mode pay curvature-weighted closure rent?',
        'primary_inputs': 'available focusing divided by p=6 curvature-weighted rent demand',
        'representative_dynamic_range': RENT_DYNS['p6_curvature_weighted_self_energy_rent_normalized'],
        'best_prior_role': 'R132/R133/R134 composite stability/ecology object',
        'should_be_used_as_mass_proxy': False,
        'should_be_used_as_existence_threshold': True,
        'interpretation': 'Composite adequacy diagnostic; not direct mass magnitude.',
    },
]
object_separation = pd.DataFrame(object_rows)

# -----------------------------------------------------------------------------
# 2. Interpretation of R135.
# -----------------------------------------------------------------------------
r135_interpretation = pd.DataFrame([
    {
        'finding': 'rent_normalized_pairwise_hits_exist',
        'status': 'YES_SCREEN',
        'interpretation': 'p=5/p=6 adequacy ratios still touch some mass ratios, but with high multiple-comparison risk.',
    },
    {
        'finding': 'rent_normalized_dynamic_range_small',
        'status': 'YES',
        'interpretation': 'p=5 dynamic range is about 24.3 and p=6 about 12.1, far below raw feedback and far below the charged-fermion benchmark.',
    },
    {
        'finding': 'adequacy_not_mass_functional',
        'status': 'PASS_INTERPRETATION',
        'interpretation': 'Adequacy asks whether a mode can exist; mass amplitude asks how much energy it traps. These should remain separate.',
    },
    {
        'finding': 'raw_feedback_remains_lead_mass_candidate',
        'status': 'PASS_INTERPRETATION',
        'interpretation': 'The mass-like object remains the raw radius/depth feedback functional pending GR/lag-field derivation.',
    },
])

# -----------------------------------------------------------------------------
# 3. Missing-factor candidate inventory from the side-convo/tool discussion.
# -----------------------------------------------------------------------------
# Important rule: a constant/global factor cannot change pairwise ratios or dynamic range.
# A candidate can matter only if it is differential or exponent-like.
CANDIDATES = [
    {
        'candidate_id': 'global_18_oriented_modes',
        'mechanical_source': '9 modes times particle/antiparticle orientation',
        'raw_factor_or_exponent': 18.0,
        'kind': 'global_multiplier',
        'can_change_ratios': False,
        'rough_numeric_relation_to_gap': 18.0 / MISSING_FACTOR_FROM_R127,
        'screen_status': 'FAIL_AS_GLOBAL_ONLY',
        'next_test': 'Only useful if converted into mode-dependent susceptibility, not as a global multiplier.',
    },
    {
        'candidate_id': 'transverse_phase_volume_6pi',
        'mechanical_source': 'three transverse/normal angular channels each contributing 2*pi phase volume',
        'raw_factor_or_exponent': 6.0 * math.pi,
        'kind': 'global_phase_volume_or_exponent_source',
        'can_change_ratios': False,
        'rough_numeric_relation_to_gap': (6.0 * math.pi) / MISSING_FACTOR_FROM_R127,
        'screen_status': 'INTERESTING_NUMERIC_NEAR_GAP_BUT_GLOBAL_FAILS',
        'next_test': 'Test as exponent/compound-lens correction, not as multiplicative factor.',
    },
    {
        'candidate_id': 'feedback_exponent_epsilon_required',
        'mechanical_source': 'missing hierarchy as exponent steepening of raw feedback rather than global multiplication',
        'raw_factor_or_exponent': REQUIRED_EXPONENT_EPS,
        'kind': 'exponent_correction_control',
        'can_change_ratios': True,
        'rough_numeric_relation_to_gap': REQUIRED_EXPONENT_EPS / (1.0/3.0),
        'screen_status': 'POSTHOC_CONTROL_NOT_LAW_BUT_CLOSE_TO_ONE_THIRD',
        'next_test': 'Derive or reject via 3-normal compound-lens/phase-volume gate.',
    },
    {
        'candidate_id': 'normal_dimension_beta_1_over_3',
        'mechanical_source': 'one-third correction from three normal dimensions',
        'raw_factor_or_exponent': 1.0/3.0,
        'kind': 'fixed_exponent_candidate',
        'can_change_ratios': True,
        'rough_numeric_relation_to_gap': (1.0/3.0) / REQUIRED_EXPONENT_EPS,
        'screen_status': 'NATURAL_CANDIDATE_BRACKETS_REQUIRED_EXPONENT',
        'next_test': 'R137 compound transverse-lens exponent screen with no masses loaded.',
    },
    {
        'candidate_id': 'slot_root_beta_1_over_4',
        'mechanical_source': 'one-quarter correction from 1 tangent + 3 normal slot capacity',
        'raw_factor_or_exponent': 1.0/4.0,
        'kind': 'fixed_exponent_candidate',
        'can_change_ratios': True,
        'rough_numeric_relation_to_gap': (1.0/4.0) / REQUIRED_EXPONENT_EPS,
        'screen_status': 'NATURAL_CANDIDATE_BRACKETS_REQUIRED_EXPONENT_FROM_BELOW',
        'next_test': 'R137/R129B compare against 1/3 without fitting.',
    },
    {
        'candidate_id': 'boundary_bulk_4pi2_bridge',
        'mechanical_source': 'possible missing phase/boundary normalization bridge',
        'raw_factor_or_exponent': 4.0 * math.pi * math.pi,
        'kind': 'normalization_or_exponent_source',
        'can_change_ratios': False,
        'rough_numeric_relation_to_gap': (4.0 * math.pi * math.pi) / MISSING_FACTOR_FROM_R127,
        'screen_status': 'GLOBAL_FORM_FAILS_UNLESS_EXPONENT_OR_DIFFERENTIAL',
        'next_test': 'Audit only after identifying which part enters differential feedback.',
    },
    {
        'candidate_id': 'inter_mode_graph_coupling',
        'mechanical_source': 'self plus pairwise interactions among nine modes',
        'raw_factor_or_exponent': 45.0/9.0,
        'kind': 'graph_coupling_candidate',
        'can_change_ratios': True,
        'rough_numeric_relation_to_gap': (45.0/9.0) / MISSING_FACTOR_FROM_R127,
        'screen_status': 'TOO_SMALL_AS_SIMPLE_FACTOR_BUT_GRAPH_WEIGHT_CAN_BE_DIFFERENTIAL',
        'next_test': 'R138 support/inter-mode coupling graph gate.',
    },
    {
        'candidate_id': 'color_or_confinement_sector_factor',
        'mechanical_source': 'sector-dependent color/confinement amplification',
        'raw_factor_or_exponent': 3.0,
        'kind': 'sector_dependent_candidate',
        'can_change_ratios': True,
        'rough_numeric_relation_to_gap': 3.0 / MISSING_FACTOR_FROM_R127,
        'screen_status': 'CANNOT_TEST_WITHOUT_SECTOR_SPLIT_OR_COLOR_DERIVATION',
        'next_test': 'Later only; do not use to fit the mass hierarchy before deriving sectors.',
    },
    {
        'candidate_id': 'V11_boundary_insolvency_extra_N',
        'mechanical_source': 'bulk N^3 demand vs boundary N^2 supply leaves one missing factor of N',
        'raw_factor_or_exponent': None,
        'kind': 'mode_dependent_insolvency_candidate',
        'can_change_ratios': True,
        'rough_numeric_relation_to_gap': None,
        'screen_status': 'PROMISING_IF_EFFECTIVE_N_IS_DERIVED_FROM_MODE_COMPLEXITY',
        'next_test': 'R139 boundary-insolvency complexity correction gate.',
    },
]
missing_factor_inventory = pd.DataFrame(CANDIDATES)

# -----------------------------------------------------------------------------
# 4. Gate plan: test all candidates, but in separate controls.
# -----------------------------------------------------------------------------
gate_plan = pd.DataFrame([
    {
        'gate': 'R137',
        'title': 'Compound Transverse-Lens / Exponent Correction Gate',
        'goal': 'Test whether three-normal/slot-root exponent corrections steepen raw feedback without fitting.',
        'tests_candidates': 'normal_dimension_beta_1_over_3, slot_root_beta_1_over_4, transverse_phase_volume_6pi-as-exponent-source',
        'must_not_do': 'Do not choose exponent from mass hits; do not use 6pi as a global multiplier.',
    },
    {
        'gate': 'R138',
        'title': 'Inter-Mode / Support-Graph Coupling Gate',
        'goal': 'Compute differential amplification from support graph degree, R/C partners, virtual support burden, and boundary assistance.',
        'tests_candidates': 'inter_mode_graph_coupling, differential collective susceptibility',
        'must_not_do': 'Do not map rho modes to particles or tune graph weights to mass ratios.',
    },
    {
        'gate': 'R139',
        'title': 'Boundary-Insolvency Complexity Correction Gate',
        'goal': 'Test whether V11-style N^3 vs N^2 deficit supplies a mode-dependent missing factor from derived mode complexity.',
        'tests_candidates': 'V11_boundary_insolvency_extra_N',
        'must_not_do': 'Do not insert the 18.8 factor as an effective N by hand.',
    },
    {
        'gate': 'R128',
        'title': 'GR/Lag Field Derivation Gate',
        'goal': 'Attempt to derive the raw feedback/radius-depth map from field equations rather than scalar proxy kernels.',
        'tests_candidates': 'underlying lag-field source of raw feedback and missing exponent',
        'must_not_do': 'Do not treat scalar kernels or power counting as full GR/PDE closure.',
    },
])

# -----------------------------------------------------------------------------
# 5. Verdict booleans.
# -----------------------------------------------------------------------------
mass_amplitude_adequacy_separated = True
adequacy_not_mass_functional = True
raw_feedback_lead_mass_candidate = True
rent_normalized_stability_diagnostic = True
missing_factor_candidate_inventory_generated = True
side_convo_candidates_triaged = True
global_multiplier_rejected = True
exponent_candidates_queued = True
no_new_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_parameter_fit_performed = True
no_mode_particle_mapping_performed = True
no_final_physical_mass_law_selected = True
true_GR_PDE_collective_field_closed = False
unique_missing_factor_closed = False
physical_mass_spectrum_claimed = False

verdict_status = 'RENT-NORMALIZED RESULT INTERPRETATION PASS / MASS-AMPLITUDE AND ADEQUACY SEPARATED, MISSING-FACTOR CANDIDATES QUEUED'

claim_boundary = pd.DataFrame([
    {
        'claim': 'R136 separates mass amplitude from closure adequacy.',
        'status': 'YES',
        'reason': 'Raw feedback is mass-amplitude-like, while rent-normalized p=5/p=6 ratios are closure-adequacy-like.',
    },
    {
        'claim': 'R136 selects p=5 or p=6 as a final mass law.',
        'status': 'NO',
        'reason': 'p=5/p=6 remain closure-rent candidates, not direct mass functionals.',
    },
    {
        'claim': 'R136 uses new empirical mass data.',
        'status': 'NO',
        'reason': 'Only frozen prior-gate benchmark numbers are interpreted; no mass table is loaded or compared.',
    },
    {
        'claim': 'R136 closes the missing 18.8x hierarchy factor.',
        'status': 'NO',
        'reason': 'Candidate sources are triaged and queued; no unique missing-factor law is proven.',
    },
    {
        'claim': 'R136 rejects global multipliers as hierarchy bridges.',
        'status': 'YES',
        'reason': 'A global factor cancels in ratios and cannot change dynamic range.',
    },
    {
        'claim': 'R136 recommends testing all candidate sources as separate controls.',
        'status': 'YES',
        'reason': '6pi/normal dimension, 4pi^2, graph coupling, boundary insolvency, and sector factors are separated into future gates.',
    },
    {
        'claim': 'R136 maps rho modes to particles.',
        'status': 'NO',
        'reason': 'No rho-to-particle assignment is performed.',
    },
    {
        'claim': 'R136 closes true GR/PDE collective field dynamics.',
        'status': 'NO',
        'reason': 'The field-equation derivation remains R128/future work.',
    },
])

gate_audit = pd.DataFrame([
    {'test': 'mass_amplitude_adequacy_separated', 'result': 'PASS' if mass_amplitude_adequacy_separated else 'WARN', 'interpretation': 'Mass amplitude and closure adequacy are treated as different objects.'},
    {'test': 'adequacy_not_mass_functional', 'result': 'PASS' if adequacy_not_mass_functional else 'WARN', 'interpretation': 'Rent-normalized adequacy is not used as direct mass magnitude.'},
    {'test': 'raw_feedback_lead_mass_candidate', 'result': 'PASS' if raw_feedback_lead_mass_candidate else 'WARN', 'interpretation': 'Raw radius/depth feedback remains the lead mass-amplitude candidate.'},
    {'test': 'missing_factor_candidate_inventory_generated', 'result': 'PASS' if missing_factor_candidate_inventory_generated else 'WARN', 'interpretation': 'Candidate sources for the remaining hierarchy factor are cataloged.'},
    {'test': 'global_multiplier_rejected', 'result': 'PASS' if global_multiplier_rejected else 'WARN', 'interpretation': 'A global multiplier is rejected because it cannot change ratios/dynamic range.'},
    {'test': 'exponent_candidates_queued', 'result': 'PASS' if exponent_candidates_queued else 'WARN', 'interpretation': 'Exponent/differential candidates are queued for future controls.'},
    {'test': 'no_new_empirical_mass_data_loaded', 'result': 'PASS' if no_new_empirical_mass_data_loaded else 'WARN', 'interpretation': 'No new empirical mass table is loaded in this interpretation gate.'},
    {'test': 'no_mode_particle_mapping_performed', 'result': 'PASS' if no_mode_particle_mapping_performed else 'WARN', 'interpretation': 'No rho-to-particle identities are assigned.'},
    {'test': 'unique_missing_factor_closed', 'result': 'OPEN', 'interpretation': 'The missing-factor source remains open.'},
    {'test': 'true_GR_PDE_collective_field_closed', 'result': 'OPEN', 'interpretation': 'GR/lag-field derivation remains open.'},
])

# Save artifacts.
object_separation.to_csv(OUT / 'R136_object_separation.csv', index=False)
r135_interpretation.to_csv(OUT / 'R136_R135_interpretation.csv', index=False)
missing_factor_inventory.to_csv(OUT / 'R136_missing_factor_candidate_inventory.csv', index=False)
gate_plan.to_csv(OUT / 'R136_next_gate_plan.csv', index=False)
claim_boundary.to_csv(OUT / 'R136_claim_boundary.csv', index=False)
gate_audit.to_csv(OUT / 'R136_gate_audit.csv', index=False)

summary = f'''# FORCE_R136 - Rent-Normalized Result Interpretation Gate

## Verdict

{verdict_status}

## Core interpretation

R135 shows that rent-normalized p=5/p=6 candidates produce screening hits, but their dynamic range is too small to be the direct mass functional.

Therefore V12.9 currently has two distinct objects:

1. Mass amplitude candidate: raw radius/depth feedback, dynamic range about {RAW_FEEDBACK_DYN:.3g}.
2. Closure adequacy candidate: rent-normalized p=5/p=6 ratios, dynamic ranges about {RENT_DYNS['p5_quadratic_density_self_energy_rent_normalized']:.3g} and {RENT_DYNS['p6_curvature_weighted_self_energy_rent_normalized']:.3g}.

## Missing factor status

Prior R127 benchmark shortfall:

missing differential factor = {MISSING_FACTOR_FROM_R127:.6g}

Required exponent correction if applied as raw-feedback steepening:

epsilon = {REQUIRED_EXPONENT_EPS:.6g}

This is close to 1/3 but is not a law. It is a target for a future derivation/control gate.

## Claim boundary

{claim_boundary.to_string(index=False)}

## Candidate inventory

{missing_factor_inventory.to_string(index=False)}

## Next gate plan

{gate_plan.to_string(index=False)}
'''
(OUT / 'FORCE_R136_summary.md').write_text(summary, encoding='utf-8')

verdict = {
    'force_id': 'FORCE_R136',
    'title': 'Rent-Normalized Result Interpretation Gate',
    'status': verdict_status,
    'freeze_id': FREEZE_ID,
    'mass_amplitude_adequacy_separated': mass_amplitude_adequacy_separated,
    'adequacy_not_mass_functional': adequacy_not_mass_functional,
    'raw_feedback_lead_mass_candidate': raw_feedback_lead_mass_candidate,
    'rent_normalized_stability_diagnostic': rent_normalized_stability_diagnostic,
    'missing_factor_candidate_inventory_generated': missing_factor_candidate_inventory_generated,
    'side_convo_candidates_triaged': side_convo_candidates_triaged,
    'global_multiplier_rejected': global_multiplier_rejected,
    'exponent_candidates_queued': exponent_candidates_queued,
    'no_new_empirical_mass_data_loaded': no_new_empirical_mass_data_loaded,
    'no_mass_matching_performed': no_mass_matching_performed,
    'no_parameter_fit_performed': no_parameter_fit_performed,
    'no_mode_particle_mapping_performed': no_mode_particle_mapping_performed,
    'no_final_physical_mass_law_selected': no_final_physical_mass_law_selected,
    'true_GR_PDE_collective_field_closed': true_GR_PDE_collective_field_closed,
    'unique_missing_factor_closed': unique_missing_factor_closed,
    'physical_mass_spectrum_claimed': physical_mass_spectrum_claimed,
    'raw_feedback_dynamic_range': RAW_FEEDBACK_DYN,
    'p5_adequacy_dynamic_range': RENT_DYNS['p5_quadratic_density_self_energy_rent_normalized'],
    'p6_adequacy_dynamic_range': RENT_DYNS['p6_curvature_weighted_self_energy_rent_normalized'],
    'missing_factor_from_R127_benchmark': MISSING_FACTOR_FROM_R127,
    'required_exponent_epsilon_control_not_law': REQUIRED_EXPONENT_EPS,
    'selected_seed': [str(x) for x in SEED],
    'canonical_species_formula': CANONICAL_SPECIES_FORMULA,
    'recommended_next': 'FORCE_R137_compound_transverse_lens_exponent_correction_gate_or_FORCE_R128_GR_lag_field_derivation_gate',
}
(OUT / 'FORCE_R136_verdict.json').write_text(json.dumps(verdict, indent=2), encoding='utf-8')

# Manifest and zip.
def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

manifest_rows = []
for p in sorted(OUT.rglob('*')):
    if p.is_file():
        manifest_rows.append({'relative_path': str(p.relative_to(OUT)), 'bytes': p.stat().st_size, 'sha256': sha256_file(p)})
pd.DataFrame(manifest_rows).to_csv(OUT / 'artifact_manifest.csv', index=False)

try:
    shutil.copy2(Path(__file__).resolve(), OUT / 'FORCE_R136_rent_normalized_result_interpretation_gate.py')
except Exception:
    pass

if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, 'r') as z:
    bad = z.testzip()
zip_integrity_pass = bad is None

print('\n=== COPY/PASTE R136 RESULT ===')
print('R136 COMPLETE')
print(f'VERDICT: {verdict_status}')
print(f'FREEZE_ID: {FREEZE_ID}')
print(f'ZIP_INTEGRITY: {"PASS" if zip_integrity_pass else bad}')
print(f'mass_amplitude_adequacy_separated: {mass_amplitude_adequacy_separated}')
print(f'adequacy_not_mass_functional: {adequacy_not_mass_functional}')
print(f'raw_feedback_lead_mass_candidate: {raw_feedback_lead_mass_candidate}')
print(f'rent_normalized_stability_diagnostic: {rent_normalized_stability_diagnostic}')
print(f'missing_factor_candidate_inventory_generated: {missing_factor_candidate_inventory_generated}')
print(f'side_convo_candidates_triaged: {side_convo_candidates_triaged}')
print(f'global_multiplier_rejected: {global_multiplier_rejected}')
print(f'exponent_candidates_queued: {exponent_candidates_queued}')
print(f'no_new_empirical_mass_data_loaded: {no_new_empirical_mass_data_loaded}')
print(f'no_mass_matching_performed: {no_mass_matching_performed}')
print(f'no_parameter_fit_performed: {no_parameter_fit_performed}')
print(f'no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}')
print(f'no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}')
print(f'true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}')
print(f'unique_missing_factor_closed: {unique_missing_factor_closed}')
print(f'physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}')
print(f'selected_seed: {SELECTED_SEED}')
print(f'raw_feedback_dynamic_range: {RAW_FEEDBACK_DYN:.10g}')
print(f'p5_adequacy_dynamic_range: {RENT_DYNS["p5_quadratic_density_self_energy_rent_normalized"]:.10g}')
print(f'p6_adequacy_dynamic_range: {RENT_DYNS["p6_curvature_weighted_self_energy_rent_normalized"]:.10g}')
print(f'missing_factor_from_R127_benchmark: {MISSING_FACTOR_FROM_R127:.10g}')
print(f'required_exponent_epsilon_CONTROL_NOT_LAW: {REQUIRED_EXPONENT_EPS:.10g}')
print('OBJECT_SEPARATION:')
print(object_separation.to_string(index=False))
print('MISSING_FACTOR_CANDIDATE_INVENTORY:')
print(missing_factor_inventory.to_string(index=False))
print('NEXT_GATE_PLAN:')
print(gate_plan.to_string(index=False))
print('CLAIM_BOUNDARY:')
for row in claim_boundary.itertuples(index=False):
    print(f'  {row.status} | {row.claim} -- {row.reason}')
print(f'PACK: {ZIP.resolve()}')
print(f'SUMMARY: {(OUT / "FORCE_R136_summary.md").resolve()}')
print('NEXT: FORCE_R137_compound_transverse_lens_exponent_correction_gate_or_FORCE_R128_GR_lag_field_derivation_gate')
print('=== END COPY/PASTE R136 RESULT ===\n')
