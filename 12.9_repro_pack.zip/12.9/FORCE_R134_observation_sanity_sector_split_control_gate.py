from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import hashlib
import pandas as pd

OUT = Path("FORCE_R134_observation_sanity_sector_split_control_gate")
ZIP = Path("FORCE_R134_observation_sanity_sector_split_control_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
TITLE = "FORCE_R134 — Observation Sanity / Sector-Split Control Gate"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
LOW_MODES = {Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1)}
VIRTUAL_DEPENDENT = {Fraction(5, 4), Fraction(5, 3)}
BOUNDARY_ASSISTED = {Fraction(2, 1)}

# R133/R126 rent-normalized available feedback values, identity normalized.
# These are geometry-screen inputs, not empirical masses.
AVAILABLE_NORM = {
    Fraction(1, 2): 0.043158,
    Fraction(2, 3): 0.161160,
    Fraction(3, 4): 0.285086,
    Fraction(1, 1): 1.000000,
    Fraction(5, 4): 5.700160,
    Fraction(4, 3): 9.398832,
    Fraction(3, 2): 27.536241,
    Fraction(5, 3): 108.109209,
    Fraction(2, 1): 776.840677,
}

RENT_LAWS = [
    ("p4_write_density_control", 4.0, "FAIL_CONTROL_TOO_SHALLOW"),
    ("p5_quadratic_density_self_energy", 5.0, "PRIMARY_DERIVED_RENT_CANDIDATE"),
    ("p6_curvature_weighted_self_energy", 6.0, "PRIMARY_COMPOSITE_RENT_CANDIDATE"),
    ("p7_acceleration_weighted_control", 7.0, "HIGH_ORDER_CONTROL_NOT_LAW"),
]

def frac_label(x):
    return str(x) if isinstance(x, Fraction) else str(x)

def label_set(xs):
    xs = list(xs)
    if not xs:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(xs))

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def support_ecology(rho):
    if rho in VIRTUAL_DEPENDENT:
        return "virtual_support_dependent"
    if rho in BOUNDARY_ASSISTED:
        return "boundary_assisted"
    return "clean_internal"

def classify(rho, adequacy):
    if adequacy < 1.0:
        return "mode_normalized_deficit_collective_candidate"
    eco = support_ecology(rho)
    if eco == "virtual_support_dependent":
        return "adequate_but_virtual_support_dependent"
    if eco == "boundary_assisted":
        return "adequate_but_boundary_assisted"
    return "standalone_clean_internal_screen"

# ---------------------------------------------------------------------
# 1. Build adequacy tables from R133-style rent profiles.
# ---------------------------------------------------------------------

adequacy_rows = []
summary_rows = []

for law_id, power, grade in RENT_LAWS:
    law_classes = []
    low_deficits = []
    low_surplus = []
    clean_standalone = []
    support_structured = []

    for rho in SEED:
        rent = float(rho) ** power
        available = AVAILABLE_NORM[rho]
        adequacy = available / rent if rent != 0 else float("inf")
        cls = classify(rho, adequacy)
        eco = support_ecology(rho)

        if rho in LOW_MODES:
            if adequacy >= 1.0:
                low_surplus.append(rho)
            else:
                low_deficits.append(rho)
        if cls == "standalone_clean_internal_screen":
            clean_standalone.append(rho)
        if cls in ["adequate_but_virtual_support_dependent", "adequate_but_boundary_assisted"]:
            support_structured.append(rho)
        law_classes.append(cls)

        adequacy_rows.append({
            "law_id": law_id,
            "power": power,
            "rho": frac_label(rho),
            "rho_float": float(rho),
            "available_norm": available,
            "required_rent": rent,
            "adequacy": adequacy,
            "closure_class": cls,
            "support_ecology": eco,
            "low_mode": rho in LOW_MODES,
        })

    low_mode_relief = len(low_deficits) == 0
    clean_capacity_for_unconfined = len(clean_standalone) >= 3
    support_scaffold_present = len(support_structured) >= 2
    no_clean_binary_split = len(set(law_classes)) > 2

    if law_id.startswith("p4"):
        sanity_status = "CONTROL_FAILS_LOW_MODE_SANITY" if not low_mode_relief else "UNEXPECTED_RELIEF"
    elif law_id.startswith("p5") or law_id.startswith("p6"):
        sanity_status = "PASS_QUALITATIVE_COMPATIBILITY_SCREEN" if (low_mode_relief and clean_capacity_for_unconfined and support_scaffold_present) else "PARTIAL"
    else:
        sanity_status = "HIGH_ORDER_CONTROL_REPORTED_NOT_LAW"

    summary_rows.append({
        "law_id": law_id,
        "power": power,
        "candidate_grade": grade,
        "low_mode_relief": low_mode_relief,
        "low_deficit_modes": label_set(low_deficits),
        "low_surplus_modes": label_set(low_surplus),
        "clean_standalone_count": len(clean_standalone),
        "clean_standalone_modes": label_set(clean_standalone),
        "support_structured_count": len(support_structured),
        "support_structured_modes": label_set(support_structured),
        "clean_capacity_for_unconfined_archetype": clean_capacity_for_unconfined,
        "support_scaffold_for_confined_archetype": support_scaffold_present,
        "four_class_ecology_present": no_clean_binary_split,
        "sanity_status": sanity_status,
    })

adequacy_table = pd.DataFrame(adequacy_rows)
sanity_summary = pd.DataFrame(summary_rows)

# ---------------------------------------------------------------------
# 2. Qualitative observation sanity register.
# Observations are recorded for sanity context only and are not used
# to compute rent profiles, thresholds, or classes.
# ---------------------------------------------------------------------

observation_awareness = pd.DataFrame([
    {
        "used_in_computation": False,
        "observation_context": "Some charged leptons can exist unconfined; the electron is stable while muon and tau decay but are not confined.",
        "sanity_use": "Require that candidate closure ecology contain enough clean standalone internal slots; do not map rho modes to leptons.",
    },
    {
        "used_in_computation": False,
        "observation_context": "Quarks are not observed as isolated free particles and their quoted masses are scheme/scale dependent.",
        "sanity_use": "Require that candidate closure ecology contain support-structured modes; do not map rho modes to quarks.",
    },
    {
        "used_in_computation": False,
        "observation_context": "R130/R131 shallow rent laws made low modes look collectively dependent, which was observation-suspicious.",
        "sanity_use": "Check whether p=5/p=6 derived rent candidates relieve this reversal without mass data.",
    },
    {
        "used_in_computation": False,
        "observation_context": "Photons, neutrinos, hadron binding masses, and full Standard Model sector assignments are outside this gate.",
        "sanity_use": "Keep this as a qualitative compatibility screen only.",
    },
])

# ---------------------------------------------------------------------
# 3. Sector-split sanity controls.
# ---------------------------------------------------------------------

p4 = sanity_summary[sanity_summary["law_id"] == "p4_write_density_control"].iloc[0]
p5 = sanity_summary[sanity_summary["law_id"] == "p5_quadratic_density_self_energy"].iloc[0]
p6 = sanity_summary[sanity_summary["law_id"] == "p6_curvature_weighted_self_energy"].iloc[0]

p4_control_fails_observation_sanity = bool(not p4["low_mode_relief"])
p5_qualitative_compatibility = bool(
    p5["low_mode_relief"]
    and p5["clean_capacity_for_unconfined_archetype"]
    and p5["support_scaffold_for_confined_archetype"]
)
p6_qualitative_compatibility = bool(
    p6["low_mode_relief"]
    and p6["clean_capacity_for_unconfined_archetype"]
    and p6["support_scaffold_for_confined_archetype"]
)

clean_unconfined_capacity_present = bool(p5["clean_standalone_count"] >= 3 and p6["clean_standalone_count"] >= 3)
support_structured_capacity_present = bool(p5["support_structured_count"] >= 2 and p6["support_structured_count"] >= 2)
four_class_ecology_present = bool(p5["four_class_ecology_present"] and p6["four_class_ecology_present"])
clean_binary_sector_split_closed = False
observation_sanity_pass = bool(
    p4_control_fails_observation_sanity
    and p5_qualitative_compatibility
    and p6_qualitative_compatibility
    and clean_unconfined_capacity_present
    and support_structured_capacity_present
)

sector_split_control = pd.DataFrame([
    {
        "control": "p4_shallow_write_density",
        "status": "FAILS_SANITY_AS_EXPECTED" if p4_control_fails_observation_sanity else "UNEXPECTED_PASS",
        "interpretation": "p=4 keeps low-mode deficits and is retained as the shallow-rent fail control.",
    },
    {
        "control": "p5_self_energy_rent",
        "status": "PASS_QUALITATIVE_SANITY" if p5_qualitative_compatibility else "PARTIAL",
        "interpretation": "p=5 relieves low modes and preserves both clean standalone and support-structured classes.",
    },
    {
        "control": "p6_curvature_weighted_self_energy_rent",
        "status": "PASS_QUALITATIVE_SANITY" if p6_qualitative_compatibility else "PARTIAL",
        "interpretation": "p=6 relieves low modes and preserves both clean standalone and support-structured classes.",
    },
    {
        "control": "clean_binary_lepton_quark_split",
        "status": "OPEN_NOT_CLOSED",
        "interpretation": "The ecology has more than two classes and no rho-to-particle mapping is declared.",
    },
    {
        "control": "quark_color_or_confinement_derivation",
        "status": "OPEN_NOT_CLOSED",
        "interpretation": "Support-structured classes are present, but confinement/color is not derived.",
    },
])

# ---------------------------------------------------------------------
# 4. Claim boundary and gate audit.
# ---------------------------------------------------------------------

no_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_parameter_fit_performed = True
no_mode_particle_mapping_performed = True
no_final_physical_sector_split_selected = True
physical_mass_spectrum_claimed = False
SM_sector_mapping_claimed = False
true_GR_PDE_collective_field_closed = False
observations_used_in_computation = False
unique_rent_law_closed = False

verdict_status = (
    "OBSERVATION SANITY / SECTOR-SPLIT CONTROL PASS / QUALITATIVE COMPATIBILITY REPORTED, NO PARTICLE MAPPING"
    if observation_sanity_pass
    and no_empirical_mass_data_loaded
    and no_mode_particle_mapping_performed
    and not physical_mass_spectrum_claimed
    else "OBSERVATION SANITY / SECTOR-SPLIT CONTROL INCONCLUSIVE"
)

gate_audit = pd.DataFrame([
    {
        "test": "p4_control_fails_observation_sanity",
        "result": "PASS" if p4_control_fails_observation_sanity else "WARN",
        "interpretation": "The shallow p=4 rent law keeps the low-mode reversal and remains a fail control.",
    },
    {
        "test": "p5_qualitative_compatibility",
        "result": "PASS" if p5_qualitative_compatibility else "WARN",
        "interpretation": "p=5 gives enough clean standalone slots and support-structured slots without observation input.",
    },
    {
        "test": "p6_qualitative_compatibility",
        "result": "PASS" if p6_qualitative_compatibility else "WARN",
        "interpretation": "p=6 gives enough clean standalone slots and support-structured slots without observation input.",
    },
    {
        "test": "clean_unconfined_capacity_present",
        "result": "PASS" if clean_unconfined_capacity_present else "WARN",
        "interpretation": "The candidate ecology has sufficient clean standalone capacity for unconfined archetypes, without assigning identities.",
    },
    {
        "test": "support_structured_capacity_present",
        "result": "PASS" if support_structured_capacity_present else "WARN",
        "interpretation": "The candidate ecology contains support-structured modes, preserving room for confined/collective archetypes.",
    },
    {
        "test": "clean_binary_sector_split_closed",
        "result": "OPEN",
        "interpretation": "A clean lepton/quark split is not derived or claimed.",
    },
    {
        "test": "observations_used_in_computation",
        "result": "NO",
        "interpretation": "Observation notes are context only; no observed masses or mappings enter the computation.",
    },
    {
        "test": "no_empirical_mass_data_loaded",
        "result": "PASS" if no_empirical_mass_data_loaded else "WARN",
        "interpretation": "No empirical mass table or mass-ratio table is loaded.",
    },
    {
        "test": "no_mode_particle_mapping_performed",
        "result": "PASS" if no_mode_particle_mapping_performed else "WARN",
        "interpretation": "No rho-to-particle identities are assigned.",
    },
    {
        "test": "observation_sanity_pass",
        "result": "PASS" if observation_sanity_pass else "WARN",
        "interpretation": "p=5/p=6 pass the qualitative observation sanity screen while p=4 remains a fail control.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R134 checks observation sanity of the p=5/p=6 rent-normalized closure ecology.",
        "status": "YES_SCREEN",
        "reason": "Observation context is recorded and compared qualitatively against class capacities, without mass data or mapping.",
    },
    {
        "claim": "R134 uses observations to tune formulas, thresholds, or classifications.",
        "status": "NO",
        "reason": "Rent laws and classes come from R132/R133 inputs; observations are not used in computation.",
    },
    {
        "claim": "R134 maps rho modes to leptons, quarks, or Standard Model particles.",
        "status": "NO",
        "reason": "Only archetype capacity is checked; no particle identities are assigned.",
    },
    {
        "claim": "R134 proves a clean standalone/confined sector split.",
        "status": "NO",
        "reason": "The closure ecology has multiple classes and remains diagnostic.",
    },
    {
        "claim": "R134 loads empirical particle masses or mass ratios.",
        "status": "NO",
        "reason": "No empirical mass table is loaded.",
    },
    {
        "claim": "R134 selects p=5 or p=6 as the final physical rent law.",
        "status": "NO",
        "reason": "p=5 and p=6 remain candidates; unique rent law and PDE derivation remain open.",
    },
    {
        "claim": "R134 confirms the V12.8/V12.9 seed as the Standard Model spectrum.",
        "status": "NO",
        "reason": "The nine modes remain a mechanical/operator-geometric seed pending physical identification.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R135",
        "title": "Locked Rent-Normalized Candidate Mass Screen Gate",
        "goal": "Freeze p=5/p=6 rent-normalized candidates, then compare blindly against the mass-ratio screen.",
        "must_not_do": "Do not retune p, thresholds, mappings, or candidate values after seeing mass hits.",
    },
    {
        "next_gate": "FORCE_R128",
        "title": "GR/Lag Field Derivation Gate",
        "goal": "Attempt to derive the feedback/rent laws from a more principled lag/field equation.",
        "must_not_do": "Do not treat power counting or observation sanity as full PDE/GR closure.",
    },
])

# Save artifacts.
adequacy_table.to_csv(OUT / "FORCE_R134_adequacy_table.csv", index=False)
sanity_summary.to_csv(OUT / "FORCE_R134_sanity_summary.csv", index=False)
observation_awareness.to_csv(OUT / "FORCE_R134_observation_awareness.csv", index=False)
sector_split_control.to_csv(OUT / "FORCE_R134_sector_split_control.csv", index=False)
gate_audit.to_csv(OUT / "FORCE_R134_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R134_claim_boundary.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R134_next_gate_plan.csv", index=False)

verdict = {
    "force_id": "FORCE_R134",
    "title": "Observation Sanity / Sector-Split Control Gate",
    "status": verdict_status,
    "freeze_id": FREEZE_ID,
    "p4_control_fails_observation_sanity": p4_control_fails_observation_sanity,
    "p5_qualitative_compatibility": p5_qualitative_compatibility,
    "p6_qualitative_compatibility": p6_qualitative_compatibility,
    "clean_unconfined_capacity_present": clean_unconfined_capacity_present,
    "support_structured_capacity_present": support_structured_capacity_present,
    "four_class_ecology_present": four_class_ecology_present,
    "observations_used_in_computation": observations_used_in_computation,
    "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
    "no_mass_matching_performed": no_mass_matching_performed,
    "no_parameter_fit_performed": no_parameter_fit_performed,
    "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
    "no_final_physical_sector_split_selected": no_final_physical_sector_split_selected,
    "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
    "SM_sector_mapping_claimed": SM_sector_mapping_claimed,
    "true_GR_PDE_collective_field_closed": true_GR_PDE_collective_field_closed,
    "unique_rent_law_closed": unique_rent_law_closed,
    "selected_seed": [frac_label(x) for x in SEED],
    "recommended_next": "FORCE_R135_locked_rent_normalized_candidate_mass_screen_gate",
}
(OUT / "FORCE_R134_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# {TITLE}

## Verdict

BOXED: {verdict_status}

## Core result

BOXED: p=4 remains a shallow-rent fail control.

BOXED: p=5 and p=6 are qualitatively observation-compatible screens: they relieve the low-mode reversal while preserving both clean standalone and support-structured classes.

## Important boundary

BOXED: No rho-to-particle mapping is declared.

BOXED: No masses or mass ratios are loaded.

BOXED: No physical sector split is selected.

## Key booleans

- p4_control_fails_observation_sanity: {p4_control_fails_observation_sanity}
- p5_qualitative_compatibility: {p5_qualitative_compatibility}
- p6_qualitative_compatibility: {p6_qualitative_compatibility}
- clean_unconfined_capacity_present: {clean_unconfined_capacity_present}
- support_structured_capacity_present: {support_structured_capacity_present}
- observations_used_in_computation: {observations_used_in_computation}
- no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}
- no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}
- unique_rent_law_closed: {unique_rent_law_closed}

## Sanity summary

{sanity_summary.to_string(index=False)}

## Sector split controls

{sector_split_control.to_string(index=False)}

## Gate audit

{gate_audit.to_string(index=False)}

## Observation awareness

{observation_awareness.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}
"""
(OUT / "FORCE_R134_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R134_observation_sanity_sector_split_control_gate.py")
except Exception:
    pass

# Manifest.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
manifest = pd.DataFrame(manifest_rows)
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Zip.
if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()
zip_integrity_pass = bad is None

print("\n=== COPY/PASTE R134 RESULT ===")
print("R134 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"p4_control_fails_observation_sanity: {p4_control_fails_observation_sanity}")
print(f"p5_qualitative_compatibility: {p5_qualitative_compatibility}")
print(f"p6_qualitative_compatibility: {p6_qualitative_compatibility}")
print(f"clean_unconfined_capacity_present: {clean_unconfined_capacity_present}")
print(f"support_structured_capacity_present: {support_structured_capacity_present}")
print(f"four_class_ecology_present: {four_class_ecology_present}")
print(f"observations_used_in_computation: {observations_used_in_computation}")
print(f"no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}")
print(f"no_mass_matching_performed: {no_mass_matching_performed}")
print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
print(f"no_final_physical_sector_split_selected: {no_final_physical_sector_split_selected}")
print(f"physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}")
print(f"SM_sector_mapping_claimed: {SM_sector_mapping_claimed}")
print(f"true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}")
print(f"unique_rent_law_closed: {unique_rent_law_closed}")
print(f"selected_seed: {{{label_set(SEED)}}}")
print("SANITY_SUMMARY:")
print(sanity_summary.to_string(index=False))
print("SECTOR_SPLIT_CONTROL:")
print(sector_split_control.to_string(index=False))
print("OBSERVATION_AWARENESS:")
print(observation_awareness.to_string(index=False))
print("GATE_AUDIT:")
print(gate_audit.to_string(index=False))
print("CLAIM_BOUNDARY:")
for row in claim_boundary.itertuples(index=False):
    print(f"  {row.status} | {row.claim} -- {row.reason}")
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R134_summary.md').resolve()}")
print("NEXT: FORCE_R135_locked_rent_normalized_candidate_mass_screen_gate")
print("=== END COPY/PASTE R134 RESULT ===\n")
