#!/usr/bin/env python3
"""
FORCE_R118 — Analytic Helical Self-Energy Derivation Gate

Purpose
-------
Replace the R116 toy lens/focusing proxies with a more principled geometry-native
self-energy candidate family for V12.9.

This gate computes self-energy-like functionals of closed helical/toroidal
worldline-tube curves using only rho and universal geometric choices. It does
NOT load empirical particle masses, does NOT compare to Standard Model mass
ratios, does NOT fit parameters to data, and does NOT select a final physical
mass law.

R118 claim boundary:
    YES: geometry-native analytic/regularized self-energy candidate roster.
    NO: true GR/PDE self-energy closure.
    NO: physical mass spectrum / SM matching / Omega0.
    NO: rho-to-particle mapping.

Run:
    python FORCE_R118_analytic_helical_self_energy_derivation_gate.py
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math
import shutil
import zipfile
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


FORCE_ID = "FORCE_R118"
TITLE = "Analytic Helical Self-Energy Derivation Gate"
OUT = Path("FORCE_R118_analytic_helical_self_energy_derivation_gate")
ZIP = Path("FORCE_R118_analytic_helical_self_energy_derivation_gate_pack.zip")
PLOTS = OUT / "plots"

SEED: List[Fraction] = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUAL_SUPPORTS: List[Fraction] = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
CONTROLS: List[Fraction] = [Fraction(1, 4), Fraction(6, 5), Fraction(7, 5), Fraction(7, 4)]
ALL_MODES: List[Fraction] = sorted(set(SEED + VIRTUAL_SUPPORTS + CONTROLS))

EPS_LIST = [0.03, 0.06, 0.12]
N_SAMPLES = 640
TORUS_R_MAJOR = 1.0
TORUS_A_MINOR = 0.35


def frac_label(x: Fraction | str | float | int) -> str:
    if isinstance(x, Fraction):
        return str(x)
    return str(x)


def label_set(xs: Iterable[Fraction]) -> str:
    return "{" + ", ".join(frac_label(x) for x in xs) + "}"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def clean_start() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    PLOTS.mkdir(parents=True)


@dataclass(frozen=True)
class CurveMetrics:
    rho: Fraction
    p: int
    q: int
    class_label: str
    species_accept: bool
    curve_length: float
    bend_energy: float
    mean_curvature: float
    rms_curvature: float
    total_abs_torsion: float
    mean_abs_torsion: float
    writhe_proxy: float
    helix_complexity: float
    analytic_lens_proxy: float


def torus_knot_curve(rho: Fraction, n: int = N_SAMPLES, R: float = TORUS_R_MAJOR, a: float = TORUS_A_MINOR) -> Tuple[np.ndarray, np.ndarray]:
    """Return t and a closed torus-knot-like curve for rho=p/q.

    Convention:
        p = normal/tube winding count
        q = longitudinal/base winding count

    The curve is not claimed to be the final physical embedding. It is a
    universal closed helical representative used to derive analytic candidate
    functionals without using mass data.
    """
    p = rho.numerator
    q = rho.denominator
    t = np.linspace(0.0, 2.0 * np.pi, n, endpoint=False)
    x = (R + a * np.cos(p * t)) * np.cos(q * t)
    y = (R + a * np.cos(p * t)) * np.sin(q * t)
    z = a * np.sin(p * t)
    r = np.stack([x, y, z], axis=1)
    return t, r


def periodic_derivative(arr: np.ndarray, dt: float, order: int = 1) -> np.ndarray:
    out = arr.copy()
    for _ in range(order):
        out = (np.roll(out, -1, axis=0) - np.roll(out, 1, axis=0)) / (2.0 * dt)
    return out


def curve_differential_geometry(rho: Fraction, class_label: str, species_accept: bool) -> Tuple[CurveMetrics, np.ndarray, np.ndarray]:
    t, r = torus_knot_curve(rho)
    dt = 2.0 * np.pi / len(t)
    rp = periodic_derivative(r, dt, 1)
    rpp = periodic_derivative(r, dt, 2)
    rppp = periodic_derivative(r, dt, 3)

    speed = np.linalg.norm(rp, axis=1)
    ds = speed * dt
    L = float(np.sum(ds))

    cross = np.cross(rp, rpp)
    cross_norm = np.linalg.norm(cross, axis=1)
    speed_safe = np.maximum(speed, 1e-12)
    kappa = cross_norm / np.maximum(speed_safe ** 3, 1e-12)

    # Torsion tau = ((r' x r'') dot r''') / |r' x r''|^2.
    torsion = np.einsum("ij,ij->i", cross, rppp) / np.maximum(cross_norm ** 2, 1e-12)

    bend_energy = float(np.sum((kappa ** 2) * ds))
    mean_curvature = float(np.sum(kappa * ds) / max(L, 1e-12))
    rms_curvature = float(math.sqrt(np.sum((kappa ** 2) * ds) / max(L, 1e-12)))
    total_abs_torsion = float(np.sum(np.abs(torsion) * ds))
    mean_abs_torsion = float(total_abs_torsion / max(L, 1e-12))

    # A dimensionless chirality/folding proxy. Not topological writhe; guardrail label says proxy.
    tangent = rp / speed_safe[:, None]
    writhe_proxy = float(np.sum(np.einsum("ij,ij->i", tangent, np.roll(tangent, -1, axis=0)) * ds) / max(L, 1e-12))

    p = rho.numerator
    q = rho.denominator
    helix_complexity = float((p * q) * math.sqrt(1.0 + float(rho) ** 2))
    analytic_lens_proxy = float((float(rho) ** 3) * math.sqrt(1.0 + float(rho) ** 2))

    metrics = CurveMetrics(
        rho=rho,
        p=p,
        q=q,
        class_label=class_label,
        species_accept=species_accept,
        curve_length=L,
        bend_energy=bend_energy,
        mean_curvature=mean_curvature,
        rms_curvature=rms_curvature,
        total_abs_torsion=total_abs_torsion,
        mean_abs_torsion=mean_abs_torsion,
        writhe_proxy=writhe_proxy,
        helix_complexity=helix_complexity,
        analytic_lens_proxy=analytic_lens_proxy,
    )
    return metrics, r, ds


def green_kernel_self_energy(r: np.ndarray, ds: np.ndarray, eps: float) -> Dict[str, float]:
    """Regularized curve-supported Green-kernel self-overlap.

    The 1/sqrt(|x-x'|^2+eps^2) kernel is a scalar Green-kernel proxy. It is
    not a solved GR self-energy; it is a geometry-native candidate ingredient.
    """
    diff = r[:, None, :] - r[None, :, :]
    dist2 = np.einsum("ijk,ijk->ij", diff, diff)
    w = ds[:, None] * ds[None, :]
    kernel = 1.0 / np.sqrt(dist2 + eps ** 2)
    all_energy = float(np.sum(w * kernel))

    n = len(ds)
    mask = ~np.eye(n, dtype=bool)
    offdiag_energy = float(np.sum(w[mask] * kernel[mask]))
    diag_energy = all_energy - offdiag_energy
    L = float(np.sum(ds))

    return {
        "green_all": all_energy,
        "green_offdiag": offdiag_energy,
        "green_diag": diag_energy,
        "green_all_density": all_energy / max(L ** 2, 1e-12),
        "green_offdiag_density": offdiag_energy / max(L ** 2, 1e-12),
        "green_diag_density": diag_energy / max(L ** 2, 1e-12),
    }


def mode_class(rho: Fraction) -> Tuple[str, bool, str]:
    if rho in SEED:
        return "stable_seed", True, "species seed mode"
    if rho in VIRTUAL_SUPPORTS:
        if rho == Fraction(1, 3):
            return "virtual_support_not_species", False, "fails_binary_no_overlap"
        return "virtual_support_not_species", False, "fails_slot_capacity"
    return "control_not_species", False, "control mode outside frozen species projection"


def ratio_dynamic_range(values: List[float]) -> float:
    vals = [float(v) for v in values if np.isfinite(v) and v > 0]
    if not vals:
        return float("nan")
    return max(vals) / min(vals)


def write_plot_bar(df: pd.DataFrame, column: str, title: str, filename: str) -> None:
    plt.figure(figsize=(10, 5))
    plot_df = df[df["class"] == "stable_seed"].copy()
    plt.bar(plot_df["rho"], plot_df[column])
    plt.xticks(rotation=35, ha="right")
    plt.ylabel(column)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(PLOTS / filename, dpi=160)
    plt.close()


def main() -> None:
    clean_start()

    # ------------------------------------------------------------------
    # 1. Generate geometry and self-energy tables.
    # ------------------------------------------------------------------
    geometry_rows = []
    kernel_rows = []

    for rho in ALL_MODES:
        cls, species_accept, rejection = mode_class(rho)
        metrics, r, ds = curve_differential_geometry(rho, cls, species_accept)
        geometry_rows.append({
            "rho": frac_label(rho),
            "rho_float": float(rho),
            "numerator_p": metrics.p,
            "denominator_q": metrics.q,
            "class": cls,
            "species_accept": species_accept,
            "species_rejection_reason": rejection,
            "curve_length": metrics.curve_length,
            "bend_energy_int_kappa2_ds": metrics.bend_energy,
            "mean_curvature": metrics.mean_curvature,
            "rms_curvature": metrics.rms_curvature,
            "total_abs_torsion": metrics.total_abs_torsion,
            "mean_abs_torsion": metrics.mean_abs_torsion,
            "writhe_proxy": metrics.writhe_proxy,
            "helix_complexity": metrics.helix_complexity,
            "analytic_lens_proxy": metrics.analytic_lens_proxy,
        })

        for eps in EPS_LIST:
            g = green_kernel_self_energy(r, ds, eps)
            kernel_rows.append({
                "rho": frac_label(rho),
                "rho_float": float(rho),
                "class": cls,
                "species_accept": species_accept,
                "eps": eps,
                **g,
            })

    geometry_df = pd.DataFrame(geometry_rows)
    kernel_df = pd.DataFrame(kernel_rows)

    # ------------------------------------------------------------------
    # 2. Regularization finite-part fit across eps values.
    # ------------------------------------------------------------------
    # This is a geometry-side regulator extrapolation, not an empirical fit.
    # Model: density(eps) = a*(1/eps) + b + c*eps.
    # The finite-part candidate is b. With only three eps values this is just
    # a diagnostic, not a settled renormalization theorem.
    finite_rows = []
    for rho_label, grp in kernel_df.groupby("rho", sort=False):
        grp = grp.sort_values("eps")
        eps = grp["eps"].to_numpy(dtype=float)
        x = np.vstack([1.0 / eps, np.ones_like(eps), eps]).T
        y_all = grp["green_all_density"].to_numpy(dtype=float)
        y_off = grp["green_offdiag_density"].to_numpy(dtype=float)
        coef_all, *_ = np.linalg.lstsq(x, y_all, rcond=None)
        coef_off, *_ = np.linalg.lstsq(x, y_off, rcond=None)
        cls = grp["class"].iloc[0]
        species_accept = bool(grp["species_accept"].iloc[0])
        finite_rows.append({
            "rho": rho_label,
            "rho_float": float(Fraction(rho_label)),
            "class": cls,
            "species_accept": species_accept,
            "all_density_divergent_coeff_a": float(coef_all[0]),
            "all_density_finite_part_b": float(coef_all[1]),
            "all_density_linear_eps_coeff_c": float(coef_all[2]),
            "offdiag_density_divergent_coeff_a": float(coef_off[0]),
            "offdiag_density_finite_part_b": float(coef_off[1]),
            "offdiag_density_linear_eps_coeff_c": float(coef_off[2]),
        })
    finite_part_df = pd.DataFrame(finite_rows)

    # ------------------------------------------------------------------
    # 3. Candidate functional roster.
    # ------------------------------------------------------------------
    seed_geom = geometry_df[geometry_df["class"] == "stable_seed"].copy()
    seed_kernel = kernel_df[kernel_df["class"] == "stable_seed"].copy()
    seed_finite = finite_part_df[finite_part_df["class"] == "stable_seed"].copy()

    # Merge central eps=0.06 self-energy columns into a seed table.
    central_kernel = seed_kernel[np.isclose(seed_kernel["eps"], 0.06)].copy()
    central_kernel = central_kernel[[
        "rho", "green_all_density", "green_offdiag_density", "green_diag_density",
        "green_all", "green_offdiag", "green_diag",
    ]]

    roster_base = seed_geom.merge(central_kernel, on="rho", how="left").merge(
        seed_finite[["rho", "all_density_finite_part_b", "offdiag_density_finite_part_b"]],
        on="rho", how="left",
    )
    roster_base["bend_times_offdiag_density"] = roster_base["bend_energy_int_kappa2_ds"] * roster_base["green_offdiag_density"]
    roster_base["curvature_times_green_density"] = roster_base["rms_curvature"] * roster_base["green_offdiag_density"]
    roster_base["torsion_plus_curvature_action"] = roster_base["bend_energy_int_kappa2_ds"] + roster_base["total_abs_torsion"]
    roster_base["finite_part_abs_all"] = roster_base["all_density_finite_part_b"].abs()
    roster_base["finite_part_abs_offdiag"] = roster_base["offdiag_density_finite_part_b"].abs()

    candidate_columns = [
        "curve_length",
        "bend_energy_int_kappa2_ds",
        "mean_curvature",
        "rms_curvature",
        "total_abs_torsion",
        "helix_complexity",
        "analytic_lens_proxy",
        "green_all_density",
        "green_offdiag_density",
        "bend_times_offdiag_density",
        "curvature_times_green_density",
        "torsion_plus_curvature_action",
        "finite_part_abs_all",
        "finite_part_abs_offdiag",
    ]

    roster_rows = []
    for col in candidate_columns:
        values = roster_base[col].replace([np.inf, -np.inf], np.nan).dropna()
        drange = ratio_dynamic_range(values.tolist())
        min_idx = roster_base[col].idxmin()
        max_idx = roster_base[col].idxmax()
        # A very high sensitivity label if finite part or regulator terms are used.
        regulator_status = "requires_regularization" if "green" in col or "finite" in col or "offdiag" in col else "local_geometric"
        roster_rows.append({
            "functional_id": col,
            "seed_dynamic_range_max_over_min": drange,
            "seed_min_rho_at_function_min": roster_base.loc[min_idx, "rho"],
            "seed_max_rho_at_function_max": roster_base.loc[max_idx, "rho"],
            "candidate_origin": regulator_status,
            "selected_as_final_physical_mass_law": False,
        })
    functional_roster = pd.DataFrame(roster_rows).sort_values(
        "seed_dynamic_range_max_over_min", ascending=False
    )

    # ------------------------------------------------------------------
    # 4. Sensitivity and controls.
    # ------------------------------------------------------------------
    sens_rows = []
    for rho_label, grp in seed_kernel.groupby("rho", sort=False):
        vals = grp["green_offdiag_density"].to_numpy(dtype=float)
        vals_all = grp["green_all_density"].to_numpy(dtype=float)
        sens_rows.append({
            "rho": rho_label,
            "offdiag_density_eps_min": float(np.min(vals)),
            "offdiag_density_eps_max": float(np.max(vals)),
            "offdiag_density_spread_frac": float((np.max(vals) - np.min(vals)) / max(np.mean(vals), 1e-12)),
            "all_density_eps_min": float(np.min(vals_all)),
            "all_density_eps_max": float(np.max(vals_all)),
            "all_density_spread_frac": float((np.max(vals_all) - np.min(vals_all)) / max(np.mean(vals_all), 1e-12)),
        })
    regularization_sensitivity = pd.DataFrame(sens_rows)

    virtual_status = geometry_df[geometry_df["class"] == "virtual_support_not_species"][[
        "rho", "class", "species_accept", "species_rejection_reason", "curve_length",
        "bend_energy_int_kappa2_ds", "analytic_lens_proxy",
    ]].copy()
    virtual_status["geometric_F_values_computed"] = True
    virtual_status["promoted_to_species_by_F"] = False
    virtual_status["interpretation"] = (
        "Focusing/self-energy values may be computed for support channels, but V12.8 species projection is not overridden."
    )

    control_status = geometry_df[geometry_df["class"] == "control_not_species"][[
        "rho", "class", "species_accept", "species_rejection_reason", "curve_length",
        "bend_energy_int_kappa2_ds", "analytic_lens_proxy",
    ]].copy()
    control_status["geometric_F_values_computed"] = True
    control_status["promoted_to_species_by_F"] = False

    derivation_audit = pd.DataFrame([
        {
            "derivation_component": "closed helical representative curve",
            "status": "PASS_CANDIDATE",
            "statement": "Each rho=p/q is represented by a closed toroidal helical curve with p normal and q longitudinal windings.",
            "boundary": "This representative embedding is not proven unique.",
        },
        {
            "derivation_component": "local curvature action",
            "status": "PASS_CANDIDATE",
            "statement": "Integral kappa^2 ds and torsion/curvature metrics are computed directly from the curve.",
            "boundary": "Local curvature alone is not proven to be the physical mass functional.",
        },
        {
            "derivation_component": "nonlocal Green-kernel self-overlap",
            "status": "PASS_CANDIDATE",
            "statement": "A regularized 1/sqrt(|x-x'|^2+eps^2) curve self-overlap is computed as a self-energy proxy.",
            "boundary": "This is not an Einstein-field self-energy solution.",
        },
        {
            "derivation_component": "regularization finite part",
            "status": "PARTIAL_OPEN",
            "statement": "A finite-part extrapolation is computed from eps samples as a diagnostic.",
            "boundary": "Counterterm/renormalization prescription is not uniquely derived.",
        },
        {
            "derivation_component": "mass data comparison",
            "status": "NOT_PERFORMED",
            "statement": "No empirical masses or SM target ratios are loaded.",
            "boundary": "Comparison is reserved for a later locked gate after a final F candidate is fixed.",
        },
        {
            "derivation_component": "full PDE/GR self-energy",
            "status": "OPEN",
            "statement": "No full field equation or GR-compatible self-consistent stress-energy solution is solved.",
            "boundary": "Physical mass law remains open.",
        },
    ])

    # ------------------------------------------------------------------
    # 5. Booleans / verdict.
    # ------------------------------------------------------------------
    geometry_table_generated = not geometry_df.empty
    seed_all_computed = set(seed_geom["rho"].tolist()) == {frac_label(x) for x in SEED}
    virtuals_computed_not_promoted = bool(
        (set(virtual_status["rho"].tolist()) == {frac_label(x) for x in VIRTUAL_SUPPORTS})
        and (not virtual_status["promoted_to_species_by_F"].any())
    )
    kernel_table_generated = not kernel_df.empty and set(kernel_df["eps"].round(6).unique()) == set(np.round(EPS_LIST, 6))
    finite_part_generated = not finite_part_df.empty
    all_functionals_finite_positive = bool(
        all(np.isfinite(roster_base[col]).all() and (roster_base[col].abs() > 0).all() for col in candidate_columns)
    )
    functional_roster_generated = not functional_roster.empty
    regularization_sensitivity_reported = not regularization_sensitivity.empty
    no_empirical_mass_data_loaded = True
    no_mass_matching_performed = True
    no_parameter_fit_performed = True
    no_mode_particle_mapping_performed = True
    no_final_physical_mass_law_selected = True
    unique_renormalization_closed = False
    dynamic_GR_self_energy_closed = False
    full_PDE_mass_functional_closed = False
    physical_mass_spectrum_claimed = False
    SM_mass_matching_claimed = False
    Omega0_claimed = False

    candidate_self_energy_roster_closed = bool(
        geometry_table_generated
        and seed_all_computed
        and virtuals_computed_not_promoted
        and kernel_table_generated
        and finite_part_generated
        and all_functionals_finite_positive
        and functional_roster_generated
        and regularization_sensitivity_reported
        and no_empirical_mass_data_loaded
        and no_mass_matching_performed
        and no_parameter_fit_performed
        and no_mode_particle_mapping_performed
        and not physical_mass_spectrum_claimed
    )

    if candidate_self_energy_roster_closed and not unique_renormalization_closed and not full_PDE_mass_functional_closed:
        verdict_status = "ANALYTIC HELICAL SELF-ENERGY CANDIDATE PASS / RENORMALIZATION, PDE CLOSURE, AND MASS MATCHING OPEN"
    else:
        verdict_status = "ANALYTIC HELICAL SELF-ENERGY DERIVATION INCONCLUSIVE"

    gate_audit = pd.DataFrame([
        {
            "test": "geometry_table_generated",
            "result": "PASS" if geometry_table_generated else "WARN",
            "interpretation": "All audited rho modes receive closed helical geometry metrics.",
        },
        {
            "test": "seed_all_computed",
            "result": "PASS" if seed_all_computed else "WARN",
            "interpretation": "All nine V12.8 seed modes are computed.",
        },
        {
            "test": "virtuals_computed_not_promoted",
            "result": "PASS" if virtuals_computed_not_promoted else "WARN",
            "interpretation": "Virtual supports receive F-values but remain species-inactive.",
        },
        {
            "test": "kernel_table_generated",
            "result": "PASS" if kernel_table_generated else "WARN",
            "interpretation": "Regularized Green-kernel self-overlap tables were generated.",
        },
        {
            "test": "finite_part_generated",
            "result": "PASS" if finite_part_generated else "WARN",
            "interpretation": "A regulator finite-part diagnostic was generated.",
        },
        {
            "test": "all_functionals_finite_positive",
            "result": "PASS" if all_functionals_finite_positive else "WARN",
            "interpretation": "Candidate self-energy/focusing functionals are finite and nonzero on seed modes.",
        },
        {
            "test": "functional_roster_generated",
            "result": "PASS" if functional_roster_generated else "WARN",
            "interpretation": "A candidate functional roster was generated without empirical masses.",
        },
        {
            "test": "regularization_sensitivity_reported",
            "result": "PASS" if regularization_sensitivity_reported else "WARN",
            "interpretation": "Regulator sensitivity is reported rather than hidden.",
        },
        {
            "test": "no_empirical_mass_data_loaded",
            "result": "PASS",
            "interpretation": "R118 does not load particle masses or SM target ratios.",
        },
        {
            "test": "no_parameter_fit_performed",
            "result": "PASS",
            "interpretation": "No coefficient/exponent is optimized against data.",
        },
        {
            "test": "unique_renormalization_closed",
            "result": "OPEN",
            "interpretation": "The regulator/counterterm prescription is not uniquely derived.",
        },
        {
            "test": "full_PDE_mass_functional_closed",
            "result": "OPEN",
            "interpretation": "No complete PDE/GR self-energy mass functional is closed.",
        },
        {
            "test": "physical_mass_spectrum_claimed",
            "result": "OPEN",
            "interpretation": "No physical mass spectrum is claimed.",
        },
    ])

    claim_boundary = pd.DataFrame([
        {
            "claim": "R118 derives geometry-native analytic/self-energy candidate F(rho) functionals.",
            "status": "YES",
            "reason": "Closed helical curves, curvature actions, and regularized Green-kernel self-overlaps are computed from rho only.",
        },
        {
            "claim": "R118 compares F(rho) to observed particle masses.",
            "status": "NO",
            "reason": "No empirical masses or SM target ratios are loaded.",
        },
        {
            "claim": "R118 selects a final physical mass law.",
            "status": "NO",
            "reason": "Regularization and PDE derivation remain open; no final F is chosen by empirical hit.",
        },
        {
            "claim": "R118 promotes virtual supports to stable species if their F-values are interesting.",
            "status": "NO",
            "reason": "V12.8 species projection remains locked; virtual supports remain support-only.",
        },
        {
            "claim": "R118 closes true GR/PDE self-energy.",
            "status": "NO",
            "reason": "The Green-kernel integral is a principled scalar self-overlap candidate, not a solved Einstein-field solution.",
        },
        {
            "claim": "R118 confirms the nine modes are physical particles.",
            "status": "NO",
            "reason": "The nine modes remain mechanical/operator-geometric seed modes.",
        },
    ])

    risk_register = pd.DataFrame([
        {
            "risk": "Regularized Green-kernel proxy is mistaken for full GR self-energy.",
            "severity": "HIGH",
            "mitigation": "Label it scalar kernel self-overlap and keep PDE/GR closure open.",
        },
        {
            "risk": "Finite-part extrapolation is mistaken for unique renormalization.",
            "severity": "HIGH",
            "mitigation": "Report regulator sensitivity and mark counterterm prescription open.",
        },
        {
            "risk": "A functional with large dynamic range is chosen post hoc.",
            "severity": "HIGH",
            "mitigation": "No mass data loaded and no final physical mass law selected in R118.",
        },
        {
            "risk": "Virtual supports are promoted to species by attractive F-values.",
            "severity": "MEDIUM",
            "mitigation": "Species projection remains inherited from V12.8; F-values do not override admissibility.",
        },
        {
            "risk": "Embedding choice R/a is arbitrary.",
            "severity": "MEDIUM",
            "mitigation": "Treat torus curve as universal representative; future gate must test embedding invariance.",
        },
    ])

    next_gate_plan = pd.DataFrame([
        {
            "next_gate": "FORCE_R119",
            "title": "Renormalization / Embedding-Invariance Closure Gate",
            "goal": "Test whether the helical self-energy candidate is stable under regulator and torus-embedding choices without mass data.",
            "must_not_do": "Do not choose regulator, tube radius, or counterterm by particle-mass hits.",
        },
        {
            "next_gate": "FORCE_R120",
            "title": "Locked Derived-F Mass-Ratio Screen Gate",
            "goal": "Only after R119 fixes one derived F(rho), compare ratios blind against the same external mass table.",
            "must_not_do": "Do not retune F(rho) after seeing the comparison and do not hand-map rho modes to particles.",
        },
    ])

    # ------------------------------------------------------------------
    # 6. Save artifacts.
    # ------------------------------------------------------------------
    geometry_df.to_csv(OUT / "FORCE_R118_helical_geometry_table.csv", index=False)
    kernel_df.to_csv(OUT / "FORCE_R118_green_kernel_self_energy.csv", index=False)
    finite_part_df.to_csv(OUT / "FORCE_R118_regularization_finite_part.csv", index=False)
    roster_base.to_csv(OUT / "FORCE_R118_seed_functional_values.csv", index=False)
    functional_roster.to_csv(OUT / "FORCE_R118_candidate_functional_roster.csv", index=False)
    regularization_sensitivity.to_csv(OUT / "FORCE_R118_regularization_sensitivity.csv", index=False)
    virtual_status.to_csv(OUT / "FORCE_R118_virtual_support_status.csv", index=False)
    control_status.to_csv(OUT / "FORCE_R118_control_mode_status.csv", index=False)
    derivation_audit.to_csv(OUT / "FORCE_R118_derivation_audit.csv", index=False)
    gate_audit.to_csv(OUT / "FORCE_R118_gate_audit.csv", index=False)
    claim_boundary.to_csv(OUT / "FORCE_R118_claim_boundary.csv", index=False)
    risk_register.to_csv(OUT / "FORCE_R118_risk_register.csv", index=False)
    next_gate_plan.to_csv(OUT / "FORCE_R118_next_gate_plan.csv", index=False)

    verdict = {
        "force_id": FORCE_ID,
        "title": TITLE,
        "status": verdict_status,
        "candidate_self_energy_roster_closed": candidate_self_energy_roster_closed,
        "geometry_table_generated": geometry_table_generated,
        "seed_all_computed": seed_all_computed,
        "virtuals_computed_not_promoted": virtuals_computed_not_promoted,
        "kernel_table_generated": kernel_table_generated,
        "finite_part_generated": finite_part_generated,
        "all_functionals_finite_positive": all_functionals_finite_positive,
        "functional_roster_generated": functional_roster_generated,
        "regularization_sensitivity_reported": regularization_sensitivity_reported,
        "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
        "no_mass_matching_performed": no_mass_matching_performed,
        "no_parameter_fit_performed": no_parameter_fit_performed,
        "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
        "no_final_physical_mass_law_selected": no_final_physical_mass_law_selected,
        "unique_renormalization_closed": unique_renormalization_closed,
        "dynamic_GR_self_energy_closed": dynamic_GR_self_energy_closed,
        "full_PDE_mass_functional_closed": full_PDE_mass_functional_closed,
        "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
        "SM_mass_matching_claimed": SM_mass_matching_claimed,
        "Omega0_claimed": Omega0_claimed,
        "selected_seed": [frac_label(x) for x in SEED],
        "recommended_next": "FORCE_R119_renormalization_embedding_invariance_closure_gate",
    }
    (OUT / "FORCE_R118_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

    summary = f"""# FORCE_R118 — Analytic Helical Self-Energy Derivation Gate

## Verdict

BOXED: {verdict_status}

## Central result

R118 replaces purely toy focusing proxies with a geometry-native self-energy candidate roster:

- closed helical/toroidal representative curve for each rho=p/q;
- local curvature action candidates such as integral kappa^2 ds;
- regularized Green-kernel self-overlap candidates;
- regulator finite-part diagnostics.

## Selected seed

BOXED: {label_set(SEED)}

## Claim boundary

BOXED: no empirical mass data loaded.
BOXED: no mass matching performed.
BOXED: no final physical mass law selected.
BOXED: full PDE/GR self-energy remains open.
BOXED: physical spectrum, SM matching, and Omega0 remain open.

## Key booleans

- candidate_self_energy_roster_closed: {candidate_self_energy_roster_closed}
- geometry_table_generated: {geometry_table_generated}
- seed_all_computed: {seed_all_computed}
- virtuals_computed_not_promoted: {virtuals_computed_not_promoted}
- kernel_table_generated: {kernel_table_generated}
- finite_part_generated: {finite_part_generated}
- all_functionals_finite_positive: {all_functionals_finite_positive}
- regularization_sensitivity_reported: {regularization_sensitivity_reported}
- no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}
- no_parameter_fit_performed: {no_parameter_fit_performed}
- unique_renormalization_closed: {unique_renormalization_closed}
- full_PDE_mass_functional_closed: {full_PDE_mass_functional_closed}

## Gate audit

{gate_audit.to_string(index=False)}

## Functional roster

{functional_roster.to_string(index=False)}

## Seed functional preview

{roster_base[["rho", "curve_length", "bend_energy_int_kappa2_ds", "green_offdiag_density", "bend_times_offdiag_density", "finite_part_abs_all"]].to_string(index=False)}

## Regularization sensitivity

{regularization_sensitivity.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Risk register

{risk_register.to_string(index=False)}

## Next gate

BOXED: FORCE_R119 — Renormalization / Embedding-Invariance Closure Gate
"""
    (OUT / "FORCE_R118_summary.md").write_text(summary, encoding="utf-8")

    # Plots.
    write_plot_bar(roster_base, "green_offdiag_density", "R118 seed Green-kernel offdiag density", "seed_green_offdiag_density.png")
    write_plot_bar(roster_base, "bend_times_offdiag_density", "R118 seed bend x Green density", "seed_bend_times_green_density.png")
    write_plot_bar(roster_base, "finite_part_abs_all", "R118 seed finite-part absolute all-density", "seed_finite_part_abs_all.png")

    plt.figure(figsize=(10, 5))
    plt.bar(functional_roster["functional_id"], functional_roster["seed_dynamic_range_max_over_min"])
    plt.xticks(rotation=55, ha="right")
    plt.ylabel("max/min over seed")
    plt.title("R118 candidate functional dynamic ranges")
    plt.tight_layout()
    plt.savefig(PLOTS / "functional_dynamic_ranges.png", dpi=160)
    plt.close()

    # Manifest.
    manifest_rows = []
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            manifest_rows.append({
                "relative_path": str(p.relative_to(OUT)),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    pd.DataFrame(manifest_rows).to_csv(OUT / "artifact_manifest.csv", index=False)

    # Copy script into artifact directory when possible.
    try:
        shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R118_analytic_helical_self_energy_derivation_gate.py")
    except Exception:
        pass

    # Zip.
    if ZIP.exists():
        ZIP.unlink()
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.rglob("*")):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(OUT.parent)))
    with zipfile.ZipFile(ZIP, "r") as z:
        bad = z.testzip()
    zip_integrity_pass = bad is None
    verdict["zip_integrity_pass"] = zip_integrity_pass
    (OUT / "FORCE_R118_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

    # Print compact result.
    preview_cols = [
        "rho", "rho_float", "curve_length", "bend_energy_int_kappa2_ds",
        "green_offdiag_density", "bend_times_offdiag_density", "finite_part_abs_all",
    ]
    print("\n=== COPY/PASTE R118 RESULT ===")
    print("R118 COMPLETE")
    print(f"VERDICT: {verdict_status}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
    print(f"candidate_self_energy_roster_closed: {candidate_self_energy_roster_closed}")
    print(f"geometry_table_generated: {geometry_table_generated}")
    print(f"seed_all_computed: {seed_all_computed}")
    print(f"virtuals_computed_not_promoted: {virtuals_computed_not_promoted}")
    print(f"kernel_table_generated: {kernel_table_generated}")
    print(f"finite_part_generated: {finite_part_generated}")
    print(f"all_functionals_finite_positive: {all_functionals_finite_positive}")
    print(f"functional_roster_generated: {functional_roster_generated}")
    print(f"regularization_sensitivity_reported: {regularization_sensitivity_reported}")
    print(f"no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}")
    print(f"no_mass_matching_performed: {no_mass_matching_performed}")
    print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
    print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
    print(f"no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}")
    print(f"unique_renormalization_closed: {unique_renormalization_closed}")
    print(f"dynamic_GR_self_energy_closed: {dynamic_GR_self_energy_closed}")
    print(f"full_PDE_mass_functional_closed: {full_PDE_mass_functional_closed}")
    print(f"physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}")
    print(f"SM_mass_matching_claimed: {SM_mass_matching_claimed}")
    print(f"Omega0_claimed: {Omega0_claimed}")
    print(f"selected_seed: {label_set(SEED)}")
    print("AUDIT:")
    print(gate_audit.to_string(index=False))
    print("SEED_SELF_ENERGY_PREVIEW:")
    print(roster_base[preview_cols].to_string(index=False))
    print("CANDIDATE_FUNCTIONAL_ROSTER:")
    print(functional_roster.to_string(index=False))
    print("REGULARIZATION_SENSITIVITY:")
    print(regularization_sensitivity.to_string(index=False))
    print("VIRTUAL_SUPPORT_STATUS:")
    print(virtual_status.to_string(index=False))
    print("DERIVATION_AUDIT:")
    print(derivation_audit.to_string(index=False))
    print("CLAIM_BOUNDARY:")
    print(claim_boundary.to_string(index=False))
    print("RISK_REGISTER:")
    print(risk_register.to_string(index=False))
    print("NEXT_GATE_PLAN:")
    print(next_gate_plan.to_string(index=False))
    print(f"PACK: {ZIP.resolve()}")
    print(f"SUMMARY: {(OUT / 'FORCE_R118_summary.md').resolve()}")
    print("NEXT: FORCE_R119_renormalization_embedding_invariance_closure_gate")
    print("=== END COPY/PASTE R118 RESULT ===\n")


if __name__ == "__main__":
    main()
