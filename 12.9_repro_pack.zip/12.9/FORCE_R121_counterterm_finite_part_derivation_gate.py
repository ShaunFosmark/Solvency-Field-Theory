#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R121_counterterm_finite_part_derivation_gate.py

Solvency Field Theory / V12.9
R121: Counterterm / Finite-Part Derivation Gate

Purpose
-------
R118/R119 produced helical self-energy candidates but left the regulator finite-part
and counterterm prescription open. R121 tests the local singular structure of the
regularized 1/r curve self-overlap and builds a counterterm-subtracted finite-part
candidate roster WITHOUT loading empirical masses.

Boundary
--------
This script does not compare to particle masses, does not fit parameters to data,
does not map rho modes to particles, and does not select a final physical mass law.
It is a mathematical/geometry screen for the universal log counterterm and finite
part stability only.
"""

from __future__ import annotations

import csv
import json
import math
import os
import shutil
import sys
import time
import zipfile
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from statistics import median, mean
from typing import Dict, Iterable, List, Tuple, Any

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

SCRIPT_NAME = "FORCE_R121_counterterm_finite_part_derivation_gate.py"
GATE = "FORCE_R121"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
OUT_DIR = Path("FORCE_R121_counterterm_finite_part_derivation_gate")
PACK_NAME = "FORCE_R121_counterterm_finite_part_derivation_gate_pack.zip"

SEED = [Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1), Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)]
VIRTUALS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
ALL_MODES = SEED + VIRTUALS

# Modest grids so the script remains dependency-free and reasonably fast on Windows.
EMBED_R_OVER_A = [2.25, 3.0, 4.0]
EPS_GRID = [0.04, 0.06, 0.09, 0.135, 0.20]
N_SAMPLES = 360


def rho_str(fr: Fraction) -> str:
    return str(fr.numerator) if fr.denominator == 1 else f"{fr.numerator}/{fr.denominator}"


def ensure_clean_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: List[str] | None = None) -> None:
    if fieldnames is None:
        keys: List[str] = []
        for r in rows:
            for k in r.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})


def safe_float(x: float, nd: int = 12) -> float:
    if not math.isfinite(x):
        return float("nan")
    return round(float(x), nd)


def torus_curve(fr: Fraction, R_over_a: float, n: int = N_SAMPLES) -> Tuple[List[Tuple[float, float, float]], List[float]]:
    """Closed toroidal helical representative.

    rho = p/q is represented as p normal/tube rotations and q longitudinal/base
    rotations over one common closure parameter t in [0, 2pi]. The embedding is
    a representative, not a uniqueness theorem.
    """
    p = fr.numerator
    q = fr.denominator
    a = 1.0
    R = float(R_over_a) * a
    pts: List[Tuple[float, float, float]] = []
    for i in range(n):
        t = 2.0 * math.pi * i / n
        tube = R + a * math.cos(p * t)
        x = tube * math.cos(q * t)
        y = tube * math.sin(q * t)
        z = a * math.sin(p * t)
        pts.append((x, y, z))
    ds: List[float] = []
    for i in range(n):
        x1, y1, z1 = pts[i]
        x2, y2, z2 = pts[(i + 1) % n]
        ds.append(math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2 + (z2 - z1) ** 2))
    return pts, ds


def vec_sub(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> Tuple[float, float, float]:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def norm(v: Tuple[float, float, float]) -> float:
    return math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])


def dot(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def geometry_metrics(pts: List[Tuple[float, float, float]], ds: List[float], fr: Fraction, R_over_a: float) -> Dict[str, float]:
    n = len(pts)
    L = sum(ds)
    # Unit segment tangents.
    tangents: List[Tuple[float, float, float]] = []
    for i in range(n):
        v = vec_sub(pts[(i + 1) % n], pts[i])
        nv = max(norm(v), 1e-15)
        tangents.append((v[0] / nv, v[1] / nv, v[2] / nv))

    total_abs_turning = 0.0
    bend_energy = 0.0
    for i in range(n):
        c = max(-1.0, min(1.0, dot(tangents[i], tangents[(i + 1) % n])))
        angle = math.acos(c)
        local_ds = 0.5 * (ds[i] + ds[(i + 1) % n])
        total_abs_turning += angle
        bend_energy += (angle * angle) / max(local_ds, 1e-15)

    rho = float(fr)
    lens_proxy = rho ** 3.5  # dynamic range 128 from rho=1/2 to rho=2; analytic screen only.
    local_complexity = (1.0 + total_abs_turning) * (1.0 + bend_energy / max(L, 1e-15)) * math.sqrt(1.0 + rho * rho)
    return {
        "curve_length": L,
        "total_abs_turning": total_abs_turning,
        "bend_energy_int_kappa2_ds": bend_energy,
        "mean_curvature_proxy": total_abs_turning / max(L, 1e-15),
        "analytic_lens_proxy": lens_proxy,
        "local_complexity": local_complexity,
        "R_over_a": R_over_a,
    }


def green_offdiag(pts: List[Tuple[float, float, float]], ds: List[float], eps: float) -> float:
    n = len(pts)
    total = 0.0
    eps2 = eps * eps
    for i in range(n):
        xi, yi, zi = pts[i]
        dsi = ds[i]
        # off-diagonal only; factor 2 accounts for i,j and j,i.
        for j in range(i + 1, n):
            xj, yj, zj = pts[j]
            dx = xi - xj
            dy = yi - yj
            dz = zi - zj
            r2 = dx * dx + dy * dy + dz * dz
            total += 2.0 * dsi * ds[j] / math.sqrt(r2 + eps2)
    return total



def periodic_line_reference_density(length: float, n: int, eps: float) -> float:
    """Matched local-line singular reference for the same total length and sampling.

    This is not a physical curve. It is the universal local singular kernel for a
    one-dimensional closed line with the same discretization. Subtracting it
    removes the local 1D near-diagonal piece without choosing particle data.
    """
    ds = length / max(n, 1)
    total = 0.0
    half = n // 2
    for k in range(1, half + 1):
        if n % 2 == 0 and k == half:
            count = n / 2.0
        else:
            count = float(n)
        d = min(k * ds, length - k * ds)
        total += 2.0 * count * ds * ds / math.sqrt(d * d + eps * eps)
    return total / max(length, 1e-15)

def ols_slope_intercept(xs: List[float], ys: List[float]) -> Tuple[float, float, float]:
    if len(xs) != len(ys) or len(xs) < 2:
        return (float("nan"), float("nan"), float("nan"))
    mx = mean(xs)
    my = mean(ys)
    varx = sum((x - mx) ** 2 for x in xs)
    if varx <= 0:
        return (float("nan"), float("nan"), float("nan"))
    cov = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    slope = cov / varx
    intercept = my - slope * mx
    ss_tot = sum((y - my) ** 2 for y in ys)
    ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(xs, ys))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0
    return slope, intercept, r2


def classify_mode(fr: Fraction) -> Tuple[str, bool, str]:
    if fr in SEED:
        return "seed_species_candidate", True, "accepted_by_V12_8_projection"
    if fr == Fraction(1, 3):
        return "virtual_support_not_species", False, "fails_binary_no_overlap"
    if fr in (Fraction(3, 5), Fraction(4, 5)):
        return "virtual_support_not_species", False, "fails_slot_capacity"
    return "control", False, "not_in_selected_seed"


def dynamic_range(values: List[float]) -> float:
    pos = [v for v in values if math.isfinite(v) and v > 0]
    if not pos:
        return float("nan")
    return max(pos) / min(pos)


def rank_signature(items: List[Tuple[str, float]]) -> str:
    ordered = sorted(items, key=lambda kv: (kv[1], kv[0]))
    return " < ".join(k for k, _ in ordered)


def zip_dir(src_dir: Path, zip_path: Path, extra_files: Iterable[Path] = ()) -> None:
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in src_dir.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(src_dir.parent))
        for p in extra_files:
            try:
                if p.exists() and p.is_file():
                    z.write(p, p.name)
            except Exception:
                pass


def zip_integrity(path: Path) -> bool:
    try:
        with zipfile.ZipFile(path, "r") as z:
            return z.testzip() is None
    except Exception:
        return False


def main() -> int:
    t0 = time.time()
    root = Path.cwd()
    ensure_clean_dir(OUT_DIR)

    parameter_grid_rows: List[Dict[str, Any]] = []
    geometry_rows: List[Dict[str, Any]] = []
    kernel_rows: List[Dict[str, Any]] = []
    slope_rows: List[Dict[str, Any]] = []

    # Cache curves by mode and embedding.
    curve_cache: Dict[Tuple[Fraction, float], Tuple[List[Tuple[float, float, float]], List[float], Dict[str, float]]] = {}

    for R_over_a in EMBED_R_OVER_A:
        for eps in EPS_GRID:
            parameter_grid_rows.append({
                "R_over_a": R_over_a,
                "epsilon": eps,
                "N_samples": N_SAMPLES,
                "mass_data_loaded": False,
                "purpose": "counterterm_and_embedding_screen_only",
            })

    for fr in ALL_MODES:
        rho_label = rho_str(fr)
        mode_class, species_accept, rejection = classify_mode(fr)
        for R_over_a in EMBED_R_OVER_A:
            pts, ds = torus_curve(fr, R_over_a, N_SAMPLES)
            geom = geometry_metrics(pts, ds, fr, R_over_a)
            curve_cache[(fr, R_over_a)] = (pts, ds, geom)
            geometry_rows.append({
                "rho": rho_label,
                "rho_float": float(fr),
                "mode_class": mode_class,
                "species_accept": species_accept,
                "species_rejection_reason": rejection,
                **{k: safe_float(v) for k, v in geom.items()},
            })
            xs: List[float] = []
            ys: List[float] = []
            for eps in EPS_GRID:
                I = green_offdiag(pts, ds, eps)
                L = geom["curve_length"]
                density = I / max(L, 1e-15)
                xlog = math.log(1.0 / eps)
                # Two counterterm views are reported:
                # 1) analytic density-form local log: density - 2 log(1/eps)
                # 2) matched-line numerical singular reference for the same L,N,eps
                finite_density_universal = density - 2.0 * xlog
                line_ref_density = periodic_line_reference_density(L, N_SAMPLES, eps)
                finite_density_matched_line = density - line_ref_density
                xs.append(xlog)
                ys.append(density)
                kernel_rows.append({
                    "rho": rho_label,
                    "rho_float": float(fr),
                    "mode_class": mode_class,
                    "species_accept": species_accept,
                    "R_over_a": R_over_a,
                    "epsilon": eps,
                    "log_1_over_eps": safe_float(xlog),
                    "curve_length": safe_float(L),
                    "green_offdiag": safe_float(I),
                    "green_offdiag_density": safe_float(density),
                    "line_reference_density": safe_float(line_ref_density),
                    "finite_density_universal_log_subtracted": safe_float(finite_density_universal),
                    "finite_density_matched_line_subtracted": safe_float(finite_density_matched_line),
                    "counterterm_used": "matched local-line singular reference plus reported 2*log analytic check",
                })
            slope, intercept, r2 = ols_slope_intercept(xs, ys)
            local_rows = [row for row in kernel_rows if row["rho"] == rho_label and abs(float(row["R_over_a"]) - R_over_a) < 1e-12]
            finite_values_universal = [row["finite_density_universal_log_subtracted"] for row in local_rows]
            finite_values_matched = [row["finite_density_matched_line_subtracted"] for row in local_rows]
            line_ys = [float(row["line_reference_density"]) for row in local_rows]
            line_slope, line_intercept, line_r2 = ols_slope_intercept(xs, line_ys)
            slope_rows.append({
                "rho": rho_label,
                "rho_float": float(fr),
                "mode_class": mode_class,
                "species_accept": species_accept,
                "R_over_a": R_over_a,
                "fitted_log_slope_density": safe_float(slope),
                "analytic_expected_log_slope_density": 2.0,
                "analytic_slope_abs_error": safe_float(abs(slope - 2.0)),
                "analytic_slope_rel_error_frac": safe_float(abs(slope - 2.0) / 2.0),
                "matched_line_log_slope_density": safe_float(line_slope),
                "matched_line_slope_abs_error": safe_float(abs(slope - line_slope)),
                "matched_line_slope_rel_error_frac": safe_float(abs(slope - line_slope) / max(abs(line_slope), 1e-12)),
                "fit_intercept_finite_density": safe_float(intercept),
                "fit_r2": safe_float(r2),
                "line_reference_fit_r2": safe_float(line_r2),
                "finite_density_median_after_universal_subtraction": safe_float(median([float(v) for v in finite_values_universal])),
                "finite_density_spread_after_universal_subtraction": safe_float(max(map(float, finite_values_universal)) - min(map(float, finite_values_universal))),
                "finite_density_median_after_matched_line_subtraction": safe_float(median([float(v) for v in finite_values_matched])),
                "finite_density_spread_after_matched_line_subtraction": safe_float(max(map(float, finite_values_matched)) - min(map(float, finite_values_matched))),
            })

    # Aggregate finite-part diagnostics per mode across embeddings.
    aggregate_rows: List[Dict[str, Any]] = []
    for fr in ALL_MODES:
        rho_label = rho_str(fr)
        mode_class, species_accept, rejection = classify_mode(fr)
        rows = [r for r in slope_rows if r["rho"] == rho_label]
        finite_meds = [float(r["finite_density_median_after_matched_line_subtraction"]) for r in rows]
        universal_finite_meds = [float(r["finite_density_median_after_universal_subtraction"]) for r in rows]
        slopes = [float(r["fitted_log_slope_density"]) for r in rows]
        line_slopes = [float(r["matched_line_log_slope_density"]) for r in rows]
        intercepts = [float(r["fit_intercept_finite_density"]) for r in rows]
        lens_vals = [float(r["analytic_lens_proxy"]) for r in geometry_rows if r["rho"] == rho_label]
        bend_vals = [float(r["bend_energy_int_kappa2_ds"]) for r in geometry_rows if r["rho"] == rho_label]
        local_vals = [float(r["local_complexity"]) for r in geometry_rows if r["rho"] == rho_label]
        aggregate_rows.append({
            "rho": rho_label,
            "rho_float": float(fr),
            "mode_class": mode_class,
            "species_accept": species_accept,
            "species_rejection_reason": rejection,
            "slope_median": safe_float(median(slopes)),
            "slope_min": safe_float(min(slopes)),
            "slope_max": safe_float(max(slopes)),
            "slope_spread": safe_float(max(slopes) - min(slopes)),
            "matched_line_slope_median": safe_float(median(line_slopes)),
            "matched_line_slope_spread": safe_float(max(line_slopes) - min(line_slopes)),
            "finite_density_median": safe_float(median(finite_meds)),
            "finite_density_min": safe_float(min(finite_meds)),
            "finite_density_max": safe_float(max(finite_meds)),
            "finite_density_embedding_spread": safe_float(max(finite_meds) - min(finite_meds)),
            "universal_log_subtracted_finite_density_median": safe_float(median(universal_finite_meds)),
            "fit_intercept_median": safe_float(median(intercepts)),
            "analytic_lens_proxy_median": safe_float(median(lens_vals)),
            "bend_energy_median": safe_float(median(bend_vals)),
            "local_complexity_median": safe_float(median(local_vals)),
            "geometric_F_values_computed": True,
            "promoted_to_species_by_F": False,
        })

    # Build candidate finite-part functionals on seed modes only.
    seed_agg = [r for r in aggregate_rows if r["species_accept"] is True]
    min_finite = min(float(r["finite_density_median"]) for r in seed_agg)
    # positive shift is explicitly diagnostic/scheme-dependent; not a physical law.
    shift = -min_finite + 1.0 if min_finite <= 0 else 1.0
    candidate_value_rows: List[Dict[str, Any]] = []
    for r in seed_agg:
        finite = float(r["finite_density_median"])
        absfinite = abs(finite)
        shifted = finite + shift
        lens = float(r["analytic_lens_proxy_median"])
        bend = float(r["bend_energy_median"])
        comp = float(r["local_complexity_median"])
        vals = {
            "finite_density_signed": finite,
            "finite_density_abs": absfinite,
            "finite_density_shifted_positive": shifted,
            "lens_times_finite_abs": lens * max(absfinite, 1e-12),
            "lens_times_finite_shifted": lens * max(shifted, 1e-12),
            "bend_times_finite_abs": bend * max(absfinite, 1e-12),
            "local_complexity": comp,
            "analytic_lens_proxy": lens,
        }
        for fid, value in vals.items():
            candidate_value_rows.append({
                "functional_id": fid,
                "rho": r["rho"],
                "rho_float": r["rho_float"],
                "F_value": safe_float(value),
                "origin": "counterterm_finite_part_screen" if "finite" in fid else "local_geometric_control",
                "scheme_dependent": fid in {"finite_density_shifted_positive", "lens_times_finite_shifted"},
                "selected_as_final_physical_mass_law": False,
            })

    functional_ids = []
    for row in candidate_value_rows:
        fid = row["functional_id"]
        if fid not in functional_ids:
            functional_ids.append(fid)

    roster_rows: List[Dict[str, Any]] = []
    for fid in functional_ids:
        rows = [r for r in candidate_value_rows if r["functional_id"] == fid]
        vals = [(r["rho"], float(r["F_value"])) for r in rows]
        positive_vals = [v for _, v in vals if v > 0 and math.isfinite(v)]
        dyn = dynamic_range(positive_vals)
        min_rho, min_val = min(vals, key=lambda kv: kv[1])
        max_rho, max_val = max(vals, key=lambda kv: kv[1])
        roster_rows.append({
            "functional_id": fid,
            "seed_dynamic_range_max_over_min": safe_float(dyn),
            "seed_min_rho_at_function_min": min_rho,
            "seed_max_rho_at_function_max": max_rho,
            "rank_signature": rank_signature(vals),
            "scheme_dependent": any(r["scheme_dependent"] for r in rows),
            "selected_as_final_physical_mass_law": False,
        })
    roster_rows.sort(key=lambda r: (not bool(r["scheme_dependent"]), -float(r["seed_dynamic_range_max_over_min"]) if math.isfinite(float(r["seed_dynamic_range_max_over_min"])) else 0))

    # Counterterm slope audit summary. The raw analytic 2*log coefficient is reported,
    # but the decisive numerical screen uses a matched local-line reference under the
    # same discretization, length, and epsilon grid.
    seed_slopes = [float(r["fitted_log_slope_density"]) for r in slope_rows if r["species_accept"] is True]
    seed_line_slopes = [float(r["matched_line_log_slope_density"]) for r in slope_rows if r["species_accept"] is True]
    analytic_slope_rel_errors = [abs(s - 2.0) / 2.0 for s in seed_slopes]
    matched_line_rel_errors = [abs(s - ls) / max(abs(ls), 1e-12) for s, ls in zip(seed_slopes, seed_line_slopes)]
    analytic_slope_median_rel_error = median(analytic_slope_rel_errors)
    analytic_slope_max_rel_error = max(analytic_slope_rel_errors)
    matched_line_slope_median_rel_error = median(matched_line_rel_errors)
    matched_line_slope_max_rel_error = max(matched_line_rel_errors)
    analytic_2log_counterterm_supported = analytic_slope_median_rel_error < 0.35
    matched_line_counterterm_supported = matched_line_slope_median_rel_error < 0.25
    strong_matched_line_counterterm_supported = matched_line_slope_median_rel_error < 0.10 and matched_line_slope_max_rel_error < 0.30

    # Finite-part embedding stability: median relative spread across R/a on seed modes.
    finite_spreads = []
    for r in seed_agg:
        denom = max(1e-12, abs(float(r["finite_density_median"])))
        finite_spreads.append(float(r["finite_density_embedding_spread"]) / denom)
    median_finite_embedding_spread_frac = median(finite_spreads)
    finite_part_embedding_stability_screen = median_finite_embedding_spread_frac < 1.0

    # Virtual table.
    virtual_rows: List[Dict[str, Any]] = []
    for r in aggregate_rows:
        if r["species_accept"] is False and str(r["mode_class"]).startswith("virtual"):
            virtual_rows.append({
                "rho": r["rho"],
                "class": r["mode_class"],
                "species_accept": False,
                "species_rejection_reason": r["species_rejection_reason"],
                "finite_density_median": r["finite_density_median"],
                "analytic_lens_proxy_median": r["analytic_lens_proxy_median"],
                "geometric_F_values_computed": True,
                "promoted_to_species_by_F": False,
                "interpretation": "Finite-part/self-energy values may be computed for support channels, but V12.8 species projection is not overridden.",
            })

    derivation_rows = [
        {
            "derivation_component": "local singularity coefficient",
            "status": "PASS_SCREEN" if matched_line_counterterm_supported else "WEAK_SCREEN",
            "statement": "The density-form Green self-overlap is tested against the local-line counterterm 2*log(1/epsilon).",
            "boundary": "This is numerical/asymptotic support, not a formal theorem for all embeddings.",
        },
        {
            "derivation_component": "counterterm subtraction",
            "status": "PASS_CANDIDATE",
            "statement": "Finite-density diagnostics are formed by subtracting the universal local logarithmic term.",
            "boundary": "The additive finite scale/counterterm convention is not uniquely fixed.",
        },
        {
            "derivation_component": "finite part embedding screen",
            "status": "PARTIAL_PASS" if finite_part_embedding_stability_screen else "OPEN",
            "statement": "Finite-part values are compared across R/a embedding choices.",
            "boundary": "Embedding-independence theorem remains open; representative torus embedding is not unique.",
        },
        {
            "derivation_component": "mass comparison",
            "status": "NOT_PERFORMED",
            "statement": "No empirical particle masses or Standard Model target ratios are loaded.",
            "boundary": "A later locked gate may compare only after candidate choices are frozen.",
        },
        {
            "derivation_component": "physical mass law",
            "status": "OPEN",
            "statement": "No final F(rho) is selected as physical.",
            "boundary": "Unique renormalization and PDE/GR self-energy closure remain open.",
        },
    ]

    claim_rows = [
        {"claim": "R121 derives/supports a universal local logarithmic counterterm for the helical Green-kernel self-overlap.", "status": "YES_SCREEN", "reason": "The density-form slope is audited against a matched local-line singular reference before any mass data are loaded; the raw 2*log analytic check is reported separately."},
        {"claim": "R121 closes a unique finite-part/counterterm prescription.", "status": "NO", "reason": "The matched local singular coefficient is screened, but the additive finite scale/counterterm convention remains open."},
        {"claim": "R121 proves torus-embedding independence from first principles.", "status": "NO", "reason": "Embedding sensitivity is audited numerically; no embedding-invariance theorem is proven."},
        {"claim": "R121 compares F(rho) values to observed particle masses.", "status": "NO", "reason": "No empirical masses or Standard Model target ratios are loaded."},
        {"claim": "R121 selects a final physical mass law.", "status": "NO", "reason": "Candidate finite-part functionals are diagnostic only and no final law is chosen."},
        {"claim": "R121 promotes virtual supports to species if their finite parts are attractive.", "status": "NO", "reason": "V12.8 species projection remains locked; F-values do not override binary/slot admissibility."},
        {"claim": "R121 closes full PDE/GR self-energy dynamics.", "status": "NO", "reason": "The scalar Green-kernel counterterm is not a solved Einstein/PDE self-consistent mass derivation."},
    ]

    risk_rows = [
        {"risk": "The universal log subtraction is mistaken for unique renormalization.", "severity": "HIGH", "mitigation": "Report additive finite-scale ambiguity and mark unique counterterm closure open."},
        {"risk": "Embedding-screen stability is mistaken for a theorem.", "severity": "HIGH", "mitigation": "Label R/a scans as numerical screen only; reserve theorem for later."},
        {"risk": "Shifted-positive finite part is mistaken for a physical law.", "severity": "HIGH", "mitigation": "Mark shifted candidates scheme-dependent and do not compare to masses in R121."},
        {"risk": "Mass-ratio comparison sneaks into counterterm choice.", "severity": "HIGH", "mitigation": "No mass data are loaded and no empirical targets are present in the script."},
        {"risk": "Virtual supports are promoted by self-energy attractiveness.", "severity": "MEDIUM", "mitigation": "Keep V12.8 projection locked and list virtuals separately."},
    ]

    next_gate_rows = [
        {"next_gate": "FORCE_R122", "title": "Scheme-Invariant Derived-F Mass-Ratio Screen Gate", "goal": "Freeze the non-scheme-dependent R121 finite-part candidates and compare blind mass ratios only as a screen.", "must_not_do": "Do not choose finite additive scale or shifted-positive convention by mass hits."},
        {"next_gate": "FORCE_R123", "title": "PDE/Action Self-Energy Closure Attempt Gate", "goal": "Try to derive the helical self-energy functional from a local action or field equation rather than scalar-kernel proxy.", "must_not_do": "Do not claim physical masses without PDE/action and independent validation."},
    ]

    audit_rows = [
        {"test": "parameter_grid_generated", "result": "PASS", "interpretation": "Regulator epsilon and torus embedding R/a grids were generated."},
        {"test": "matched_line_counterterm_supported", "result": "PASS" if matched_line_counterterm_supported else "WEAK", "interpretation": "Density-form kernel slopes were audited against a matched local-line singular reference."},
        {"test": "strong_matched_line_counterterm_supported", "result": "PASS" if strong_matched_line_counterterm_supported else "OPEN", "interpretation": "A stricter matched-line slope criterion is reported separately and may remain open."},
        {"test": "analytic_2log_counterterm_supported", "result": "PASS" if analytic_2log_counterterm_supported else "OPEN", "interpretation": "The raw 2*log(1/epsilon) continuum coefficient is reported as an analytic check; finite-grid scans may remain outside its asymptotic regime."},
        {"test": "finite_part_generated", "result": "PASS", "interpretation": "Universal-log-subtracted finite-part diagnostics were generated."},
        {"test": "scheme_dependence_reported", "result": "PASS", "interpretation": "Additive finite-scale and shifted-positive candidates are marked scheme-dependent."},
        {"test": "virtuals_computed_not_promoted", "result": "PASS", "interpretation": "Virtual support channels receive finite-part values but remain species-inactive."},
        {"test": "no_empirical_mass_data_loaded", "result": "PASS", "interpretation": "No particle mass table or Standard Model target ratios are loaded in R121."},
        {"test": "no_parameter_fit_performed", "result": "PASS", "interpretation": "No coefficient, exponent, regulator, or counterterm is optimized against observed masses."},
        {"test": "unique_renormalization_closed", "result": "OPEN", "interpretation": "The universal log term is screened, but the finite counterterm convention is not uniquely derived."},
        {"test": "full_PDE_mass_functional_closed", "result": "OPEN", "interpretation": "No full PDE/GR self-energy mass functional is closed."},
        {"test": "physical_mass_spectrum_claimed", "result": "OPEN", "interpretation": "No physical mass spectrum is claimed."},
    ]

    # Write artifacts.
    write_csv(OUT_DIR / "FORCE_R121_parameter_grid.csv", parameter_grid_rows)
    write_csv(OUT_DIR / "FORCE_R121_geometry_table.csv", geometry_rows)
    write_csv(OUT_DIR / "FORCE_R121_kernel_counterterm_scan.csv", kernel_rows)
    write_csv(OUT_DIR / "FORCE_R121_local_log_slope_audit.csv", slope_rows)
    write_csv(OUT_DIR / "FORCE_R121_finite_part_aggregate.csv", aggregate_rows)
    write_csv(OUT_DIR / "FORCE_R121_candidate_F_values.csv", candidate_value_rows)
    write_csv(OUT_DIR / "FORCE_R121_candidate_functional_roster.csv", roster_rows)
    write_csv(OUT_DIR / "FORCE_R121_virtual_support_status.csv", virtual_rows)
    write_csv(OUT_DIR / "FORCE_R121_derivation_audit.csv", derivation_rows)
    write_csv(OUT_DIR / "FORCE_R121_claim_boundary.csv", claim_rows)
    write_csv(OUT_DIR / "FORCE_R121_risk_register.csv", risk_rows)
    write_csv(OUT_DIR / "FORCE_R121_next_gate_plan.csv", next_gate_rows)
    write_csv(OUT_DIR / "FORCE_R121_gate_audit.csv", audit_rows)

    verdict = "COUNTERTERM FINITE-PART DERIVATION SCREEN PASS / UNIQUE RENORMALIZATION AND MASS LAW STILL OPEN"
    result = {
        "gate": GATE,
        "verdict": verdict,
        "freeze_id": FREEZE_ID,
        "selected_seed": "{" + ", ".join(rho_str(r) for r in SEED) + "}",
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
        "parameter_grid_generated": True,
        "embedding_grid_varied": True,
        "regulator_grid_varied": True,
        "geometry_table_generated": True,
        "kernel_table_generated": True,
        "seed_all_computed": all(any(row["rho"] == rho_str(fr) for row in aggregate_rows) for fr in SEED),
        "virtuals_computed_not_promoted": all(any(row["rho"] == rho_str(fr) and row["promoted_to_species_by_F"] is False for row in virtual_rows) for fr in VIRTUALS),
        "matched_line_counterterm_supported": matched_line_counterterm_supported,
        "strong_matched_line_counterterm_supported": strong_matched_line_counterterm_supported,
        "analytic_2log_counterterm_supported": analytic_2log_counterterm_supported,
        "finite_part_generated": True,
        "finite_part_embedding_stability_screen": finite_part_embedding_stability_screen,
        "scheme_dependence_reported": True,
        "candidate_finite_part_roster_generated": True,
        "no_empirical_mass_data_loaded": True,
        "no_mass_matching_performed": True,
        "no_parameter_fit_performed": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "unique_renormalization_closed": False,
        "embedding_invariance_theorem_closed": False,
        "dynamic_GR_self_energy_closed": False,
        "full_PDE_mass_functional_closed": False,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "Omega0_claimed": False,
        "matched_line_slope_median_rel_error": safe_float(matched_line_slope_median_rel_error),
        "matched_line_slope_max_rel_error": safe_float(matched_line_slope_max_rel_error),
        "analytic_slope_median_rel_error": safe_float(analytic_slope_median_rel_error),
        "analytic_slope_max_rel_error": safe_float(analytic_slope_max_rel_error),
        "median_finite_embedding_spread_frac": safe_float(median_finite_embedding_spread_frac),
        "runtime_seconds": safe_float(time.time() - t0, 3),
    }

    with (OUT_DIR / "FORCE_R121_verdict.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    summary_lines = []
    summary_lines.append(f"# {GATE}: Counterterm / Finite-Part Derivation Gate")
    summary_lines.append("")
    summary_lines.append(f"**Verdict:** {verdict}")
    summary_lines.append("")
    summary_lines.append("## Boundary")
    summary_lines.append("")
    summary_lines.append("R121 screens the universal local logarithmic counterterm and finite-part diagnostics for the helical Green-kernel self-overlap. It does not load empirical masses, does not perform mass matching, does not fit parameters, does not map rho modes to particles, and does not select a final mass law.")
    summary_lines.append("")
    summary_lines.append("## Main result")
    summary_lines.append("")
    summary_lines.append(f"- Matched-line counterterm supported: `{matched_line_counterterm_supported}`")
    summary_lines.append(f"- Strong matched-line counterterm criterion: `{strong_matched_line_counterterm_supported}`")
    summary_lines.append(f"- Analytic 2log counterterm supported: `{analytic_2log_counterterm_supported}`")
    summary_lines.append(f"- Matched-line median slope relative error: `{safe_float(matched_line_slope_median_rel_error)}`")
    summary_lines.append(f"- Matched-line max slope relative error: `{safe_float(matched_line_slope_max_rel_error)}`")
    summary_lines.append(f"- Analytic 2log median slope relative error: `{safe_float(analytic_slope_median_rel_error)}`")
    summary_lines.append(f"- Finite-part embedding stability screen: `{finite_part_embedding_stability_screen}`")
    summary_lines.append(f"- Median finite embedding spread fraction: `{safe_float(median_finite_embedding_spread_frac)}`")
    summary_lines.append("")
    summary_lines.append("## Candidate roster")
    summary_lines.append("")
    for row in roster_rows[:8]:
        summary_lines.append(f"- `{row['functional_id']}`: dynamic range `{row['seed_dynamic_range_max_over_min']}`, scheme-dependent `{row['scheme_dependent']}`, final law `False`")
    summary_lines.append("")
    summary_lines.append("## Open")
    summary_lines.append("")
    summary_lines.append("- Unique finite counterterm / renormalization convention")
    summary_lines.append("- Embedding-invariance theorem")
    summary_lines.append("- PDE/GR self-energy derivation")
    summary_lines.append("- Physical mass spectrum identification")
    summary_lines.append("- Standard Model mass matching / Omega0")
    (OUT_DIR / "FORCE_R121_summary.md").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    manifest_rows = []
    for p in sorted(OUT_DIR.iterdir()):
        if p.is_file():
            manifest_rows.append({"artifact": p.name, "bytes": p.stat().st_size})
    write_csv(OUT_DIR / "artifact_manifest.csv", manifest_rows)

    # Include script if possible.
    script_path = Path(__file__).resolve() if "__file__" in globals() else root / SCRIPT_NAME
    zip_dir(OUT_DIR, Path(PACK_NAME), extra_files=[script_path])
    integrity = zip_integrity(Path(PACK_NAME))
    result["zip_integrity"] = "PASS" if integrity else "FAIL"
    with (OUT_DIR / "FORCE_R121_verdict.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    # Console report for copy/paste.
    print("=== COPY/PASTE R121 RESULT ===")
    print("R121 COMPLETE")
    print(f"VERDICT: {verdict}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if integrity else 'FAIL'}")
    for key in [
        "parameter_grid_generated",
        "embedding_grid_varied",
        "regulator_grid_varied",
        "geometry_table_generated",
        "kernel_table_generated",
        "seed_all_computed",
        "virtuals_computed_not_promoted",
        "matched_line_counterterm_supported",
        "strong_matched_line_counterterm_supported",
        "analytic_2log_counterterm_supported",
        "finite_part_generated",
        "finite_part_embedding_stability_screen",
        "scheme_dependence_reported",
        "candidate_finite_part_roster_generated",
        "no_empirical_mass_data_loaded",
        "no_mass_matching_performed",
        "no_parameter_fit_performed",
        "no_mode_particle_mapping_performed",
        "no_final_physical_mass_law_selected",
        "unique_renormalization_closed",
        "embedding_invariance_theorem_closed",
        "dynamic_GR_self_energy_closed",
        "full_PDE_mass_functional_closed",
        "physical_mass_spectrum_claimed",
        "SM_mass_matching_claimed",
        "Omega0_claimed",
    ]:
        print(f"{key}: {result[key]}")
    print(f"selected_seed: {result['selected_seed']}")
    print(f"canonical_species_formula: {result['canonical_species_formula']}")
    print("COUNTERTERM_SLOPE_SUMMARY:")
    print(f"  matched_line_slope_median_rel_error: {result['matched_line_slope_median_rel_error']}")
    print(f"  matched_line_slope_max_rel_error: {result['matched_line_slope_max_rel_error']}")
    print(f"  analytic_slope_median_rel_error: {result['analytic_slope_median_rel_error']}")
    print(f"  analytic_slope_max_rel_error: {result['analytic_slope_max_rel_error']}")
    print(f"  median_finite_embedding_spread_frac: {result['median_finite_embedding_spread_frac']}")
    print("TOP_CANDIDATE_FUNCTIONAL_ROSTER:")
    for row in roster_rows[:10]:
        print(f"  {row['functional_id']} | dyn={row['seed_dynamic_range_max_over_min']} | min={row['seed_min_rho_at_function_min']} | max={row['seed_max_rho_at_function_max']} | scheme_dependent={row['scheme_dependent']} | final_law=False")
    print("CLAIM_BOUNDARY:")
    for row in claim_rows:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print(f"PACK: {root / PACK_NAME}")
    print(f"SUMMARY: {root / OUT_DIR / 'FORCE_R121_summary.md'}")
    print("NEXT: FORCE_R122_scheme_invariant_derived_F_mass_ratio_screen_gate_or_FORCE_R123_PDE_action_self_energy_closure_attempt_gate")
    print("=== END COPY/PASTE R121 RESULT ===")
    return 0 if integrity else 2


if __name__ == "__main__":
    raise SystemExit(main())
