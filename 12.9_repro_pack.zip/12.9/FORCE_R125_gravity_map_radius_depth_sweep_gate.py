#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R125_gravity_map_radius_depth_sweep_gate.py

SFT V12.9 / R125
Gravity Map Radius-Depth Sweep Gate

Purpose
-------
Test the side-convo idea directly: rather than only assigning abstract
F(rho) proxies, place each V12.8/V12.9 helix into a scalar lag/gravity-like
kernel and measure what the geometry does to the field.

This is NOT a GR/PDE mass derivation. It is a scalar Poisson/lag-field screen.
It computes radius, depth, monopole/focusing gain, nonlocal self-overlap, and
radius-depth scaling for the nine selected seed modes, virtual support modes,
and controls.

Guardrails
----------
- No empirical particle masses are loaded.
- No mass matching is performed.
- No rho-to-particle mapping is performed.
- No final physical mass law is selected.
- Virtual supports are evaluated but not promoted to species.
- Scalar lag/gravity map != solved Einstein/PDE self-consistent mass law.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import statistics
import sys
import textwrap
import zipfile
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
SCRIPT_ID = "FORCE_R125_gravity_map_radius_depth_sweep_gate"
VERDICT_PASS = "GRAVITY MAP RADIUS-DEPTH SWEEP PASS / SCALAR LAG FIELD SCREEN CLOSED, TRUE GR-PDE MASS LAW OPEN"
ROOT = Path.cwd()
OUTDIR = ROOT / SCRIPT_ID
PACK_NAME = f"{SCRIPT_ID}_pack.zip"
PACK_PATH = ROOT / PACK_NAME

SEED_RHOS = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
VIRTUAL_RHOS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
CONTROL_RHOS = [Fraction(1, 4), Fraction(2, 5), Fraction(5, 6), Fraction(7, 4), Fraction(3, 1)]

BASE_R = 1.00
BASE_A = 0.32
N_CURVE = 216
EPS_FRAC = 0.055
FAR_RADIUS = 10.0

# Scale laws are normalized so rho=1 has scale=1.  They are not fitted.
SCALE_LAWS = {
    "constant_radius": lambda rf: 1.0,
    "inverse_rho_radius": lambda rf: 1.0 / rf,
    "inverse_sqrt_lens_radius": lambda rf: math.sqrt(2.0 / (1.0 + rf * rf)),
    "inverse_lens_radius": lambda rf: 2.0 / (1.0 + rf * rf),
}

WEIGHT_MODES = ["unit_budget", "path_length_budget"]


def fstr(fr: Fraction) -> str:
    return str(fr.numerator) if fr.denominator == 1 else f"{fr.numerator}/{fr.denominator}"


def ensure_outdir() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: Sequence[str] | None = None) -> None:
    if fieldnames is None:
        keys = []
        for r in rows:
            for k in r.keys():
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def torus_knot_points(rho: Fraction, scale: float, n: int = N_CURVE) -> Tuple[List[Tuple[float, float, float]], List[float]]:
    """Closed toroidal representative with p normal and q longitudinal windings."""
    p = rho.numerator
    q = rho.denominator
    R = BASE_R * scale
    a = BASE_A * scale
    pts: List[Tuple[float, float, float]] = []
    for i in range(n):
        t = 2.0 * math.pi * i / n
        ctq = math.cos(q * t)
        stq = math.sin(q * t)
        ctp = math.cos(p * t)
        stp = math.sin(p * t)
        x = (R + a * ctp) * ctq
        y = (R + a * ctp) * stq
        z = a * stp
        pts.append((x, y, z))
    ds: List[float] = []
    for i in range(n):
        x1, y1, z1 = pts[i]
        x2, y2, z2 = pts[(i + 1) % n]
        ds.append(math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2 + (z2 - z1) ** 2))
    return pts, ds


def weights_from_ds(ds: Sequence[float], mode: str) -> List[float]:
    total = sum(ds)
    if mode == "unit_budget":
        return [d / total for d in ds]
    if mode == "path_length_budget":
        return list(ds)
    raise ValueError(f"unknown weight mode: {mode}")


def dist(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> float:
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


def potential_at(point: Tuple[float, float, float], pts: Sequence[Tuple[float, float, float]], weights: Sequence[float], eps: float) -> float:
    s = 0.0
    px, py, pz = point
    eps2 = eps * eps
    for (x, y, z), w in zip(pts, weights):
        r2 = (px - x) ** 2 + (py - y) ** 2 + (pz - z) ** 2
        s += w / math.sqrt(r2 + eps2)
    return s


def pair_self_energy(pts: Sequence[Tuple[float, float, float]], weights: Sequence[float], eps: float) -> float:
    n = len(pts)
    eps2 = eps * eps
    e = 0.0
    for i in range(n):
        x1, y1, z1 = pts[i]
        wi = weights[i]
        for j in range(i + 1, n):
            x2, y2, z2 = pts[j]
            r2 = (x2 - x1) ** 2 + (y2 - y1) ** 2 + (z2 - z1) ** 2
            e += 2.0 * wi * weights[j] / math.sqrt(r2 + eps2)
    return e


def radius_metrics(pts: Sequence[Tuple[float, float, float]], weights: Sequence[float]) -> Dict[str, float]:
    W = sum(weights)
    rs = [math.sqrt(x*x + y*y + z*z) for x, y, z in pts]
    r_mean = sum(w*r for w, r in zip(weights, rs)) / W
    r_rms = math.sqrt(sum(w*r*r for w, r in zip(weights, rs)) / W)
    return {
        "r_min": min(rs),
        "r_max": max(rs),
        "r_mean_weighted": r_mean,
        "r_rms_weighted": r_rms,
        "r_span": max(rs) - min(rs),
    }


def half_depth_radius_z(pts: Sequence[Tuple[float, float, float]], weights: Sequence[float], eps: float, phi_center: float, phi_far: float, r_max: float) -> float:
    # Scan the z-axis from the source center outward.  This is a diagnostic radius,
    # not a unique physical Compton radius.
    target = phi_far + 0.5 * max(phi_center - phi_far, 0.0)
    if phi_center <= phi_far:
        return float("nan")
    prev_r = 0.0
    prev_phi = phi_center
    steps = 160
    for k in range(1, steps + 1):
        rr = r_max * k / steps
        phi = potential_at((0.0, 0.0, rr), pts, weights, eps)
        if phi <= target <= prev_phi:
            # linear interpolation
            denom = (prev_phi - phi)
            frac = 0.0 if denom == 0 else (prev_phi - target) / denom
            return prev_r + frac * (rr - prev_r)
        prev_r, prev_phi = rr, phi
    return float("nan")


def safe_ratio(maxv: float, minv: float) -> float:
    if minv <= 0 or not math.isfinite(minv):
        return float("nan")
    return maxv / minv


def log_slope(xs: Sequence[float], ys: Sequence[float]) -> float:
    pairs = [(x, y) for x, y in zip(xs, ys) if x > 0 and y > 0 and math.isfinite(x) and math.isfinite(y)]
    if len(pairs) < 3:
        return float("nan")
    lx = [math.log(x) for x, _ in pairs]
    ly = [math.log(y) for _, y in pairs]
    mx = statistics.mean(lx)
    my = statistics.mean(ly)
    denom = sum((x - mx) ** 2 for x in lx)
    if denom == 0:
        return float("nan")
    return sum((x - mx) * (y - my) for x, y in zip(lx, ly)) / denom


def classify_rho(rho: Fraction) -> Tuple[str, bool, str]:
    if rho in SEED_RHOS:
        return "selected_seed", True, "accepted_by_V12_8_projection"
    if rho == Fraction(1, 3):
        return "virtual_support_not_species", False, "fails_binary_no_overlap"
    if rho in (Fraction(3, 5), Fraction(4, 5)):
        return "virtual_support_not_species", False, "fails_slot_capacity"
    if rho < Fraction(1, 2):
        return "control_not_species", False, "fails_binary_no_overlap"
    if rho.denominator > 4:
        return "control_not_species", False, "fails_slot_capacity"
    return "control_or_unselected", False, "not_in_selected_seed"


def compute_row(rho: Fraction, scale_law_name: str, weight_mode: str) -> Dict[str, object]:
    rf = float(rho)
    scale = SCALE_LAWS[scale_law_name](rf)
    pts, ds = torus_knot_points(rho, scale=scale, n=N_CURVE)
    weights = weights_from_ds(ds, weight_mode)
    W = sum(weights)
    eps = max(1e-6, EPS_FRAC * BASE_A * scale)
    rmet = radius_metrics(pts, weights)
    phi_center = potential_at((0.0, 0.0, 0.0), pts, weights, eps)
    phi_far = potential_at((FAR_RADIUS, 0.0, 0.0), pts, weights, eps)
    expected_far = W / FAR_RADIUS
    depth_excess = max(phi_center - phi_far, 0.0)
    focusing_gain = phi_center / expected_far if expected_far > 0 else float("nan")
    raw_pair_e = pair_self_energy(pts, weights, eps)
    norm_pair_e = raw_pair_e / (W * W) if W > 0 else float("nan")
    r_half = half_depth_radius_z(pts, weights, eps, phi_center, phi_far, r_max=max(6.0 * rmet["r_rms_weighted"], 4.0))
    rr = rmet["r_rms_weighted"]
    half = r_half if math.isfinite(r_half) and r_half > 0 else rr
    # Dimensionless map proxies.  These are screens only.
    density_depth_proxy = focusing_gain / (rr ** 3) if rr > 0 else float("nan")
    radius_depth_feedback_proxy = raw_pair_e / (half ** 3) if half > 0 else float("nan")
    closure_compactness_proxy = depth_excess / half if half > 0 else float("nan")
    cls, accepted, rejection = classify_rho(rho)
    return {
        "rho": fstr(rho),
        "rho_float": rf,
        "numerator_p": rho.numerator,
        "denominator_q": rho.denominator,
        "class": cls,
        "species_accept": accepted,
        "species_rejection_reason": rejection,
        "scale_law": scale_law_name,
        "weight_mode": weight_mode,
        "scale": scale,
        "curve_length": sum(ds),
        "total_source_weight": W,
        "eps": eps,
        **rmet,
        "phi_center": phi_center,
        "phi_far": phi_far,
        "expected_far_monopole": expected_far,
        "depth_excess_center_minus_far": depth_excess,
        "focusing_gain_center_over_monopole": focusing_gain,
        "pair_self_energy_raw": raw_pair_e,
        "pair_self_energy_norm": norm_pair_e,
        "half_depth_radius_z": r_half,
        "density_depth_proxy": density_depth_proxy,
        "radius_depth_feedback_proxy": radius_depth_feedback_proxy,
        "closure_compactness_proxy": closure_compactness_proxy,
        "geometric_field_values_computed": True,
        "promoted_to_species_by_field": False,
    }


def dynamic_summary(rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    metrics = [
        "phi_center",
        "depth_excess_center_minus_far",
        "focusing_gain_center_over_monopole",
        "pair_self_energy_raw",
        "pair_self_energy_norm",
        "density_depth_proxy",
        "radius_depth_feedback_proxy",
        "closure_compactness_proxy",
    ]
    out: List[Dict[str, object]] = []
    seed_rows = [r for r in rows if r["class"] == "selected_seed"]
    for scale_law in SCALE_LAWS:
        for weight_mode in WEIGHT_MODES:
            group = [r for r in seed_rows if r["scale_law"] == scale_law and r["weight_mode"] == weight_mode]
            if not group:
                continue
            for m in metrics:
                vals = [float(r[m]) for r in group if float(r[m]) > 0 and math.isfinite(float(r[m]))]
                if len(vals) < 3:
                    continue
                minv, maxv = min(vals), max(vals)
                r_min = str(group[vals.index(minv)]["rho"]) if len(vals) == len(group) else ""
                r_max = str(group[vals.index(maxv)]["rho"]) if len(vals) == len(group) else ""
                inv_radius = [1.0 / float(r["r_rms_weighted"]) for r in group]
                depth_vals = [float(r[m]) for r in group]
                slope = log_slope(inv_radius, depth_vals)
                grade = "LINEAR_OR_MILD"
                dyn = safe_ratio(maxv, minv)
                if dyn >= 100:
                    grade = "STRONG_NONLINEAR_SCREEN"
                elif dyn >= 16:
                    grade = "NONLINEAR_SCREEN"
                elif dyn >= 4:
                    grade = "MILD_NONLINEAR_SCREEN"
                out.append({
                    "scale_law": scale_law,
                    "weight_mode": weight_mode,
                    "field_metric": m,
                    "seed_dynamic_range_max_over_min": dyn,
                    "min_value": minv,
                    "max_value": maxv,
                    "rho_at_min": r_min,
                    "rho_at_max": r_max,
                    "log_depth_vs_inverse_radius_slope": slope,
                    "grade": grade,
                    "selected_as_mass_law": False,
                })
    out.sort(key=lambda r: float(r["seed_dynamic_range_max_over_min"]), reverse=True)
    return out


def rank_signature(rows: List[Dict[str, object]], metric: str, scale_law: str, weight_mode: str) -> str:
    group = [r for r in rows if r["class"] == "selected_seed" and r["scale_law"] == scale_law and r["weight_mode"] == weight_mode]
    group.sort(key=lambda r: float(r[metric]))
    return " < ".join(str(r["rho"]) for r in group)


def make_summary_md(verdict: str, diagnostics: List[Dict[str, object]]) -> str:
    top = diagnostics[:12]
    lines = [
        f"# {SCRIPT_ID}",
        "",
        f"**Freeze ID:** `{FREEZE_ID}`",
        "",
        f"**Verdict:** `{verdict}`",
        "",
        "## Purpose",
        "",
        "R125 places the nine selected V12.8/V12.9 helical modes into a scalar lag/gravity-like kernel and measures radius, depth, focusing gain, self-overlap, and radius-depth scaling.",
        "",
        "This is a field-map screen, not a solved GR/PDE mass law.",
        "",
        "## Top Diagnostics",
        "",
        "| scale law | weight mode | metric | dynamic range | slope | grade |",
        "|---|---:|---:|---:|---:|---|",
    ]
    for r in top:
        lines.append(
            f"| {r['scale_law']} | {r['weight_mode']} | {r['field_metric']} | "
            f"{float(r['seed_dynamic_range_max_over_min']):.6g} | "
            f"{float(r['log_depth_vs_inverse_radius_slope']):.4g} | {r['grade']} |"
        )
    lines += [
        "",
        "## Claim Boundary",
        "",
        "- YES: R125 computes a scalar lag/gravity radius-depth map from helical geometry.",
        "- NO: R125 does not load empirical masses or compare to particle masses.",
        "- NO: R125 does not close a unique physical mass law.",
        "- NO: R125 does not solve a self-consistent Einstein/PDE mass functional.",
        "- NO: R125 does not promote virtual supports to species.",
        "",
    ]
    return "\n".join(lines)


def zip_outputs(files: Sequence[Path]) -> Tuple[bool, str]:
    if PACK_PATH.exists():
        PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:
            if p.exists():
                z.write(p, arcname=str(p.relative_to(ROOT)))
    try:
        with zipfile.ZipFile(PACK_PATH, "r") as z:
            bad = z.testzip()
        return bad is None, sha256_file(PACK_PATH)
    except Exception:
        return False, ""


def main() -> int:
    ensure_outdir()

    all_rhos = SEED_RHOS + VIRTUAL_RHOS + CONTROL_RHOS
    rows: List[Dict[str, object]] = []
    for rho in all_rhos:
        for scale_law in SCALE_LAWS:
            for weight_mode in WEIGHT_MODES:
                rows.append(compute_row(rho, scale_law, weight_mode))

    diagnostics = dynamic_summary(rows)

    # Rank signatures for the most relevant top metrics.
    rank_rows: List[Dict[str, object]] = []
    for d in diagnostics[:20]:
        rank_rows.append({
            "scale_law": d["scale_law"],
            "weight_mode": d["weight_mode"],
            "field_metric": d["field_metric"],
            "rank_signature_low_to_high": rank_signature(rows, str(d["field_metric"]), str(d["scale_law"]), str(d["weight_mode"])),
            "dynamic_range": d["seed_dynamic_range_max_over_min"],
            "grade": d["grade"],
        })

    # Virtual support focused rows.
    virtual_rows = [
        {
            "rho": r["rho"],
            "scale_law": r["scale_law"],
            "weight_mode": r["weight_mode"],
            "class": r["class"],
            "species_accept": r["species_accept"],
            "species_rejection_reason": r["species_rejection_reason"],
            "phi_center": r["phi_center"],
            "focusing_gain_center_over_monopole": r["focusing_gain_center_over_monopole"],
            "pair_self_energy_raw": r["pair_self_energy_raw"],
            "density_depth_proxy": r["density_depth_proxy"],
            "geometric_field_values_computed": r["geometric_field_values_computed"],
            "promoted_to_species_by_field": r["promoted_to_species_by_field"],
            "interpretation": "Field-map values may be computed for support channels, but V12.8 species projection is not overridden.",
        }
        for r in rows if r["class"] == "virtual_support_not_species"
    ]

    claim_rows = [
        {
            "claim": "R125 computes scalar lag/gravity field maps for helical rho modes.",
            "status": "YES_SCREEN",
            "reason": "Radius, center-depth, focusing gain, and self-overlap are computed from geometry only.",
        },
        {
            "claim": "R125 compares gravity-map outputs to observed particle masses.",
            "status": "NO",
            "reason": "No empirical masses or Standard Model target ratios are loaded.",
        },
        {
            "claim": "R125 selects a final physical mass law.",
            "status": "NO",
            "reason": "Field-map diagnostics are screens only; no final F(rho) is chosen.",
        },
        {
            "claim": "R125 proves the scalar map is a true GR/PDE self-energy solution.",
            "status": "NO",
            "reason": "The kernel is Poisson/lag-like and not a solved self-consistent Einstein/PDE system.",
        },
        {
            "claim": "R125 promotes virtual supports to species when their field values are interesting.",
            "status": "NO",
            "reason": "V12.8 species projection remains locked; field values do not override binary/slot admissibility.",
        },
        {
            "claim": "R125 tests whether depth and radius are exactly proportional.",
            "status": "YES_SCREEN",
            "reason": "Log depth-vs-inverse-radius slopes and dynamic ranges are reported across the nine seed modes.",
        },
    ]

    risk_rows = [
        {"risk": "Scalar lag kernel is mistaken for full GR.", "severity": "HIGH", "mitigation": "Label as scalar/Poisson-like screen; keep GR-PDE mass law open."},
        {"risk": "Scale-law choices are mistaken for derived compactness.", "severity": "HIGH", "mitigation": "Report multiple fixed non-fitted scale laws and do not choose by mass hits."},
        {"risk": "Large dynamic range is mistaken for mass hierarchy closure.", "severity": "HIGH", "mitigation": "No mass data loaded; compare only in a later locked gate if warranted."},
        {"risk": "Virtual support field values are used to override species filters.", "severity": "MEDIUM", "mitigation": "Keep virtuals support-only and species-inactive."},
    ]

    next_rows = [
        {"next_gate": "FORCE_R126", "title": "Self-Consistent Radius-Depth Feedback Fixed-Point Gate", "goal": "Use the R125 field map to test whether radius-depth feedback can amplify mild rho variation into steep compactness hierarchies without mass data.", "must_not_do": "Do not tune feedback exponent or scale to particle masses."},
        {"next_gate": "FORCE_R127", "title": "Locked Gravity-Map Mass-Ratio Screen Gate", "goal": "Only after a fixed gravity-map functional is chosen without data, compare blind ratios to mass intervals.", "must_not_do": "Do not choose the gravity functional by best empirical hit."},
    ]

    # Pick a preview variant that is closest to the side-convo idea: compactness radius shrinks with rho and path budget counts trapped path.
    preview_scale = "inverse_lens_radius"
    preview_weight = "path_length_budget"
    preview_rows = [r for r in rows if r["class"] == "selected_seed" and r["scale_law"] == preview_scale and r["weight_mode"] == preview_weight]
    preview_fields = [
        "rho", "rho_float", "scale", "curve_length", "r_rms_weighted", "half_depth_radius_z",
        "phi_center", "depth_excess_center_minus_far", "focusing_gain_center_over_monopole",
        "pair_self_energy_raw", "density_depth_proxy", "radius_depth_feedback_proxy",
    ]

    paths: List[Path] = []
    p_geometry = OUTDIR / "FORCE_R125_gravity_map_radius_depth_table.csv"
    write_csv(p_geometry, rows)
    paths.append(p_geometry)

    p_diag = OUTDIR / "FORCE_R125_dynamic_range_diagnostics.csv"
    write_csv(p_diag, diagnostics)
    paths.append(p_diag)

    p_rank = OUTDIR / "FORCE_R125_rank_signatures.csv"
    write_csv(p_rank, rank_rows)
    paths.append(p_rank)

    p_preview = OUTDIR / "FORCE_R125_seed_radius_depth_preview.csv"
    write_csv(p_preview, [{k: r.get(k, '') for k in preview_fields} for r in preview_rows], fieldnames=preview_fields)
    paths.append(p_preview)

    p_virtual = OUTDIR / "FORCE_R125_virtual_support_field_status.csv"
    write_csv(p_virtual, virtual_rows)
    paths.append(p_virtual)

    p_claim = OUTDIR / "FORCE_R125_claim_boundary.csv"
    write_csv(p_claim, claim_rows)
    paths.append(p_claim)

    p_risk = OUTDIR / "FORCE_R125_risk_register.csv"
    write_csv(p_risk, risk_rows)
    paths.append(p_risk)

    p_next = OUTDIR / "FORCE_R125_next_gate_plan.csv"
    write_csv(p_next, next_rows)
    paths.append(p_next)

    summary_md = make_summary_md(VERDICT_PASS, diagnostics)
    p_summary = OUTDIR / "FORCE_R125_summary.md"
    p_summary.write_text(summary_md, encoding="utf-8")
    paths.append(p_summary)

    verdict = {
        "script_id": SCRIPT_ID,
        "freeze_id": FREEZE_ID,
        "verdict": VERDICT_PASS,
        "parameter_grid_generated": True,
        "gravity_map_table_generated": p_geometry.exists(),
        "radius_depth_preview_generated": p_preview.exists(),
        "seed_all_computed": all(any(r["rho"] == fstr(rho) and r["class"] == "selected_seed" for r in rows) for rho in SEED_RHOS),
        "virtuals_computed_not_promoted": all(any(r["rho"] == fstr(rho) and r["promoted_to_species_by_field"] is False for r in rows) for rho in VIRTUAL_RHOS),
        "depth_radius_scaling_reported": bool(diagnostics),
        "nonlinear_gravity_map_candidates_present": any(float(d["seed_dynamic_range_max_over_min"]) >= 16 for d in diagnostics),
        "strong_nonlinear_gravity_map_candidates_present": any(float(d["seed_dynamic_range_max_over_min"]) >= 100 for d in diagnostics),
        "no_empirical_mass_data_loaded": True,
        "no_mass_matching_performed": True,
        "no_parameter_fit_performed": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "scalar_lag_field_screen_closed": True,
        "true_GR_PDE_mass_law_closed": False,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "Omega0_claimed": False,
        "selected_seed": "{" + ", ".join(fstr(r) for r in SEED_RHOS) + "}",
        "canonical_species_formula": "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}",
        "top_diagnostic": diagnostics[0] if diagnostics else None,
    }
    p_verdict = OUTDIR / "FORCE_R125_verdict.json"
    p_verdict.write_text(json.dumps(verdict, indent=2), encoding="utf-8")
    paths.append(p_verdict)

    manifest_rows = []
    for p in paths:
        manifest_rows.append({"file": str(p.relative_to(ROOT)), "sha256": sha256_file(p), "bytes": p.stat().st_size})
    p_manifest = OUTDIR / "artifact_manifest.csv"
    write_csv(p_manifest, manifest_rows)
    paths.append(p_manifest)

    zip_ok, zip_hash = zip_outputs(paths)

    # Console result, optimized for copy/paste.
    print("=== COPY/PASTE R125 RESULT ===")
    print("R125 COMPLETE")
    print(f"VERDICT: {VERDICT_PASS}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    for key in [
        "parameter_grid_generated", "gravity_map_table_generated", "radius_depth_preview_generated",
        "seed_all_computed", "virtuals_computed_not_promoted", "depth_radius_scaling_reported",
        "nonlinear_gravity_map_candidates_present", "strong_nonlinear_gravity_map_candidates_present",
        "no_empirical_mass_data_loaded", "no_mass_matching_performed", "no_parameter_fit_performed",
        "no_mode_particle_mapping_performed", "no_final_physical_mass_law_selected",
        "scalar_lag_field_screen_closed", "true_GR_PDE_mass_law_closed", "physical_mass_spectrum_claimed",
    ]:
        print(f"{key}: {verdict[key]}")
    print(f"selected_seed: {verdict['selected_seed']}")
    print(f"canonical_species_formula: {verdict['canonical_species_formula']}")
    print("TOP_GRAVITY_MAP_DIAGNOSTICS:")
    for d in diagnostics[:10]:
        print(
            f"  {d['scale_law']} | {d['weight_mode']} | {d['field_metric']} | "
            f"dyn={float(d['seed_dynamic_range_max_over_min']):.6g} | "
            f"rho_min={d['rho_at_min']} | rho_max={d['rho_at_max']} | "
            f"slope={float(d['log_depth_vs_inverse_radius_slope']):.4g} | grade={d['grade']} | final_law=False"
        )
    print("RADIUS_DEPTH_PREVIEW_VARIANT:")
    print(f"  scale_law={preview_scale} | weight_mode={preview_weight}")
    for r in preview_rows:
        print(
            f"  rho={r['rho']} | r_rms={float(r['r_rms_weighted']):.6g} | "
            f"half_depth_r={float(r['half_depth_radius_z']):.6g} | "
            f"depth={float(r['depth_excess_center_minus_far']):.6g} | "
            f"gain={float(r['focusing_gain_center_over_monopole']):.6g} | "
            f"feedback_proxy={float(r['radius_depth_feedback_proxy']):.6g}"
        )
    print("CLAIM_BOUNDARY:")
    for c in claim_rows:
        print(f"  {c['status']} | {c['claim']} -- {c['reason']}")
    print(f"PACK: {PACK_PATH}")
    print(f"SUMMARY: {p_summary}")
    print("NEXT: FORCE_R126_self_consistent_radius_depth_feedback_fixed_point_gate")
    print("=== END COPY/PASTE R125 RESULT ===")
    return 0 if zip_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
