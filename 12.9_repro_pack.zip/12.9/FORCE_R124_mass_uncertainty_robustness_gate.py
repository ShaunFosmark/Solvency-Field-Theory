#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R124_mass_uncertainty_robustness_gate.py

SFT V12.9 / FORCE_R124
Mass-Uncertainty Robustness Gate

Purpose
-------
R122 found scheme-clean pairwise mass-ratio screen hits, but many involve quark
masses, which are screening-only and scheme/scale dependent. R124 tests whether
those hits survive uncertainty/range scanning.

Strict protocol
---------------
1. Load or reconstruct the already-frozen R122 scheme-clean F(rho) candidate table.
2. Hash/freeze those candidate values before any mass uncertainty table is used.
3. Load compact charged-fermion uncertainty/range intervals only after freeze.
4. Compare frozen F-ratios to mass-ratio intervals.
5. Do not retune, refit, remap, or select a final physical mass law.

This is a robustness screen, not a mass derivation.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import shutil
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
GATE_ID = "FORCE_R124"
GATE_TITLE = "Mass-Uncertainty Robustness Gate"
VERDICT_PASS = "MASS-UNCERTAINTY ROBUSTNESS SCREEN PASS / ROBUSTNESS REPORTED, FULL MASS LAW NOT CLOSED"
ROOT = Path.cwd()
OUTDIR = ROOT / "FORCE_R124_mass_uncertainty_robustness_gate"
PACK_PATH = ROOT / "FORCE_R124_mass_uncertainty_robustness_gate_pack.zip"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]
PRIMARY_FUNCTIONALS = [
    "lens_times_finite_abs",
    "bend_times_finite_abs",
    "analytic_lens_proxy",
    "finite_density_abs",
    "finite_density_signed_abs_screen",
    "local_complexity",
    "total_abs_turning",
    "curve_length",
]

# Compact uncertainty/range table in MeV. Leptons are narrow; quark ranges are
# intentionally broader screening intervals to reflect scheme/scale caution.
MASS_INTERVAL_TABLE = [
    {"particle": "electron", "sector": "charged_lepton", "nominal_MeV": 0.510998950, "min_MeV": 0.510998949, "max_MeV": 0.510998951, "range_note": "precision lepton screening interval"},
    {"particle": "muon", "sector": "charged_lepton", "nominal_MeV": 105.6583755, "min_MeV": 105.6583740, "max_MeV": 105.6583770, "range_note": "precision lepton screening interval"},
    {"particle": "tau", "sector": "charged_lepton", "nominal_MeV": 1776.86, "min_MeV": 1776.74, "max_MeV": 1776.98, "range_note": "lepton screening interval"},
    {"particle": "up_quark", "sector": "quark", "nominal_MeV": 2.16, "min_MeV": 1.76, "max_MeV": 2.56, "range_note": "broad quark screening interval; scheme/scale dependent"},
    {"particle": "down_quark", "sector": "quark", "nominal_MeV": 4.67, "min_MeV": 4.07, "max_MeV": 5.27, "range_note": "broad quark screening interval; scheme/scale dependent"},
    {"particle": "strange_quark", "sector": "quark", "nominal_MeV": 93.4, "min_MeV": 87.0, "max_MeV": 99.0, "range_note": "broad quark screening interval; scheme/scale dependent"},
    {"particle": "charm_quark", "sector": "quark", "nominal_MeV": 1270.0, "min_MeV": 1240.0, "max_MeV": 1300.0, "range_note": "broad quark screening interval; scheme/scale dependent"},
    {"particle": "bottom_quark", "sector": "quark", "nominal_MeV": 4180.0, "min_MeV": 4130.0, "max_MeV": 4230.0, "range_note": "broad quark screening interval; scheme/scale dependent"},
    {"particle": "top_quark", "sector": "quark", "nominal_MeV": 172570.0, "min_MeV": 172270.0, "max_MeV": 172870.0, "range_note": "top screening interval"},
]


def frac_s(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def parse_frac(s: str) -> Fraction:
    s = str(s).strip()
    if "/" in s:
        a, b = s.split("/", 1)
        return Fraction(int(a), int(b))
    return Fraction(int(s), 1)


def ffmt(x: float, digits: int = 6) -> str:
    if not math.isfinite(x):
        return str(x)
    if x == 0:
        return "0"
    ax = abs(x)
    if ax >= 100000 or ax < 0.0001:
        return f"{x:.{digits}e}"
    return f"{x:.{digits}g}"


def write_csv(path: Path, rows: List[dict], fieldnames: List[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_ratio(a: float, b: float) -> float:
    if a <= 0 or b <= 0:
        return float("nan")
    r = a / b
    return r if r >= 1 else 1 / r


def percent_error(a: float, b: float) -> float:
    if a <= 0 or b <= 0:
        return float("nan")
    return abs(math.log(a / b)) * 100.0


def interval_ratio_ge1(row_a: dict, row_b: dict) -> Tuple[float, float, float]:
    # Returns nominal, min_possible, max_possible for ge-1 ratio over endpoint intervals.
    nom = safe_ratio(float(row_a["nominal_MeV"]), float(row_b["nominal_MeV"]))
    vals = []
    for ma, mb in product([float(row_a["min_MeV"]), float(row_a["max_MeV"])], [float(row_b["min_MeV"]), float(row_b["max_MeV"])]):
        vals.append(safe_ratio(ma, mb))
    return nom, min(vals), max(vals)


def interval_distance_ratio(F: float, lo: float, hi: float) -> float:
    # Log-distance of F from interval [lo, hi], zero if inside.
    if lo <= F <= hi:
        return 0.0
    if F < lo:
        return abs(math.log(F / lo))
    return abs(math.log(F / hi))


def lens_proxy(r: Fraction) -> float:
    return (float(r) / 0.5) ** 3.5


def finite_abs_component(r: Fraction) -> float:
    table = {
        Fraction(1, 2): 1.00,
        Fraction(2, 3): 1.10,
        Fraction(3, 4): 1.20,
        Fraction(1, 1): 1.30,
        Fraction(5, 4): 2.00,
        Fraction(4, 3): 2.10,
        Fraction(3, 2): 0.963,
        Fraction(5, 3): 2.78,
        Fraction(2, 1): 1.20,
    }
    return table[r]


def bend_energy_proxy(r: Fraction) -> float:
    x = float(r)
    q = r.denominator
    p = r.numerator
    closure_cost = 1.0 + 0.10 * (q - 1) + 0.025 * max(p - q, 0)
    return (1.0 + x * x + (x - 1.0) ** 2) * closure_cost


def local_complexity_proxy(r: Fraction) -> float:
    x = float(r)
    p, q = r.numerator, r.denominator
    winding_load = 1.0 + abs(x - 1.0) + 0.55 * x * x
    closure_ports = 1.0 + 0.18 * (q - 1) + 0.10 * max(p - q, 0)
    return winding_load * closure_ports


def total_abs_turning_proxy(r: Fraction) -> float:
    x = float(r)
    return 1.0 + x + abs(x - 1.0)


def curve_length_proxy(r: Fraction) -> float:
    return r.denominator * math.sqrt(1.0 + float(r) ** 2)


def fallback_candidate_rows() -> List[dict]:
    rows = []
    finite = {r: finite_abs_component(r) for r in SEED}
    lens = {r: lens_proxy(r) for r in SEED}
    bend = {r: bend_energy_proxy(r) for r in SEED}
    local = {r: local_complexity_proxy(r) for r in SEED}
    turn = {r: total_abs_turning_proxy(r) for r in SEED}
    curve = {r: curve_length_proxy(r) for r in SEED}
    values = {
        "lens_times_finite_abs": {r: lens[r] * finite[r] for r in SEED},
        "bend_times_finite_abs": {r: bend[r] * finite[r] ** 2 for r in SEED},
        "analytic_lens_proxy": lens,
        "finite_density_abs": {r: finite[r] ** 2 for r in SEED},
        "finite_density_signed_abs_screen": {r: finite[r] ** 2 for r in SEED},
        "local_complexity": local,
        "total_abs_turning": turn,
        "curve_length": curve,
    }
    for fid, vmap in values.items():
        dyn = max(vmap.values()) / min(vmap.values())
        for r in SEED:
            rows.append({
                "functional_id": fid,
                "rho": frac_s(r),
                "rho_float": float(r),
                "F_value": vmap[r],
                "scheme_dependent": False,
                "primary_screen": True,
                "candidate_origin": "R124 fallback reconstruction from scheme-clean R122/R121 formulas",
                "seed_dynamic_range_max_over_min": dyn if r == SEED[0] else "",
                "selected_as_final_physical_mass_law": False,
            })
    return rows


def find_r122_candidate_csv() -> Path | None:
    candidates = [
        ROOT / "FORCE_R122_scheme_invariant_derived_F_mass_ratio_screen_gate" / "FORCE_R122_scheme_invariant_candidate_values_FROZEN.csv",
        ROOT / "FORCE_R122_scheme_invariant_candidate_values_FROZEN.csv",
    ]
    for c in candidates:
        if c.exists():
            return c
    for path in ROOT.rglob("FORCE_R122_scheme_invariant_candidate_values_FROZEN.csv"):
        return path
    return None


def load_candidate_rows() -> Tuple[List[dict], str, str]:
    src = find_r122_candidate_csv()
    if src is not None:
        rows = []
        with src.open("r", newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("functional_id") in PRIMARY_FUNCTIONALS and str(row.get("rho")) in {frac_s(x) for x in SEED}:
                    row["F_value"] = float(row["F_value"])
                    row["rho_float"] = float(row.get("rho_float", float(parse_frac(row["rho"]))))
                    rows.append(row)
        if rows:
            return rows, "loaded_from_R122_frozen_csv", str(src)
    return fallback_candidate_rows(), "fallback_reconstructed", "internal_fallback"


def main() -> int:
    if OUTDIR.exists():
        shutil.rmtree(OUTDIR)
    OUTDIR.mkdir(parents=True, exist_ok=True)

    candidate_rows, candidate_source_status, candidate_source_path = load_candidate_rows()
    candidate_freeze_path = OUTDIR / "FORCE_R124_candidate_values_FROZEN_BEFORE_MASS_INTERVALS.csv"
    write_csv(candidate_freeze_path, candidate_rows)
    candidate_freeze_hash = sha256_file(candidate_freeze_path)
    (OUTDIR / "FORCE_R124_candidate_freeze_hash.txt").write_text(candidate_freeze_hash + "\n", encoding="utf-8")

    # Only now write/load the uncertainty table.
    mass_path = OUTDIR / "FORCE_R124_charged_fermion_mass_uncertainty_table_LOADED_AFTER_FREEZE.csv"
    write_csv(mass_path, MASS_INTERVAL_TABLE)

    mass_pair_rows: List[dict] = []
    for a, b in combinations(MASS_INTERVAL_TABLE, 2):
        nom, lo, hi = interval_ratio_ge1(a, b)
        sectors = {a["sector"], b["sector"]}
        mass_pair_rows.append({
            "particle_pair": f"{a['particle']} vs {b['particle']}",
            "particle_a": a["particle"],
            "particle_b": b["particle"],
            "sector_a": a["sector"],
            "sector_b": b["sector"],
            "same_sector": a["sector"] == b["sector"],
            "lepton_lepton": a["sector"] == b["sector"] == "charged_lepton",
            "quark_quark": a["sector"] == b["sector"] == "quark",
            "mass_ratio_nominal_ge_1": nom,
            "mass_ratio_min_ge_1": lo,
            "mass_ratio_max_ge_1": hi,
            "interval_log_width": math.log(hi / lo) if lo > 0 else float("nan"),
            "uncertainty_note": "quark_range_present" if "quark" in sectors else "precision_lepton_range",
        })
    write_csv(OUTDIR / "FORCE_R124_mass_ratio_uncertainty_intervals.csv", mass_pair_rows)

    # Build functional pair ratios.
    by_func: Dict[str, Dict[Fraction, float]] = {}
    for row in candidate_rows:
        by_func.setdefault(row["functional_id"], {})[parse_frac(row["rho"])] = float(row["F_value"])

    f_pair_rows: List[dict] = []
    for fid, fmap in by_func.items():
        for r1, r2 in combinations(SEED, 2):
            if r1 not in fmap or r2 not in fmap:
                continue
            ratio = safe_ratio(fmap[r1], fmap[r2])
            f_pair_rows.append({
                "functional_id": fid,
                "rho_pair": f"{frac_s(r1)} vs {frac_s(r2)}",
                "rho_a": frac_s(r1),
                "rho_b": frac_s(r2),
                "F_ratio_ge_1": ratio,
            })
    write_csv(OUTDIR / "FORCE_R124_functional_pairwise_ratios.csv", f_pair_rows)

    comparison_rows: List[dict] = []
    for fr in f_pair_rows:
        F = float(fr["F_ratio_ge_1"])
        for mr in mass_pair_rows:
            nom = float(mr["mass_ratio_nominal_ge_1"])
            lo = float(mr["mass_ratio_min_ge_1"])
            hi = float(mr["mass_ratio_max_ge_1"])
            err_nom = percent_error(F, nom)
            dist_interval = interval_distance_ratio(F, lo, hi)
            comparison_rows.append({
                **fr,
                **{k: mr[k] for k in ["particle_pair", "particle_a", "particle_b", "sector_a", "sector_b", "same_sector", "lepton_lepton", "quark_quark", "mass_ratio_nominal_ge_1", "mass_ratio_min_ge_1", "mass_ratio_max_ge_1", "uncertainty_note"]},
                "nominal_percent_log_error": err_nom,
                "inside_mass_uncertainty_interval": lo <= F <= hi,
                "distance_to_interval_percent_log": dist_interval * 100.0,
                "robust_within_1pct_interval": dist_interval <= math.log(1.01),
                "robust_within_5pct_interval": dist_interval <= math.log(1.05),
                "nominal_within_1pct": err_nom <= math.log(1.01) * 100.0,
                "nominal_within_5pct": err_nom <= math.log(1.05) * 100.0,
            })
    write_csv(OUTDIR / "FORCE_R124_uncertainty_comparison_all.csv", comparison_rows)

    robust_rows = [r for r in comparison_rows if r["robust_within_5pct_interval"]]
    robust_rows_sorted = sorted(robust_rows, key=lambda r: (float(r["distance_to_interval_percent_log"]), float(r["nominal_percent_log_error"])))
    write_csv(OUTDIR / "FORCE_R124_robust_hits_le_5pct_interval.csv", robust_rows_sorted[:250])

    threshold_summary: List[dict] = []
    for fid, fmap in by_func.items():
        subset = [r for r in comparison_rows if r["functional_id"] == fid]
        if not subset:
            continue
        fvals = [float(v) for v in fmap.values()]
        threshold_summary.append({
            "functional_id": fid,
            "F_dynamic_range_max_over_min": max(fvals) / min(fvals),
            "best_nominal_percent_log_error": min(float(r["nominal_percent_log_error"]) for r in subset),
            "best_interval_distance_percent_log": min(float(r["distance_to_interval_percent_log"]) for r in subset),
            "inside_interval_hits": sum(1 for r in subset if r["inside_mass_uncertainty_interval"]),
            "robust_hits_le_1pct_interval": sum(1 for r in subset if r["robust_within_1pct_interval"]),
            "robust_hits_le_5pct_interval": sum(1 for r in subset if r["robust_within_5pct_interval"]),
            "same_sector_robust_hits_le_5pct": sum(1 for r in subset if r["same_sector"] and r["robust_within_5pct_interval"]),
            "lepton_lepton_robust_hits_le_5pct": sum(1 for r in subset if r["lepton_lepton"] and r["robust_within_5pct_interval"]),
            "quark_quark_robust_hits_le_5pct": sum(1 for r in subset if r["quark_quark"] and r["robust_within_5pct_interval"]),
            "multiple_comparison_warning": "HIGH",
            "selected_as_final_physical_mass_law": False,
        })
    threshold_summary = sorted(threshold_summary, key=lambda r: (-(r["same_sector_robust_hits_le_5pct"]), -(r["robust_hits_le_5pct_interval"]), r["best_interval_distance_percent_log"]))
    write_csv(OUTDIR / "FORCE_R124_threshold_summary.csv", threshold_summary)

    top_by_functional = []
    for fid in by_func:
        subset = [r for r in comparison_rows if r["functional_id"] == fid]
        if subset:
            best = min(subset, key=lambda r: (float(r["distance_to_interval_percent_log"]), float(r["nominal_percent_log_error"])))
            top_by_functional.append(best)
    top_by_functional = sorted(top_by_functional, key=lambda r: (float(r["distance_to_interval_percent_log"]), float(r["nominal_percent_log_error"])))
    write_csv(OUTDIR / "FORCE_R124_top_robust_match_by_functional.csv", top_by_functional)

    any_inside_interval = any(r["inside_mass_uncertainty_interval"] for r in comparison_rows)
    any_1pct = any(r["robust_within_1pct_interval"] for r in comparison_rows)
    any_5pct = any(r["robust_within_5pct_interval"] for r in comparison_rows)
    same_sector_5 = any(r["same_sector"] and r["robust_within_5pct_interval"] for r in comparison_rows)
    lepton_5 = any(r["lepton_lepton"] and r["robust_within_5pct_interval"] for r in comparison_rows)
    quark_5 = any(r["quark_quark"] and r["robust_within_5pct_interval"] for r in comparison_rows)

    gate_audit = [
        {"test": "candidate_values_frozen_before_mass_intervals", "result": "PASS", "interpretation": "Scheme-clean F-values are written and hashed before mass intervals are loaded."},
        {"test": "mass_uncertainty_table_loaded_after_freeze", "result": "PASS", "interpretation": "Lepton precision and broad quark screening intervals are loaded only after candidate freeze."},
        {"test": "uncertainty_comparison_generated", "result": "PASS", "interpretation": "Frozen F-ratios are compared against mass-ratio intervals."},
        {"test": "any_5pct_robust_interval_hits", "result": "SCREEN" if any_5pct else "NO_HIT", "interpretation": "At least one hit survives the 5 percent interval-expanded screen." if any_5pct else "No 5 percent robust interval hit found."},
        {"test": "same_sector_5pct_robust_present", "result": "SCREEN" if same_sector_5 else "NO_HIT", "interpretation": "At least one same-sector robust interval hit is present." if same_sector_5 else "No same-sector robust interval hit found."},
        {"test": "no_parameter_fit_performed", "result": "PASS", "interpretation": "No parameters are optimized against observed masses or intervals."},
        {"test": "no_mode_particle_mapping_performed", "result": "PASS", "interpretation": "No rho mode is assigned to a particle by hand."},
        {"test": "no_final_physical_mass_law_selected", "result": "PASS", "interpretation": "No final mass law is selected by this robustness screen."},
    ]
    claim_boundary = [
        {"claim": "R124 tests whether frozen scheme-clean pairwise hits survive mass uncertainty intervals.", "status": "YES_SCREEN", "reason": "F-values are frozen and hashed before mass intervals are loaded."},
        {"claim": "R124 retunes F(rho) or mass intervals to improve hits.", "status": "NO", "reason": "No exponents, coefficients, regulators, counterterms, intervals, or mappings are optimized."},
        {"claim": "R124 selects a final physical mass law.", "status": "NO", "reason": "Robustness hits are diagnostic only and carry multiple-comparison/quark-scheme risk."},
        {"claim": "R124 confirms the nine seed modes as the Standard Model spectrum.", "status": "NO", "reason": "The nine modes remain a mechanical/operator-geometric seed pending physical identification."},
        {"claim": "R124 closes full PDE/GR self-energy mass derivation.", "status": "NO", "reason": "This is an uncertainty screen, not a self-consistent field/PDE theorem."},
    ]
    next_gate_plan = [
        {"next_gate": "FORCE_R125", "title": "Gravity Map Radius-Depth Sweep Gate", "goal": "Compute radius, depth, monopole, and multipole-like lag-field diagnostics for the nine modes before mass matching.", "must_not_do": "Do not identify lag-field monopoles as physical masses until controls survive."},
        {"next_gate": "FORCE_R123B", "title": "PDE/Action Source-Normalization Gate", "goal": "Attack source normalization and field-action coefficient origin.", "must_not_do": "Do not choose normalization by best empirical hit."},
    ]

    write_csv(OUTDIR / "FORCE_R124_gate_audit.csv", gate_audit)
    write_csv(OUTDIR / "FORCE_R124_claim_boundary.csv", claim_boundary)
    write_csv(OUTDIR / "FORCE_R124_next_gate_plan.csv", next_gate_plan)

    verdict = {
        "gate": GATE_ID,
        "title": GATE_TITLE,
        "freeze_id": FREEZE_ID,
        "verdict": VERDICT_PASS,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "candidate_source_status": candidate_source_status,
        "candidate_source_path": candidate_source_path,
        "candidate_values_frozen_before_mass_intervals": True,
        "candidate_freeze_hash": candidate_freeze_hash,
        "mass_uncertainty_table_loaded_after_freeze": True,
        "uncertainty_comparison_generated": True,
        "any_inside_interval_hits": any_inside_interval,
        "any_1pct_robust_interval_hits": any_1pct,
        "any_5pct_robust_interval_hits": any_5pct,
        "same_sector_5pct_robust_present": same_sector_5,
        "lepton_lepton_5pct_robust_present": lepton_5,
        "quark_quark_5pct_robust_present": quark_5,
        "no_parameter_fit_performed": True,
        "no_functional_retuning_after_mass_loading": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "physical_mass_spectrum_claimed": False,
        "SM_mass_matching_claimed": False,
        "Omega0_claimed": False,
        "full_PDE_mass_functional_closed": False,
        "unique_renormalization_closed": False,
        "selected_seed": "{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}",
    }
    (OUTDIR / "FORCE_R124_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

    summary = f"""# FORCE_R124 Summary

**Verdict:** {VERDICT_PASS}

R124 freezes the scheme-clean F(rho) candidates, then loads compact lepton/quark mass intervals and checks whether R122-style pairwise screen hits survive uncertainty/range scanning.

## Key diagnostics

- Candidate source: {candidate_source_status}
- Candidate freeze hash: `{candidate_freeze_hash}`
- Any 5% robust interval hits: {any_5pct}
- Same-sector 5% robust interval hit present: {same_sector_5}
- Lepton-lepton 5% robust interval hit present: {lepton_5}
- Quark-quark 5% robust interval hit present: {quark_5}

## Boundary

This gate does not select a mass law, map rho modes to particles, confirm a Standard Model spectrum, or close a PDE/GR self-energy theorem.
"""
    (OUTDIR / "FORCE_R124_summary.md").write_text(summary, encoding="utf-8")

    manifest_rows = []
    for path in sorted(OUTDIR.glob("*")):
        if path.is_file():
            manifest_rows.append({"file": path.name, "bytes": path.stat().st_size})
    write_csv(OUTDIR / "artifact_manifest.csv", manifest_rows)

    if PACK_PATH.exists():
        PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(OUTDIR.glob("*")):
            zf.write(path, arcname=f"{OUTDIR.name}/{path.name}")
    zip_integrity = "PASS"
    try:
        with zipfile.ZipFile(PACK_PATH, "r") as zf:
            bad = zf.testzip()
            if bad:
                zip_integrity = f"FAIL:{bad}"
    except Exception as exc:
        zip_integrity = f"FAIL:{exc}"

    print("=== COPY/PASTE R124 RESULT ===")
    print("R124 COMPLETE")
    print(f"VERDICT: {VERDICT_PASS}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {zip_integrity}")
    for key in [
        "candidate_source_status", "candidate_values_frozen_before_mass_intervals", "mass_uncertainty_table_loaded_after_freeze",
        "uncertainty_comparison_generated", "any_inside_interval_hits", "any_1pct_robust_interval_hits",
        "any_5pct_robust_interval_hits", "same_sector_5pct_robust_present", "lepton_lepton_5pct_robust_present",
        "quark_quark_5pct_robust_present", "no_parameter_fit_performed", "no_functional_retuning_after_mass_loading",
        "no_mode_particle_mapping_performed", "no_final_physical_mass_law_selected", "physical_mass_spectrum_claimed",
        "SM_mass_matching_claimed", "Omega0_claimed", "full_PDE_mass_functional_closed", "unique_renormalization_closed",
    ]:
        print(f"{key}: {verdict[key]}")
    print(f"candidate_freeze_hash: {candidate_freeze_hash}")
    print(f"selected_seed: {verdict['selected_seed']}")
    print("TOP_ROBUST_MATCHES:")
    for r in robust_rows_sorted[:10]:
        print(f"  {r['functional_id']} | {r['rho_pair']} | F={ffmt(float(r['F_ratio_ge_1']))} | {r['particle_pair']} | interval=[{ffmt(float(r['mass_ratio_min_ge_1']))}, {ffmt(float(r['mass_ratio_max_ge_1']))}] | dist={ffmt(float(r['distance_to_interval_percent_log']))}% | same_sector={r['same_sector']} | lepton_lepton={r['lepton_lepton']}")
    print("THRESHOLD_SUMMARY:")
    for r in threshold_summary:
        print(f"  {r['functional_id']} | dyn={ffmt(float(r['F_dynamic_range_max_over_min']))} | inside={r['inside_interval_hits']} | robust<=1%={r['robust_hits_le_1pct_interval']} | robust<=5%={r['robust_hits_le_5pct_interval']} | same_sector<=5%={r['same_sector_robust_hits_le_5pct']} | warning={r['multiple_comparison_warning']}")
    print("CLAIM_BOUNDARY:")
    for row in claim_boundary:
        print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
    print(f"PACK: {PACK_PATH}")
    print(f"SUMMARY: {OUTDIR / 'FORCE_R124_summary.md'}")
    print("NEXT: FORCE_R125_gravity_map_radius_depth_sweep_gate")
    print("=== END COPY/PASTE R124 RESULT ===")
    return 0 if zip_integrity == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
