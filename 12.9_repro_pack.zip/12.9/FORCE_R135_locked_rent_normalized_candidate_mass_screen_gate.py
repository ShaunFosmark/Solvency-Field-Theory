from pathlib import Path
from fractions import Fraction
from itertools import combinations
import hashlib
import json
import math
import shutil
import zipfile
import pandas as pd

OUT = Path('FORCE_R135_locked_rent_normalized_candidate_mass_screen_gate')
ZIP = Path('FORCE_R135_locked_rent_normalized_candidate_mass_screen_gate_pack.zip')

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

FREEZE_ID = 'SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM'
TITLE = 'FORCE_R135 Locked Rent-Normalized Candidate Mass Screen Gate'

SEED = [Fraction(1,2), Fraction(2,3), Fraction(3,4), Fraction(1,1), Fraction(5,4), Fraction(4,3), Fraction(3,2), Fraction(5,3), Fraction(2,1)]
SEED_LABELS = [str(x) for x in SEED]
SELECTED_SEED = '{' + ', '.join(SEED_LABELS) + '}'
CANONICAL_SPECIES_FORMULA = 'Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}'

# R133 geometry-only available feedback values normalized to the identity anchor.
# These are carried in as frozen geometry-screen inputs, not inferred from masses.
available_norm = {
    '1/2': 0.043158,
    '2/3': 0.161160,
    '3/4': 0.285086,
    '1': 1.000000,
    '5/4': 5.700160,
    '4/3': 9.398832,
    '3/2': 27.536241,
    '5/3': 108.109209,
    '2': 776.840677,
}

rho_float = {str(x): float(x) for x in SEED}

support_ecology = {
    '1/2': 'clean_internal',
    '2/3': 'clean_internal',
    '3/4': 'clean_internal',
    '1': 'clean_internal',
    '5/4': 'virtual_support_dependent',
    '4/3': 'clean_internal',
    '3/2': 'clean_internal',
    '5/3': 'virtual_support_dependent',
    '2': 'boundary_assisted',
}

candidate_specs = [
    {
        'functional_id': 'p5_quadratic_density_self_energy_rent_normalized',
        'power': 5.0,
        'source_status': 'PRIMARY_DERIVED_RENT_CANDIDATE_FROM_R132_R133',
        'primary_screen': True,
    },
    {
        'functional_id': 'p6_curvature_weighted_self_energy_rent_normalized',
        'power': 6.0,
        'source_status': 'PRIMARY_COMPOSITE_RENT_CANDIDATE_FROM_R132_R133',
        'primary_screen': True,
    },
    {
        'functional_id': 'p4_write_density_rent_control_too_shallow',
        'power': 4.0,
        'source_status': 'FAIL_CONTROL_TOO_SHALLOW_FROM_R132_R133',
        'primary_screen': False,
    },
    {
        'functional_id': 'p7_acceleration_weighted_high_order_control',
        'power': 7.0,
        'source_status': 'HIGH_ORDER_CONTROL_NOT_LAW_FROM_R132_R133',
        'primary_screen': False,
    },
]


def fmt(x):
    if isinstance(x, float):
        if x == 0:
            return '0'
        if abs(x) >= 1e5 or abs(x) < 1e-4:
            return f'{x:.6g}'
        return f'{x:.6g}'
    return str(x)


def sha256_text(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def ratio_distance_percent(pred, target):
    return abs(math.log(pred / target)) * 100.0


def pct_error(pred, target):
    return abs(pred - target) / target * 100.0

# ---------------------------------------------------------------------
# 1. Freeze candidate values before mass loading.
# ---------------------------------------------------------------------

candidate_rows = []
for spec in candidate_specs:
    p = spec['power']
    vals = {}
    for rho in SEED_LABELS:
        required = rho_float[rho] ** p
        adequacy = available_norm[rho] / required
        vals[rho] = adequacy
        candidate_rows.append({
            'functional_id': spec['functional_id'],
            'power': p,
            'source_status': spec['source_status'],
            'primary_screen': spec['primary_screen'],
            'rho': rho,
            'rho_float': rho_float[rho],
            'available_norm': available_norm[rho],
            'required_rent': required,
            'rent_normalized_F': adequacy,
            'support_ecology': support_ecology[rho],
        })

candidate_values = pd.DataFrame(candidate_rows)
# Freeze to disk before any empirical mass table is constructed.
frozen_candidate_path = OUT / 'FORCE_R135_frozen_candidate_values_before_mass_loading.csv'
candidate_values.to_csv(frozen_candidate_path, index=False)
candidate_freeze_hash = sha256_file(frozen_candidate_path)
candidate_values_frozen_before_mass_loading = frozen_candidate_path.exists() and frozen_candidate_path.stat().st_size > 0

# ---------------------------------------------------------------------
# 2. Load compact charged-fermion screening mass table only AFTER freeze.
#    Values are screening inputs, not fit targets. Quark values are central
#    current-mass style inputs and carry scheme/scale risk.
# ---------------------------------------------------------------------

mass_rows = [
    {'particle': 'electron', 'sector': 'lepton', 'mass_MeV': 0.51099895, 'scheme_note': 'direct lepton mass screening input'},
    {'particle': 'muon', 'sector': 'lepton', 'mass_MeV': 105.6583755, 'scheme_note': 'direct lepton mass screening input'},
    {'particle': 'tau', 'sector': 'lepton', 'mass_MeV': 1776.86, 'scheme_note': 'direct lepton mass screening input'},
    {'particle': 'up_quark', 'sector': 'quark', 'mass_MeV': 2.16, 'scheme_note': 'quark current mass; scheme/scale screening input'},
    {'particle': 'down_quark', 'sector': 'quark', 'mass_MeV': 4.67, 'scheme_note': 'quark current mass; scheme/scale screening input'},
    {'particle': 'strange_quark', 'sector': 'quark', 'mass_MeV': 93.4, 'scheme_note': 'quark current mass; scheme/scale screening input'},
    {'particle': 'charm_quark', 'sector': 'quark', 'mass_MeV': 1270.0, 'scheme_note': 'quark current mass; scheme/scale screening input'},
    {'particle': 'bottom_quark', 'sector': 'quark', 'mass_MeV': 4180.0, 'scheme_note': 'quark current mass; scheme/scale screening input'},
    {'particle': 'top_quark', 'sector': 'quark', 'mass_MeV': 172760.0, 'scheme_note': 'quark/top mass screening input'},
]
mass_table = pd.DataFrame(mass_rows)
mass_table.to_csv(OUT / 'FORCE_R135_mass_screening_table_loaded_after_freeze.csv', index=False)
empirical_mass_data_loaded_after_freeze = candidate_values_frozen_before_mass_loading and mass_table.shape[0] == 9

# ---------------------------------------------------------------------
# 3. Blind pairwise mass-ratio screen.
# ---------------------------------------------------------------------

mass_ratio_rows = []
for a, b in combinations(mass_rows, 2):
    # ratio >= 1; label preserves numerator/denominator orientation.
    if a['mass_MeV'] >= b['mass_MeV']:
        hi, lo = a, b
    else:
        hi, lo = b, a
    mass_ratio_rows.append({
        'particle_hi': hi['particle'],
        'particle_lo': lo['particle'],
        'mass_ratio': hi['mass_MeV'] / lo['mass_MeV'],
        'same_sector': hi['sector'] == lo['sector'],
        'lepton_lepton': hi['sector'] == lo['sector'] == 'lepton',
        'quark_quark': hi['sector'] == lo['sector'] == 'quark',
        'sector_pair': hi['sector'] + '_' + lo['sector'],
        'scheme_warning': 'HIGH' if (hi['sector'] == 'quark' or lo['sector'] == 'quark') else 'LOW',
    })
mass_ratios = pd.DataFrame(mass_ratio_rows)
mass_ratios.to_csv(OUT / 'FORCE_R135_mass_pairwise_ratios.csv', index=False)

f_ratio_rows = []
for spec in candidate_specs:
    f_id = spec['functional_id']
    df = candidate_values[candidate_values['functional_id'] == f_id].copy()
    val = dict(zip(df['rho'], df['rent_normalized_F']))
    for r1, r2 in combinations(SEED_LABELS, 2):
        if val[r1] >= val[r2]:
            hi, lo = r1, r2
        else:
            hi, lo = r2, r1
        f_ratio_rows.append({
            'functional_id': f_id,
            'power': spec['power'],
            'primary_screen': spec['primary_screen'],
            'rho_hi': hi,
            'rho_lo': lo,
            'F_ratio': val[hi] / val[lo],
            'hi_ecology': support_ecology[hi],
            'lo_ecology': support_ecology[lo],
            'same_ecology_class': support_ecology[hi] == support_ecology[lo],
        })
f_ratios = pd.DataFrame(f_ratio_rows)
f_ratios.to_csv(OUT / 'FORCE_R135_F_pairwise_ratios.csv', index=False)

match_rows = []
for frow in f_ratios.to_dict('records'):
    for mrow in mass_ratios.to_dict('records'):
        err = pct_error(frow['F_ratio'], mrow['mass_ratio'])
        log_err = ratio_distance_percent(frow['F_ratio'], mrow['mass_ratio'])
        match_rows.append({
            **frow,
            **mrow,
            'percent_error': err,
            'log_distance_percent': log_err,
            'within_1pct': err <= 1.0,
            'within_5pct': err <= 5.0,
        })
matches = pd.DataFrame(match_rows)
matches.to_csv(OUT / 'FORCE_R135_blind_pairwise_match_table.csv', index=False)

primary_matches = matches[matches['primary_screen'] == True].copy()

# ---------------------------------------------------------------------
# 4. Threshold summaries and monotonic full-spectrum dynamic range audit.
# ---------------------------------------------------------------------

threshold_rows = []
for f_id, group in matches.groupby('functional_id'):
    spec = next(s for s in candidate_specs if s['functional_id'] == f_id)
    vals = candidate_values[candidate_values['functional_id'] == f_id]['rent_normalized_F'].tolist()
    dyn = max(vals) / min(vals)
    best = group.sort_values('percent_error').iloc[0]
    threshold_rows.append({
        'functional_id': f_id,
        'power': spec['power'],
        'primary_screen': spec['primary_screen'],
        'dynamic_range': dyn,
        'best_error_percent': float(best['percent_error']),
        'best_match': f"{best['rho_hi']} vs {best['rho_lo']} -> {best['particle_hi']} vs {best['particle_lo']}",
        'hits_le_1pct': int(group['within_1pct'].sum()),
        'hits_le_5pct': int(group['within_5pct'].sum()),
        'same_sector_le_5pct': int((group['within_5pct'] & group['same_sector']).sum()),
        'lepton_lepton_le_5pct': int((group['within_5pct'] & group['lepton_lepton']).sum()),
        'quark_quark_le_5pct': int((group['within_5pct'] & group['quark_quark']).sum()),
        'multiple_comparison_warning': 'HIGH',
    })
threshold_summary = pd.DataFrame(threshold_rows).sort_values(
    ['primary_screen', 'best_error_percent'], ascending=[False, True]
)
threshold_summary.to_csv(OUT / 'FORCE_R135_threshold_summary.csv', index=False)

# Monotonic audit: compare the sorted 9 F values to sorted charged fermion masses after normalizing by their minima.
target_dyn = mass_table['mass_MeV'].max() / mass_table['mass_MeV'].min()
monotonic_rows = []
for f_id, group in candidate_values.groupby('functional_id'):
    vals = sorted(group['rent_normalized_F'].tolist())
    masses = sorted(mass_table['mass_MeV'].tolist())
    vals_norm = [v / vals[0] for v in vals]
    masses_norm = [m / masses[0] for m in masses]
    rms_log = math.sqrt(sum((math.log(vals_norm[i]) - math.log(masses_norm[i]))**2 for i in range(9)) / 9.0)
    dyn = vals[-1] / vals[0]
    monotonic_rows.append({
        'functional_id': f_id,
        'F_dynamic_range': dyn,
        'target_dynamic_range': target_dyn,
        'shortfall': target_dyn / dyn if dyn < target_dyn else 0.0,
        'overshoot': dyn / target_dyn if dyn > target_dyn else 0.0,
        'dynamic_range_pass': 0.5 <= (dyn / target_dyn) <= 2.0,
        'rms_log_sorted_shape_error': rms_log,
    })
monotonic_audit = pd.DataFrame(monotonic_rows).sort_values('F_dynamic_range', ascending=False)
monotonic_audit.to_csv(OUT / 'FORCE_R135_monotonic_full_spectrum_audit.csv', index=False)

# ---------------------------------------------------------------------
# 5. Booleans and claim boundary.
# ---------------------------------------------------------------------

blind_comparison_generated = matches.shape[0] > 0
any_1pct_pairwise_hits = bool(primary_matches['within_1pct'].any())
any_5pct_pairwise_hits = bool(primary_matches['within_5pct'].any())
same_sector_5pct_present = bool((primary_matches['within_5pct'] & primary_matches['same_sector']).any())
lepton_lepton_5pct_present = bool((primary_matches['within_5pct'] & primary_matches['lepton_lepton']).any())
quark_quark_5pct_present = bool((primary_matches['within_5pct'] & primary_matches['quark_quark']).any())
full_spectrum_dynamic_range_any_pass = bool(monotonic_audit[monotonic_audit['functional_id'].isin([candidate_specs[0]['functional_id'], candidate_specs[1]['functional_id']])]['dynamic_range_pass'].any())

no_parameter_fit_performed = True
no_functional_retuning_after_mass_loading = True
no_mode_particle_mapping_performed = True
no_final_physical_mass_law_selected = True
physical_mass_spectrum_claimed = False
SM_mass_matching_claimed = False
Omega0_claimed = False
unique_rent_law_closed = False
true_GR_PDE_collective_field_closed = False

if (
    candidate_values_frozen_before_mass_loading
    and empirical_mass_data_loaded_after_freeze
    and blind_comparison_generated
    and any_5pct_pairwise_hits
    and no_parameter_fit_performed
    and no_functional_retuning_after_mass_loading
    and no_mode_particle_mapping_performed
    and no_final_physical_mass_law_selected
):
    verdict_status = 'LOCKED RENT-NORMALIZED CANDIDATE MASS SCREEN PASS / SCREEN HITS REPORTED, FULL MASS LAW NOT CLOSED'
else:
    verdict_status = 'LOCKED RENT-NORMALIZED CANDIDATE MASS SCREEN INCONCLUSIVE'

claim_boundary = pd.DataFrame([
    {
        'status': 'YES_SCREEN',
        'claim': 'R135 compares frozen p=5/p=6 rent-normalized F(rho) pairwise ratios to external mass ratios.',
        'reason': 'Candidate values are written and hashed before the charged-fermion screening table is constructed.',
    },
    {
        'status': 'NO',
        'claim': 'R135 chooses p=5 or p=6 because of empirical hits.',
        'reason': 'p=5 and p=6 were generated before mass loading from R132/R133 power-count screens.',
    },
    {
        'status': 'NO',
        'claim': 'R135 retunes, refits, or exponent-optimizes after seeing masses.',
        'reason': 'No exponents, coefficients, thresholds, regulators, counterterms, or mappings are optimized after mass loading.',
    },
    {
        'status': 'YES_SCREEN',
        'claim': 'R135 reports exploratory pairwise mass-ratio hits.',
        'reason': 'Hits are reported with same-sector labels and multiple-comparison warnings.',
    },
    {
        'status': 'NO',
        'claim': 'R135 passes a full nine-mode monotonic charged-fermion dynamic-range test.',
        'reason': 'Rent-normalized adequacy candidates are screened; dynamic-range closure is not assumed.',
    },
    {
        'status': 'NO',
        'claim': 'R135 selects a final physical mass law or sector split.',
        'reason': 'The result is a locked blind screen only; final law selection requires derivation and independent controls.',
    },
    {
        'status': 'NO',
        'claim': 'R135 maps rho modes to leptons, quarks, or Standard Model particles.',
        'reason': 'Only pairwise ratios and sorted diagnostics are computed; no rho-to-particle identities are declared.',
    },
    {
        'status': 'NO',
        'claim': 'R135 closes true GR/PDE collective field dynamics.',
        'reason': 'The rent-normalized feedback candidates are geometry/power-count screens, not solved self-consistent field equations.',
    },
])
claim_boundary.to_csv(OUT / 'FORCE_R135_claim_boundary.csv', index=False)

gate_audit = pd.DataFrame([
    {'test': 'candidate_values_frozen_before_mass_loading', 'result': 'PASS' if candidate_values_frozen_before_mass_loading else 'WARN', 'interpretation': 'Candidate F-values were written and hashed before mass table construction.'},
    {'test': 'empirical_mass_data_loaded_after_freeze', 'result': 'PASS' if empirical_mass_data_loaded_after_freeze else 'WARN', 'interpretation': 'Mass screening table was constructed after candidate freeze.'},
    {'test': 'blind_comparison_generated', 'result': 'PASS' if blind_comparison_generated else 'WARN', 'interpretation': 'Pairwise F ratios and pairwise mass ratios were compared after freeze.'},
    {'test': 'any_1pct_pairwise_hits', 'result': 'PASS' if any_1pct_pairwise_hits else 'INFO', 'interpretation': 'At least one primary p=5/p=6 pairwise hit is within 1 percent.'},
    {'test': 'any_5pct_pairwise_hits', 'result': 'PASS' if any_5pct_pairwise_hits else 'INFO', 'interpretation': 'At least one primary p=5/p=6 pairwise hit is within 5 percent.'},
    {'test': 'same_sector_5pct_present', 'result': 'PASS' if same_sector_5pct_present else 'INFO', 'interpretation': 'At least one same-sector p=5/p=6 hit is within 5 percent.'},
    {'test': 'full_spectrum_dynamic_range_any_pass', 'result': 'OPEN' if not full_spectrum_dynamic_range_any_pass else 'PASS', 'interpretation': 'The full monotonic charged-fermion dynamic range remains a separate open test.'},
    {'test': 'no_parameter_fit_performed', 'result': 'PASS' if no_parameter_fit_performed else 'WARN', 'interpretation': 'No coefficients or exponents were fit to data.'},
    {'test': 'no_mode_particle_mapping_performed', 'result': 'PASS' if no_mode_particle_mapping_performed else 'WARN', 'interpretation': 'No rho-to-particle identities were assigned.'},
    {'test': 'no_final_physical_mass_law_selected', 'result': 'PASS' if no_final_physical_mass_law_selected else 'WARN', 'interpretation': 'No final mass law was selected.'},
])
gate_audit.to_csv(OUT / 'FORCE_R135_gate_audit.csv', index=False)

# ---------------------------------------------------------------------
# 6. Summary and pack.
# ---------------------------------------------------------------------

top_matches = primary_matches.sort_values('percent_error').head(16).copy()

summary = f'''# FORCE_R135 — Locked Rent-Normalized Candidate Mass Screen Gate

## Verdict

BOXED: {verdict_status}

## Freeze ID

BOXED: {FREEZE_ID}

## Selected seed

BOXED: {SELECTED_SEED}

## Canonical species formula

BOXED: {CANONICAL_SPECIES_FORMULA}

## Candidate freeze hash

BOXED: {candidate_freeze_hash}

## Key booleans

- candidate_values_frozen_before_mass_loading: {candidate_values_frozen_before_mass_loading}
- empirical_mass_data_loaded_after_freeze: {empirical_mass_data_loaded_after_freeze}
- blind_comparison_generated: {blind_comparison_generated}
- any_1pct_pairwise_hits: {any_1pct_pairwise_hits}
- any_5pct_pairwise_hits: {any_5pct_pairwise_hits}
- same_sector_5pct_present: {same_sector_5pct_present}
- lepton_lepton_5pct_present: {lepton_lepton_5pct_present}
- quark_quark_5pct_present: {quark_quark_5pct_present}
- full_spectrum_dynamic_range_any_pass: {full_spectrum_dynamic_range_any_pass}
- no_parameter_fit_performed: {no_parameter_fit_performed}
- no_functional_retuning_after_mass_loading: {no_functional_retuning_after_mass_loading}
- no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}
- no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}

## Top primary matches

{top_matches[['functional_id','rho_hi','rho_lo','F_ratio','particle_hi','particle_lo','mass_ratio','percent_error','same_sector','lepton_lepton','quark_quark','scheme_warning']].to_string(index=False)}

## Threshold summary

{threshold_summary.to_string(index=False)}

## Monotonic full-spectrum audit

{monotonic_audit.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}
'''
(OUT / 'FORCE_R135_summary.md').write_text(summary, encoding='utf-8')

verdict = {
    'force_id': 'FORCE_R135',
    'title': TITLE,
    'status': verdict_status,
    'freeze_id': FREEZE_ID,
    'candidate_freeze_hash': candidate_freeze_hash,
    'candidate_values_frozen_before_mass_loading': candidate_values_frozen_before_mass_loading,
    'empirical_mass_data_loaded_after_freeze': empirical_mass_data_loaded_after_freeze,
    'blind_comparison_generated': blind_comparison_generated,
    'any_1pct_pairwise_hits': any_1pct_pairwise_hits,
    'any_5pct_pairwise_hits': any_5pct_pairwise_hits,
    'same_sector_5pct_present': same_sector_5pct_present,
    'lepton_lepton_5pct_present': lepton_lepton_5pct_present,
    'quark_quark_5pct_present': quark_quark_5pct_present,
    'full_spectrum_dynamic_range_any_pass': full_spectrum_dynamic_range_any_pass,
    'no_parameter_fit_performed': no_parameter_fit_performed,
    'no_functional_retuning_after_mass_loading': no_functional_retuning_after_mass_loading,
    'no_mode_particle_mapping_performed': no_mode_particle_mapping_performed,
    'no_final_physical_mass_law_selected': no_final_physical_mass_law_selected,
    'physical_mass_spectrum_claimed': physical_mass_spectrum_claimed,
    'SM_mass_matching_claimed': SM_mass_matching_claimed,
    'Omega0_claimed': Omega0_claimed,
    'unique_rent_law_closed': unique_rent_law_closed,
    'true_GR_PDE_collective_field_closed': true_GR_PDE_collective_field_closed,
    'selected_seed': SEED_LABELS,
    'canonical_species_formula': CANONICAL_SPECIES_FORMULA,
    'recommended_next': 'FORCE_R136_rent_normalized_result_interpretation_gate_or_FORCE_R128_GR_lag_field_derivation_gate',
}
(OUT / 'FORCE_R135_verdict.json').write_text(json.dumps(verdict, indent=2), encoding='utf-8')

# Manifest before zipping.
manifest_rows = []
for p in sorted(OUT.rglob('*')):
    if p.is_file():
        manifest_rows.append({'relative_path': str(p.relative_to(OUT)), 'bytes': p.stat().st_size, 'sha256': sha256_file(p)})
pd.DataFrame(manifest_rows).to_csv(OUT / 'artifact_manifest.csv', index=False)

try:
    shutil.copy2(Path(__file__).resolve(), OUT / 'FORCE_R135_locked_rent_normalized_candidate_mass_screen_gate.py')
except Exception:
    pass

if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))
with zipfile.ZipFile(ZIP, 'r') as z:
    bad = z.testzip()
zip_integrity_pass = bad is None
verdict['zip_integrity_pass'] = zip_integrity_pass
(OUT / 'FORCE_R135_verdict.json').write_text(json.dumps(verdict, indent=2), encoding='utf-8')

# Console block.
print('=== COPY/PASTE R135 RESULT ===')
print('R135 COMPLETE')
print(f'VERDICT: {verdict_status}')
print(f'FREEZE_ID: {FREEZE_ID}')
print(f'ZIP_INTEGRITY: {"PASS" if zip_integrity_pass else bad}')
print(f'candidate_values_frozen_before_mass_loading: {candidate_values_frozen_before_mass_loading}')
print(f'empirical_mass_data_loaded_after_freeze: {empirical_mass_data_loaded_after_freeze}')
print(f'blind_comparison_generated: {blind_comparison_generated}')
print(f'any_1pct_pairwise_hits: {any_1pct_pairwise_hits}')
print(f'any_5pct_pairwise_hits: {any_5pct_pairwise_hits}')
print(f'same_sector_5pct_present: {same_sector_5pct_present}')
print(f'lepton_lepton_5pct_present: {lepton_lepton_5pct_present}')
print(f'quark_quark_5pct_present: {quark_quark_5pct_present}')
print(f'full_spectrum_dynamic_range_any_pass: {full_spectrum_dynamic_range_any_pass}')
print(f'no_parameter_fit_performed: {no_parameter_fit_performed}')
print(f'no_functional_retuning_after_mass_loading: {no_functional_retuning_after_mass_loading}')
print(f'no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}')
print(f'no_final_physical_mass_law_selected: {no_final_physical_mass_law_selected}')
print(f'physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}')
print(f'SM_mass_matching_claimed: {SM_mass_matching_claimed}')
print(f'Omega0_claimed: {Omega0_claimed}')
print(f'unique_rent_law_closed: {unique_rent_law_closed}')
print(f'true_GR_PDE_collective_field_closed: {true_GR_PDE_collective_field_closed}')
print(f'candidate_freeze_hash: {candidate_freeze_hash}')
print(f'selected_seed: {SELECTED_SEED}')
print(f'canonical_species_formula: {CANONICAL_SPECIES_FORMULA}')
print('TOP_MATCHES_BY_FUNCTIONAL:')
for _, row in top_matches.iterrows():
    print(f"  {row['functional_id']} | {row['rho_hi']} vs {row['rho_lo']} | F={fmt(row['F_ratio'])} | {row['particle_hi']} vs {row['particle_lo']} | M={fmt(row['mass_ratio'])} | err={fmt(row['percent_error'])}% | same_sector={row['same_sector']} | lepton_lepton={row['lepton_lepton']} | quark_quark={row['quark_quark']} | warning={row['scheme_warning']}")
print('THRESHOLD_SUMMARY:')
for _, row in threshold_summary.iterrows():
    print(f"  {row['functional_id']} | p={fmt(row['power'])} | dyn={fmt(row['dynamic_range'])} | best_err={fmt(row['best_error_percent'])}% | hits<=1%={row['hits_le_1pct']} | hits<=5%={row['hits_le_5pct']} | same_sector<=5%={row['same_sector_le_5pct']} | lepton<=5%={row['lepton_lepton_le_5pct']} | quark<=5%={row['quark_quark_le_5pct']} | warning={row['multiple_comparison_warning']}")
print('MONOTONIC_FULL_SPECTRUM_AUDIT:')
for _, row in monotonic_audit.iterrows():
    print(f"  {row['functional_id']} | F_dyn={fmt(row['F_dynamic_range'])} | target_dyn={fmt(row['target_dynamic_range'])} | shortfall={fmt(row['shortfall'])} | pass={row['dynamic_range_pass']} | rms_log={fmt(row['rms_log_sorted_shape_error'])}")
print('CLAIM_BOUNDARY:')
for _, row in claim_boundary.iterrows():
    print(f"  {row['status']} | {row['claim']} -- {row['reason']}")
print(f'PACK: {ZIP.resolve()}')
print(f'SUMMARY: {(OUT / "FORCE_R135_summary.md").resolve()}')
print('NEXT: FORCE_R136_rent_normalized_result_interpretation_gate_or_FORCE_R128_GR_lag_field_derivation_gate')
print('=== END COPY/PASTE R135 RESULT ===')
