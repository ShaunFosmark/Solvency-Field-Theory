# FORCE_R125_gravity_map_radius_depth_sweep_gate

**Freeze ID:** `SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM`

**Verdict:** `GRAVITY MAP RADIUS-DEPTH SWEEP PASS / SCALAR LAG FIELD SCREEN CLOSED, TRUE GR-PDE MASS LAW OPEN`

## Purpose

R125 places the nine selected V12.8/V12.9 helical modes into a scalar lag/gravity-like kernel and measures radius, depth, focusing gain, self-overlap, and radius-depth scaling.

This is a field-map screen, not a solved GR/PDE mass law.

## Top Diagnostics

| scale law | weight mode | metric | dynamic range | slope | grade |
|---|---:|---:|---:|---:|---|
| inverse_lens_radius | unit_budget | density_depth_proxy | 269.251 | 4.002 | STRONG_NONLINEAR_SCREEN |
| inverse_rho_radius | unit_budget | density_depth_proxy | 269.251 | 4.002 | STRONG_NONLINEAR_SCREEN |
| inverse_rho_radius | path_length_budget | density_depth_proxy | 269.251 | 4.002 | STRONG_NONLINEAR_SCREEN |
| inverse_lens_radius | path_length_budget | density_depth_proxy | 269.251 | 4.002 | STRONG_NONLINEAR_SCREEN |
| inverse_lens_radius | unit_budget | radius_depth_feedback_proxy | 214.365 | 3.738 | STRONG_NONLINEAR_SCREEN |
| inverse_rho_radius | unit_budget | radius_depth_feedback_proxy | 189.007 | 3.65 | STRONG_NONLINEAR_SCREEN |
| inverse_lens_radius | path_length_budget | pair_self_energy_raw | 24.7893 | -1.334 | NONLINEAR_SCREEN |
| inverse_rho_radius | path_length_budget | pair_self_energy_raw | 20.6578 | -1.232 | NONLINEAR_SCREEN |
| inverse_lens_radius | path_length_budget | radius_depth_feedback_proxy | 19.4382 | 1.32 | NONLINEAR_SCREEN |
| inverse_sqrt_lens_radius | unit_budget | radius_depth_feedback_proxy | 16.8757 | 3.808 | NONLINEAR_SCREEN |
| inverse_sqrt_lens_radius | path_length_budget | density_depth_proxy | 16.8282 | 4.005 | NONLINEAR_SCREEN |
| inverse_sqrt_lens_radius | unit_budget | density_depth_proxy | 16.8282 | 4.005 | NONLINEAR_SCREEN |

## Claim Boundary

- YES: R125 computes a scalar lag/gravity radius-depth map from helical geometry.
- NO: R125 does not load empirical masses or compare to particle masses.
- NO: R125 does not close a unique physical mass law.
- NO: R125 does not solve a self-consistent Einstein/PDE mass functional.
- NO: R125 does not promote virtual supports to species.
