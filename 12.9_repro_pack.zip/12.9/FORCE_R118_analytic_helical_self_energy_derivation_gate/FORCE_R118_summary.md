# FORCE_R118 — Analytic Helical Self-Energy Derivation Gate

## Verdict

BOXED: ANALYTIC HELICAL SELF-ENERGY CANDIDATE PASS / RENORMALIZATION, PDE CLOSURE, AND MASS MATCHING OPEN

## Central result

R118 replaces purely toy focusing proxies with a geometry-native self-energy candidate roster:

- closed helical/toroidal representative curve for each rho=p/q;
- local curvature action candidates such as integral kappa^2 ds;
- regularized Green-kernel self-overlap candidates;
- regulator finite-part diagnostics.

## Selected seed

BOXED: {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}

## Claim boundary

BOXED: no empirical mass data loaded.
BOXED: no mass matching performed.
BOXED: no final physical mass law selected.
BOXED: full PDE/GR self-energy remains open.
BOXED: physical spectrum, SM matching, and Omega0 remain open.

## Key booleans

- candidate_self_energy_roster_closed: True
- geometry_table_generated: True
- seed_all_computed: True
- virtuals_computed_not_promoted: True
- kernel_table_generated: True
- finite_part_generated: True
- all_functionals_finite_positive: True
- regularization_sensitivity_reported: True
- no_empirical_mass_data_loaded: True
- no_parameter_fit_performed: True
- unique_renormalization_closed: False
- full_PDE_mass_functional_closed: False

## Gate audit

                               test result                                                                   interpretation
           geometry_table_generated   PASS                   All audited rho modes receive closed helical geometry metrics.
                  seed_all_computed   PASS                                          All nine V12.8 seed modes are computed.
     virtuals_computed_not_promoted   PASS                   Virtual supports receive F-values but remain species-inactive.
             kernel_table_generated   PASS                     Regularized Green-kernel self-overlap tables were generated.
              finite_part_generated   PASS                                A regulator finite-part diagnostic was generated.
    all_functionals_finite_positive   PASS Candidate self-energy/focusing functionals are finite and nonzero on seed modes.
        functional_roster_generated   PASS            A candidate functional roster was generated without empirical masses.
regularization_sensitivity_reported   PASS                            Regulator sensitivity is reported rather than hidden.
      no_empirical_mass_data_loaded   PASS                          R118 does not load particle masses or SM target ratios.
         no_parameter_fit_performed   PASS                               No coefficient/exponent is optimized against data.
      unique_renormalization_closed   OPEN                  The regulator/counterterm prescription is not uniquely derived.
    full_PDE_mass_functional_closed   OPEN                        No complete PDE/GR self-energy mass functional is closed.
     physical_mass_spectrum_claimed   OPEN                                            No physical mass spectrum is claimed.

## Functional roster

                functional_id  seed_dynamic_range_max_over_min seed_min_rho_at_function_min seed_max_rho_at_function_max        candidate_origin  selected_as_final_physical_mass_law
          analytic_lens_proxy                       128.000000                          1/2                            2         local_geometric                                False
            total_abs_torsion                        24.911200                          1/2                          5/3         local_geometric                                False
             helix_complexity                        22.638463                            1                          5/4         local_geometric                                False
torsion_plus_curvature_action                         6.949196                            1                          5/3         local_geometric                                False
    bend_energy_int_kappa2_ds                         4.504617                            1                          5/3         local_geometric                                False
                 curve_length                         4.124468                            1                          5/4         local_geometric                                False
   bend_times_offdiag_density                         3.096542                            1                          5/3 requires_regularization                                False
curvature_times_green_density                         1.827334                          3/4                            2 requires_regularization                                False
        green_offdiag_density                         1.498901                          5/4                            1 requires_regularization                                False
            green_all_density                         1.485508                          5/4                            1 requires_regularization                                False
      finite_part_abs_offdiag                         1.480004                          5/4                            1 requires_regularization                                False
          finite_part_abs_all                         1.480004                          5/4                            1 requires_regularization                                False
               mean_curvature                         1.324535                            1                            2         local_geometric                                False
                rms_curvature                         1.321976                            1                            2         local_geometric                                False

## Seed functional preview

rho  curve_length  bend_energy_int_kappa2_ds  green_offdiag_density  bend_times_offdiag_density  finite_part_abs_all
1/2     12.768832                  12.587041               1.113874                   14.020382             1.144414
2/3     19.384542                  18.376228               1.014176                   18.636733             1.045797
3/4     26.029134                  24.311788               0.974810                   23.699370             1.006319
  1      6.678111                   6.196508               1.458014                    9.034598             1.486088
5/4     27.543656                  27.340683               0.972722                   26.594892             1.004111
4/3     20.895913                  21.567525               1.006548                   21.708756             1.038099
3/2     14.269016                  16.220151               1.085672                   17.609764             1.116118
5/3     21.948713                  27.912897               1.002261                   27.976011             1.033835
  2      7.723025                  12.523565               1.351905                   16.930669             1.380009

## Regularization sensitivity

rho  offdiag_density_eps_min  offdiag_density_eps_max  offdiag_density_spread_frac  all_density_eps_min  all_density_eps_max  all_density_spread_frac
1/2                 1.016986                 1.195493                     0.160993             1.030754             1.250565                 0.192662
2/3                 0.952983                 1.059559                     0.105635             0.966715             1.114487                 0.141959
3/4                 0.930586                 1.003279                     0.074975             0.944298             1.058124                 0.113650
  1                 1.263507                 1.638486                     0.258013             1.277150             1.693060                 0.280042
5/4                 0.930968                 0.998782                     0.070092             0.944538             1.053060                 0.108614
4/3                 0.950017                 1.047304                     0.097162             0.963563             1.101486                 0.133531
3/2                 0.999601                 1.156520                     0.145215             1.013098             1.210510                 0.177514
5/3                 0.948573                 1.040163                     0.091866             0.962024             1.093967                 0.128301
  2                 1.184801                 1.504957                     0.237642             1.198169             1.558429                 0.261359

## Claim boundary

                                                                              claim status                                                                                                           reason
    R118 derives geometry-native analytic/self-energy candidate F(rho) functionals.    YES Closed helical curves, curvature actions, and regularized Green-kernel self-overlaps are computed from rho only.
                                  R118 compares F(rho) to observed particle masses.     NO                                                              No empirical masses or SM target ratios are loaded.
                                            R118 selects a final physical mass law.     NO                            Regularization and PDE derivation remain open; no final F is chosen by empirical hit.
R118 promotes virtual supports to stable species if their F-values are interesting.     NO                                   V12.8 species projection remains locked; virtual supports remain support-only.
                                               R118 closes true GR/PDE self-energy.     NO   The Green-kernel integral is a principled scalar self-overlap candidate, not a solved Einstein-field solution.
                               R118 confirms the nine modes are physical particles.     NO                                                  The nine modes remain mechanical/operator-geometric seed modes.

## Risk register

                                                               risk severity                                                                                 mitigation
Regularized Green-kernel proxy is mistaken for full GR self-energy.     HIGH                          Label it scalar kernel self-overlap and keep PDE/GR closure open.
  Finite-part extrapolation is mistaken for unique renormalization.     HIGH                       Report regulator sensitivity and mark counterterm prescription open.
          A functional with large dynamic range is chosen post hoc.     HIGH                       No mass data loaded and no final physical mass law selected in R118.
   Virtual supports are promoted to species by attractive F-values.   MEDIUM   Species projection remains inherited from V12.8; F-values do not override admissibility.
                                 Embedding choice R/a is arbitrary.   MEDIUM Treat torus curve as universal representative; future gate must test embedding invariance.

## Next gate

BOXED: FORCE_R119 — Renormalization / Embedding-Invariance Closure Gate
