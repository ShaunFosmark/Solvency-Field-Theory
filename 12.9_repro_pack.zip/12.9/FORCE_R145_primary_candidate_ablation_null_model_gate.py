#!/usr/bin/env python3
"""
FORCE_R145_primary_candidate_ablation_null_model_gate.py

Primary Candidate Ablation / Null Model Gate.

Fast version: null simulations use pure Python scoring instead of per-null pandas frames.

Purpose:
- Compare primary bridge candidates against random monotonic null curves with the same dynamic range.
- Remove full-span endpoint hits from independent-evidence metrics.
- Include raw-feedback and equal-log-spacing controls.
- No retuning, fitting, rho-to-particle mapping, or final law selection.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
import hashlib
import itertools
import json
import math
import random
import shutil
import statistics
import zipfile

import pandas as pd


FORCE_ID = "FORCE_R145"
TITLE = "Primary Candidate Ablation / Null Model Gate"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
OUT = Path("FORCE_R145_primary_candidate_ablation_null_model_gate")
PACK = Path("FORCE_R145_primary_candidate_ablation_null_model_gate_pack.zip")

RANDOM_SEED = 1452029
N_NULL = 2000

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]

RAW_F = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

TARGET_DYN = 338083.0
RAW_DYN = max(RAW_F.values()) / min(RAW_F.values())
BETA_6PI = math.log(6.0 * math.pi) / math.log(RAW_DYN)
BETA_18 = math.log(18.0) / math.log(RAW_DYN)


def flabel(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def canonical_species_formula() -> str:
    return "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class Particle:
    name: str
    sector: str
    mass: float


PARTICLES = [
    Particle("electron", "lepton", 0.51099895),
    Particle("muon", "lepton", 105.6583755),
    Particle("tau", "lepton", 1776.86),
    Particle("up_quark", "quark", 2.16),
    Particle("down_quark", "quark", 4.67),
    Particle("strange_quark", "quark", 93.4),
    Particle("charm_quark", "quark", 1270.0),
    Particle("bottom_quark", "quark", 4198.0),
    Particle("top_quark", "quark", 172760.0),
]


def pct_error(x: float, y: float) -> float:
    return abs(x / y - 1.0) * 100.0


def mass_ratio_records() -> list[dict]:
    rows = []
    for a, b in itertools.combinations(PARTICLES, 2):
        if a.mass >= b.mass:
            hi, lo = a, b
        else:
            hi, lo = b, a
        rows.append({
            "mass_pair": f"{hi.name} vs {lo.name}",
            "ratio": hi.mass / lo.mass,
            "same_sector": hi.sector == lo.sector,
            "lepton_lepton": hi.sector == "lepton" and lo.sector == "lepton",
            "quark_quark": hi.sector == "quark" and lo.sector == "quark",
        })
    return rows


MASS_RECS = mass_ratio_records()


def values_from_beta_gamma(beta: float = 0.0, gamma: float = 0.0) -> dict[Fraction, float]:
    out = {}
    for r, v in RAW_F.items():
        rho_norm = float(r / Fraction(1, 2))
        out[r] = (v ** (1.0 + beta)) * (rho_norm ** gamma)
    return out


def equal_log_values(dynamic_range: float) -> dict[Fraction, float]:
    logs = [i * math.log(dynamic_range) / (len(SEED) - 1) for i in range(len(SEED))]
    return {r: math.exp(x) for r, x in zip(SEED, logs)}


def random_monotonic_values(dynamic_range: float, rng: random.Random) -> dict[Fraction, float]:
    internal = sorted(rng.random() for _ in range(len(SEED) - 2))
    positions = [0.0] + internal + [1.0]
    logs = [p * math.log(dynamic_range) for p in positions]
    return {r: math.exp(x) for r, x in zip(SEED, logs)}


def candidate_values() -> dict[str, dict]:
    return {
        "R137_transverse_phase_volume_6pi_exponent": {
            "tier": "primary", "family": "compound_transverse_lens", "beta": BETA_6PI, "gamma": 0.0,
            "values": values_from_beta_gamma(beta=BETA_6PI, gamma=0.0),
        },
        "R137_oriented_modes_18_exponent": {
            "tier": "primary", "family": "compound_transverse_lens", "beta": BETA_18, "gamma": 0.0,
            "values": values_from_beta_gamma(beta=BETA_18, gamma=0.0),
        },
        "R139_boundary_area_rho2_candidate": {
            "tier": "primary", "family": "boundary_insolvency", "beta": 0.0, "gamma": 2.0,
            "values": values_from_beta_gamma(beta=0.0, gamma=2.0),
        },
        "raw_feedback_control": {
            "tier": "control", "family": "raw_feedback", "beta": 0.0, "gamma": 0.0,
            "values": values_from_beta_gamma(beta=0.0, gamma=0.0),
        },
        "equal_log_spacing_target_control": {
            "tier": "null_control", "family": "equal_log_spacing", "beta": None, "gamma": None,
            "values": equal_log_values(TARGET_DYN),
        },
    }


def pair_ratio_records(values: dict[Fraction, float]) -> list[dict]:
    min_mode = min(values, key=values.get)
    max_mode = max(values, key=values.get)
    endpoint = {min_mode, max_mode}
    rows = []
    for a, b in itertools.combinations(SEED, 2):
        va, vb = values[a], values[b]
        if va >= vb:
            hi, lo, ratio = a, b, va / vb
        else:
            hi, lo, ratio = b, a, vb / va
        rows.append({
            "mode_pair": f"{flabel(hi)} vs {flabel(lo)}",
            "ratio": ratio,
            "endpoint": {hi, lo} == endpoint,
        })
    return rows


def score_fast(values: dict[Fraction, float], threshold_pct: float = 5.0) -> dict:
    pairs = pair_ratio_records(values)
    hits = 0
    hits_ind = 0
    same_ind = 0
    lep_ind = 0
    quark_ind = 0
    best_err_ind = 1e99
    best_match = None
    top_rows = []

    for pr in pairs:
        for mr in MASS_RECS:
            err = pct_error(pr["ratio"], mr["ratio"])
            hit = err <= threshold_pct
            independent = not pr["endpoint"]
            if hit:
                hits += 1
                if independent:
                    hits_ind += 1
                    same_ind += int(mr["same_sector"])
                    lep_ind += int(mr["lepton_lepton"])
                    quark_ind += int(mr["quark_quark"])
            if independent and err < best_err_ind:
                best_err_ind = err
                best_match = {
                    "mode_pair": pr["mode_pair"],
                    "F_ratio": pr["ratio"],
                    "mass_pair": mr["mass_pair"],
                    "err_pct": err,
                    "same_sector": mr["same_sector"],
                    "lepton_lepton": mr["lepton_lepton"],
                    "quark_quark": mr["quark_quark"],
                    "endpoint_dynamic_range_hit": pr["endpoint"],
                }
            if len(top_rows) < 200 or err < max(r["err_pct"] for r in top_rows):
                top_rows.append({
                    "mode_pair": pr["mode_pair"],
                    "F_ratio": pr["ratio"],
                    "mass_pair": mr["mass_pair"],
                    "err_pct": err,
                    "same_sector": mr["same_sector"],
                    "lepton_lepton": mr["lepton_lepton"],
                    "quark_quark": mr["quark_quark"],
                    "endpoint_dynamic_range_hit": pr["endpoint"],
                })
                if len(top_rows) > 200:
                    top_rows = sorted(top_rows, key=lambda x: x["err_pct"])[:100]

    dyn = max(values.values()) / min(values.values())
    return {
        "dynamic_range": dyn,
        "hits_5pct": hits,
        "hits_5pct_independent": hits_ind,
        "same_sector_5pct_independent": same_ind,
        "lepton_5pct_independent": lep_ind,
        "quark_5pct_independent": quark_ind,
        "best_err_pct_independent": best_err_ind,
        "best_match_independent": best_match,
        "top_rows": sorted(top_rows, key=lambda x: x["err_pct"])[:20],
    }


def percentile(sorted_vals: list[float], q: float) -> float:
    if not sorted_vals:
        return float("nan")
    pos = (len(sorted_vals) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return sorted_vals[lo]
    return sorted_vals[lo] * (hi - pos) + sorted_vals[hi] * (pos - lo)


def null_distribution(dynamic_range: float, n: int = N_NULL) -> pd.DataFrame:
    rng = random.Random(RANDOM_SEED + int(round(dynamic_range)))
    rows = []
    for i in range(n):
        vals = random_monotonic_values(dynamic_range, rng)
        s = score_fast(vals)
        rows.append({
            "null_id": i,
            "dynamic_range": dynamic_range,
            "hits_5pct_independent": s["hits_5pct_independent"],
            "same_sector_5pct_independent": s["same_sector_5pct_independent"],
            "lepton_5pct_independent": s["lepton_5pct_independent"],
            "quark_5pct_independent": s["quark_5pct_independent"],
            "best_err_pct_independent": s["best_err_pct_independent"],
        })
    return pd.DataFrame(rows)


def summarize_null(null_df: pd.DataFrame, observed: dict, metric: str, higher_is_more_signal: bool = True) -> dict:
    vals = sorted(null_df[metric].tolist())
    obs = observed[metric]
    if higher_is_more_signal:
        p = sum(v >= obs for v in vals) / len(vals)
    else:
        p = sum(v <= obs for v in vals) / len(vals)
    return {
        f"{metric}_obs": obs,
        f"{metric}_null_mean": statistics.mean(vals),
        f"{metric}_null_p50": percentile(vals, 0.50),
        f"{metric}_null_p90": percentile(vals, 0.90),
        f"{metric}_null_p95": percentile(vals, 0.95),
        f"{metric}_null_p99": percentile(vals, 0.99),
        f"{metric}_empirical_p": p,
    }


def main() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    (OUT / "tables").mkdir()

    cands = candidate_values()
    candidate_blob = json.dumps({
        cid: {
            "tier": c["tier"], "family": c["family"], "beta": c["beta"], "gamma": c["gamma"],
            "values": {flabel(k): v for k, v in c["values"].items()},
        } for cid, c in cands.items()
    }, indent=2, sort_keys=True)
    candidate_freeze_hash = sha256_text(candidate_blob)
    (OUT / "candidate_values_frozen_before_null_generation.json").write_text(candidate_blob, encoding="utf-8")

    mass_df = pd.DataFrame(MASS_RECS)
    mass_ratio_hash = sha256_text(mass_df.to_csv(index=False))
    mass_df.to_csv(OUT / "tables" / "mass_ratio_screen_table_for_null_scoring.csv", index=False)

    observed_rows = []
    top_rows = []
    observed_scores = {}
    for cid, c in cands.items():
        s = score_fast(c["values"])
        observed_scores[cid] = s
        observed_rows.append({
            "candidate_id": cid,
            "tier": c["tier"],
            "family": c["family"],
            "dynamic_range": s["dynamic_range"],
            "hits_5pct": s["hits_5pct"],
            "hits_5pct_independent": s["hits_5pct_independent"],
            "same_sector_5pct_independent": s["same_sector_5pct_independent"],
            "lepton_5pct_independent": s["lepton_5pct_independent"],
            "quark_5pct_independent": s["quark_5pct_independent"],
            "best_err_pct_independent": s["best_err_pct_independent"],
        })
        for tr in s["top_rows"]:
            row = dict(tr)
            row["candidate_id"] = cid
            top_rows.append(row)

    observed_df = pd.DataFrame(observed_rows).sort_values(["tier", "hits_5pct_independent"], ascending=[True, False])
    observed_df.to_csv(OUT / "tables" / "observed_candidate_scores.csv", index=False)
    pd.DataFrame(top_rows).sort_values("err_pct").to_csv(OUT / "tables" / "observed_candidate_top_matches.csv", index=False)

    null_range_keys = {
        "target_dynamic_range_null": TARGET_DYN,
        "R137_6pi_dynamic_range_null": observed_scores["R137_transverse_phase_volume_6pi_exponent"]["dynamic_range"],
        "R139_boundary_dynamic_range_null": observed_scores["R139_boundary_area_rho2_candidate"]["dynamic_range"],
    }

    null_summary_rows = []
    for key, dyn in null_range_keys.items():
        nd = null_distribution(dyn, n=N_NULL)
        nd.to_csv(OUT / "tables" / f"{key}.csv", index=False)
        for cid in ["R137_transverse_phase_volume_6pi_exponent", "R137_oriented_modes_18_exponent", "R139_boundary_area_rho2_candidate"]:
            obs = observed_scores[cid]
            row = {
                "null_key": key,
                "candidate_id": cid,
                "null_dynamic_range": dyn,
                "candidate_dynamic_range": obs["dynamic_range"],
            }
            row.update(summarize_null(nd, obs, "hits_5pct_independent", True))
            row.update(summarize_null(nd, obs, "same_sector_5pct_independent", True))
            row.update(summarize_null(nd, obs, "lepton_5pct_independent", True))
            row.update(summarize_null(nd, obs, "best_err_pct_independent", False))
            null_summary_rows.append(row)

    null_summary_df = pd.DataFrame(null_summary_rows)
    null_summary_df.to_csv(OUT / "tables" / "null_model_summary.csv", index=False)

    ablation = pd.DataFrame([
        {
            "ablation_id": "raw_feedback_no_bridge",
            "interpretation": "Remove bridge correction entirely.",
            "dynamic_range": observed_scores["raw_feedback_control"]["dynamic_range"],
            "hits_5pct_independent": observed_scores["raw_feedback_control"]["hits_5pct_independent"],
            "same_sector_5pct_independent": observed_scores["raw_feedback_control"]["same_sector_5pct_independent"],
            "result": "RANGE_FAIL_BUT_PAIRWISE_SIGNAL_PRESENT",
        },
        {
            "ablation_id": "equal_log_spacing_same_target_range",
            "interpretation": "Keep the full dynamic range but remove SFT-specific internal shape.",
            "dynamic_range": observed_scores["equal_log_spacing_target_control"]["dynamic_range"],
            "hits_5pct_independent": observed_scores["equal_log_spacing_target_control"]["hits_5pct_independent"],
            "same_sector_5pct_independent": observed_scores["equal_log_spacing_target_control"]["same_sector_5pct_independent"],
            "result": "NULL_SHAPE_CONTROL",
        },
        {
            "ablation_id": "primary_bridge_shape_R137_6pi",
            "interpretation": "R137 6pi bridge candidate retains SFT-specific internal shape.",
            "dynamic_range": observed_scores["R137_transverse_phase_volume_6pi_exponent"]["dynamic_range"],
            "hits_5pct_independent": observed_scores["R137_transverse_phase_volume_6pi_exponent"]["hits_5pct_independent"],
            "same_sector_5pct_independent": observed_scores["R137_transverse_phase_volume_6pi_exponent"]["same_sector_5pct_independent"],
            "result": "PRIMARY_SCREEN_SHAPE",
        },
        {
            "ablation_id": "primary_bridge_shape_R139_boundary",
            "interpretation": "R139 boundary bridge candidate retains SFT-specific internal shape.",
            "dynamic_range": observed_scores["R139_boundary_area_rho2_candidate"]["dynamic_range"],
            "hits_5pct_independent": observed_scores["R139_boundary_area_rho2_candidate"]["hits_5pct_independent"],
            "same_sector_5pct_independent": observed_scores["R139_boundary_area_rho2_candidate"]["same_sector_5pct_independent"],
            "result": "PRIMARY_SCREEN_SHAPE",
        },
    ])
    ablation.to_csv(OUT / "tables" / "ablation_summary.csv", index=False)

    primary_null = null_summary_df[null_summary_df["null_key"] == "target_dynamic_range_null"].copy()
    evidence_rows = []
    for row in primary_null.itertuples(index=False):
        p_hits = getattr(row, "hits_5pct_independent_empirical_p")
        p_same = getattr(row, "same_sector_5pct_independent_empirical_p")
        p_lep = getattr(row, "lepton_5pct_independent_empirical_p")
        p_best = getattr(row, "best_err_pct_independent_empirical_p")
        n_sig = sum(p <= 0.05 for p in [p_hits, p_same, p_lep, p_best])
        evidence_rows.append({
            "candidate_id": row.candidate_id,
            "null_key": row.null_key,
            "p_hits_independent": p_hits,
            "p_same_sector": p_same,
            "p_lepton": p_lep,
            "p_best_error": p_best,
            "metrics_p_le_0p05": n_sig,
            "null_result": "UNUSUAL_SCREEN_SIGNAL" if n_sig >= 2 else "NULL_RISK_REMAINS_HIGH",
        })
    evidence_df = pd.DataFrame(evidence_rows)
    evidence_df.to_csv(OUT / "tables" / "evidence_against_null_summary.csv", index=False)

    any_unusual = (evidence_df["null_result"] == "UNUSUAL_SCREEN_SIGNAL").any()
    primary_has_signal = any(
        observed_scores[cid]["hits_5pct_independent"] > 0
        for cid in ["R137_transverse_phase_volume_6pi_exponent", "R137_oriented_modes_18_exponent", "R139_boundary_area_rho2_candidate"]
    )

    claim_boundary = pd.DataFrame([
        {"status": "YES_SCREEN", "claim": "R145 compares primary bridge candidates against random monotonic null curves with matching dynamic range.", "reason": "Null distributions preserve endpoint range but randomize internal shape."},
        {"status": "YES", "claim": "R145 excludes endpoint/range-selected hits from independent evidence.", "reason": "Full-span endpoint hits are not counted as independent surprises."},
        {"status": "YES_SCREEN", "claim": "R145 reports whether internal hits are unusual relative to null controls.", "reason": "Empirical p-values are reported for hit counts, same-sector counts, lepton counts, and best internal error."},
        {"status": "NO", "claim": "R145 proves bridge candidates are physical mass laws.", "reason": "Null-model evidence is screening-only and depends on the chosen null family."},
        {"status": "NO", "claim": "R145 maps rho modes to particles.", "reason": "Only pairwise ratios are scored; no identities are assigned."},
        {"status": "NO", "claim": "R145 closes true GR/PDE dynamics.", "reason": "Field-equation derivation remains open."},
    ])
    claim_boundary.to_csv(OUT / "tables" / "claim_boundary.csv", index=False)

    audit = pd.DataFrame([
        {"test": "candidate_values_frozen_before_null_generation", "result": "PASS", "interpretation": "Candidate values are serialized and hashed before null generation."},
        {"test": "endpoint_hits_removed_from_independent_metric", "result": "PASS", "interpretation": "Full-span endpoint hits are not counted as independent evidence."},
        {"test": "random_monotonic_nulls_generated", "result": "PASS", "interpretation": f"{N_NULL} nulls are generated per dynamic-range family."},
        {"test": "ablation_controls_generated", "result": "PASS", "interpretation": "Raw feedback and equal-log-spacing controls are included."},
        {"test": "primary_internal_signal_present", "result": "PASS" if primary_has_signal else "WARN", "interpretation": "Primary candidates have internal non-endpoint hits."},
        {"test": "null_unusual_signal_present", "result": "PASS" if any_unusual else "OPEN", "interpretation": "At least one candidate is unusual under the current null criteria." if any_unusual else "Null-risk remains high under the current criteria."},
        {"test": "no_final_law_selected", "result": "PASS", "interpretation": "R145 remains a null-model screen only."},
    ])
    audit.to_csv(OUT / "tables" / "gate_audit.csv", index=False)

    verdict = {
        "force_id": FORCE_ID,
        "verdict": "PRIMARY CANDIDATE ABLATION / NULL MODEL SCREEN PASS / NULL RISK QUANTIFIED, FINAL LAW OPEN",
        "freeze_id": FREEZE_ID,
        "candidate_values_frozen_before_null_generation": True,
        "mass_ratio_screen_table_hash": mass_ratio_hash,
        "candidate_freeze_hash": candidate_freeze_hash,
        "random_monotonic_nulls_generated": True,
        "n_null_per_family": N_NULL,
        "endpoint_hits_removed_from_independent_metric": True,
        "ablation_controls_generated": True,
        "primary_internal_signal_present": primary_has_signal,
        "null_unusual_signal_present": bool(any_unusual),
        "no_parameter_fit_performed": True,
        "no_functional_retuning_after_mass_loading": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "physical_mass_spectrum_claimed": False,
        "true_GR_PDE_collective_field_closed": False,
        "selected_seed": "{" + ", ".join(flabel(x) for x in SEED) + "}",
        "canonical_species_formula": canonical_species_formula(),
    }
    (OUT / "FORCE_R145_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

    summary = []
    summary.append(f"# {FORCE_ID} - {TITLE}\n")
    summary.append(f"VERDICT: {verdict['verdict']}\n")
    summary.append(f"FREEZE_ID: {FREEZE_ID}\n")
    summary.append(f"candidate_freeze_hash: {candidate_freeze_hash}\n")
    summary.append(f"N_NULL per family: {N_NULL}\n")
    summary.append("## Observed candidate scores\n")
    summary.append(observed_df.to_string(index=False))
    summary.append("\n\n## Null model summary\n")
    summary.append(null_summary_df.to_string(index=False))
    summary.append("\n\n## Evidence against null summary\n")
    summary.append(evidence_df.to_string(index=False))
    summary.append("\n\n## Ablation summary\n")
    summary.append(ablation.to_string(index=False))
    summary.append("\n\n## Claim boundary\n")
    summary.append(claim_boundary.to_string(index=False))
    (OUT / "FORCE_R145_summary.md").write_text("\n".join(summary), encoding="utf-8")

    try:
        shutil.copy2(Path(__file__).resolve(), OUT / Path(__file__).name)
    except Exception:
        pass

    manifest_rows = []
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            manifest_rows.append({"relative_path": str(p.relative_to(OUT)), "bytes": p.stat().st_size, "sha256": sha256_file(p)})
    pd.DataFrame(manifest_rows).to_csv(OUT / "artifact_manifest.csv", index=False)

    if PACK.exists():
        PACK.unlink()
    with zipfile.ZipFile(PACK, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.rglob("*")):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(OUT.parent)))
    with zipfile.ZipFile(PACK, "r") as z:
        bad = z.testzip()
    zip_ok = bad is None

    print("\n=== COPY/PASTE R145 RESULT ===")
    print("R145 COMPLETE")
    print(f"VERDICT: {verdict['verdict']}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else bad}")
    print("candidate_values_frozen_before_null_generation: True")
    print(f"candidate_freeze_hash: {candidate_freeze_hash}")
    print(f"mass_ratio_screen_table_hash: {mass_ratio_hash}")
    print("random_monotonic_nulls_generated: True")
    print(f"n_null_per_family: {N_NULL}")
    print("endpoint_hits_removed_from_independent_metric: True")
    print("ablation_controls_generated: True")
    print(f"primary_internal_signal_present: {primary_has_signal}")
    print(f"null_unusual_signal_present: {bool(any_unusual)}")
    print("no_parameter_fit_performed: True")
    print("no_functional_retuning_after_mass_loading: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_physical_mass_law_selected: True")
    print("physical_mass_spectrum_claimed: False")
    print("true_GR_PDE_collective_field_closed: False")
    print(f"selected_seed: {verdict['selected_seed']}")
    print(f"canonical_species_formula: {canonical_species_formula()}")
    print("OBSERVED_CANDIDATE_SCORES:")
    for row in observed_df.itertuples(index=False):
        print(f"  {row.candidate_id} | tier={row.tier} | dyn={row.dynamic_range:.6g} | independent<=5%={row.hits_5pct_independent} | same_sector_ind<=5%={row.same_sector_5pct_independent} | lepton_ind<=5%={row.lepton_5pct_independent} | quark_ind<=5%={row.quark_5pct_independent} | best_err_ind={row.best_err_pct_independent:.6g}%")
    print("EVIDENCE_AGAINST_NULL_SUMMARY:")
    for row in evidence_df.itertuples(index=False):
        print(f"  {row.candidate_id} | null={row.null_key} | p_hits={row.p_hits_independent:.4f} | p_same={row.p_same_sector:.4f} | p_lepton={row.p_lepton:.4f} | p_best={row.p_best_error:.4f} | metrics<=0.05={row.metrics_p_le_0p05} | result={row.null_result}")
    print("ABLATION_SUMMARY:")
    for row in ablation.itertuples(index=False):
        print(f"  {row.ablation_id} | dyn={row.dynamic_range:.6g} | independent<=5%={row.hits_5pct_independent} | same_sector_ind<=5%={row.same_sector_5pct_independent} | result={row.result}")
    print("CLAIM_BOUNDARY:")
    for row in claim_boundary.itertuples(index=False):
        print(f"  {row.status} | {row.claim} -- {row.reason}")
    print(f"PACK: {PACK.resolve()}")
    print(f"SUMMARY: {(OUT / 'FORCE_R145_summary.md').resolve()}")
    print("NEXT: FORCE_R128_GR_lag_field_derivation_gate_or_FORCE_R146_V12_9_bridge_screen_rollup_gate")
    print("=== END COPY/PASTE R145 RESULT ===\n")


if __name__ == "__main__":
    main()
