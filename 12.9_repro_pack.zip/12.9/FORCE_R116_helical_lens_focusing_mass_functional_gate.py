from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import hashlib
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# FORCE_R116 — Helical Lens / Focusing Mass Functional Gate
#
# Purpose:
#   Start V12.9-style work without breaking the V12.8 freeze boundary.
#
#   V12.8 gave the mechanical/operator-geometric seed:
#       Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}
#
#   R116 asks a new, strictly pre-mass-matching question:
#       Can we define geometry-native candidate focusing functionals F(rho)
#       for the nine seed modes before comparing to physical particle masses?
#
# Core intuition under audit:
#   - Particles are stable one-speed closure/focusing modes.
#   - Mass is a focusing functional of the mode.
#   - Gravity is the macroscopic gradient of the focusing/concentration.
#   - The nine V12.8 modes are candidate aberration-free support lenses.
#
# Hard guardrails:
#   - No empirical particle masses are loaded.
#   - No SM mapping is attempted.
#   - No fitted parameters are optimized against data.
#   - R116 does NOT claim physical masses.
#   - R116 does NOT close GR/PDE self-energy.
#
# Output:
#   - Geometry table for seed, virtual supports, and controls.
#   - Candidate focusing functional roster.
#   - Blind relative-ratio tables generated before any mass comparison.
#   - Claim boundary and next gate plan.

OUT = Path("FORCE_R116_helical_lens_focusing_mass_functional_gate")
ZIP = Path("FORCE_R116_helical_lens_focusing_mass_functional_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

FORCE_ID = "FORCE_R116"
TITLE = "Helical Lens / Focusing Mass Functional Gate"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
]

VIRTUAL_SUPPORTS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]
CONTROLS = [Fraction(1, 4), Fraction(6, 5), Fraction(7, 5), Fraction(7, 4), Fraction(5, 2)]
ALL_MODES = sorted(set(SEED + VIRTUAL_SUPPORTS + CONTROLS))

ANCHORS = "{1,1/2,1/3}"
CANONICAL_FORMULA = "Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}"

# Geometry constants fixed before any data comparison.
# The minor/major ratio is not optimized. We use a canonical small tube radius
# motivated by the V12.8 1+3 slot capacity: one radial/tube scale out of four slots.
MAJOR_R = 1.0
MINOR_A = 0.25
N_SAMPLES = 360
EPSILON_LIST = [0.03, 0.06, 0.12]

# ---------------------------------------------------------------------
# Utility helpers.
# ---------------------------------------------------------------------

def frac_label(x):
    if isinstance(x, Fraction):
        return str(x)
    return str(x)


def label_set(xs):
    return ", ".join(frac_label(x) for x in sorted(xs)) if xs else "none"


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def classify_mode(rho):
    if rho in SEED:
        return "stable_seed_species"
    if rho in VIRTUAL_SUPPORTS:
        return "virtual_support_not_species"
    return "control_or_intruder"


def species_accept(rho):
    return (rho in SEED)


def support_role(rho):
    if rho in SEED:
        return "stable_species"
    if rho in VIRTUAL_SUPPORTS:
        return "support_only"
    return "control"


def safe_div(a, b):
    if abs(b) < 1e-15:
        return float("nan")
    return a / b

# ---------------------------------------------------------------------
# Geometry model.
# ---------------------------------------------------------------------
# For a rational cadence rho=p/q, build a closed toroidal helix over the
# minimal closure interval q base cycles:
#
#   phi(t) = 2π t
#   psi(t) = 2π rho t
#   gamma(t) = ((R + a cos psi) cos phi,
#               (R + a cos psi) sin phi,
#                a sin psi)
#
# with t in [0, q).  The curve closes because after q base cycles, psi has
# advanced p full normal rotations.  This is a geometry proxy, not a final
# physical worldline solution.


def toroidal_helix_points(rho, n=N_SAMPLES, R=MAJOR_R, a=MINOR_A):
    p = rho.numerator
    q = rho.denominator
    t = np.linspace(0.0, float(q), n, endpoint=False)
    phi = 2.0 * np.pi * t
    psi = 2.0 * np.pi * float(rho) * t
    x = (R + a * np.cos(psi)) * np.cos(phi)
    y = (R + a * np.cos(psi)) * np.sin(phi)
    z = a * np.sin(psi)
    pts = np.column_stack([x, y, z])
    return t, pts


def periodic_derivative(arr, dt):
    return (np.roll(arr, -1, axis=0) - np.roll(arr, 1, axis=0)) / (2.0 * dt)


def periodic_second_derivative(arr, dt):
    return (np.roll(arr, -1, axis=0) - 2.0 * arr + np.roll(arr, 1, axis=0)) / (dt * dt)


def geometry_metrics(rho):
    q = rho.denominator
    t, pts = toroidal_helix_points(rho)
    dt = float(q) / N_SAMPLES

    r1 = periodic_derivative(pts, dt)
    r2 = periodic_second_derivative(pts, dt)
    speed = np.linalg.norm(r1, axis=1)
    ds = speed * dt
    length = float(np.sum(ds))

    cross = np.cross(r1, r2)
    cross_norm = np.linalg.norm(cross, axis=1)
    curvature = cross_norm / np.maximum(speed ** 3, 1e-15)
    mean_curvature = float(np.sum(curvature * ds) / max(length, 1e-15))
    bend_energy = float(np.sum((curvature ** 2) * ds))

    # Regularized line self-overlap integral.  This is a lens/focusing proxy:
    # modes with larger self-proximity at fixed geometry concentrate more path
    # near itself.  Diagonal self-terms are excluded.
    diff = pts[:, None, :] - pts[None, :, :]
    dist2 = np.sum(diff * diff, axis=2)
    w = ds

    overlaps = {}
    overlap_densities = {}
    for eps in EPSILON_LIST:
        kernel = 1.0 / np.sqrt(dist2 + eps * eps)
        np.fill_diagonal(kernel, 0.0)
        raw = 0.5 * float(np.sum((w[:, None] * w[None, :]) * kernel))
        density = raw / max(length * length, 1e-15)
        overlaps[eps] = raw
        overlap_densities[eps] = density

    # Dimensionless analytic proxies, independent of the torus integral.
    x = float(rho)
    analytic_path = math.sqrt(1.0 + x * x)
    analytic_curvature = (x * x) / (1.0 + x * x)
    analytic_pass_curvature = x * analytic_curvature
    analytic_lens = analytic_pass_curvature * analytic_path

    return {
        "rho": frac_label(rho),
        "rho_float": x,
        "numerator_p": rho.numerator,
        "denominator_q": rho.denominator,
        "minimal_base_cycles_q": rho.denominator,
        "normal_turns_p": rho.numerator,
        "class": classify_mode(rho),
        "support_role": support_role(rho),
        "species_accept": species_accept(rho),
        "torus_major_R": MAJOR_R,
        "tube_minor_a": MINOR_A,
        "samples": N_SAMPLES,
        "curve_length": length,
        "mean_curvature": mean_curvature,
        "bend_energy_int_kappa2_ds": bend_energy,
        "self_overlap_eps_0p03": overlaps[0.03],
        "self_overlap_eps_0p06": overlaps[0.06],
        "self_overlap_eps_0p12": overlaps[0.12],
        "overlap_density_eps_0p03": overlap_densities[0.03],
        "overlap_density_eps_0p06": overlap_densities[0.06],
        "overlap_density_eps_0p12": overlap_densities[0.12],
        "analytic_path_sqrt_1_plus_rho2": analytic_path,
        "analytic_curvature_proxy": analytic_curvature,
        "analytic_pass_curvature": analytic_pass_curvature,
        "analytic_lens_proxy": analytic_lens,
    }

# ---------------------------------------------------------------------
# Generate geometry tables.
# ---------------------------------------------------------------------

geometry_rows = [geometry_metrics(rho) for rho in ALL_MODES]
mode_geometry = pd.DataFrame(geometry_rows)

candidate_columns = [
    "rho_float",
    "curve_length",
    "mean_curvature",
    "bend_energy_int_kappa2_ds",
    "self_overlap_eps_0p03",
    "self_overlap_eps_0p06",
    "self_overlap_eps_0p12",
    "overlap_density_eps_0p03",
    "overlap_density_eps_0p06",
    "overlap_density_eps_0p12",
    "analytic_path_sqrt_1_plus_rho2",
    "analytic_curvature_proxy",
    "analytic_pass_curvature",
    "analytic_lens_proxy",
]

# Candidate roster: these are F(rho) candidates.  None are selected by data.
functional_rows = []
for col in candidate_columns:
    seed_vals = mode_geometry[mode_geometry["class"] == "stable_seed_species"][col].astype(float)
    all_vals = mode_geometry[col].astype(float)
    functional_rows.append({
        "functional_id": col,
        "uses_empirical_mass_data": False,
        "geometry_native": True,
        "finite_all_modes": bool(np.isfinite(all_vals).all()),
        "positive_all_modes": bool((all_vals > 0).all()),
        "seed_dynamic_range_max_over_min": float(seed_vals.max() / seed_vals.min()),
        "seed_min_rho_at_function_min": mode_geometry.loc[mode_geometry[mode_geometry["class"] == "stable_seed_species"][col].astype(float).idxmin(), "rho"],
        "seed_max_rho_at_function_max": mode_geometry.loc[mode_geometry[mode_geometry["class"] == "stable_seed_species"][col].astype(float).idxmax(), "rho"],
        "selected_as_physical_mass_law": False,
        "interpretation": (
            "geometry-only candidate focusing functional; blind relative ratios can be generated, "
            "but no physical mass matching is performed in R116"
        ),
    })
functional_roster = pd.DataFrame(functional_rows)

# Relative ratios normalized two ways: to rho=1/2 and to each functional's minimum seed value.
ratio_rows = []
seed_geo = mode_geometry[mode_geometry["class"] == "stable_seed_species"].copy()
base_row = seed_geo[seed_geo["rho"] == "1/2"].iloc[0]
for _, row in seed_geo.iterrows():
    for col in candidate_columns:
        vals = seed_geo[col].astype(float)
        ratio_rows.append({
            "rho": row["rho"],
            "functional_id": col,
            "F_value": float(row[col]),
            "ratio_to_rho_1_2": safe_div(float(row[col]), float(base_row[col])),
            "ratio_to_seed_min": safe_div(float(row[col]), float(vals.min())),
            "rank_within_seed_low_to_high": int(vals.rank(method="min").loc[row.name]),
        })
relative_ratios = pd.DataFrame(ratio_rows)

# Pairwise blind ratios within seed; still no physical mass data.
pairwise_rows = []
for col in candidate_columns:
    vals = {row["rho"]: float(row[col]) for _, row in seed_geo.iterrows()}
    labels = list(vals.keys())
    for i, a in enumerate(labels):
        for b in labels[i+1:]:
            hi = max(vals[a], vals[b])
            lo = min(vals[a], vals[b])
            pairwise_rows.append({
                "functional_id": col,
                "mode_a": a,
                "mode_b": b,
                "ratio_high_over_low": safe_div(hi, lo),
                "larger_F_mode": a if vals[a] >= vals[b] else b,
                "smaller_F_mode": b if vals[a] >= vals[b] else a,
            })
pairwise_blind_ratios = pd.DataFrame(pairwise_rows)

# Virtual support status table.
virtual_status_rows = []
for rho in VIRTUAL_SUPPORTS:
    geo = mode_geometry[mode_geometry["rho"] == frac_label(rho)].iloc[0]
    if rho == Fraction(1, 3):
        reason = "fails_binary_no_overlap"
    elif rho in [Fraction(3, 5), Fraction(4, 5)]:
        reason = "fails_slot_capacity"
    else:
        reason = "not_species"
    virtual_status_rows.append({
        "rho": frac_label(rho),
        "class": geo["class"],
        "support_role": geo["support_role"],
        "species_accept": bool(geo["species_accept"]),
        "geometric_F_values_computed": True,
        "promoted_to_species_by_F": False,
        "species_rejection_reason": reason,
        "interpretation": "Focusing values may be computed for support channels, but support-only modes are not promoted to stable species.",
    })
virtual_support_status = pd.DataFrame(virtual_status_rows)

# Sensitivity of self-overlap under regularization.
sensitivity_rows = []
for _, row in seed_geo.iterrows():
    vals = [float(row["self_overlap_eps_0p03"]), float(row["self_overlap_eps_0p06"]), float(row["self_overlap_eps_0p12"])]
    dens = [float(row["overlap_density_eps_0p03"]), float(row["overlap_density_eps_0p06"]), float(row["overlap_density_eps_0p12"])]
    sensitivity_rows.append({
        "rho": row["rho"],
        "self_overlap_eps_min": min(vals),
        "self_overlap_eps_max": max(vals),
        "self_overlap_eps_spread_frac": safe_div(max(vals) - min(vals), np.mean(vals)),
        "density_eps_min": min(dens),
        "density_eps_max": max(dens),
        "density_eps_spread_frac": safe_div(max(dens) - min(dens), np.mean(dens)),
    })
regularization_sensitivity = pd.DataFrame(sensitivity_rows)

# ---------------------------------------------------------------------
# Audits and claim boundaries.
# ---------------------------------------------------------------------

no_empirical_mass_data_loaded = True
no_mass_matching_performed = True
no_mode_particle_mapping_performed = True
no_parameter_fit_performed = True
geometry_table_generated = bool(len(mode_geometry) == len(ALL_MODES))
seed_all_computed = bool(set(seed_geo["rho"]) == set(frac_label(x) for x in SEED))
virtuals_computed_not_promoted = bool(
    virtual_support_status["geometric_F_values_computed"].all()
    and not virtual_support_status["promoted_to_species_by_F"].any()
)
all_functionals_finite_positive = bool(functional_roster["finite_all_modes"].all() and functional_roster["positive_all_modes"].all())
blind_ratios_generated = bool(len(relative_ratios) > 0 and len(pairwise_blind_ratios) > 0)
regularization_sensitivity_reported = bool(len(regularization_sensitivity) == len(SEED))

# This gate intentionally stays open on physical derivation claims.
dynamic_GR_self_energy_closed = False
full_PDE_mass_functional_closed = False
physical_mass_spectrum_claimed = False
SM_mass_matching_claimed = False
Omega0_claimed = False

candidate_functional_roster_closed = bool(
    geometry_table_generated
    and seed_all_computed
    and virtuals_computed_not_promoted
    and all_functionals_finite_positive
    and blind_ratios_generated
    and regularization_sensitivity_reported
    and no_empirical_mass_data_loaded
    and no_mass_matching_performed
    and no_parameter_fit_performed
)

if candidate_functional_roster_closed:
    verdict_status = "HELICAL LENS FOCUSING FUNCTIONAL CANDIDATE PASS / MASS MATCHING, PDE SELF-ENERGY, AND PHYSICAL SPECTRUM OPEN"
else:
    verdict_status = "HELICAL LENS FOCUSING FUNCTIONAL CANDIDATE INCONCLUSIVE"

gate_audit = pd.DataFrame([
    {
        "test": "geometry_table_generated",
        "result": "PASS" if geometry_table_generated else "WARN",
        "interpretation": "Seed, virtual support, and control modes were assigned geometry-native helical/toroidal lens metrics.",
    },
    {
        "test": "seed_all_computed",
        "result": "PASS" if seed_all_computed else "WARN",
        "interpretation": "All nine V12.8 seed modes were evaluated.",
    },
    {
        "test": "virtuals_computed_not_promoted",
        "result": "PASS" if virtuals_computed_not_promoted else "WARN",
        "interpretation": "Virtual support channels receive F-values but are not promoted to species.",
    },
    {
        "test": "all_functionals_finite_positive",
        "result": "PASS" if all_functionals_finite_positive else "WARN",
        "interpretation": "All candidate focusing functionals are finite and positive on the audited modes.",
    },
    {
        "test": "blind_ratios_generated",
        "result": "PASS" if blind_ratios_generated else "WARN",
        "interpretation": "Blind relative ratios were generated before any empirical mass comparison.",
    },
    {
        "test": "regularization_sensitivity_reported",
        "result": "PASS" if regularization_sensitivity_reported else "WARN",
        "interpretation": "Regularized self-overlap sensitivity was reported for the seed modes.",
    },
    {
        "test": "no_empirical_mass_data_loaded",
        "result": "PASS" if no_empirical_mass_data_loaded else "FAIL",
        "interpretation": "No particle mass table or Standard Model target ratios are loaded in R116.",
    },
    {
        "test": "no_parameter_fit_performed",
        "result": "PASS" if no_parameter_fit_performed else "FAIL",
        "interpretation": "No parameter is optimized against observed masses.",
    },
    {
        "test": "candidate_functional_roster_closed",
        "result": "PASS" if candidate_functional_roster_closed else "WARN",
        "interpretation": "R116 closes a candidate geometry-only F(rho) roster, not a physical mass theory.",
    },
    {
        "test": "dynamic_GR_self_energy_closed",
        "result": "OPEN",
        "interpretation": "A true GR/PDE self-energy derivation remains open.",
    },
    {
        "test": "physical_mass_spectrum_claimed",
        "result": "OPEN",
        "interpretation": "No physical mass spectrum is claimed.",
    },
    {
        "test": "SM_mass_matching_claimed",
        "result": "OPEN",
        "interpretation": "No Standard Model mass matching is claimed.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R116 defines geometry-native candidate focusing functionals F(rho).",
        "status": "YES",
        "reason": "Analytic helical proxies and regularized toroidal self-overlap metrics are computed from rho only.",
    },
    {
        "claim": "R116 compares F(rho) to observed particle masses.",
        "status": "NO",
        "reason": "No empirical masses or SM target ratios are loaded.",
    },
    {
        "claim": "R116 selects a final physical mass law.",
        "status": "NO",
        "reason": "The candidate roster is geometry-only; no candidate is chosen by data.",
    },
    {
        "claim": "R116 promotes virtual supports to stable species if their F-values look interesting.",
        "status": "NO",
        "reason": "Species projection remains inherited from V12.8; virtual supports remain species-inactive.",
    },
    {
        "claim": "R116 closes a true GR/PDE self-energy calculation.",
        "status": "NO",
        "reason": "The self-overlap integral is a toy geometry/focusing proxy, not a solved Einstein-field self-energy calculation.",
    },
    {
        "claim": "R116 claims the nine modes are confirmed particles.",
        "status": "NO",
        "reason": "The nine modes remain a mechanical/operator-geometric seed.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R117",
        "title": "Blind F(rho) Mass-Ratio Comparison Gate",
        "goal": "Freeze candidate F(rho) functions first, then compare blind ratios to external particle-mass ratios without retuning.",
        "must_not_do": "Do not modify F(rho) after seeing mass-ratio comparisons; do not map modes to particles by hand.",
    },
    {
        "next_gate": "FORCE_R118",
        "title": "Analytic Helical Self-Energy Derivation Gate",
        "goal": "Try to replace toy regularized self-overlap with a principled action/PDE or GR-compatible self-energy derivation.",
        "must_not_do": "Do not claim physical masses until the field/action derivation and mass comparison survive controls.",
    },
])

# ---------------------------------------------------------------------
# Save CSV / JSON / summary.
# ---------------------------------------------------------------------

mode_geometry.to_csv(OUT / "FORCE_R116_mode_geometry_table.csv", index=False)
functional_roster.to_csv(OUT / "FORCE_R116_candidate_functional_roster.csv", index=False)
relative_ratios.to_csv(OUT / "FORCE_R116_blind_relative_ratios.csv", index=False)
pairwise_blind_ratios.to_csv(OUT / "FORCE_R116_pairwise_blind_ratios.csv", index=False)
virtual_support_status.to_csv(OUT / "FORCE_R116_virtual_support_status.csv", index=False)
regularization_sensitivity.to_csv(OUT / "FORCE_R116_regularization_sensitivity.csv", index=False)
gate_audit.to_csv(OUT / "FORCE_R116_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R116_claim_boundary.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R116_next_gate_plan.csv", index=False)

verdict = {
    "force_id": FORCE_ID,
    "title": TITLE,
    "status": verdict_status,
    "candidate_functional_roster_closed": candidate_functional_roster_closed,
    "geometry_table_generated": geometry_table_generated,
    "seed_all_computed": seed_all_computed,
    "virtuals_computed_not_promoted": virtuals_computed_not_promoted,
    "all_functionals_finite_positive": all_functionals_finite_positive,
    "blind_ratios_generated": blind_ratios_generated,
    "regularization_sensitivity_reported": regularization_sensitivity_reported,
    "no_empirical_mass_data_loaded": no_empirical_mass_data_loaded,
    "no_mass_matching_performed": no_mass_matching_performed,
    "no_mode_particle_mapping_performed": no_mode_particle_mapping_performed,
    "no_parameter_fit_performed": no_parameter_fit_performed,
    "dynamic_GR_self_energy_closed": dynamic_GR_self_energy_closed,
    "full_PDE_mass_functional_closed": full_PDE_mass_functional_closed,
    "physical_mass_spectrum_claimed": physical_mass_spectrum_claimed,
    "SM_mass_matching_claimed": SM_mass_matching_claimed,
    "Omega0_claimed": Omega0_claimed,
    "selected_seed": [frac_label(x) for x in SEED],
    "canonical_species_formula": CANONICAL_FORMULA,
    "recommended_next": "FORCE_R117_blind_Frho_mass_ratio_comparison_gate",
}
(OUT / "FORCE_R116_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

# Compact tables for readable summary.
seed_focus_cols = [
    "rho", "rho_float", "numerator_p", "denominator_q", "curve_length",
    "bend_energy_int_kappa2_ds", "self_overlap_eps_0p06",
    "overlap_density_eps_0p06", "analytic_lens_proxy"
]
seed_focus_preview = mode_geometry[mode_geometry["class"] == "stable_seed_species"][seed_focus_cols]

functional_preview = functional_roster[[
    "functional_id", "seed_dynamic_range_max_over_min", "seed_min_rho_at_function_min", "seed_max_rho_at_function_max", "selected_as_physical_mass_law"
]]

summary = f"""# FORCE_R116 — Helical Lens / Focusing Mass Functional Gate

## Verdict

BOXED: {verdict_status}

## V12.9-style conceptual seed

BOXED:
Mass is treated as a candidate focusing functional of a stable one-speed closure mode.

BOXED:
Gravity is interpreted as the macroscopic gradient of that focusing/concentration.

BOXED:
The V12.8 nine-mode set remains a mechanical/operator-geometric seed, not a confirmed physical spectrum.

## V12.8 inherited species formula

BOXED:
{CANONICAL_FORMULA}

## Selected seed under audit

BOXED:
{{{label_set(SEED)}}}

## What R116 closes

BOXED:
A geometry-only candidate F(rho) roster and blind ratio tables were generated before any empirical mass comparison.

## What R116 does not close

BOXED:
No physical mass spectrum is claimed.

BOXED:
No Standard Model mass matching is performed.

BOXED:
No GR/PDE self-energy derivation is closed.

BOXED:
No virtual support is promoted to stable species.

## Key booleans

- candidate_functional_roster_closed: {candidate_functional_roster_closed}
- geometry_table_generated: {geometry_table_generated}
- seed_all_computed: {seed_all_computed}
- virtuals_computed_not_promoted: {virtuals_computed_not_promoted}
- all_functionals_finite_positive: {all_functionals_finite_positive}
- blind_ratios_generated: {blind_ratios_generated}
- no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}
- no_parameter_fit_performed: {no_parameter_fit_performed}
- dynamic_GR_self_energy_closed: {dynamic_GR_self_energy_closed}
- physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}

## Gate audit

{gate_audit.to_string(index=False)}

## Seed focusing preview

{seed_focus_preview.to_string(index=False)}

## Candidate functional preview

{functional_preview.to_string(index=False)}

## Virtual support status

{virtual_support_status.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}
"""
(OUT / "FORCE_R116_summary.md").write_text(summary, encoding="utf-8")

# ---------------------------------------------------------------------
# Plots.
# ---------------------------------------------------------------------

plot_seed = seed_geo.copy()
# Use simple Matplotlib defaults; no explicit colors/styles.
for col, filename, title in [
    ("curve_length", "seed_curve_length.png", "R116 Seed curve length by mode"),
    ("bend_energy_int_kappa2_ds", "seed_bend_energy.png", "R116 Seed bending energy by mode"),
    ("self_overlap_eps_0p06", "seed_self_overlap_eps_0p06.png", "R116 Seed self-overlap proxy by mode"),
    ("analytic_lens_proxy", "seed_analytic_lens_proxy.png", "R116 Seed analytic lens proxy by mode"),
]:
    plt.figure(figsize=(9, 5))
    plt.bar(plot_seed["rho"], plot_seed[col].astype(float))
    plt.xlabel("rho")
    plt.ylabel(col)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(PLOTS / filename, dpi=160)
    plt.close()

plt.figure(figsize=(10, 5))
plt.bar(functional_roster["functional_id"], functional_roster["seed_dynamic_range_max_over_min"].astype(float))
plt.xticks(rotation=60, ha="right")
plt.ylabel("seed max/min dynamic range")
plt.title("R116 candidate focusing functional dynamic ranges")
plt.tight_layout()
plt.savefig(PLOTS / "candidate_dynamic_ranges.png", dpi=160)
plt.close()

# ---------------------------------------------------------------------
# Manifest and zip.
# ---------------------------------------------------------------------

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R116_helical_lens_focusing_mass_functional_gate.py")
except Exception:
    pass

manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
manifest = pd.DataFrame(manifest_rows)
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()
zip_integrity_pass = bad is None
verdict["zip_integrity_pass"] = zip_integrity_pass
(OUT / "FORCE_R116_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

# Pretty console tables.
def table_str(df, max_rows=None):
    if max_rows is not None:
        df = df.head(max_rows)
    return df.to_string(index=False)

print("\n=== COPY/PASTE R116 RESULT ===")
print("R116 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"candidate_functional_roster_closed: {candidate_functional_roster_closed}")
print(f"geometry_table_generated: {geometry_table_generated}")
print(f"seed_all_computed: {seed_all_computed}")
print(f"virtuals_computed_not_promoted: {virtuals_computed_not_promoted}")
print(f"all_functionals_finite_positive: {all_functionals_finite_positive}")
print(f"blind_ratios_generated: {blind_ratios_generated}")
print(f"regularization_sensitivity_reported: {regularization_sensitivity_reported}")
print(f"no_empirical_mass_data_loaded: {no_empirical_mass_data_loaded}")
print(f"no_mass_matching_performed: {no_mass_matching_performed}")
print(f"no_mode_particle_mapping_performed: {no_mode_particle_mapping_performed}")
print(f"no_parameter_fit_performed: {no_parameter_fit_performed}")
print(f"dynamic_GR_self_energy_closed: {dynamic_GR_self_energy_closed}")
print(f"full_PDE_mass_functional_closed: {full_PDE_mass_functional_closed}")
print(f"physical_mass_spectrum_claimed: {physical_mass_spectrum_claimed}")
print(f"SM_mass_matching_claimed: {SM_mass_matching_claimed}")
print(f"Omega0_claimed: {Omega0_claimed}")
print(f"selected_seed: {{{label_set(SEED)}}}")
print(f"canonical_species_formula: {CANONICAL_FORMULA}")
print("AUDIT:")
print(table_str(gate_audit))
print("SEED_FOCUSING_PREVIEW:")
print(table_str(seed_focus_preview))
print("CANDIDATE_FUNCTIONAL_ROSTER:")
print(table_str(functional_preview))
print("VIRTUAL_SUPPORT_STATUS:")
print(table_str(virtual_support_status))
print("REGULARIZATION_SENSITIVITY:")
print(table_str(regularization_sensitivity))
print("CLAIM_BOUNDARY:")
print(table_str(claim_boundary))
print("NEXT_GATE_PLAN:")
print(table_str(next_gate_plan))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R116_summary.md').resolve()}")
print("NEXT: FORCE_R117_blind_Frho_mass_ratio_comparison_gate")
print("=== END COPY/PASTE R116 RESULT ===\n")
