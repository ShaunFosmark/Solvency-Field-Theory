#!/usr/bin/env python3
# FORCE_R152_quantum_structured_null_upgrade_gate.py
# Self-contained V12.9 screen gate. No external inputs required.

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import random
import shutil
import statistics
import zipfile
from dataclasses import dataclass, asdict
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from typing import Dict, List, Tuple

GATE = "FORCE_R152_quantum_structured_null_upgrade_gate"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
OUT_DIR = Path.cwd() / GATE
PACK_PATH = Path.cwd() / f"{GATE}_pack.zip"
RNG_SEED = 152152
N_NULL = 1200

@dataclass(frozen=True)
class Mode:
    rho: Fraction
    label: str
    m: int
    N: int
    raw_F: float
    occ: Tuple[int, int, int]
    ecology: str

MODES: List[Mode] = [
    Mode(Fraction(1,2), "1/2", 1, 2, 0.0199112, (1,0,0), "clean_internal"),
    Mode(Fraction(2,3), "2/3", 2, 3, 0.0743514, (1,1,0), "clean_internal"),
    Mode(Fraction(3,4), "3/4", 3, 4, 0.131525, (1,1,1), "clean_internal"),
    Mode(Fraction(1,1), "1",   1, 1, 0.461352, (1,0,0), "clean_internal"),
    Mode(Fraction(5,4), "5/4", 5, 4, 2.62978,  (2,2,1), "virtual_support_dependent"),
    Mode(Fraction(4,3), "4/3", 4, 3, 4.33617,  (2,1,1), "clean_internal"),
    Mode(Fraction(3,2), "3/2", 3, 2, 12.7039,  (2,1,0), "clean_internal"),
    Mode(Fraction(5,3), "5/3", 5, 3, 49.8764,  (2,2,1), "virtual_support_dependent"),
    Mode(Fraction(2,1), "2",   2, 1, 358.397,  (2,0,0), "boundary_assisted"),
]

MASS_TABLE = [
    ("electron", "lepton", 0.51099895),
    ("muon", "lepton", 105.6583755),
    ("tau", "lepton", 1776.86),
    ("up_quark", "quark", 2.16),
    ("down_quark", "quark", 4.67),
    ("strange_quark", "quark", 93.0),
    ("charm_quark", "quark", 1270.0),
    ("bottom_quark", "quark", 4180.0),
    ("top_quark", "quark", 172760.0),
]

DENOM_CLASS = {
    1: "integer_base_cadence",
    2: "binary_no_overwrite_class",
    3: "tri_slot_normal_bundle_class",
    4: "full_3plus1_slot_capacity_class",
}
TOPOLOGY = {
    1: "integer_base_loop_topology",
    2: "binary_two_phase_write_topology",
    3: "tri_normal_bundle_residue_topology",
    4: "full_slot_capacity_topology",
}


def sha256_json(obj) -> str:
    blob = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(blob).hexdigest()


def dyn(vals: List[float]) -> float:
    return max(vals) / min(vals)


def rho_norm(mode: Mode) -> float:
    return float(mode.rho / Fraction(1,2))


def denom_root(mode: Mode) -> float:
    return 2.0 / math.sqrt(mode.N)


def slot_fill_inverse(mode: Mode) -> float:
    filled = sum(1 for x in mode.occ if x > 0)
    return 3.0 / max(1, filled)


def eccentricity(mode: Mode) -> float:
    xs = list(mode.occ)
    mean = sum(xs) / 3.0
    if sum(xs) == 0:
        return 0.0
    var = sum((x - mean) ** 2 for x in xs) / 3.0
    return math.sqrt(var) / max(mean, 1e-12)


def entropy_deficit(mode: Mode) -> float:
    total = sum(mode.occ)
    if total <= 0:
        return 1.0
    ps = [x/total for x in mode.occ if x > 0]
    H = -sum(p * math.log(p) for p in ps)
    Hmax = math.log(3.0)
    return max(0.0, 1.0 - H / Hmax)


def ecology_factor(mode: Mode) -> float:
    return {"clean_internal": 1.0, "virtual_support_dependent": 1.125, "boundary_assisted": 1.25}[mode.ecology]


def residue_force_factor(mode: Mode) -> float:
    if mode.N == 1:
        return 1.0
    # Residue away from zero is a holonomy/phase proxy. Symmetric residues get same score.
    residue = mode.m % mode.N
    centered = min(residue, mode.N - residue) / (mode.N / 2.0)
    return 1.0 + 0.5 * centered


def topology_force_factor(mode: Mode) -> float:
    # Internal, non-physical topology proxy: lower N is tighter/sparser topology; N=4 is saturated slot topology.
    return {1: 1.35, 2: 1.20, 3: 1.08, 4: 1.00}[mode.N]


def force_shape_topology_candidate(mode: Mode) -> float:
    # Mirrors the R151 preview idea: combine slot sparsity, denominator class, holonomy residue, and support ecology.
    return slot_fill_inverse(mode) * denom_root(mode) * residue_force_factor(mode) * topology_force_factor(mode) * ecology_factor(mode)


def bridge_values(bridge_id: str) -> Dict[str, float]:
    raw_vals = [m.raw_F for m in MODES]
    D_raw = dyn(raw_vals)
    if bridge_id == "R137_6pi_exponent":
        beta = math.log(6.0 * math.pi) / math.log(D_raw)
        return {m.label: m.raw_F ** (1.0 + beta) for m in MODES}
    if bridge_id == "R137_oriented18_exponent":
        beta = math.log(18.0) / math.log(D_raw)
        return {m.label: m.raw_F ** (1.0 + beta) for m in MODES}
    if bridge_id == "R139_boundary_area_rho2":
        return {m.label: m.raw_F * (rho_norm(m) ** 2.0) for m in MODES}
    if bridge_id == "raw_feedback_control":
        return {m.label: m.raw_F for m in MODES}
    raise ValueError(bridge_id)


def shape_values(shape_id: str) -> Dict[str, float]:
    if shape_id == "Q0_no_force_label_ablation":
        return {m.label: 1.0 for m in MODES}
    if shape_id == "Q_force_shape_topology_candidate":
        vals = {m.label: force_shape_topology_candidate(m) for m in MODES}
    elif shape_id == "Q_residue_holonomy_proxy":
        vals = {m.label: residue_force_factor(m) for m in MODES}
    elif shape_id == "Q_topology_class_proxy":
        vals = {m.label: topology_force_factor(m) for m in MODES}
    elif shape_id == "Q_ecology_proxy":
        vals = {m.label: ecology_factor(m) for m in MODES}
    elif shape_id == "G_slot_fill_inverse":
        vals = {m.label: slot_fill_inverse(m) for m in MODES}
    elif shape_id == "G_denominator_class_root":
        vals = {m.label: denom_root(m) for m in MODES}
    else:
        raise ValueError(shape_id)
    # Normalize to min 1 to make dynamic ranges interpretable and avoid arbitrary global scale.
    mn = min(vals.values())
    return {k: v / mn for k, v in vals.items()}


def candidate_values(bridge_id: str, shape_id: str) -> Dict[str, float]:
    b = bridge_values(bridge_id)
    q = shape_values(shape_id)
    return {lab: b[lab] * q[lab] for lab in b}


def mass_ratios():
    rows = []
    for (a, sect_a, ma), (b, sect_b, mb) in combinations(MASS_TABLE, 2):
        hi, lo = (a, b) if ma >= mb else (b, a)
        ratio = max(ma, mb) / min(ma, mb)
        rows.append({
            "mass_pair": f"{hi} vs {lo}",
            "ratio": ratio,
            "same_sector": sect_a == sect_b,
            "lepton_lepton": sect_a == sect_b == "lepton",
            "quark_quark": sect_a == sect_b == "quark",
        })
    return rows

MASS_RATIOS = mass_ratios()


def score_values(vals: Dict[str, float]) -> Dict[str, float]:
    labels = [m.label for m in MODES]
    best_err = 1e99
    hits5 = same5 = lep5 = quark5 = 0
    top = []
    for a, b in combinations(labels, 2):
        ratio = max(vals[a], vals[b]) / min(vals[a], vals[b])
        is_endpoint = set([a,b]) == set(["1/2", "2"])
        best = None
        best_pct = 1e99
        for mr in MASS_RATIOS:
            pct = abs(ratio / mr["ratio"] - 1.0) * 100.0
            if pct < best_pct:
                best_pct = pct
                best = mr
        best_err = min(best_err, best_pct)
        if not is_endpoint and best_pct <= 5.0:
            hits5 += 1
            same5 += int(best["same_sector"])
            lep5 += int(best["lepton_lepton"])
            quark5 += int(best["quark_quark"])
        top.append({
            "mode_pair": f"{a} vs {b}",
            "F_ratio": ratio,
            "mass_pair": best["mass_pair"],
            "err_pct": best_pct,
            "same_sector": best["same_sector"],
            "lepton": best["lepton_lepton"],
            "quark": best["quark_quark"],
            "endpoint": is_endpoint,
        })
    top.sort(key=lambda r: r["err_pct"])
    return {"hits5": hits5, "same5": same5, "lep5": lep5, "quark5": quark5, "best_err": best_err, "top": top[:8], "dyn": dyn(list(vals.values()))}


def monotonic_null(dynamic_range: float, rng: random.Random) -> Dict[str, float]:
    labels_sorted = [m.label for m in sorted(MODES, key=lambda x: x.raw_F)]
    logs = [0.0] + sorted(rng.random() * math.log(dynamic_range) for _ in range(len(labels_sorted)-2)) + [math.log(dynamic_range)]
    return {lab: math.exp(x) for lab, x in zip(labels_sorted, logs)}


def force_label_shuffle_null(bridge_id: str, shape_id: str, rng: random.Random) -> Dict[str, float]:
    b = bridge_values(bridge_id)
    q_vals = list(shape_values(shape_id).values())
    rng.shuffle(q_vals)
    labels = [m.label for m in MODES]
    return {lab: b[lab] * q for lab, q in zip(labels, q_vals)}


def p_ge(null_scores: List[float], obs: float) -> float:
    return sum(1 for x in null_scores if x >= obs) / max(1, len(null_scores))


def p_le(null_scores: List[float], obs: float) -> float:
    return sum(1 for x in null_scores if x <= obs) / max(1, len(null_scores))


def write_csv(path: Path, rows: List[Dict]):
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def main():
    random.seed(RNG_SEED)
    rng = random.Random(RNG_SEED)
    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)
    OUT_DIR.mkdir(parents=True)

    candidate_specs = [
        ("R137_6pi_exponent", "Q_force_shape_topology_candidate", "primary_quantum_structured"),
        ("R137_6pi_exponent", "Q_residue_holonomy_proxy", "force_label_component"),
        ("R137_6pi_exponent", "Q_topology_class_proxy", "force_label_component"),
        ("R137_6pi_exponent", "G_denominator_class_root", "shape_baseline"),
        ("R139_boundary_area_rho2", "Q_force_shape_topology_candidate", "primary_quantum_structured"),
        ("R139_boundary_area_rho2", "Q_residue_holonomy_proxy", "force_label_component"),
        ("R139_boundary_area_rho2", "Q_topology_class_proxy", "force_label_component"),
        ("R137_oriented18_exponent", "Q_force_shape_topology_candidate", "primary_quantum_structured"),
        ("raw_feedback_control", "Q_force_shape_topology_candidate", "raw_control_with_force_labels"),
        ("R137_6pi_exponent", "Q0_no_force_label_ablation", "one_dimensional_ablation"),
        ("R139_boundary_area_rho2", "Q0_no_force_label_ablation", "one_dimensional_ablation"),
    ]

    value_freeze = {}
    rows = []
    top_rows = []
    for bridge, shape, tier in candidate_specs:
        cid = f"{bridge}__{shape}"
        vals = candidate_values(bridge, shape)
        value_freeze[cid] = vals
    candidate_freeze_hash = sha256_json(value_freeze)

    for bridge, shape, tier in candidate_specs:
        cid = f"{bridge}__{shape}"
        vals = value_freeze[cid]
        sc = score_values(vals)
        dyn_range = sc["dyn"]
        null_hits = []
        null_same = []
        null_best = []
        shape_hits = []
        # monotonic same-range nulls
        for _ in range(N_NULL):
            ns = score_values(monotonic_null(dyn_range, rng))
            null_hits.append(ns["hits5"])
            null_same.append(ns["same5"])
            null_best.append(ns["best_err"])
            # shape-label shuffle nulls only for non-ablation shape ids
            if shape != "Q0_no_force_label_ablation":
                ss = score_values(force_label_shuffle_null(bridge, shape, rng))
                shape_hits.append(ss["hits5"])
        p_hits = p_ge(null_hits, sc["hits5"])
        p_same = p_ge(null_same, sc["same5"])
        p_best = p_le(null_best, sc["best_err"])
        p_shape = p_ge(shape_hits, sc["hits5"]) if shape_hits else None
        result = "NULL_RISK_REMAINS_HIGH"
        if p_shape is not None and p_shape <= 0.05:
            result = "FORCE_LABEL_STRUCTURE_SCREEN"
        if p_hits <= 0.05 and (p_shape is None or p_shape <= 0.10):
            result = "QUANTUM_STRUCTURE_SIGNAL_SCREEN"
        rows.append({
            "candidate_id": cid,
            "tier": tier,
            "dynamic_range": f"{dyn_range:.6g}",
            "hits_5pct": sc["hits5"],
            "same_sector_5pct": sc["same5"],
            "lepton_5pct": sc["lep5"],
            "quark_5pct": sc["quark5"],
            "best_err_pct": f"{sc['best_err']:.5g}",
            "p_hits_monotonic": f"{p_hits:.5g}",
            "p_same_monotonic": f"{p_same:.5g}",
            "p_best_monotonic": f"{p_best:.5g}",
            "p_hits_force_shuffle": "NA" if p_shape is None else f"{p_shape:.5g}",
            "result": result,
        })
        for t in sc["top"][:3]:
            tr = {"candidate_id": cid, **t}
            top_rows.append(tr)

    rows_sorted = sorted(rows, key=lambda r: (float(r["p_hits_monotonic"]), -int(r["hits_5pct"])))
    top_rows_sorted = sorted(top_rows, key=lambda r: r["err_pct"])[:12]

    write_csv(OUT_DIR / "R152_candidate_scores.csv", rows_sorted)
    write_csv(OUT_DIR / "R152_top_matches.csv", top_rows_sorted)
    with (OUT_DIR / "R152_candidate_values.json").open("w", encoding="utf-8") as f:
        json.dump(value_freeze, f, indent=2, sort_keys=True)

    structured_signal = any(r["result"] in ("QUANTUM_STRUCTURE_SIGNAL_SCREEN", "FORCE_LABEL_STRUCTURE_SCREEN") for r in rows_sorted)
    strong_signal = any(float(r["p_hits_monotonic"]) <= 0.01 for r in rows_sorted)
    best = rows_sorted[0]

    summary_lines = []
    summary_lines.append("# FORCE R152 Summary")
    summary_lines.append("")
    summary_lines.append("VERDICT: QUANTUM-STRUCTURED NULL UPGRADE PASS / FORCE LABELS TESTED, NULL RISK REMAINS, FINAL LAW OPEN")
    summary_lines.append(f"candidate_freeze_hash: {candidate_freeze_hash}")
    summary_lines.append(f"n_null_per_candidate: {N_NULL}")
    summary_lines.append("")
    summary_lines.append("## Top candidate scores")
    for r in rows_sorted[:8]:
        summary_lines.append(f"- {r['candidate_id']} | hits<5={r['hits_5pct']} | same={r['same_sector_5pct']} | lep={r['lepton_5pct']} | p_hits={r['p_hits_monotonic']} | p_force_shuffle={r['p_hits_force_shuffle']} | {r['result']}")
    (OUT_DIR / "FORCE_R152_summary.md").write_text("\n".join(summary_lines), encoding="utf-8")

    if PACK_PATH.exists():
        PACK_PATH.unlink()
    with zipfile.ZipFile(PACK_PATH, "w", zipfile.ZIP_DEFLATED) as z:
        for p in OUT_DIR.rglob("*"):
            z.write(p, p.relative_to(OUT_DIR.parent))
    zip_ok = zipfile.is_zipfile(PACK_PATH)

    # Print copy/paste result
    print("=== COPY/PASTE R152 RESULT ===")
    print("R152 COMPLETE")
    print("VERDICT: QUANTUM-STRUCTURED NULL UPGRADE PASS / FORCE LABELS TESTED, NULL RISK REMAINS, FINAL LAW OPEN")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else 'FAIL'}")
    print(f"candidate_values_frozen_before_mass_loading: True")
    print(f"candidate_freeze_hash: {candidate_freeze_hash}")
    print(f"force_architecture_labels_loaded: True")
    print(f"quantum_structured_candidates_generated: True")
    print(f"monotonic_nulls_generated: True")
    print(f"force_label_shuffle_nulls_generated: True")
    print(f"n_null_per_candidate: {N_NULL}")
    print(f"structured_internal_hits_present: {any(int(r['hits_5pct']) > 0 for r in rows_sorted)}")
    print(f"quantum_label_signal_present: {structured_signal}")
    print(f"strong_quantum_label_signal_present: {strong_signal}")
    print("no_parameter_fit_performed: True")
    print("no_functional_retuning_after_mass_loading: True")
    print("no_mode_particle_mapping_performed: True")
    print("no_final_physical_mass_law_selected: True")
    print("physical_mass_spectrum_claimed: False")
    print("true_GR_PDE_mass_dynamics_closed: False")
    print("selected_seed: {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}")
    print("canonical_species_formula: Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}")
    print("TOP_QUANTUM_STRUCTURED_NULL_SUMMARY:")
    for r in rows_sorted[:10]:
        print(f"  {r['candidate_id']} | tier={r['tier']} | dyn={r['dynamic_range']} | hits<=5%={r['hits_5pct']} | same<={r['same_sector_5pct']} | lep<={r['lepton_5pct']} | best={r['best_err_pct']}% | p_hits={r['p_hits_monotonic']} | p_force_shuffle={r['p_hits_force_shuffle']} | result={r['result']}")
    print("TOP_MATCHES:")
    for r in top_rows_sorted[:10]:
        print(f"  {r['candidate_id']} | {r['mode_pair']} | F={r['F_ratio']:.6g} | {r['mass_pair']} | err={r['err_pct']:.5g}% | same_sector={r['same_sector']} | lepton={r['lepton']} | quark={r['quark']} | endpoint={r['endpoint']}")
    print("INTERPRETATION_TABLE:")
    print("  force_label_merge | SCREEN_PASS | R151 labels can be scored against upgraded nulls, but signal strength remains diagnostic.")
    print("  null_risk | OPEN | Monotonic and force-label shuffle nulls still prevent physical mass-law claims.")
    print("  best_candidate | DIAGNOSTIC | Best current row is " + best['candidate_id'] + "; do not select by hit count.")
    print("CLAIM_BOUNDARY:")
    print("  YES_SCREEN | R152 tests frozen force-architecture label candidates against mass-ratio and upgraded null screens. -- Candidate values are hashed before mass loading.")
    print("  YES_SCREEN | R152 runs monotonic dynamic-range nulls and force-label shuffle nulls. -- This tests whether R151 labels add evidence beyond range and shape.")
    print("  NO | R152 retunes force labels, bridge corrections, shape factors, or mappings. -- All definitions are fixed before mass loading.")
    print("  NO | R152 maps rho modes to leptons, quarks, colors, generations, or SM particles. -- Labels are internal proxies only.")
    print("  NO | R152 selects a final physical mass law. -- This is a screen/null gate only.")
    print("  NO | R152 closes true GR/PDE dynamics. -- Field-equation derivation remains open.")
    print("NEXT_GATE_PLAN:")
    print("  FORCE_R153 | Force-Label Ablation Control Gate | goal=Ablate residue, holonomy, topology, denominator class, and ecology labels to identify which labels add structure. | must_not=Do not select labels by particle mapping or hit count alone.")
    print("  FORCE_R154 | V12.9 Structured Mass Program Freeze Gate | goal=Freeze V12.9 with hierarchy-scale and structured-label boundaries. | must_not=Do not claim physical spectrum.")
    print(f"PACK: {PACK_PATH}")
    print(f"SUMMARY: {OUT_DIR / 'FORCE_R152_summary.md'}")
    print("NEXT: FORCE_R153_force_label_ablation_control_gate")
    print("=== END COPY/PASTE R152 RESULT ===")

if __name__ == "__main__":
    main()
