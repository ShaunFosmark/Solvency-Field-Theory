#!/usr/bin/env python3
"""
FORCE_R144_bridge_candidate_robustness_uncertainty_gate.py

Bridge Candidate Robustness / Uncertainty Gate.

Purpose:
- Freeze the R141/R142 bridge candidate values before loading mass intervals.
- Stress-test R142 primary and secondary bridge screen hits under mass uncertainty ranges.
- Separate endpoint/range-selected hits from internal hits.
- Keep primary/secondary/control tiers separate.
- Do not retune candidate definitions, exponents, boundary powers, or mappings.

Claim boundary:
- This is a robustness screen only.
- It does not select a final mass law.
- It does not map rho modes to particles.
- It does not close GR/PDE dynamics.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
import hashlib
import itertools
import json
import math
import shutil
import zipfile

import pandas as pd


FORCE_ID = "FORCE_R144"
TITLE = "Bridge Candidate Robustness / Uncertainty Gate"
FREEZE_ID = "SFT_V12_9_HELICAL_LENS_MASS_FUNCTIONAL_PROGRAM"
OUT = Path("FORCE_R144_bridge_candidate_robustness_uncertainty_gate")
PACK = Path("FORCE_R144_bridge_candidate_robustness_uncertainty_gate_pack.zip")

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]

RAW_F = {
    Fraction(1, 2): 0.0199112,
    Fraction(2, 3): 0.0743514,
    Fraction(3, 4): 0.131525,
    Fraction(1, 1): 0.461352,
    Fraction(5, 4): 2.62978,
    Fraction(4, 3): 4.33617,
    Fraction(3, 2): 12.7039,
    Fraction(5, 3): 49.8764,
    Fraction(2, 1): 358.397,
}

TARGET_DYN = 338083.0
RAW_DYN = max(RAW_F.values()) / min(RAW_F.values())
BETA_6PI = math.log(6.0 * math.pi) / math.log(RAW_DYN)
BETA_18 = math.log(18.0) / math.log(RAW_DYN)

def flabel(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"

def canonical_species_formula() -> str:
    return "Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def ratio_interval(a_low: float, a_high: float, b_low: float, b_high: float) -> tuple[float, float]:
    vals = [a_low / b_low, a_low / b_high, a_high / b_low, a_high / b_high]
    return min(vals), max(vals)

def interval_distance_fraction(x: float, lo: float, hi: float) -> float:
    if lo <= x <= hi:
        return 0.0
    if x < lo:
        return (lo - x) / lo
    return (x - hi) / hi

def pct(x: float) -> float:
    return 100.0 * x

@dataclass(frozen=True)
class Particle:
    name: str
    sector: str
    central: float
    low: float
    high: float
    note: str

# Compact screening table with deliberately broader uncertainty ranges for quarks.
# Units cancel in ratios; values are MeV-like screening values.
PARTICLES = [
    Particle("electron", "lepton", 0.51099895, 0.51099890, 0.51099900, "direct measured lepton mass; tiny range"),
    Particle("muon", "lepton", 105.6583755, 105.65836, 105.65839, "direct measured lepton mass; tiny range"),
    Particle("tau", "lepton", 1776.86, 1776.70, 1777.02, "direct measured lepton mass; narrow range"),
    Particle("up_quark", "quark", 2.16, 1.55, 2.80, "screening current-quark range; scheme/scale caveat"),
    Particle("down_quark", "quark", 4.67, 4.10, 5.30, "screening current-quark range; scheme/scale caveat"),
    Particle("strange_quark", "quark", 93.4, 80.0, 110.0, "screening current-quark range; scheme/scale caveat"),
    Particle("charm_quark", "quark", 1270.0, 1160.0, 1340.0, "screening heavy-quark range; scheme/scale caveat"),
    Particle("bottom_quark", "quark", 4198.0, 4130.0, 4370.0, "screening heavy-quark range; scheme/scale caveat"),
    Particle("top_quark", "quark", 172760.0, 171700.0, 173900.0, "screening top-quark range; scheme/scale caveat"),
]

def mass_ratio_table() -> pd.DataFrame:
    rows = []
    for a, b in itertools.combinations(PARTICLES, 2):
        # Store larger/smaller central ratio, with conservative interval from corresponding numerator/denominator.
        if a.central >= b.central:
            hi_p, lo_p = a, b
        else:
            hi_p, lo_p = b, a
        lo, hi = ratio_interval(hi_p.low, hi_p.high, lo_p.low, lo_p.high)
        rows.append({
            "mass_pair": f"{hi_p.name} vs {lo_p.name}",
            "hi_particle": hi_p.name,
            "lo_particle": lo_p.name,
            "sector_hi": hi_p.sector,
            "sector_lo": lo_p.sector,
            "same_sector": hi_p.sector == lo_p.sector,
            "lepton_lepton": hi_p.sector == "lepton" and lo_p.sector == "lepton",
            "quark_quark": hi_p.sector == "quark" and lo_p.sector == "quark",
            "central_ratio": hi_p.central / lo_p.central,
            "interval_low": lo,
            "interval_high": hi,
            "range_note": f"{hi_p.note}; {lo_p.note}",
        })
    return pd.DataFrame(rows)

def candidate_values() -> dict[str, dict]:
    def values(beta: float = 0.0, gamma: float = 0.0) -> dict[Fraction, float]:
        out = {}
        for r, v in RAW_F.items():
            rho_norm = float(r / Fraction(1, 2))
            out[r] = (v ** (1.0 + beta)) * (rho_norm ** gamma)
        return out

    return {
        "R137_transverse_phase_volume_6pi_exponent": {
            "tier": "primary",
            "family": "compound_transverse_lens",
            "beta": BETA_6PI,
            "gamma": 0.0,
            "values": values(beta=BETA_6PI, gamma=0.0),
        },
        "R137_oriented_modes_18_exponent": {
            "tier": "primary",
            "family": "compound_transverse_lens",
            "beta": BETA_18,
            "gamma": 0.0,
            "values": values(beta=BETA_18, gamma=0.0),
        },
        "R139_boundary_area_rho2_candidate": {
            "tier": "primary",
            "family": "boundary_insolvency",
            "beta": 0.0,
            "gamma": 2.0,
            "values": values(beta=0.0, gamma=2.0),
        },
        "R140B_partial_slot_beta_boundary_quarter": {
            "tier": "secondary",
            "family": "partial_hybrid_screen",
            "beta": 0.25,
            "gamma": 0.25,
            "values": values(beta=0.25, gamma=0.25),
        },
        "R140B_partial_slot_beta_boundary_half": {
            "tier": "secondary",
            "family": "partial_hybrid_screen",
            "beta": 0.25,
            "gamma": 0.50,
            "values": values(beta=0.25, gamma=0.50),
        },
        "raw_feedback_control": {
            "tier": "control",
            "family": "raw_feedback",
            "beta": 0.0,
            "gamma": 0.0,
            "values": values(beta=0.0, gamma=0.0),
        },
    }

def candidate_dynamic_rows(cands: dict[str, dict]) -> list[dict]:
    rows = []
    for cid, c in cands.items():
        vals = list(c["values"].values())
        dyn = max(vals) / min(vals)
        if dyn >= TARGET_DYN:
            relation = "overshoot"
            factor = dyn / TARGET_DYN
        else:
            relation = "shortfall"
            factor = TARGET_DYN / dyn
        rows.append({
            "candidate_id": cid,
            "tier": c["tier"],
            "family": c["family"],
            "beta": c["beta"],
            "gamma": c["gamma"],
            "dynamic_range": dyn,
            "relation": relation,
            "factor": factor,
            "within_25pct": factor <= 1.25,
            "endpoint_mode_pair": f"{flabel(max(c['values'], key=c['values'].get))} vs {flabel(min(c['values'], key=c['values'].get))}",
        })
    return rows

def pairwise_candidate_ratios(cid: str, c: dict) -> pd.DataFrame:
    rows = []
    vals = c["values"]
    min_mode = min(vals, key=vals.get)
    max_mode = max(vals, key=vals.get)
    endpoint_pair = {min_mode, max_mode}
    for a, b in itertools.combinations(SEED, 2):
        va, vb = vals[a], vals[b]
        if va >= vb:
            hi, lo = a, b
            ratio = va / vb
        else:
            hi, lo = b, a
            ratio = vb / va
        rows.append({
            "candidate_id": cid,
            "tier": c["tier"],
            "family": c["family"],
            "mode_pair": f"{flabel(hi)} vs {flabel(lo)}",
            "hi_mode": flabel(hi),
            "lo_mode": flabel(lo),
            "F_ratio": ratio,
            "endpoint_dynamic_range_hit": {hi, lo} == endpoint_pair,
        })
    return pd.DataFrame(rows)

def compare_to_intervals(cands: dict[str, dict], masses: pd.DataFrame) -> pd.DataFrame:
    rows = []
    cand_ratio_tables = [pairwise_candidate_ratios(cid, c) for cid, c in cands.items()]
    cand_ratios = pd.concat(cand_ratio_tables, ignore_index=True)

    for cr in cand_ratios.itertuples(index=False):
        for mr in masses.itertuples(index=False):
            d = interval_distance_fraction(cr.F_ratio, mr.interval_low, mr.interval_high)
            rows.append({
                "candidate_id": cr.candidate_id,
                "tier": cr.tier,
                "family": cr.family,
                "mode_pair": cr.mode_pair,
                "F_ratio": cr.F_ratio,
                "mass_pair": mr.mass_pair,
                "mass_ratio_central": mr.central_ratio,
                "interval_low": mr.interval_low,
                "interval_high": mr.interval_high,
                "distance_pct": pct(d),
                "inside_interval": d == 0.0,
                "robust_1pct": d <= 0.01,
                "robust_5pct": d <= 0.05,
                "same_sector": mr.same_sector,
                "lepton_lepton": mr.lepton_lepton,
                "quark_quark": mr.quark_quark,
                "endpoint_dynamic_range_hit": cr.endpoint_dynamic_range_hit,
                "independent_internal_hit": not cr.endpoint_dynamic_range_hit,
                "range_note": mr.range_note,
            })
    return pd.DataFrame(rows)

def summarize_thresholds(comp: pd.DataFrame, dyn_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for cid, g in comp.groupby("candidate_id"):
        dyn_row = dyn_df[dyn_df["candidate_id"] == cid].iloc[0]
        independent = g[g["independent_internal_hit"]]
        rows.append({
            "candidate_id": cid,
            "tier": dyn_row["tier"],
            "family": dyn_row["family"],
            "dynamic_range": dyn_row["dynamic_range"],
            "inside_interval": int(g["inside_interval"].sum()),
            "inside_interval_independent": int(independent["inside_interval"].sum()),
            "robust_1pct": int(g["robust_1pct"].sum()),
            "robust_1pct_independent": int(independent["robust_1pct"].sum()),
            "robust_5pct": int(g["robust_5pct"].sum()),
            "robust_5pct_independent": int(independent["robust_5pct"].sum()),
            "same_sector_5pct_independent": int((independent["robust_5pct"] & independent["same_sector"]).sum()),
            "lepton_5pct_independent": int((independent["robust_5pct"] & independent["lepton_lepton"]).sum()),
            "quark_5pct_independent": int((independent["robust_5pct"] & independent["quark_quark"]).sum()),
            "best_distance_pct_independent": float(independent["distance_pct"].min()),
            "warning": "HIGH",
        })
    return pd.DataFrame(rows).sort_values(
        ["tier", "robust_5pct_independent", "same_sector_5pct_independent", "best_distance_pct_independent"],
        ascending=[True, False, False, True],
    )

def main() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    (OUT / "tables").mkdir()
    (OUT / "source_snapshots").mkdir()

    cands = candidate_values()
    candidate_blob = json.dumps({
        cid: {
            "tier": c["tier"], "family": c["family"], "beta": c["beta"], "gamma": c["gamma"],
            "values": {flabel(k): v for k, v in c["values"].items()},
        } for cid, c in cands.items()
    }, indent=2, sort_keys=True)
    candidate_freeze_hash = sha256_text(candidate_blob)
    (OUT / "candidate_values_frozen_before_mass_loading.json").write_text(candidate_blob, encoding="utf-8")

    dyn_df = pd.DataFrame(candidate_dynamic_rows(cands))
    dyn_df.to_csv(OUT / "tables" / "candidate_dynamic_ranges.csv", index=False)

    masses = mass_ratio_table()
    masses.to_csv(OUT / "tables" / "mass_uncertainty_interval_table_loaded_after_freeze.csv", index=False)

    comp = compare_to_intervals(cands, masses)
    comp.to_csv(OUT / "tables" / "candidate_mass_interval_comparisons.csv", index=False)

    # Top robust matches: independent hits first, then inside/near interval, then same-sector.
    top = comp.sort_values(
        ["inside_interval", "distance_pct", "same_sector", "lepton_lepton", "quark_quark"],
        ascending=[False, True, False, False, False],
    ).head(30)
    top.to_csv(OUT / "tables" / "top_robust_matches.csv", index=False)

    thresh = summarize_thresholds(comp, dyn_df)
    thresh.to_csv(OUT / "tables" / "threshold_summary.csv", index=False)

    primary = thresh[thresh["tier"] == "primary"]
    primary_independent_5pct = int(primary["robust_5pct_independent"].sum())
    primary_same_sector_5pct = int(primary["same_sector_5pct_independent"].sum())
    primary_lepton_5pct = int(primary["lepton_5pct_independent"].sum())
    primary_quark_5pct = int(primary["quark_5pct_independent"].sum())

    claim_boundary = pd.DataFrame([
        {"status": "YES_SCREEN", "claim": "R144 stress-tests frozen R141/R142 bridge candidates under mass uncertainty intervals.", "reason": "Candidate values are hashed before uncertainty intervals are loaded."},
        {"status": "NO", "claim": "R144 retunes candidate exponents, boundary powers, or mappings.", "reason": "All beta/gamma definitions are fixed before uncertainty loading."},
        {"status": "YES_SCREEN", "claim": "R144 reports robust interval hits and separates endpoint hits.", "reason": "Inside-interval and 1%/5% robust hits are reported separately from full-span endpoint evidence."},
        {"status": "NO", "claim": "R144 selects a final physical mass law.", "reason": "Robustness evidence is screening-only and retains multiple-comparison/quark-scheme warnings."},
        {"status": "NO", "claim": "R144 maps rho modes to Standard Model particles.", "reason": "Only pairwise ratios are compared; no identities are assigned."},
        {"status": "NO", "claim": "R144 closes true GR/PDE bridge dynamics.", "reason": "The field-equation derivation remains open."},
    ])
    claim_boundary.to_csv(OUT / "tables" / "claim_boundary.csv", index=False)

    audit = pd.DataFrame([
        {"test": "candidate_values_frozen_before_mass_intervals", "result": "PASS", "interpretation": "Candidate values are serialized and hashed before uncertainty intervals are loaded."},
        {"test": "mass_uncertainty_table_loaded_after_freeze", "result": "PASS", "interpretation": "Mass intervals are loaded only after the candidate freeze."},
        {"test": "primary_robust_internal_hits_present", "result": "PASS" if primary_independent_5pct > 0 else "WARN", "interpretation": "Primary candidates retain internal robust hits under uncertainty intervals."},
        {"test": "same_sector_robust_hits_present", "result": "PASS" if primary_same_sector_5pct > 0 else "WARN", "interpretation": "Same-sector robust hits remain after endpoint removal."},
        {"test": "clean_lepton_robust_hit_present", "result": "PASS" if primary_lepton_5pct > 0 else "WARN", "interpretation": "Lepton-lepton robust hits remain after endpoint removal."},
        {"test": "quark_scheme_caveat_retained", "result": "PASS", "interpretation": "Quark interval hits are reported with scheme/range caveats."},
        {"test": "no_mass_law_selected", "result": "PASS", "interpretation": "R144 remains a robustness screen only."},
    ])
    audit.to_csv(OUT / "tables" / "gate_audit.csv", index=False)

    verdict = {
        "force_id": FORCE_ID,
        "verdict": "BRIDGE CANDIDATE ROBUSTNESS / UNCERTAINTY SCREEN PASS / ROBUST HITS REPORTED, FINAL LAW OPEN",
        "freeze_id": FREEZE_ID,
        "candidate_values_frozen_before_mass_intervals": True,
        "mass_uncertainty_table_loaded_after_freeze": True,
        "uncertainty_comparison_generated": True,
        "primary_robust_internal_hits_present": primary_independent_5pct > 0,
        "same_sector_5pct_robust_present": primary_same_sector_5pct > 0,
        "lepton_lepton_5pct_robust_present": primary_lepton_5pct > 0,
        "quark_quark_5pct_robust_present": primary_quark_5pct > 0,
        "endpoint_hits_separated": True,
        "no_parameter_fit_performed": True,
        "no_functional_retuning_after_mass_loading": True,
        "no_mode_particle_mapping_performed": True,
        "no_final_physical_mass_law_selected": True,
        "physical_mass_spectrum_claimed": False,
        "true_GR_PDE_collective_field_closed": False,
        "candidate_freeze_hash": candidate_freeze_hash,
        "selected_seed": "{" + ", ".join(flabel(x) for x in SEED) + "}",
        "canonical_species_formula": canonical_species_formula(),
    }
    (OUT / "FORCE_R144_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

    summary = []
    summary.append(f"# {FORCE_ID} - {TITLE}\n")
    summary.append(f"VERDICT: {verdict['verdict']}\n")
    summary.append(f"FREEZE_ID: {FREEZE_ID}\n")
    summary.append(f"candidate_freeze_hash: {candidate_freeze_hash}\n")
    summary.append("## Candidate dynamic ranges\n")
    summary.append(dyn_df.to_string(index=False))
    summary.append("\n\n## Top robust matches\n")
    summary.append(top[[
        "candidate_id", "tier", "mode_pair", "F_ratio", "mass_pair", "interval_low", "interval_high",
        "distance_pct", "same_sector", "lepton_lepton", "quark_quark", "endpoint_dynamic_range_hit"
    ]].to_string(index=False))
    summary.append("\n\n## Threshold summary\n")
    summary.append(thresh.to_string(index=False))
    summary.append("\n\n## Claim boundary\n")
    summary.append(claim_boundary.to_string(index=False))
    (OUT / "FORCE_R144_summary.md").write_text("\n".join(summary), encoding="utf-8")

    # Copy script into output.
    try:
        shutil.copy2(Path(__file__).resolve(), OUT / Path(__file__).name)
    except Exception:
        pass

    manifest_rows = []
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            manifest_rows.append({"relative_path": str(p.relative_to(OUT)), "bytes": p.stat().st_size, "sha256": sha256_file(p)})
    manifest = pd.DataFrame(manifest_rows)
    manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

    if PACK.exists():
        PACK.unlink()
    with zipfile.ZipFile(PACK, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.rglob("*")):
            if p.is_file():
                z.write(p, arcname=str(p.relative_to(OUT.parent)))
    with zipfile.ZipFile(PACK, "r") as z:
        bad = z.testzip()
    zip_ok = bad is None

    print("\n=== COPY/PASTE R144 RESULT ===")
    print("R144 COMPLETE")
    print(f"VERDICT: {verdict['verdict']}")
    print(f"FREEZE_ID: {FREEZE_ID}")
    print(f"ZIP_INTEGRITY: {'PASS' if zip_ok else bad}")
    print(f"candidate_values_frozen_before_mass_intervals: True")
    print(f"mass_uncertainty_table_loaded_after_freeze: True")
    print(f"uncertainty_comparison_generated: True")
    print(f"primary_robust_internal_hits_present: {primary_independent_5pct > 0}")
    print(f"same_sector_5pct_robust_present: {primary_same_sector_5pct > 0}")
    print(f"lepton_lepton_5pct_robust_present: {primary_lepton_5pct > 0}")
    print(f"quark_quark_5pct_robust_present: {primary_quark_5pct > 0}")
    print(f"endpoint_hits_separated: True")
    print(f"no_parameter_fit_performed: True")
    print(f"no_functional_retuning_after_mass_loading: True")
    print(f"no_mode_particle_mapping_performed: True")
    print(f"no_final_physical_mass_law_selected: True")
    print(f"physical_mass_spectrum_claimed: False")
    print(f"true_GR_PDE_collective_field_closed: False")
    print(f"candidate_freeze_hash: {candidate_freeze_hash}")
    print(f"selected_seed: {verdict['selected_seed']}")
    print(f"canonical_species_formula: {canonical_species_formula()}")
    print("TOP_ROBUST_MATCHES:")
    cols = ["candidate_id", "tier", "mode_pair", "F_ratio", "mass_pair", "interval_low", "interval_high", "distance_pct", "same_sector", "lepton_lepton", "quark_quark", "endpoint_dynamic_range_hit"]
    for row in top[cols].head(15).itertuples(index=False):
        print("  " + " | ".join(f"{col}={getattr(row, col)}" for col in cols))
    print("THRESHOLD_SUMMARY:")
    for row in thresh.itertuples(index=False):
        print(f"  {row.candidate_id} | tier={row.tier} | dyn={row.dynamic_range:.6g} | inside={row.inside_interval} | robust<=1%={row.robust_1pct} | robust<=5%={row.robust_5pct} | independent<=5%={row.robust_5pct_independent} | same_sector_ind<=5%={row.same_sector_5pct_independent} | lepton_ind<=5%={row.lepton_5pct_independent} | quark_ind<=5%={row.quark_5pct_independent} | warning={row.warning}")
    print("CLAIM_BOUNDARY:")
    for row in claim_boundary.itertuples(index=False):
        print(f"  {row.status} | {row.claim} -- {row.reason}")
    print(f"PACK: {PACK.resolve()}")
    print(f"SUMMARY: {(OUT / 'FORCE_R144_summary.md').resolve()}")
    print("NEXT: FORCE_R145_primary_candidate_ablation_null_model_gate_or_FORCE_R128_GR_lag_field_derivation_gate")
    print("=== END COPY/PASTE R144 RESULT ===\n")

if __name__ == "__main__":
    main()
