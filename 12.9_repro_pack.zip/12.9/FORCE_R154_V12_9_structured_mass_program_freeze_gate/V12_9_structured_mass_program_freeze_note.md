# Solvency Field Theory V12.9: Helical Lens Structured Mass-Amplitude Program

**Freeze ID:** `SFT_V12_9_HELICAL_LENS_STRUCTURED_MASS_PROGRAM_FREEZE`

## Safe claim

V12.9 freezes a structured mass-amplitude research program. It preserves a hierarchy-scale bridge screen from helical radius/depth feedback, separates mass amplitude from closure adequacy, downgrades pairwise ratio hits after null controls, and queues a structured mass-functional program using `(rho, m, N, shape, support ecology, force-label proxies)`.

## What is preserved

- The V12.8 nine-mode mechanical/operator-geometric seed is preserved: `1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2`.
- The canonical species formula is preserved: `Species = D_RC({1,1/2,1/3}) intersect {rho >= 1/2} intersect {denom(rho) <= 4}`.
- The mass-amplitude object is distinct from rent-normalized closure adequacy.
- The primary bridge candidates remain screened hierarchy-scale candidates.
- R147-R153 show that internal shape/force labels are informative diagnostics.

## What is not claimed

V12.9 does not derive a physical particle spectrum, Standard Model mapping, final mass law, individual particle masses, Omega0, or a completed covariant GR/PDE derivation.

## Evidence status

| evidence_item | status | what_survives | what_does_not_survive |
|---|---|---|---|
| nine-mode seed | PRESERVED | V12.8 species formula remains locked | not a physical particle spectrum |
| mass-amplitude baseline | PRESERVED | raw feedback is the lead baseline object | under-spans hierarchy by itself |
| closure adequacy | SEPARATED | p=5/p=6 rent-normalized adequacy is stability/existence diagnostic | not the mass functional |
| hierarchy-scale bridge | SCREEN_SURVIVES | primary bridge candidates reach charged-fermion hierarchy scale within screen tolerance | not final law because null/PDE boundaries remain |
| pairwise ratio hits | DOWNGRADED | hits exist and some are clean-screen interesting | R145 nulls show hit counts are not statistically unusual |
| shape structure | HELPFUL_DIAGNOSTIC | slot-fill and denominator-class factors are informative | not enough to close spectrum |
| force labels | LOCALIZED_DIAGNOSTIC | force-label components change score landscape | no strong force-label signal; no mapping |
| true field derivation | OPEN | R128 scalar lag screen supports candidates | covariant/self-consistent GR/PDE not solved |

## Primary bridge candidates

| candidate_id | family | dynamic_range | status | boundary |
|---|---|---|---|---|
| R137_transverse_phase_volume_6pi_exponent | compound_transverse_lens | 339287.651855 | PRIMARY_FIELD_SCREEN_SUPPORTED_SURVIVOR | screen candidate only; exponent entry not derived from full GR/PDE |
| R137_oriented_modes_18_exponent | compound_transverse_lens | 323995.841537 | PRIMARY_FIELD_SCREEN_SUPPORTED_SURVIVOR | screen candidate only; oriented-mode exponent source not final law |
| R139_boundary_area_rho2_candidate | boundary_insolvency | 287996.303588 | PRIMARY_FIELD_SCREEN_SUPPORTED_SURVIVOR | screen candidate only; inverse boundary-area response not full PDE theorem |

## Open problem register

| open_item | status | boundary |
|---|---|---|
| unique mass-amplitude law | OPEN | bridge candidates remain alternative screens |
| covariant GR/PDE derivation | OPEN | R128 is scalar lag/field screen only |
| physical particle identification | OPEN | no rho-to-particle identities assigned |
| Standard Model charges/sectors | OPEN | force labels are proxies, not SM mapping |
| mass hierarchy and individual masses | OPEN | hierarchy-scale screens only; no final mass spectrum |
| null-resistant internal structure | OPEN | R145/R148/R152 keep null risk open |
| Omega0/cosmology | OUT_OF_SCOPE | not addressed by V12.9 structured mass program |
