Recommended sharing package for the unified SFT note
===================================================

Main document (show first)
--------------------------
1. unified_sft_note.pdf
   The integrated note that combines the burden/capacity grammar,
   local compactness screening, the cosmological screen/release bridge,
   and the DESI DR2 alignment discussion.

Support files (share only after the main note or zip alongside it)
-----------------------------------------------------------------
2. paper_table_main.csv
   Headline DESI comparison rows used in the main text.

3. paper_table_appendix.csv
   Broader comparison rows for appendix/supporting discussion.

4. paper_table_notes.txt
   Guardrails for interpreting the comparison bundle.

5. local_gravity_note.pdf
   Standalone technical local-gravity companion.

Editing source
--------------
6. unified_sft_note.tex
   LaTeX source for the integrated note.

Suggested handoff order
-----------------------
A. unified_sft_note.pdf
B. paper_table_main.csv
C. paper_table_appendix.csv
D. local_gravity_note.pdf
E. paper_table_notes.txt

What not to lead with
---------------------
- Internal extraction intermediates
- Raw parser outputs
- Limit-only or unmatched comparison rows as headline evidence

Core posture
------------
- The main note is the thing to show people first.
- The support files exist to backstop the note, not replace it.
- The current best claim is phenomenological alignment plus a coherent local screening extension,
  not proof of a finished fundamental theory.
