from pathlib import Path
from fractions import Fraction
from itertools import combinations
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R100_primitive_anchor_field_origin_gate")
ZIP = Path("FORCE_R100_primitive_anchor_field_origin_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R100 — Primitive Anchor Field-Origin Gate
#
# V12.7 froze the operator-level theorem stack:
#
#   stable candidate = membership in minimal joint R/C support domain
#                      + rho >= 1/2
#                      + denom(rho) <= 4
#
# with support domain generated from:
#
#   {1, 1/2, 1/3}
#
# R100 question:
#
#   Why exactly {1, 1/2, 1/3}?
#
# Candidate origin:
#
#   1     = identity/base cadence anchor
#   1/2   = binary no-overwrite write-cell anchor
#   1/3   = tri-normal virtual support anchor from three transverse normal directions
#
# R100 tests whether these anchors are minimally required by the V12.7
# joint-domain operator, and whether the natural controls fail:
#
#   omit 1       -> lose identity mode
#   omit 1/2     -> lose binary/no-overwrite branch modes
#   omit 1/3     -> lose 5/3 support
#   replace 1/3 with 1/4 -> admits 7/4 intruder and loses 5/3
#   all rationals / no support -> admits 7/4
#
# Claim boundary:
# - This is still an operator-origin gate.
# - It tests whether the primitive anchors are minimally forced by
#   identity + binary write + tri-normal support.
# - It does not derive a full PDE/action field implementation.
# - It does not derive masses, Omega0, or a confirmed physical spectrum.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

HELD_OUT = {
    Fraction(1, 2), Fraction(3, 4), Fraction(1, 1),
    Fraction(3, 2), Fraction(2, 1)
}

V127_ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def R_map(x):
    return Fraction(2, 1) - x

def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def close_domain(anchors, max_den, ops=("R", "C")):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(300):
        before = set(active)

        for x in list(active):
            if "R" in ops:
                y = R_map(x)
                if y == 0:
                    boundary_used = True
                elif in_interval(y) and y in universe:
                    active.add(y)

            if "C" in ops:
                y = C_map(x)
                if in_interval(y) and y in universe:
                    active.add(y)

        if active == before:
            break

    return active, boundary_used

def binary_accept(x):
    return x >= Fraction(1, 2)

def slot_accept(x):
    return x.denominator <= 4

def stable_by_domain(domain, max_den):
    universe = rational_universe(max_den)
    return {
        x for x in universe
        if binary_accept(x)
        and slot_accept(x)
        and x in domain
    }

def stable_from_anchors(anchors, max_den, all_domain=False, no_support=False):
    if no_support:
        domain, boundary_used = close_domain(V127_ANCHORS, max_den, ("R", "C"))
        universe = rational_universe(max_den)
        stable = {
            x for x in universe
            if binary_accept(x)
            and slot_accept(x)
        }
        return domain, stable, boundary_used

    if all_domain:
        domain = rational_universe(max_den)
        stable = stable_by_domain(domain, max_den)
        return domain, stable, True

    domain, boundary_used = close_domain(anchors, max_den, ("R", "C"))
    stable = stable_by_domain(domain, max_den)
    return domain, stable, boundary_used

# ---------------------------------------------------------------------
# 1. Main hypothesis tests.
# ---------------------------------------------------------------------

models = [
    {
        "model": "A0_no_anchors",
        "origin_story": "nothing primitive",
        "anchors": set(),
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "A1_identity_only",
        "origin_story": "identity/base cadence only",
        "anchors": {Fraction(1, 1)},
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "A2_binary_only",
        "origin_story": "binary no-overwrite cell only",
        "anchors": {Fraction(1, 2)},
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "A3_trinormal_only",
        "origin_story": "tri-normal virtual support only",
        "anchors": {Fraction(1, 3)},
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "A4_identity_plus_binary",
        "origin_story": "identity + binary, no tri-normal support",
        "anchors": {Fraction(1, 1), Fraction(1, 2)},
        "expected": "FAIL_MISSING_5_3",
    },
    {
        "model": "A5_identity_plus_trinormal",
        "origin_story": "identity + tri-normal, no binary anchor",
        "anchors": {Fraction(1, 1), Fraction(1, 3)},
        "expected": "FAIL_MISSING_BINARY_BRANCH",
    },
    {
        "model": "A6_binary_plus_trinormal",
        "origin_story": "binary + tri-normal, no identity anchor",
        "anchors": {Fraction(1, 2), Fraction(1, 3)},
        "expected": "FAIL_MISSING_IDENTITY",
    },
    {
        "model": "A7_identity_binary_trinormal",
        "origin_story": "candidate: identity + binary no-overwrite + three normal directions",
        "anchors": {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)},
        "expected": "PASS_EXACT_SEED",
    },
    {
        "model": "A8_identity_binary_fournormal",
        "origin_story": "control: replace tri-normal 1/3 with four-normal 1/4",
        "anchors": {Fraction(1, 1), Fraction(1, 2), Fraction(1, 4)},
        "expected": "FAIL_INTRUDER_AND_MISSING_5_3",
    },
    {
        "model": "A9_identity_binary_trinormal_plus_quarter",
        "origin_story": "control: add 1/4 underwrite anchor",
        "anchors": {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3), Fraction(1, 4)},
        "expected": "FAIL_INTRUDER_7_4",
    },
    {
        "model": "A10_all_rationals_support",
        "origin_story": "control: all rationals allowed as support",
        "anchors": set(),
        "all_domain": True,
        "expected": "FAIL_INTRUDER_7_4",
    },
    {
        "model": "A11_no_support_filter",
        "origin_story": "control: remove support-domain filter",
        "anchors": V127_ANCHORS,
        "no_support": True,
        "expected": "FAIL_INTRUDER_7_4",
    },
]

score_rows = []
interval_rows = []
intruder_rows = []

for model in models:
    exact_all = True
    growth_blocked = True
    final_domain = set()
    final_stable = set()
    final_boundary_used = False

    for max_den in DENOM_AUDITS:
        domain, stable, boundary_used = stable_from_anchors(
            anchors=model["anchors"],
            max_den=max_den,
            all_domain=bool(model.get("all_domain", False)),
            no_support=bool(model.get("no_support", False)),
        )

        final_domain = domain
        final_stable = stable
        final_boundary_used = boundary_used

        extras = sorted(stable - SEED)
        missing = sorted(SEED - stable)
        stable_equals_seed = stable == SEED
        growth_over_seed = len(stable) - len(SEED)

        if not stable_equals_seed:
            exact_all = False
        if growth_over_seed != 0:
            growth_blocked = False

        interval_rows.append({
            "model": model["model"],
            "origin_story": model["origin_story"],
            "anchor_set": label_set(model["anchors"]) if not model.get("all_domain", False) else "all_rationals",
            "max_den": max_den,
            "support_domain_count": len(domain),
            "stable_count": len(stable),
            "stable_fractions": label_set(stable),
            "stable_equals_seed": stable_equals_seed,
            "growth_over_seed": growth_over_seed,
            "extra_vs_seed": label_set(set(extras)),
            "missing_from_seed": label_set(set(missing)),
            "boundary_used": boundary_used,
        })

        if max_den == DENOM_AUDITS[-1]:
            for x in extras:
                intruder_rows.append({
                    "model": model["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": "0_boundary" if R_map(x) == 0 else frac_label(R_map(x)),
                    "C_partner": frac_label(C_map(x)) if C_map(x) else "none",
                    "reason": "admitted_beyond_seed",
                })
            for x in missing:
                intruder_rows.append({
                    "model": model["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": "0_boundary" if R_map(x) == 0 else frac_label(R_map(x)),
                    "C_partner": frac_label(C_map(x)) if C_map(x) else "none",
                    "reason": "seed_mode_rejected",
                })

    hits = len(final_stable & HELD_OUT)
    precision = hits / len(final_stable) if final_stable else 0.0
    recall = hits / len(HELD_OUT)

    if exact_all and model["expected"].startswith("PASS"):
        survivor_status = "PASS_EXACT_SEED"
    elif not exact_all and model["expected"].startswith("FAIL"):
        survivor_status = "PASS_CONTROL_FAILED_AS_EXPECTED"
    elif exact_all and model["expected"].startswith("FAIL"):
        survivor_status = "UNEXPECTED_EXACT_SEED"
    else:
        survivor_status = "PARTIAL"

    is_candidate = model["model"] == "A7_identity_binary_trinormal"

    audit_score = (
        10.0 * int(is_candidate and exact_all)
        + 4.0 * int(exact_all)
        + 2.0 * int(hits == 5)
        - 0.5 * abs(len(final_stable) - len(SEED))
        - 1.0 * int(model.get("all_domain", False))
        - 1.0 * int(model.get("no_support", False))
    )

    score_rows.append({
        "model": model["model"],
        "origin_story": model["origin_story"],
        "anchor_set": label_set(model["anchors"]) if not model.get("all_domain", False) else "all_rationals",
        "support_domain_count_final": len(final_domain),
        "stable_count_final": len(final_stable),
        "stable_fractions_final": label_set(final_stable),
        "posthoc_hits": hits,
        "precision_posthoc": precision,
        "recall_posthoc": recall,
        "exact_seed_all_denominators": exact_all,
        "growth_blocked": growth_blocked,
        "boundary_used_final": final_boundary_used,
        "expected": model["expected"],
        "survivor_status": survivor_status,
        "audit_score": audit_score,
    })

scorecard = pd.DataFrame(score_rows).sort_values(
    ["audit_score", "stable_count_final"],
    ascending=[False, True]
).reset_index(drop=True)

interval_audit = pd.DataFrame(interval_rows)
intruder_audit = pd.DataFrame(intruder_rows)

# ---------------------------------------------------------------------
# 2. Minimal-anchor subset scan.
# ---------------------------------------------------------------------

candidate_pool = [
    Fraction(1, 1), Fraction(1, 2), Fraction(1, 3),
    Fraction(1, 4), Fraction(1, 5)
]

subset_rows = []

for r in range(0, len(candidate_pool) + 1):
    for subset in combinations(candidate_pool, r):
        anchors = set(subset)

        exact_all = True
        final_stable = set()
        final_domain = set()

        for max_den in DENOM_AUDITS:
            domain, stable, _ = stable_from_anchors(anchors, max_den)
            final_stable = stable
            final_domain = domain

            if stable != SEED:
                exact_all = False

        subset_rows.append({
            "anchor_set": label_set(anchors),
            "anchor_count": len(anchors),
            "support_domain_count_final": len(final_domain),
            "stable_count_final": len(final_stable),
            "stable_fractions_final": label_set(final_stable),
            "exact_seed_all_denominators": exact_all,
            "extra_vs_seed": label_set(final_stable - SEED),
            "missing_from_seed": label_set(SEED - final_stable),
            "is_v127_anchor_set": anchors == V127_ANCHORS,
        })

subset_scan = pd.DataFrame(subset_rows).sort_values(
    ["exact_seed_all_denominators", "anchor_count", "anchor_set"],
    ascending=[False, True, True]
).reset_index(drop=True)

exact_subsets = subset_scan[subset_scan["exact_seed_all_denominators"] == True]
if len(exact_subsets):
    min_exact_size = int(exact_subsets["anchor_count"].min())
    minimal_exact = exact_subsets[exact_subsets["anchor_count"] == min_exact_size]
    minimal_exact_unique_v127 = (
        len(minimal_exact) == 1
        and bool(minimal_exact.iloc[0]["is_v127_anchor_set"])
    )
else:
    min_exact_size = None
    minimal_exact_unique_v127 = False

# ---------------------------------------------------------------------
# 3. Identity / binary / tri-normal origin audits.
# ---------------------------------------------------------------------

# Identity anchor: unique fixed point of both R and C in the interval.
universe = rational_universe(max(DENOM_AUDITS))
fixed_rows = []
for x in sorted(universe):
    is_R_fixed = R_map(x) == x
    is_C_fixed = C_map(x) == x
    if is_R_fixed or is_C_fixed:
        fixed_rows.append({
            "fraction": frac_label(x),
            "R_fixed": is_R_fixed,
            "C_fixed": is_C_fixed,
            "both_fixed": is_R_fixed and is_C_fixed,
        })

fixed_point_audit = pd.DataFrame(fixed_rows)
identity_unique_joint_fixed_point = (
    set(Fraction(row["fraction"]) for _, row in fixed_point_audit[fixed_point_audit["both_fixed"]].iterrows())
    == {Fraction(1, 1)}
)

# Tri-normal dimension scan:
# anchor set = {1, 1/2, 1/D_perp}
# Does D_perp=3 uniquely recover the seed among tested dimensions?
dimension_rows = []
for D_perp in [1, 2, 3, 4, 5, 6]:
    normal_anchor = Fraction(1, D_perp)
    anchors = {Fraction(1, 1), Fraction(1, 2), normal_anchor}

    exact_all = True
    final_stable = set()
    for max_den in DENOM_AUDITS:
        _, stable, _ = stable_from_anchors(anchors, max_den)
        final_stable = stable
        if stable != SEED:
            exact_all = False

    dimension_rows.append({
        "D_perp": D_perp,
        "normal_share_anchor": frac_label(normal_anchor),
        "anchor_set": label_set(anchors),
        "stable_count_final": len(final_stable),
        "stable_fractions_final": label_set(final_stable),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(final_stable - SEED),
        "missing_from_seed": label_set(SEED - final_stable),
    })

dimension_scan = pd.DataFrame(dimension_rows)
trinormal_D3_unique = (
    dimension_scan[dimension_scan["exact_seed_all_denominators"] == True]["D_perp"].tolist()
    == [3]
)

# Binary K scan:
# anchor set = {1, 1/K, 1/3}
# Does K=2 uniquely recover the seed among tested K?
K_rows = []
for K in [1, 2, 3, 4, 5, 6]:
    binary_anchor = Fraction(1, K)
    anchors = {Fraction(1, 1), binary_anchor, Fraction(1, 3)}

    exact_all = True
    final_stable = set()
    for max_den in DENOM_AUDITS:
        _, stable, _ = stable_from_anchors(anchors, max_den)
        final_stable = stable
        if stable != SEED:
            exact_all = False

    K_rows.append({
        "K": K,
        "binary_candidate_anchor": frac_label(binary_anchor),
        "anchor_set": label_set(anchors),
        "stable_count_final": len(final_stable),
        "stable_fractions_final": label_set(final_stable),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(final_stable - SEED),
        "missing_from_seed": label_set(SEED - final_stable),
    })

binary_K_scan = pd.DataFrame(K_rows)
binary_K2_unique = (
    binary_K_scan[binary_K_scan["exact_seed_all_denominators"] == True]["K"].tolist()
    == [2]
)

# ---------------------------------------------------------------------
# 4. Verdict booleans.
# ---------------------------------------------------------------------

def score_row(model):
    return scorecard[scorecard["model"] == model].iloc[0]

a7 = score_row("A7_identity_binary_trinormal")
a4 = score_row("A4_identity_plus_binary")
a5 = score_row("A5_identity_plus_trinormal")
a6 = score_row("A6_binary_plus_trinormal")
a8 = score_row("A8_identity_binary_fournormal")
a9 = score_row("A9_identity_binary_trinormal_plus_quarter")
a10 = score_row("A10_all_rationals_support")
a11 = score_row("A11_no_support_filter")

candidate_anchor_set_survives = bool(a7["survivor_status"] == "PASS_EXACT_SEED")
omit_trinormal_fails = bool(a4["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED")
omit_binary_fails = bool(a5["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED")
omit_identity_fails = bool(a6["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED")
fournormal_replacement_fails = bool(a8["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED")
quarter_anchor_expands_intruder = bool(a9["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED")
all_rationals_fail = bool(a10["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED")
no_support_fails = bool(a11["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED")

if (
    candidate_anchor_set_survives
    and omit_trinormal_fails
    and omit_binary_fails
    and omit_identity_fails
    and fournormal_replacement_fails
    and quarter_anchor_expands_intruder
    and all_rationals_fail
    and no_support_fails
    and minimal_exact_unique_v127
    and identity_unique_joint_fixed_point
    and trinormal_D3_unique
    and binary_K2_unique
):
    verdict_status = "PRIMITIVE ANCHOR ORIGIN CANDIDATE PASS / FIELD-ACTION DERIVATION STILL OPEN"
elif candidate_anchor_set_survives and minimal_exact_unique_v127:
    verdict_status = "PRIMITIVE ANCHOR MINIMALITY SIGNAL PASS / SOME ORIGIN CONTROLS SURVIVE"
else:
    verdict_status = "PRIMITIVE ANCHOR ORIGIN INCONCLUSIVE / V12_7 ANCHORS REMAIN OPEN"

audit_df = pd.DataFrame([
    {
        "test": "candidate_anchor_set_survives",
        "result": "PASS" if candidate_anchor_set_survives else "WARN",
        "interpretation": "{1,1/2,1/3} generates the exact V12.7 seed under joint R/C domain membership plus R95/R96 filters.",
    },
    {
        "test": "minimal_exact_unique_v127",
        "result": "PASS" if minimal_exact_unique_v127 else "WARN",
        "interpretation": "Among tested primitive anchor subsets, {1,1/2,1/3} is the unique minimal exact seed generator.",
    },
    {
        "test": "identity_unique_joint_fixed_point",
        "result": "PASS" if identity_unique_joint_fixed_point else "WARN",
        "interpretation": "rho=1 is the unique tested point fixed by both R(rho)=2-rho and C(rho)=1/rho.",
    },
    {
        "test": "binary_K2_unique",
        "result": "PASS" if binary_K2_unique else "WARN",
        "interpretation": "K=2 is the unique tested binary-anchor choice that preserves the exact seed when paired with identity and tri-normal support.",
    },
    {
        "test": "trinormal_D3_unique",
        "result": "PASS" if trinormal_D3_unique else "WARN",
        "interpretation": "D_perp=3 is the unique tested normal-share choice that preserves the exact seed when paired with identity and binary support.",
    },
    {
        "test": "omit_identity_fails",
        "result": "PASS" if omit_identity_fails else "WARN",
        "interpretation": "Without identity/base cadence, the rho=1 seed mode is lost.",
    },
    {
        "test": "omit_binary_fails",
        "result": "PASS" if omit_binary_fails else "WARN",
        "interpretation": "Without the binary no-overwrite anchor, the binary branch is not recovered.",
    },
    {
        "test": "omit_trinormal_fails",
        "result": "PASS" if omit_trinormal_fails else "WARN",
        "interpretation": "Without the tri-normal virtual support anchor, the 5/3 seed mode is lost.",
    },
    {
        "test": "fournormal_replacement_fails",
        "result": "PASS" if fournormal_replacement_fails else "WARN",
        "interpretation": "Replacing 1/3 with 1/4 loses 5/3 and admits 7/4.",
    },
    {
        "test": "quarter_anchor_expands_intruder",
        "result": "PASS" if quarter_anchor_expands_intruder else "WARN",
        "interpretation": "Adding 1/4 over-expands the support domain and admits 7/4.",
    },
    {
        "test": "selectivity_controls",
        "result": "PASS" if (all_rationals_fail and no_support_fails) else "WARN",
        "interpretation": "All-rational support and no support filter both admit 7/4.",
    },
    {
        "test": "field_action_derivation",
        "result": "OPEN",
        "interpretation": "R100 is still operator-origin evidence, not a full field/action derivation.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "{1,1/2,1/3} has an operator-level primitive-origin candidate.",
        "status": "YES",
        "reason": "It is the unique minimal tested anchor set that generates the exact seed under V12.7 filters.",
    },
    {
        "claim": "1 is identified as the identity/base cadence anchor.",
        "status": "YES",
        "reason": "It is the unique tested joint fixed point of R and C and omission loses rho=1.",
    },
    {
        "claim": "1/2 is identified as the binary no-overwrite anchor.",
        "status": "YES",
        "reason": "K=2 is uniquely exact in the tested K-scan, matching the R94/R95 binary result.",
    },
    {
        "claim": "1/3 is identified as the tri-normal virtual support anchor.",
        "status": "YES",
        "reason": "D_perp=3 is uniquely exact in the tested normal-share scan; omission loses 5/3.",
    },
    {
        "claim": "1/3 is a stable species.",
        "status": "NO",
        "reason": "It fails rho>=1/2 and remains a virtual support anchor.",
    },
    {
        "claim": "The primitive anchors are fully derived from local field equations.",
        "status": "NO",
        "reason": "R100 does not provide a PDE/action field derivation.",
    },
    {
        "claim": "This closes V12.8.",
        "status": "NO",
        "reason": "R100 begins V12.8; closure-map and field/action origins remain ahead.",
    },
])

theorem_candidate = pd.DataFrame([
    {
        "layer": 1,
        "anchor": "1",
        "candidate_origin": "identity/base cadence",
        "operator_evidence": "unique tested joint fixed point of R and C; omission loses rho=1",
        "status": "CANDIDATE_PASS",
    },
    {
        "layer": 2,
        "anchor": "1/2",
        "candidate_origin": "binary no-overwrite compact-phase cell",
        "operator_evidence": "K=2 unique tested exact K-anchor; inherited R94/R95 binary update stack",
        "status": "CANDIDATE_PASS",
    },
    {
        "layer": 3,
        "anchor": "1/3",
        "candidate_origin": "three-normal virtual support share",
        "operator_evidence": "D_perp=3 unique tested exact normal-share anchor; omission loses 5/3",
        "status": "CANDIDATE_PASS",
    },
    {
        "layer": 4,
        "anchor": "{1,1/2,1/3}",
        "candidate_origin": "identity + binary write + tri-normal support",
        "operator_evidence": "unique minimal tested exact seed generator",
        "status": "CANDIDATE_PASS",
    },
    {
        "layer": 5,
        "anchor": "field/action implementation",
        "candidate_origin": "local PDE/action derivation",
        "operator_evidence": "not supplied by R100",
        "status": "OPEN",
    },
])

# Save artifacts.
scorecard.to_csv(OUT / "FORCE_R100_anchor_origin_scorecard.csv", index=False)
interval_audit.to_csv(OUT / "FORCE_R100_interval_audit.csv", index=False)
intruder_audit.to_csv(OUT / "FORCE_R100_intruder_and_missing_seed_audit.csv", index=False)
subset_scan.to_csv(OUT / "FORCE_R100_minimal_anchor_subset_scan.csv", index=False)
fixed_point_audit.to_csv(OUT / "FORCE_R100_identity_fixed_point_audit.csv", index=False)
dimension_scan.to_csv(OUT / "FORCE_R100_trinormal_dimension_scan.csv", index=False)
binary_K_scan.to_csv(OUT / "FORCE_R100_binary_K_scan.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R100_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R100_claim_boundary_matrix.csv", index=False)
theorem_candidate.to_csv(OUT / "FORCE_R100_theorem_candidate.csv", index=False)

verdict = {
    "force_id": "FORCE_R100",
    "title": "Primitive Anchor Field-Origin Gate",
    "status": verdict_status,
    "candidate_anchor_set_survives": candidate_anchor_set_survives,
    "minimal_exact_unique_v127": minimal_exact_unique_v127,
    "identity_unique_joint_fixed_point": identity_unique_joint_fixed_point,
    "binary_K2_unique": binary_K2_unique,
    "trinormal_D3_unique": trinormal_D3_unique,
    "omit_identity_fails": omit_identity_fails,
    "omit_binary_fails": omit_binary_fails,
    "omit_trinormal_fails": omit_trinormal_fails,
    "fournormal_replacement_fails": fournormal_replacement_fails,
    "quarter_anchor_expands_intruder": quarter_anchor_expands_intruder,
    "all_rationals_fail": all_rationals_fail,
    "no_support_fails": no_support_fails,
    "field_action_derivation_closed": False,
    "recommended_next": "FORCE_R101_trinormal_virtual_support_anchor_gate",
}
(OUT / "FORCE_R100_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R100 — Primitive Anchor Field-Origin Gate

## Verdict

BOXED: {verdict_status}

## Central result

R100 tests whether the V12.7 primitive anchor set

BOXED: {{1, 1/2, 1/3}}

has an operator-level origin as:

- 1 = identity/base cadence;
- 1/2 = binary no-overwrite cell;
- 1/3 = tri-normal virtual support anchor.

## Candidate anchor set

BOXED: candidate survives = {candidate_anchor_set_survives}

BOXED: unique minimal exact tested anchor set = {minimal_exact_unique_v127}

## Key audits

{audit_df.to_string(index=False)}

## Scorecard

{scorecard.to_string(index=False)}

## Minimal anchor subset scan

{subset_scan.to_string(index=False)}

## Tri-normal dimension scan

{dimension_scan.to_string(index=False)}

## Binary K scan

{binary_K_scan.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Theorem candidate

{theorem_candidate.to_string(index=False)}

## Intruder / missing seed audit

{intruder_audit.to_string(index=False) if len(intruder_audit) else "none"}

## Remaining open item

R100 gives an operator-origin candidate for the primitive anchors. It does not derive the full field/action implementation.

## Recommended next

BOXED: FORCE_R101 — Tri-Normal Virtual Support Anchor Gate
"""
(OUT / "FORCE_R100_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R100_primitive_anchor_field_origin_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R100_summary.md", "role": "summary"},
    {"file": "FORCE_R100_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R100_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R100_anchor_origin_scorecard.csv", "role": "anchor origin scorecard"},
    {"file": "FORCE_R100_interval_audit.csv", "role": "interval audit"},
    {"file": "FORCE_R100_intruder_and_missing_seed_audit.csv", "role": "intruder audit"},
    {"file": "FORCE_R100_minimal_anchor_subset_scan.csv", "role": "minimal subset scan"},
    {"file": "FORCE_R100_identity_fixed_point_audit.csv", "role": "identity fixed-point audit"},
    {"file": "FORCE_R100_trinormal_dimension_scan.csv", "role": "tri-normal dimension scan"},
    {"file": "FORCE_R100_binary_K_scan.csv", "role": "binary K scan"},
    {"file": "FORCE_R100_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R100_theorem_candidate.csv", "role": "theorem candidate"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(12, 5))
plt.bar(scorecard["model"], scorecard["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xticks(rotation=35, ha="right")
plt.ylabel("final stable count")
plt.title("R100 primitive anchor hypotheses")
plt.tight_layout()
plt.savefig(PLOTS / "anchor_hypothesis_stable_counts.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(dimension_scan["D_perp"].astype(str), dimension_scan["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xlabel("D_perp")
plt.ylabel("final stable count")
plt.title("Tri-normal support scan: D_perp=3 is exact")
plt.tight_layout()
plt.savefig(PLOTS / "trinormal_dimension_scan.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(binary_K_scan["K"].astype(str), binary_K_scan["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xlabel("K")
plt.ylabel("final stable count")
plt.title("Binary anchor scan: K=2 is exact")
plt.tight_layout()
plt.savefig(PLOTS / "binary_K_scan.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

compact_scorecard = scorecard[[
    "model", "origin_story", "anchor_set", "support_domain_count_final",
    "stable_count_final", "stable_fractions_final",
    "exact_seed_all_denominators", "survivor_status"
]]

compact_subset = subset_scan[[
    "anchor_set", "anchor_count", "stable_count_final",
    "stable_fractions_final", "exact_seed_all_denominators",
    "is_v127_anchor_set"
]].head(12)

print("\n=== COPY/PASTE R100 RESULT ===")
print("R100 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"candidate_anchor_set_survives: {candidate_anchor_set_survives}")
print(f"minimal_exact_unique_v127: {minimal_exact_unique_v127}")
print(f"identity_unique_joint_fixed_point: {identity_unique_joint_fixed_point}")
print(f"binary_K2_unique: {binary_K2_unique}")
print(f"trinormal_D3_unique: {trinormal_D3_unique}")
print(f"omit_identity_fails: {omit_identity_fails}")
print(f"omit_binary_fails: {omit_binary_fails}")
print(f"omit_trinormal_fails: {omit_trinormal_fails}")
print(f"fournormal_replacement_fails: {fournormal_replacement_fails}")
print(f"quarter_anchor_expands_intruder: {quarter_anchor_expands_intruder}")
print(f"all_rationals_fail: {all_rationals_fail}")
print(f"no_support_fails: {no_support_fails}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("ANCHOR_ORIGIN_SCORECARD:")
print(compact_scorecard.to_string(index=False))
print("MINIMAL_ANCHOR_SUBSET_SCAN_HEAD:")
print(compact_subset.to_string(index=False))
print("TRINORMAL_DIMENSION_SCAN:")
print(dimension_scan.to_string(index=False))
print("BINARY_K_SCAN:")
print(binary_K_scan.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("INTRUDER_AND_MISSING_SEED_AUDIT:")
print(intruder_audit.to_string(index=False) if len(intruder_audit) else "none")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R100_summary.md').resolve()}")
print("NEXT: FORCE_R101_trinormal_virtual_support_anchor_gate")
print("=== END COPY/PASTE R100 RESULT ===\n")
