from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R107_euler_lagrange_constraint_variation_gate")
ZIP = Path("FORCE_R107_euler_lagrange_constraint_variation_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R107 — Euler-Lagrange / Constraint Variation Gate
#
# R106 produced the first no-smuggling candidate action blueprint:
#
#   S = S_phase + S_binary + S_normal + S_R + S_C + S_slot + S_split
#
# R107 asks:
#
#   Do the stationarity equations actually yield the required constraints?
#
# Expected honest result:
#
#   S_R and S_C can pass as formal variational constraint terms:
#
#       S_R = lambda_R (rho + rho_R - 2)^2
#       dS_R/drho_R = 0 -> rho_R = 2 - rho
#
#       S_C = lambda_C (rho*rho_C - 1)^2
#       dS_C/drho_C = 0 -> rho_C = 1/rho
#
#   But binary write, normal-frame origin, slot capacity, and species projection
#   are still constraint/geometric/projection rules, not yet full PDE derivations.
#
# Claim boundary:
# - R107 does not close the full field/PDE theory.
# - R107 only checks formal variation/constraint stationarity.
# - It must preserve open status for binary/normal/species projection PDE origin.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def in_interval(x):
    return x is not None and x > 0 and x <= 2

# Candidate variational constraints from R106.
def R_from_variation(rho, T=Fraction(2, 1)):
    return T - rho

def C_from_variation(rho, A=Fraction(1, 1)):
    if rho == 0:
        return None
    return A / rho

def residual_R(rho, rho_R, T=Fraction(2, 1)):
    return rho + rho_R - T

def residual_C(rho, rho_C, A=Fraction(1, 1)):
    return rho * rho_C - A

def dSR_drhoR(rho, rho_R, lam=Fraction(1, 1), T=Fraction(2, 1)):
    return 2 * lam * residual_R(rho, rho_R, T)

def dSR_drho(rho, rho_R, lam=Fraction(1, 1), T=Fraction(2, 1)):
    return 2 * lam * residual_R(rho, rho_R, T)

def dSC_drhoC(rho, rho_C, lam=Fraction(1, 1), A=Fraction(1, 1)):
    return 2 * lam * rho * residual_C(rho, rho_C, A)

def dSC_drho(rho, rho_C, lam=Fraction(1, 1), A=Fraction(1, 1)):
    return 2 * lam * rho_C * residual_C(rho, rho_C, A)

def close_domain_from_variation(anchors, max_den, T=Fraction(2, 1), A=Fraction(1, 1)):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(900):
        before = set(active)
        for x in list(active):
            r = R_from_variation(x, T=T)
            if r == 0:
                boundary_used = True
            elif in_interval(r) and r in universe:
                active.add(r)

            c = C_from_variation(x, A=A)
            if in_interval(c) and c in universe:
                active.add(c)

        if active == before:
            break

    return active, boundary_used

def stable_by_domain(domain, max_den):
    universe = rational_universe(max_den)
    return {
        x for x in universe
        if x in domain
        and x >= Fraction(1, 2)
        and x.denominator <= 4
    }

# ---------------------------------------------------------------------
# 1. Formal variation table.
# ---------------------------------------------------------------------

variation_terms = pd.DataFrame([
    {
        "term": "S_phase",
        "functional_form": "∫ dτ Kθ (Dτθ - Ω)^2",
        "varied_variable": "Ω",
        "formal_variation": "δS_phase/δΩ = -2Kθ(Dτθ-Ω)",
        "stationary_target": "Ω=Dτθ; identity cadence branch requires normalization",
        "status": "PARTIAL_FORMAL_VARIATION",
        "open_item": "does not yet derive complete clock/cadence PDE",
    },
    {
        "term": "S_binary",
        "functional_form": "Π_no-overlap[write_cell(θ_n), write_cell(θ_{n+1})]",
        "varied_variable": "discrete write update",
        "formal_variation": "not smooth Euler-Lagrange; discrete/KKT-style condition",
        "stationary_target": "cell width 1/2; accept iff Δθ>=1/2",
        "status": "OPEN_DISCRETE_VARIATION",
        "open_item": "needs discrete variational or KKT formulation",
    },
    {
        "term": "S_normal",
        "functional_form": "∫ dτ K_N Σ_i=1^3 ||Dτ n_i||^2",
        "varied_variable": "normal frame n_i",
        "formal_variation": "normal-frame variation gives parallel/elastic frame equation",
        "stationary_target": "D_perp=3 equal-share support anchor 1/3",
        "status": "PARTIAL_GEOMETRIC_INPUT",
        "open_item": "variation does not by itself prove D_perp=3; geometry input remains",
    },
    {
        "term": "S_R",
        "functional_form": "λ_R(ρ+ρ_R-2)^2",
        "varied_variable": "ρ_R",
        "formal_variation": "∂S_R/∂ρ_R = 2λ_R(ρ+ρ_R-2)",
        "stationary_target": "ρ_R=2-ρ",
        "status": "VARIATIONAL_CONSTRAINT_PASS",
        "open_item": "requires interpretation of auxiliary partner variable ρ_R",
    },
    {
        "term": "S_C",
        "functional_form": "λ_C(ρρ_C-1)^2",
        "varied_variable": "ρ_C",
        "formal_variation": "∂S_C/∂ρ_C = 2λ_Cρ(ρρ_C-1)",
        "stationary_target": "ρ_C=1/ρ for ρ≠0",
        "status": "VARIATIONAL_CONSTRAINT_PASS",
        "open_item": "requires interpretation of auxiliary partner variable ρ_C",
    },
    {
        "term": "S_slot",
        "functional_form": "rank_allowed = 1 tangent + 3 normal slots",
        "varied_variable": "topological/rank data",
        "formal_variation": "not ordinary smooth variation",
        "stationary_target": "denom(ρ)<=4",
        "status": "OPEN_TOPOLOGICAL_CONSTRAINT",
        "open_item": "needs topological/rank-capacity derivation",
    },
    {
        "term": "S_split",
        "functional_form": "species_domain = support_domain ∩ binary_filter ∩ slot_filter",
        "varied_variable": "projection map",
        "formal_variation": "projection rule, not Euler-Lagrange yet",
        "stationary_target": "support-active virtual modes are species-inactive",
        "status": "OPEN_PROJECTION_DERIVATION",
        "open_item": "needs derivation of support-to-species projection",
    },
])

# ---------------------------------------------------------------------
# 2. Numeric/formal stationarity checks for R and C.
# ---------------------------------------------------------------------

test_modes = sorted(SEED | VIRTUAL_SUPPORTS | {Fraction(1, 4), Fraction(7, 4), Fraction(6, 5), Fraction(7, 5)})
stationarity_rows = []

for rho in test_modes:
    rho_R = R_from_variation(rho)
    rho_C = C_from_variation(rho)

    R_res = residual_R(rho, rho_R)
    C_res = residual_C(rho, rho_C) if rho_C is not None else None

    stationarity_rows.append({
        "rho": frac_label(rho),
        "rho_float": float(rho),
        "R_partner_from_variation": frac_label(rho_R),
        "R_residual_rho_plus_rhoR_minus_2": frac_label(R_res),
        "dSR_drhoR": frac_label(dSR_drhoR(rho, rho_R)),
        "R_stationary_pass": R_res == 0 and dSR_drhoR(rho, rho_R) == 0,
        "C_partner_from_variation": frac_label(rho_C),
        "C_residual_rho_rhoC_minus_1": frac_label(C_res),
        "dSC_drhoC": frac_label(dSC_drhoC(rho, rho_C)) if rho_C is not None else "none",
        "C_stationary_pass": rho_C is not None and C_res == 0 and dSC_drhoC(rho, rho_C) == 0,
        "combined_dS_drho_at_constraints": frac_label(
            dSR_drho(rho, rho_R) + dSC_drho(rho, rho_C)
        ) if rho_C is not None else "none",
        "combined_stationary_when_constraints_satisfied": (
            rho_C is not None
            and dSR_drho(rho, rho_R) + dSC_drho(rho, rho_C) == 0
        ),
    })

stationarity_audit = pd.DataFrame(stationarity_rows)

R_variation_pass = bool(stationarity_audit["R_stationary_pass"].all())
C_variation_pass = bool(stationarity_audit["C_stationary_pass"].all())
combined_stationarity_pass = bool(stationarity_audit["combined_stationary_when_constraints_satisfied"].all())

# ---------------------------------------------------------------------
# 3. Wrong-stationarity controls.
# ---------------------------------------------------------------------

wrong_rows = []

wrong_controls = [
    {
        "control": "wrong_R_total_T_3_2",
        "T": Fraction(3, 2),
        "A": Fraction(1, 1),
        "expected": "FAIL_WRONG_R",
    },
    {
        "control": "wrong_R_total_T_5_2",
        "T": Fraction(5, 2),
        "A": Fraction(1, 1),
        "expected": "FAIL_WRONG_R",
    },
    {
        "control": "wrong_C_product_A_2_3",
        "T": Fraction(2, 1),
        "A": Fraction(2, 3),
        "expected": "FAIL_WRONG_C",
    },
    {
        "control": "wrong_C_product_A_3_2",
        "T": Fraction(2, 1),
        "A": Fraction(3, 2),
        "expected": "FAIL_WRONG_C",
    },
]

for ctl in wrong_controls:
    domain, _ = close_domain_from_variation(ANCHORS, max(DENOM_AUDITS), T=ctl["T"], A=ctl["A"])
    stable = stable_by_domain(domain, max(DENOM_AUDITS))
    exact = stable == SEED

    wrong_rows.append({
        "control": ctl["control"],
        "T": frac_label(ctl["T"]),
        "A": frac_label(ctl["A"]),
        "domain_count": len(domain),
        "stable_count": len(stable),
        "stable_fractions": label_set(stable),
        "exact_seed": exact,
        "extra_vs_seed": label_set(stable - SEED),
        "missing_from_seed": label_set(SEED - stable),
        "expected": ctl["expected"],
        "control_status": "PASS_CONTROL_FAILED_AS_EXPECTED" if not exact else "UNEXPECTED_EXACT_SEED",
    })

wrong_constraint_controls = pd.DataFrame(wrong_rows)
wrong_controls_fail = bool((wrong_constraint_controls["control_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED").all())

# ---------------------------------------------------------------------
# 4. Operator reconstruction from varied R/C constraints.
# ---------------------------------------------------------------------

reconstruction_rows = []

for max_den in DENOM_AUDITS:
    domain, boundary_used = close_domain_from_variation(ANCHORS, max_den, T=Fraction(2, 1), A=Fraction(1, 1))
    stable = stable_by_domain(domain, max_den)

    reconstruction_rows.append({
        "max_den": max_den,
        "domain_count": len(domain),
        "stable_count": len(stable),
        "stable_fractions": label_set(stable),
        "exact_seed": stable == SEED,
        "extra_vs_seed": label_set(stable - SEED),
        "missing_from_seed": label_set(SEED - stable),
        "boundary_used": boundary_used,
    })

operator_reconstruction = pd.DataFrame(reconstruction_rows)

operator_reconstruction_exact = bool(operator_reconstruction["exact_seed"].all())

domain_full, boundary_used = close_domain_from_variation(ANCHORS, max(DENOM_AUDITS))
stable_full = stable_by_domain(domain_full, max(DENOM_AUDITS))

virtual_support_split_pass = all(
    v in domain_full and v not in stable_full
    for v in VIRTUAL_SUPPORTS
)
intruder_7_4_excluded = Fraction(7, 4) not in domain_full and Fraction(7, 4) not in stable_full

# ---------------------------------------------------------------------
# 5. Term closure classification.
# ---------------------------------------------------------------------

term_closure = pd.DataFrame([
    {
        "term": "S_phase",
        "variation_status": "PARTIAL",
        "operator_target": "identity cadence 1",
        "closed_by_R107": False,
        "reason": "formal cadence normalization only; full clock PDE remains open",
    },
    {
        "term": "S_binary",
        "variation_status": "OPEN",
        "operator_target": "1/2 and rho>=1/2",
        "closed_by_R107": False,
        "reason": "requires discrete/KKT no-overlap variational principle",
    },
    {
        "term": "S_normal",
        "variation_status": "PARTIAL",
        "operator_target": "1/3 and 1+3 slot capacity",
        "closed_by_R107": False,
        "reason": "normal-frame action present but D_perp=3 remains geometric input",
    },
    {
        "term": "S_R",
        "variation_status": "PASS",
        "operator_target": "R(rho)=2-rho",
        "closed_by_R107": True,
        "reason": "auxiliary variation gives rho_R=2-rho",
    },
    {
        "term": "S_C",
        "variation_status": "PASS",
        "operator_target": "C(rho)=1/rho",
        "closed_by_R107": True,
        "reason": "auxiliary variation gives rho_C=1/rho for rho != 0",
    },
    {
        "term": "S_slot",
        "variation_status": "OPEN",
        "operator_target": "denom(rho)<=4",
        "closed_by_R107": False,
        "reason": "topological/rank capacity derivation remains open",
    },
    {
        "term": "S_split",
        "variation_status": "OPEN",
        "operator_target": "support/species projection",
        "closed_by_R107": False,
        "reason": "projection still not derived from Euler-Lagrange flow",
    },
])

closed_terms = int(term_closure["closed_by_R107"].sum())
open_or_partial_terms = int(len(term_closure) - closed_terms)

RC_variational_constraints_closed = (
    R_variation_pass
    and C_variation_pass
    and combined_stationarity_pass
)

binary_normal_projection_still_open = bool(
    not term_closure[term_closure["term"].isin(["S_binary", "S_normal", "S_slot", "S_split"])]["closed_by_R107"].any()
)

full_variational_PDE_closed = False
physical_spectrum_claimed = False

# ---------------------------------------------------------------------
# 6. Verdict.
# ---------------------------------------------------------------------

if (
    RC_variational_constraints_closed
    and wrong_controls_fail
    and operator_reconstruction_exact
    and virtual_support_split_pass
    and intruder_7_4_excluded
    and binary_normal_projection_still_open
    and not full_variational_PDE_closed
):
    verdict_status = "R/C VARIATIONAL CONSTRAINT PASS / DISCRETE BINARY-NORMAL-SPECIES PDE DERIVATION OPEN"
elif RC_variational_constraints_closed and operator_reconstruction_exact:
    verdict_status = "R/C VARIATIONAL SIGNAL PASS / SOME DERIVATION CONTROLS OPEN"
else:
    verdict_status = "EULER-LAGRANGE CONSTRAINT VARIATION INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "R_variation_pass",
        "result": "PASS" if R_variation_pass else "WARN",
        "interpretation": "Variation of S_R with respect to rho_R yields rho_R=2-rho.",
    },
    {
        "test": "C_variation_pass",
        "result": "PASS" if C_variation_pass else "WARN",
        "interpretation": "Variation of S_C with respect to rho_C yields rho_C=1/rho for rho!=0.",
    },
    {
        "test": "combined_stationarity_pass",
        "result": "PASS" if combined_stationarity_pass else "WARN",
        "interpretation": "When both constraints are satisfied, the combined rho derivative from S_R+S_C vanishes.",
    },
    {
        "test": "wrong_controls_fail",
        "result": "PASS" if wrong_controls_fail else "WARN",
        "interpretation": "Wrong R totals and wrong C products fail to reconstruct the exact seed.",
    },
    {
        "test": "operator_reconstruction_exact",
        "result": "PASS" if operator_reconstruction_exact else "WARN",
        "interpretation": "Using the varied R/C constraints with the R100-R104 filters reconstructs the exact seed.",
    },
    {
        "test": "virtual_support_split_pass",
        "result": "PASS" if virtual_support_split_pass else "WARN",
        "interpretation": "1/3, 3/5, and 4/5 remain support-active but species-inactive.",
    },
    {
        "test": "intruder_7_4_excluded",
        "result": "PASS" if intruder_7_4_excluded else "WARN",
        "interpretation": "The 7/4 intruder remains excluded.",
    },
    {
        "test": "binary_normal_projection_still_open",
        "result": "PASS" if binary_normal_projection_still_open else "WARN",
        "interpretation": "R107 honestly keeps binary/no-overlap, normal-frame origin, slot cap, and projection derivations open.",
    },
    {
        "test": "full_variational_PDE_closed",
        "result": "OPEN",
        "interpretation": "R107 does not close the full PDE/action derivation.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R107 variationally derives R(rho)=2-rho from S_R.",
        "status": "YES",
        "reason": "∂S_R/∂rho_R=0 gives rho_R=2-rho for lambda_R nonzero.",
    },
    {
        "claim": "R107 variationally derives C(rho)=1/rho from S_C.",
        "status": "YES",
        "reason": "∂S_C/∂rho_C=0 gives rho_C=1/rho for rho nonzero and lambda_C nonzero.",
    },
    {
        "claim": "R107 derives the binary no-overlap rule as a smooth Euler-Lagrange equation.",
        "status": "NO",
        "reason": "Binary write/no-overlap remains a discrete or KKT-style variational problem.",
    },
    {
        "claim": "R107 derives D_perp=3 from the normal-frame action.",
        "status": "NO",
        "reason": "The normal-frame term supports the geometry, but D_perp=3 remains a geometric input here.",
    },
    {
        "claim": "R107 derives the slot-capacity denominator filter from variation.",
        "status": "NO",
        "reason": "The slot filter remains a topological/rank-capacity rule.",
    },
    {
        "claim": "R107 derives support-to-species projection from Euler-Lagrange flow.",
        "status": "NO",
        "reason": "The projection remains open and should be tested in a later gate.",
    },
    {
        "claim": "R107 closes the full field/action/PDE implementation.",
        "status": "NO",
        "reason": "Only R/C auxiliary constraint stationarity passes; full PDE derivation remains open.",
    },
    {
        "claim": "The nine-mode seed is a confirmed physical particle spectrum.",
        "status": "NO",
        "reason": "It remains a mechanical support seed, not a confirmed spectrum.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R108",
        "title": "Locality and Gauge/Frame Relabeling Gate",
        "goal": "Check whether the R106/R107 action terms are local and invariant under allowed phase and normal-frame relabelings.",
        "must_not_do": "Do not hide global ledger choices inside local-looking boundary terms.",
    },
    {
        "next_gate": "FORCE_R109",
        "title": "Discrete Binary No-Overlap Variation Gate",
        "goal": "Turn the binary write rule into a discrete variational/KKT constraint rather than a declared projector.",
        "must_not_do": "Do not assume rho>=1/2 without the no-overlap update.",
    },
    {
        "next_gate": "FORCE_R110",
        "title": "Normal-Bundle Dimension / Slot-Capacity Derivation Gate",
        "goal": "Pressure-test whether D_perp=3 and 1+3 slot capacity arise from the worldline tube geometry.",
        "must_not_do": "Do not insert D_perp=3 only because it works.",
    },
    {
        "next_gate": "FORCE_R111",
        "title": "Support-to-Species Projection Derivation Gate",
        "goal": "Derive why support-active modes project to stable species only after binary and slot filters.",
        "must_not_do": "Do not delete 1/3, 3/5, or 4/5 by hand.",
    },
])

# Save artifacts.
variation_terms.to_csv(OUT / "FORCE_R107_variation_terms.csv", index=False)
stationarity_audit.to_csv(OUT / "FORCE_R107_stationarity_audit.csv", index=False)
wrong_constraint_controls.to_csv(OUT / "FORCE_R107_wrong_constraint_controls.csv", index=False)
operator_reconstruction.to_csv(OUT / "FORCE_R107_operator_reconstruction_from_variation.csv", index=False)
term_closure.to_csv(OUT / "FORCE_R107_term_closure_classification.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R107_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R107_claim_boundary_matrix.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R107_next_gate_plan.csv", index=False)

verdict = {
    "force_id": "FORCE_R107",
    "title": "Euler-Lagrange / Constraint Variation Gate",
    "status": verdict_status,
    "R_variation_pass": R_variation_pass,
    "C_variation_pass": C_variation_pass,
    "combined_stationarity_pass": combined_stationarity_pass,
    "RC_variational_constraints_closed": RC_variational_constraints_closed,
    "wrong_controls_fail": wrong_controls_fail,
    "operator_reconstruction_exact": operator_reconstruction_exact,
    "virtual_support_split_pass": virtual_support_split_pass,
    "intruder_7_4_excluded": intruder_7_4_excluded,
    "closed_terms": closed_terms,
    "open_or_partial_terms": open_or_partial_terms,
    "binary_normal_projection_still_open": binary_normal_projection_still_open,
    "full_variational_PDE_closed": full_variational_PDE_closed,
    "physical_spectrum_claimed": physical_spectrum_claimed,
    "recommended_next": "FORCE_R108_locality_gauge_frame_relabeling_gate",
}
(OUT / "FORCE_R107_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R107 — Euler-Lagrange / Constraint Variation Gate

## Verdict

BOXED: {verdict_status}

## What passed

BOXED: R/C auxiliary constraint variation passes.

S_R = lambda_R (rho + rho_R - 2)^2

dS_R/d rho_R = 0 gives:

BOXED: rho_R = 2 - rho

S_C = lambda_C (rho*rho_C - 1)^2

dS_C/d rho_C = 0 gives:

BOXED: rho_C = 1/rho

## What remains open

BOXED: binary write, normal-frame origin, slot capacity, and support-to-species projection are not yet full PDE/Euler-Lagrange derivations.

## Reconstructed seed

BOXED: {label_set(stable_full)}

## Key booleans

- R_variation_pass: {R_variation_pass}
- C_variation_pass: {C_variation_pass}
- combined_stationarity_pass: {combined_stationarity_pass}
- wrong_controls_fail: {wrong_controls_fail}
- operator_reconstruction_exact: {operator_reconstruction_exact}
- virtual_support_split_pass: {virtual_support_split_pass}
- intruder_7_4_excluded: {intruder_7_4_excluded}
- binary_normal_projection_still_open: {binary_normal_projection_still_open}
- full_variational_PDE_closed: {full_variational_PDE_closed}

## Gate audit

{audit_df.to_string(index=False)}

## Variation terms

{variation_terms.to_string(index=False)}

## Stationarity audit

{stationarity_audit.to_string(index=False)}

## Wrong constraint controls

{wrong_constraint_controls.to_string(index=False)}

## Operator reconstruction from variation

{operator_reconstruction.to_string(index=False)}

## Term closure classification

{term_closure.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}

## Recommended next

BOXED: FORCE_R108 — Locality and Gauge/Frame Relabeling Gate
"""
(OUT / "FORCE_R107_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R107_euler_lagrange_constraint_variation_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R107_summary.md", "role": "summary"},
    {"file": "FORCE_R107_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R107_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R107_variation_terms.csv", "role": "variation terms"},
    {"file": "FORCE_R107_stationarity_audit.csv", "role": "stationarity audit"},
    {"file": "FORCE_R107_wrong_constraint_controls.csv", "role": "wrong constraint controls"},
    {"file": "FORCE_R107_operator_reconstruction_from_variation.csv", "role": "operator reconstruction"},
    {"file": "FORCE_R107_term_closure_classification.csv", "role": "term closure classification"},
    {"file": "FORCE_R107_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R107_next_gate_plan.csv", "role": "next gate plan"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(8, 5))
counts = term_closure["variation_status"].value_counts()
plt.bar(counts.index, counts.values)
plt.xticks(rotation=30, ha="right")
plt.ylabel("term count")
plt.title("R107 term variation status")
plt.tight_layout()
plt.savefig(PLOTS / "term_variation_status_counts.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(operator_reconstruction["max_den"].astype(str), operator_reconstruction["stable_count"])
plt.axhline(len(SEED), linestyle="--")
plt.xlabel("max denominator audit")
plt.ylabel("stable count")
plt.title("R107 operator reconstruction from varied R/C constraints")
plt.tight_layout()
plt.savefig(PLOTS / "operator_reconstruction_stable_counts.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

print("\n=== COPY/PASTE R107 RESULT ===")
print("R107 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"R_variation_pass: {R_variation_pass}")
print(f"C_variation_pass: {C_variation_pass}")
print(f"combined_stationarity_pass: {combined_stationarity_pass}")
print(f"RC_variational_constraints_closed: {RC_variational_constraints_closed}")
print(f"wrong_controls_fail: {wrong_controls_fail}")
print(f"operator_reconstruction_exact: {operator_reconstruction_exact}")
print(f"reconstructed_seed: {label_set(stable_full)}")
print(f"virtual_support_split_pass: {virtual_support_split_pass}")
print(f"intruder_7_4_excluded: {intruder_7_4_excluded}")
print(f"closed_terms: {closed_terms}")
print(f"open_or_partial_terms: {open_or_partial_terms}")
print(f"binary_normal_projection_still_open: {binary_normal_projection_still_open}")
print(f"full_variational_PDE_closed: {full_variational_PDE_closed}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("VARIATION_TERMS:")
print(variation_terms.to_string(index=False))
print("STATIONARITY_AUDIT:")
print(stationarity_audit.to_string(index=False))
print("WRONG_CONSTRAINT_CONTROLS:")
print(wrong_constraint_controls.to_string(index=False))
print("OPERATOR_RECONSTRUCTION_FROM_VARIATION:")
print(operator_reconstruction.to_string(index=False))
print("TERM_CLOSURE_CLASSIFICATION:")
print(term_closure.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R107_summary.md').resolve()}")
print("NEXT: FORCE_R108_locality_gauge_frame_relabeling_gate")
print("=== END COPY/PASTE R107 RESULT ===\n")
