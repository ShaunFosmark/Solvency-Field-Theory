from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R103_reciprocal_cadence_return_map_origin_gate")
ZIP = Path("FORCE_R103_reciprocal_cadence_return_map_origin_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R103 — Reciprocal Cadence-Return Map Origin Gate
#
# V12.7/R99 froze:
#
#   stable candidate = rho in minimal joint R/C support domain
#                      + rho >= 1/2
#                      + denom(rho) <= 4
#
# with primitive anchors:
#
#   {1, 1/2, 1/3}
#
# R100/R101/R102 sharpened:
#
#   1   = identity/base cadence
#   1/2 = binary no-overwrite cell
#   1/3 = tri-normal virtual support anchor
#   R(rho)=2-rho = doubled-boundary reflection/complement
#
# R103 question:
#
#   Why C(rho)=1/rho?
#
# Candidate origin:
#
#   C is the cadence-return / reciprocal closure map. A mode and its
#   reciprocal partner complete one cadence-return product:
#
#       rho * C(rho) = 1
#
# Required native roles:
#
#   C(1)     = 1       identity cadence fixed point
#   C(2)     = 1/2     endpoint returns to binary anchor
#   C(3/2)   = 2/3     high binary-compatible mode returns to lower partner
#   C(4/3)   = 3/4     high slot-3 mode returns to lower partner
#   C(5/4)   = 4/5     virtual reciprocal support channel
#   C(5/3)   = 3/5     virtual reciprocal support channel
#
# These conditions force A=1 in the family:
#
#       C_A(rho)=A/rho
#
# Claim boundary:
# - This is an operator/geometric origin gate for reciprocal closure.
# - It does not derive the full PDE/action field implementation.
# - It does not claim confirmed physical particle spectrum, masses, or Omega0.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def R_map(x):
    return Fraction(2, 1) - x

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def C_none(x):
    return None

def C_identity(x):
    return x

def C_reflection_duplicate(x):
    return R_map(x)

def C_A_factory(A):
    def C_A(x):
        if x == 0:
            return None
        return A / x
    return C_A

def C_power_square_bad(x):
    if x == 0:
        return None
    return Fraction(1, 1) / (x * x)

def C_two_minus_inverse_bad(x):
    if x == 0:
        return None
    return Fraction(2, 1) - Fraction(1, 1) / x

C_MODELS = [
    {
        "model": "C0_no_reciprocal_R_only",
        "description": "No reciprocal map; only R reflection acts.",
        "C_kind": "none",
        "A": None,
        "C_map": C_none,
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "C1_identity_no_return",
        "description": "Identity map C(rho)=rho; no reciprocal return.",
        "C_kind": "identity",
        "A": None,
        "C_map": C_identity,
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "C2_half_product_A1_2",
        "description": "Wrong product map C(rho)=(1/2)/rho.",
        "C_kind": "A_over_rho",
        "A": Fraction(1, 2),
        "C_map": C_A_factory(Fraction(1, 2)),
        "expected": "FAIL_WRONG_PRODUCT",
    },
    {
        "model": "C3_two_thirds_product_A2_3",
        "description": "Wrong product map C(rho)=(2/3)/rho.",
        "C_kind": "A_over_rho",
        "A": Fraction(2, 3),
        "C_map": C_A_factory(Fraction(2, 3)),
        "expected": "FAIL_WRONG_PRODUCT",
    },
    {
        "model": "C4_unit_reciprocal_A1",
        "description": "Candidate cadence-return map C(rho)=1/rho.",
        "C_kind": "A_over_rho",
        "A": Fraction(1, 1),
        "C_map": C_A_factory(Fraction(1, 1)),
        "expected": "PASS_EXACT_SEED",
    },
    {
        "model": "C5_three_halves_product_A3_2",
        "description": "Wrong product map C(rho)=(3/2)/rho.",
        "C_kind": "A_over_rho",
        "A": Fraction(3, 2),
        "C_map": C_A_factory(Fraction(3, 2)),
        "expected": "FAIL_WRONG_PRODUCT",
    },
    {
        "model": "C6_two_product_A2",
        "description": "Wrong product map C(rho)=2/rho.",
        "C_kind": "A_over_rho",
        "A": Fraction(2, 1),
        "C_map": C_A_factory(Fraction(2, 1)),
        "expected": "FAIL_WRONG_PRODUCT",
    },
    {
        "model": "C7_power_square_bad",
        "description": "Bad nonlinear control C(rho)=1/rho^2.",
        "C_kind": "bad_power",
        "A": None,
        "C_map": C_power_square_bad,
        "expected": "FAIL_NON_RECIPROCAL",
    },
    {
        "model": "C8_reflection_duplicate",
        "description": "Bad control: duplicate R as C.",
        "C_kind": "duplicate_R",
        "A": None,
        "C_map": C_reflection_duplicate,
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "C9_two_minus_inverse_bad",
        "description": "Bad mixed control C(rho)=2-1/rho.",
        "C_kind": "bad_mixed",
        "A": None,
        "C_map": C_two_minus_inverse_bad,
        "expected": "FAIL_NON_RECIPROCAL",
    },
]

def close_domain(C_func, max_den, use_R=True):
    universe = rational_universe(max_den)
    active = {a for a in ANCHORS if a in universe}
    boundary_used = False

    for _ in range(600):
        before = set(active)

        for x in list(active):
            if use_R:
                y = R_map(x)
                if y == 0:
                    boundary_used = True
                elif in_interval(y) and y in universe:
                    active.add(y)

            y = C_func(x)
            if in_interval(y) and y in universe:
                active.add(y)

        if active == before:
            break

    return active, boundary_used

def binary_accept(x):
    return x >= Fraction(1, 2)

def slot_accept(x):
    return x.denominator <= 4

def stable_by_domain(domain, max_den):
    universe = rational_universe(max_den)
    return {
        x for x in universe
        if binary_accept(x)
        and slot_accept(x)
        and x in domain
    }

score_rows = []
interval_rows = []
intruder_rows = []

for m in C_MODELS:
    exact_all = True
    final_domain = set()
    final_stable = set()
    final_boundary_used = False

    for max_den in DENOM_AUDITS:
        domain, boundary_used = close_domain(m["C_map"], max_den, use_R=True)
        stable = stable_by_domain(domain, max_den)

        final_domain = domain
        final_stable = stable
        final_boundary_used = boundary_used

        extras = stable - SEED
        missing = SEED - stable
        exact = stable == SEED

        if not exact:
            exact_all = False

        interval_rows.append({
            "model": m["model"],
            "C_kind": m["C_kind"],
            "A": frac_label(m.get("A", None)),
            "max_den": max_den,
            "support_domain_count": len(domain),
            "stable_count": len(stable),
            "stable_fractions": label_set(stable),
            "exact_seed": exact,
            "extra_vs_seed": label_set(extras),
            "missing_from_seed": label_set(missing),
            "boundary_used": boundary_used,
        })

        if max_den == DENOM_AUDITS[-1]:
            for x in sorted(extras):
                intruder_rows.append({
                    "model": m["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": frac_label(R_map(x)),
                    "C_partner": frac_label(m["C_map"](x)),
                    "reason": "admitted_beyond_seed",
                })
            for x in sorted(missing):
                intruder_rows.append({
                    "model": m["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": frac_label(R_map(x)),
                    "C_partner": frac_label(m["C_map"](x)),
                    "reason": "seed_mode_rejected",
                })

    if exact_all and m["expected"].startswith("PASS"):
        survivor_status = "PASS_EXACT_SEED"
    elif (not exact_all) and m["expected"].startswith("FAIL"):
        survivor_status = "PASS_CONTROL_FAILED_AS_EXPECTED"
    elif exact_all and m["expected"].startswith("FAIL"):
        survivor_status = "UNEXPECTED_EXACT_SEED"
    else:
        survivor_status = "PARTIAL"

    score_rows.append({
        "model": m["model"],
        "description": m["description"],
        "C_kind": m["C_kind"],
        "A": frac_label(m.get("A", None)),
        "support_domain_count_final": len(final_domain),
        "stable_count_final": len(final_stable),
        "stable_fractions_final": label_set(final_stable),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(final_stable - SEED),
        "missing_from_seed": label_set(SEED - final_stable),
        "boundary_used_final": final_boundary_used,
        "expected": m["expected"],
        "survivor_status": survivor_status,
    })

scorecard = pd.DataFrame(score_rows)
interval_audit = pd.DataFrame(interval_rows)
intruder_audit = pd.DataFrame(intruder_rows)

# ---------------------------------------------------------------------
# A-scan for C_A(rho)=A/rho.
# ---------------------------------------------------------------------

A_SCAN = [
    Fraction(1, 3), Fraction(1, 2), Fraction(2, 3), Fraction(3, 4),
    Fraction(1, 1), Fraction(4, 3), Fraction(3, 2), Fraction(2, 1)
]

axiom_rows = []

for A in A_SCAN:
    C_A = C_A_factory(A)
    domain, boundary_used = close_domain(C_A, max(DENOM_AUDITS), use_R=True)
    stable = stable_by_domain(domain, max(DENOM_AUDITS))

    identity_fixed = C_A(Fraction(1, 1)) == Fraction(1, 1)
    endpoint_to_binary = C_A(Fraction(2, 1)) == Fraction(1, 2)
    high_binary_return = C_A(Fraction(3, 2)) == Fraction(2, 3)
    high_slot3_return = C_A(Fraction(4, 3)) == Fraction(3, 4)
    high_slot4_virtual = C_A(Fraction(5, 4)) == Fraction(4, 5)
    high_trinormal_virtual = C_A(Fraction(5, 3)) == Fraction(3, 5)

    product_unit_sample_pass = True
    involutive_sample_pass = True

    for x in [
        Fraction(1, 2), Fraction(2, 3), Fraction(3, 4),
        Fraction(1, 1), Fraction(5, 4), Fraction(4, 3),
        Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
    ]:
        y = C_A(x)
        if x * y != Fraction(1, 1):
            product_unit_sample_pass = False
        yy = C_A(y)
        if yy != x:
            involutive_sample_pass = False

    axiom_rows.append({
        "A": frac_label(A),
        "C_formula": f"{frac_label(A)} / rho",
        "support_domain_count": len(domain),
        "stable_count": len(stable),
        "stable_fractions": label_set(stable),
        "exact_seed": stable == SEED,
        "identity_fixed_C1_eq_1": identity_fixed,
        "endpoint_C2_eq_1_2": endpoint_to_binary,
        "high_binary_C3_2_eq_2_3": high_binary_return,
        "high_slot3_C4_3_eq_3_4": high_slot3_return,
        "slot4_virtual_C5_4_eq_4_5": high_slot4_virtual,
        "trinormal_virtual_C5_3_eq_3_5": high_trinormal_virtual,
        "product_unit_sample_pass": product_unit_sample_pass,
        "involutive_sample_pass": involutive_sample_pass,
        "axiom_count": sum([
            stable == SEED,
            identity_fixed,
            endpoint_to_binary,
            high_binary_return,
            high_slot3_return,
            high_slot4_virtual,
            high_trinormal_virtual,
            product_unit_sample_pass,
            involutive_sample_pass,
        ]),
        "extra_vs_seed": label_set(stable - SEED),
        "missing_from_seed": label_set(SEED - stable),
    })

axiom_scan = pd.DataFrame(axiom_rows).sort_values(
    ["axiom_count", "exact_seed"],
    ascending=[False, False]
).reset_index(drop=True)

# ---------------------------------------------------------------------
# Candidate support truth table under C(rho)=1/rho.
# ---------------------------------------------------------------------

C_unit = C_A_factory(Fraction(1, 1))
domain_C1, boundary_C1 = close_domain(C_unit, max(DENOM_AUDITS), use_R=True)
stable_C1 = stable_by_domain(domain_C1, max(DENOM_AUDITS))

test_modes = [
    Fraction(1, 4), Fraction(1, 3), Fraction(3, 5), Fraction(1, 2),
    Fraction(2, 3), Fraction(3, 4), Fraction(4, 5), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2),
    Fraction(5, 3), Fraction(7, 4), Fraction(2, 1)
]

truth_rows = []
for x in test_modes:
    r = R_map(x)
    c = C_unit(x)
    truth_rows.append({
        "rho_fraction": frac_label(x),
        "rho": float(x),
        "denominator": x.denominator,
        "in_joint_domain": x in domain_C1,
        "binary_accept": binary_accept(x),
        "slot_accept": slot_accept(x),
        "stable_candidate": x in stable_C1,
        "R_partner": frac_label(r),
        "R_supported": True if r == 0 else r in domain_C1,
        "C_partner": frac_label(c),
        "C_supported": in_interval(c) and c in domain_C1,
        "product_rho_C": frac_label(x * c),
        "seed_member": x in SEED,
        "role": (
            "stable_seed"
            if x in stable_C1
            else (
                "virtual_reciprocal_support"
                if x in {Fraction(3, 5), Fraction(4, 5)}
                else (
                    "tri_normal_virtual_anchor"
                    if x == Fraction(1, 3)
                    else (
                        "boundary_rejected_intruder"
                        if x == Fraction(7, 4)
                        else "support_or_rejected_control"
                    )
                )
            )
        ),
    })

support_truth_table = pd.DataFrame(truth_rows)

# ---------------------------------------------------------------------
# Reciprocal pair audit.
# ---------------------------------------------------------------------

pair_rows = []
for x in sorted(SEED):
    c = C_unit(x)
    pair_rows.append({
        "rho_fraction": frac_label(x),
        "C_partner": frac_label(c),
        "product": frac_label(x * c),
        "partner_in_domain": c in domain_C1,
        "rho_stable": x in stable_C1,
        "partner_stable": c in stable_C1,
        "partner_virtual_support": (c in domain_C1 and c not in stable_C1),
        "reason_partner_not_stable": (
            "denom_gt_4"
            if c in domain_C1 and c not in stable_C1 and c.denominator > 4
            else (
                "rho_lt_1_2"
                if c in domain_C1 and c not in stable_C1 and c < Fraction(1, 2)
                else ""
            )
        ),
    })

reciprocal_pair_audit = pd.DataFrame(pair_rows)

# ---------------------------------------------------------------------
# Verdict booleans.
# ---------------------------------------------------------------------

def model_status(model):
    return scorecard[scorecard["model"] == model].iloc[0]["survivor_status"]

unit_reciprocal_exact_seed = model_status("C4_unit_reciprocal_A1") == "PASS_EXACT_SEED"

control_models = [
    "C0_no_reciprocal_R_only",
    "C1_identity_no_return",
    "C2_half_product_A1_2",
    "C3_two_thirds_product_A2_3",
    "C5_three_halves_product_A3_2",
    "C6_two_product_A2",
    "C7_power_square_bad",
    "C8_reflection_duplicate",
    "C9_two_minus_inverse_bad",
]
controls_fail = all(model_status(m) == "PASS_CONTROL_FAILED_AS_EXPECTED" for m in control_models)

exact_As = set(axiom_scan[axiom_scan["exact_seed"] == True]["A"].tolist())
A1_unique_exact_in_scan = exact_As == {"1"}

A1_row = axiom_scan[axiom_scan["A"] == "1"].iloc[0]
A1_satisfies_all_axioms = bool(
    A1_row["identity_fixed_C1_eq_1"]
    and A1_row["endpoint_C2_eq_1_2"]
    and A1_row["high_binary_C3_2_eq_2_3"]
    and A1_row["high_slot3_C4_3_eq_3_4"]
    and A1_row["slot4_virtual_C5_4_eq_4_5"]
    and A1_row["trinormal_virtual_C5_3_eq_3_5"]
    and A1_row["product_unit_sample_pass"]
    and A1_row["involutive_sample_pass"]
    and A1_row["exact_seed"]
)

identity_fixed_forces_A1 = set(
    axiom_scan[axiom_scan["identity_fixed_C1_eq_1"] == True]["A"].tolist()
) == {"1"}

endpoint_binary_forces_A1 = set(
    axiom_scan[axiom_scan["endpoint_C2_eq_1_2"] == True]["A"].tolist()
) == {"1"}

high_binary_return_forces_A1 = set(
    axiom_scan[axiom_scan["high_binary_C3_2_eq_2_3"] == True]["A"].tolist()
) == {"1"}

high_slot3_return_forces_A1 = set(
    axiom_scan[axiom_scan["high_slot3_C4_3_eq_3_4"] == True]["A"].tolist()
) == {"1"}

virtual_return_forces_A1 = (
    set(axiom_scan[axiom_scan["slot4_virtual_C5_4_eq_4_5"] == True]["A"].tolist()) == {"1"}
    and set(axiom_scan[axiom_scan["trinormal_virtual_C5_3_eq_3_5"] == True]["A"].tolist()) == {"1"}
)

product_unit_forces_A1 = set(
    axiom_scan[axiom_scan["product_unit_sample_pass"] == True]["A"].tolist()
) == {"1"}

reciprocal_involutive = bool(A1_row["involutive_sample_pass"])

virtual_reciprocal_support_present = (
    Fraction(3, 5) in domain_C1
    and Fraction(4, 5) in domain_C1
    and Fraction(3, 5) not in stable_C1
    and Fraction(4, 5) not in stable_C1
)

if (
    unit_reciprocal_exact_seed
    and controls_fail
    and A1_unique_exact_in_scan
    and A1_satisfies_all_axioms
    and identity_fixed_forces_A1
    and endpoint_binary_forces_A1
    and high_binary_return_forces_A1
    and high_slot3_return_forces_A1
    and virtual_return_forces_A1
    and product_unit_forces_A1
    and reciprocal_involutive
    and virtual_reciprocal_support_present
):
    verdict_status = "RECIPROCAL CADENCE-RETURN MAP ORIGIN PASS / FIELD-ACTION DERIVATION STILL OPEN"
elif unit_reciprocal_exact_seed and A1_unique_exact_in_scan:
    verdict_status = "RECIPROCAL CADENCE-RETURN MAP SIGNAL PASS / SOME AXIOM CONTROLS SURVIVE"
else:
    verdict_status = "RECIPROCAL CADENCE-RETURN MAP ORIGIN INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "unit_reciprocal_exact_seed",
        "result": "PASS" if unit_reciprocal_exact_seed else "WARN",
        "interpretation": "C(rho)=1/rho with R reflection recovers the exact V12.7 seed.",
    },
    {
        "test": "controls_fail",
        "result": "PASS" if controls_fail else "WARN",
        "interpretation": "No-C, identity, wrong-product, power, duplicate-R, and mixed controls fail.",
    },
    {
        "test": "A1_unique_exact_in_scan",
        "result": "PASS" if A1_unique_exact_in_scan else "WARN",
        "interpretation": "Among tested C_A(rho)=A/rho maps, only A=1 recovers the exact seed.",
    },
    {
        "test": "identity_fixed_forces_A1",
        "result": "PASS" if identity_fixed_forces_A1 else "WARN",
        "interpretation": "C_A(1)=1 forces A=1.",
    },
    {
        "test": "endpoint_binary_forces_A1",
        "result": "PASS" if endpoint_binary_forces_A1 else "WARN",
        "interpretation": "C_A(2)=1/2 forces A=1.",
    },
    {
        "test": "high_binary_return_forces_A1",
        "result": "PASS" if high_binary_return_forces_A1 else "WARN",
        "interpretation": "C_A(3/2)=2/3 forces A=1.",
    },
    {
        "test": "high_slot3_return_forces_A1",
        "result": "PASS" if high_slot3_return_forces_A1 else "WARN",
        "interpretation": "C_A(4/3)=3/4 forces A=1.",
    },
    {
        "test": "virtual_return_forces_A1",
        "result": "PASS" if virtual_return_forces_A1 else "WARN",
        "interpretation": "C_A(5/4)=4/5 and C_A(5/3)=3/5 force A=1.",
    },
    {
        "test": "product_unit_forces_A1",
        "result": "PASS" if product_unit_forces_A1 else "WARN",
        "interpretation": "The cadence-return product rho*C(rho)=1 forces A=1.",
    },
    {
        "test": "reciprocal_involutive",
        "result": "PASS" if reciprocal_involutive else "WARN",
        "interpretation": "C(C(rho))=rho for the reciprocal map.",
    },
    {
        "test": "virtual_reciprocal_support_present",
        "result": "PASS" if virtual_reciprocal_support_present else "WARN",
        "interpretation": "3/5 and 4/5 appear as reciprocal support channels but fail the N<=4 species filter.",
    },
    {
        "test": "field_action_derivation",
        "result": "OPEN",
        "interpretation": "R103 supports the reciprocal cadence-return map at operator level; it is not a full PDE/action derivation.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "C(rho)=1/rho has an operator-level cadence-return origin candidate.",
        "status": "YES",
        "reason": "A=1 is the unique tested reciprocal-product map satisfying exact seed recovery and the cadence-return axioms.",
    },
    {
        "claim": "The reciprocal map is arbitrary.",
        "status": "NO",
        "reason": "Wrong-product and non-reciprocal controls fail.",
    },
    {
        "claim": "C fixes the identity cadence.",
        "status": "YES",
        "reason": "C(1)=1.",
    },
    {
        "claim": "C returns the high endpoint to the binary anchor.",
        "status": "YES",
        "reason": "C(2)=1/2.",
    },
    {
        "claim": "C supplies stable reciprocal partners for 3/2 and 4/3.",
        "status": "YES",
        "reason": "C(3/2)=2/3 and C(4/3)=3/4.",
    },
    {
        "claim": "C supplies virtual reciprocal support channels for 5/3 and 5/4.",
        "status": "YES",
        "reason": "C(5/3)=3/5 and C(5/4)=4/5; these are support channels, not stable species.",
    },
    {
        "claim": "All reciprocal support channels are stable species.",
        "status": "NO",
        "reason": "3/5 and 4/5 are in the support domain but fail denom(rho)<=4.",
    },
    {
        "claim": "The full field/action origin of C is solved.",
        "status": "NO",
        "reason": "R103 is an operator/geometric cadence-return gate, not a PDE/action derivation.",
    },
])

theorem_candidate = pd.DataFrame([
    {
        "layer": 1,
        "statement": "Cadence-return closure requires rho*C(rho)=1.",
        "status": "MODEL_AXIOM",
    },
    {
        "layer": 2,
        "statement": "In the family C_A(rho)=A/rho, cadence-return product forces A=1.",
        "status": "PASS",
    },
    {
        "layer": 3,
        "statement": "Therefore C(rho)=1/rho.",
        "status": "CANDIDATE_PASS",
    },
    {
        "layer": 4,
        "statement": "C is involutive: C(C(rho))=rho.",
        "status": "PASS",
    },
    {
        "layer": 5,
        "statement": "C supplies stable reciprocal partners for 2, 3/2, and 4/3.",
        "status": "PASS",
    },
    {
        "layer": 6,
        "statement": "C supplies virtual reciprocal support for 5/4 and 5/3 through 4/5 and 3/5.",
        "status": "PASS",
    },
    {
        "layer": 7,
        "statement": "Full field/action implementation remains open.",
        "status": "OPEN",
    },
])

# Save artifacts.
scorecard.to_csv(OUT / "FORCE_R103_reciprocal_model_scorecard.csv", index=False)
interval_audit.to_csv(OUT / "FORCE_R103_interval_audit.csv", index=False)
intruder_audit.to_csv(OUT / "FORCE_R103_intruder_and_missing_seed_audit.csv", index=False)
axiom_scan.to_csv(OUT / "FORCE_R103_A_over_rho_axiom_scan.csv", index=False)
support_truth_table.to_csv(OUT / "FORCE_R103_support_truth_table.csv", index=False)
reciprocal_pair_audit.to_csv(OUT / "FORCE_R103_reciprocal_pair_audit.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R103_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R103_claim_boundary_matrix.csv", index=False)
theorem_candidate.to_csv(OUT / "FORCE_R103_theorem_candidate.csv", index=False)

verdict = {
    "force_id": "FORCE_R103",
    "title": "Reciprocal Cadence-Return Map Origin Gate",
    "status": verdict_status,
    "unit_reciprocal_exact_seed": unit_reciprocal_exact_seed,
    "controls_fail": controls_fail,
    "A1_unique_exact_in_scan": A1_unique_exact_in_scan,
    "A1_satisfies_all_axioms": A1_satisfies_all_axioms,
    "identity_fixed_forces_A1": identity_fixed_forces_A1,
    "endpoint_binary_forces_A1": endpoint_binary_forces_A1,
    "high_binary_return_forces_A1": high_binary_return_forces_A1,
    "high_slot3_return_forces_A1": high_slot3_return_forces_A1,
    "virtual_return_forces_A1": virtual_return_forces_A1,
    "product_unit_forces_A1": product_unit_forces_A1,
    "reciprocal_involutive": reciprocal_involutive,
    "virtual_reciprocal_support_present": virtual_reciprocal_support_present,
    "field_action_derivation_closed": False,
    "recommended_next": "FORCE_R104_joint_RC_support_domain_origin_rollup_gate",
}
(OUT / "FORCE_R103_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R103 — Reciprocal Cadence-Return Map Origin Gate

## Verdict

BOXED: {verdict_status}

## Central result

R103 tests the origin of the reciprocal closure map:

BOXED: C(rho)=1/rho

Candidate origin:

BOXED: C is cadence-return closure.

A mode and its reciprocal partner satisfy:

BOXED: rho*C(rho)=1

## Why A=1?

In the family C_A(rho)=A/rho, the following force A=1:

- C_A(1)=1
- C_A(2)=1/2
- C_A(3/2)=2/3
- C_A(4/3)=3/4
- C_A(5/4)=4/5
- C_A(5/3)=3/5
- rho*C_A(rho)=1

## Key booleans

- unit_reciprocal_exact_seed: {unit_reciprocal_exact_seed}
- controls_fail: {controls_fail}
- A1_unique_exact_in_scan: {A1_unique_exact_in_scan}
- A1_satisfies_all_axioms: {A1_satisfies_all_axioms}
- product_unit_forces_A1: {product_unit_forces_A1}
- reciprocal_involutive: {reciprocal_involutive}
- virtual_reciprocal_support_present: {virtual_reciprocal_support_present}

## Gate audit

{audit_df.to_string(index=False)}

## Reciprocal model scorecard

{scorecard.to_string(index=False)}

## A-over-rho axiom scan

{axiom_scan.to_string(index=False)}

## Reciprocal pair audit

{reciprocal_pair_audit.to_string(index=False)}

## Support truth table

{support_truth_table.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Theorem candidate

{theorem_candidate.to_string(index=False)}

## Remaining open item

R103 supports the reciprocal map at operator/geometric cadence-return level.
It does not derive the full field/action implementation.

## Recommended next

BOXED: FORCE_R104 — Joint R/C Support-Domain Origin Rollup Gate
"""
(OUT / "FORCE_R103_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R103_reciprocal_cadence_return_map_origin_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R103_summary.md", "role": "summary"},
    {"file": "FORCE_R103_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R103_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R103_reciprocal_model_scorecard.csv", "role": "reciprocal model scorecard"},
    {"file": "FORCE_R103_interval_audit.csv", "role": "interval audit"},
    {"file": "FORCE_R103_intruder_and_missing_seed_audit.csv", "role": "intruder audit"},
    {"file": "FORCE_R103_A_over_rho_axiom_scan.csv", "role": "A-over-rho axiom scan"},
    {"file": "FORCE_R103_support_truth_table.csv", "role": "support truth table"},
    {"file": "FORCE_R103_reciprocal_pair_audit.csv", "role": "reciprocal pair audit"},
    {"file": "FORCE_R103_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R103_theorem_candidate.csv", "role": "theorem candidate"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(12, 5))
plt.bar(scorecard["model"], scorecard["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xticks(rotation=35, ha="right")
plt.ylabel("final stable count")
plt.title("R103 reciprocal-map controls")
plt.tight_layout()
plt.savefig(PLOTS / "reciprocal_model_stable_counts.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(axiom_scan["A"], axiom_scan["axiom_count"])
plt.xlabel("A in C_A(rho)=A/rho")
plt.ylabel("axiom count")
plt.title("R103 reciprocal product scan: A=1 satisfies all tested axioms")
plt.tight_layout()
plt.savefig(PLOTS / "A_over_rho_axiom_scan.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

compact_scorecard = scorecard[[
    "model", "C_kind", "A", "support_domain_count_final",
    "stable_count_final", "stable_fractions_final",
    "exact_seed_all_denominators", "survivor_status"
]]

compact_axiom = axiom_scan[[
    "A", "C_formula", "stable_count", "stable_fractions", "exact_seed",
    "identity_fixed_C1_eq_1", "endpoint_C2_eq_1_2",
    "high_binary_C3_2_eq_2_3", "high_slot3_C4_3_eq_3_4",
    "slot4_virtual_C5_4_eq_4_5", "trinormal_virtual_C5_3_eq_3_5",
    "product_unit_sample_pass", "axiom_count"
]]

print("\n=== COPY/PASTE R103 RESULT ===")
print("R103 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"unit_reciprocal_exact_seed: {unit_reciprocal_exact_seed}")
print(f"controls_fail: {controls_fail}")
print(f"A1_unique_exact_in_scan: {A1_unique_exact_in_scan}")
print(f"A1_satisfies_all_axioms: {A1_satisfies_all_axioms}")
print(f"identity_fixed_forces_A1: {identity_fixed_forces_A1}")
print(f"endpoint_binary_forces_A1: {endpoint_binary_forces_A1}")
print(f"high_binary_return_forces_A1: {high_binary_return_forces_A1}")
print(f"high_slot3_return_forces_A1: {high_slot3_return_forces_A1}")
print(f"virtual_return_forces_A1: {virtual_return_forces_A1}")
print(f"product_unit_forces_A1: {product_unit_forces_A1}")
print(f"reciprocal_involutive: {reciprocal_involutive}")
print(f"virtual_reciprocal_support_present: {virtual_reciprocal_support_present}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("RECIPROCAL_MODEL_SCORECARD:")
print(compact_scorecard.to_string(index=False))
print("A_OVER_RHO_AXIOM_SCAN:")
print(compact_axiom.to_string(index=False))
print("RECIPROCAL_PAIR_AUDIT:")
print(reciprocal_pair_audit.to_string(index=False))
print("SUPPORT_TRUTH_TABLE:")
print(support_truth_table.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("INTRUDER_AND_MISSING_SEED_AUDIT:")
print(intruder_audit.to_string(index=False) if len(intruder_audit) else "none")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R103_summary.md').resolve()}")
print("NEXT: FORCE_R104_joint_RC_support_domain_origin_rollup_gate")
print("=== END COPY/PASTE R103 RESULT ===\n")
