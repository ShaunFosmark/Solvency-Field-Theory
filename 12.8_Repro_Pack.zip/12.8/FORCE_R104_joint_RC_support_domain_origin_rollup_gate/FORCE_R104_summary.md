# FORCE_R104 — Joint R/C Support-Domain Origin Rollup Gate

## Verdict

BOXED: JOINT R/C SUPPORT-DOMAIN ORIGIN ROLLUP PASS / FIELD-ACTION DERIVATION STILL OPEN

## Central theorem candidate

BOXED:
stable candidate =
rho in D_RC({1,1/2,1/3})
AND rho >= 1/2
AND denom(rho) <= 4

with:

R(rho)=2-rho

C(rho)=1/rho

## Selected seed

BOXED: 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2

## Key booleans

- full_stack_exact_seed: True
- all_controls_fail: True
- minimal_exact_unique_v128: True
- R2_unique: True
- C1_unique: True
- domain_contains_seed: True
- domain_excludes_7_4: True
- all_seed_R_supported: True
- all_seed_C_supported: True
- virtual_supports_present_not_stable: True
- species_excludes_virtual_supports: True

## Gate audit

                               test result                                                                                         interpretation
              full_stack_exact_seed   PASS                                The full R100-R103 stack recovers the exact V12.7/V12.8 nine-mode seed.
                  all_controls_fail   PASS Removing or corrupting R, C, anchors, binary filter, slot filter, or support-domain selectivity fails.
          minimal_exact_unique_v128   PASS                                        {1,1/2,1/3} remains the unique minimal tested exact anchor set.
                          R2_unique   PASS                                                R(rho)=2-rho is the unique tested exact complement map.
                          C1_unique   PASS                                 C(rho)=1/rho is the unique tested exact reciprocal cadence-return map.
               domain_contains_seed   PASS                                               All nine seed modes lie in the joint R/C support domain.
                domain_excludes_7_4   PASS                                                     The support domain excludes the main 7/4 intruder.
               all_seed_R_supported   PASS                                                     Every seed mode has reflection/complement support.
               all_seed_C_supported   PASS                                                 Every seed mode has reciprocal/cadence-return support.
virtual_supports_present_not_stable   PASS                                         1/3, 3/5, and 4/5 are support channels but not stable species.
            field_action_derivation   OPEN                                      R104 is a rollup theorem-stack gate, not a PDE/action derivation.

## Component control scorecard

                                 model                                                    description       anchor_set  use_R  use_C  use_binary_filter  use_slot_filter  promote_anchors  all_domain  support_domain_count_final  stable_count_final                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              stable_fractions_final  exact_seed_all_denominators                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              extra_vs_seed               missing_from_seed  boundary_used_final              expected                 survivor_status
               M0_full_R100_R103_stack                                     Full V12.8 operator stack.      1/3, 1/2, 1   True   True               True             True            False       False                          94                   9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none                            none                 True       PASS_EXACT_SEED                 PASS_EXACT_SEED
                               M1_no_R                           Remove reflection complement branch.      1/3, 1/2, 1  False   True               True             True            False       False                           4                   3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           1/2, 1, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none    2/3, 3/4, 5/4, 4/3, 3/2, 5/3                False FAIL_MISSING_R_BRANCH PASS_CONTROL_FAILED_AS_EXPECTED
                               M2_no_C                       Remove reciprocal cadence-return branch.      1/3, 1/2, 1   True  False               True             True            False       False                           5                   4                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    1/2, 1, 3/2, 5/3                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none           2/3, 3/4, 5/4, 4/3, 2                False FAIL_MISSING_C_BRANCH PASS_CONTROL_FAILED_AS_EXPECTED
                       M3_wrong_R_T3_2                    Wrong reflection complement R(rho)=3/2-rho.      1/3, 1/2, 1   True   True               True             True            False       False                           8                   3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           1/2, 1, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none    2/3, 3/4, 5/4, 4/3, 3/2, 5/3                False          FAIL_WRONG_R PASS_CONTROL_FAILED_AS_EXPECTED
                       M4_wrong_C_A2_3                     Wrong reciprocal product C(rho)=(2/3)/rho.      1/3, 1/2, 1   True   True               True             True            False       False                          18                   7                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       1/2, 2/3, 1, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none                        3/4, 5/4                 True          FAIL_WRONG_C PASS_CONTROL_FAILED_AS_EXPECTED
               M5_omit_identity_anchor                           Remove identity/base cadence anchor.         1/3, 1/2   True   True               True             True            False       False                          93                   8                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none                               1                 True FAIL_MISSING_IDENTITY PASS_CONTROL_FAILED_AS_EXPECTED
                 M6_omit_binary_anchor                             Remove binary no-overwrite anchor.           1/3, 1   True   True               True             True            False       False                          31                   2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              1, 5/3                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none 1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2                False   FAIL_MISSING_BINARY PASS_CONTROL_FAILED_AS_EXPECTED
              M7_omit_trinormal_anchor                      Remove tri-normal virtual support anchor.           1/2, 1   True   True               True             True            False       False                          64                   8                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none                             5/3                 True      FAIL_MISSING_5_3 PASS_CONTROL_FAILED_AS_EXPECTED
                 M8_add_quarter_anchor                  Add 1/4 as an extra primitive support anchor. 1/4, 1/3, 1/2, 1   True   True               True             True            False       False                         114                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        7/4                            none                 True     FAIL_7_4_INTRUDER PASS_CONTROL_FAILED_AS_EXPECTED
           M9_no_binary_species_filter              Remove rho>=1/2 binary no-overlap species filter.      1/3, 1/2, 1   True   True              False             True            False       False                          94                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3                            none                 True FAIL_SUBHALF_INTRUDER PASS_CONTROL_FAILED_AS_EXPECTED
            M10_no_slot_species_filter             Remove denom(rho)<=4 slot-capacity species filter.      1/3, 1/2, 1   True   True               True            False            False       False                          94                  93 1/2, 3/5, 2/3, 5/7, 3/4, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 1, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 5/4, 9/7, 4/3, 7/5, 3/2, 5/3, 2                        False 3/5, 5/7, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 9/7, 7/5                            none                 True  FAIL_DENOM_INTRUDERS PASS_CONTROL_FAILED_AS_EXPECTED
              M11_all_rationals_domain     Remove support-domain selectivity; all rationals eligible.      1/3, 1/2, 1   True   True               True             True            False        True                         648                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        7/4                            none                 True     FAIL_7_4_INTRUDER PASS_CONTROL_FAILED_AS_EXPECTED
M12_promote_virtual_anchors_to_species Bad control: primitive support anchors bypass species filters.      1/3, 1/2, 1   True   True               True             True             True       False                          94                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3                            none                 True     FAIL_1_3_INTRUDER PASS_CONTROL_FAILED_AS_EXPECTED

## Minimal anchor subset scan

           anchor_set  anchor_count  support_domain_count_final  stable_count_final                       stable_fractions_final  exact_seed_all_denominators extra_vs_seed                       missing_from_seed  is_v128_anchor_set
          1/3, 1/2, 1             3                          94                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True          none                                    none                True
     1/5, 1/3, 1/2, 1             4                         108                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True          none                                    none               False
                 none             0                           0                   0                                         none                        False          none 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2               False
                    1             1                           1                   1                                            1                        False          none    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False
                  1/2             1                          63                   7              1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2                        False          none                                  1, 5/3               False
                  1/3             1                          30                   1                                          5/3                        False          none      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2               False
                  1/4             1                          20                   1                                          7/4                        False           7/4 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2               False
                  1/5             1                          14                   0                                         none                        False          none 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2               False
               1/2, 1             2                          64                   8           1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False          none                                     5/3               False
               1/3, 1             2                          31                   2                                       1, 5/3                        False          none         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False
             1/3, 1/2             2                          93                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2                        False          none                                       1               False
               1/4, 1             2                          21                   2                                       1, 7/4                        False           7/4    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False
             1/4, 1/2             2                          83                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4                                  1, 5/3               False
             1/4, 1/3             2                          50                   2                                     5/3, 7/4                        False           7/4      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2               False
               1/5, 1             2                          15                   1                                            1                        False          none    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False
             1/5, 1/2             2                          77                   7              1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2                        False          none                                  1, 5/3               False
             1/5, 1/3             2                          44                   1                                          5/3                        False          none      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2               False
             1/5, 1/4             2                          34                   1                                          7/4                        False           7/4 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2               False
          1/4, 1/2, 1             3                          84                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4                                     5/3               False
          1/4, 1/3, 1             3                          51                   3                                  1, 5/3, 7/4                        False           7/4         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False
        1/4, 1/3, 1/2             3                         113                   9    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False           7/4                                       1               False
          1/5, 1/2, 1             3                          78                   8           1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False          none                                     5/3               False
          1/5, 1/3, 1             3                          45                   2                                       1, 5/3                        False          none         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False
        1/5, 1/3, 1/2             3                         107                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2                        False          none                                       1               False
          1/5, 1/4, 1             3                          35                   2                                       1, 7/4                        False           7/4    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False
        1/5, 1/4, 1/2             3                          97                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4                                  1, 5/3               False
        1/5, 1/4, 1/3             3                          64                   2                                     5/3, 7/4                        False           7/4      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2               False
     1/4, 1/3, 1/2, 1             4                         114                  10 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False           7/4                                    none               False
     1/5, 1/4, 1/2, 1             4                          98                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4                                     5/3               False
     1/5, 1/4, 1/3, 1             4                          65                   3                                  1, 5/3, 7/4                        False           7/4         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False
   1/5, 1/4, 1/3, 1/2             4                         127                   9    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False           7/4                                       1               False
1/5, 1/4, 1/3, 1/2, 1             5                         128                  10 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False           7/4                                    none               False

## R-map uniqueness scan

  T R_formula  stable_count                        stable_fractions  exact_seed  identity_fixed  endpoint_to_boundary  binary_support  trinormal_support  axiom_count
  2   2 - rho             9 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True            True                  True            True               True            5
  1   1 - rho             5                     1/2, 2/3, 1, 3/2, 2       False           False                 False           False              False            0
4/3 4/3 - rho             3                               1/2, 1, 2       False           False                 False           False              False            0
3/2 3/2 - rho             3                               1/2, 1, 2       False           False                 False           False              False            0
5/3 5/3 - rho             7           1/2, 2/3, 3/4, 1, 4/3, 3/2, 2       False           False                 False           False              False            0
7/3 7/3 - rho             5                     1/2, 3/4, 1, 4/3, 2       False           False                 False           False              False            0
5/2 5/2 - rho             5                     1/2, 2/3, 1, 3/2, 2       False           False                 False           False              False            0
  3   3 - rho             3                               1/2, 1, 2       False           False                 False           False              False            0

## C-map uniqueness scan

  A C_formula  stable_count                        stable_fractions  exact_seed  identity_fixed  endpoint_to_binary  high_binary_return  high_slot3_return  product_unit  axiom_count
  1   1 / rho             9 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True            True                True                True               True          True            6
1/3 1/3 / rho             7         1/2, 2/3, 1, 4/3, 3/2, 5/3, 7/4       False           False               False               False              False         False            0
1/2 1/2 / rho             4                        1/2, 1, 3/2, 5/3       False           False               False               False              False         False            0
2/3 2/3 / rho             7           1/2, 2/3, 1, 4/3, 3/2, 5/3, 2       False           False               False               False              False         False            0
3/4 3/4 / rho             6              1/2, 3/4, 1, 5/4, 3/2, 5/3       False           False               False               False              False         False            0
4/3 4/3 / rho             7           1/2, 2/3, 1, 4/3, 3/2, 5/3, 2       False           False               False               False              False         False            0
3/2 3/2 / rho             4                        1/2, 1, 3/2, 5/3       False           False               False               False              False         False            0
  2   2 / rho             7           1/2, 2/3, 1, 4/3, 3/2, 5/3, 2       False           False               False               False              False         False            0

## Seed dependency audit

seed_mode  R_partner  R_partner_role  R_supported C_partner  C_partner_role  C_supported C_product
      1/2        3/2          stable         True         2          stable         True         1
      2/3        4/3          stable         True       3/2          stable         True         1
      3/4        5/4          stable         True       4/3          stable         True         1
        1          1          stable         True         1          stable         True         1
      5/4        3/4          stable         True       4/5 virtual/support         True         1
      4/3        2/3          stable         True       3/4          stable         True         1
      3/2        1/2          stable         True       2/3          stable         True         1
      5/3        1/3 virtual/support         True       3/5 virtual/support         True         1
        2 0_boundary        boundary         True       1/2          stable         True         1

## Support truth table

rho_fraction      rho  denominator  in_joint_domain  primitive_anchor  binary_accept  slot_accept  stable_candidate  R_partner  R_supported C_partner  C_supported                       role
         1/4 0.250000            4            False             False          False         True             False        7/4        False         4        False          rejected_intruder
         1/3 0.333333            3             True              True          False         True             False        5/3         True         3        False     virtual_support_anchor
         1/2 0.500000            2             True              True           True         True              True        3/2         True         2         True                stable_seed
         3/5 0.600000            5             True             False           True        False             False        7/5         True       5/3         True virtual_reciprocal_support
         2/3 0.666667            3             True             False           True         True              True        4/3         True       3/2         True                stable_seed
         3/4 0.750000            4             True             False           True         True              True        5/4         True       4/3         True                stable_seed
         4/5 0.800000            5             True             False           True        False             False        6/5         True       5/4         True virtual_reciprocal_support
           1 1.000000            1             True              True           True         True              True          1         True         1         True                stable_seed
         6/5 1.200000            5             True             False           True        False             False        4/5         True       5/6         True         support_or_control
         5/4 1.250000            4             True             False           True         True              True        3/4         True       4/5         True                stable_seed
         4/3 1.333333            3             True             False           True         True              True        2/3         True       3/4         True                stable_seed
         7/5 1.400000            5             True             False           True        False             False        3/5         True       5/7         True         support_or_control
         3/2 1.500000            2             True             False           True         True              True        1/2         True       2/3         True                stable_seed
         5/3 1.666667            3             True             False           True         True              True        1/3         True       3/5         True                stable_seed
         7/4 1.750000            4            False             False           True         True             False        1/4        False       4/7        False          rejected_intruder
           2 2.000000            1             True             False           True         True              True 0_boundary         True       1/2         True                stable_seed

## Theorem stack rollup

 layer                            result                         statement                                                              origin               status                             open_boundary
     1              Primitive anchor set                       {1,1/2,1/3} identity cadence + binary no-overwrite + tri-normal virtual support PASS_OPERATOR_ORIGIN                   field/action derivation
     2                   Identity anchor                                 1                                          unique joint fixed cadence PASS_OPERATOR_ORIGIN                   field/action derivation
     3                     Binary anchor                               1/2                                minimum faithful no-overwrite record PASS_OPERATOR_ORIGIN                   field/action derivation
     4 Tri-normal virtual support anchor                               1/3                                  three transverse normal directions PASS_OPERATOR_ORIGIN                   field-bundle derivation
     5         Reflection complement map                      R(rho)=2-rho                                doubled-boundary complement on [0,2] PASS_OPERATOR_ORIGIN                   field/action derivation
     6     Reciprocal cadence-return map                      C(rho)=1/rho                                                        rho*C(rho)=1 PASS_OPERATOR_ORIGIN                   field/action derivation
     7              Joint support domain                 D_RC({1,1/2,1/3})                                               closure under R and C          PASS_ROLLUP           local PDE/action implementation
     8                    Species filter        rho>=1/2 and denom(rho)<=4                             binary no-overwrite + 3+1 slot capacity PASS_OPERATOR_ORIGIN               field/action implementation
     9            Stable mechanical seed {1/2,2/3,3/4,1,5/4,4/3,3/2,5/3,2}                            joint support domain plus species filter          PASS_ROLLUP physical spectrum/mass/Omega0 not claimed

## Claim boundary

                                                                                           claim status                                                                          reason
The R100-R103 operator-origin stack coheres into one joint R/C support-domain theorem candidate.    YES The full stack recovers the exact seed and all component-removal controls fail.
                   The stable seed is selected by D_RC({1,1/2,1/3}) plus rho>=1/2 plus denom<=4.    YES  The full-stack stable set equals the nine-mode seed across denominator audits.
                                                                  R and C are arbitrary choices.     NO    Wrong R and wrong C controls fail; R2 and C1 are unique in the tested scans.
                                                    Virtual support channels are stable species.     NO    1/3, 3/5, and 4/5 are in the support domain but rejected by species filters.
                                               The full local field/action/PDE origin is solved.     NO                                      R104 is an operator/geometric rollup only.
                              The nine-mode seed is confirmed as the physical particle spectrum.     NO      R104 selects a mechanical support seed, not a confirmed physical spectrum.
                                                     Masses, Omega0, or SM matching are derived.     NO                                                 Those remain future-work items.

## Intruder / missing seed audit

                                 model fraction      rho  denominator  R_partner C_partner               reason
                               M1_no_R      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                               M1_no_R      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                               M1_no_R      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                               M1_no_R      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                               M1_no_R      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
                               M1_no_R      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
                               M2_no_C      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                               M2_no_C      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                               M2_no_C      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                               M2_no_C      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                               M2_no_C        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
                       M3_wrong_R_T3_2      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                       M3_wrong_R_T3_2      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                       M3_wrong_R_T3_2      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                       M3_wrong_R_T3_2      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                       M3_wrong_R_T3_2      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
                       M3_wrong_R_T3_2      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
                       M4_wrong_C_A2_3      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                       M4_wrong_C_A2_3      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
               M5_omit_identity_anchor        1 1.000000            1          1         1   seed_mode_rejected
                 M6_omit_binary_anchor      1/2 0.500000            2        3/2         2   seed_mode_rejected
                 M6_omit_binary_anchor      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                 M6_omit_binary_anchor      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                 M6_omit_binary_anchor      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                 M6_omit_binary_anchor      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                 M6_omit_binary_anchor      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
                 M6_omit_binary_anchor        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
              M7_omit_trinormal_anchor      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
                 M8_add_quarter_anchor      7/4 1.750000            4        1/4       4/7 admitted_beyond_seed
           M9_no_binary_species_filter      1/3 0.333333            3        5/3         3 admitted_beyond_seed
            M10_no_slot_species_filter      3/5 0.600000            5        7/5       5/3 admitted_beyond_seed
            M10_no_slot_species_filter      5/7 0.714286            7        9/7       7/5 admitted_beyond_seed
            M10_no_slot_species_filter      7/9 0.777778            9       11/9       9/7 admitted_beyond_seed
            M10_no_slot_species_filter      4/5 0.800000            5        6/5       5/4 admitted_beyond_seed
            M10_no_slot_species_filter     9/11 0.818182           11      13/11      11/9 admitted_beyond_seed
            M10_no_slot_species_filter      5/6 0.833333            6        7/6       6/5 admitted_beyond_seed
            M10_no_slot_species_filter    11/13 0.846154           13      15/13     13/11 admitted_beyond_seed
            M10_no_slot_species_filter      6/7 0.857143            7        8/7       7/6 admitted_beyond_seed
            M10_no_slot_species_filter    13/15 0.866667           15      17/15     15/13 admitted_beyond_seed
            M10_no_slot_species_filter      7/8 0.875000            8        9/8       8/7 admitted_beyond_seed
            M10_no_slot_species_filter    15/17 0.882353           17      19/17     17/15 admitted_beyond_seed
            M10_no_slot_species_filter      8/9 0.888889            9       10/9       9/8 admitted_beyond_seed
            M10_no_slot_species_filter    17/19 0.894737           19      21/19     19/17 admitted_beyond_seed
            M10_no_slot_species_filter     9/10 0.900000           10      11/10      10/9 admitted_beyond_seed
            M10_no_slot_species_filter    19/21 0.904762           21      23/21     21/19 admitted_beyond_seed
            M10_no_slot_species_filter    10/11 0.909091           11      12/11     11/10 admitted_beyond_seed
            M10_no_slot_species_filter    21/23 0.913043           23      25/23     23/21 admitted_beyond_seed
            M10_no_slot_species_filter    11/12 0.916667           12      13/12     12/11 admitted_beyond_seed
            M10_no_slot_species_filter    23/25 0.920000           25      27/25     25/23 admitted_beyond_seed
            M10_no_slot_species_filter    12/13 0.923077           13      14/13     13/12 admitted_beyond_seed
            M10_no_slot_species_filter    25/27 0.925926           27      29/27     27/25 admitted_beyond_seed
            M10_no_slot_species_filter    13/14 0.928571           14      15/14     14/13 admitted_beyond_seed
            M10_no_slot_species_filter    27/29 0.931034           29      31/29     29/27 admitted_beyond_seed
            M10_no_slot_species_filter    14/15 0.933333           15      16/15     15/14 admitted_beyond_seed
            M10_no_slot_species_filter    29/31 0.935484           31      33/31     31/29 admitted_beyond_seed
            M10_no_slot_species_filter    15/16 0.937500           16      17/16     16/15 admitted_beyond_seed
            M10_no_slot_species_filter    16/17 0.941176           17      18/17     17/16 admitted_beyond_seed
            M10_no_slot_species_filter    17/18 0.944444           18      19/18     18/17 admitted_beyond_seed
            M10_no_slot_species_filter    18/19 0.947368           19      20/19     19/18 admitted_beyond_seed
            M10_no_slot_species_filter    19/20 0.950000           20      21/20     20/19 admitted_beyond_seed
            M10_no_slot_species_filter    20/21 0.952381           21      22/21     21/20 admitted_beyond_seed
            M10_no_slot_species_filter    21/22 0.954545           22      23/22     22/21 admitted_beyond_seed
            M10_no_slot_species_filter    22/23 0.956522           23      24/23     23/22 admitted_beyond_seed
            M10_no_slot_species_filter    23/24 0.958333           24      25/24     24/23 admitted_beyond_seed
            M10_no_slot_species_filter    24/25 0.960000           25      26/25     25/24 admitted_beyond_seed
            M10_no_slot_species_filter    25/26 0.961538           26      27/26     26/25 admitted_beyond_seed
            M10_no_slot_species_filter    26/27 0.962963           27      28/27     27/26 admitted_beyond_seed
            M10_no_slot_species_filter    27/28 0.964286           28      29/28     28/27 admitted_beyond_seed
            M10_no_slot_species_filter    28/29 0.965517           29      30/29     29/28 admitted_beyond_seed
            M10_no_slot_species_filter    29/30 0.966667           30      31/30     30/29 admitted_beyond_seed
            M10_no_slot_species_filter    30/31 0.967742           31      32/31     31/30 admitted_beyond_seed
            M10_no_slot_species_filter    31/32 0.968750           32      33/32     32/31 admitted_beyond_seed
            M10_no_slot_species_filter    33/32 1.031250           32      31/32     32/33 admitted_beyond_seed
            M10_no_slot_species_filter    32/31 1.032258           31      30/31     31/32 admitted_beyond_seed
            M10_no_slot_species_filter    31/30 1.033333           30      29/30     30/31 admitted_beyond_seed
            M10_no_slot_species_filter    30/29 1.034483           29      28/29     29/30 admitted_beyond_seed
            M10_no_slot_species_filter    29/28 1.035714           28      27/28     28/29 admitted_beyond_seed
            M10_no_slot_species_filter    28/27 1.037037           27      26/27     27/28 admitted_beyond_seed
            M10_no_slot_species_filter    27/26 1.038462           26      25/26     26/27 admitted_beyond_seed
            M10_no_slot_species_filter    26/25 1.040000           25      24/25     25/26 admitted_beyond_seed
            M10_no_slot_species_filter    25/24 1.041667           24      23/24     24/25 admitted_beyond_seed
            M10_no_slot_species_filter    24/23 1.043478           23      22/23     23/24 admitted_beyond_seed
            M10_no_slot_species_filter    23/22 1.045455           22      21/22     22/23 admitted_beyond_seed
            M10_no_slot_species_filter    22/21 1.047619           21      20/21     21/22 admitted_beyond_seed
            M10_no_slot_species_filter    21/20 1.050000           20      19/20     20/21 admitted_beyond_seed
            M10_no_slot_species_filter    20/19 1.052632           19      18/19     19/20 admitted_beyond_seed
            M10_no_slot_species_filter    19/18 1.055556           18      17/18     18/19 admitted_beyond_seed
            M10_no_slot_species_filter    18/17 1.058824           17      16/17     17/18 admitted_beyond_seed
            M10_no_slot_species_filter    17/16 1.062500           16      15/16     16/17 admitted_beyond_seed
            M10_no_slot_species_filter    33/31 1.064516           31      29/31     31/33 admitted_beyond_seed
            M10_no_slot_species_filter    16/15 1.066667           15      14/15     15/16 admitted_beyond_seed
            M10_no_slot_species_filter    31/29 1.068966           29      27/29     29/31 admitted_beyond_seed
            M10_no_slot_species_filter    15/14 1.071429           14      13/14     14/15 admitted_beyond_seed
            M10_no_slot_species_filter    29/27 1.074074           27      25/27     27/29 admitted_beyond_seed
            M10_no_slot_species_filter    14/13 1.076923           13      12/13     13/14 admitted_beyond_seed
            M10_no_slot_species_filter    27/25 1.080000           25      23/25     25/27 admitted_beyond_seed
            M10_no_slot_species_filter    13/12 1.083333           12      11/12     12/13 admitted_beyond_seed
            M10_no_slot_species_filter    25/23 1.086957           23      21/23     23/25 admitted_beyond_seed
            M10_no_slot_species_filter    12/11 1.090909           11      10/11     11/12 admitted_beyond_seed
            M10_no_slot_species_filter    23/21 1.095238           21      19/21     21/23 admitted_beyond_seed
            M10_no_slot_species_filter    11/10 1.100000           10       9/10     10/11 admitted_beyond_seed
            M10_no_slot_species_filter    21/19 1.105263           19      17/19     19/21 admitted_beyond_seed
            M10_no_slot_species_filter     10/9 1.111111            9        8/9      9/10 admitted_beyond_seed
            M10_no_slot_species_filter    19/17 1.117647           17      15/17     17/19 admitted_beyond_seed
            M10_no_slot_species_filter      9/8 1.125000            8        7/8       8/9 admitted_beyond_seed
            M10_no_slot_species_filter    17/15 1.133333           15      13/15     15/17 admitted_beyond_seed
            M10_no_slot_species_filter      8/7 1.142857            7        6/7       7/8 admitted_beyond_seed
            M10_no_slot_species_filter    15/13 1.153846           13      11/13     13/15 admitted_beyond_seed
            M10_no_slot_species_filter      7/6 1.166667            6        5/6       6/7 admitted_beyond_seed
            M10_no_slot_species_filter    13/11 1.181818           11       9/11     11/13 admitted_beyond_seed
            M10_no_slot_species_filter      6/5 1.200000            5        4/5       5/6 admitted_beyond_seed
            M10_no_slot_species_filter     11/9 1.222222            9        7/9      9/11 admitted_beyond_seed
            M10_no_slot_species_filter      9/7 1.285714            7        5/7       7/9 admitted_beyond_seed
            M10_no_slot_species_filter      7/5 1.400000            5        3/5       5/7 admitted_beyond_seed
              M11_all_rationals_domain      7/4 1.750000            4        1/4       4/7 admitted_beyond_seed
M12_promote_virtual_anchors_to_species      1/3 0.333333            3        5/3         3 admitted_beyond_seed

## Remaining open item

R104 consolidates the operator-origin theorem stack. It does not derive the local PDE/action field implementation.

## Recommended next

BOXED: FORCE_R105 — Field/Action/PDE Implementation Readiness Gate
