from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R106_candidate_worldline_tube_phase_boundary_action_gate")
ZIP = Path("FORCE_R106_candidate_worldline_tube_phase_boundary_action_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R106 — Candidate Worldline-Tube Phase/Boundary Action Gate
#
# R105 established the guardrails:
#
#   Do not insert the nine seed modes.
#   Do not use a polynomial with seed roots.
#   Do not use a nonlocal global oracle.
#   Use local phase/cadence, binary write, normal-frame, R-complement,
#   C-cadence-return, and species/support separation ingredients.
#
# R106 question:
#
#   Can we write a first explicit no-smuggling action/constraint blueprint
#   whose operator consequences reproduce:
#
#       anchors {1,1/2,1/3}
#       R(rho)=2-rho
#       C(rho)=1/rho
#       rho >= 1/2
#       denom(rho) <= 4
#
#   and therefore select:
#
#       {1/2,2/3,3/4,1,5/4,4/3,3/2,5/3,2}
#
# without inserting that target list into the action?
#
# Claim boundary:
# - R106 proposes and audits a candidate action/constraint blueprint.
# - R106 does not prove the Euler-Lagrange equations yet.
# - R106 does not close the PDE/field derivation.
# - R106 does not claim physical particle spectrum, masses, SM matching, or Omega0.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def R_factory(T):
    def R(x):
        return T - x
    return R

def C_factory(A):
    def C(x):
        if x == 0:
            return None
        return A / x
    return C

def close_domain(anchors, max_den, R_func=None, C_func=None):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(900):
        before = set(active)

        for x in list(active):
            if R_func is not None:
                y = R_func(x)
                if y == 0:
                    boundary_used = True
                elif in_interval(y) and y in universe:
                    active.add(y)

            if C_func is not None:
                y = C_func(x)
                if in_interval(y) and y in universe:
                    active.add(y)

        if active == before:
            break

    return active, boundary_used

def stable_by_domain(domain, max_den, binary_filter=True, slot_cap=None):
    universe = rational_universe(max_den)
    stable = set()

    for x in universe:
        if x not in domain:
            continue
        if binary_filter and x < Fraction(1, 2):
            continue
        if slot_cap is not None and x.denominator > slot_cap:
            continue
        stable.add(x)

    return stable

def derive_anchors_from_terms(model):
    anchors = set()

    if model["term_phase_identity"]:
        anchors.add(Fraction(1, 1))

    if model["term_binary_write"]:
        anchors.add(Fraction(1, 2))

    if model["term_normal_bundle"]:
        D = model["normal_dimension"]
        anchors.add(Fraction(1, D))

    return anchors

def derive_maps_from_terms(model):
    R_func = None
    C_func = None

    if model["term_R_complement"]:
        R_func = R_factory(model["R_total"])

    if model["term_C_return"]:
        C_func = C_factory(model["C_product"])

    return R_func, C_func

def derive_species_filters_from_terms(model):
    binary_filter = model["term_binary_write"] and model["species_binary_filter"]

    slot_cap = None
    if model["term_normal_bundle"] and model["species_slot_filter"]:
        slot_cap = 1 + model["normal_dimension"]

    return binary_filter, slot_cap

def evaluate_model(model, max_den):
    if model["target_seed_lookup"]:
        domain = set(SEED)
        stable = set(SEED)
        return {
            "anchors": set(),
            "domain": domain,
            "stable": stable,
            "boundary_used": False,
            "R_func": None,
            "C_func": None,
            "binary_filter": False,
            "slot_cap": None,
        }

    anchors = derive_anchors_from_terms(model)
    R_func, C_func = derive_maps_from_terms(model)
    binary_filter, slot_cap = derive_species_filters_from_terms(model)

    if model["all_rationals_domain"]:
        domain = rational_universe(max_den)
        boundary_used = True
    else:
        domain, boundary_used = close_domain(anchors, max_den, R_func=R_func, C_func=C_func)

    stable = stable_by_domain(domain, max_den, binary_filter=binary_filter, slot_cap=slot_cap)

    if model["promote_support_to_species"]:
        stable |= set(domain)

    return {
        "anchors": anchors,
        "domain": domain,
        "stable": stable,
        "boundary_used": boundary_used,
        "R_func": R_func,
        "C_func": C_func,
        "binary_filter": binary_filter,
        "slot_cap": slot_cap,
    }

# ---------------------------------------------------------------------
# 1. Candidate action routes.
# ---------------------------------------------------------------------

base = {
    "target_seed_lookup": False,
    "polynomial_seed_roots": False,
    "global_nonlocal_oracle": False,
    "local_fields": True,
    "action_principle": True,
    "term_phase_identity": True,
    "term_binary_write": True,
    "term_normal_bundle": True,
    "normal_dimension": 3,
    "term_R_complement": True,
    "R_total": Fraction(2, 1),
    "term_C_return": True,
    "C_product": Fraction(1, 1),
    "species_binary_filter": True,
    "species_slot_filter": True,
    "support_species_split": True,
    "all_rationals_domain": False,
    "promote_support_to_species": False,
    "expected": "PASS_EXACT_SEED",
}

models = [
    {
        **base,
        "model": "A0_seed_lookup_oracle",
        "description": "Directly returns the nine seed modes.",
        "target_seed_lookup": True,
        "polynomial_seed_roots": False,
        "global_nonlocal_oracle": True,
        "local_fields": False,
        "action_principle": False,
        "expected": "REJECT_TARGET_SMUGGLING",
    },
    {
        **base,
        "model": "A1_polynomial_roots_at_seed",
        "description": "Potential V(rho)=product over seed roots.",
        "target_seed_lookup": True,
        "polynomial_seed_roots": True,
        "global_nonlocal_oracle": False,
        "local_fields": False,
        "action_principle": True,
        "expected": "REJECT_TARGET_SMUGGLING",
    },
    {
        **base,
        "model": "A2_global_operator_oracle",
        "description": "Nonlocal oracle reproduces the operator stack.",
        "global_nonlocal_oracle": True,
        "local_fields": False,
        "action_principle": False,
        "expected": "REJECT_NONLOCAL_ORACLE",
    },
    {
        **base,
        "model": "A3_phase_only",
        "description": "Only local phase/cadence identity term.",
        "term_binary_write": False,
        "term_normal_bundle": False,
        "term_R_complement": False,
        "term_C_return": False,
        "species_binary_filter": False,
        "species_slot_filter": False,
        "expected": "FAIL_TOO_WEAK",
    },
    {
        **base,
        "model": "A4_binary_only_plus_phase",
        "description": "Phase plus binary write, no normal bundle.",
        "term_normal_bundle": False,
        "species_slot_filter": False,
        "expected": "FAIL_MISSING_TRINORMAL_AND_SLOT",
    },
    {
        **base,
        "model": "A5_normal_only_plus_phase",
        "description": "Phase plus normal bundle, no binary write.",
        "term_binary_write": False,
        "species_binary_filter": False,
        "expected": "FAIL_MISSING_BINARY",
    },
    {
        **base,
        "model": "A6_no_R_complement",
        "description": "Full local structure but no R complement term.",
        "term_R_complement": False,
        "expected": "FAIL_MISSING_R",
    },
    {
        **base,
        "model": "A7_no_C_return",
        "description": "Full local structure but no C cadence-return term.",
        "term_C_return": False,
        "expected": "FAIL_MISSING_C",
    },
    {
        **base,
        "model": "A8_wrong_R_total_3_2",
        "description": "Wrong R constraint: rho+rho_R=3/2.",
        "R_total": Fraction(3, 2),
        "expected": "FAIL_WRONG_R",
    },
    {
        **base,
        "model": "A9_wrong_C_product_2_3",
        "description": "Wrong C constraint: rho*rho_C=2/3.",
        "C_product": Fraction(2, 3),
        "expected": "FAIL_WRONG_C",
    },
    {
        **base,
        "model": "A10_wrong_normal_dimension_4",
        "description": "Four-normal replacement D_perp=4.",
        "normal_dimension": 4,
        "expected": "FAIL_7_4_INTRUDER",
    },
    {
        **base,
        "model": "A11_no_binary_species_filter",
        "description": "Keep binary anchor but remove rho>=1/2 species filter.",
        "species_binary_filter": False,
        "expected": "FAIL_SUBHALF_INTRUDER",
    },
    {
        **base,
        "model": "A12_no_slot_species_filter",
        "description": "Keep normal bundle but remove denom<=4 species filter.",
        "species_slot_filter": False,
        "expected": "FAIL_DENOM_INTRUDERS",
    },
    {
        **base,
        "model": "A13_all_rationals_domain",
        "description": "Remove support-domain selectivity.",
        "all_rationals_domain": True,
        "expected": "FAIL_7_4_INTRUDER",
    },
    {
        **base,
        "model": "A14_promote_support_to_species",
        "description": "Collapse support/species distinction.",
        "promote_support_to_species": True,
        "expected": "FAIL_VIRTUAL_SUPPORT_SPECIES_INTRUDERS",
    },
    {
        **base,
        "model": "A15_candidate_worldline_tube_phase_boundary_action",
        "description": "No-smuggling coupled phase/binary/normal/R/C action blueprint.",
        "expected": "PASS_EXACT_SEED",
    },
]

score_rows = []
interval_rows = []
intruder_rows = []

for m in models:
    exact_all = True
    final = None

    for max_den in DENOM_AUDITS:
        res = evaluate_model(m, max_den)
        stable = res["stable"]
        domain = res["domain"]
        anchors = res["anchors"]

        exact = stable == SEED
        if not exact:
            exact_all = False

        interval_rows.append({
            "model": m["model"],
            "max_den": max_den,
            "anchor_set": label_set(anchors),
            "domain_count": len(domain),
            "stable_count": len(stable),
            "stable_fractions": label_set(stable),
            "exact_seed": exact,
            "extra_vs_seed": label_set(stable - SEED),
            "missing_from_seed": label_set(SEED - stable),
            "boundary_used": res["boundary_used"],
            "slot_cap": res["slot_cap"] if res["slot_cap"] is not None else "none",
            "binary_filter": res["binary_filter"],
        })

        if max_den == DENOM_AUDITS[-1]:
            final = res
            for x in sorted(stable - SEED):
                intruder_rows.append({
                    "model": m["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": frac_label(R_factory(Fraction(2, 1))(x)),
                    "C_partner": frac_label(C_factory(Fraction(1, 1))(x)),
                    "reason": "admitted_beyond_seed",
                })
            for x in sorted(SEED - stable):
                intruder_rows.append({
                    "model": m["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": frac_label(R_factory(Fraction(2, 1))(x)),
                    "C_partner": frac_label(C_factory(Fraction(1, 1))(x)),
                    "reason": "seed_mode_rejected",
                })

    smuggling = bool(m["target_seed_lookup"] or m["polynomial_seed_roots"])
    nonlocal_oracle = bool(m["global_nonlocal_oracle"] or not m["local_fields"])

    if exact_all and m["expected"].startswith("PASS") and not smuggling and not nonlocal_oracle:
        survivor_status = "PASS_EXACT_SEED_NO_SMUGGLING_BLUEPRINT"
    elif (smuggling or nonlocal_oracle) and m["expected"].startswith("REJECT"):
        survivor_status = "PASS_REJECTED_FAKE_SOLUTION"
    elif (not exact_all) and m["expected"].startswith("FAIL"):
        survivor_status = "PASS_CONTROL_FAILED_AS_EXPECTED"
    elif exact_all and m["expected"].startswith("FAIL"):
        survivor_status = "UNEXPECTED_EXACT_SEED"
    else:
        survivor_status = "PARTIAL"

    derives_anchors = final["anchors"] == {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
    derives_R = bool(m["term_R_complement"] and m["R_total"] == Fraction(2, 1))
    derives_C = bool(m["term_C_return"] and m["C_product"] == Fraction(1, 1))
    derives_filters = bool(final["binary_filter"] and final["slot_cap"] == 4)
    local_variational = bool(m["local_fields"] and m["action_principle"])
    no_smuggling = not smuggling and not nonlocal_oracle

    readiness_score = sum([
        bool(m["local_fields"]),
        bool(m["action_principle"]),
        derives_anchors,
        derives_R,
        derives_C,
        derives_filters,
        bool(m["support_species_split"]),
        exact_all,
        no_smuggling,
        local_variational,
    ])

    score_rows.append({
        "model": m["model"],
        "description": m["description"],
        "anchor_set_final": label_set(final["anchors"]),
        "domain_count_final": len(final["domain"]),
        "stable_count_final": len(final["stable"]),
        "stable_fractions_final": label_set(final["stable"]),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(final["stable"] - SEED),
        "missing_from_seed": label_set(SEED - final["stable"]),
        "target_seed_lookup": m["target_seed_lookup"],
        "polynomial_seed_roots": m["polynomial_seed_roots"],
        "global_nonlocal_oracle": m["global_nonlocal_oracle"],
        "local_fields": m["local_fields"],
        "action_principle": m["action_principle"],
        "derives_anchors": derives_anchors,
        "derives_R": derives_R,
        "derives_C": derives_C,
        "derives_filters": derives_filters,
        "support_species_split": m["support_species_split"],
        "no_smuggling": no_smuggling,
        "local_variational": local_variational,
        "readiness_score": readiness_score,
        "expected": m["expected"],
        "survivor_status": survivor_status,
    })

scorecard = pd.DataFrame(score_rows).sort_values(
    ["readiness_score", "exact_seed_all_denominators"],
    ascending=[False, False]
).reset_index(drop=True)

interval_audit = pd.DataFrame(interval_rows)
intruder_audit = pd.DataFrame(intruder_rows)

# ---------------------------------------------------------------------
# 2. Candidate action blueprint terms.
# ---------------------------------------------------------------------

action_terms = pd.DataFrame([
    {
        "term_id": "S_phase",
        "action_or_constraint_form": "∫ dτ Kθ (Dτθ - Ω)^2",
        "operator_consequence": "identity/base cadence anchor 1",
        "no_smuggling_check": "does not contain seed list",
        "status": "DEFINED_BLUEPRINT_TERM",
    },
    {
        "term_id": "S_binary",
        "action_or_constraint_form": "Π_no-overlap[write_cell(θ_n), write_cell(θ_{n+1})]",
        "operator_consequence": "binary anchor 1/2 and species filter rho>=1/2",
        "no_smuggling_check": "depends on binary predicate, not target modes",
        "status": "DEFINED_BLUEPRINT_TERM",
    },
    {
        "term_id": "S_normal",
        "action_or_constraint_form": "∫ dτ K_N Σ_{i=1}^{3} ||Dτ n_i||^2",
        "operator_consequence": "tri-normal virtual support anchor 1/3 and slot cap 1+3=4",
        "no_smuggling_check": "uses normal-frame dimension, not seed roots",
        "status": "DEFINED_BLUEPRINT_TERM",
    },
    {
        "term_id": "S_R",
        "action_or_constraint_form": "λ_R (ρ + ρ_R - 2)^2",
        "operator_consequence": "R(ρ)=2-ρ",
        "no_smuggling_check": "enforces complement total, not seed list",
        "status": "DEFINED_BLUEPRINT_TERM",
    },
    {
        "term_id": "S_C",
        "action_or_constraint_form": "λ_C (ρ ρ_C - 1)^2",
        "operator_consequence": "C(ρ)=1/ρ",
        "no_smuggling_check": "enforces cadence-return product, not seed list",
        "status": "DEFINED_BLUEPRINT_TERM",
    },
    {
        "term_id": "S_slot",
        "action_or_constraint_form": "rank_allowed = 1 tangent + 3 normal slots",
        "operator_consequence": "denom(ρ)<=4 for stable species",
        "no_smuggling_check": "uses 3+1 capacity, not denominator deletion by hand",
        "status": "DEFINED_BLUEPRINT_TERM",
    },
    {
        "term_id": "S_split",
        "action_or_constraint_form": "species_domain = support_domain ∩ binary_filter ∩ slot_filter",
        "operator_consequence": "1/3, 3/5, 4/5 are support-active but species-inactive",
        "no_smuggling_check": "projection rule, not manual virtual-mode deletion",
        "status": "DEFINED_BLUEPRINT_TERM",
    },
])

constraint_equations = pd.DataFrame([
    {
        "constraint": "phase identity",
        "stationarity_or_rule": "δS_phase/δΩ -> Ω=Ω0",
        "operator_target": "ρ=1",
        "status": "BLUEPRINT_ONLY_VARIATION_NEXT",
    },
    {
        "constraint": "binary write no-overlap",
        "stationarity_or_rule": "cell width = 1/2; accept iff Δθ>=1/2",
        "operator_target": "anchor 1/2 and ρ>=1/2",
        "status": "BLUEPRINT_ONLY_VARIATION_NEXT",
    },
    {
        "constraint": "normal-frame equal share",
        "stationarity_or_rule": "D_perp=3 equal support share",
        "operator_target": "anchor 1/3 and cap 4",
        "status": "BLUEPRINT_ONLY_VARIATION_NEXT",
    },
    {
        "constraint": "reflection complement",
        "stationarity_or_rule": "∂/∂ρ_R λ_R(ρ+ρ_R-2)^2=0",
        "operator_target": "ρ_R=2-ρ",
        "status": "CONSTRAINT_STATIONARITY_FORMAL",
    },
    {
        "constraint": "cadence return",
        "stationarity_or_rule": "∂/∂ρ_C λ_C(ρρ_C-1)^2=0",
        "operator_target": "ρ_C=1/ρ",
        "status": "CONSTRAINT_STATIONARITY_FORMAL",
    },
    {
        "constraint": "species projection",
        "stationarity_or_rule": "support domain projected through binary and slot filters",
        "operator_target": "nine-mode mechanical seed",
        "status": "BLUEPRINT_ONLY_PROJECTION_NEXT",
    },
])

# ---------------------------------------------------------------------
# 3. Best candidate and truth/projection audit.
# ---------------------------------------------------------------------

best = scorecard[scorecard["model"] == "A15_candidate_worldline_tube_phase_boundary_action"].iloc[0]
best_res = evaluate_model(models[-1], max(DENOM_AUDITS))
best_domain = best_res["domain"]
best_stable = best_res["stable"]

support_rows = []
for x in sorted(SEED | VIRTUAL_SUPPORTS | {Fraction(1, 4), Fraction(7, 4), Fraction(6, 5), Fraction(7, 5)}):
    r = R_factory(Fraction(2, 1))(x)
    c = C_factory(Fraction(1, 1))(x)

    support_rows.append({
        "rho_fraction": frac_label(x),
        "rho": float(x),
        "denominator": x.denominator,
        "in_support_domain": x in best_domain,
        "stable_species": x in best_stable,
        "binary_accept": x >= Fraction(1, 2),
        "slot_accept": x.denominator <= 4,
        "R_partner": frac_label(r),
        "R_supported": True if r == 0 else r in best_domain,
        "C_partner": frac_label(c),
        "C_supported": in_interval(c) and c in best_domain,
        "role": (
            "stable_seed"
            if x in best_stable
            else (
                "virtual_support"
                if x in VIRTUAL_SUPPORTS
                else "rejected_control"
            )
        ),
    })

support_projection_audit = pd.DataFrame(support_rows)

# ---------------------------------------------------------------------
# 4. No-smuggling audit.
# ---------------------------------------------------------------------

fake_solution_audit = pd.DataFrame([
    {
        "model": row["model"],
        "exact_seed_all_denominators": row["exact_seed_all_denominators"],
        "target_seed_lookup": row["target_seed_lookup"],
        "polynomial_seed_roots": row["polynomial_seed_roots"],
        "global_nonlocal_oracle": row["global_nonlocal_oracle"],
        "local_fields": row["local_fields"],
        "no_smuggling": row["no_smuggling"],
        "rejected_as_fake_solution": (
            row["target_seed_lookup"]
            or row["polynomial_seed_roots"]
            or row["global_nonlocal_oracle"]
            or not row["local_fields"]
        ),
        "reason": (
            "target seed lookup"
            if row["target_seed_lookup"]
            else (
                "polynomial roots at seed"
                if row["polynomial_seed_roots"]
                else (
                    "global nonlocal oracle"
                    if row["global_nonlocal_oracle"]
                    else (
                        "nonlocal / no local fields"
                        if not row["local_fields"]
                        else "not fake; may be partial/open"
                    )
                )
            )
        ),
    }
    for _, row in scorecard.iterrows()
])

# ---------------------------------------------------------------------
# 5. Verdict booleans.
# ---------------------------------------------------------------------

good_exact_seed = bool(best["exact_seed_all_denominators"])
good_no_smuggling = bool(best["no_smuggling"])
good_local_variational = bool(best["local_variational"])
good_derives_anchors = bool(best["derives_anchors"])
good_derives_R = bool(best["derives_R"])
good_derives_C = bool(best["derives_C"])
good_derives_filters = bool(best["derives_filters"])
good_virtual_support_split = all(
    v in best_domain and v not in best_stable for v in VIRTUAL_SUPPORTS
)
good_excludes_intruders = Fraction(7, 4) not in best_domain and Fraction(7, 4) not in best_stable
fake_exact_routes_rejected = all(
    bool(row["rejected_as_fake_solution"])
    for _, row in fake_solution_audit.iterrows()
    if bool(row["exact_seed_all_denominators"]) and not bool(row["no_smuggling"])
)
structural_controls_fail = all(
    row["survivor_status"] in {
        "PASS_CONTROL_FAILED_AS_EXPECTED",
        "PASS_REJECTED_FAKE_SOLUTION",
        "PASS_EXACT_SEED_NO_SMUGGLING_BLUEPRINT",
    }
    for _, row in scorecard.iterrows()
)
action_terms_defined = len(action_terms) == 7
constraint_equations_defined = len(constraint_equations) == 6
variation_closed = False
PDE_closed = False
physical_spectrum_claimed = False

if (
    good_exact_seed
    and good_no_smuggling
    and good_local_variational
    and good_derives_anchors
    and good_derives_R
    and good_derives_C
    and good_derives_filters
    and good_virtual_support_split
    and good_excludes_intruders
    and fake_exact_routes_rejected
    and structural_controls_fail
    and action_terms_defined
    and constraint_equations_defined
    and not variation_closed
    and not PDE_closed
):
    verdict_status = "CANDIDATE WORLDLINE-TUBE PHASE/BOUNDARY ACTION BLUEPRINT PASS / VARIATIONAL PDE DERIVATION STILL OPEN"
elif good_exact_seed and good_no_smuggling:
    verdict_status = "CANDIDATE ACTION BLUEPRINT SIGNAL PASS / SOME GUARDRAILS OPEN"
else:
    verdict_status = "CANDIDATE ACTION BLUEPRINT INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "good_exact_seed",
        "result": "PASS" if good_exact_seed else "WARN",
        "interpretation": "The candidate action blueprint reproduces the exact nine-mode operator seed.",
    },
    {
        "test": "good_no_smuggling",
        "result": "PASS" if good_no_smuggling else "WARN",
        "interpretation": "The candidate does not use seed lookup, seed-root polynomial, or nonlocal oracle.",
    },
    {
        "test": "good_local_variational",
        "result": "PASS" if good_local_variational else "WARN",
        "interpretation": "The candidate has local fields and an action/constraint functional form.",
    },
    {
        "test": "good_derives_anchors",
        "result": "PASS" if good_derives_anchors else "WARN",
        "interpretation": "The candidate derives anchors {1,1/2,1/3} from phase, binary write, and tri-normal bundle terms.",
    },
    {
        "test": "good_derives_R",
        "result": "PASS" if good_derives_R else "WARN",
        "interpretation": "The candidate contains the complement constraint yielding R(rho)=2-rho.",
    },
    {
        "test": "good_derives_C",
        "result": "PASS" if good_derives_C else "WARN",
        "interpretation": "The candidate contains the cadence-return constraint yielding C(rho)=1/rho.",
    },
    {
        "test": "good_derives_filters",
        "result": "PASS" if good_derives_filters else "WARN",
        "interpretation": "The candidate derives rho>=1/2 and denom<=4 from binary write and 3+1 slot capacity.",
    },
    {
        "test": "good_virtual_support_split",
        "result": "PASS" if good_virtual_support_split else "WARN",
        "interpretation": "1/3, 3/5, and 4/5 remain support-active but species-inactive.",
    },
    {
        "test": "good_excludes_intruders",
        "result": "PASS" if good_excludes_intruders else "WARN",
        "interpretation": "The candidate excludes the main 7/4 intruder.",
    },
    {
        "test": "fake_exact_routes_rejected",
        "result": "PASS" if fake_exact_routes_rejected else "WARN",
        "interpretation": "Exact but smuggled/nonlocal routes are rejected.",
    },
    {
        "test": "variation_closed",
        "result": "OPEN",
        "interpretation": "R106 defines stationarity targets but does not yet prove Euler-Lagrange derivation.",
    },
    {
        "test": "PDE_closed",
        "result": "OPEN",
        "interpretation": "R106 is not a completed PDE implementation.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R106 gives a no-smuggling candidate action/constraint blueprint.",
        "status": "YES",
        "reason": "The best candidate reproduces the operator seed from phase, binary, normal, R, C, and projection terms without seed lookup.",
    },
    {
        "claim": "R106 proves the Euler-Lagrange field equations.",
        "status": "NO",
        "reason": "R106 defines formal stationarity/constraint targets; variation is deferred to R107.",
    },
    {
        "claim": "R106 closes the full field/action/PDE derivation.",
        "status": "NO",
        "reason": "PDE implementation remains open.",
    },
    {
        "claim": "Seed lookup or polynomial roots are valid derivations.",
        "status": "NO",
        "reason": "They are rejected as target-smuggling.",
    },
    {
        "claim": "Virtual support channels are stable species.",
        "status": "NO",
        "reason": "1/3, 3/5, and 4/5 remain support-active but species-inactive.",
    },
    {
        "claim": "The nine-mode seed is a confirmed physical particle spectrum.",
        "status": "NO",
        "reason": "It remains a mechanical seed until physical field, mass, and interaction bridges are derived.",
    },
    {
        "claim": "Masses, SM matching, or Omega0 are derived.",
        "status": "NO",
        "reason": "Those are not addressed in R106.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R107",
        "title": "Euler-Lagrange / Constraint Variation Gate",
        "goal": "Vary the R106 functional and check whether the desired stationarity equations actually follow.",
        "must_not_do": "Do not assume constraints are equations of motion without variation.",
    },
    {
        "next_gate": "FORCE_R108",
        "title": "Locality and Gauge/Frame Relabeling Gate",
        "goal": "Check phase gauge and normal-frame relabeling covariance of the action blueprint.",
        "must_not_do": "Do not hide a global ledger oracle in the boundary terms.",
    },
    {
        "next_gate": "FORCE_R109",
        "title": "Support-to-Species Projection Gate",
        "goal": "Derive the support/species split from the action/projection structure.",
        "must_not_do": "Do not delete virtual modes by hand.",
    },
])

# Save artifacts.
scorecard.to_csv(OUT / "FORCE_R106_candidate_action_scorecard.csv", index=False)
interval_audit.to_csv(OUT / "FORCE_R106_interval_audit.csv", index=False)
intruder_audit.to_csv(OUT / "FORCE_R106_intruder_and_missing_seed_audit.csv", index=False)
action_terms.to_csv(OUT / "FORCE_R106_candidate_action_terms.csv", index=False)
constraint_equations.to_csv(OUT / "FORCE_R106_constraint_equation_targets.csv", index=False)
support_projection_audit.to_csv(OUT / "FORCE_R106_support_species_projection_audit.csv", index=False)
fake_solution_audit.to_csv(OUT / "FORCE_R106_fake_solution_rejection_audit.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R106_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R106_claim_boundary_matrix.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R106_next_gate_plan.csv", index=False)

verdict = {
    "force_id": "FORCE_R106",
    "title": "Candidate Worldline-Tube Phase/Boundary Action Gate",
    "status": verdict_status,
    "good_exact_seed": good_exact_seed,
    "good_no_smuggling": good_no_smuggling,
    "good_local_variational": good_local_variational,
    "good_derives_anchors": good_derives_anchors,
    "good_derives_R": good_derives_R,
    "good_derives_C": good_derives_C,
    "good_derives_filters": good_derives_filters,
    "good_virtual_support_split": good_virtual_support_split,
    "good_excludes_intruders": good_excludes_intruders,
    "fake_exact_routes_rejected": fake_exact_routes_rejected,
    "action_terms_defined": action_terms_defined,
    "constraint_equations_defined": constraint_equations_defined,
    "variation_closed": variation_closed,
    "PDE_closed": PDE_closed,
    "physical_spectrum_claimed": physical_spectrum_claimed,
    "recommended_next": "FORCE_R107_euler_lagrange_constraint_variation_gate",
}
(OUT / "FORCE_R106_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R106 — Candidate Worldline-Tube Phase/Boundary Action Gate

## Verdict

BOXED: {verdict_status}

## Candidate action blueprint

BOXED:
S = S_phase + S_binary + S_normal + S_R + S_C + S_slot + S_split

where:

- S_phase supplies identity/base cadence.
- S_binary supplies binary no-overwrite and rho>=1/2.
- S_normal supplies three normal directions, 1/3 virtual support, and 1+3 slot capacity.
- S_R supplies R(rho)=2-rho.
- S_C supplies C(rho)=1/rho.
- S_slot supplies denom(rho)<=4.
- S_split separates support channels from stable species.

## Selected seed

BOXED: {label_set(best_stable)}

## Key booleans

- good_exact_seed: {good_exact_seed}
- good_no_smuggling: {good_no_smuggling}
- good_local_variational: {good_local_variational}
- good_derives_anchors: {good_derives_anchors}
- good_derives_R: {good_derives_R}
- good_derives_C: {good_derives_C}
- good_derives_filters: {good_derives_filters}
- good_virtual_support_split: {good_virtual_support_split}
- good_excludes_intruders: {good_excludes_intruders}
- fake_exact_routes_rejected: {fake_exact_routes_rejected}
- variation_closed: {variation_closed}
- PDE_closed: {PDE_closed}

## Gate audit

{audit_df.to_string(index=False)}

## Candidate action scorecard

{scorecard.to_string(index=False)}

## Action terms

{action_terms.to_string(index=False)}

## Constraint equation targets

{constraint_equations.to_string(index=False)}

## Support/species projection audit

{support_projection_audit.to_string(index=False)}

## Fake solution rejection audit

{fake_solution_audit.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}

## Intruder / missing seed audit

{intruder_audit.to_string(index=False) if len(intruder_audit) else "none"}

## Recommended next

BOXED: FORCE_R107 — Euler-Lagrange / Constraint Variation Gate
"""
(OUT / "FORCE_R106_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R106_candidate_worldline_tube_phase_boundary_action_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R106_summary.md", "role": "summary"},
    {"file": "FORCE_R106_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R106_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R106_candidate_action_scorecard.csv", "role": "candidate action scorecard"},
    {"file": "FORCE_R106_interval_audit.csv", "role": "interval audit"},
    {"file": "FORCE_R106_intruder_and_missing_seed_audit.csv", "role": "intruder audit"},
    {"file": "FORCE_R106_candidate_action_terms.csv", "role": "candidate action terms"},
    {"file": "FORCE_R106_constraint_equation_targets.csv", "role": "constraint equation targets"},
    {"file": "FORCE_R106_support_species_projection_audit.csv", "role": "support/species projection audit"},
    {"file": "FORCE_R106_fake_solution_rejection_audit.csv", "role": "fake solution rejection audit"},
    {"file": "FORCE_R106_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R106_next_gate_plan.csv", "role": "next gate plan"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(13, 5))
plt.bar(scorecard["model"], scorecard["readiness_score"])
plt.xticks(rotation=40, ha="right")
plt.ylabel("readiness score")
plt.title("R106 candidate action route readiness")
plt.tight_layout()
plt.savefig(PLOTS / "candidate_action_readiness_scores.png", dpi=160)
plt.close()

plt.figure(figsize=(13, 5))
plt.bar(scorecard["model"], scorecard["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xticks(rotation=40, ha="right")
plt.ylabel("stable count")
plt.title("R106 stable count by candidate action/control")
plt.tight_layout()
plt.savefig(PLOTS / "candidate_action_stable_counts.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

compact_scorecard = scorecard[[
    "model",
    "stable_count_final",
    "stable_fractions_final",
    "exact_seed_all_denominators",
    "no_smuggling",
    "local_variational",
    "readiness_score",
    "survivor_status",
]]

print("\n=== COPY/PASTE R106 RESULT ===")
print("R106 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"good_exact_seed: {good_exact_seed}")
print(f"selected_seed: {label_set(best_stable)}")
print(f"good_no_smuggling: {good_no_smuggling}")
print(f"good_local_variational: {good_local_variational}")
print(f"good_derives_anchors: {good_derives_anchors}")
print(f"good_derives_R: {good_derives_R}")
print(f"good_derives_C: {good_derives_C}")
print(f"good_derives_filters: {good_derives_filters}")
print(f"good_virtual_support_split: {good_virtual_support_split}")
print(f"good_excludes_intruders: {good_excludes_intruders}")
print(f"fake_exact_routes_rejected: {fake_exact_routes_rejected}")
print(f"action_terms_defined: {action_terms_defined}")
print(f"constraint_equations_defined: {constraint_equations_defined}")
print(f"variation_closed: {variation_closed}")
print(f"PDE_closed: {PDE_closed}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("CANDIDATE_ACTION_SCORECARD:")
print(compact_scorecard.to_string(index=False))
print("ACTION_TERMS:")
print(action_terms.to_string(index=False))
print("CONSTRAINT_EQUATION_TARGETS:")
print(constraint_equations.to_string(index=False))
print("SUPPORT_SPECIES_PROJECTION_AUDIT:")
print(support_projection_audit.to_string(index=False))
print("FAKE_SOLUTION_REJECTION_AUDIT:")
print(fake_solution_audit.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print("INTRUDER_AND_MISSING_SEED_AUDIT:")
print(intruder_audit.to_string(index=False) if len(intruder_audit) else "none")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R106_summary.md').resolve()}")
print("NEXT: FORCE_R107_euler_lagrange_constraint_variation_gate")
print("=== END COPY/PASTE R106 RESULT ===\n")
