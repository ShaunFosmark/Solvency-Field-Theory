# FORCE_R109 — Discrete Binary No-Overlap Variation Gate

## Verdict

BOXED: DISCRETE BINARY KKT NO-OVERLAP PASS / WIDTH ORIGIN INHERITED AND SMOOTH PDE DERIVATION OPEN

## Central result

Given binary write-cell width:

BOXED: w = 1/2

the no-overlap inequality is:

BOXED: g(rho)=rho-w>=0

The minimal-advance KKT problem:

BOXED: minimize 1/2 k rho^2 subject to rho-w>=0

has boundary solution:

BOXED: rho_* = w = 1/2

Therefore admissibility is:

BOXED: rho >= 1/2

## Selected seed

BOXED: 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2

## Key booleans

- K2_KKT_pass: True
- K2_operator_exact: True
- K2_minimal_binary_record: True
- integer_K_controls_fail: True
- binary_controls_fail: True
- subhalf_virtual_rejected: True
- denom5_virtual_rejected: True
- truth_table_exact_seed: True
- arbitrary_width_tuning_risk_detected: True
- width_origin_inherited_from_binary_record: True
- smooth_PDE_closed: False

## Gate audit

                                test result                                                                                                interpretation
                         K2_KKT_pass   PASS            For binary width w=1/2, KKT stationarity, feasibility, dual feasibility, and complementarity pass.
                   K2_operator_exact   PASS           The binary K=2 threshold reconstructs the exact nine-mode seed with the R/C domain and slot filter.
             integer_K_controls_fail   PASS                   K=1 is too strict; K>=3 admits surplus/subhalf structure or otherwise fails exact recovery.
                binary_controls_fail   PASS                                          No-binary, wrong-sign, no-slot, and non-binary record controls fail.
            subhalf_virtual_rejected   PASS                                      The 1/3 tri-normal support channel is rejected as a species by rho>=1/2.
             denom5_virtual_rejected   PASS                                                    3/5 and 4/5 remain rejected as species by the slot filter.
              truth_table_exact_seed   PASS                                        The R109 admissibility truth table selects exactly the nine-mode seed.
arbitrary_width_tuning_risk_detected   PASS  Arbitrary tuned widths can also work; therefore width must come from binary record cardinality, not fitting.
             K2_origin_newly_derived   OPEN R109 inherits K=2 from the binary predicate/no-overwrite stack; it does not newly derive K=2 from smooth PDE.
                   smooth_PDE_closed   OPEN                                         R109 is a discrete/KKT variational gate, not a smooth PDE derivation.

## K-record KKT boundary audit

 K_record_cells cell_width_w rho_star_minimal_nonoverlap mu_star stationarity_residual feasibility_boundary_residual complementarity_residual  dual_feasible  primal_feasible  KKT_pass                   record_status  stable_count                             stable_fractions  exact_seed extra_vs_seed missing_from_seed
              1            1                           1       1            0_boundary                    0_boundary               0_boundary           True             True      True FAIL_UNARY_CANNOT_ANSWER_YES_NO             6                     1, 5/4, 4/3, 3/2, 5/3, 2       False          none     1/2, 2/3, 3/4
              2          1/2                         1/2     1/2            0_boundary                    0_boundary               0_boundary           True             True      True  PASS_BINARY_MINIMAL_NONTRIVIAL             9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True          none              none
              3          1/3                         1/3     1/3            0_boundary                    0_boundary               0_boundary           True             True      True      FAIL_SURPLUS_RECORD_LABELS            10 1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False           1/3              none
              4          1/4                         1/4     1/4            0_boundary                    0_boundary               0_boundary           True             True      True      FAIL_SURPLUS_RECORD_LABELS            10 1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False           1/3              none
              5          1/5                         1/5     1/5            0_boundary                    0_boundary               0_boundary           True             True      True      FAIL_SURPLUS_RECORD_LABELS            10 1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False           1/3              none
              6          1/6                         1/6     1/6            0_boundary                    0_boundary               0_boundary           True             True      True      FAIL_SURPLUS_RECORD_LABELS            10 1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False           1/3              none
              7          1/7                         1/7     1/7            0_boundary                    0_boundary               0_boundary           True             True      True      FAIL_SURPLUS_RECORD_LABELS            10 1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False           1/3              none
              8          1/8                         1/8     1/8            0_boundary                    0_boundary               0_boundary           True             True      True      FAIL_SURPLUS_RECORD_LABELS            10 1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False           1/3              none

## Binary filter controls

                         model                                                    description  threshold direction slot_cap  stable_count_final                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              stable_fractions_final  exact_seed_all_denominators                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              extra_vs_seed                  missing_from_seed                    expected                  control_status
       B0_no_binary_inequality          No binary inequality; direction none and threshold 0. 0_boundary      none        4                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3                               none       FAIL_SUBHALF_INTRUDER PASS_CONTROL_FAILED_AS_EXPECTED
       B1_unary_K1_threshold_1                        Unary record K=1 gives w=1; too strict.          1        ge        4                   6                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1, 5/4, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none                      1/2, 2/3, 3/4     FAIL_MISSING_LOW_BRANCH PASS_CONTROL_FAILED_AS_EXPECTED
    B2_binary_K2_threshold_1_2                                 Binary record K=2 gives w=1/2.        1/2        ge        4                   9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none                               none             PASS_EXACT_SEED                 PASS_EXACT_SEED
   B3_ternary_K3_threshold_1_3 Ternary record K=3 gives w=1/3; admits 1/3 support as species.        1/3        ge        4                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3                               none           FAIL_1_3_INTRUDER PASS_CONTROL_FAILED_AS_EXPECTED
B4_quaternary_K4_threshold_1_4                       K=4 gives surplus labels and admits 1/3.        1/4        ge        4                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3                               none           FAIL_1_3_INTRUDER PASS_CONTROL_FAILED_AS_EXPECTED
  B5_wrong_sign_accept_overlap        Wrong inequality accepts rho<=1/2 rather than rho>=1/2.        1/2        le        4                   2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1/3, 1/2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/3 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2             FAIL_WRONG_SIGN PASS_CONTROL_FAILED_AS_EXPECTED
        B6_no_slot_cap_control                    Binary threshold kept but slot cap removed.        1/2        ge     none                  93 1/2, 3/5, 2/3, 5/7, 3/4, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 1, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 5/4, 9/7, 4/3, 7/5, 3/2, 5/3, 2                        False 3/5, 5/7, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 9/7, 7/5                               none FAIL_DENOM5_VIRTUAL_SPECIES PASS_CONTROL_FAILED_AS_EXPECTED

## Arbitrary width tuning scan

width  stable_count                             stable_fractions  exact_seed extra_vs_seed missing_from_seed  valid_binary_record_width                                         interpretation
  1/4            10 1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False           1/3              none                      False                         control width fails exact seed
  1/3            10 1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False           1/3              none                      False                         control width fails exact seed
  2/5             9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True          none              none                      False tuned exact width; reject unless independently derived
 7/16             9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True          none              none                      False tuned exact width; reject unless independently derived
  1/2             9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True          none              none                       True                                   binary-derived width
  3/5             8           2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False          none               1/2                      False                         control width fails exact seed
  2/3             8           2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False          none               1/2                      False                         control width fails exact seed
  3/4             7                3/4, 1, 5/4, 4/3, 3/2, 5/3, 2       False          none          1/2, 2/3                      False                         control width fails exact seed
    1             6                     1, 5/4, 4/3, 3/2, 5/3, 2       False          none     1/2, 2/3, 3/4                      False                         control width fails exact seed

## Admissibility truth table

rho_fraction      rho  denominator  in_support_domain g_rho_minus_1_2  binary_no_overlap_feasible  slot_accept  stable_species  selected_by_R109_filter  R_partner C_partner                     role
         1/4 0.250000            4              False            -1/4                       False         True           False                    False        7/4         4         rejected_control
         1/3 0.333333            3               True            -1/6                       False         True           False                    False        5/3         3 virtual_support_rejected
         1/2 0.500000            2               True      0_boundary                        True         True            True                     True        3/2         2              stable_seed
         3/5 0.600000            5               True            1/10                        True        False           False                    False        7/5       5/3 virtual_support_rejected
         2/3 0.666667            3               True             1/6                        True         True            True                     True        4/3       3/2              stable_seed
         3/4 0.750000            4               True             1/4                        True         True            True                     True        5/4       4/3              stable_seed
         4/5 0.800000            5               True            3/10                        True        False           False                    False        6/5       5/4 virtual_support_rejected
           1 1.000000            1               True             1/2                        True         True            True                     True          1         1              stable_seed
         6/5 1.200000            5               True            7/10                        True        False           False                    False        4/5       5/6         rejected_control
         5/4 1.250000            4               True             3/4                        True         True            True                     True        3/4       4/5              stable_seed
         4/3 1.333333            3               True             5/6                        True         True            True                     True        2/3       3/4              stable_seed
         7/5 1.400000            5               True            9/10                        True        False           False                    False        3/5       5/7         rejected_control
         3/2 1.500000            2               True               1                        True         True            True                     True        1/2       2/3              stable_seed
         5/3 1.666667            3               True             7/6                        True         True            True                     True        1/3       3/5              stable_seed
         7/4 1.750000            4              False             5/4                        True         True           False                    False        1/4       4/7         rejected_control
           2 2.000000            1               True             3/2                        True         True            True                     True 0_boundary       1/2              stable_seed

## KKT formal statement

 step                                                      statement                                                  formula                                status
    1                                 Binary record gives two cells.                                                      K=2 INHERITED_FROM_BINARY_PREDICATE_STACK
    2                            Cell width is inverse record count.                                                w=1/K=1/2                PASS_CONDITIONAL_ON_K2
    3               No-overlap inequality on unwrapped write ledger.                                          g(rho)=rho-w>=0              PASS_DISCRETE_CONSTRAINT
    4                                 Minimal-advance KKT objective.                      min 1/2 k rho^2 subject to rho-w>=0                        PASS_KKT_SETUP
    5                                              KKT stationarity.                                             k rho - mu=0                                  PASS
    6 Complementarity selects boundary for minimal admissible write.                                    mu(rho-w)=0 -> rho*=w                                  PASS
    7                                              Binary threshold.                      rho* = 1/2; admissible iff rho>=1/2                                  PASS
    8                                         Smooth PDE derivation. continuous Euler-Lagrange flow for discrete write update                                  OPEN

## Claim boundary

                                                                    claim status                                                                                                            reason
R109 derives rho>=1/2 as a binary no-overlap KKT admissibility condition.    YES               Given binary cell width w=1/2, the KKT boundary solution is rho*=1/2 and admissibility is rho>=1/2.
                                     R109 newly derives K=2 from scratch.     NO K=2 is inherited from the binary no-overwrite predicate stack; R109 derives the threshold once w=1/2 is supplied.
                                     R109 deletes sub-half modes by hand.     NO                                                        Sub-half modes violate the no-overlap inequality rho-w>=0.
                                   Arbitrary tuned widths are acceptable.     NO                           The scan detects tuned-width risk; acceptable width must be record-cardinality-derived.
                 R109 closes the smooth PDE derivation of binary writing.     NO                                             The result is a discrete/KKT variational condition, not a smooth PDE.
                                  R109 derives D_perp=3 or slot capacity.     NO                                                    Those remain assigned to the normal-bundle/slot-capacity gate.
                   R109 derives support-to-species projection completely.     NO                                It contributes the binary inequality but does not derive the whole projection map.
            The nine-mode seed is a confirmed physical particle spectrum.     NO             It remains a mechanical support seed until physical field, mass, and interaction bridges are derived.

## Next gate plan

 next_gate                                                   title                                                                                           goal                                                 must_not_do
FORCE_R110 Normal-Bundle Dimension / Slot-Capacity Derivation Gate Pressure-test whether D_perp=3 and 1+3 slot capacity arise from local worldline-tube geometry. Do not insert D_perp=3 merely because it recovers the seed.
FORCE_R111           Support-to-Species Projection Derivation Gate      Derive why support-active modes become stable species only after binary and slot filters.                     Do not delete 1/3, 3/5, or 4/5 by hand.

## Intruder / missing seed audit

                         model fraction      rho  denominator  R_partner C_partner               reason
       B0_no_binary_inequality      1/3 0.333333            3        5/3         3 admitted_beyond_seed
       B1_unary_K1_threshold_1      1/2 0.500000            2        3/2         2   seed_mode_rejected
       B1_unary_K1_threshold_1      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
       B1_unary_K1_threshold_1      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
   B3_ternary_K3_threshold_1_3      1/3 0.333333            3        5/3         3 admitted_beyond_seed
B4_quaternary_K4_threshold_1_4      1/3 0.333333            3        5/3         3 admitted_beyond_seed
  B5_wrong_sign_accept_overlap      1/3 0.333333            3        5/3         3 admitted_beyond_seed
  B5_wrong_sign_accept_overlap      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
  B5_wrong_sign_accept_overlap      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
  B5_wrong_sign_accept_overlap        1 1.000000            1          1         1   seed_mode_rejected
  B5_wrong_sign_accept_overlap      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
  B5_wrong_sign_accept_overlap      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
  B5_wrong_sign_accept_overlap      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
  B5_wrong_sign_accept_overlap      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
  B5_wrong_sign_accept_overlap        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
        B6_no_slot_cap_control      3/5 0.600000            5        7/5       5/3 admitted_beyond_seed
        B6_no_slot_cap_control      5/7 0.714286            7        9/7       7/5 admitted_beyond_seed
        B6_no_slot_cap_control      7/9 0.777778            9       11/9       9/7 admitted_beyond_seed
        B6_no_slot_cap_control      4/5 0.800000            5        6/5       5/4 admitted_beyond_seed
        B6_no_slot_cap_control     9/11 0.818182           11      13/11      11/9 admitted_beyond_seed
        B6_no_slot_cap_control      5/6 0.833333            6        7/6       6/5 admitted_beyond_seed
        B6_no_slot_cap_control    11/13 0.846154           13      15/13     13/11 admitted_beyond_seed
        B6_no_slot_cap_control      6/7 0.857143            7        8/7       7/6 admitted_beyond_seed
        B6_no_slot_cap_control    13/15 0.866667           15      17/15     15/13 admitted_beyond_seed
        B6_no_slot_cap_control      7/8 0.875000            8        9/8       8/7 admitted_beyond_seed
        B6_no_slot_cap_control    15/17 0.882353           17      19/17     17/15 admitted_beyond_seed
        B6_no_slot_cap_control      8/9 0.888889            9       10/9       9/8 admitted_beyond_seed
        B6_no_slot_cap_control    17/19 0.894737           19      21/19     19/17 admitted_beyond_seed
        B6_no_slot_cap_control     9/10 0.900000           10      11/10      10/9 admitted_beyond_seed
        B6_no_slot_cap_control    19/21 0.904762           21      23/21     21/19 admitted_beyond_seed
        B6_no_slot_cap_control    10/11 0.909091           11      12/11     11/10 admitted_beyond_seed
        B6_no_slot_cap_control    21/23 0.913043           23      25/23     23/21 admitted_beyond_seed
        B6_no_slot_cap_control    11/12 0.916667           12      13/12     12/11 admitted_beyond_seed
        B6_no_slot_cap_control    23/25 0.920000           25      27/25     25/23 admitted_beyond_seed
        B6_no_slot_cap_control    12/13 0.923077           13      14/13     13/12 admitted_beyond_seed
        B6_no_slot_cap_control    25/27 0.925926           27      29/27     27/25 admitted_beyond_seed
        B6_no_slot_cap_control    13/14 0.928571           14      15/14     14/13 admitted_beyond_seed
        B6_no_slot_cap_control    27/29 0.931034           29      31/29     29/27 admitted_beyond_seed
        B6_no_slot_cap_control    14/15 0.933333           15      16/15     15/14 admitted_beyond_seed
        B6_no_slot_cap_control    29/31 0.935484           31      33/31     31/29 admitted_beyond_seed
        B6_no_slot_cap_control    15/16 0.937500           16      17/16     16/15 admitted_beyond_seed
        B6_no_slot_cap_control    16/17 0.941176           17      18/17     17/16 admitted_beyond_seed
        B6_no_slot_cap_control    17/18 0.944444           18      19/18     18/17 admitted_beyond_seed
        B6_no_slot_cap_control    18/19 0.947368           19      20/19     19/18 admitted_beyond_seed
        B6_no_slot_cap_control    19/20 0.950000           20      21/20     20/19 admitted_beyond_seed
        B6_no_slot_cap_control    20/21 0.952381           21      22/21     21/20 admitted_beyond_seed
        B6_no_slot_cap_control    21/22 0.954545           22      23/22     22/21 admitted_beyond_seed
        B6_no_slot_cap_control    22/23 0.956522           23      24/23     23/22 admitted_beyond_seed
        B6_no_slot_cap_control    23/24 0.958333           24      25/24     24/23 admitted_beyond_seed
        B6_no_slot_cap_control    24/25 0.960000           25      26/25     25/24 admitted_beyond_seed
        B6_no_slot_cap_control    25/26 0.961538           26      27/26     26/25 admitted_beyond_seed
        B6_no_slot_cap_control    26/27 0.962963           27      28/27     27/26 admitted_beyond_seed
        B6_no_slot_cap_control    27/28 0.964286           28      29/28     28/27 admitted_beyond_seed
        B6_no_slot_cap_control    28/29 0.965517           29      30/29     29/28 admitted_beyond_seed
        B6_no_slot_cap_control    29/30 0.966667           30      31/30     30/29 admitted_beyond_seed
        B6_no_slot_cap_control    30/31 0.967742           31      32/31     31/30 admitted_beyond_seed
        B6_no_slot_cap_control    31/32 0.968750           32      33/32     32/31 admitted_beyond_seed
        B6_no_slot_cap_control    33/32 1.031250           32      31/32     32/33 admitted_beyond_seed
        B6_no_slot_cap_control    32/31 1.032258           31      30/31     31/32 admitted_beyond_seed
        B6_no_slot_cap_control    31/30 1.033333           30      29/30     30/31 admitted_beyond_seed
        B6_no_slot_cap_control    30/29 1.034483           29      28/29     29/30 admitted_beyond_seed
        B6_no_slot_cap_control    29/28 1.035714           28      27/28     28/29 admitted_beyond_seed
        B6_no_slot_cap_control    28/27 1.037037           27      26/27     27/28 admitted_beyond_seed
        B6_no_slot_cap_control    27/26 1.038462           26      25/26     26/27 admitted_beyond_seed
        B6_no_slot_cap_control    26/25 1.040000           25      24/25     25/26 admitted_beyond_seed
        B6_no_slot_cap_control    25/24 1.041667           24      23/24     24/25 admitted_beyond_seed
        B6_no_slot_cap_control    24/23 1.043478           23      22/23     23/24 admitted_beyond_seed
        B6_no_slot_cap_control    23/22 1.045455           22      21/22     22/23 admitted_beyond_seed
        B6_no_slot_cap_control    22/21 1.047619           21      20/21     21/22 admitted_beyond_seed
        B6_no_slot_cap_control    21/20 1.050000           20      19/20     20/21 admitted_beyond_seed
        B6_no_slot_cap_control    20/19 1.052632           19      18/19     19/20 admitted_beyond_seed
        B6_no_slot_cap_control    19/18 1.055556           18      17/18     18/19 admitted_beyond_seed
        B6_no_slot_cap_control    18/17 1.058824           17      16/17     17/18 admitted_beyond_seed
        B6_no_slot_cap_control    17/16 1.062500           16      15/16     16/17 admitted_beyond_seed
        B6_no_slot_cap_control    33/31 1.064516           31      29/31     31/33 admitted_beyond_seed
        B6_no_slot_cap_control    16/15 1.066667           15      14/15     15/16 admitted_beyond_seed
        B6_no_slot_cap_control    31/29 1.068966           29      27/29     29/31 admitted_beyond_seed
        B6_no_slot_cap_control    15/14 1.071429           14      13/14     14/15 admitted_beyond_seed
        B6_no_slot_cap_control    29/27 1.074074           27      25/27     27/29 admitted_beyond_seed
        B6_no_slot_cap_control    14/13 1.076923           13      12/13     13/14 admitted_beyond_seed
        B6_no_slot_cap_control    27/25 1.080000           25      23/25     25/27 admitted_beyond_seed
        B6_no_slot_cap_control    13/12 1.083333           12      11/12     12/13 admitted_beyond_seed
        B6_no_slot_cap_control    25/23 1.086957           23      21/23     23/25 admitted_beyond_seed
        B6_no_slot_cap_control    12/11 1.090909           11      10/11     11/12 admitted_beyond_seed
        B6_no_slot_cap_control    23/21 1.095238           21      19/21     21/23 admitted_beyond_seed
        B6_no_slot_cap_control    11/10 1.100000           10       9/10     10/11 admitted_beyond_seed
        B6_no_slot_cap_control    21/19 1.105263           19      17/19     19/21 admitted_beyond_seed
        B6_no_slot_cap_control     10/9 1.111111            9        8/9      9/10 admitted_beyond_seed
        B6_no_slot_cap_control    19/17 1.117647           17      15/17     17/19 admitted_beyond_seed
        B6_no_slot_cap_control      9/8 1.125000            8        7/8       8/9 admitted_beyond_seed
        B6_no_slot_cap_control    17/15 1.133333           15      13/15     15/17 admitted_beyond_seed
        B6_no_slot_cap_control      8/7 1.142857            7        6/7       7/8 admitted_beyond_seed
        B6_no_slot_cap_control    15/13 1.153846           13      11/13     13/15 admitted_beyond_seed
        B6_no_slot_cap_control      7/6 1.166667            6        5/6       6/7 admitted_beyond_seed
        B6_no_slot_cap_control    13/11 1.181818           11       9/11     11/13 admitted_beyond_seed
        B6_no_slot_cap_control      6/5 1.200000            5        4/5       5/6 admitted_beyond_seed
        B6_no_slot_cap_control     11/9 1.222222            9        7/9      9/11 admitted_beyond_seed
        B6_no_slot_cap_control      9/7 1.285714            7        5/7       7/9 admitted_beyond_seed
        B6_no_slot_cap_control      7/5 1.400000            5        3/5       5/7 admitted_beyond_seed

## Recommended next

BOXED: FORCE_R110 — Normal-Bundle Dimension / Slot-Capacity Derivation Gate
