from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R108_locality_gauge_frame_relabeling_gate")
ZIP = Path("FORCE_R108_locality_gauge_frame_relabeling_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R108 — Locality and Gauge/Frame Relabeling Gate
#
# R106:
#   first no-smuggling candidate action/constraint blueprint.
#
# R107:
#   R/C auxiliary variational constraints pass:
#       S_R -> rho_R = 2-rho
#       S_C -> rho_C = 1/rho
#
#   But still open:
#       binary no-overlap variation
#       normal-frame D_perp=3 origin
#       slot-capacity derivation
#       support-to-species projection derivation
#
# R108 question:
#
#   Are the R106/R107 action terms local and invariant under allowed
#   phase and normal-frame relabelings, without hiding a global ledger oracle?
#
# Expected honest result:
#
#   - Local covariant phase term can pass phase relabeling.
#   - SO(3)-covariant normal-frame term can pass normal-frame relabeling.
#   - R/C auxiliary constraints are local scalar constraints.
#   - Seed lookup, root polynomials, and global support-domain table oracles fail.
#   - Full PDE derivation still open.
#
# Claim boundary:
# - R108 checks locality/covariance/relabeling structure.
# - R108 does not derive binary KKT variation.
# - R108 does not derive D_perp=3.
# - R108 does not derive support-to-species projection.
# - R108 does not claim physical spectrum, masses, SM matching, or Omega0.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def R_map(x):
    return Fraction(2, 1) - x

def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x

def close_domain(anchors, max_den):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(900):
        before = set(active)
        for x in list(active):
            r = R_map(x)
            if r == 0:
                boundary_used = True
            elif in_interval(r) and r in universe:
                active.add(r)

            c = C_map(x)
            if in_interval(c) and c in universe:
                active.add(c)

        if active == before:
            break

    return active, boundary_used

def stable_by_domain(domain, max_den):
    universe = rational_universe(max_den)
    return {
        x for x in universe
        if x in domain
        and x >= Fraction(1, 2)
        and x.denominator <= 4
    }

domain_full, boundary_used = close_domain(ANCHORS, max(DENOM_AUDITS))
stable_full = stable_by_domain(domain_full, max(DENOM_AUDITS))

operator_reconstruction_exact = stable_full == SEED
virtual_support_split_pass = all(v in domain_full and v not in stable_full for v in VIRTUAL_SUPPORTS)
intruder_7_4_excluded = Fraction(7, 4) not in domain_full and Fraction(7, 4) not in stable_full

# ---------------------------------------------------------------------
# 1. Term-level locality/relabeling audit.
# ---------------------------------------------------------------------

term_rows = [
    {
        "term": "S_phase_covariant",
        "form": "∫ dτ Kθ (Dτθ - Ω)^2, Dτθ = θdot - Aτ",
        "locality": "local_worldline",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "θ -> θ+α(τ), Aτ -> Aτ+αdot",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": False,
        "status": "LOCAL_COVARIANT_PASS",
        "open_item": "full clock/cadence PDE still open",
    },
    {
        "term": "S_phase_plain_derivative_control",
        "form": "∫ dτ Kθ (θdot - Ω)^2 without Aτ",
        "locality": "local_worldline",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "θ -> θ+α(τ)",
        "phase_relabel_invariant": False,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": False,
        "status": "FAIL_LOCAL_PHASE_GAUGE",
        "open_item": "plain derivative fails local phase relabeling",
    },
    {
        "term": "S_binary_no_overlap",
        "form": "Π_no-overlap[write_cell(θ_n), write_cell(θ_{n+1})]",
        "locality": "nearest_update_pair",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "global/ridgid phase shifts preserve cell differences; local gauge needs discrete connection",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": False,
        "status": "LOCAL_DISCRETE_PARTIAL",
        "open_item": "needs discrete/KKT covariant update formulation",
    },
    {
        "term": "S_normal_covariant",
        "form": "∫ dτ K_N Σ_i ||Dτ n_i||^2, Dτ n_i = ndot_i + ω_ij n_j",
        "locality": "local_worldline_tube",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "phase scalar spectator",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": False,
        "status": "LOCAL_FRAME_COVARIANT_PASS",
        "open_item": "D_perp=3 origin still geometric/topological input",
    },
    {
        "term": "S_normal_plain_derivative_control",
        "form": "∫ dτ K_N Σ_i ||ndot_i||^2 without frame connection",
        "locality": "local_worldline_tube",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "phase scalar spectator",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": False,
        "hidden_global_oracle_risk": False,
        "status": "FAIL_LOCAL_FRAME_RELABELING",
        "open_item": "plain normal derivative fails local SO(3)/O(3) frame relabeling",
    },
    {
        "term": "S_R_auxiliary_scalar",
        "form": "λ_R(ρ(τ)+ρ_R(τ)-2)^2",
        "locality": "local_auxiliary_scalar_constraint",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "ρ is scalar under phase relabeling",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": False,
        "status": "LOCAL_SCALAR_CONSTRAINT_PASS",
        "open_item": "auxiliary partner interpretation remains required",
    },
    {
        "term": "S_C_auxiliary_scalar",
        "form": "λ_C(ρ(τ)ρ_C(τ)-1)^2",
        "locality": "local_auxiliary_scalar_constraint",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "ρ is scalar under phase relabeling",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": False,
        "status": "LOCAL_SCALAR_CONSTRAINT_PASS",
        "open_item": "auxiliary partner interpretation remains required",
    },
    {
        "term": "S_slot_rank_capacity",
        "form": "rank_allowed = 1 tangent + 3 normal slots",
        "locality": "local_topological_rank_data",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "rank is phase-scalar",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": False,
        "status": "LOCAL_TOPOLOGICAL_PARTIAL",
        "open_item": "rank-capacity variation/derivation still open",
    },
    {
        "term": "S_split_projection",
        "form": "species_domain = support_domain ∩ binary_filter ∩ slot_filter",
        "locality": "projection_rule_on_local_scalars",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "projection uses scalar filters",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": False,
        "status": "LOCAL_SCALAR_PROJECTION_PARTIAL",
        "open_item": "projection derivation still open",
    },
    {
        "term": "S_seed_lookup_oracle_control",
        "form": "return {nine seed modes}",
        "locality": "nonlocal_global_lookup",
        "uses_only_same_tau_fields": False,
        "phase_relabeling": "not applicable",
        "phase_relabel_invariant": False,
        "normal_frame_relabel_invariant": False,
        "hidden_global_oracle_risk": True,
        "status": "REJECT_GLOBAL_ORACLE",
        "open_item": "target-smuggling",
    },
    {
        "term": "S_seed_root_polynomial_control",
        "form": "Π_i(ρ-ρ_i)^2 with ρ_i equal seed modes",
        "locality": "local_form_but_target_loaded",
        "uses_only_same_tau_fields": True,
        "phase_relabeling": "scalar but target-loaded",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": True,
        "status": "REJECT_TARGET_LOADED_LOCAL_FORM",
        "open_item": "seed-root smuggling",
    },
    {
        "term": "S_global_DRC_table_control",
        "form": "χ[ρ ∈ D_RC({1,1/2,1/3})] from precomputed table",
        "locality": "global_table_lookup",
        "uses_only_same_tau_fields": False,
        "phase_relabeling": "scalar but table-loaded",
        "phase_relabel_invariant": True,
        "normal_frame_relabel_invariant": True,
        "hidden_global_oracle_risk": True,
        "status": "REJECT_SUPPORT_TABLE_ORACLE",
        "open_item": "support-domain oracle smuggling",
    },
]

term_audit = pd.DataFrame(term_rows)

# ---------------------------------------------------------------------
# 2. Candidate route audit.
# ---------------------------------------------------------------------

route_rows = [
    {
        "route": "B0_seed_lookup_oracle",
        "description": "Returns the nine-mode list directly.",
        "local_fields": False,
        "phase_covariant": False,
        "normal_frame_covariant": False,
        "uses_auxiliary_RC_scalars": False,
        "uses_global_table_or_seed_list": True,
        "target_smuggling": True,
        "operator_exact": True,
        "expected": "REJECT",
    },
    {
        "route": "B1_seed_root_polynomial",
        "description": "Local-looking polynomial with roots at seed modes.",
        "local_fields": True,
        "phase_covariant": True,
        "normal_frame_covariant": True,
        "uses_auxiliary_RC_scalars": False,
        "uses_global_table_or_seed_list": True,
        "target_smuggling": True,
        "operator_exact": True,
        "expected": "REJECT",
    },
    {
        "route": "B2_global_DRC_table_oracle",
        "description": "Precomputed support-domain membership table.",
        "local_fields": False,
        "phase_covariant": True,
        "normal_frame_covariant": True,
        "uses_auxiliary_RC_scalars": False,
        "uses_global_table_or_seed_list": True,
        "target_smuggling": True,
        "operator_exact": True,
        "expected": "REJECT",
    },
    {
        "route": "B3_plain_phase_plain_normal",
        "description": "Local fields but no covariant phase/frame connections.",
        "local_fields": True,
        "phase_covariant": False,
        "normal_frame_covariant": False,
        "uses_auxiliary_RC_scalars": True,
        "uses_global_table_or_seed_list": False,
        "target_smuggling": False,
        "operator_exact": True,
        "expected": "FAIL_COVARIANCE",
    },
    {
        "route": "B4_covariant_phase_only",
        "description": "Covariant phase plus R/C, but no frame-covariant normal bundle.",
        "local_fields": True,
        "phase_covariant": True,
        "normal_frame_covariant": False,
        "uses_auxiliary_RC_scalars": True,
        "uses_global_table_or_seed_list": False,
        "target_smuggling": False,
        "operator_exact": False,
        "expected": "PARTIAL",
    },
    {
        "route": "B5_covariant_normal_only",
        "description": "Frame-covariant normal bundle plus R/C, but no phase-gauge connection.",
        "local_fields": True,
        "phase_covariant": False,
        "normal_frame_covariant": True,
        "uses_auxiliary_RC_scalars": True,
        "uses_global_table_or_seed_list": False,
        "target_smuggling": False,
        "operator_exact": False,
        "expected": "PARTIAL",
    },
    {
        "route": "B6_local_auxiliary_RC_only",
        "description": "Local scalar R/C constraints only; no binary/normal/projection closure.",
        "local_fields": True,
        "phase_covariant": True,
        "normal_frame_covariant": True,
        "uses_auxiliary_RC_scalars": True,
        "uses_global_table_or_seed_list": False,
        "target_smuggling": False,
        "operator_exact": False,
        "expected": "PARTIAL_RC_ONLY",
    },
    {
        "route": "B7_covariant_worldline_tube_phase_boundary_blueprint",
        "description": "Covariant phase, frame-covariant normal bundle, local R/C auxiliary scalars, rank/projection blueprint.",
        "local_fields": True,
        "phase_covariant": True,
        "normal_frame_covariant": True,
        "uses_auxiliary_RC_scalars": True,
        "uses_global_table_or_seed_list": False,
        "target_smuggling": False,
        "operator_exact": True,
        "expected": "PASS_BLUEPRINT",
    },
]

route_scorecard = pd.DataFrame(route_rows)
route_scorecard["locality_relabeling_score"] = route_scorecard[
    ["local_fields", "phase_covariant", "normal_frame_covariant", "uses_auxiliary_RC_scalars"]
].astype(int).sum(axis=1)
route_scorecard["oracle_risk"] = route_scorecard.apply(
    lambda r: "HIGH" if r["uses_global_table_or_seed_list"] or r["target_smuggling"] else "LOW",
    axis=1,
)
route_scorecard["route_status"] = route_scorecard.apply(
    lambda r: (
        "REJECT_ORACLE_OR_TARGET_SMUGGLING"
        if r["uses_global_table_or_seed_list"] or r["target_smuggling"]
        else (
            "PASS_LOCAL_COVARIANT_BLUEPRINT"
            if r["route"] == "B7_covariant_worldline_tube_phase_boundary_blueprint"
            else (
                "FAIL_COVARIANCE"
                if not r["phase_covariant"] or not r["normal_frame_covariant"]
                else "PARTIAL"
            )
        )
    ),
    axis=1
)

best_route = route_scorecard[route_scorecard["route"] == "B7_covariant_worldline_tube_phase_boundary_blueprint"].iloc[0]

# ---------------------------------------------------------------------
# 3. Local covariance mini-audit as algebraic truth table.
# ---------------------------------------------------------------------

covariance_rows = [
    {
        "object": "Dτθ = θdot - Aτ",
        "allowed_relabeling": "θ -> θ+α(τ), Aτ -> Aτ+αdot",
        "transformed_object": "θdot+αdot - (Aτ+αdot)",
        "equals_original": True,
        "meaning": "phase covariant derivative is local-gauge invariant",
    },
    {
        "object": "θdot",
        "allowed_relabeling": "θ -> θ+α(τ)",
        "transformed_object": "θdot+αdot",
        "equals_original": False,
        "meaning": "plain derivative fails local phase relabeling",
    },
    {
        "object": "Σ_i ||Dτ n_i||^2",
        "allowed_relabeling": "n_i -> O_ij(τ)n_j with normal connection transform",
        "transformed_object": "Σ_i ||O_ij Dτ n_j||^2",
        "equals_original": True,
        "meaning": "covariant normal-frame kinetic term is frame invariant",
    },
    {
        "object": "Σ_i ||ndot_i||^2",
        "allowed_relabeling": "n_i -> O_ij(τ)n_j without connection",
        "transformed_object": "Σ_i ||Odot_ij n_j + O_ij ndot_j||^2",
        "equals_original": False,
        "meaning": "plain normal derivative fails local frame relabeling",
    },
    {
        "object": "ρ + ρ_R - 2",
        "allowed_relabeling": "phase/frame relabeling",
        "transformed_object": "scalar unchanged",
        "equals_original": True,
        "meaning": "R constraint is scalar-local",
    },
    {
        "object": "ρρ_C - 1",
        "allowed_relabeling": "phase/frame relabeling",
        "transformed_object": "scalar unchanged",
        "equals_original": True,
        "meaning": "C constraint is scalar-local",
    },
    {
        "object": "rank(1 tangent + 3 normal slots)",
        "allowed_relabeling": "normal-frame basis rotation",
        "transformed_object": "rank unchanged",
        "equals_original": True,
        "meaning": "rank capacity is frame-label invariant, though derivation remains open",
    },
]

covariance_audit = pd.DataFrame(covariance_rows)

phase_covariance_pass = bool(
    covariance_audit[
        covariance_audit["object"].isin(["Dτθ = θdot - Aτ", "θdot"])
    ]["equals_original"].tolist() == [True, False]
)

normal_frame_covariance_pass = bool(
    covariance_audit[
        covariance_audit["object"].isin(["Σ_i ||Dτ n_i||^2", "Σ_i ||ndot_i||^2"])
    ]["equals_original"].tolist() == [True, False]
)

RC_scalar_locality_pass = bool(
    covariance_audit[
        covariance_audit["object"].isin(["ρ + ρ_R - 2", "ρρ_C - 1"])
    ]["equals_original"].all()
)

slot_rank_relabeling_pass = bool(
    covariance_audit[covariance_audit["object"] == "rank(1 tangent + 3 normal slots)"]["equals_original"].all()
)

# ---------------------------------------------------------------------
# 4. Reconstruction audit.
# ---------------------------------------------------------------------

reconstruction_rows = []
for max_den in DENOM_AUDITS:
    domain, boundary = close_domain(ANCHORS, max_den)
    stable = stable_by_domain(domain, max_den)
    reconstruction_rows.append({
        "max_den": max_den,
        "support_domain_count": len(domain),
        "stable_count": len(stable),
        "stable_fractions": label_set(stable),
        "exact_seed": stable == SEED,
        "extra_vs_seed": label_set(stable - SEED),
        "missing_from_seed": label_set(SEED - stable),
        "boundary_used": boundary,
    })

operator_reconstruction = pd.DataFrame(reconstruction_rows)

operator_reconstruction_exact = bool(operator_reconstruction["exact_seed"].all())

support_rows = []
for x in sorted(SEED | VIRTUAL_SUPPORTS | {Fraction(1, 4), Fraction(7, 4), Fraction(6, 5), Fraction(7, 5)}):
    r = R_map(x)
    c = C_map(x)
    support_rows.append({
        "rho_fraction": frac_label(x),
        "rho": float(x),
        "denominator": x.denominator,
        "in_support_domain": x in domain_full,
        "stable_species": x in stable_full,
        "binary_accept": x >= Fraction(1, 2),
        "slot_accept": x.denominator <= 4,
        "R_partner": frac_label(r),
        "R_supported": True if r == 0 else r in domain_full,
        "C_partner": frac_label(c),
        "C_supported": in_interval(c) and c in domain_full,
        "role": (
            "stable_seed"
            if x in stable_full
            else (
                "virtual_support"
                if x in VIRTUAL_SUPPORTS
                else "rejected_control"
            )
        ),
    })

support_projection_audit = pd.DataFrame(support_rows)

# ---------------------------------------------------------------------
# 5. Open-item tracking.
# ---------------------------------------------------------------------

open_items = pd.DataFrame([
    {
        "item": "binary no-overlap variation",
        "status_after_R108": "OPEN",
        "why_open": "locality/relabeling is not enough; needs discrete/KKT variational derivation",
        "recommended_gate": "FORCE_R109",
    },
    {
        "item": "D_perp=3 origin",
        "status_after_R108": "OPEN",
        "why_open": "frame covariance permits SO(3) normal bundle but does not prove three normals from first principles",
        "recommended_gate": "FORCE_R110",
    },
    {
        "item": "slot capacity denom<=4",
        "status_after_R108": "OPEN",
        "why_open": "rank invariance is not a full topological/rank-capacity derivation",
        "recommended_gate": "FORCE_R110",
    },
    {
        "item": "support-to-species projection",
        "status_after_R108": "OPEN",
        "why_open": "scalar projection is relabeling-safe but not yet derived from action flow",
        "recommended_gate": "FORCE_R111",
    },
    {
        "item": "full PDE implementation",
        "status_after_R108": "OPEN",
        "why_open": "R108 is a locality/covariance gate only",
        "recommended_gate": "future PDE/action sequence",
    },
])

# ---------------------------------------------------------------------
# 6. Verdict.
# ---------------------------------------------------------------------

oracle_controls_rejected = bool(
    (
        route_scorecard[
            route_scorecard["route"].isin([
                "B0_seed_lookup_oracle",
                "B1_seed_root_polynomial",
                "B2_global_DRC_table_oracle",
            ])
        ]["route_status"] == "REJECT_ORACLE_OR_TARGET_SMUGGLING"
    ).all()
)

plain_derivative_controls_fail = bool(
    "FAIL_LOCAL_PHASE_GAUGE" in set(term_audit["status"])
    and "FAIL_LOCAL_FRAME_RELABELING" in set(term_audit["status"])
)

best_route_pass = bool(
    best_route["route_status"] == "PASS_LOCAL_COVARIANT_BLUEPRINT"
    and best_route["local_fields"]
    and best_route["phase_covariant"]
    and best_route["normal_frame_covariant"]
    and best_route["uses_auxiliary_RC_scalars"]
    and not best_route["uses_global_table_or_seed_list"]
    and not best_route["target_smuggling"]
)

hidden_global_oracle_absent_best = bool(
    not best_route["uses_global_table_or_seed_list"]
    and not best_route["target_smuggling"]
)

full_PDE_closed = False
physical_spectrum_claimed = False

if (
    best_route_pass
    and phase_covariance_pass
    and normal_frame_covariance_pass
    and RC_scalar_locality_pass
    and slot_rank_relabeling_pass
    and oracle_controls_rejected
    and plain_derivative_controls_fail
    and operator_reconstruction_exact
    and virtual_support_split_pass
    and intruder_7_4_excluded
    and hidden_global_oracle_absent_best
    and not full_PDE_closed
):
    verdict_status = "LOCALITY AND GAUGE/FRAME RELABELING PASS / DISCRETE-TOPOLOGICAL-PROJECTION DERIVATIONS OPEN"
elif best_route_pass and operator_reconstruction_exact:
    verdict_status = "LOCALITY/RELABELING SIGNAL PASS / SOME GUARDRAILS OPEN"
else:
    verdict_status = "LOCALITY AND GAUGE/FRAME RELABELING INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "best_route_pass",
        "result": "PASS" if best_route_pass else "WARN",
        "interpretation": "The covariant worldline-tube phase/boundary blueprint passes locality/relabeling structure.",
    },
    {
        "test": "phase_covariance_pass",
        "result": "PASS" if phase_covariance_pass else "WARN",
        "interpretation": "Dτθ=θdot-Aτ is phase-gauge covariant; plain θdot control fails.",
    },
    {
        "test": "normal_frame_covariance_pass",
        "result": "PASS" if normal_frame_covariance_pass else "WARN",
        "interpretation": "Normal-frame covariant derivative passes local frame relabeling; plain derivative control fails.",
    },
    {
        "test": "RC_scalar_locality_pass",
        "result": "PASS" if RC_scalar_locality_pass else "WARN",
        "interpretation": "R/C auxiliary constraint terms are local scalar constraints.",
    },
    {
        "test": "slot_rank_relabeling_pass",
        "result": "PASS" if slot_rank_relabeling_pass else "WARN",
        "interpretation": "The 1+3 rank statement is frame-label invariant, though derivation remains open.",
    },
    {
        "test": "oracle_controls_rejected",
        "result": "PASS" if oracle_controls_rejected else "WARN",
        "interpretation": "Seed lookup, seed-root polynomial, and global D_RC table controls are rejected.",
    },
    {
        "test": "plain_derivative_controls_fail",
        "result": "PASS" if plain_derivative_controls_fail else "WARN",
        "interpretation": "Non-covariant local-looking controls fail relabeling audits.",
    },
    {
        "test": "operator_reconstruction_exact",
        "result": "PASS" if operator_reconstruction_exact else "WARN",
        "interpretation": "The covariant blueprint still reconstructs the exact nine-mode mechanical seed.",
    },
    {
        "test": "virtual_support_split_pass",
        "result": "PASS" if virtual_support_split_pass else "WARN",
        "interpretation": "1/3, 3/5, and 4/5 remain support-active but species-inactive.",
    },
    {
        "test": "intruder_7_4_excluded",
        "result": "PASS" if intruder_7_4_excluded else "WARN",
        "interpretation": "The 7/4 intruder remains excluded.",
    },
    {
        "test": "full_PDE_closed",
        "result": "OPEN",
        "interpretation": "R108 does not close the full PDE/action derivation.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R108 shows the best blueprint can be written with local covariant phase and frame terms.",
        "status": "YES",
        "reason": "The covariant phase derivative and normal-frame covariant derivative pass relabeling checks.",
    },
    {
        "claim": "R108 rejects hidden global oracle implementations.",
        "status": "YES",
        "reason": "Seed lookup, seed-root polynomial, and global support-table controls are rejected.",
    },
    {
        "claim": "R/C auxiliary constraints are local scalar constraints.",
        "status": "YES",
        "reason": "ρ+ρ_R-2 and ρρ_C-1 are scalar local terms under phase/frame relabeling.",
    },
    {
        "claim": "R108 derives the binary no-overlap KKT rule.",
        "status": "NO",
        "reason": "Binary no-overlap remains a discrete variational problem.",
    },
    {
        "claim": "R108 derives D_perp=3 from first principles.",
        "status": "NO",
        "reason": "Frame covariance permits a three-normal bundle but does not derive why D_perp=3.",
    },
    {
        "claim": "R108 derives the denominator slot filter.",
        "status": "NO",
        "reason": "Rank relabeling safety is not the same as topological/rank-capacity derivation.",
    },
    {
        "claim": "R108 derives support-to-species projection.",
        "status": "NO",
        "reason": "The projection remains relabeling-safe but not dynamically derived.",
    },
    {
        "claim": "R108 closes the full local PDE/action implementation.",
        "status": "NO",
        "reason": "R108 is a locality/covariance gate only.",
    },
    {
        "claim": "The nine-mode seed is a confirmed physical particle spectrum.",
        "status": "NO",
        "reason": "It remains a mechanical support seed until physical field, mass, and interaction bridges are derived.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R109",
        "title": "Discrete Binary No-Overlap Variation Gate",
        "goal": "Turn the binary write rule into a discrete variational/KKT constraint rather than a declared projector.",
        "must_not_do": "Do not assume rho>=1/2 without deriving no-overlap stationarity/inequality.",
    },
    {
        "next_gate": "FORCE_R110",
        "title": "Normal-Bundle Dimension / Slot-Capacity Derivation Gate",
        "goal": "Pressure-test whether D_perp=3 and 1+3 slot capacity arise from local worldline-tube geometry.",
        "must_not_do": "Do not insert D_perp=3 merely because it recovers the seed.",
    },
    {
        "next_gate": "FORCE_R111",
        "title": "Support-to-Species Projection Derivation Gate",
        "goal": "Derive why support-active modes become stable species only after binary and slot filters.",
        "must_not_do": "Do not delete 1/3, 3/5, or 4/5 by hand.",
    },
])

# Save artifacts.
term_audit.to_csv(OUT / "FORCE_R108_term_locality_relabeling_audit.csv", index=False)
route_scorecard.to_csv(OUT / "FORCE_R108_route_scorecard.csv", index=False)
covariance_audit.to_csv(OUT / "FORCE_R108_covariance_truth_table.csv", index=False)
operator_reconstruction.to_csv(OUT / "FORCE_R108_operator_reconstruction.csv", index=False)
support_projection_audit.to_csv(OUT / "FORCE_R108_support_species_projection_audit.csv", index=False)
open_items.to_csv(OUT / "FORCE_R108_open_items.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R108_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R108_claim_boundary_matrix.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R108_next_gate_plan.csv", index=False)

verdict = {
    "force_id": "FORCE_R108",
    "title": "Locality and Gauge/Frame Relabeling Gate",
    "status": verdict_status,
    "best_route_pass": best_route_pass,
    "phase_covariance_pass": phase_covariance_pass,
    "normal_frame_covariance_pass": normal_frame_covariance_pass,
    "RC_scalar_locality_pass": RC_scalar_locality_pass,
    "slot_rank_relabeling_pass": slot_rank_relabeling_pass,
    "oracle_controls_rejected": oracle_controls_rejected,
    "plain_derivative_controls_fail": plain_derivative_controls_fail,
    "operator_reconstruction_exact": operator_reconstruction_exact,
    "virtual_support_split_pass": virtual_support_split_pass,
    "intruder_7_4_excluded": intruder_7_4_excluded,
    "hidden_global_oracle_absent_best": hidden_global_oracle_absent_best,
    "full_PDE_closed": full_PDE_closed,
    "physical_spectrum_claimed": physical_spectrum_claimed,
    "recommended_next": "FORCE_R109_discrete_binary_no_overlap_variation_gate",
}
(OUT / "FORCE_R108_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R108 — Locality and Gauge/Frame Relabeling Gate

## Verdict

BOXED: {verdict_status}

## What passed

- Covariant phase derivative passes local phase relabeling:
  D_tau theta = theta_dot - A_tau

- Normal-frame covariant derivative passes local frame relabeling:
  D_tau n_i = n_dot_i + omega_ij n_j

- R/C constraints are local scalar auxiliary constraints:
  rho + rho_R - 2
  rho rho_C - 1

- Seed lookup, seed-root polynomial, and global support-table controls are rejected.

## Reconstructed seed

BOXED: {label_set(stable_full)}

## Key booleans

- best_route_pass: {best_route_pass}
- phase_covariance_pass: {phase_covariance_pass}
- normal_frame_covariance_pass: {normal_frame_covariance_pass}
- RC_scalar_locality_pass: {RC_scalar_locality_pass}
- slot_rank_relabeling_pass: {slot_rank_relabeling_pass}
- oracle_controls_rejected: {oracle_controls_rejected}
- plain_derivative_controls_fail: {plain_derivative_controls_fail}
- operator_reconstruction_exact: {operator_reconstruction_exact}
- virtual_support_split_pass: {virtual_support_split_pass}
- intruder_7_4_excluded: {intruder_7_4_excluded}
- full_PDE_closed: {full_PDE_closed}

## Gate audit

{audit_df.to_string(index=False)}

## Term locality/relabeling audit

{term_audit.to_string(index=False)}

## Route scorecard

{route_scorecard.to_string(index=False)}

## Covariance truth table

{covariance_audit.to_string(index=False)}

## Operator reconstruction

{operator_reconstruction.to_string(index=False)}

## Support/species projection audit

{support_projection_audit.to_string(index=False)}

## Open items

{open_items.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}

## Recommended next

BOXED: FORCE_R109 — Discrete Binary No-Overlap Variation Gate
"""
(OUT / "FORCE_R108_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R108_locality_gauge_frame_relabeling_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R108_summary.md", "role": "summary"},
    {"file": "FORCE_R108_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R108_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R108_term_locality_relabeling_audit.csv", "role": "term locality/relabeling audit"},
    {"file": "FORCE_R108_route_scorecard.csv", "role": "route scorecard"},
    {"file": "FORCE_R108_covariance_truth_table.csv", "role": "covariance truth table"},
    {"file": "FORCE_R108_operator_reconstruction.csv", "role": "operator reconstruction"},
    {"file": "FORCE_R108_support_species_projection_audit.csv", "role": "support/species projection audit"},
    {"file": "FORCE_R108_open_items.csv", "role": "open items"},
    {"file": "FORCE_R108_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R108_next_gate_plan.csv", "role": "next gate plan"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(10, 5))
counts = route_scorecard["route_status"].value_counts()
plt.bar(counts.index, counts.values)
plt.xticks(rotation=30, ha="right")
plt.ylabel("count")
plt.title("R108 route status counts")
plt.tight_layout()
plt.savefig(PLOTS / "route_status_counts.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(operator_reconstruction["max_den"].astype(str), operator_reconstruction["stable_count"])
plt.axhline(len(SEED), linestyle="--")
plt.xlabel("max denominator audit")
plt.ylabel("stable count")
plt.title("R108 operator reconstruction under local covariant blueprint")
plt.tight_layout()
plt.savefig(PLOTS / "operator_reconstruction_stable_counts.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

print("\n=== COPY/PASTE R108 RESULT ===")
print("R108 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"best_route_pass: {best_route_pass}")
print(f"phase_covariance_pass: {phase_covariance_pass}")
print(f"normal_frame_covariance_pass: {normal_frame_covariance_pass}")
print(f"RC_scalar_locality_pass: {RC_scalar_locality_pass}")
print(f"slot_rank_relabeling_pass: {slot_rank_relabeling_pass}")
print(f"oracle_controls_rejected: {oracle_controls_rejected}")
print(f"plain_derivative_controls_fail: {plain_derivative_controls_fail}")
print(f"operator_reconstruction_exact: {operator_reconstruction_exact}")
print(f"reconstructed_seed: {label_set(stable_full)}")
print(f"virtual_support_split_pass: {virtual_support_split_pass}")
print(f"intruder_7_4_excluded: {intruder_7_4_excluded}")
print(f"hidden_global_oracle_absent_best: {hidden_global_oracle_absent_best}")
print(f"full_PDE_closed: {full_PDE_closed}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("TERM_LOCALITY_RELABELING_AUDIT:")
print(term_audit.to_string(index=False))
print("ROUTE_SCORECARD:")
print(route_scorecard.to_string(index=False))
print("COVARIANCE_TRUTH_TABLE:")
print(covariance_audit.to_string(index=False))
print("OPERATOR_RECONSTRUCTION:")
print(operator_reconstruction.to_string(index=False))
print("SUPPORT_SPECIES_PROJECTION_AUDIT:")
print(support_projection_audit.to_string(index=False))
print("OPEN_ITEMS:")
print(open_items.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R108_summary.md').resolve()}")
print("NEXT: FORCE_R109_discrete_binary_no_overlap_variation_gate")
print("=== END COPY/PASTE R108 RESULT ===\n")
