# FORCE_R113 Proof Sketch

1. Primitive support anchors are fixed as A={1,1/2,1/3}. The anchor 1 is the identity/base cadence support; 1/2 is the binary no-overwrite support; 1/3 is the tri-normal virtual support anchor.

2. The support closure maps are R(rho)=2-rho and C(rho)=1/rho. These maps generate the joint R/C support domain D_RC(A).

3. Support compatibility alone is not species stability. A support-active mode must also satisfy binary write admissibility and slot-capacity admissibility.

4. Binary no-overlap gives rho>=1/2 as a discrete KKT condition conditional on binary write-cell width w=1/2.

5. A 1D worldline in inherited 3+1 spacetime has D_perp=3 normal directions, giving total slot capacity N_slot=1+D_perp=4. Therefore stable species require denom(rho)<=4.

6. Applying Species = Support ∩ Binary ∩ Slot selects exactly {1/2,2/3,3/4,1,5/4,4/3,3/2,5/3,2}.

7. The virtual support channels 1/3, 3/5, and 4/5 are not manually deleted. The mode 1/3 fails binary no-overlap; 3/5 and 4/5 fail slot capacity. They remain support-active but species-inactive.

8. The proof is operator-geometric. A full dynamical PDE derivation remains future work.
