# V12.8 Canonical Operator-Geometric Formula

## Primitive anchors

A = {1, 1/2, 1/3}

## Closure maps

R(rho)=2-rho

C(rho)=1/rho

## Support domain

rho ∈ D_RC(A)

## Binary admissibility

rho >= 1/2

## Slot admissibility

denom(rho) <= 4

## Species projection

Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}

## Selected seed

{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}
