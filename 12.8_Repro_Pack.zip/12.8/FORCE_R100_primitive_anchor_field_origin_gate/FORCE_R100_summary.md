# FORCE_R100 — Primitive Anchor Field-Origin Gate

## Verdict

BOXED: PRIMITIVE ANCHOR ORIGIN CANDIDATE PASS / FIELD-ACTION DERIVATION STILL OPEN

## Central result

R100 tests whether the V12.7 primitive anchor set

BOXED: {1, 1/2, 1/3}

has an operator-level origin as:

- 1 = identity/base cadence;
- 1/2 = binary no-overwrite cell;
- 1/3 = tri-normal virtual support anchor.

## Candidate anchor set

BOXED: candidate survives = True

BOXED: unique minimal exact tested anchor set = True

## Key audits

                             test result                                                                                                                interpretation
    candidate_anchor_set_survives   PASS                            {1,1/2,1/3} generates the exact V12.7 seed under joint R/C domain membership plus R95/R96 filters.
        minimal_exact_unique_v127   PASS                                Among tested primitive anchor subsets, {1,1/2,1/3} is the unique minimal exact seed generator.
identity_unique_joint_fixed_point   PASS                                                 rho=1 is the unique tested point fixed by both R(rho)=2-rho and C(rho)=1/rho.
                 binary_K2_unique   PASS K=2 is the unique tested binary-anchor choice that preserves the exact seed when paired with identity and tri-normal support.
              trinormal_D3_unique   PASS D_perp=3 is the unique tested normal-share choice that preserves the exact seed when paired with identity and binary support.
              omit_identity_fails   PASS                                                                   Without identity/base cadence, the rho=1 seed mode is lost.
                omit_binary_fails   PASS                                                   Without the binary no-overwrite anchor, the binary branch is not recovered.
             omit_trinormal_fails   PASS                                                     Without the tri-normal virtual support anchor, the 5/3 seed mode is lost.
     fournormal_replacement_fails   PASS                                                                              Replacing 1/3 with 1/4 loses 5/3 and admits 7/4.
  quarter_anchor_expands_intruder   PASS                                                                    Adding 1/4 over-expands the support domain and admits 7/4.
             selectivity_controls   PASS                                                                    All-rational support and no support filter both admit 7/4.
          field_action_derivation   OPEN                                                   R100 is still operator-origin evidence, not a full field/action derivation.

## Scorecard

                                    model                                                        origin_story       anchor_set  support_domain_count_final  stable_count_final                       stable_fractions_final  posthoc_hits  precision_posthoc  recall_posthoc  exact_seed_all_denominators  growth_blocked  boundary_used_final                      expected                 survivor_status  audit_score
             A7_identity_binary_trinormal candidate: identity + binary no-overwrite + three normal directions      1/3, 1/2, 1                          94                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2             5           0.555556             1.0                         True            True                 True               PASS_EXACT_SEED                 PASS_EXACT_SEED         16.0
            A8_identity_binary_fournormal                control: replace tri-normal 1/3 with four-normal 1/4      1/4, 1/2, 1                          84                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 7/4, 2             5           0.555556             1.0                        False            True                 True FAIL_INTRUDER_AND_MISSING_5_3 PASS_CONTROL_FAILED_AS_EXPECTED          2.0
                  A4_identity_plus_binary                            identity + binary, no tri-normal support           1/2, 1                          64                   8           1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2             5           0.625000             1.0                        False           False                 True              FAIL_MISSING_5_3 PASS_CONTROL_FAILED_AS_EXPECTED          1.5
A9_identity_binary_trinormal_plus_quarter                                  control: add 1/4 underwrite anchor 1/4, 1/3, 1/2, 1                         114                  10 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2             5           0.500000             1.0                        False           False                 True             FAIL_INTRUDER_7_4 PASS_CONTROL_FAILED_AS_EXPECTED          1.5
                A10_all_rationals_support                           control: all rationals allowed as support    all_rationals                         648                  10 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2             5           0.500000             1.0                        False           False                 True             FAIL_INTRUDER_7_4 PASS_CONTROL_FAILED_AS_EXPECTED          0.5
                    A11_no_support_filter                               control: remove support-domain filter      1/3, 1/2, 1                          94                  10 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2             5           0.500000             1.0                        False           False                 True             FAIL_INTRUDER_7_4 PASS_CONTROL_FAILED_AS_EXPECTED          0.5
                 A6_binary_plus_trinormal                             binary + tri-normal, no identity anchor         1/3, 1/2                          93                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2             4           0.500000             0.8                        False           False                 True         FAIL_MISSING_IDENTITY PASS_CONTROL_FAILED_AS_EXPECTED         -0.5
                           A2_binary_only                                       binary no-overwrite cell only              1/2                          63                   7              1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2             4           0.571429             0.8                        False           False                 True              FAIL_SIGNAL_LOST PASS_CONTROL_FAILED_AS_EXPECTED         -1.0
               A5_identity_plus_trinormal                             identity + tri-normal, no binary anchor           1/3, 1                          31                   2                                       1, 5/3             1           0.500000             0.2                        False           False                False    FAIL_MISSING_BINARY_BRANCH PASS_CONTROL_FAILED_AS_EXPECTED         -3.5
                         A1_identity_only                                          identity/base cadence only                1                           1                   1                                            1             1           1.000000             0.2                        False           False                False              FAIL_SIGNAL_LOST PASS_CONTROL_FAILED_AS_EXPECTED         -4.0
                        A3_trinormal_only                                     tri-normal virtual support only              1/3                          30                   1                                          5/3             0           0.000000             0.0                        False           False                False              FAIL_SIGNAL_LOST PASS_CONTROL_FAILED_AS_EXPECTED         -4.0
                            A0_no_anchors                                                   nothing primitive             none                           0                   0                                         none             0           0.000000             0.0                        False           False                False              FAIL_SIGNAL_LOST PASS_CONTROL_FAILED_AS_EXPECTED         -4.5

## Minimal anchor subset scan

           anchor_set  anchor_count  support_domain_count_final  stable_count_final                       stable_fractions_final  exact_seed_all_denominators extra_vs_seed                       missing_from_seed  is_v127_anchor_set
          1/3, 1/2, 1             3                          94                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True          none                                    none                True
     1/5, 1/3, 1/2, 1             4                         108                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True          none                                    none               False
                 none             0                           0                   0                                         none                        False          none 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2               False
                    1             1                           1                   1                                            1                        False          none    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False
                  1/2             1                          63                   7              1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2                        False          none                                  1, 5/3               False
                  1/3             1                          30                   1                                          5/3                        False          none      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2               False
                  1/4             1                          20                   1                                          7/4                        False           7/4 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2               False
                  1/5             1                          14                   0                                         none                        False          none 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2               False
               1/2, 1             2                          64                   8           1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False          none                                     5/3               False
               1/3, 1             2                          31                   2                                       1, 5/3                        False          none         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False
             1/3, 1/2             2                          93                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2                        False          none                                       1               False
               1/4, 1             2                          21                   2                                       1, 7/4                        False           7/4    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False
             1/4, 1/2             2                          83                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4                                  1, 5/3               False
             1/4, 1/3             2                          50                   2                                     5/3, 7/4                        False           7/4      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2               False
               1/5, 1             2                          15                   1                                            1                        False          none    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False
             1/5, 1/2             2                          77                   7              1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2                        False          none                                  1, 5/3               False
             1/5, 1/3             2                          44                   1                                          5/3                        False          none      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2               False
             1/5, 1/4             2                          34                   1                                          7/4                        False           7/4 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2               False
          1/4, 1/2, 1             3                          84                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4                                     5/3               False
          1/4, 1/3, 1             3                          51                   3                                  1, 5/3, 7/4                        False           7/4         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False
        1/4, 1/3, 1/2             3                         113                   9    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False           7/4                                       1               False
          1/5, 1/2, 1             3                          78                   8           1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False          none                                     5/3               False
          1/5, 1/3, 1             3                          45                   2                                       1, 5/3                        False          none         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False
        1/5, 1/3, 1/2             3                         107                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2                        False          none                                       1               False
          1/5, 1/4, 1             3                          35                   2                                       1, 7/4                        False           7/4    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False
        1/5, 1/4, 1/2             3                          97                   8         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4                                  1, 5/3               False
        1/5, 1/4, 1/3             3                          64                   2                                     5/3, 7/4                        False           7/4      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2               False
     1/4, 1/3, 1/2, 1             4                         114                  10 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False           7/4                                    none               False
     1/5, 1/4, 1/2, 1             4                          98                   9      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4                                     5/3               False
     1/5, 1/4, 1/3, 1             4                          65                   3                                  1, 5/3, 7/4                        False           7/4         1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False
   1/5, 1/4, 1/3, 1/2             4                         127                   9    1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False           7/4                                       1               False
1/5, 1/4, 1/3, 1/2, 1             5                         128                  10 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False           7/4                                    none               False

## Tri-normal dimension scan

 D_perp normal_share_anchor  anchor_set  stable_count_final                  stable_fractions_final  exact_seed_all_denominators extra_vs_seed missing_from_seed
      1                   1      1/2, 1                   8      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False          none               5/3
      2                 1/2      1/2, 1                   8      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False          none               5/3
      3                 1/3 1/3, 1/2, 1                   9 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True          none              none
      4                 1/4 1/4, 1/2, 1                   9 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 7/4, 2                        False           7/4               5/3
      5                 1/5 1/5, 1/2, 1                   8      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False          none               5/3
      6                 1/6 1/6, 1/2, 1                   8      1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 2                        False          none               5/3

## Binary K scan

 K binary_candidate_anchor  anchor_set  stable_count_final                  stable_fractions_final  exact_seed_all_denominators extra_vs_seed               missing_from_seed
 1                       1      1/3, 1                   2                                  1, 5/3                        False          none 1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2
 2                     1/2 1/3, 1/2, 1                   9 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True          none                            none
 3                     1/3      1/3, 1                   2                                  1, 5/3                        False          none 1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2
 4                     1/4 1/4, 1/3, 1                   3                             1, 5/3, 7/4                        False           7/4 1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2
 5                     1/5 1/5, 1/3, 1                   2                                  1, 5/3                        False          none 1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2
 6                     1/6 1/6, 1/3, 1                   2                                  1, 5/3                        False          none 1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2

## Claim boundary

                                                              claim status                                                                                        reason
      {1,1/2,1/3} has an operator-level primitive-origin candidate.    YES It is the unique minimal tested anchor set that generates the exact seed under V12.7 filters.
               1 is identified as the identity/base cadence anchor.    YES                It is the unique tested joint fixed point of R and C and omission loses rho=1.
               1/2 is identified as the binary no-overwrite anchor.    YES               K=2 is uniquely exact in the tested K-scan, matching the R94/R95 binary result.
        1/3 is identified as the tri-normal virtual support anchor.    YES               D_perp=3 is uniquely exact in the tested normal-share scan; omission loses 5/3.
                                           1/3 is a stable species.     NO                                       It fails rho>=1/2 and remains a virtual support anchor.
The primitive anchors are fully derived from local field equations.     NO                                          R100 does not provide a PDE/action field derivation.
                                                 This closes V12.8.     NO                         R100 begins V12.8; closure-map and field/action origins remain ahead.

## Theorem candidate

 layer                      anchor                             candidate_origin                                                       operator_evidence         status
     1                           1                        identity/base cadence        unique tested joint fixed point of R and C; omission loses rho=1 CANDIDATE_PASS
     2                         1/2       binary no-overwrite compact-phase cell K=2 unique tested exact K-anchor; inherited R94/R95 binary update stack CANDIDATE_PASS
     3                         1/3           three-normal virtual support share    D_perp=3 unique tested exact normal-share anchor; omission loses 5/3 CANDIDATE_PASS
     4                 {1,1/2,1/3} identity + binary write + tri-normal support                              unique minimal tested exact seed generator CANDIDATE_PASS
     5 field/action implementation                  local PDE/action derivation                                                    not supplied by R100           OPEN

## Intruder / missing seed audit

                                    model fraction      rho  denominator  R_partner C_partner               reason
                            A0_no_anchors      1/2 0.500000            2        3/2         2   seed_mode_rejected
                            A0_no_anchors      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                            A0_no_anchors      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                            A0_no_anchors        1 1.000000            1          1         1   seed_mode_rejected
                            A0_no_anchors      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                            A0_no_anchors      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                            A0_no_anchors      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
                            A0_no_anchors      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
                            A0_no_anchors        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
                         A1_identity_only      1/2 0.500000            2        3/2         2   seed_mode_rejected
                         A1_identity_only      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                         A1_identity_only      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                         A1_identity_only      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                         A1_identity_only      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                         A1_identity_only      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
                         A1_identity_only      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
                         A1_identity_only        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
                           A2_binary_only        1 1.000000            1          1         1   seed_mode_rejected
                           A2_binary_only      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
                        A3_trinormal_only      1/2 0.500000            2        3/2         2   seed_mode_rejected
                        A3_trinormal_only      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                        A3_trinormal_only      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                        A3_trinormal_only        1 1.000000            1          1         1   seed_mode_rejected
                        A3_trinormal_only      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                        A3_trinormal_only      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                        A3_trinormal_only      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
                        A3_trinormal_only        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
                  A4_identity_plus_binary      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
               A5_identity_plus_trinormal      1/2 0.500000            2        3/2         2   seed_mode_rejected
               A5_identity_plus_trinormal      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
               A5_identity_plus_trinormal      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
               A5_identity_plus_trinormal      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
               A5_identity_plus_trinormal      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
               A5_identity_plus_trinormal      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
               A5_identity_plus_trinormal        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
                 A6_binary_plus_trinormal        1 1.000000            1          1         1   seed_mode_rejected
            A8_identity_binary_fournormal      7/4 1.750000            4        1/4       4/7 admitted_beyond_seed
            A8_identity_binary_fournormal      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
A9_identity_binary_trinormal_plus_quarter      7/4 1.750000            4        1/4       4/7 admitted_beyond_seed
                A10_all_rationals_support      7/4 1.750000            4        1/4       4/7 admitted_beyond_seed
                    A11_no_support_filter      7/4 1.750000            4        1/4       4/7 admitted_beyond_seed

## Remaining open item

R100 gives an operator-origin candidate for the primitive anchors. It does not derive the full field/action implementation.

## Recommended next

BOXED: FORCE_R101 — Tri-Normal Virtual Support Anchor Gate
