from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import hashlib
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
OUT = Path("FORCE_R114_V12_8_appendix_packaging_freeze_gate")
ZIP = Path("SFT_V12_8_operator_geometry_freeze_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

SNAP = OUT / "source_snapshots"
SNAP.mkdir()

PLOTS = OUT / "plots"
PLOTS.mkdir()

FREEZE_ID = "SFT_V12_8_OPERATOR_GEOMETRY_FREEZE"
FREEZE_TITLE = "Solvency Field Theory V12.8: Operator-Geometric Support-to-Species Seed Closure"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
]

VIRTUAL_SUPPORTS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

def frac_label(x):
    return str(x) if isinstance(x, Fraction) else str(x)

def label_list(xs):
    return ", ".join(frac_label(x) for x in xs)

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

canonical_formula = (
    "Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}"
)

selected_seed = "{" + label_list(SEED) + "}"

# ---------------------------------------------------------------------
# 1. Expected V12.8 theorem-stack ledger.
# ---------------------------------------------------------------------

expected_gates = [
    {
        "gate": "R100",
        "title": "Primitive Anchor Field-Origin Gate",
        "closed_statement": "A={1,1/2,1/3} is the minimal exact primitive support-anchor set at operator level.",
        "status": "PASS_OPERATOR_ORIGIN_CANDIDATE",
        "boundary": "Complete field/PDE derivation remains open.",
    },
    {
        "gate": "R101",
        "title": "Tri-Normal Virtual Support Anchor Gate",
        "closed_statement": "1/3 is a tri-normal virtual support anchor, required for closure but not stable species.",
        "status": "PASS_OPERATOR_GEOMETRY_CANDIDATE",
        "boundary": "Physical species status remains excluded for 1/3.",
    },
    {
        "gate": "R102",
        "title": "Reflection Complement Map Origin Gate",
        "closed_statement": "R(rho)=2-rho is the operator-level reflection complement map.",
        "status": "PASS_OPERATOR_ORIGIN",
        "boundary": "Full PDE implementation remains open.",
    },
    {
        "gate": "R103",
        "title": "Reciprocal Cadence-Return Map Origin Gate",
        "closed_statement": "C(rho)=1/rho is the operator-level cadence-return map.",
        "status": "PASS_OPERATOR_ORIGIN",
        "boundary": "Full PDE implementation remains open.",
    },
    {
        "gate": "R104",
        "title": "Joint R/C Support-Domain Origin Rollup Gate",
        "closed_statement": "D_RC({1,1/2,1/3}) supplies the support domain.",
        "status": "PASS_ROLLUP",
        "boundary": "Support domain is not automatically a species list.",
    },
    {
        "gate": "R105",
        "title": "Field/Action/PDE Implementation Readiness Gate",
        "closed_statement": "Identifies required field/action terms and rejects seed lookup/root/oracle routes.",
        "status": "PASS_READINESS_ONLY",
        "boundary": "Readiness only; full PDE/action derivation remains open.",
    },
    {
        "gate": "R106",
        "title": "Candidate Worldline-Tube Phase/Boundary Action Gate",
        "closed_statement": "Provides a no-smuggling candidate worldline-tube phase/boundary action blueprint.",
        "status": "PASS_BLUEPRINT_ONLY",
        "boundary": "Blueprint only; not a full variational/PDE closure.",
    },
    {
        "gate": "R107",
        "title": "Euler-Lagrange / Constraint Variation Gate",
        "closed_statement": "R/C auxiliary scalar constraints variationally yield rho_R=2-rho and rho_C=1/rho.",
        "status": "PASS_AUXILIARY_VARIATION",
        "boundary": "Binary, normal, slot, and projection PDEs remain open.",
    },
    {
        "gate": "R108",
        "title": "Locality and Gauge/Frame Relabeling Gate",
        "closed_statement": "The action blueprint passes local phase-gauge and normal-frame relabeling checks.",
        "status": "PASS_LOCAL_COVARIANT_BLUEPRINT",
        "boundary": "Relabeling safety is not full PDE closure.",
    },
    {
        "gate": "R109",
        "title": "Discrete Binary No-Overlap Variation Gate",
        "closed_statement": "Given binary width w=1/2, KKT no-overlap gives rho>=1/2.",
        "status": "PASS_DISCRETE_KKT_CONDITIONAL",
        "boundary": "K=2 deeper origin remains inherited.",
    },
    {
        "gate": "R110",
        "title": "Normal-Bundle Dimension / Slot-Capacity Derivation Gate",
        "closed_statement": "A 1D worldline in inherited 3+1 geometry gives D_perp=3 and N_slot=4.",
        "status": "PASS_GEOMETRY_CONDITIONAL",
        "boundary": "The deeper origin of 3+1 spacetime remains open.",
    },
    {
        "gate": "R111",
        "title": "Support-to-Species Projection Derivation Gate",
        "closed_statement": "Species = Support ∩ Binary ∩ Slot selects the exact nine-mode mechanical seed.",
        "status": "PASS_OPERATOR_GEOMETRY_PROJECTION",
        "boundary": "Dynamic PDE projection and physical spectrum remain open.",
    },
    {
        "gate": "R112",
        "title": "V12.8 Operator-to-Geometry Rollup Gate",
        "closed_statement": "R100-R111 form a closed operator-to-geometry theorem stack.",
        "status": "PASS_OPERATOR_GEOMETRY_ROLLUP",
        "boundary": "PDE, physical spectrum, masses, SM matching, Omega0 remain open.",
    },
    {
        "gate": "R113",
        "title": "V12.8 Prewrite Claim-Boundary / Paper-Insertion Gate",
        "closed_statement": "Safe manuscript language and claim boundary are ready.",
        "status": "PASS_PREWRITE_CLAIM_BOUNDARY",
        "boundary": "Language must not upgrade mechanical seed to physical spectrum.",
    },
]

expected_gate_df = pd.DataFrame(expected_gates)

# ---------------------------------------------------------------------
# 2. Discover local artifacts from R100-R113.
# ---------------------------------------------------------------------

def find_artifacts_for_gate(gate):
    # Avoid scanning inside the new R114 output directory.
    hits = []
    for p in ROOT.rglob(f"*{gate}*"):
        try:
            if OUT in p.parents or p == OUT:
                continue
        except Exception:
            pass
        if p.is_file() or p.is_dir():
            hits.append(p)
    return sorted(set(hits), key=lambda x: str(x).lower())

inventory_rows = []
snapshot_rows = []

for gate in expected_gate_df["gate"]:
    hits = find_artifacts_for_gate(gate)

    verdict_files = [
        p for p in hits
        if p.is_file() and p.name.lower().endswith("verdict.json")
    ]
    summary_files = [
        p for p in hits
        if p.is_file() and ("summary" in p.name.lower()) and p.suffix.lower() in [".md", ".txt"]
    ]
    pack_files = [
        p for p in hits
        if p.is_file() and p.suffix.lower() == ".zip"
    ]
    md_files = [
        p for p in hits
        if p.is_file() and p.suffix.lower() == ".md"
    ]
    csv_files = [
        p for p in hits
        if p.is_file() and p.suffix.lower() == ".csv"
    ]

    inventory_rows.append({
        "gate": gate,
        "artifact_hits": len(hits),
        "verdict_json_count": len(verdict_files),
        "summary_count": len(summary_files),
        "zip_pack_count": len(pack_files),
        "md_count": len(md_files),
        "csv_count": len(csv_files),
        "source_found": len(hits) > 0,
        "best_verdict_path": str(verdict_files[0]) if verdict_files else "",
        "best_summary_path": str(summary_files[0]) if summary_files else "",
        "best_pack_path": str(pack_files[0]) if pack_files else "",
    })

    # Copy compact source snapshots only, not full nested packs.
    for p in (verdict_files[:1] + summary_files[:1]):
        try:
            target = SNAP / f"{gate}_{p.name}"
            shutil.copy2(p, target)
            snapshot_rows.append({
                "gate": gate,
                "source": str(p),
                "snapshot": str(target),
                "sha256": sha256_file(target),
                "bytes": target.stat().st_size,
            })
        except Exception as e:
            snapshot_rows.append({
                "gate": gate,
                "source": str(p),
                "snapshot": "",
                "sha256": "",
                "bytes": 0,
                "error": str(e),
            })

artifact_inventory = pd.DataFrame(inventory_rows)
source_snapshot_inventory = pd.DataFrame(snapshot_rows)

gates_with_sources = int(artifact_inventory["source_found"].sum())
expected_gates_count = len(expected_gate_df)
source_inventory_complete = gates_with_sources == expected_gates_count

r112_found = bool(artifact_inventory[artifact_inventory["gate"] == "R112"]["source_found"].iloc[0])
r113_found = bool(artifact_inventory[artifact_inventory["gate"] == "R113"]["source_found"].iloc[0])
core_rollup_sources_found = r112_found and r113_found

# ---------------------------------------------------------------------
# 3. Freeze artifacts.
# ---------------------------------------------------------------------

safe_paper_insert = f"""# V12.8 Frozen Paper Insert

## V12.8 operator-geometric support-to-species closure

The V12.8 audit establishes an operator-geometric closure from primitive support anchors to a finite mechanical seed. The primitive support anchors are

A = {{1, 1/2, 1/3}}.

The two closure maps are

R(rho)=2-rho,

and

C(rho)=1/rho.

The joint support domain D_RC(A) is generated by applying these maps to the anchor set within the admissible interval 0<rho<=2, with R(2)=0_boundary treated as a boundary endpoint.

Support activity is not sufficient for stable species activity. The species projection is defined by the simultaneous admissibility condition

{canonical_formula}.

Here rho>=1/2 is the binary no-overlap admissibility threshold, obtained as a discrete KKT condition conditional on binary write-cell width w=1/2. The denominator cap denom(rho)<=4 is the worldline-tube slot-capacity condition obtained from a 1D worldline in inherited 3+1 spacetime, where D_perp=3 and N_slot=1+D_perp=4.

The projection selects exactly the nine-mode mechanical seed

{selected_seed}.

The virtual support channels {{1/3, 3/5, 4/5}} remain support-active but species-inactive. They are not removed by hand: 1/3 fails binary no-overlap, while 3/5 and 4/5 fail the slot-capacity condition. Stable modes may nevertheless depend on these virtual support channels; for example, 5/3 is supported through 1/3 and 3/5, while 5/4 has reciprocal support through 4/5.

This result should be read as an operator-geometric support-to-species selection theorem. It does not yet constitute a physical particle-spectrum derivation. A complete local PDE/action implementation, physical species identification, Standard Model charge and mass matching, Omega0, the deeper origin of K=2, and the deeper origin of 3+1 spacetime remain open.
"""

freeze_note = f"""# {FREEZE_TITLE}

## Freeze ID

BOXED: {FREEZE_ID}

## Frozen claim

BOXED:
V12.8 closes an operator-geometric theorem stack selecting a nine-mode mechanical seed.

## Canonical formula

BOXED:
{canonical_formula}

## Selected seed

BOXED:
{selected_seed}

## Virtual support status

BOXED:
{{1/3, 3/5, 4/5}} are support-active but species-inactive.

- 1/3 fails binary no-overlap.
- 3/5 fails slot capacity.
- 4/5 fails slot capacity.

## Guardrail boundary

BOXED:
This is not a confirmed physical particle-spectrum derivation.

BOXED:
Full PDE/action dynamics remain open.

BOXED:
Masses, Standard Model matching, and Omega0 remain open.

BOXED:
K=2 deeper origin remains inherited.

BOXED:
3+1 spacetime origin remains inherited.

## Source inventory

- Expected gates: {expected_gates_count}
- Gates with local artifacts discovered: {gates_with_sources}
- Source inventory complete: {source_inventory_complete}
- Core R112/R113 sources found: {core_rollup_sources_found}

## Freeze interpretation

The freeze pack preserves the R100-R113 theorem-stack ledger, safe paper insert language, claim-boundary matrix, overclaim guardrails, open-problem register, source artifact inventory, and compact source snapshots where available.
"""

final_freeze_card = f"""# V12.8 Final Freeze Card

## Status

FROZEN as operator-geometric theorem-stack package.

## Exact allowed sentence

V12.8 derives a nine-mode mechanical/operator-geometric support seed from primitive support anchors, R/C closure, binary no-overlap admissibility, and 3+1 worldline-tube slot capacity.

## Exact selected seed

{selected_seed}

## Canonical projection

{canonical_formula}

## Required disclaimer

This is not yet a physical particle-spectrum derivation, not a completed PDE/action theory, and not a Standard Model mass/parameter derivation.

## Open items preserved

- Full PDE/action dynamics.
- Physical particle-spectrum identification.
- Mass hierarchy.
- Standard Model charge/mass matching.
- Omega0.
- Deeper origin of K=2.
- Deeper origin of 3+1 spacetime.
"""

do_not_overclaim = pd.DataFrame([
    {
        "prohibited_claim": "V12.8 derives the physical particle spectrum.",
        "safe_replacement": "V12.8 selects a nine-mode mechanical/operator-geometric seed.",
        "status": "PROHIBITED",
    },
    {
        "prohibited_claim": "V12.8 derives the Standard Model.",
        "safe_replacement": "V12.8 provides an operator-geometric support scaffold for future physical matching.",
        "status": "PROHIBITED",
    },
    {
        "prohibited_claim": "V12.8 derives particle masses.",
        "safe_replacement": "Mass hierarchy and parameter matching remain open.",
        "status": "PROHIBITED",
    },
    {
        "prohibited_claim": "V12.8 predicts Omega0.",
        "safe_replacement": "Omega0 is not addressed by V12.8.",
        "status": "PROHIBITED",
    },
    {
        "prohibited_claim": "V12.8 closes full PDE/action dynamics.",
        "safe_replacement": "V12.8 closes the operator-geometric theorem stack; full PDE/action dynamics remain open.",
        "status": "PROHIBITED",
    },
    {
        "prohibited_claim": "V12.8 derives K=2 from scratch.",
        "safe_replacement": "K=2 remains inherited from the binary no-overwrite predicate stack.",
        "status": "PROHIBITED",
    },
    {
        "prohibited_claim": "V12.8 derives why spacetime is 3+1.",
        "safe_replacement": "The 3+1 premise is inherited; R110 derives D_perp=3 conditional on it.",
        "status": "PROHIBITED",
    },
    {
        "prohibited_claim": "Virtual supports are manually deleted.",
        "safe_replacement": "Virtual supports fail admissibility filters while remaining support-active.",
        "status": "PROHIBITED",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R100-R113 can be frozen as a V12.8 operator-to-geometry theorem stack.",
        "status": "YES",
        "reason": "The theorem stack and safe paper language are packaged with boundaries and guardrails.",
    },
    {
        "claim": "The canonical formula selects exactly nine mechanical seed modes.",
        "status": "YES",
        "reason": canonical_formula,
    },
    {
        "claim": "Virtual support modes are support-active but species-inactive.",
        "status": "YES",
        "reason": "1/3 fails binary; 3/5 and 4/5 fail slot capacity.",
    },
    {
        "claim": "The freeze pack claims a confirmed physical spectrum.",
        "status": "NO",
        "reason": "Physical spectrum identification remains open.",
    },
    {
        "claim": "The freeze pack claims masses, SM matching, or Omega0.",
        "status": "NO",
        "reason": "These remain future work.",
    },
    {
        "claim": "The freeze pack claims full PDE/action closure.",
        "status": "NO",
        "reason": "Full local PDE/action dynamics remain open.",
    },
    {
        "claim": "The freeze pack derives K=2 from scratch.",
        "status": "NO",
        "reason": "K=2 deeper origin remains inherited.",
    },
    {
        "claim": "The freeze pack derives why spacetime is 3+1.",
        "status": "NO",
        "reason": "3+1 spacetime origin remains inherited.",
    },
])

open_problem_register = pd.DataFrame([
    {
        "open_item": "Full local PDE/action implementation",
        "status": "OPEN",
        "frozen_boundary": "R105-R108 give readiness, blueprint, R/C auxiliary variation, and covariance only.",
    },
    {
        "open_item": "Physical particle-spectrum identification",
        "status": "OPEN",
        "frozen_boundary": "The nine-mode set is a mechanical/operator-geometric seed.",
    },
    {
        "open_item": "Mass hierarchy and Standard Model matching",
        "status": "OPEN",
        "frozen_boundary": "No SM mass or parameter matching is claimed.",
    },
    {
        "open_item": "Omega0",
        "status": "OPEN",
        "frozen_boundary": "Not addressed by V12.8.",
    },
    {
        "open_item": "K=2 deeper origin",
        "status": "INHERITED",
        "frozen_boundary": "R109 derives rho>=1/2 conditional on binary write-cell width w=1/2.",
    },
    {
        "open_item": "3+1 spacetime deeper origin",
        "status": "INHERITED",
        "frozen_boundary": "R110 derives D_perp=3 conditional on 3+1 spacetime.",
    },
    {
        "open_item": "Dynamic support-to-species PDE flow",
        "status": "OPEN",
        "frozen_boundary": "R111 closes projection as logical/operator-geometric admissibility.",
    },
])

appendix_toc = pd.DataFrame([
    {
        "appendix_item": "A",
        "title": "V12.8 theorem-stack ledger",
        "file": "V12_8_gate_rollup_R100_R113.csv",
    },
    {
        "appendix_item": "B",
        "title": "Canonical operator-geometric formula",
        "file": "V12_8_operator_formula.md",
    },
    {
        "appendix_item": "C",
        "title": "Safe paper insert",
        "file": "V12_8_safe_paper_insert.md",
    },
    {
        "appendix_item": "D",
        "title": "Claim boundary matrix",
        "file": "V12_8_claim_boundary_matrix.csv",
    },
    {
        "appendix_item": "E",
        "title": "Do-not-overclaim guardrails",
        "file": "V12_8_do_not_overclaim_guardrails.csv",
    },
    {
        "appendix_item": "F",
        "title": "Open problem register",
        "file": "V12_8_open_problem_register.csv",
    },
    {
        "appendix_item": "G",
        "title": "Artifact inventory",
        "file": "V12_8_artifact_inventory.csv",
    },
    {
        "appendix_item": "H",
        "title": "Compact source snapshots",
        "file": "source_snapshots/",
    },
])

operator_formula_md = f"""# V12.8 Canonical Operator-Geometric Formula

## Primitive anchors

A = {{1, 1/2, 1/3}}

## Closure maps

R(rho)=2-rho

C(rho)=1/rho

## Support domain

rho ∈ D_RC(A)

## Binary admissibility

rho >= 1/2

## Slot admissibility

denom(rho) <= 4

## Species projection

{canonical_formula}

## Selected seed

{selected_seed}
"""

# Write freeze docs.
(OUT / "SFT_V12_8_operator_geometry_freeze_note.md").write_text(freeze_note, encoding="utf-8")
(OUT / "V12_8_final_freeze_card.md").write_text(final_freeze_card, encoding="utf-8")
(OUT / "V12_8_safe_paper_insert.md").write_text(safe_paper_insert, encoding="utf-8")
(OUT / "V12_8_operator_formula.md").write_text(operator_formula_md, encoding="utf-8")

expected_gate_df.to_csv(OUT / "V12_8_gate_rollup_R100_R113.csv", index=False)
artifact_inventory.to_csv(OUT / "V12_8_artifact_inventory.csv", index=False)
source_snapshot_inventory.to_csv(OUT / "V12_8_source_snapshot_inventory.csv", index=False)
claim_boundary.to_csv(OUT / "V12_8_claim_boundary_matrix.csv", index=False)
do_not_overclaim.to_csv(OUT / "V12_8_do_not_overclaim_guardrails.csv", index=False)
open_problem_register.to_csv(OUT / "V12_8_open_problem_register.csv", index=False)
appendix_toc.to_csv(OUT / "V12_8_appendix_toc.csv", index=False)

# ---------------------------------------------------------------------
# 4. Overclaim scan and freeze verdict.
# ---------------------------------------------------------------------

generated_md_files = list(OUT.glob("*.md"))

forbidden_exact_phrases = [
    "derives the physical particle spectrum",
    "derives the Standard Model",
    "predicts particle masses",
    "predicts Omega0",
    "closes full PDE/action dynamics",
    "derives K=2 from scratch",
    "derives why spacetime is 3+1",
    "virtual supports are manually deleted",
]

scan_rows = []
for md in generated_md_files:
    text = md.read_text(encoding="utf-8").lower()
    for phrase in forbidden_exact_phrases:
        scan_rows.append({
            "file": md.name,
            "forbidden_phrase": phrase,
            "present": phrase.lower() in text,
        })

overclaim_scan = pd.DataFrame(scan_rows)
overclaim_guardrail_pass = not bool(overclaim_scan["present"].any())

required_files = [
    OUT / "SFT_V12_8_operator_geometry_freeze_note.md",
    OUT / "V12_8_final_freeze_card.md",
    OUT / "V12_8_safe_paper_insert.md",
    OUT / "V12_8_operator_formula.md",
    OUT / "V12_8_gate_rollup_R100_R113.csv",
    OUT / "V12_8_claim_boundary_matrix.csv",
    OUT / "V12_8_do_not_overclaim_guardrails.csv",
    OUT / "V12_8_open_problem_register.csv",
    OUT / "V12_8_artifact_inventory.csv",
    OUT / "V12_8_appendix_toc.csv",
]

required_files_present = all(p.exists() and p.stat().st_size > 0 for p in required_files)

full_PDE_claimed_closed = False
physical_spectrum_claimed = False
masses_SM_Omega0_claimed = False
K2_origin_claimed_derived = False
spacetime_3plus1_origin_claimed_derived = False

freeze_ready = bool(
    required_files_present
    and core_rollup_sources_found
    and overclaim_guardrail_pass
    and not full_PDE_claimed_closed
    and not physical_spectrum_claimed
    and not masses_SM_Omega0_claimed
    and not K2_origin_claimed_derived
    and not spacetime_3plus1_origin_claimed_derived
)

if freeze_ready and source_inventory_complete:
    verdict_status = "V12.8 APPENDIX PACKAGING / FREEZE PASS"
elif freeze_ready and not source_inventory_complete:
    verdict_status = "V12.8 FREEZE PACK PASS / SOURCE INVENTORY PARTIAL"
else:
    verdict_status = "V12.8 FREEZE PACKAGING INCONCLUSIVE"

gate_audit = pd.DataFrame([
    {
        "test": "required_files_present",
        "result": "PASS" if required_files_present else "WARN",
        "interpretation": "Freeze note, formula, paper insert, rollup, guardrails, claim matrix, and inventory were generated.",
    },
    {
        "test": "core_rollup_sources_found",
        "result": "PASS" if core_rollup_sources_found else "WARN",
        "interpretation": "R112 and R113 source artifacts were found locally.",
    },
    {
        "test": "source_inventory_complete",
        "result": "PASS" if source_inventory_complete else "PARTIAL",
        "interpretation": f"{gates_with_sources}/{expected_gates_count} expected gate artifact groups were found locally.",
    },
    {
        "test": "overclaim_guardrail_pass",
        "result": "PASS" if overclaim_guardrail_pass else "WARN",
        "interpretation": "Generated freeze docs do not use prohibited exact overclaim phrases.",
    },
    {
        "test": "full_PDE_claimed_closed",
        "result": "OPEN",
        "interpretation": "Full PDE/action closure is not claimed.",
    },
    {
        "test": "physical_spectrum_claimed",
        "result": "OPEN",
        "interpretation": "Physical particle-spectrum derivation is not claimed.",
    },
    {
        "test": "masses_SM_Omega0_claimed",
        "result": "OPEN",
        "interpretation": "Masses, SM matching, and Omega0 are not claimed.",
    },
    {
        "test": "K2_origin_claimed_derived",
        "result": "INHERITED",
        "interpretation": "K=2 deeper origin remains inherited.",
    },
    {
        "test": "spacetime_3plus1_origin_claimed_derived",
        "result": "INHERITED",
        "interpretation": "3+1 spacetime origin remains inherited.",
    },
    {
        "test": "freeze_ready",
        "result": "PASS" if freeze_ready else "WARN",
        "interpretation": "The freeze pack is ready if core sources and required freeze docs are present.",
    },
])

gate_audit.to_csv(OUT / "FORCE_R114_gate_audit.csv", index=False)
overclaim_scan.to_csv(OUT / "FORCE_R114_overclaim_scan.csv", index=False)

# Summary and verdict JSON.
summary = f"""# FORCE_R114 — V12.8 Appendix Packaging / Freeze Gate

## Verdict

BOXED: {verdict_status}

## Freeze ID

BOXED: {FREEZE_ID}

## Frozen title

BOXED: {FREEZE_TITLE}

## Frozen allowed claim

BOXED:
V12.8 closes an operator-geometric theorem stack selecting a nine-mode mechanical seed.

## Canonical formula

BOXED:
{canonical_formula}

## Selected seed

BOXED:
{selected_seed}

## Freeze-ready booleans

- required_files_present: {required_files_present}
- core_rollup_sources_found: {core_rollup_sources_found}
- source_inventory_complete: {source_inventory_complete}
- gates_with_sources: {gates_with_sources}/{expected_gates_count}
- overclaim_guardrail_pass: {overclaim_guardrail_pass}
- freeze_ready: {freeze_ready}

## Claims not made

- full_PDE_claimed_closed: {full_PDE_claimed_closed}
- physical_spectrum_claimed: {physical_spectrum_claimed}
- masses_SM_Omega0_claimed: {masses_SM_Omega0_claimed}
- K2_origin_claimed_derived: {K2_origin_claimed_derived}
- spacetime_3plus1_origin_claimed_derived: {spacetime_3plus1_origin_claimed_derived}

## Gate audit

{gate_audit.to_string(index=False)}

## Artifact inventory

{artifact_inventory.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Open problem register

{open_problem_register.to_string(index=False)}

## Do-not-overclaim guardrails

{do_not_overclaim.to_string(index=False)}

## Appendix TOC

{appendix_toc.to_string(index=False)}
"""
(OUT / "FORCE_R114_summary.md").write_text(summary, encoding="utf-8")

verdict = {
    "force_id": "FORCE_R114",
    "title": "V12.8 Appendix Packaging / Freeze Gate",
    "freeze_id": FREEZE_ID,
    "freeze_title": FREEZE_TITLE,
    "status": verdict_status,
    "required_files_present": required_files_present,
    "core_rollup_sources_found": core_rollup_sources_found,
    "source_inventory_complete": source_inventory_complete,
    "gates_with_sources": gates_with_sources,
    "expected_gates_count": expected_gates_count,
    "overclaim_guardrail_pass": overclaim_guardrail_pass,
    "freeze_ready": freeze_ready,
    "selected_seed": [frac_label(x) for x in SEED],
    "canonical_formula": canonical_formula,
    "full_PDE_claimed_closed": full_PDE_claimed_closed,
    "physical_spectrum_claimed": physical_spectrum_claimed,
    "masses_SM_Omega0_claimed": masses_SM_Omega0_claimed,
    "K2_origin_claimed_derived": K2_origin_claimed_derived,
    "spacetime_3plus1_origin_claimed_derived": spacetime_3plus1_origin_claimed_derived,
    "pack_name": str(ZIP),
    "recommended_next": "freeze_V12_8_or_compile_public_note",
}
(OUT / "FORCE_R114_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

# Manifest after all files are created.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": p.stat().st_size,
            "sha256": sha256_file(p),
        })
manifest = pd.DataFrame(manifest_rows)
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(8, 5))
plt.bar(["found", "missing"], [gates_with_sources, expected_gates_count - gates_with_sources])
plt.ylabel("gate artifact groups")
plt.title("R114 source inventory completeness")
plt.tight_layout()
plt.savefig(PLOTS / "source_inventory_completeness.png", dpi=160)
plt.close()

status_counts = expected_gate_df["status"].value_counts()
plt.figure(figsize=(11, 5))
plt.bar(status_counts.index, status_counts.values)
plt.xticks(rotation=35, ha="right")
plt.ylabel("count")
plt.title("R114 expected theorem-stack statuses")
plt.tight_layout()
plt.savefig(PLOTS / "theorem_stack_status_counts.png", dpi=160)
plt.close()

boundary_counts = claim_boundary["status"].value_counts()
plt.figure(figsize=(7, 5))
plt.bar(boundary_counts.index, boundary_counts.values)
plt.ylabel("count")
plt.title("R114 claim boundary YES/NO counts")
plt.tight_layout()
plt.savefig(PLOTS / "claim_boundary_counts.png", dpi=160)
plt.close()

# Copy this script.
try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R114_V12_8_appendix_packaging_freeze_gate.py")
except Exception:
    pass

# Zip.
if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

zip_integrity_pass = bad is None

# Update verdict with zip integrity.
verdict["zip_integrity_pass"] = zip_integrity_pass
(OUT / "FORCE_R114_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

print("\n=== COPY/PASTE R114 RESULT ===")
print("R114 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"FREEZE_TITLE: {FREEZE_TITLE}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"required_files_present: {required_files_present}")
print(f"core_rollup_sources_found: {core_rollup_sources_found}")
print(f"source_inventory_complete: {source_inventory_complete}")
print(f"gates_with_sources: {gates_with_sources}/{expected_gates_count}")
print(f"overclaim_guardrail_pass: {overclaim_guardrail_pass}")
print(f"freeze_ready: {freeze_ready}")
print(f"selected_seed: {selected_seed}")
print(f"canonical_formula: {canonical_formula}")
print(f"full_PDE_claimed_closed: {full_PDE_claimed_closed}")
print(f"physical_spectrum_claimed: {physical_spectrum_claimed}")
print(f"masses_SM_Omega0_claimed: {masses_SM_Omega0_claimed}")
print(f"K2_origin_claimed_derived: {K2_origin_claimed_derived}")
print(f"spacetime_3plus1_origin_claimed_derived: {spacetime_3plus1_origin_claimed_derived}")
print("AUDIT:")
print(gate_audit.to_string(index=False))
print("APPENDIX_TOC:")
print(appendix_toc.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("OPEN_PROBLEM_REGISTER:")
print(open_problem_register.to_string(index=False))
print("DO_NOT_OVERCLAIM_GUARDRAILS:")
print(do_not_overclaim.to_string(index=False))
print("ARTIFACT_INVENTORY:")
print(artifact_inventory.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R114_summary.md').resolve()}")
print("NEXT: freeze_V12_8_or_compile_public_note")
print("=== END COPY/PASTE R114 RESULT ===\n")
