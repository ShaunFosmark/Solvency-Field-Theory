# FORCE_R110 — Normal-Bundle Dimension / Slot-Capacity Derivation Gate

## Verdict

BOXED: NORMAL-BUNDLE D_PERP=3 AND 1+3 SLOT-CAPACITY PASS / 3+1 ORIGIN AND FULL PDE DERIVATION OPEN

## Central geometry

A 1D worldline in 3+1 spacetime has:

BOXED: D_perp = 4 - 1 = 3

The total slot budget is:

BOXED: N_slot = 1 + D_perp = 1 + 3 = 4

The tri-normal virtual support anchor is:

BOXED: rho_normal = 1/D_perp = 1/3

The species denominator filter is:

BOXED: denom(rho) <= 4

## Selected seed

BOXED: 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2

## Key booleans

- normal_rank_conditional_derivation_pass: True
- slot_capacity_conditional_derivation_pass: True
- D3_geometry_exact: True
- wrong_dimensions_fail: True
- cap4_exact: True
- cap_controls_fail: True
- best_route_pass: True
- hardcoded_cap_rejected: True
- route_controls_fail: True
- operator_reconstruction_exact: True
- virtual_support_split_pass: True
- intruder_7_4_excluded: True
- spacetime_dimension_origin_derived: False
- smooth_PDE_closed: False

## Gate audit

                                     test result                                                                          interpretation
  normal_rank_conditional_derivation_pass   PASS                       For a 1D worldline in 3+1 spacetime, normal rank is D_perp=4-1=3.
slot_capacity_conditional_derivation_pass   PASS                           Tangent/base slot plus three normal slots gives N_slot=1+3=4.
                        D3_geometry_exact   PASS                     The 3+1 worldline-tube route reconstructs the exact nine-mode seed.
                    wrong_dimensions_fail   PASS              2+1, 4+1, and higher/lower ambient-dimension controls fail exact recovery.
                               cap4_exact   PASS                                  For D_perp=3, slot cap 4 is the exact-capacity result.
                        cap_controls_fail   PASS                             Cap controls below 4 are too strict; above 4 are too loose.
                   hardcoded_cap_rejected   PASS       A naked denominator cap 4 with no worldline geometry is rejected as a cap oracle.
                      route_controls_fail   PASS                    Wrong-dimension, normal-only, extra-slot, and no-slot controls fail.
            operator_reconstruction_exact   PASS Selected geometry plus R/C domain and binary KKT threshold reconstructs the exact seed.
               virtual_support_split_pass   PASS                           1/3, 3/5, and 4/5 remain support-active but species-inactive.
                    intruder_7_4_excluded   PASS           The 7/4 intruder remains excluded by the 3+1 geometry support/capacity stack.
       spacetime_dimension_origin_derived   OPEN  R110 does not derive why spacetime is 3+1; it uses 3+1 as inherited physical geometry.
                        smooth_PDE_closed   OPEN                     R110 is a geometry/capacity gate, not a full smooth PDE derivation.

## Geometry derivation steps

 step                                                                                     statement                              formula                             status
    1                                              Take the local object to be a 1D worldline tube.       x^mu(tau), rank(T_worldline)=1                    GEOMETRIC_INPUT
    2                                                         Embed the worldline in 3+1 spacetime.                             dim(M)=4        INHERITED_PHYSICAL_GEOMETRY
    3                                        Normal-bundle rank is ambient rank minus tangent rank.                D_perp = dim(M)-1 = 3         PASS_CONDITIONAL_ON_3PLUS1
    4                   Tri-normal equal-share support anchor follows from three normal directions.          rho_normal = 1/D_perp = 1/3       PASS_CONDITIONAL_ON_D_PERP_3
    5 Total independent write/cadence slot budget includes one tangent/base slot plus normal slots.              N_slot = 1 + D_perp = 4 PASS_CONDITIONAL_ON_WORLDLINE_TUBE
    6                                 Stable species denominator filter follows from slot capacity.             denom(rho) <= N_slot = 4      PASS_OPERATOR_GEOMETRY_BRIDGE
    7                                           The deeper origin of 3+1 spacetime is derived here.                        why dim(M)=4?           OPEN_NOT_DERIVED_IN_R110
    8                                         The full smooth PDE/action derivation is closed here. Euler-Lagrange/PDE for slot capacity           OPEN_NOT_DERIVED_IN_R110

## Ambient dimension scan

 ambient_spacetime_dim  worldline_tangent_rank  D_perp normal_support_anchor  slot_cap_1_plus_Dperp  anchor_set  support_domain_count  stable_count_final                                                           stable_fractions_final  exact_seed_all_denominators                                extra_vs_seed       missing_from_seed            geometry_status
                     2                       1       1                     1                      2      1/2, 1                    64                   4                                                                   1/2, 1, 3/2, 2                        False                                         none 2/3, 3/4, 5/4, 4/3, 5/3     FAIL_CONTROL_DIMENSION
                     3                       1       2                   1/2                      3      1/2, 1                    64                   6                                                         1/2, 2/3, 1, 4/3, 3/2, 2                        False                                         none           3/4, 5/4, 5/3     FAIL_CONTROL_DIMENSION
                     4                       1       3                   1/3                      4 1/3, 1/2, 1                    94                   9                                          1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True                                         none                    none PASS_3PLUS1_WORLDLINE_TUBE
                     5                       1       4                   1/4                      5 1/4, 1/2, 1                    84                  11                                1/2, 2/3, 3/4, 4/5, 1, 6/5, 5/4, 4/3, 3/2, 7/4, 2                        False                                4/5, 6/5, 7/4                     5/3     FAIL_CONTROL_DIMENSION
                     6                       1       5                   1/5                      6 1/5, 1/2, 1                    78                  13                      1/2, 2/3, 3/4, 4/5, 5/6, 1, 7/6, 6/5, 5/4, 4/3, 3/2, 9/5, 2                        False                      4/5, 5/6, 7/6, 6/5, 9/5                     5/3     FAIL_CONTROL_DIMENSION
                     7                       1       6                   1/6                      7 1/6, 1/2, 1                    76                  15           1/2, 2/3, 3/4, 4/5, 5/6, 6/7, 1, 8/7, 7/6, 6/5, 5/4, 4/3, 3/2, 11/6, 2                        False           4/5, 5/6, 6/7, 8/7, 7/6, 6/5, 11/6                     5/3     FAIL_CONTROL_DIMENSION
                     8                       1       7                   1/7                      8 1/7, 1/2, 1                    74                  17 1/2, 2/3, 3/4, 4/5, 5/6, 6/7, 7/8, 1, 9/8, 8/7, 7/6, 6/5, 5/4, 4/3, 3/2, 13/7, 2                        False 4/5, 5/6, 6/7, 7/8, 9/8, 8/7, 7/6, 6/5, 13/7                     5/3     FAIL_CONTROL_DIMENSION

## Slot-capacity scan

 slot_cap                     derivation_route  stable_count                                                                                    stable_fractions  exact_seed                                              extra_vs_seed                 missing_from_seed                                                  interpretation
        1                     control_capacity             2                                                                                                1, 2       False                                                       none 1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3                                                      too strict
        2                     control_capacity             4                                                                                      1/2, 1, 3/2, 2       False                                                       none           2/3, 3/4, 5/4, 4/3, 5/3                                                      too strict
        3                     control_capacity             7                                                                       1/2, 2/3, 1, 4/3, 3/2, 5/3, 2       False                                                       none                          3/4, 5/4                                                      too strict
        4 worldline_tangent_plus_three_normals             9                                                             1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True                                                       none                              none                                              1+3 capacity exact
        5                     control_capacity            13                                         1/2, 3/5, 2/3, 3/4, 4/5, 1, 6/5, 5/4, 4/3, 7/5, 3/2, 5/3, 2       False                                         3/5, 4/5, 6/5, 7/5                              none too loose; admits extra virtual/support denominators as species
        6                     control_capacity            15                               1/2, 3/5, 2/3, 3/4, 4/5, 5/6, 1, 7/6, 6/5, 5/4, 4/3, 7/5, 3/2, 5/3, 2       False                               3/5, 4/5, 5/6, 7/6, 6/5, 7/5                              none too loose; admits extra virtual/support denominators as species
        7                     control_capacity            19           1/2, 3/5, 2/3, 5/7, 3/4, 4/5, 5/6, 6/7, 1, 8/7, 7/6, 6/5, 5/4, 9/7, 4/3, 7/5, 3/2, 5/3, 2       False           3/5, 5/7, 4/5, 5/6, 6/7, 8/7, 7/6, 6/5, 9/7, 7/5                              none too loose; admits extra virtual/support denominators as species
        8                     control_capacity            21 1/2, 3/5, 2/3, 5/7, 3/4, 4/5, 5/6, 6/7, 7/8, 1, 9/8, 8/7, 7/6, 6/5, 5/4, 9/7, 4/3, 7/5, 3/2, 5/3, 2       False 3/5, 5/7, 4/5, 5/6, 6/7, 7/8, 9/8, 8/7, 7/6, 6/5, 9/7, 7/5                              none too loose; admits extra virtual/support denominators as species

## Candidate route scorecard

                         route                                          description  ambient_dim  D_perp normal_anchor slot_cap  local_geometry  hardcoded_target_cap  uses_3plus1_worldline_geometry  stable_count                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    stable_fractions  exact_seed                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              extra_vs_seed missing_from_seed                  expected                    route_status
C0_hardcoded_denominator_cap_4      Directly impose denom(rho)<=4 with no geometry.            4       3           1/3        4           False                  True                           False             9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none              none         REJECT_CAP_ORACLE        PASS_REJECTED_CAP_ORACLE
     C1_two_plus_one_worldline                1D worldline in 2+1 ambient geometry.            3       2           1/2        3            True                 False                           False             6                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1/2, 2/3, 1, 4/3, 3/2, 2       False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none     3/4, 5/4, 5/3      FAIL_WRONG_DIMENSION PASS_CONTROL_FAILED_AS_EXPECTED
   C2_three_plus_one_worldline   1D worldline in 3+1 geometry; D_perp=3; slots=1+3.            4       3           1/3        4            True                 False                            True             9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none              none PASS_CONDITIONAL_GEOMETRY       PASS_CONDITIONAL_GEOMETRY
    C3_four_plus_one_worldline                1D worldline in 4+1 ambient geometry.            5       4           1/4        5            True                 False                           False            11                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   1/2, 2/3, 3/4, 4/5, 1, 6/5, 5/4, 4/3, 3/2, 7/4, 2       False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              4/5, 6/5, 7/4               5/3      FAIL_WRONG_DIMENSION PASS_CONTROL_FAILED_AS_EXPECTED
C4_normal_only_no_tangent_slot D_perp=3 but slot capacity counts only normal slots.            4       3           1/3        3            True                 False                            True             7                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       1/2, 2/3, 1, 4/3, 3/2, 5/3, 2       False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       none          3/4, 5/4 FAIL_MISSING_TANGENT_SLOT PASS_CONTROL_FAILED_AS_EXPECTED
        C5_extra_internal_slot         D_perp=3 but an extra fifth slot is allowed.            4       3           1/3        5            True                  True                            True            13                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         1/2, 3/5, 2/3, 3/4, 4/5, 1, 6/5, 5/4, 4/3, 7/5, 3/2, 5/3, 2       False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         3/5, 4/5, 6/5, 7/5              none            FAIL_TOO_LOOSE PASS_CONTROL_FAILED_AS_EXPECTED
                C6_no_slot_cap             D_perp=3 but no denominator slot filter.            4       3           1/3     none            True                 False                            True            93 1/2, 3/5, 2/3, 5/7, 3/4, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 1, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 5/4, 9/7, 4/3, 7/5, 3/2, 5/3, 2       False 3/5, 5/7, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 9/7, 7/5              none        FAIL_UNBOUNDED_CAP PASS_CONTROL_FAILED_AS_EXPECTED

## Support/species projection audit

rho_fraction      rho  denominator  in_support_domain  binary_accept  slot_accept_Dperp3_cap4  stable_species  R_partner  R_supported C_partner  C_supported             role
         1/4 0.250000            4              False          False                     True           False        7/4        False         4        False rejected_control
         1/3 0.333333            3               True          False                     True           False        5/3         True         3        False  virtual_support
         1/2 0.500000            2               True           True                     True            True        3/2         True         2         True      stable_seed
         3/5 0.600000            5               True           True                    False           False        7/5         True       5/3         True  virtual_support
         2/3 0.666667            3               True           True                     True            True        4/3         True       3/2         True      stable_seed
         3/4 0.750000            4               True           True                     True            True        5/4         True       4/3         True      stable_seed
         4/5 0.800000            5               True           True                    False           False        6/5         True       5/4         True  virtual_support
           1 1.000000            1               True           True                     True            True          1         True         1         True      stable_seed
         6/5 1.200000            5               True           True                    False           False        4/5         True       5/6         True rejected_control
         5/4 1.250000            4               True           True                     True            True        3/4         True       4/5         True      stable_seed
         4/3 1.333333            3               True           True                     True            True        2/3         True       3/4         True      stable_seed
         7/5 1.400000            5               True           True                    False           False        3/5         True       5/7         True rejected_control
         3/2 1.500000            2               True           True                     True            True        1/2         True       2/3         True      stable_seed
         5/3 1.666667            3               True           True                     True            True        1/3         True       3/5         True      stable_seed
         7/4 1.750000            4              False           True                     True           False        1/4        False       4/7        False rejected_control
           2 2.000000            1               True           True                     True            True 0_boundary         True       1/2         True      stable_seed

## Intruder / missing seed audit

                         route fraction      rho  denominator R_partner C_partner               reason
     C1_two_plus_one_worldline      3/4 0.750000            4       5/4       4/3   seed_mode_rejected
     C1_two_plus_one_worldline      5/4 1.250000            4       3/4       4/5   seed_mode_rejected
     C1_two_plus_one_worldline      5/3 1.666667            3       1/3       3/5   seed_mode_rejected
    C3_four_plus_one_worldline      4/5 0.800000            5       6/5       5/4 admitted_beyond_seed
    C3_four_plus_one_worldline      6/5 1.200000            5       4/5       5/6 admitted_beyond_seed
    C3_four_plus_one_worldline      7/4 1.750000            4       1/4       4/7 admitted_beyond_seed
    C3_four_plus_one_worldline      5/3 1.666667            3       1/3       3/5   seed_mode_rejected
C4_normal_only_no_tangent_slot      3/4 0.750000            4       5/4       4/3   seed_mode_rejected
C4_normal_only_no_tangent_slot      5/4 1.250000            4       3/4       4/5   seed_mode_rejected
        C5_extra_internal_slot      3/5 0.600000            5       7/5       5/3 admitted_beyond_seed
        C5_extra_internal_slot      4/5 0.800000            5       6/5       5/4 admitted_beyond_seed
        C5_extra_internal_slot      6/5 1.200000            5       4/5       5/6 admitted_beyond_seed
        C5_extra_internal_slot      7/5 1.400000            5       3/5       5/7 admitted_beyond_seed
                C6_no_slot_cap      3/5 0.600000            5       7/5       5/3 admitted_beyond_seed
                C6_no_slot_cap      5/7 0.714286            7       9/7       7/5 admitted_beyond_seed
                C6_no_slot_cap      7/9 0.777778            9      11/9       9/7 admitted_beyond_seed
                C6_no_slot_cap      4/5 0.800000            5       6/5       5/4 admitted_beyond_seed
                C6_no_slot_cap     9/11 0.818182           11     13/11      11/9 admitted_beyond_seed
                C6_no_slot_cap      5/6 0.833333            6       7/6       6/5 admitted_beyond_seed
                C6_no_slot_cap    11/13 0.846154           13     15/13     13/11 admitted_beyond_seed
                C6_no_slot_cap      6/7 0.857143            7       8/7       7/6 admitted_beyond_seed
                C6_no_slot_cap    13/15 0.866667           15     17/15     15/13 admitted_beyond_seed
                C6_no_slot_cap      7/8 0.875000            8       9/8       8/7 admitted_beyond_seed
                C6_no_slot_cap    15/17 0.882353           17     19/17     17/15 admitted_beyond_seed
                C6_no_slot_cap      8/9 0.888889            9      10/9       9/8 admitted_beyond_seed
                C6_no_slot_cap    17/19 0.894737           19     21/19     19/17 admitted_beyond_seed
                C6_no_slot_cap     9/10 0.900000           10     11/10      10/9 admitted_beyond_seed
                C6_no_slot_cap    19/21 0.904762           21     23/21     21/19 admitted_beyond_seed
                C6_no_slot_cap    10/11 0.909091           11     12/11     11/10 admitted_beyond_seed
                C6_no_slot_cap    21/23 0.913043           23     25/23     23/21 admitted_beyond_seed
                C6_no_slot_cap    11/12 0.916667           12     13/12     12/11 admitted_beyond_seed
                C6_no_slot_cap    23/25 0.920000           25     27/25     25/23 admitted_beyond_seed
                C6_no_slot_cap    12/13 0.923077           13     14/13     13/12 admitted_beyond_seed
                C6_no_slot_cap    25/27 0.925926           27     29/27     27/25 admitted_beyond_seed
                C6_no_slot_cap    13/14 0.928571           14     15/14     14/13 admitted_beyond_seed
                C6_no_slot_cap    27/29 0.931034           29     31/29     29/27 admitted_beyond_seed
                C6_no_slot_cap    14/15 0.933333           15     16/15     15/14 admitted_beyond_seed
                C6_no_slot_cap    29/31 0.935484           31     33/31     31/29 admitted_beyond_seed
                C6_no_slot_cap    15/16 0.937500           16     17/16     16/15 admitted_beyond_seed
                C6_no_slot_cap    16/17 0.941176           17     18/17     17/16 admitted_beyond_seed
                C6_no_slot_cap    17/18 0.944444           18     19/18     18/17 admitted_beyond_seed
                C6_no_slot_cap    18/19 0.947368           19     20/19     19/18 admitted_beyond_seed
                C6_no_slot_cap    19/20 0.950000           20     21/20     20/19 admitted_beyond_seed
                C6_no_slot_cap    20/21 0.952381           21     22/21     21/20 admitted_beyond_seed
                C6_no_slot_cap    21/22 0.954545           22     23/22     22/21 admitted_beyond_seed
                C6_no_slot_cap    22/23 0.956522           23     24/23     23/22 admitted_beyond_seed
                C6_no_slot_cap    23/24 0.958333           24     25/24     24/23 admitted_beyond_seed
                C6_no_slot_cap    24/25 0.960000           25     26/25     25/24 admitted_beyond_seed
                C6_no_slot_cap    25/26 0.961538           26     27/26     26/25 admitted_beyond_seed
                C6_no_slot_cap    26/27 0.962963           27     28/27     27/26 admitted_beyond_seed
                C6_no_slot_cap    27/28 0.964286           28     29/28     28/27 admitted_beyond_seed
                C6_no_slot_cap    28/29 0.965517           29     30/29     29/28 admitted_beyond_seed
                C6_no_slot_cap    29/30 0.966667           30     31/30     30/29 admitted_beyond_seed
                C6_no_slot_cap    30/31 0.967742           31     32/31     31/30 admitted_beyond_seed
                C6_no_slot_cap    31/32 0.968750           32     33/32     32/31 admitted_beyond_seed
                C6_no_slot_cap    33/32 1.031250           32     31/32     32/33 admitted_beyond_seed
                C6_no_slot_cap    32/31 1.032258           31     30/31     31/32 admitted_beyond_seed
                C6_no_slot_cap    31/30 1.033333           30     29/30     30/31 admitted_beyond_seed
                C6_no_slot_cap    30/29 1.034483           29     28/29     29/30 admitted_beyond_seed
                C6_no_slot_cap    29/28 1.035714           28     27/28     28/29 admitted_beyond_seed
                C6_no_slot_cap    28/27 1.037037           27     26/27     27/28 admitted_beyond_seed
                C6_no_slot_cap    27/26 1.038462           26     25/26     26/27 admitted_beyond_seed
                C6_no_slot_cap    26/25 1.040000           25     24/25     25/26 admitted_beyond_seed
                C6_no_slot_cap    25/24 1.041667           24     23/24     24/25 admitted_beyond_seed
                C6_no_slot_cap    24/23 1.043478           23     22/23     23/24 admitted_beyond_seed
                C6_no_slot_cap    23/22 1.045455           22     21/22     22/23 admitted_beyond_seed
                C6_no_slot_cap    22/21 1.047619           21     20/21     21/22 admitted_beyond_seed
                C6_no_slot_cap    21/20 1.050000           20     19/20     20/21 admitted_beyond_seed
                C6_no_slot_cap    20/19 1.052632           19     18/19     19/20 admitted_beyond_seed
                C6_no_slot_cap    19/18 1.055556           18     17/18     18/19 admitted_beyond_seed
                C6_no_slot_cap    18/17 1.058824           17     16/17     17/18 admitted_beyond_seed
                C6_no_slot_cap    17/16 1.062500           16     15/16     16/17 admitted_beyond_seed
                C6_no_slot_cap    33/31 1.064516           31     29/31     31/33 admitted_beyond_seed
                C6_no_slot_cap    16/15 1.066667           15     14/15     15/16 admitted_beyond_seed
                C6_no_slot_cap    31/29 1.068966           29     27/29     29/31 admitted_beyond_seed
                C6_no_slot_cap    15/14 1.071429           14     13/14     14/15 admitted_beyond_seed
                C6_no_slot_cap    29/27 1.074074           27     25/27     27/29 admitted_beyond_seed
                C6_no_slot_cap    14/13 1.076923           13     12/13     13/14 admitted_beyond_seed
                C6_no_slot_cap    27/25 1.080000           25     23/25     25/27 admitted_beyond_seed
                C6_no_slot_cap    13/12 1.083333           12     11/12     12/13 admitted_beyond_seed
                C6_no_slot_cap    25/23 1.086957           23     21/23     23/25 admitted_beyond_seed
                C6_no_slot_cap    12/11 1.090909           11     10/11     11/12 admitted_beyond_seed
                C6_no_slot_cap    23/21 1.095238           21     19/21     21/23 admitted_beyond_seed
                C6_no_slot_cap    11/10 1.100000           10      9/10     10/11 admitted_beyond_seed
                C6_no_slot_cap    21/19 1.105263           19     17/19     19/21 admitted_beyond_seed
                C6_no_slot_cap     10/9 1.111111            9       8/9      9/10 admitted_beyond_seed
                C6_no_slot_cap    19/17 1.117647           17     15/17     17/19 admitted_beyond_seed
                C6_no_slot_cap      9/8 1.125000            8       7/8       8/9 admitted_beyond_seed
                C6_no_slot_cap    17/15 1.133333           15     13/15     15/17 admitted_beyond_seed
                C6_no_slot_cap      8/7 1.142857            7       6/7       7/8 admitted_beyond_seed
                C6_no_slot_cap    15/13 1.153846           13     11/13     13/15 admitted_beyond_seed
                C6_no_slot_cap      7/6 1.166667            6       5/6       6/7 admitted_beyond_seed
                C6_no_slot_cap    13/11 1.181818           11      9/11     11/13 admitted_beyond_seed
                C6_no_slot_cap      6/5 1.200000            5       4/5       5/6 admitted_beyond_seed
                C6_no_slot_cap     11/9 1.222222            9       7/9      9/11 admitted_beyond_seed
                C6_no_slot_cap      9/7 1.285714            7       5/7       7/9 admitted_beyond_seed
                C6_no_slot_cap      7/5 1.400000            5       3/5       5/7 admitted_beyond_seed

## Claim boundary

                                                                     claim status                                                                                                reason
 R110 derives D_perp=3 conditionally from a 1D worldline in 3+1 spacetime.    YES                                    Normal-bundle rank is ambient dimension minus tangent rank: 4-1=3.
R110 derives slot capacity 4 conditionally from tangent plus normal slots.    YES                                    One tangent/base cadence slot plus three normal slots gives 1+3=4.
   R110 derives the normal support anchor 1/3 conditionally from D_perp=3.    YES                                                    Equal-share tri-normal support gives 1/D_perp=1/3.
                  R110 derives why spacetime is 3+1 from first principles.     NO                                3+1 spacetime is an inherited physical/geometric premise in this gate.
                     A naked denom<=4 rule with no geometry is acceptable.     NO                                                  The hardcoded cap route is rejected as a cap oracle.
                        R110 closes the full smooth PDE/action derivation.     NO                                                R110 is a geometry/rank-capacity derivation gate only.
                         R110 fully derives support-to-species projection.     NO               It supplies the slot-capacity component; the full projection is still assigned to R111.
             The nine-mode seed is a confirmed physical particle spectrum.     NO It remains a mechanical support seed until physical field, mass, and interaction bridges are derived.

## Next gate plan

 next_gate                                         title                                                                                      goal                                                     must_not_do
FORCE_R111 Support-to-Species Projection Derivation Gate Derive why support-active modes become stable species only after binary and slot filters.                         Do not delete 1/3, 3/5, or 4/5 by hand.
FORCE_R112        V12.8 Operator-to-Geometry Rollup Gate Roll up R100-R111 into a single operator/geometry theorem stack with open-claim boundary. Do not claim physical spectrum, masses, SM matching, or Omega0.

## Recommended next

BOXED: FORCE_R111 — Support-to-Species Projection Derivation Gate
