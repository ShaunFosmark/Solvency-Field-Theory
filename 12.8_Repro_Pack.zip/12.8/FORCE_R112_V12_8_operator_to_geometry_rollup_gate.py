from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R112_V12_8_operator_to_geometry_rollup_gate")
ZIP = Path("FORCE_R112_V12_8_operator_to_geometry_rollup_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R112 — V12.8 Operator-to-Geometry Rollup Gate
#
# Purpose:
#   Roll up R100-R111 into one theorem-stack audit.
#
# Central V12.8 operator-geometric claim:
#
#   Primitive anchors:
#       A = {1, 1/2, 1/3}
#
#   Maps:
#       R(rho) = 2 - rho
#       C(rho) = 1/rho
#
#   Joint support:
#       rho in D_RC(A)
#
#   Species projection:
#       rho in D_RC(A)
#       rho >= 1/2
#       denom(rho) <= 4
#
#   Selected mechanical seed:
#       {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}
#
# Claim boundary:
#   R112 can close the V12.8 operator-to-geometry theorem stack.
#   It does not close full PDE/action dynamics.
#   It does not claim confirmed physical spectrum.
#   It does not derive masses, SM matching, Omega0, or why 3+1 spacetime exists.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}
CONTROL_MODES = {Fraction(1, 4), Fraction(7, 4), Fraction(6, 5), Fraction(7, 5)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def R_map(x, T=Fraction(2, 1)):
    return T - x

def C_map(x, A=Fraction(1, 1)):
    if x == 0:
        return None
    return A / x

def close_domain(anchors, max_den, T=Fraction(2, 1), A=Fraction(1, 1)):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(900):
        before = set(active)

        for x in list(active):
            r = R_map(x, T=T)
            if r == 0:
                boundary_used = True
            elif in_interval(r) and r in universe:
                active.add(r)

            c = C_map(x, A=A)
            if in_interval(c) and c in universe:
                active.add(c)

        if active == before:
            break

    return active, boundary_used

def binary_accept(x):
    return x >= Fraction(1, 2)

def slot_accept(x, cap=4):
    return x.denominator <= cap

def species_projection(domain, max_den, binary=True, slot=True, cap=4, logic="and"):
    universe = rational_universe(max_den)
    selected = set()

    for x in universe:
        if x not in domain:
            continue

        b = binary_accept(x)
        s = slot_accept(x, cap=cap)

        if binary and slot:
            accept = b and s if logic == "and" else b or s
        elif binary and not slot:
            accept = b
        elif slot and not binary:
            accept = s
        else:
            accept = True

        if accept:
            selected.add(x)

    return selected

def role_of(x, domain, stable):
    if x == 0:
        return "boundary"
    if x in stable:
        return "stable_species"
    if x in domain:
        return "support_only"
    return "not_supported"

domain_full, boundary_used = close_domain(ANCHORS, max(DENOM_AUDITS))
stable_full = species_projection(domain_full, max(DENOM_AUDITS), binary=True, slot=True, cap=4, logic="and")

# ---------------------------------------------------------------------
# 1. Theorem stack rollup.
# ---------------------------------------------------------------------

theorem_stack = pd.DataFrame([
    {
        "gate": "R100",
        "theorem_piece": "primitive anchor candidate set",
        "closed_statement": "A={1,1/2,1/3} is the minimal exact primitive support anchor set at operator level.",
        "status": "PASS_OPERATOR_ORIGIN_CANDIDATE",
        "depends_on": "identity cadence, binary no-overwrite, tri-normal support",
        "open_boundary": "not a complete field/PDE derivation from nothing",
    },
    {
        "gate": "R101",
        "theorem_piece": "tri-normal virtual support anchor",
        "closed_statement": "1/3 acts as virtual support anchor, required for 5/3 closure but not stable species.",
        "status": "PASS_OPERATOR_GEOMETRY_CANDIDATE",
        "depends_on": "D_perp=3 support channel",
        "open_boundary": "D_perp=3 geometric origin handled conditionally in R110",
    },
    {
        "gate": "R102",
        "theorem_piece": "reflection complement",
        "closed_statement": "R(rho)=2-rho is the unique exact complement map in the scanned family.",
        "status": "PASS_OPERATOR_ORIGIN",
        "depends_on": "doubled boundary complement",
        "open_boundary": "auxiliary variational implementation handled in R107",
    },
    {
        "gate": "R103",
        "theorem_piece": "reciprocal cadence-return",
        "closed_statement": "C(rho)=1/rho is the unique exact cadence-return map in the scanned family.",
        "status": "PASS_OPERATOR_ORIGIN",
        "depends_on": "rho*C(rho)=1",
        "open_boundary": "auxiliary variational implementation handled in R107",
    },
    {
        "gate": "R104",
        "theorem_piece": "joint R/C support domain",
        "closed_statement": "D_RC({1,1/2,1/3}) gives the support domain from which the seed is projected.",
        "status": "PASS_ROLLUP",
        "depends_on": "R100-R103",
        "open_boundary": "support does not equal species",
    },
    {
        "gate": "R105",
        "theorem_piece": "field/action/PDE implementation readiness",
        "closed_statement": "Identifies required terms and rejects lookup/root/oracle routes.",
        "status": "PASS_READINESS_ONLY",
        "depends_on": "R104",
        "open_boundary": "field/action/PDE implementation still open",
    },
    {
        "gate": "R106",
        "theorem_piece": "candidate worldline-tube action blueprint",
        "closed_statement": "Provides no-smuggling candidate action/constraint blueprint.",
        "status": "PASS_BLUEPRINT_ONLY",
        "depends_on": "phase, binary, normal, R/C, slot, split terms",
        "open_boundary": "Euler-Lagrange/PDE derivation still open",
    },
    {
        "gate": "R107",
        "theorem_piece": "R/C auxiliary variational constraints",
        "closed_statement": "S_R -> rho_R=2-rho and S_C -> rho_C=1/rho.",
        "status": "PASS_AUXILIARY_VARIATION",
        "depends_on": "R106 R/C scalar auxiliary terms",
        "open_boundary": "binary/normal/slot/projection PDE still open",
    },
    {
        "gate": "R108",
        "theorem_piece": "locality and gauge/frame relabeling",
        "closed_statement": "Covariant phase and normal-frame terms pass relabeling; oracles rejected.",
        "status": "PASS_LOCAL_COVARIANT_BLUEPRINT",
        "depends_on": "D_tau theta, D_tau n_i, local scalar R/C terms",
        "open_boundary": "does not derive discrete/topological projection pieces",
    },
    {
        "gate": "R109",
        "theorem_piece": "binary no-overlap KKT threshold",
        "closed_statement": "Given binary width w=1/2, KKT no-overlap gives rho>=1/2.",
        "status": "PASS_DISCRETE_KKT_CONDITIONAL",
        "depends_on": "inherited K=2 binary record",
        "open_boundary": "does not newly derive K=2 or smooth binary PDE",
    },
    {
        "gate": "R110",
        "theorem_piece": "normal-bundle dimension and slot capacity",
        "closed_statement": "1D worldline in 3+1 gives D_perp=3 and N_slot=1+3=4.",
        "status": "PASS_GEOMETRY_CONDITIONAL",
        "depends_on": "inherited 3+1 spacetime",
        "open_boundary": "does not derive why spacetime is 3+1",
    },
    {
        "gate": "R111",
        "theorem_piece": "support-to-species projection",
        "closed_statement": "Species = Support ∩ Binary ∩ Slot selects the exact nine-mode mechanical seed.",
        "status": "PASS_OPERATOR_GEOMETRY_PROJECTION",
        "depends_on": "R104, R109, R110",
        "open_boundary": "dynamic PDE projection and physical spectrum remain open",
    },
])

# ---------------------------------------------------------------------
# 2. Formula audit across denominator cutoffs.
# ---------------------------------------------------------------------

formula_rows = []
for max_den in DENOM_AUDITS:
    domain, boundary = close_domain(ANCHORS, max_den)
    selected = species_projection(domain, max_den, binary=True, slot=True, cap=4, logic="and")

    formula_rows.append({
        "max_den": max_den,
        "support_domain_count": len(domain),
        "selected_species_count": len(selected),
        "selected_species": label_set(selected),
        "exact_seed": selected == SEED,
        "extra_vs_seed": label_set(selected - SEED),
        "missing_from_seed": label_set(SEED - selected),
        "boundary_used": boundary,
    })

operator_formula_audit = pd.DataFrame(formula_rows)

formula_exact_all = bool(operator_formula_audit["exact_seed"].all())

# ---------------------------------------------------------------------
# 3. Selected seed / virtual support audit.
# ---------------------------------------------------------------------

seed_rows = []
for x in sorted(SEED):
    r = R_map(x)
    c = C_map(x)
    seed_rows.append({
        "rho": frac_label(x),
        "float": float(x),
        "denominator": x.denominator,
        "in_support_domain": x in domain_full,
        "binary_accept": binary_accept(x),
        "slot_accept": slot_accept(x),
        "species_accept": x in stable_full,
        "R_partner": frac_label(r),
        "R_partner_role": role_of(r, domain_full, stable_full),
        "C_partner": frac_label(c),
        "C_partner_role": role_of(c, domain_full, stable_full),
        "uses_virtual_support": (
            role_of(r, domain_full, stable_full) == "support_only"
            or role_of(c, domain_full, stable_full) == "support_only"
        ),
    })

selected_seed_audit = pd.DataFrame(seed_rows)

virtual_rows = []
for x in sorted(VIRTUAL_SUPPORTS):
    virtual_rows.append({
        "rho": frac_label(x),
        "float": float(x),
        "denominator": x.denominator,
        "in_support_domain": x in domain_full,
        "binary_accept": binary_accept(x),
        "slot_accept": slot_accept(x),
        "species_accept": x in stable_full,
        "rejection_reason": (
            "fails_binary_no_overlap"
            if not binary_accept(x)
            else (
                "fails_slot_capacity"
                if not slot_accept(x)
                else "none"
            )
        ),
        "R_partner": frac_label(R_map(x)),
        "C_partner": frac_label(C_map(x)),
    })

virtual_support_audit = pd.DataFrame(virtual_rows)

virtuals_support_active_not_species = bool(
    all(row["in_support_domain"] and not row["species_accept"] for _, row in virtual_support_audit.iterrows())
)

five_thirds_virtual_dependency = bool(
    selected_seed_audit[selected_seed_audit["rho"] == "5/3"].iloc[0]["uses_virtual_support"]
)

five_fourths_virtual_dependency = bool(
    selected_seed_audit[selected_seed_audit["rho"] == "5/4"].iloc[0]["uses_virtual_support"]
)

stable_virtual_dependency_pass = five_thirds_virtual_dependency and five_fourths_virtual_dependency

# ---------------------------------------------------------------------
# 4. Control failure rollup.
# ---------------------------------------------------------------------

control_specs = []

# Anchor controls.
for label, anchors, expected in [
    ("full_anchor_set", ANCHORS, "PASS"),
    ("remove_identity_anchor", {Fraction(1,2), Fraction(1,3)}, "FAIL"),
    ("remove_binary_anchor", {Fraction(1,1), Fraction(1,3)}, "FAIL"),
    ("remove_trinormal_anchor", {Fraction(1,1), Fraction(1,2)}, "FAIL"),
    ("replace_trinormal_with_quarter", {Fraction(1,1), Fraction(1,2), Fraction(1,4)}, "FAIL"),
]:
    domain, boundary = close_domain(anchors, max(DENOM_AUDITS))
    selected = species_projection(domain, max(DENOM_AUDITS), binary=True, slot=True, cap=4, logic="and")
    control_specs.append({
        "control": label,
        "category": "anchor_set",
        "selected_count": len(selected),
        "selected": label_set(selected),
        "exact_seed": selected == SEED,
        "extra_vs_seed": label_set(selected - SEED),
        "missing_from_seed": label_set(SEED - selected),
        "expected": expected,
    })

# Map controls.
for label, T, A, expected in [
    ("canonical_R2_C1", Fraction(2,1), Fraction(1,1), "PASS"),
    ("wrong_R_total_3_2", Fraction(3,2), Fraction(1,1), "FAIL"),
    ("wrong_R_total_5_2", Fraction(5,2), Fraction(1,1), "FAIL"),
    ("wrong_C_product_2_3", Fraction(2,1), Fraction(2,3), "FAIL"),
    ("wrong_C_product_3_2", Fraction(2,1), Fraction(3,2), "FAIL"),
]:
    domain, boundary = close_domain(ANCHORS, max(DENOM_AUDITS), T=T, A=A)
    selected = species_projection(domain, max(DENOM_AUDITS), binary=True, slot=True, cap=4, logic="and")
    control_specs.append({
        "control": label,
        "category": "R_C_maps",
        "selected_count": len(selected),
        "selected": label_set(selected),
        "exact_seed": selected == SEED,
        "extra_vs_seed": label_set(selected - SEED),
        "missing_from_seed": label_set(SEED - selected),
        "expected": expected,
    })

# Projection controls.
projection_controls = [
    ("support_only", True, True, 4, "none", "FAIL"),
    ("support_binary_no_slot", True, False, None, "and", "FAIL"),
    ("support_slot_no_binary", False, True, 4, "and", "FAIL"),
    ("support_binary_or_slot", True, True, 4, "or", "FAIL"),
    ("canonical_support_binary_slot", True, True, 4, "and", "PASS"),
]
for label, use_binary, use_slot, cap, logic, expected in projection_controls:
    if label == "support_only":
        selected = set(domain_full)
    else:
        selected = species_projection(
            domain_full,
            max(DENOM_AUDITS),
            binary=use_binary,
            slot=use_slot,
            cap=cap if cap is not None else 10**6,
            logic=logic,
        )
    control_specs.append({
        "control": label,
        "category": "projection_logic",
        "selected_count": len(selected),
        "selected": label_set(selected),
        "exact_seed": selected == SEED,
        "extra_vs_seed": label_set(selected - SEED),
        "missing_from_seed": label_set(SEED - selected),
        "expected": expected,
    })

# Geometry/capacity controls.
for label, cap, expected in [
    ("slot_cap_3_too_strict", 3, "FAIL"),
    ("slot_cap_4_canonical", 4, "PASS"),
    ("slot_cap_5_too_loose", 5, "FAIL"),
    ("slot_cap_none", 10**6, "FAIL"),
]:
    selected = species_projection(domain_full, max(DENOM_AUDITS), binary=True, slot=True, cap=cap, logic="and")
    control_specs.append({
        "control": label,
        "category": "slot_capacity",
        "selected_count": len(selected),
        "selected": label_set(selected),
        "exact_seed": selected == SEED,
        "extra_vs_seed": label_set(selected - SEED),
        "missing_from_seed": label_set(SEED - selected),
        "expected": expected,
    })

# Smuggling controls.
control_specs.append({
    "control": "manual_seed_lookup",
    "category": "no_smuggling",
    "selected_count": len(SEED),
    "selected": label_set(SEED),
    "exact_seed": True,
    "extra_vs_seed": "none",
    "missing_from_seed": "none",
    "expected": "REJECT",
})
control_specs.append({
    "control": "manual_delete_named_virtuals",
    "category": "no_smuggling",
    "selected_count": len(domain_full - VIRTUAL_SUPPORTS),
    "selected": label_set(domain_full - VIRTUAL_SUPPORTS),
    "exact_seed": (domain_full - VIRTUAL_SUPPORTS) == SEED,
    "extra_vs_seed": label_set((domain_full - VIRTUAL_SUPPORTS) - SEED),
    "missing_from_seed": label_set(SEED - (domain_full - VIRTUAL_SUPPORTS)),
    "expected": "REJECT",
})

control_failure_rollup = pd.DataFrame(control_specs)

def control_status(row):
    if row["expected"] == "PASS" and row["exact_seed"]:
        return "PASS_CANONICAL_EXACT"
    if row["expected"] == "FAIL" and not row["exact_seed"]:
        return "PASS_CONTROL_FAILED_AS_EXPECTED"
    if row["expected"] == "REJECT":
        return "PASS_REJECTED_EVEN_IF_EXACT" if row["exact_seed"] else "PASS_REJECTED_SMUGGLING_OR_MANUAL_RULE"
    if row["expected"] == "FAIL" and row["exact_seed"]:
        return "UNEXPECTED_EXACT_CONTROL"
    if row["expected"] == "PASS" and not row["exact_seed"]:
        return "CANONICAL_FAILED"
    return "UNKNOWN"

control_failure_rollup["control_status"] = control_failure_rollup.apply(control_status, axis=1)

canonical_controls_pass = bool(
    control_failure_rollup[
        control_failure_rollup["expected"] == "PASS"
    ]["control_status"].eq("PASS_CANONICAL_EXACT").all()
)

failure_controls_fail = bool(
    control_failure_rollup[
        control_failure_rollup["expected"] == "FAIL"
    ]["control_status"].eq("PASS_CONTROL_FAILED_AS_EXPECTED").all()
)

smuggling_controls_rejected = bool(
    control_failure_rollup[
        control_failure_rollup["expected"] == "REJECT"
    ]["control_status"].str.startswith("PASS_REJECTED").all()
)

# ---------------------------------------------------------------------
# 5. Dependency graph.
# ---------------------------------------------------------------------

dependency_edges = pd.DataFrame([
    {"source": "identity/base cadence", "target": "anchor 1", "edge_type": "origin"},
    {"source": "binary no-overwrite record", "target": "anchor 1/2", "edge_type": "origin"},
    {"source": "tri-normal virtual support", "target": "anchor 1/3", "edge_type": "origin"},
    {"source": "anchor set {1,1/2,1/3}", "target": "D_RC support domain", "edge_type": "generates"},
    {"source": "R(rho)=2-rho", "target": "D_RC support domain", "edge_type": "closure_map"},
    {"source": "C(rho)=1/rho", "target": "D_RC support domain", "edge_type": "closure_map"},
    {"source": "R107 auxiliary variation", "target": "R/C maps", "edge_type": "variational_support"},
    {"source": "R108 local covariance", "target": "action blueprint admissibility", "edge_type": "guardrail"},
    {"source": "binary KKT no-overlap", "target": "rho>=1/2", "edge_type": "species_filter"},
    {"source": "3+1 worldline-tube geometry", "target": "D_perp=3", "edge_type": "conditional_geometry"},
    {"source": "D_perp=3", "target": "anchor 1/3", "edge_type": "support_anchor"},
    {"source": "1 tangent + 3 normals", "target": "denom(rho)<=4", "edge_type": "slot_filter"},
    {"source": "D_RC support domain", "target": "support-to-species projection", "edge_type": "input"},
    {"source": "rho>=1/2", "target": "support-to-species projection", "edge_type": "input"},
    {"source": "denom(rho)<=4", "target": "support-to-species projection", "edge_type": "input"},
    {"source": "support-to-species projection", "target": "nine-mode mechanical seed", "edge_type": "selects"},
    {"source": "virtual supports {1/3,3/5,4/5}", "target": "closure support without species", "edge_type": "separation"},
])

# ---------------------------------------------------------------------
# 6. Open problem register and claim boundary.
# ---------------------------------------------------------------------

open_problem_register = pd.DataFrame([
    {
        "open_item": "primitive-anchor field origin",
        "status": "OPEN / CANDIDATE ONLY",
        "what_is_closed": "minimal exact operator anchor set and geometric/operator motivations",
        "what_is_not_closed": "derivation from a completed field/PDE theory",
    },
    {
        "open_item": "K=2 deeper origin",
        "status": "INHERITED",
        "what_is_closed": "given binary record width w=1/2, KKT gives rho>=1/2",
        "what_is_not_closed": "new derivation of K=2 from smooth PDE or deeper ontology",
    },
    {
        "open_item": "3+1 spacetime origin",
        "status": "INHERITED",
        "what_is_closed": "given 3+1 and 1D worldline, D_perp=3 and slot cap 4",
        "what_is_not_closed": "why spacetime is 3+1 from first principles",
    },
    {
        "open_item": "dynamic PDE projection flow",
        "status": "OPEN",
        "what_is_closed": "logical/operator-geometric projection Species=Support∩Binary∩Slot",
        "what_is_not_closed": "Euler-Lagrange or PDE flow deriving the projection dynamically",
    },
    {
        "open_item": "full local action/PDE implementation",
        "status": "OPEN",
        "what_is_closed": "candidate local covariant blueprint and R/C auxiliary variation",
        "what_is_not_closed": "complete field equations with all constraints derived",
    },
    {
        "open_item": "physical particle spectrum",
        "status": "OPEN",
        "what_is_closed": "nine-mode mechanical/operator-geometric seed",
        "what_is_not_closed": "confirmed Standard Model spectrum or physical species mapping",
    },
    {
        "open_item": "masses / SM matching / Omega0",
        "status": "OPEN",
        "what_is_closed": "none in R112",
        "what_is_not_closed": "mass hierarchy, electroweak values, Standard Model parameter matching, Omega0",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R112 closes the V12.8 operator-to-geometry theorem stack.",
        "status": "YES",
        "reason": "R100-R111 combine into a no-smuggling support/projection formula selecting the exact mechanical seed.",
    },
    {
        "claim": "The selected seed is exactly nine modes.",
        "status": "YES",
        "reason": "D_RC({1,1/2,1/3}) ∩ {rho>=1/2} ∩ {denom(rho)<=4} selects exactly nine modes across denominator audits.",
    },
    {
        "claim": "Virtual support modes are manually deleted.",
        "status": "NO",
        "reason": "1/3 fails binary; 3/5 and 4/5 fail slot capacity; they remain support-active but species-inactive.",
    },
    {
        "claim": "The stack uses seed lookup or polynomial root fitting.",
        "status": "NO",
        "reason": "Lookup/root/oracle/manual deletion controls are rejected.",
    },
    {
        "claim": "R112 closes full PDE/action dynamics.",
        "status": "NO",
        "reason": "The stack is operator/geometric with partial variational support, not a complete PDE theory.",
    },
    {
        "claim": "R112 derives K=2 from scratch.",
        "status": "NO",
        "reason": "K=2 remains inherited from the binary predicate/no-overwrite stack.",
    },
    {
        "claim": "R112 derives why spacetime is 3+1.",
        "status": "NO",
        "reason": "3+1 is an inherited physical/geometric premise.",
    },
    {
        "claim": "The nine-mode seed is a confirmed physical particle spectrum.",
        "status": "NO",
        "reason": "It remains a mechanical/operator-geometric seed.",
    },
    {
        "claim": "Masses, Standard Model matching, or Omega0 are derived.",
        "status": "NO",
        "reason": "R112 does not address physical parameter matching.",
    },
])

paper_insert_language = """# V12.8 Safe Paper Insert Language

## Safe theorem-stack statement

The V12.8 audit closes an operator/geometric route from the primitive support anchors
{1, 1/2, 1/3}, together with the reflection and reciprocal closure maps

R(rho)=2-rho,     C(rho)=1/rho,

to the nine-mode mechanical seed

{1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}

by applying the species projection

rho in D_RC({1,1/2,1/3}), rho >= 1/2, denom(rho) <= 4.

## Safe interpretation

The result is an operator/geometric support-to-species selection theorem.
It is not yet a confirmed physical particle spectrum.

## Required boundary language

- The binary threshold rho>=1/2 is obtained as a discrete KKT no-overlap condition conditional on binary record width w=1/2.
- The denominator cap denom(rho)<=4 is obtained conditionally from a 1D worldline in inherited 3+1 spacetime.
- The projection is closed logically/operator-geometrically, not as a full PDE flow.
- The primitive anchors have operator/geometric motivations, but the complete field/PDE origin remains open.
- Masses, Standard Model matching, Omega0, and physical spectrum identification remain future work.

## Prohibited upgrade

Do not state that V12.8 derives the Standard Model particle spectrum.
Do not state that V12.8 derives masses or electroweak parameters.
Do not state that V12.8 closes the full PDE/action theory.
"""

(OUT / "FORCE_R112_safe_paper_insert_language.md").write_text(paper_insert_language, encoding="utf-8")

# ---------------------------------------------------------------------
# 7. Final verdict.
# ---------------------------------------------------------------------

operator_geometric_stack_closed = bool(
    formula_exact_all
    and stable_full == SEED
    and virtuals_support_active_not_species
    and stable_virtual_dependency_pass
    and canonical_controls_pass
    and failure_controls_fail
    and smuggling_controls_rejected
)

full_PDE_closed = False
physical_spectrum_claimed = False
masses_SM_Omega0_derived = False
K2_origin_derived_from_scratch = False
spacetime_3plus1_origin_derived = False

if (
    operator_geometric_stack_closed
    and not full_PDE_closed
    and not physical_spectrum_claimed
    and not masses_SM_Omega0_derived
    and not K2_origin_derived_from_scratch
    and not spacetime_3plus1_origin_derived
):
    verdict_status = "V12.8 OPERATOR-TO-GEOMETRY THEOREM STACK PASS / PDE, PHYSICAL SPECTRUM, MASSES, SM MATCHING, OMEGA0 OPEN"
else:
    verdict_status = "V12.8 OPERATOR-TO-GEOMETRY ROLLUP INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "formula_exact_all",
        "result": "PASS" if formula_exact_all else "WARN",
        "interpretation": "The canonical formula selects the exact nine-mode seed across denominator audits.",
    },
    {
        "test": "virtuals_support_active_not_species",
        "result": "PASS" if virtuals_support_active_not_species else "WARN",
        "interpretation": "1/3, 3/5, and 4/5 remain support-active but species-inactive.",
    },
    {
        "test": "stable_virtual_dependency_pass",
        "result": "PASS" if stable_virtual_dependency_pass else "WARN",
        "interpretation": "Stable modes 5/3 and 5/4 can depend on virtual support channels.",
    },
    {
        "test": "canonical_controls_pass",
        "result": "PASS" if canonical_controls_pass else "WARN",
        "interpretation": "Canonical full-anchor/map/projection/cap controls are exact.",
    },
    {
        "test": "failure_controls_fail",
        "result": "PASS" if failure_controls_fail else "WARN",
        "interpretation": "Removed anchors, wrong maps, wrong projection logic, and wrong caps fail.",
    },
    {
        "test": "smuggling_controls_rejected",
        "result": "PASS" if smuggling_controls_rejected else "WARN",
        "interpretation": "Seed lookup and manual deletion routes are rejected.",
    },
    {
        "test": "operator_geometric_stack_closed",
        "result": "PASS" if operator_geometric_stack_closed else "WARN",
        "interpretation": "The R100-R111 operator/geometric theorem stack is internally closed.",
    },
    {
        "test": "full_PDE_closed",
        "result": "OPEN",
        "interpretation": "R112 does not close full PDE/action dynamics.",
    },
    {
        "test": "physical_spectrum_claimed",
        "result": "OPEN",
        "interpretation": "R112 does not claim a confirmed physical particle spectrum.",
    },
    {
        "test": "masses_SM_Omega0_derived",
        "result": "OPEN",
        "interpretation": "R112 does not derive masses, SM matching, or Omega0.",
    },
])

# ---------------------------------------------------------------------
# Save artifacts.
# ---------------------------------------------------------------------

theorem_stack.to_csv(OUT / "FORCE_R112_theorem_stack_rollup.csv", index=False)
operator_formula_audit.to_csv(OUT / "FORCE_R112_operator_formula_audit.csv", index=False)
selected_seed_audit.to_csv(OUT / "FORCE_R112_selected_seed_audit.csv", index=False)
virtual_support_audit.to_csv(OUT / "FORCE_R112_virtual_support_audit.csv", index=False)
control_failure_rollup.to_csv(OUT / "FORCE_R112_control_failure_rollup.csv", index=False)
dependency_edges.to_csv(OUT / "FORCE_R112_dependency_graph_edges.csv", index=False)
open_problem_register.to_csv(OUT / "FORCE_R112_open_problem_register.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R112_claim_boundary_matrix.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R112_gate_audit.csv", index=False)

verdict = {
    "force_id": "FORCE_R112",
    "title": "V12.8 Operator-to-Geometry Rollup Gate",
    "status": verdict_status,
    "operator_geometric_stack_closed": operator_geometric_stack_closed,
    "formula_exact_all": formula_exact_all,
    "selected_seed": [frac_label(x) for x in sorted(stable_full)],
    "virtuals_support_active_not_species": virtuals_support_active_not_species,
    "stable_virtual_dependency_pass": stable_virtual_dependency_pass,
    "canonical_controls_pass": canonical_controls_pass,
    "failure_controls_fail": failure_controls_fail,
    "smuggling_controls_rejected": smuggling_controls_rejected,
    "full_PDE_closed": full_PDE_closed,
    "physical_spectrum_claimed": physical_spectrum_claimed,
    "masses_SM_Omega0_derived": masses_SM_Omega0_derived,
    "K2_origin_derived_from_scratch": K2_origin_derived_from_scratch,
    "spacetime_3plus1_origin_derived": spacetime_3plus1_origin_derived,
    "recommended_next": "FORCE_R113_V12_8_prewrite_claim_boundary_paper_insertion_gate",
}
(OUT / "FORCE_R112_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R112 — V12.8 Operator-to-Geometry Rollup Gate

## Verdict

BOXED: {verdict_status}

## Canonical V12.8 formula

BOXED:
rho ∈ D_RC({{1,1/2,1/3}})

BOXED:
rho >= 1/2

BOXED:
denom(rho) <= 4

Therefore:

BOXED:
Species = D_RC({{1,1/2,1/3}}) ∩ {{rho>=1/2}} ∩ {{denom(rho)<=4}}

## Selected mechanical seed

BOXED:
{label_set(stable_full)}

## Closed at R112

BOXED:
The V12.8 operator/geometric theorem stack is internally closed.

## Not closed at R112

BOXED:
Full PDE/action dynamics remain open.

BOXED:
Physical particle-spectrum identification remains open.

BOXED:
Masses, Standard Model matching, and Omega0 remain open.

BOXED:
K=2 deeper origin remains inherited.

BOXED:
3+1 spacetime origin remains inherited.

## Key booleans

- operator_geometric_stack_closed: {operator_geometric_stack_closed}
- formula_exact_all: {formula_exact_all}
- virtuals_support_active_not_species: {virtuals_support_active_not_species}
- stable_virtual_dependency_pass: {stable_virtual_dependency_pass}
- canonical_controls_pass: {canonical_controls_pass}
- failure_controls_fail: {failure_controls_fail}
- smuggling_controls_rejected: {smuggling_controls_rejected}
- full_PDE_closed: {full_PDE_closed}
- physical_spectrum_claimed: {physical_spectrum_claimed}
- masses_SM_Omega0_derived: {masses_SM_Omega0_derived}

## Gate audit

{audit_df.to_string(index=False)}

## Theorem stack rollup

{theorem_stack.to_string(index=False)}

## Operator formula audit

{operator_formula_audit.to_string(index=False)}

## Selected seed audit

{selected_seed_audit.to_string(index=False)}

## Virtual support audit

{virtual_support_audit.to_string(index=False)}

## Control failure rollup

{control_failure_rollup.to_string(index=False)}

## Dependency graph edges

{dependency_edges.to_string(index=False)}

## Open problem register

{open_problem_register.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Recommended next

BOXED: FORCE_R113 — V12.8 Prewrite Claim-Boundary / Paper-Insertion Gate
"""
(OUT / "FORCE_R112_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R112_V12_8_operator_to_geometry_rollup_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R112_summary.md", "role": "summary"},
    {"file": "FORCE_R112_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R112_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R112_theorem_stack_rollup.csv", "role": "R100-R111 theorem stack rollup"},
    {"file": "FORCE_R112_operator_formula_audit.csv", "role": "formula exactness audit"},
    {"file": "FORCE_R112_selected_seed_audit.csv", "role": "selected seed audit"},
    {"file": "FORCE_R112_virtual_support_audit.csv", "role": "virtual support audit"},
    {"file": "FORCE_R112_control_failure_rollup.csv", "role": "control failure rollup"},
    {"file": "FORCE_R112_dependency_graph_edges.csv", "role": "dependency graph edge list"},
    {"file": "FORCE_R112_open_problem_register.csv", "role": "open problem register"},
    {"file": "FORCE_R112_claim_boundary_matrix.csv", "role": "claim boundary matrix"},
    {"file": "FORCE_R112_safe_paper_insert_language.md", "role": "safe paper insert language"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(8, 5))
plt.bar(operator_formula_audit["max_den"].astype(str), operator_formula_audit["selected_species_count"])
plt.axhline(len(SEED), linestyle="--")
plt.xlabel("max denominator audit")
plt.ylabel("selected species count")
plt.title("R112 canonical formula selected count")
plt.tight_layout()
plt.savefig(PLOTS / "canonical_formula_selected_count.png", dpi=160)
plt.close()

status_counts = control_failure_rollup["control_status"].value_counts()
plt.figure(figsize=(10, 5))
plt.bar(status_counts.index, status_counts.values)
plt.xticks(rotation=35, ha="right")
plt.ylabel("count")
plt.title("R112 control status counts")
plt.tight_layout()
plt.savefig(PLOTS / "control_status_counts.png", dpi=160)
plt.close()

gate_status_counts = theorem_stack["status"].value_counts()
plt.figure(figsize=(10, 5))
plt.bar(gate_status_counts.index, gate_status_counts.values)
plt.xticks(rotation=35, ha="right")
plt.ylabel("count")
plt.title("R112 theorem stack status counts")
plt.tight_layout()
plt.savefig(PLOTS / "theorem_stack_status_counts.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

compact_controls = control_failure_rollup[[
    "control",
    "category",
    "selected_count",
    "exact_seed",
    "extra_vs_seed",
    "missing_from_seed",
    "expected",
    "control_status",
]]

print("\n=== COPY/PASTE R112 RESULT ===")
print("R112 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"operator_geometric_stack_closed: {operator_geometric_stack_closed}")
print(f"formula_exact_all: {formula_exact_all}")
print(f"selected_seed: {label_set(stable_full)}")
print(f"virtuals_support_active_not_species: {virtuals_support_active_not_species}")
print(f"stable_virtual_dependency_pass: {stable_virtual_dependency_pass}")
print(f"canonical_controls_pass: {canonical_controls_pass}")
print(f"failure_controls_fail: {failure_controls_fail}")
print(f"smuggling_controls_rejected: {smuggling_controls_rejected}")
print(f"full_PDE_closed: {full_PDE_closed}")
print(f"physical_spectrum_claimed: {physical_spectrum_claimed}")
print(f"masses_SM_Omega0_derived: {masses_SM_Omega0_derived}")
print(f"K2_origin_derived_from_scratch: {K2_origin_derived_from_scratch}")
print(f"spacetime_3plus1_origin_derived: {spacetime_3plus1_origin_derived}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("THEOREM_STACK_ROLLUP:")
print(theorem_stack.to_string(index=False))
print("OPERATOR_FORMULA_AUDIT:")
print(operator_formula_audit.to_string(index=False))
print("SELECTED_SEED_AUDIT:")
print(selected_seed_audit.to_string(index=False))
print("VIRTUAL_SUPPORT_AUDIT:")
print(virtual_support_audit.to_string(index=False))
print("CONTROL_FAILURE_ROLLUP:")
print(compact_controls.to_string(index=False))
print("OPEN_PROBLEM_REGISTER:")
print(open_problem_register.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R112_summary.md').resolve()}")
print("NEXT: FORCE_R113_V12_8_prewrite_claim_boundary_paper_insertion_gate")
print("=== END COPY/PASTE R112 RESULT ===\n")
