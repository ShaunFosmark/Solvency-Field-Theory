from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R101_trinormal_virtual_support_anchor_gate")
ZIP = Path("FORCE_R101_trinormal_virtual_support_anchor_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R101 — Tri-Normal Virtual Support Anchor Gate
#
# V12.7 froze:
#
#   stable candidate = membership in minimal joint R/C support domain
#                      + rho >= 1/2
#                      + denom(rho) <= 4
#
# with support domain generated from:
#
#   {1, 1/2, 1/3}
#
# R100 passed:
#
#   {1,1/2,1/3} = unique minimal tested primitive anchor set
#
# R101 question:
#
#   What exactly is 1/3?
#
# Candidate:
#
#   1/3 is not a stable species.
#   1/3 is a virtual support anchor supplied by the three transverse normal
#   directions of a worldline tube.
#
# Operator role:
#
#   R(5/3) = 2 - 5/3 = 1/3
#
# so the 5/3 seed mode needs the 1/3 channel as reflection/complement support.
#
# Species rejection:
#
#   1/3 fails binary no-overwrite:
#
#       rho = 1/3 < 1/2
#
# so it is support-active but species-inactive.
#
# Claim boundary:
# - This is still an operator/geometry-origin gate.
# - It does not derive the full local field/PDE/action.
# - It does not claim 1/3 is a particle.
# - It does not derive masses, Omega0, or confirmed physical spectrum.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

V127_ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def R_map(x):
    return Fraction(2, 1) - x

def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def close_domain(anchors, max_den, ops=("R", "C")):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(400):
        before = set(active)

        for x in list(active):
            if "R" in ops:
                y = R_map(x)
                if y == 0:
                    boundary_used = True
                elif in_interval(y) and y in universe:
                    active.add(y)

            if "C" in ops:
                y = C_map(x)
                if in_interval(y) and y in universe:
                    active.add(y)

        if active == before:
            break

    return active, boundary_used

def binary_accept(x):
    return x >= Fraction(1, 2)

def slot_accept(x):
    return x.denominator <= 4

def stable_by_domain(domain, max_den):
    universe = rational_universe(max_den)
    return {
        x for x in universe
        if binary_accept(x)
        and slot_accept(x)
        and x in domain
    }

def stable_from_anchors(anchors, max_den):
    domain, boundary_used = close_domain(anchors, max_den, ("R", "C"))
    stable = stable_by_domain(domain, max_den)
    return domain, stable, boundary_used

def partner_status(x, domain):
    r = R_map(x)
    c = C_map(x)
    return {
        "R_partner": "0_boundary" if r == 0 else frac_label(r),
        "R_supported": True if r == 0 else r in domain,
        "C_partner": frac_label(c) if c else "none",
        "C_supported": in_interval(c) and c in domain,
    }

# ---------------------------------------------------------------------
# 1. Normal-share scan.
# ---------------------------------------------------------------------

dimension_rows = []
intruder_rows = []
interval_rows = []

for D_perp in [1, 2, 3, 4, 5, 6, 7, 8]:
    normal_anchor = Fraction(1, D_perp)
    anchors = {Fraction(1, 1), Fraction(1, 2), normal_anchor}

    exact_all = True
    final_domain = set()
    final_stable = set()
    final_boundary_used = False

    for max_den in DENOM_AUDITS:
        domain, stable, boundary_used = stable_from_anchors(anchors, max_den)
        final_domain = domain
        final_stable = stable
        final_boundary_used = boundary_used

        if stable != SEED:
            exact_all = False

        interval_rows.append({
            "D_perp": D_perp,
            "normal_anchor": frac_label(normal_anchor),
            "anchor_set": label_set(anchors),
            "max_den": max_den,
            "support_domain_count": len(domain),
            "stable_count": len(stable),
            "stable_fractions": label_set(stable),
            "exact_seed": stable == SEED,
            "extra_vs_seed": label_set(stable - SEED),
            "missing_from_seed": label_set(SEED - stable),
            "boundary_used": boundary_used,
        })

    extras = final_stable - SEED
    missing = SEED - final_stable

    for x in sorted(extras):
        ps = partner_status(x, final_domain)
        intruder_rows.append({
            "model": f"D_perp_{D_perp}",
            "fraction": frac_label(x),
            "rho": float(x),
            "denominator": x.denominator,
            "R_partner": ps["R_partner"],
            "C_partner": ps["C_partner"],
            "reason": "admitted_beyond_seed",
        })

    for x in sorted(missing):
        ps = partner_status(x, final_domain)
        intruder_rows.append({
            "model": f"D_perp_{D_perp}",
            "fraction": frac_label(x),
            "rho": float(x),
            "denominator": x.denominator,
            "R_partner": ps["R_partner"],
            "C_partner": ps["C_partner"],
            "reason": "seed_mode_rejected",
        })

    dimension_rows.append({
        "D_perp": D_perp,
        "normal_anchor": frac_label(normal_anchor),
        "anchor_set": label_set(anchors),
        "normal_share_total": float(D_perp * normal_anchor),
        "support_domain_count_final": len(final_domain),
        "stable_count_final": len(final_stable),
        "stable_fractions_final": label_set(final_stable),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(extras),
        "missing_from_seed": label_set(missing),
        "boundary_used_final": final_boundary_used,
    })

dimension_scan = pd.DataFrame(dimension_rows)
interval_audit = pd.DataFrame(interval_rows)
intruder_audit = pd.DataFrame(intruder_rows)

exact_Ds = dimension_scan[dimension_scan["exact_seed_all_denominators"] == True]["D_perp"].tolist()
trinormal_D3_unique = exact_Ds == [3]

# ---------------------------------------------------------------------
# 2. Virtual support vs stable species audit.
# ---------------------------------------------------------------------

candidate_domain, _ = close_domain(V127_ANCHORS, max(DENOM_AUDITS), ("R", "C"))
candidate_stable = stable_by_domain(candidate_domain, max(DENOM_AUDITS))

test_modes = [
    Fraction(1, 4), Fraction(1, 3), Fraction(1, 2),
    Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2),
    Fraction(5, 3), Fraction(7, 4), Fraction(2, 1)
]

truth_rows = []
for x in test_modes:
    ps = partner_status(x, candidate_domain)
    truth_rows.append({
        "rho_fraction": frac_label(x),
        "rho": float(x),
        "denominator": x.denominator,
        "in_joint_domain": x in candidate_domain,
        "is_primitive_anchor": x in V127_ANCHORS,
        "binary_accept": binary_accept(x),
        "slot_accept": slot_accept(x),
        "stable_candidate": x in candidate_stable,
        "R_partner": ps["R_partner"],
        "R_supported": ps["R_supported"],
        "C_partner": ps["C_partner"],
        "C_supported": ps["C_supported"],
        "role": (
            "stable_seed"
            if x in candidate_stable
            else (
                "virtual_support_anchor"
                if x == Fraction(1, 3) and x in candidate_domain and not binary_accept(x)
                else (
                    "rejected_intruder"
                    if x == Fraction(7, 4)
                    else "support_or_rejected_control"
                )
            )
        ),
    })

support_truth_table = pd.DataFrame(truth_rows)

one_third_in_domain = Fraction(1, 3) in candidate_domain
one_third_binary_rejected = not binary_accept(Fraction(1, 3))
one_third_not_stable = Fraction(1, 3) not in candidate_stable
one_third_virtual_not_species = (
    one_third_in_domain and one_third_binary_rejected and one_third_not_stable
)

five_thirds_supported_by_one_third = (
    R_map(Fraction(5, 3)) == Fraction(1, 3)
    and Fraction(1, 3) in candidate_domain
    and Fraction(5, 3) in candidate_stable
)

# ---------------------------------------------------------------------
# 3. Omission / promotion controls.
# ---------------------------------------------------------------------

control_models = [
    {
        "model": "C0_full_virtual_1_3",
        "description": "Full V12.7 anchors; 1/3 allowed as support but not species.",
        "anchors": {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)},
        "promote_anchors": False,
        "expected": "PASS_EXACT_SEED",
    },
    {
        "model": "C1_omit_1_3",
        "description": "Remove tri-normal virtual support anchor.",
        "anchors": {Fraction(1, 1), Fraction(1, 2)},
        "promote_anchors": False,
        "expected": "FAIL_MISSING_5_3",
    },
    {
        "model": "C2_replace_1_3_with_1_4",
        "description": "Four-normal replacement control.",
        "anchors": {Fraction(1, 1), Fraction(1, 2), Fraction(1, 4)},
        "promote_anchors": False,
        "expected": "FAIL_7_4_INTRUDER",
    },
    {
        "model": "C3_promote_1_3_to_species",
        "description": "Bad control: allow primitive anchors to bypass binary species filter.",
        "anchors": {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)},
        "promote_anchors": True,
        "expected": "FAIL_1_3_INTRUDER",
    },
]

control_rows = []

for model in control_models:
    exact_all = True
    final_domain = set()
    final_stable = set()

    for max_den in DENOM_AUDITS:
        domain, stable, _ = stable_from_anchors(model["anchors"], max_den)

        if model["promote_anchors"]:
            stable = set(stable) | set(model["anchors"])

        final_domain = domain
        final_stable = stable

        if final_stable != SEED:
            exact_all = False

    extras = final_stable - SEED
    missing = SEED - final_stable

    if exact_all and model["expected"].startswith("PASS"):
        survivor_status = "PASS_EXACT_SEED"
    elif (not exact_all) and model["expected"].startswith("FAIL"):
        survivor_status = "PASS_CONTROL_FAILED_AS_EXPECTED"
    elif exact_all and model["expected"].startswith("FAIL"):
        survivor_status = "UNEXPECTED_EXACT_SEED"
    else:
        survivor_status = "PARTIAL"

    control_rows.append({
        "model": model["model"],
        "description": model["description"],
        "anchor_set": label_set(model["anchors"]),
        "promote_anchors_to_species": model["promote_anchors"],
        "support_domain_count_final": len(final_domain),
        "stable_count_final": len(final_stable),
        "stable_fractions_final": label_set(final_stable),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(extras),
        "missing_from_seed": label_set(missing),
        "expected": model["expected"],
        "survivor_status": survivor_status,
    })

control_scorecard = pd.DataFrame(control_rows)

full_virtual_passes = (
    control_scorecard[
        control_scorecard["model"] == "C0_full_virtual_1_3"
    ].iloc[0]["survivor_status"] == "PASS_EXACT_SEED"
)

omit_1_3_fails = (
    control_scorecard[
        control_scorecard["model"] == "C1_omit_1_3"
    ].iloc[0]["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

replace_1_3_with_1_4_fails = (
    control_scorecard[
        control_scorecard["model"] == "C2_replace_1_3_with_1_4"
    ].iloc[0]["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

promote_1_3_to_species_fails = (
    control_scorecard[
        control_scorecard["model"] == "C3_promote_1_3_to_species"
    ].iloc[0]["survivor_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

# ---------------------------------------------------------------------
# 4. Verdict.
# ---------------------------------------------------------------------

if (
    trinormal_D3_unique
    and one_third_virtual_not_species
    and five_thirds_supported_by_one_third
    and full_virtual_passes
    and omit_1_3_fails
    and replace_1_3_with_1_4_fails
    and promote_1_3_to_species_fails
):
    verdict_status = "TRI-NORMAL VIRTUAL SUPPORT ANCHOR PASS / FIELD-BUNDLE DERIVATION STILL OPEN"
elif one_third_virtual_not_species and five_thirds_supported_by_one_third:
    verdict_status = "TRI-NORMAL SUPPORT ROLE SIGNAL PASS / SOME CONTROLS SURVIVE"
else:
    verdict_status = "TRI-NORMAL VIRTUAL SUPPORT ANCHOR INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "trinormal_D3_unique",
        "result": "PASS" if trinormal_D3_unique else "WARN",
        "interpretation": "Among tested normal dimensions, D_perp=3 is the unique exact normal-share anchor.",
    },
    {
        "test": "one_third_in_joint_domain",
        "result": "PASS" if one_third_in_domain else "WARN",
        "interpretation": "1/3 is present in the joint R/C support domain.",
    },
    {
        "test": "one_third_binary_rejected",
        "result": "PASS" if one_third_binary_rejected else "WARN",
        "interpretation": "1/3 fails rho>=1/2 and therefore fails the binary no-overlap species filter.",
    },
    {
        "test": "one_third_not_stable",
        "result": "PASS" if one_third_not_stable else "WARN",
        "interpretation": "1/3 is support-active but not a stable species candidate.",
    },
    {
        "test": "five_thirds_supported_by_one_third",
        "result": "PASS" if five_thirds_supported_by_one_third else "WARN",
        "interpretation": "5/3 needs 1/3 as its reflection/complement support because R(5/3)=1/3.",
    },
    {
        "test": "omit_1_3_fails",
        "result": "PASS" if omit_1_3_fails else "WARN",
        "interpretation": "Removing 1/3 loses 5/3 from the seed.",
    },
    {
        "test": "replace_1_3_with_1_4_fails",
        "result": "PASS" if replace_1_3_with_1_4_fails else "WARN",
        "interpretation": "Replacing 1/3 with 1/4 admits 7/4 and loses 5/3.",
    },
    {
        "test": "promote_1_3_to_species_fails",
        "result": "PASS" if promote_1_3_to_species_fails else "WARN",
        "interpretation": "Promoting 1/3 to species bypasses the binary no-overlap rule and creates a forbidden sub-half-turn species.",
    },
    {
        "test": "field_bundle_derivation",
        "result": "OPEN",
        "interpretation": "R101 supports the tri-normal interpretation at operator level; it is not yet a full field-bundle derivation.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "1/3 has an operator-level tri-normal virtual support interpretation.",
        "status": "YES",
        "reason": "D_perp=3 is the unique tested exact normal-share anchor and omission loses 5/3.",
    },
    {
        "claim": "1/3 is a stable species.",
        "status": "NO",
        "reason": "1/3 fails rho>=1/2 and is excluded by the binary no-overlap species filter.",
    },
    {
        "claim": "1/3 is required as support for 5/3.",
        "status": "YES",
        "reason": "R(5/3)=1/3, and removing 1/3 removes the 5/3 seed mode.",
    },
    {
        "claim": "A four-normal replacement works equally well.",
        "status": "NO",
        "reason": "1/4 admits 7/4 and loses 5/3.",
    },
    {
        "claim": "Virtual support channels may exist without being stable species.",
        "status": "YES",
        "reason": "1/3 is in the support domain but fails the species filter.",
    },
    {
        "claim": "The full local field-bundle origin of 1/3 is solved.",
        "status": "NO",
        "reason": "R101 is an operator-level gate; PDE/action implementation remains open.",
    },
])

theorem_candidate = pd.DataFrame([
    {
        "layer": 1,
        "statement": "A worldline tube has three transverse normal directions in 3+1 spacetime.",
        "status": "ASSUMED_GEOMETRIC_INPUT",
    },
    {
        "layer": 2,
        "statement": "Equal normal support share gives the virtual anchor 1/D_perp.",
        "status": "OPERATOR_MODEL",
    },
    {
        "layer": 3,
        "statement": "For D_perp=3, the virtual support anchor is 1/3.",
        "status": "PASS",
    },
    {
        "layer": 4,
        "statement": "1/3 supports 5/3 through R(5/3)=1/3.",
        "status": "PASS",
    },
    {
        "layer": 5,
        "statement": "1/3 is not a stable species because rho=1/3<1/2.",
        "status": "PASS",
    },
    {
        "layer": 6,
        "statement": "The field-bundle/PDE mechanism generating this support share remains open.",
        "status": "OPEN",
    },
])

# Save files.
dimension_scan.to_csv(OUT / "FORCE_R101_trinormal_dimension_scan.csv", index=False)
interval_audit.to_csv(OUT / "FORCE_R101_interval_audit.csv", index=False)
intruder_audit.to_csv(OUT / "FORCE_R101_intruder_and_missing_seed_audit.csv", index=False)
support_truth_table.to_csv(OUT / "FORCE_R101_support_truth_table.csv", index=False)
control_scorecard.to_csv(OUT / "FORCE_R101_virtual_vs_species_control_scorecard.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R101_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R101_claim_boundary_matrix.csv", index=False)
theorem_candidate.to_csv(OUT / "FORCE_R101_theorem_candidate.csv", index=False)

verdict = {
    "force_id": "FORCE_R101",
    "title": "Tri-Normal Virtual Support Anchor Gate",
    "status": verdict_status,
    "trinormal_D3_unique": trinormal_D3_unique,
    "one_third_in_domain": one_third_in_domain,
    "one_third_binary_rejected": one_third_binary_rejected,
    "one_third_not_stable": one_third_not_stable,
    "one_third_virtual_not_species": one_third_virtual_not_species,
    "five_thirds_supported_by_one_third": five_thirds_supported_by_one_third,
    "full_virtual_passes": full_virtual_passes,
    "omit_1_3_fails": omit_1_3_fails,
    "replace_1_3_with_1_4_fails": replace_1_3_with_1_4_fails,
    "promote_1_3_to_species_fails": promote_1_3_to_species_fails,
    "field_bundle_derivation_closed": False,
    "recommended_next": "FORCE_R102_reflection_complement_map_origin_gate",
}
(OUT / "FORCE_R101_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R101 — Tri-Normal Virtual Support Anchor Gate

## Verdict

BOXED: {verdict_status}

## Central result

R101 tests the meaning of the V12.7 primitive anchor 1/3.

BOXED: 1/3 is a virtual support anchor, not a stable species.

Operator role:

R(5/3)=2-5/3=1/3

Species rejection:

1/3 < 1/2, so it fails the binary no-overlap species filter.

## Key booleans

- trinormal_D3_unique: {trinormal_D3_unique}
- one_third_in_domain: {one_third_in_domain}
- one_third_binary_rejected: {one_third_binary_rejected}
- one_third_not_stable: {one_third_not_stable}
- five_thirds_supported_by_one_third: {five_thirds_supported_by_one_third}

## Gate audit

{audit_df.to_string(index=False)}

## Tri-normal dimension scan

{dimension_scan.to_string(index=False)}

## Virtual-vs-species controls

{control_scorecard.to_string(index=False)}

## Support truth table

{support_truth_table.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Theorem candidate

{theorem_candidate.to_string(index=False)}

## Remaining open item

R101 supports the tri-normal virtual-support interpretation at operator level.
It does not yet derive the full field-bundle/PDE implementation.

## Recommended next

BOXED: FORCE_R102 — Reflection Complement Map Origin Gate
"""
(OUT / "FORCE_R101_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R101_trinormal_virtual_support_anchor_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R101_summary.md", "role": "summary"},
    {"file": "FORCE_R101_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R101_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R101_trinormal_dimension_scan.csv", "role": "tri-normal dimension scan"},
    {"file": "FORCE_R101_interval_audit.csv", "role": "interval audit"},
    {"file": "FORCE_R101_intruder_and_missing_seed_audit.csv", "role": "intruder audit"},
    {"file": "FORCE_R101_support_truth_table.csv", "role": "support truth table"},
    {"file": "FORCE_R101_virtual_vs_species_control_scorecard.csv", "role": "virtual-vs-species controls"},
    {"file": "FORCE_R101_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R101_theorem_candidate.csv", "role": "theorem candidate"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(9, 5))
plt.bar(dimension_scan["D_perp"].astype(str), dimension_scan["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xlabel("D_perp")
plt.ylabel("final stable count")
plt.title("R101 normal-share scan: D_perp=3 exact")
plt.tight_layout()
plt.savefig(PLOTS / "trinormal_dimension_scan.png", dpi=160)
plt.close()

plt.figure(figsize=(11, 5))
plt.bar(control_scorecard["model"], control_scorecard["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xticks(rotation=30, ha="right")
plt.ylabel("final stable count")
plt.title("R101 virtual support vs stable species controls")
plt.tight_layout()
plt.savefig(PLOTS / "virtual_vs_species_controls.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

print("\n=== COPY/PASTE R101 RESULT ===")
print("R101 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"trinormal_D3_unique: {trinormal_D3_unique}")
print(f"one_third_in_domain: {one_third_in_domain}")
print(f"one_third_binary_rejected: {one_third_binary_rejected}")
print(f"one_third_not_stable: {one_third_not_stable}")
print(f"one_third_virtual_not_species: {one_third_virtual_not_species}")
print(f"five_thirds_supported_by_one_third: {five_thirds_supported_by_one_third}")
print(f"full_virtual_passes: {full_virtual_passes}")
print(f"omit_1_3_fails: {omit_1_3_fails}")
print(f"replace_1_3_with_1_4_fails: {replace_1_3_with_1_4_fails}")
print(f"promote_1_3_to_species_fails: {promote_1_3_to_species_fails}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("TRINORMAL_DIMENSION_SCAN:")
print(dimension_scan.to_string(index=False))
print("VIRTUAL_VS_SPECIES_CONTROL_SCORECARD:")
print(control_scorecard.to_string(index=False))
print("SUPPORT_TRUTH_TABLE:")
print(support_truth_table.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("INTRUDER_AND_MISSING_SEED_AUDIT:")
print(intruder_audit.to_string(index=False) if len(intruder_audit) else "none")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R101_summary.md').resolve()}")
print("NEXT: FORCE_R102_reflection_complement_map_origin_gate")
print("=== END COPY/PASTE R101 RESULT ===\n")
