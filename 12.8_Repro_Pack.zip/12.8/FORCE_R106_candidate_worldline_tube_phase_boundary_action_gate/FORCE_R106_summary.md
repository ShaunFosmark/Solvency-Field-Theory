# FORCE_R106 — Candidate Worldline-Tube Phase/Boundary Action Gate

## Verdict

BOXED: CANDIDATE WORLDLINE-TUBE PHASE/BOUNDARY ACTION BLUEPRINT PASS / VARIATIONAL PDE DERIVATION STILL OPEN

## Candidate action blueprint

BOXED:
S = S_phase + S_binary + S_normal + S_R + S_C + S_slot + S_split

where:

- S_phase supplies identity/base cadence.
- S_binary supplies binary no-overwrite and rho>=1/2.
- S_normal supplies three normal directions, 1/3 virtual support, and 1+3 slot capacity.
- S_R supplies R(rho)=2-rho.
- S_C supplies C(rho)=1/rho.
- S_slot supplies denom(rho)<=4.
- S_split separates support channels from stable species.

## Selected seed

BOXED: 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2

## Key booleans

- good_exact_seed: True
- good_no_smuggling: True
- good_local_variational: True
- good_derives_anchors: True
- good_derives_R: True
- good_derives_C: True
- good_derives_filters: True
- good_virtual_support_split: True
- good_excludes_intruders: True
- fake_exact_routes_rejected: True
- variation_closed: False
- PDE_closed: False

## Gate audit

                      test result                                                                                   interpretation
           good_exact_seed   PASS                     The candidate action blueprint reproduces the exact nine-mode operator seed.
         good_no_smuggling   PASS                The candidate does not use seed lookup, seed-root polynomial, or nonlocal oracle.
    good_local_variational   PASS                         The candidate has local fields and an action/constraint functional form.
      good_derives_anchors   PASS The candidate derives anchors {1,1/2,1/3} from phase, binary write, and tri-normal bundle terms.
            good_derives_R   PASS                          The candidate contains the complement constraint yielding R(rho)=2-rho.
            good_derives_C   PASS                      The candidate contains the cadence-return constraint yielding C(rho)=1/rho.
      good_derives_filters   PASS             The candidate derives rho>=1/2 and denom<=4 from binary write and 3+1 slot capacity.
good_virtual_support_split   PASS                                    1/3, 3/5, and 4/5 remain support-active but species-inactive.
   good_excludes_intruders   PASS                                                    The candidate excludes the main 7/4 intruder.
fake_exact_routes_rejected   PASS                                                 Exact but smuggled/nonlocal routes are rejected.
          variation_closed   OPEN              R106 defines stationarity targets but does not yet prove Euler-Lagrange derivation.
                PDE_closed   OPEN                                                      R106 is not a completed PDE implementation.

## Candidate action scorecard

                                             model                                                    description anchor_set_final  domain_count_final  stable_count_final                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   stable_fractions_final  exact_seed_all_denominators                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   extra_vs_seed                    missing_from_seed  target_seed_lookup  polynomial_seed_roots  global_nonlocal_oracle  local_fields  action_principle  derives_anchors  derives_R  derives_C  derives_filters  support_species_split  no_smuggling  local_variational  readiness_score                               expected                        survivor_status
A15_candidate_worldline_tube_phase_boundary_action No-smuggling coupled phase/binary/normal/R/C action blueprint.      1/3, 1/2, 1                  94                   9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none                                 none               False                  False                   False          True              True             True       True       True             True                   True          True               True               10                        PASS_EXACT_SEED PASS_EXACT_SEED_NO_SMUGGLING_BLUEPRINT
                          A13_all_rationals_domain                             Remove support-domain selectivity.      1/3, 1/2, 1                 648                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 7/4, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             7/4                                 none               False                  False                   False          True              True             True       True       True             True                   True          True               True                9                      FAIL_7_4_INTRUDER        PASS_CONTROL_FAILED_AS_EXPECTED
                    A14_promote_support_to_species                          Collapse support/species distinction.      1/3, 1/2, 1                  94                  94 1/3, 1/2, 3/5, 2/3, 5/7, 3/4, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 1, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 5/4, 9/7, 4/3, 7/5, 3/2, 5/3, 2                        False 1/3, 3/5, 5/7, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 9/7, 7/5                                 none               False                  False                   False          True              True             True       True       True             True                   True          True               True                9 FAIL_VIRTUAL_SUPPORT_SPECIES_INTRUDERS        PASS_CONTROL_FAILED_AS_EXPECTED
                                A6_no_R_complement                 Full local structure but no R complement term.      1/3, 1/2, 1                   4                   3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                1/2, 1, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none         2/3, 3/4, 5/4, 4/3, 3/2, 5/3               False                  False                   False          True              True             True      False       True             True                   True          True               True                8                         FAIL_MISSING_R        PASS_CONTROL_FAILED_AS_EXPECTED
                                    A7_no_C_return             Full local structure but no C cadence-return term.      1/3, 1/2, 1                   5                   4                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         1/2, 1, 3/2, 5/3                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none                2/3, 3/4, 5/4, 4/3, 2               False                  False                   False          True              True             True       True      False             True                   True          True               True                8                         FAIL_MISSING_C        PASS_CONTROL_FAILED_AS_EXPECTED
                              A8_wrong_R_total_3_2                             Wrong R constraint: rho+rho_R=3/2.      1/3, 1/2, 1                   8                   3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                1/2, 1, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none         2/3, 3/4, 5/4, 4/3, 3/2, 5/3               False                  False                   False          True              True             True      False       True             True                   True          True               True                8                           FAIL_WRONG_R        PASS_CONTROL_FAILED_AS_EXPECTED
                            A9_wrong_C_product_2_3                             Wrong C constraint: rho*rho_C=2/3.      1/3, 1/2, 1                  18                   7                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1/2, 2/3, 1, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none                             3/4, 5/4               False                  False                   False          True              True             True       True      False             True                   True          True               True                8                           FAIL_WRONG_C        PASS_CONTROL_FAILED_AS_EXPECTED
                      A11_no_binary_species_filter         Keep binary anchor but remove rho>=1/2 species filter.      1/3, 1/2, 1                  94                  10                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1/3, 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1/3                                 none               False                  False                   False          True              True             True       True       True            False                   True          True               True                8                  FAIL_SUBHALF_INTRUDER        PASS_CONTROL_FAILED_AS_EXPECTED
                        A12_no_slot_species_filter         Keep normal bundle but remove denom<=4 species filter.      1/3, 1/2, 1                  94                  93      1/2, 3/5, 2/3, 5/7, 3/4, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 1, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 5/4, 9/7, 4/3, 7/5, 3/2, 5/3, 2                        False      3/5, 5/7, 7/9, 4/5, 9/11, 5/6, 11/13, 6/7, 13/15, 7/8, 15/17, 8/9, 17/19, 9/10, 19/21, 10/11, 21/23, 11/12, 23/25, 12/13, 25/27, 13/14, 27/29, 14/15, 29/31, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 33/31, 16/15, 31/29, 15/14, 29/27, 14/13, 27/25, 13/12, 25/23, 12/11, 23/21, 11/10, 21/19, 10/9, 19/17, 9/8, 17/15, 8/7, 15/13, 7/6, 13/11, 6/5, 11/9, 9/7, 7/5                                 none               False                  False                   False          True              True             True       True       True            False                   True          True               True                8                   FAIL_DENOM_INTRUDERS        PASS_CONTROL_FAILED_AS_EXPECTED
                         A4_binary_only_plus_phase                     Phase plus binary write, no normal bundle.           1/2, 1                  64                  64                                                                                                                                                                                                   1/2, 2/3, 3/4, 4/5, 5/6, 6/7, 7/8, 8/9, 9/10, 10/11, 11/12, 12/13, 13/14, 14/15, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 1, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 16/15, 15/14, 14/13, 13/12, 12/11, 11/10, 10/9, 9/8, 8/7, 7/6, 6/5, 5/4, 4/3, 3/2, 2                        False                                                                                                                                                                                              4/5, 5/6, 6/7, 7/8, 8/9, 9/10, 10/11, 11/12, 12/13, 13/14, 14/15, 15/16, 16/17, 17/18, 18/19, 19/20, 20/21, 21/22, 22/23, 23/24, 24/25, 25/26, 26/27, 27/28, 28/29, 29/30, 30/31, 31/32, 33/32, 32/31, 31/30, 30/29, 29/28, 28/27, 27/26, 26/25, 25/24, 24/23, 23/22, 22/21, 21/20, 20/19, 19/18, 18/17, 17/16, 16/15, 15/14, 14/13, 13/12, 12/11, 11/10, 10/9, 9/8, 8/7, 7/6, 6/5                                  5/3               False                  False                   False          True              True            False       True       True            False                   True          True               True                7        FAIL_MISSING_TRINORMAL_AND_SLOT        PASS_CONTROL_FAILED_AS_EXPECTED
                         A5_normal_only_plus_phase                     Phase plus normal bundle, no binary write.           1/3, 1                  31                   3                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              1/3, 1, 5/3                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             1/3      1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 2               False                  False                   False          True              True            False       True       True            False                   True          True               True                7                    FAIL_MISSING_BINARY        PASS_CONTROL_FAILED_AS_EXPECTED
                      A10_wrong_normal_dimension_4                              Four-normal replacement D_perp=4.      1/4, 1/2, 1                  84                  11                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1/2, 2/3, 3/4, 4/5, 1, 6/5, 5/4, 4/3, 3/2, 7/4, 2                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   4/5, 6/5, 7/4                                  5/3               False                  False                   False          True              True            False       True       True            False                   True          True               True                7                      FAIL_7_4_INTRUDER        PASS_CONTROL_FAILED_AS_EXPECTED
                         A2_global_operator_oracle                 Nonlocal oracle reproduces the operator stack.      1/3, 1/2, 1                  94                   9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none                                 none               False                  False                    True         False             False             True       True       True             True                   True         False              False                6                 REJECT_NONLOCAL_ORACLE            PASS_REJECTED_FAKE_SOLUTION
                       A1_polynomial_roots_at_seed                      Potential V(rho)=product over seed roots.             none                   9                   9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none                                 none                True                   True                   False         False              True            False       True       True            False                   True         False              False                5                REJECT_TARGET_SMUGGLING            PASS_REJECTED_FAKE_SOLUTION
                                     A3_phase_only                        Only local phase/cadence identity term.                1                   1                   1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        1                        False                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none 1/2, 2/3, 3/4, 5/4, 4/3, 3/2, 5/3, 2               False                  False                   False          True              True            False      False      False            False                   True          True               True                5                          FAIL_TOO_WEAK        PASS_CONTROL_FAILED_AS_EXPECTED
                             A0_seed_lookup_oracle                          Directly returns the nine seed modes.             none                   9                   9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            none                                 none                True                  False                    True         False             False            False       True       True            False                   True         False              False                4                REJECT_TARGET_SMUGGLING            PASS_REJECTED_FAKE_SOLUTION

## Action terms

 term_id                                     action_or_constraint_form                                     operator_consequence                                  no_smuggling_check                 status
 S_phase                                           ∫ dτ Kθ (Dτθ - Ω)^2                           identity/base cadence anchor 1                          does not contain seed list DEFINED_BLUEPRINT_TERM
S_binary            Π_no-overlap[write_cell(θ_n), write_cell(θ_{n+1})]            binary anchor 1/2 and species filter rho>=1/2       depends on binary predicate, not target modes DEFINED_BLUEPRINT_TERM
S_normal                             ∫ dτ K_N Σ_{i=1}^{3} ||Dτ n_i||^2 tri-normal virtual support anchor 1/3 and slot cap 1+3=4         uses normal-frame dimension, not seed roots DEFINED_BLUEPRINT_TERM
     S_R                                           λ_R (ρ + ρ_R - 2)^2                                                 R(ρ)=2-ρ            enforces complement total, not seed list DEFINED_BLUEPRINT_TERM
     S_C                                             λ_C (ρ ρ_C - 1)^2                                                 C(ρ)=1/ρ      enforces cadence-return product, not seed list DEFINED_BLUEPRINT_TERM
  S_slot                     rank_allowed = 1 tangent + 3 normal slots                           denom(ρ)<=4 for stable species uses 3+1 capacity, not denominator deletion by hand DEFINED_BLUEPRINT_TERM
 S_split species_domain = support_domain ∩ binary_filter ∩ slot_filter    1/3, 3/5, 4/5 are support-active but species-inactive   projection rule, not manual virtual-mode deletion DEFINED_BLUEPRINT_TERM

## Constraint equation targets

              constraint                                     stationarity_or_rule           operator_target                         status
          phase identity                                      δS_phase/δΩ -> Ω=Ω0                       ρ=1  BLUEPRINT_ONLY_VARIATION_NEXT
 binary write no-overlap                     cell width = 1/2; accept iff Δθ>=1/2     anchor 1/2 and ρ>=1/2  BLUEPRINT_ONLY_VARIATION_NEXT
normal-frame equal share                             D_perp=3 equal support share      anchor 1/3 and cap 4  BLUEPRINT_ONLY_VARIATION_NEXT
   reflection complement                                  ∂/∂ρ_R λ_R(ρ+ρ_R-2)^2=0                   ρ_R=2-ρ CONSTRAINT_STATIONARITY_FORMAL
          cadence return                                   ∂/∂ρ_C λ_C(ρρ_C-1)^2=0                   ρ_C=1/ρ CONSTRAINT_STATIONARITY_FORMAL
      species projection support domain projected through binary and slot filters nine-mode mechanical seed BLUEPRINT_ONLY_PROJECTION_NEXT

## Support/species projection audit

rho_fraction      rho  denominator  in_support_domain  stable_species  binary_accept  slot_accept  R_partner  R_supported C_partner  C_supported             role
         1/4 0.250000            4              False           False          False         True        7/4        False         4        False rejected_control
         1/3 0.333333            3               True           False          False         True        5/3         True         3        False  virtual_support
         1/2 0.500000            2               True            True           True         True        3/2         True         2         True      stable_seed
         3/5 0.600000            5               True           False           True        False        7/5         True       5/3         True  virtual_support
         2/3 0.666667            3               True            True           True         True        4/3         True       3/2         True      stable_seed
         3/4 0.750000            4               True            True           True         True        5/4         True       4/3         True      stable_seed
         4/5 0.800000            5               True           False           True        False        6/5         True       5/4         True  virtual_support
           1 1.000000            1               True            True           True         True          1         True         1         True      stable_seed
         6/5 1.200000            5               True           False           True        False        4/5         True       5/6         True rejected_control
         5/4 1.250000            4               True            True           True         True        3/4         True       4/5         True      stable_seed
         4/3 1.333333            3               True            True           True         True        2/3         True       3/4         True      stable_seed
         7/5 1.400000            5               True           False           True        False        3/5         True       5/7         True rejected_control
         3/2 1.500000            2               True            True           True         True        1/2         True       2/3         True      stable_seed
         5/3 1.666667            3               True            True           True         True        1/3         True       3/5         True      stable_seed
         7/4 1.750000            4              False           False           True         True        1/4        False       4/7        False rejected_control
           2 2.000000            1               True            True           True         True 0_boundary         True       1/2         True      stable_seed

## Fake solution rejection audit

                                             model  exact_seed_all_denominators  target_seed_lookup  polynomial_seed_roots  global_nonlocal_oracle  local_fields  no_smuggling  rejected_as_fake_solution                        reason
A15_candidate_worldline_tube_phase_boundary_action                         True               False                  False                   False          True          True                      False not fake; may be partial/open
                          A13_all_rationals_domain                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                    A14_promote_support_to_species                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                                A6_no_R_complement                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                                    A7_no_C_return                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                              A8_wrong_R_total_3_2                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                            A9_wrong_C_product_2_3                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                      A11_no_binary_species_filter                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                        A12_no_slot_species_filter                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                         A4_binary_only_plus_phase                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                         A5_normal_only_plus_phase                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                      A10_wrong_normal_dimension_4                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                         A2_global_operator_oracle                         True               False                  False                    True         False         False                       True        global nonlocal oracle
                       A1_polynomial_roots_at_seed                         True                True                   True                   False         False         False                       True            target seed lookup
                                     A3_phase_only                        False               False                  False                   False          True          True                      False not fake; may be partial/open
                             A0_seed_lookup_oracle                         True                True                  False                    True         False         False                       True            target seed lookup

## Claim boundary

                                                           claim status                                                                                                                      reason
R106 gives a no-smuggling candidate action/constraint blueprint.    YES The best candidate reproduces the operator seed from phase, binary, normal, R, C, and projection terms without seed lookup.
                 R106 proves the Euler-Lagrange field equations.     NO                                         R106 defines formal stationarity/constraint targets; variation is deferred to R107.
               R106 closes the full field/action/PDE derivation.     NO                                                                                            PDE implementation remains open.
          Seed lookup or polynomial roots are valid derivations.     NO                                                                                      They are rejected as target-smuggling.
                    Virtual support channels are stable species.     NO                                                               1/3, 3/5, and 4/5 remain support-active but species-inactive.
   The nine-mode seed is a confirmed physical particle spectrum.     NO                               It remains a mechanical seed until physical field, mass, and interaction bridges are derived.
                     Masses, SM matching, or Omega0 are derived.     NO                                                                                            Those are not addressed in R106.

## Next gate plan

 next_gate                                      title                                                                                           goal                                                          must_not_do
FORCE_R107 Euler-Lagrange / Constraint Variation Gate Vary the R106 functional and check whether the desired stationarity equations actually follow. Do not assume constraints are equations of motion without variation.
FORCE_R108   Locality and Gauge/Frame Relabeling Gate              Check phase gauge and normal-frame relabeling covariance of the action blueprint.            Do not hide a global ledger oracle in the boundary terms.
FORCE_R109         Support-to-Species Projection Gate                         Derive the support/species split from the action/projection structure.                                 Do not delete virtual modes by hand.

## Intruder / missing seed audit

                         model fraction      rho  denominator  R_partner C_partner               reason
                 A3_phase_only      1/2 0.500000            2        3/2         2   seed_mode_rejected
                 A3_phase_only      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                 A3_phase_only      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                 A3_phase_only      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                 A3_phase_only      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                 A3_phase_only      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
                 A3_phase_only      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
                 A3_phase_only        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
     A4_binary_only_plus_phase      4/5 0.800000            5        6/5       5/4 admitted_beyond_seed
     A4_binary_only_plus_phase      5/6 0.833333            6        7/6       6/5 admitted_beyond_seed
     A4_binary_only_plus_phase      6/7 0.857143            7        8/7       7/6 admitted_beyond_seed
     A4_binary_only_plus_phase      7/8 0.875000            8        9/8       8/7 admitted_beyond_seed
     A4_binary_only_plus_phase      8/9 0.888889            9       10/9       9/8 admitted_beyond_seed
     A4_binary_only_plus_phase     9/10 0.900000           10      11/10      10/9 admitted_beyond_seed
     A4_binary_only_plus_phase    10/11 0.909091           11      12/11     11/10 admitted_beyond_seed
     A4_binary_only_plus_phase    11/12 0.916667           12      13/12     12/11 admitted_beyond_seed
     A4_binary_only_plus_phase    12/13 0.923077           13      14/13     13/12 admitted_beyond_seed
     A4_binary_only_plus_phase    13/14 0.928571           14      15/14     14/13 admitted_beyond_seed
     A4_binary_only_plus_phase    14/15 0.933333           15      16/15     15/14 admitted_beyond_seed
     A4_binary_only_plus_phase    15/16 0.937500           16      17/16     16/15 admitted_beyond_seed
     A4_binary_only_plus_phase    16/17 0.941176           17      18/17     17/16 admitted_beyond_seed
     A4_binary_only_plus_phase    17/18 0.944444           18      19/18     18/17 admitted_beyond_seed
     A4_binary_only_plus_phase    18/19 0.947368           19      20/19     19/18 admitted_beyond_seed
     A4_binary_only_plus_phase    19/20 0.950000           20      21/20     20/19 admitted_beyond_seed
     A4_binary_only_plus_phase    20/21 0.952381           21      22/21     21/20 admitted_beyond_seed
     A4_binary_only_plus_phase    21/22 0.954545           22      23/22     22/21 admitted_beyond_seed
     A4_binary_only_plus_phase    22/23 0.956522           23      24/23     23/22 admitted_beyond_seed
     A4_binary_only_plus_phase    23/24 0.958333           24      25/24     24/23 admitted_beyond_seed
     A4_binary_only_plus_phase    24/25 0.960000           25      26/25     25/24 admitted_beyond_seed
     A4_binary_only_plus_phase    25/26 0.961538           26      27/26     26/25 admitted_beyond_seed
     A4_binary_only_plus_phase    26/27 0.962963           27      28/27     27/26 admitted_beyond_seed
     A4_binary_only_plus_phase    27/28 0.964286           28      29/28     28/27 admitted_beyond_seed
     A4_binary_only_plus_phase    28/29 0.965517           29      30/29     29/28 admitted_beyond_seed
     A4_binary_only_plus_phase    29/30 0.966667           30      31/30     30/29 admitted_beyond_seed
     A4_binary_only_plus_phase    30/31 0.967742           31      32/31     31/30 admitted_beyond_seed
     A4_binary_only_plus_phase    31/32 0.968750           32      33/32     32/31 admitted_beyond_seed
     A4_binary_only_plus_phase    33/32 1.031250           32      31/32     32/33 admitted_beyond_seed
     A4_binary_only_plus_phase    32/31 1.032258           31      30/31     31/32 admitted_beyond_seed
     A4_binary_only_plus_phase    31/30 1.033333           30      29/30     30/31 admitted_beyond_seed
     A4_binary_only_plus_phase    30/29 1.034483           29      28/29     29/30 admitted_beyond_seed
     A4_binary_only_plus_phase    29/28 1.035714           28      27/28     28/29 admitted_beyond_seed
     A4_binary_only_plus_phase    28/27 1.037037           27      26/27     27/28 admitted_beyond_seed
     A4_binary_only_plus_phase    27/26 1.038462           26      25/26     26/27 admitted_beyond_seed
     A4_binary_only_plus_phase    26/25 1.040000           25      24/25     25/26 admitted_beyond_seed
     A4_binary_only_plus_phase    25/24 1.041667           24      23/24     24/25 admitted_beyond_seed
     A4_binary_only_plus_phase    24/23 1.043478           23      22/23     23/24 admitted_beyond_seed
     A4_binary_only_plus_phase    23/22 1.045455           22      21/22     22/23 admitted_beyond_seed
     A4_binary_only_plus_phase    22/21 1.047619           21      20/21     21/22 admitted_beyond_seed
     A4_binary_only_plus_phase    21/20 1.050000           20      19/20     20/21 admitted_beyond_seed
     A4_binary_only_plus_phase    20/19 1.052632           19      18/19     19/20 admitted_beyond_seed
     A4_binary_only_plus_phase    19/18 1.055556           18      17/18     18/19 admitted_beyond_seed
     A4_binary_only_plus_phase    18/17 1.058824           17      16/17     17/18 admitted_beyond_seed
     A4_binary_only_plus_phase    17/16 1.062500           16      15/16     16/17 admitted_beyond_seed
     A4_binary_only_plus_phase    16/15 1.066667           15      14/15     15/16 admitted_beyond_seed
     A4_binary_only_plus_phase    15/14 1.071429           14      13/14     14/15 admitted_beyond_seed
     A4_binary_only_plus_phase    14/13 1.076923           13      12/13     13/14 admitted_beyond_seed
     A4_binary_only_plus_phase    13/12 1.083333           12      11/12     12/13 admitted_beyond_seed
     A4_binary_only_plus_phase    12/11 1.090909           11      10/11     11/12 admitted_beyond_seed
     A4_binary_only_plus_phase    11/10 1.100000           10       9/10     10/11 admitted_beyond_seed
     A4_binary_only_plus_phase     10/9 1.111111            9        8/9      9/10 admitted_beyond_seed
     A4_binary_only_plus_phase      9/8 1.125000            8        7/8       8/9 admitted_beyond_seed
     A4_binary_only_plus_phase      8/7 1.142857            7        6/7       7/8 admitted_beyond_seed
     A4_binary_only_plus_phase      7/6 1.166667            6        5/6       6/7 admitted_beyond_seed
     A4_binary_only_plus_phase      6/5 1.200000            5        4/5       5/6 admitted_beyond_seed
     A4_binary_only_plus_phase      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
     A5_normal_only_plus_phase      1/3 0.333333            3        5/3         3 admitted_beyond_seed
     A5_normal_only_plus_phase      1/2 0.500000            2        3/2         2   seed_mode_rejected
     A5_normal_only_plus_phase      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
     A5_normal_only_plus_phase      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
     A5_normal_only_plus_phase      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
     A5_normal_only_plus_phase      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
     A5_normal_only_plus_phase      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
     A5_normal_only_plus_phase        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
            A6_no_R_complement      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
            A6_no_R_complement      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
            A6_no_R_complement      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
            A6_no_R_complement      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
            A6_no_R_complement      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
            A6_no_R_complement      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
                A7_no_C_return      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
                A7_no_C_return      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
                A7_no_C_return      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
                A7_no_C_return      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
                A7_no_C_return        2 2.000000            1 0_boundary       1/2   seed_mode_rejected
          A8_wrong_R_total_3_2      2/3 0.666667            3        4/3       3/2   seed_mode_rejected
          A8_wrong_R_total_3_2      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
          A8_wrong_R_total_3_2      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
          A8_wrong_R_total_3_2      4/3 1.333333            3        2/3       3/4   seed_mode_rejected
          A8_wrong_R_total_3_2      3/2 1.500000            2        1/2       2/3   seed_mode_rejected
          A8_wrong_R_total_3_2      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
        A9_wrong_C_product_2_3      3/4 0.750000            4        5/4       4/3   seed_mode_rejected
        A9_wrong_C_product_2_3      5/4 1.250000            4        3/4       4/5   seed_mode_rejected
  A10_wrong_normal_dimension_4      4/5 0.800000            5        6/5       5/4 admitted_beyond_seed
  A10_wrong_normal_dimension_4      6/5 1.200000            5        4/5       5/6 admitted_beyond_seed
  A10_wrong_normal_dimension_4      7/4 1.750000            4        1/4       4/7 admitted_beyond_seed
  A10_wrong_normal_dimension_4      5/3 1.666667            3        1/3       3/5   seed_mode_rejected
  A11_no_binary_species_filter      1/3 0.333333            3        5/3         3 admitted_beyond_seed
    A12_no_slot_species_filter      3/5 0.600000            5        7/5       5/3 admitted_beyond_seed
    A12_no_slot_species_filter      5/7 0.714286            7        9/7       7/5 admitted_beyond_seed
    A12_no_slot_species_filter      7/9 0.777778            9       11/9       9/7 admitted_beyond_seed
    A12_no_slot_species_filter      4/5 0.800000            5        6/5       5/4 admitted_beyond_seed
    A12_no_slot_species_filter     9/11 0.818182           11      13/11      11/9 admitted_beyond_seed
    A12_no_slot_species_filter      5/6 0.833333            6        7/6       6/5 admitted_beyond_seed
    A12_no_slot_species_filter    11/13 0.846154           13      15/13     13/11 admitted_beyond_seed
    A12_no_slot_species_filter      6/7 0.857143            7        8/7       7/6 admitted_beyond_seed
    A12_no_slot_species_filter    13/15 0.866667           15      17/15     15/13 admitted_beyond_seed
    A12_no_slot_species_filter      7/8 0.875000            8        9/8       8/7 admitted_beyond_seed
    A12_no_slot_species_filter    15/17 0.882353           17      19/17     17/15 admitted_beyond_seed
    A12_no_slot_species_filter      8/9 0.888889            9       10/9       9/8 admitted_beyond_seed
    A12_no_slot_species_filter    17/19 0.894737           19      21/19     19/17 admitted_beyond_seed
    A12_no_slot_species_filter     9/10 0.900000           10      11/10      10/9 admitted_beyond_seed
    A12_no_slot_species_filter    19/21 0.904762           21      23/21     21/19 admitted_beyond_seed
    A12_no_slot_species_filter    10/11 0.909091           11      12/11     11/10 admitted_beyond_seed
    A12_no_slot_species_filter    21/23 0.913043           23      25/23     23/21 admitted_beyond_seed
    A12_no_slot_species_filter    11/12 0.916667           12      13/12     12/11 admitted_beyond_seed
    A12_no_slot_species_filter    23/25 0.920000           25      27/25     25/23 admitted_beyond_seed
    A12_no_slot_species_filter    12/13 0.923077           13      14/13     13/12 admitted_beyond_seed
    A12_no_slot_species_filter    25/27 0.925926           27      29/27     27/25 admitted_beyond_seed
    A12_no_slot_species_filter    13/14 0.928571           14      15/14     14/13 admitted_beyond_seed
    A12_no_slot_species_filter    27/29 0.931034           29      31/29     29/27 admitted_beyond_seed
    A12_no_slot_species_filter    14/15 0.933333           15      16/15     15/14 admitted_beyond_seed
    A12_no_slot_species_filter    29/31 0.935484           31      33/31     31/29 admitted_beyond_seed
    A12_no_slot_species_filter    15/16 0.937500           16      17/16     16/15 admitted_beyond_seed
    A12_no_slot_species_filter    16/17 0.941176           17      18/17     17/16 admitted_beyond_seed
    A12_no_slot_species_filter    17/18 0.944444           18      19/18     18/17 admitted_beyond_seed
    A12_no_slot_species_filter    18/19 0.947368           19      20/19     19/18 admitted_beyond_seed
    A12_no_slot_species_filter    19/20 0.950000           20      21/20     20/19 admitted_beyond_seed
    A12_no_slot_species_filter    20/21 0.952381           21      22/21     21/20 admitted_beyond_seed
    A12_no_slot_species_filter    21/22 0.954545           22      23/22     22/21 admitted_beyond_seed
    A12_no_slot_species_filter    22/23 0.956522           23      24/23     23/22 admitted_beyond_seed
    A12_no_slot_species_filter    23/24 0.958333           24      25/24     24/23 admitted_beyond_seed
    A12_no_slot_species_filter    24/25 0.960000           25      26/25     25/24 admitted_beyond_seed
    A12_no_slot_species_filter    25/26 0.961538           26      27/26     26/25 admitted_beyond_seed
    A12_no_slot_species_filter    26/27 0.962963           27      28/27     27/26 admitted_beyond_seed
    A12_no_slot_species_filter    27/28 0.964286           28      29/28     28/27 admitted_beyond_seed
    A12_no_slot_species_filter    28/29 0.965517           29      30/29     29/28 admitted_beyond_seed
    A12_no_slot_species_filter    29/30 0.966667           30      31/30     30/29 admitted_beyond_seed
    A12_no_slot_species_filter    30/31 0.967742           31      32/31     31/30 admitted_beyond_seed
    A12_no_slot_species_filter    31/32 0.968750           32      33/32     32/31 admitted_beyond_seed
    A12_no_slot_species_filter    33/32 1.031250           32      31/32     32/33 admitted_beyond_seed
    A12_no_slot_species_filter    32/31 1.032258           31      30/31     31/32 admitted_beyond_seed
    A12_no_slot_species_filter    31/30 1.033333           30      29/30     30/31 admitted_beyond_seed
    A12_no_slot_species_filter    30/29 1.034483           29      28/29     29/30 admitted_beyond_seed
    A12_no_slot_species_filter    29/28 1.035714           28      27/28     28/29 admitted_beyond_seed
    A12_no_slot_species_filter    28/27 1.037037           27      26/27     27/28 admitted_beyond_seed
    A12_no_slot_species_filter    27/26 1.038462           26      25/26     26/27 admitted_beyond_seed
    A12_no_slot_species_filter    26/25 1.040000           25      24/25     25/26 admitted_beyond_seed
    A12_no_slot_species_filter    25/24 1.041667           24      23/24     24/25 admitted_beyond_seed
    A12_no_slot_species_filter    24/23 1.043478           23      22/23     23/24 admitted_beyond_seed
    A12_no_slot_species_filter    23/22 1.045455           22      21/22     22/23 admitted_beyond_seed
    A12_no_slot_species_filter    22/21 1.047619           21      20/21     21/22 admitted_beyond_seed
    A12_no_slot_species_filter    21/20 1.050000           20      19/20     20/21 admitted_beyond_seed
    A12_no_slot_species_filter    20/19 1.052632           19      18/19     19/20 admitted_beyond_seed
    A12_no_slot_species_filter    19/18 1.055556           18      17/18     18/19 admitted_beyond_seed
    A12_no_slot_species_filter    18/17 1.058824           17      16/17     17/18 admitted_beyond_seed
    A12_no_slot_species_filter    17/16 1.062500           16      15/16     16/17 admitted_beyond_seed
    A12_no_slot_species_filter    33/31 1.064516           31      29/31     31/33 admitted_beyond_seed
    A12_no_slot_species_filter    16/15 1.066667           15      14/15     15/16 admitted_beyond_seed
    A12_no_slot_species_filter    31/29 1.068966           29      27/29     29/31 admitted_beyond_seed
    A12_no_slot_species_filter    15/14 1.071429           14      13/14     14/15 admitted_beyond_seed
    A12_no_slot_species_filter    29/27 1.074074           27      25/27     27/29 admitted_beyond_seed
    A12_no_slot_species_filter    14/13 1.076923           13      12/13     13/14 admitted_beyond_seed
    A12_no_slot_species_filter    27/25 1.080000           25      23/25     25/27 admitted_beyond_seed
    A12_no_slot_species_filter    13/12 1.083333           12      11/12     12/13 admitted_beyond_seed
    A12_no_slot_species_filter    25/23 1.086957           23      21/23     23/25 admitted_beyond_seed
    A12_no_slot_species_filter    12/11 1.090909           11      10/11     11/12 admitted_beyond_seed
    A12_no_slot_species_filter    23/21 1.095238           21      19/21     21/23 admitted_beyond_seed
    A12_no_slot_species_filter    11/10 1.100000           10       9/10     10/11 admitted_beyond_seed
    A12_no_slot_species_filter    21/19 1.105263           19      17/19     19/21 admitted_beyond_seed
    A12_no_slot_species_filter     10/9 1.111111            9        8/9      9/10 admitted_beyond_seed
    A12_no_slot_species_filter    19/17 1.117647           17      15/17     17/19 admitted_beyond_seed
    A12_no_slot_species_filter      9/8 1.125000            8        7/8       8/9 admitted_beyond_seed
    A12_no_slot_species_filter    17/15 1.133333           15      13/15     15/17 admitted_beyond_seed
    A12_no_slot_species_filter      8/7 1.142857            7        6/7       7/8 admitted_beyond_seed
    A12_no_slot_species_filter    15/13 1.153846           13      11/13     13/15 admitted_beyond_seed
    A12_no_slot_species_filter      7/6 1.166667            6        5/6       6/7 admitted_beyond_seed
    A12_no_slot_species_filter    13/11 1.181818           11       9/11     11/13 admitted_beyond_seed
    A12_no_slot_species_filter      6/5 1.200000            5        4/5       5/6 admitted_beyond_seed
    A12_no_slot_species_filter     11/9 1.222222            9        7/9      9/11 admitted_beyond_seed
    A12_no_slot_species_filter      9/7 1.285714            7        5/7       7/9 admitted_beyond_seed
    A12_no_slot_species_filter      7/5 1.400000            5        3/5       5/7 admitted_beyond_seed
      A13_all_rationals_domain      7/4 1.750000            4        1/4       4/7 admitted_beyond_seed
A14_promote_support_to_species      1/3 0.333333            3        5/3         3 admitted_beyond_seed
A14_promote_support_to_species      3/5 0.600000            5        7/5       5/3 admitted_beyond_seed
A14_promote_support_to_species      5/7 0.714286            7        9/7       7/5 admitted_beyond_seed
A14_promote_support_to_species      7/9 0.777778            9       11/9       9/7 admitted_beyond_seed
A14_promote_support_to_species      4/5 0.800000            5        6/5       5/4 admitted_beyond_seed
A14_promote_support_to_species     9/11 0.818182           11      13/11      11/9 admitted_beyond_seed
A14_promote_support_to_species      5/6 0.833333            6        7/6       6/5 admitted_beyond_seed
A14_promote_support_to_species    11/13 0.846154           13      15/13     13/11 admitted_beyond_seed
A14_promote_support_to_species      6/7 0.857143            7        8/7       7/6 admitted_beyond_seed
A14_promote_support_to_species    13/15 0.866667           15      17/15     15/13 admitted_beyond_seed
A14_promote_support_to_species      7/8 0.875000            8        9/8       8/7 admitted_beyond_seed
A14_promote_support_to_species    15/17 0.882353           17      19/17     17/15 admitted_beyond_seed
A14_promote_support_to_species      8/9 0.888889            9       10/9       9/8 admitted_beyond_seed
A14_promote_support_to_species    17/19 0.894737           19      21/19     19/17 admitted_beyond_seed
A14_promote_support_to_species     9/10 0.900000           10      11/10      10/9 admitted_beyond_seed
A14_promote_support_to_species    19/21 0.904762           21      23/21     21/19 admitted_beyond_seed
A14_promote_support_to_species    10/11 0.909091           11      12/11     11/10 admitted_beyond_seed
A14_promote_support_to_species    21/23 0.913043           23      25/23     23/21 admitted_beyond_seed
A14_promote_support_to_species    11/12 0.916667           12      13/12     12/11 admitted_beyond_seed
A14_promote_support_to_species    23/25 0.920000           25      27/25     25/23 admitted_beyond_seed
A14_promote_support_to_species    12/13 0.923077           13      14/13     13/12 admitted_beyond_seed
A14_promote_support_to_species    25/27 0.925926           27      29/27     27/25 admitted_beyond_seed
A14_promote_support_to_species    13/14 0.928571           14      15/14     14/13 admitted_beyond_seed
A14_promote_support_to_species    27/29 0.931034           29      31/29     29/27 admitted_beyond_seed
A14_promote_support_to_species    14/15 0.933333           15      16/15     15/14 admitted_beyond_seed
A14_promote_support_to_species    29/31 0.935484           31      33/31     31/29 admitted_beyond_seed
A14_promote_support_to_species    15/16 0.937500           16      17/16     16/15 admitted_beyond_seed
A14_promote_support_to_species    16/17 0.941176           17      18/17     17/16 admitted_beyond_seed
A14_promote_support_to_species    17/18 0.944444           18      19/18     18/17 admitted_beyond_seed
A14_promote_support_to_species    18/19 0.947368           19      20/19     19/18 admitted_beyond_seed
A14_promote_support_to_species    19/20 0.950000           20      21/20     20/19 admitted_beyond_seed
A14_promote_support_to_species    20/21 0.952381           21      22/21     21/20 admitted_beyond_seed
A14_promote_support_to_species    21/22 0.954545           22      23/22     22/21 admitted_beyond_seed
A14_promote_support_to_species    22/23 0.956522           23      24/23     23/22 admitted_beyond_seed
A14_promote_support_to_species    23/24 0.958333           24      25/24     24/23 admitted_beyond_seed
A14_promote_support_to_species    24/25 0.960000           25      26/25     25/24 admitted_beyond_seed
A14_promote_support_to_species    25/26 0.961538           26      27/26     26/25 admitted_beyond_seed
A14_promote_support_to_species    26/27 0.962963           27      28/27     27/26 admitted_beyond_seed
A14_promote_support_to_species    27/28 0.964286           28      29/28     28/27 admitted_beyond_seed
A14_promote_support_to_species    28/29 0.965517           29      30/29     29/28 admitted_beyond_seed
A14_promote_support_to_species    29/30 0.966667           30      31/30     30/29 admitted_beyond_seed
A14_promote_support_to_species    30/31 0.967742           31      32/31     31/30 admitted_beyond_seed
A14_promote_support_to_species    31/32 0.968750           32      33/32     32/31 admitted_beyond_seed
A14_promote_support_to_species    33/32 1.031250           32      31/32     32/33 admitted_beyond_seed
A14_promote_support_to_species    32/31 1.032258           31      30/31     31/32 admitted_beyond_seed
A14_promote_support_to_species    31/30 1.033333           30      29/30     30/31 admitted_beyond_seed
A14_promote_support_to_species    30/29 1.034483           29      28/29     29/30 admitted_beyond_seed
A14_promote_support_to_species    29/28 1.035714           28      27/28     28/29 admitted_beyond_seed
A14_promote_support_to_species    28/27 1.037037           27      26/27     27/28 admitted_beyond_seed
A14_promote_support_to_species    27/26 1.038462           26      25/26     26/27 admitted_beyond_seed
A14_promote_support_to_species    26/25 1.040000           25      24/25     25/26 admitted_beyond_seed
A14_promote_support_to_species    25/24 1.041667           24      23/24     24/25 admitted_beyond_seed
A14_promote_support_to_species    24/23 1.043478           23      22/23     23/24 admitted_beyond_seed
A14_promote_support_to_species    23/22 1.045455           22      21/22     22/23 admitted_beyond_seed
A14_promote_support_to_species    22/21 1.047619           21      20/21     21/22 admitted_beyond_seed
A14_promote_support_to_species    21/20 1.050000           20      19/20     20/21 admitted_beyond_seed
A14_promote_support_to_species    20/19 1.052632           19      18/19     19/20 admitted_beyond_seed
A14_promote_support_to_species    19/18 1.055556           18      17/18     18/19 admitted_beyond_seed
A14_promote_support_to_species    18/17 1.058824           17      16/17     17/18 admitted_beyond_seed
A14_promote_support_to_species    17/16 1.062500           16      15/16     16/17 admitted_beyond_seed
A14_promote_support_to_species    33/31 1.064516           31      29/31     31/33 admitted_beyond_seed
A14_promote_support_to_species    16/15 1.066667           15      14/15     15/16 admitted_beyond_seed
A14_promote_support_to_species    31/29 1.068966           29      27/29     29/31 admitted_beyond_seed
A14_promote_support_to_species    15/14 1.071429           14      13/14     14/15 admitted_beyond_seed
A14_promote_support_to_species    29/27 1.074074           27      25/27     27/29 admitted_beyond_seed
A14_promote_support_to_species    14/13 1.076923           13      12/13     13/14 admitted_beyond_seed
A14_promote_support_to_species    27/25 1.080000           25      23/25     25/27 admitted_beyond_seed
A14_promote_support_to_species    13/12 1.083333           12      11/12     12/13 admitted_beyond_seed
A14_promote_support_to_species    25/23 1.086957           23      21/23     23/25 admitted_beyond_seed
A14_promote_support_to_species    12/11 1.090909           11      10/11     11/12 admitted_beyond_seed
A14_promote_support_to_species    23/21 1.095238           21      19/21     21/23 admitted_beyond_seed
A14_promote_support_to_species    11/10 1.100000           10       9/10     10/11 admitted_beyond_seed
A14_promote_support_to_species    21/19 1.105263           19      17/19     19/21 admitted_beyond_seed
A14_promote_support_to_species     10/9 1.111111            9        8/9      9/10 admitted_beyond_seed
A14_promote_support_to_species    19/17 1.117647           17      15/17     17/19 admitted_beyond_seed
A14_promote_support_to_species      9/8 1.125000            8        7/8       8/9 admitted_beyond_seed
A14_promote_support_to_species    17/15 1.133333           15      13/15     15/17 admitted_beyond_seed
A14_promote_support_to_species      8/7 1.142857            7        6/7       7/8 admitted_beyond_seed
A14_promote_support_to_species    15/13 1.153846           13      11/13     13/15 admitted_beyond_seed
A14_promote_support_to_species      7/6 1.166667            6        5/6       6/7 admitted_beyond_seed
A14_promote_support_to_species    13/11 1.181818           11       9/11     11/13 admitted_beyond_seed
A14_promote_support_to_species      6/5 1.200000            5        4/5       5/6 admitted_beyond_seed
A14_promote_support_to_species     11/9 1.222222            9        7/9      9/11 admitted_beyond_seed
A14_promote_support_to_species      9/7 1.285714            7        5/7       7/9 admitted_beyond_seed
A14_promote_support_to_species      7/5 1.400000            5        3/5       5/7 admitted_beyond_seed

## Recommended next

BOXED: FORCE_R107 — Euler-Lagrange / Constraint Variation Gate
