from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R102_reflection_complement_map_origin_gate")
ZIP = Path("FORCE_R102_reflection_complement_map_origin_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R102 — Reflection Complement Map Origin Gate
#
# V12.7/R99 froze the support-domain language:
#
#   stable candidate = rho in minimal joint R/C support domain
#                      + rho >= 1/2
#                      + denom(rho) <= 4
#
# with primitive anchors:
#
#   {1, 1/2, 1/3}
#
# R100/R101 sharpened the anchor interpretation:
#
#   1   = identity/base cadence
#   1/2 = binary no-overwrite cell
#   1/3 = tri-normal virtual support anchor, not stable species
#
# R102 question:
#
#   Why R(rho)=2-rho?
#
# Candidate origin:
#
#   R is the complement/reflection map on the doubled closure interval [0,2].
#
# Required native roles:
#
#   R(1)   = 1             identity/base cadence fixed point
#   R(2)   = 0_boundary    endpoint closes against zero boundary
#   R(3/2) = 1/2           binary high partner closes to binary anchor
#   R(5/3) = 1/3           tri-normal high partner closes to tri-normal virtual anchor
#
# These four conditions all force the complement total T=2 in the family:
#
#   R_T(rho)=T-rho
#
# Claim boundary:
# - This is an operator/geometric origin gate for the reflection map.
# - It does not derive the full PDE/action field implementation.
# - It does not derive the reciprocal map C(rho)=1/rho.
# - It does not claim real particle spectrum, masses, or Omega0.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def R_identity(x):
    return x

def R_none(x):
    return None

def R_T_factory(T):
    def R_T(x):
        return T - x
    return R_T

def R_scaled_bad(x):
    return Fraction(2, 1) - 2 * x

def R_reciprocal_duplicate(x):
    return C_map(x)

R_MODELS = [
    {
        "model": "R0_no_reflection_C_only",
        "description": "No reflection map; only reciprocal closure acts.",
        "R_kind": "none",
        "R_map": R_none,
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "R1_identity_no_complement",
        "description": "Identity map R(rho)=rho; no complement.",
        "R_kind": "identity",
        "R_map": R_identity,
        "expected": "FAIL_SIGNAL_LOST",
    },
    {
        "model": "R2_unit_complement_T1",
        "description": "Unit complement R(rho)=1-rho.",
        "R_kind": "T_minus_rho",
        "T": Fraction(1, 1),
        "R_map": R_T_factory(Fraction(1, 1)),
        "expected": "FAIL_TOO_SMALL",
    },
    {
        "model": "R3_three_halves_complement_T3_2",
        "description": "Intermediate complement R(rho)=3/2-rho.",
        "R_kind": "T_minus_rho",
        "T": Fraction(3, 2),
        "R_map": R_T_factory(Fraction(3, 2)),
        "expected": "FAIL_TOO_SMALL",
    },
    {
        "model": "R4_two_complement_T2",
        "description": "Candidate doubled-boundary complement R(rho)=2-rho.",
        "R_kind": "T_minus_rho",
        "T": Fraction(2, 1),
        "R_map": R_T_factory(Fraction(2, 1)),
        "expected": "PASS_EXACT_SEED",
    },
    {
        "model": "R5_five_halves_complement_T5_2",
        "description": "Oversized complement R(rho)=5/2-rho.",
        "R_kind": "T_minus_rho",
        "T": Fraction(5, 2),
        "R_map": R_T_factory(Fraction(5, 2)),
        "expected": "FAIL_WRONG_DOMAIN",
    },
    {
        "model": "R6_three_complement_T3",
        "description": "Large complement R(rho)=3-rho.",
        "R_kind": "T_minus_rho",
        "T": Fraction(3, 1),
        "R_map": R_T_factory(Fraction(3, 1)),
        "expected": "FAIL_WRONG_DOMAIN",
    },
    {
        "model": "R7_scaled_bad_2_minus_2rho",
        "description": "Bad affine control R(rho)=2-2rho.",
        "R_kind": "bad_affine",
        "R_map": R_scaled_bad,
        "expected": "FAIL_NON_INVOLUTIVE_SIGNAL",
    },
    {
        "model": "R8_reciprocal_duplicate",
        "description": "Bad control: reflection duplicated by reciprocal map.",
        "R_kind": "duplicate_C",
        "R_map": R_reciprocal_duplicate,
        "expected": "FAIL_SIGNAL_LOST",
    },
]

def close_domain(R_func, max_den, use_C=True):
    universe = rational_universe(max_den)
    active = {a for a in ANCHORS if a in universe}
    boundary_used = False

    for _ in range(500):
        before = set(active)

        for x in list(active):
            y = R_func(x)
            if y == 0:
                boundary_used = True
            elif in_interval(y) and y in universe:
                active.add(y)

            if use_C:
                y = C_map(x)
                if in_interval(y) and y in universe:
                    active.add(y)

        if active == before:
            break

    return active, boundary_used

def binary_accept(x):
    return x >= Fraction(1, 2)

def slot_accept(x):
    return x.denominator <= 4

def stable_by_domain(domain, max_den):
    universe = rational_universe(max_den)
    return {
        x for x in universe
        if binary_accept(x)
        and slot_accept(x)
        and x in domain
    }

score_rows = []
interval_rows = []
intruder_rows = []

for m in R_MODELS:
    exact_all = True
    final_domain = set()
    final_stable = set()
    final_boundary_used = False

    for max_den in DENOM_AUDITS:
        domain, boundary_used = close_domain(m["R_map"], max_den, use_C=True)
        stable = stable_by_domain(domain, max_den)

        final_domain = domain
        final_stable = stable
        final_boundary_used = boundary_used

        extras = stable - SEED
        missing = SEED - stable
        exact = stable == SEED

        if not exact:
            exact_all = False

        interval_rows.append({
            "model": m["model"],
            "R_kind": m["R_kind"],
            "T": frac_label(m.get("T", None)),
            "max_den": max_den,
            "support_domain_count": len(domain),
            "stable_count": len(stable),
            "stable_fractions": label_set(stable),
            "exact_seed": exact,
            "extra_vs_seed": label_set(extras),
            "missing_from_seed": label_set(missing),
            "boundary_used": boundary_used,
        })

        if max_den == DENOM_AUDITS[-1]:
            for x in sorted(extras):
                intruder_rows.append({
                    "model": m["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": frac_label(m["R_map"](x)),
                    "C_partner": frac_label(C_map(x)),
                    "reason": "admitted_beyond_seed",
                })
            for x in sorted(missing):
                intruder_rows.append({
                    "model": m["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": frac_label(m["R_map"](x)),
                    "C_partner": frac_label(C_map(x)),
                    "reason": "seed_mode_rejected",
                })

    if exact_all and m["expected"].startswith("PASS"):
        survivor_status = "PASS_EXACT_SEED"
    elif (not exact_all) and m["expected"].startswith("FAIL"):
        survivor_status = "PASS_CONTROL_FAILED_AS_EXPECTED"
    elif exact_all and m["expected"].startswith("FAIL"):
        survivor_status = "UNEXPECTED_EXACT_SEED"
    else:
        survivor_status = "PARTIAL"

    score_rows.append({
        "model": m["model"],
        "description": m["description"],
        "R_kind": m["R_kind"],
        "T": frac_label(m.get("T", None)),
        "support_domain_count_final": len(final_domain),
        "stable_count_final": len(final_stable),
        "stable_fractions_final": label_set(final_stable),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(final_stable - SEED),
        "missing_from_seed": label_set(SEED - final_stable),
        "boundary_used_final": final_boundary_used,
        "expected": m["expected"],
        "survivor_status": survivor_status,
    })

scorecard = pd.DataFrame(score_rows)
interval_audit = pd.DataFrame(interval_rows)
intruder_audit = pd.DataFrame(intruder_rows)

# ---------------------------------------------------------------------
# Axiom scan for R_T(rho)=T-rho.
# ---------------------------------------------------------------------

T_SCAN = [
    Fraction(1, 1), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3),
    Fraction(2, 1), Fraction(7, 3), Fraction(5, 2), Fraction(3, 1)
]

axiom_rows = []

for T in T_SCAN:
    R_T = R_T_factory(T)
    domain, boundary_used = close_domain(R_T, max(DENOM_AUDITS), use_C=True)
    stable = stable_by_domain(domain, max(DENOM_AUDITS))

    identity_fixed = R_T(Fraction(1, 1)) == Fraction(1, 1)
    endpoint_2_to_boundary = R_T(Fraction(2, 1)) == 0
    binary_high_to_binary_anchor = R_T(Fraction(3, 2)) == Fraction(1, 2)
    trinormal_high_to_trinormal_anchor = R_T(Fraction(5, 3)) == Fraction(1, 3)
    involutive_sample_pass = True

    for x in [Fraction(1, 3), Fraction(1, 2), Fraction(2, 3), Fraction(1, 1), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)]:
        y = R_T(x)
        yy = R_T(y)
        if yy != x:
            involutive_sample_pass = False

    axiom_rows.append({
        "T": frac_label(T),
        "R_formula": f"{frac_label(T)} - rho",
        "support_domain_count": len(domain),
        "stable_count": len(stable),
        "stable_fractions": label_set(stable),
        "exact_seed": stable == SEED,
        "identity_fixed_R1_eq_1": identity_fixed,
        "endpoint_R2_eq_0_boundary": endpoint_2_to_boundary,
        "binary_high_R3_2_eq_1_2": binary_high_to_binary_anchor,
        "trinormal_high_R5_3_eq_1_3": trinormal_high_to_trinormal_anchor,
        "involutive_sample_pass": involutive_sample_pass,
        "axiom_count": sum([
            identity_fixed,
            endpoint_2_to_boundary,
            binary_high_to_binary_anchor,
            trinormal_high_to_trinormal_anchor,
            involutive_sample_pass,
            stable == SEED,
        ]),
        "extra_vs_seed": label_set(stable - SEED),
        "missing_from_seed": label_set(SEED - stable),
    })

axiom_scan = pd.DataFrame(axiom_rows).sort_values(
    ["axiom_count", "exact_seed"],
    ascending=[False, False]
).reset_index(drop=True)

# ---------------------------------------------------------------------
# Candidate support truth table under R(rho)=2-rho.
# ---------------------------------------------------------------------

R2 = R_T_factory(Fraction(2, 1))
domain_R2, boundary_R2 = close_domain(R2, max(DENOM_AUDITS), use_C=True)
stable_R2 = stable_by_domain(domain_R2, max(DENOM_AUDITS))

test_modes = [
    Fraction(1, 4), Fraction(1, 3), Fraction(1, 2),
    Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2),
    Fraction(5, 3), Fraction(7, 4), Fraction(2, 1)
]

truth_rows = []
for x in test_modes:
    r = R2(x)
    c = C_map(x)
    truth_rows.append({
        "rho_fraction": frac_label(x),
        "rho": float(x),
        "denominator": x.denominator,
        "in_R2_joint_domain": x in domain_R2,
        "binary_accept": binary_accept(x),
        "slot_accept": slot_accept(x),
        "stable_candidate": x in stable_R2,
        "R2_partner": frac_label(r),
        "R2_supported": True if r == 0 else r in domain_R2,
        "C_partner": frac_label(c),
        "C_supported": in_interval(c) and c in domain_R2,
        "seed_member": x in SEED,
        "role": (
            "stable_seed"
            if x in stable_R2
            else (
                "tri_normal_virtual_anchor"
                if x == Fraction(1, 3)
                else (
                    "boundary_rejected_intruder"
                    if x == Fraction(7, 4)
                    else "support_or_rejected_control"
                )
            )
        ),
    })

support_truth_table = pd.DataFrame(truth_rows)

# ---------------------------------------------------------------------
# Verdict booleans.
# ---------------------------------------------------------------------

def model_status(model):
    return scorecard[scorecard["model"] == model].iloc[0]["survivor_status"]

two_complement_exact_seed = model_status("R4_two_complement_T2") == "PASS_EXACT_SEED"

control_models = [
    "R0_no_reflection_C_only",
    "R1_identity_no_complement",
    "R2_unit_complement_T1",
    "R3_three_halves_complement_T3_2",
    "R5_five_halves_complement_T5_2",
    "R6_three_complement_T3",
    "R7_scaled_bad_2_minus_2rho",
    "R8_reciprocal_duplicate",
]
controls_fail = all(model_status(m) == "PASS_CONTROL_FAILED_AS_EXPECTED" for m in control_models)

exact_Ts = set(axiom_scan[axiom_scan["exact_seed"] == True]["T"].tolist())
T2_unique_exact_in_scan = exact_Ts == {"2"}

T2_row = axiom_scan[axiom_scan["T"] == "2"].iloc[0]
T2_satisfies_all_axioms = bool(
    T2_row["identity_fixed_R1_eq_1"]
    and T2_row["endpoint_R2_eq_0_boundary"]
    and T2_row["binary_high_R3_2_eq_1_2"]
    and T2_row["trinormal_high_R5_3_eq_1_3"]
    and T2_row["involutive_sample_pass"]
    and T2_row["exact_seed"]
)

identity_fixed_forces_T2 = set(
    axiom_scan[axiom_scan["identity_fixed_R1_eq_1"] == True]["T"].tolist()
) == {"2"}

endpoint_boundary_forces_T2 = set(
    axiom_scan[axiom_scan["endpoint_R2_eq_0_boundary"] == True]["T"].tolist()
) == {"2"}

binary_high_support_forces_T2 = set(
    axiom_scan[axiom_scan["binary_high_R3_2_eq_1_2"] == True]["T"].tolist()
) == {"2"}

trinormal_high_support_forces_T2 = set(
    axiom_scan[axiom_scan["trinormal_high_R5_3_eq_1_3"] == True]["T"].tolist()
) == {"2"}

if (
    two_complement_exact_seed
    and controls_fail
    and T2_unique_exact_in_scan
    and T2_satisfies_all_axioms
    and identity_fixed_forces_T2
    and endpoint_boundary_forces_T2
    and binary_high_support_forces_T2
    and trinormal_high_support_forces_T2
):
    verdict_status = "REFLECTION COMPLEMENT MAP ORIGIN PASS / FIELD-ACTION DERIVATION STILL OPEN"
elif two_complement_exact_seed and T2_unique_exact_in_scan:
    verdict_status = "REFLECTION COMPLEMENT MAP SIGNAL PASS / SOME AXIOM CONTROLS SURVIVE"
else:
    verdict_status = "REFLECTION COMPLEMENT MAP ORIGIN INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "two_complement_exact_seed",
        "result": "PASS" if two_complement_exact_seed else "WARN",
        "interpretation": "R(rho)=2-rho with reciprocal closure recovers the exact V12.7 seed.",
    },
    {
        "test": "controls_fail",
        "result": "PASS" if controls_fail else "WARN",
        "interpretation": "No-reflection, identity, wrong-T complements, scaled bad affine, and duplicate-reciprocal controls fail.",
    },
    {
        "test": "T2_unique_exact_in_scan",
        "result": "PASS" if T2_unique_exact_in_scan else "WARN",
        "interpretation": "Among tested complement totals T, only T=2 recovers the exact seed.",
    },
    {
        "test": "identity_fixed_forces_T2",
        "result": "PASS" if identity_fixed_forces_T2 else "WARN",
        "interpretation": "R_T(1)=1 forces T=2.",
    },
    {
        "test": "endpoint_boundary_forces_T2",
        "result": "PASS" if endpoint_boundary_forces_T2 else "WARN",
        "interpretation": "R_T(2)=0_boundary forces T=2.",
    },
    {
        "test": "binary_high_support_forces_T2",
        "result": "PASS" if binary_high_support_forces_T2 else "WARN",
        "interpretation": "R_T(3/2)=1/2 forces T=2.",
    },
    {
        "test": "trinormal_high_support_forces_T2",
        "result": "PASS" if trinormal_high_support_forces_T2 else "WARN",
        "interpretation": "R_T(5/3)=1/3 forces T=2.",
    },
    {
        "test": "T2_satisfies_all_axioms",
        "result": "PASS" if T2_satisfies_all_axioms else "WARN",
        "interpretation": "T=2 is involutive, fixes identity, sends endpoint to boundary, and supplies binary/tri-normal complement support.",
    },
    {
        "test": "field_action_derivation",
        "result": "OPEN",
        "interpretation": "R102 supports the reflection-complement map at operator level; it is not a full PDE/action derivation.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R(rho)=2-rho has an operator-level complement-origin candidate.",
        "status": "YES",
        "reason": "T=2 is the unique tested complement total satisfying exact seed recovery and the identity/boundary/support axioms.",
    },
    {
        "claim": "The reflection map is arbitrary.",
        "status": "NO",
        "reason": "Wrong complement totals and non-complement controls fail.",
    },
    {
        "claim": "R fixes the identity cadence.",
        "status": "YES",
        "reason": "R(1)=1.",
    },
    {
        "claim": "R closes the high endpoint against the zero boundary.",
        "status": "YES",
        "reason": "R(2)=0_boundary.",
    },
    {
        "claim": "R supplies tri-normal complement support for 5/3.",
        "status": "YES",
        "reason": "R(5/3)=1/3.",
    },
    {
        "claim": "R supplies binary complement support for 3/2.",
        "status": "YES",
        "reason": "R(3/2)=1/2.",
    },
    {
        "claim": "The full field/action origin of R is solved.",
        "status": "NO",
        "reason": "R102 is an operator/geometric complement gate, not a PDE/action derivation.",
    },
    {
        "claim": "The reciprocal map C(rho)=1/rho is derived here.",
        "status": "NO",
        "reason": "R102 uses C as the already frozen reciprocal closure branch; R103 should test C origin.",
    },
])

theorem_candidate = pd.DataFrame([
    {
        "layer": 1,
        "statement": "Closure reflection is a complement map R_T(rho)=T-rho.",
        "status": "MODEL_FAMILY",
    },
    {
        "layer": 2,
        "statement": "Identity/base cadence must be fixed: R_T(1)=1.",
        "status": "FORCES_T_EQ_2",
    },
    {
        "layer": 3,
        "statement": "Endpoint 2 closes to the zero boundary: R_T(2)=0_boundary.",
        "status": "FORCES_T_EQ_2",
    },
    {
        "layer": 4,
        "statement": "Binary high partner closes to binary anchor: R_T(3/2)=1/2.",
        "status": "FORCES_T_EQ_2",
    },
    {
        "layer": 5,
        "statement": "Tri-normal high partner closes to tri-normal anchor: R_T(5/3)=1/3.",
        "status": "FORCES_T_EQ_2",
    },
    {
        "layer": 6,
        "statement": "Therefore T=2 and R(rho)=2-rho.",
        "status": "CANDIDATE_PASS",
    },
    {
        "layer": 7,
        "statement": "Full field/action implementation remains open.",
        "status": "OPEN",
    },
])

# Save artifacts.
scorecard.to_csv(OUT / "FORCE_R102_reflection_model_scorecard.csv", index=False)
interval_audit.to_csv(OUT / "FORCE_R102_interval_audit.csv", index=False)
intruder_audit.to_csv(OUT / "FORCE_R102_intruder_and_missing_seed_audit.csv", index=False)
axiom_scan.to_csv(OUT / "FORCE_R102_complement_T_axiom_scan.csv", index=False)
support_truth_table.to_csv(OUT / "FORCE_R102_support_truth_table.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R102_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R102_claim_boundary_matrix.csv", index=False)
theorem_candidate.to_csv(OUT / "FORCE_R102_theorem_candidate.csv", index=False)

verdict = {
    "force_id": "FORCE_R102",
    "title": "Reflection Complement Map Origin Gate",
    "status": verdict_status,
    "two_complement_exact_seed": two_complement_exact_seed,
    "controls_fail": controls_fail,
    "T2_unique_exact_in_scan": T2_unique_exact_in_scan,
    "T2_satisfies_all_axioms": T2_satisfies_all_axioms,
    "identity_fixed_forces_T2": identity_fixed_forces_T2,
    "endpoint_boundary_forces_T2": endpoint_boundary_forces_T2,
    "binary_high_support_forces_T2": binary_high_support_forces_T2,
    "trinormal_high_support_forces_T2": trinormal_high_support_forces_T2,
    "field_action_derivation_closed": False,
    "reciprocal_map_derived_here": False,
    "recommended_next": "FORCE_R103_reciprocal_cadence_return_map_origin_gate",
}
(OUT / "FORCE_R102_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R102 — Reflection Complement Map Origin Gate

## Verdict

BOXED: {verdict_status}

## Central result

R102 tests the origin of the reflection map:

BOXED: R(rho)=2-rho

Candidate origin:

BOXED: R is complement/reflection on the doubled closure interval [0,2].

## Why T=2?

In the family R_T(rho)=T-rho, the following all force T=2:

- R_T(1)=1
- R_T(2)=0_boundary
- R_T(3/2)=1/2
- R_T(5/3)=1/3

## Key booleans

- two_complement_exact_seed: {two_complement_exact_seed}
- controls_fail: {controls_fail}
- T2_unique_exact_in_scan: {T2_unique_exact_in_scan}
- T2_satisfies_all_axioms: {T2_satisfies_all_axioms}
- identity_fixed_forces_T2: {identity_fixed_forces_T2}
- endpoint_boundary_forces_T2: {endpoint_boundary_forces_T2}
- binary_high_support_forces_T2: {binary_high_support_forces_T2}
- trinormal_high_support_forces_T2: {trinormal_high_support_forces_T2}

## Gate audit

{audit_df.to_string(index=False)}

## Reflection model scorecard

{scorecard.to_string(index=False)}

## Complement T axiom scan

{axiom_scan.to_string(index=False)}

## Support truth table

{support_truth_table.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Theorem candidate

{theorem_candidate.to_string(index=False)}

## Remaining open item

R102 supports the reflection map at operator/geometric complement level.
It does not derive the full field/action implementation, and it does not derive C(rho)=1/rho.

## Recommended next

BOXED: FORCE_R103 — Reciprocal Cadence-Return Map Origin Gate
"""
(OUT / "FORCE_R102_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R102_reflection_complement_map_origin_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R102_summary.md", "role": "summary"},
    {"file": "FORCE_R102_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R102_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R102_reflection_model_scorecard.csv", "role": "reflection model scorecard"},
    {"file": "FORCE_R102_interval_audit.csv", "role": "interval audit"},
    {"file": "FORCE_R102_intruder_and_missing_seed_audit.csv", "role": "intruder audit"},
    {"file": "FORCE_R102_complement_T_axiom_scan.csv", "role": "complement T axiom scan"},
    {"file": "FORCE_R102_support_truth_table.csv", "role": "support truth table"},
    {"file": "FORCE_R102_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R102_theorem_candidate.csv", "role": "theorem candidate"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(12, 5))
plt.bar(scorecard["model"], scorecard["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xticks(rotation=35, ha="right")
plt.ylabel("final stable count")
plt.title("R102 reflection-map controls")
plt.tight_layout()
plt.savefig(PLOTS / "reflection_model_stable_counts.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(axiom_scan["T"], axiom_scan["axiom_count"])
plt.xlabel("T in R_T(rho)=T-rho")
plt.ylabel("axiom count")
plt.title("R102 complement total scan: T=2 satisfies all tested axioms")
plt.tight_layout()
plt.savefig(PLOTS / "complement_T_axiom_scan.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

compact_scorecard = scorecard[[
    "model", "R_kind", "T", "support_domain_count_final",
    "stable_count_final", "stable_fractions_final",
    "exact_seed_all_denominators", "survivor_status"
]]

compact_axiom = axiom_scan[[
    "T", "R_formula", "stable_count", "stable_fractions", "exact_seed",
    "identity_fixed_R1_eq_1", "endpoint_R2_eq_0_boundary",
    "binary_high_R3_2_eq_1_2", "trinormal_high_R5_3_eq_1_3",
    "axiom_count"
]]

print("\n=== COPY/PASTE R102 RESULT ===")
print("R102 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"two_complement_exact_seed: {two_complement_exact_seed}")
print(f"controls_fail: {controls_fail}")
print(f"T2_unique_exact_in_scan: {T2_unique_exact_in_scan}")
print(f"T2_satisfies_all_axioms: {T2_satisfies_all_axioms}")
print(f"identity_fixed_forces_T2: {identity_fixed_forces_T2}")
print(f"endpoint_boundary_forces_T2: {endpoint_boundary_forces_T2}")
print(f"binary_high_support_forces_T2: {binary_high_support_forces_T2}")
print(f"trinormal_high_support_forces_T2: {trinormal_high_support_forces_T2}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("REFLECTION_MODEL_SCORECARD:")
print(compact_scorecard.to_string(index=False))
print("COMPLEMENT_T_AXIOM_SCAN:")
print(compact_axiom.to_string(index=False))
print("SUPPORT_TRUTH_TABLE:")
print(support_truth_table.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("INTRUDER_AND_MISSING_SEED_AUDIT:")
print(intruder_audit.to_string(index=False) if len(intruder_audit) else "none")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R102_summary.md').resolve()}")
print("NEXT: FORCE_R103_reciprocal_cadence_return_map_origin_gate")
print("=== END COPY/PASTE R102 RESULT ===\n")
