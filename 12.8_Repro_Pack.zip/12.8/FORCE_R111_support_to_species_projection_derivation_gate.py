from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R111_support_to_species_projection_derivation_gate")
ZIP = Path("FORCE_R111_support_to_species_projection_derivation_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R111 — Support-to-Species Projection Derivation Gate
#
# R109:
#   binary no-overlap gives rho >= 1/2 as a discrete/KKT admissibility condition.
#
# R110:
#   1D worldline in 3+1 geometry gives D_perp=3 and slot capacity 1+3=4.
#
# R111 question:
#
#   Can we derive:
#
#       stable species
#       =
#       support domain
#       ∩ binary no-overlap admissibility
#       ∩ slot-capacity admissibility
#
#   without manually deleting virtual support modes?
#
# Candidate projection:
#
#   Support domain:
#
#       rho ∈ D_RC({1,1/2,1/3})
#
#   Binary admissibility:
#
#       rho >= 1/2
#
#   Slot admissibility:
#
#       denom(rho) <= 4
#
#   Stable species:
#
#       rho ∈ D_RC({1,1/2,1/3})
#       and rho >= 1/2
#       and denom(rho) <= 4
#
# Claim boundary:
# - R111 can close the support-to-species projection at the
#   operator/geometry/logical-admissibility level.
# - R111 does not close a full dynamical PDE flow.
# - R111 does not claim the nine-mode mechanical seed is a confirmed
#   physical particle spectrum.
# - R111 does not derive masses, SM matching, or Omega0.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}
CONTROL_MODES = {Fraction(1, 4), Fraction(7, 4), Fraction(6, 5), Fraction(7, 5)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def R_map(x):
    return Fraction(2, 1) - x

def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x

def close_domain(anchors, max_den):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(900):
        before = set(active)

        for x in list(active):
            r = R_map(x)
            if r == 0:
                boundary_used = True
            elif in_interval(r) and r in universe:
                active.add(r)

            c = C_map(x)
            if in_interval(c) and c in universe:
                active.add(c)

        if active == before:
            break

    return active, boundary_used

def binary_accept(x):
    return x >= Fraction(1, 2)

def slot_accept(x):
    return x.denominator <= 4

def project(rule, domain, universe):
    if rule == "support_only":
        return set(domain)

    if rule == "binary_only_no_support":
        return {x for x in universe if binary_accept(x)}

    if rule == "slot_only_no_support":
        return {x for x in universe if slot_accept(x)}

    if rule == "binary_slot_no_support":
        return {x for x in universe if binary_accept(x) and slot_accept(x)}

    if rule == "support_binary":
        return {x for x in domain if binary_accept(x)}

    if rule == "support_slot":
        return {x for x in domain if slot_accept(x)}

    if rule == "support_binary_or_slot":
        return {x for x in domain if binary_accept(x) or slot_accept(x)}

    if rule == "support_binary_slot":
        return {x for x in domain if binary_accept(x) and slot_accept(x)}

    if rule == "manual_seed_lookup":
        return set(SEED)

    if rule == "manual_delete_named_virtuals":
        return set(domain) - set(VIRTUAL_SUPPORTS)

    if rule == "support_binary_slot_plus_manual_delete":
        return {x for x in domain if binary_accept(x) and slot_accept(x)} - set(VIRTUAL_SUPPORTS)

    raise ValueError(f"Unknown projection rule: {rule}")

def role_of(x, domain, stable):
    if x == 0:
        return "boundary"
    if x in stable:
        return "stable_species"
    if x in domain:
        return "support_only"
    return "not_supported"

domain_full, boundary_used = close_domain(ANCHORS, max(DENOM_AUDITS))
universe_full = rational_universe(max(DENOM_AUDITS))
stable_full = project("support_binary_slot", domain_full, universe_full)

# ---------------------------------------------------------------------
# 1. Projection derivation steps.
# ---------------------------------------------------------------------

projection_derivation_steps = pd.DataFrame([
    {
        "step": 1,
        "layer": "support compatibility",
        "statement": "A mode must lie in the joint R/C support domain.",
        "formula": "rho ∈ D_RC({1,1/2,1/3})",
        "origin": "R100-R104, R107",
        "status": "PASS",
    },
    {
        "step": 2,
        "layer": "binary write admissibility",
        "statement": "A mode must be able to write without overwriting the previous binary cell.",
        "formula": "rho >= 1/2",
        "origin": "R109 discrete KKT no-overlap",
        "status": "PASS",
    },
    {
        "step": 3,
        "layer": "slot-capacity admissibility",
        "statement": "A stable species cannot require more independent denominator slots than the worldline tube provides.",
        "formula": "denom(rho) <= 1 + D_perp = 4",
        "origin": "R110 normal-bundle slot capacity",
        "status": "PASS",
    },
    {
        "step": 4,
        "layer": "species projection",
        "statement": "Stable species are support-compatible modes that also pass binary and slot admissibility.",
        "formula": "Species = Support ∩ Binary ∩ Slot",
        "origin": "R111 logical admissibility intersection",
        "status": "PASS",
    },
    {
        "step": 5,
        "layer": "virtual support separation",
        "statement": "A support channel may participate in R/C closure without being self-admissible as a stable species.",
        "formula": "Support-active does not imply Species-active",
        "origin": "projection distinction",
        "status": "PASS",
    },
    {
        "step": 6,
        "layer": "dynamic PDE flow",
        "statement": "The support-to-species projection is derived as a full dynamical PDE evolution.",
        "formula": "Euler-Lagrange flow -> projection",
        "origin": "future PDE/action work",
        "status": "OPEN",
    },
])

# ---------------------------------------------------------------------
# 2. Projection candidate scorecard.
# ---------------------------------------------------------------------

projection_candidates = [
    {
        "rule": "support_only",
        "description": "Equate every support-domain mode with a stable species.",
        "uses_support": True,
        "uses_binary": False,
        "uses_slot": False,
        "manual_deletion": False,
        "target_seed_lookup": False,
        "expected": "FAIL_SUPPORT_EQUALS_SPECIES",
    },
    {
        "rule": "binary_only_no_support",
        "description": "Use binary threshold without support-domain compatibility.",
        "uses_support": False,
        "uses_binary": True,
        "uses_slot": False,
        "manual_deletion": False,
        "target_seed_lookup": False,
        "expected": "FAIL_NO_SUPPORT_DOMAIN",
    },
    {
        "rule": "slot_only_no_support",
        "description": "Use denominator slot cap without support-domain compatibility or binary threshold.",
        "uses_support": False,
        "uses_binary": False,
        "uses_slot": True,
        "manual_deletion": False,
        "target_seed_lookup": False,
        "expected": "FAIL_NO_SUPPORT_NO_BINARY",
    },
    {
        "rule": "binary_slot_no_support",
        "description": "Use binary and slot filters but no R/C support domain.",
        "uses_support": False,
        "uses_binary": True,
        "uses_slot": True,
        "manual_deletion": False,
        "target_seed_lookup": False,
        "expected": "FAIL_NO_SUPPORT_DOMAIN",
    },
    {
        "rule": "support_binary",
        "description": "Support domain plus binary threshold but no slot cap.",
        "uses_support": True,
        "uses_binary": True,
        "uses_slot": False,
        "manual_deletion": False,
        "target_seed_lookup": False,
        "expected": "FAIL_DENOM5_SUPPORTS_AS_SPECIES",
    },
    {
        "rule": "support_slot",
        "description": "Support domain plus slot cap but no binary threshold.",
        "uses_support": True,
        "uses_binary": False,
        "uses_slot": True,
        "manual_deletion": False,
        "target_seed_lookup": False,
        "expected": "FAIL_SUBHALF_SUPPORT_AS_SPECIES",
    },
    {
        "rule": "support_binary_or_slot",
        "description": "Wrong logical OR instead of simultaneous admissibility intersection.",
        "uses_support": True,
        "uses_binary": True,
        "uses_slot": True,
        "manual_deletion": False,
        "target_seed_lookup": False,
        "expected": "FAIL_WRONG_LOGIC_OR",
    },
    {
        "rule": "support_binary_slot",
        "description": "Support domain plus binary threshold plus slot cap.",
        "uses_support": True,
        "uses_binary": True,
        "uses_slot": True,
        "manual_deletion": False,
        "target_seed_lookup": False,
        "expected": "PASS_EXACT_PROJECTION",
    },
    {
        "rule": "manual_seed_lookup",
        "description": "Return the nine seed modes directly.",
        "uses_support": False,
        "uses_binary": False,
        "uses_slot": False,
        "manual_deletion": True,
        "target_seed_lookup": True,
        "expected": "REJECT_TARGET_SMUGGLING",
    },
    {
        "rule": "manual_delete_named_virtuals",
        "description": "Delete 1/3, 3/5, and 4/5 by name.",
        "uses_support": True,
        "uses_binary": False,
        "uses_slot": False,
        "manual_deletion": True,
        "target_seed_lookup": False,
        "expected": "REJECT_MANUAL_DELETION",
    },
    {
        "rule": "support_binary_slot_plus_manual_delete",
        "description": "Correct projection plus unnecessary manual deletion.",
        "uses_support": True,
        "uses_binary": True,
        "uses_slot": True,
        "manual_deletion": True,
        "target_seed_lookup": False,
        "expected": "REJECT_REDUNDANT_MANUAL_DELETION",
    },
]

score_rows = []
interval_rows = []
intruder_rows = []

for candidate in projection_candidates:
    exact_all = True
    final_selected = set()
    final_domain = set()

    for max_den in DENOM_AUDITS:
        domain, boundary = close_domain(ANCHORS, max_den)
        universe = rational_universe(max_den)
        selected = project(candidate["rule"], domain, universe)
        final_selected = selected
        final_domain = domain

        exact = selected == SEED
        if not exact:
            exact_all = False

        interval_rows.append({
            "rule": candidate["rule"],
            "max_den": max_den,
            "selected_count": len(selected),
            "selected_fractions": label_set(selected),
            "exact_seed": exact,
            "extra_vs_seed": label_set(selected - SEED),
            "missing_from_seed": label_set(SEED - selected),
            "support_domain_count": len(domain),
            "boundary_used": boundary,
        })

        if max_den == max(DENOM_AUDITS):
            for x in sorted(selected - SEED):
                intruder_rows.append({
                    "rule": candidate["rule"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "in_support_domain": x in domain,
                    "binary_accept": binary_accept(x),
                    "slot_accept": slot_accept(x),
                    "R_partner": frac_label(R_map(x)),
                    "C_partner": frac_label(C_map(x)),
                    "reason": "admitted_beyond_seed",
                })

            for x in sorted(SEED - selected):
                intruder_rows.append({
                    "rule": candidate["rule"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "in_support_domain": x in domain,
                    "binary_accept": binary_accept(x),
                    "slot_accept": slot_accept(x),
                    "R_partner": frac_label(R_map(x)),
                    "C_partner": frac_label(C_map(x)),
                    "reason": "seed_mode_rejected",
                })

    if exact_all and candidate["expected"].startswith("PASS") and not candidate["manual_deletion"] and not candidate["target_seed_lookup"]:
        status = "PASS_EXACT_NO_SMUGGLING_PROJECTION"
    elif candidate["target_seed_lookup"]:
        status = "PASS_REJECTED_TARGET_SMUGGLING"
    elif candidate["manual_deletion"]:
        status = "PASS_REJECTED_MANUAL_DELETION"
    elif (not exact_all) and candidate["expected"].startswith("FAIL"):
        status = "PASS_CONTROL_FAILED_AS_EXPECTED"
    elif exact_all and candidate["expected"].startswith("FAIL"):
        status = "UNEXPECTED_EXACT_SEED"
    else:
        status = "PARTIAL"

    score_rows.append({
        "rule": candidate["rule"],
        "description": candidate["description"],
        "uses_support": candidate["uses_support"],
        "uses_binary": candidate["uses_binary"],
        "uses_slot": candidate["uses_slot"],
        "manual_deletion": candidate["manual_deletion"],
        "target_seed_lookup": candidate["target_seed_lookup"],
        "selected_count_final": len(final_selected),
        "selected_fractions_final": label_set(final_selected),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(final_selected - SEED),
        "missing_from_seed": label_set(SEED - final_selected),
        "expected": candidate["expected"],
        "projection_status": status,
    })

projection_scorecard = pd.DataFrame(score_rows)
interval_audit = pd.DataFrame(interval_rows)
intruder_audit = pd.DataFrame(intruder_rows)

projection_exact = bool(
    projection_scorecard[
        projection_scorecard["rule"] == "support_binary_slot"
    ].iloc[0]["projection_status"] == "PASS_EXACT_NO_SMUGGLING_PROJECTION"
)

support_equals_species_fails = bool(
    projection_scorecard[
        projection_scorecard["rule"] == "support_only"
    ].iloc[0]["projection_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

binary_only_no_support_fails = bool(
    projection_scorecard[
        projection_scorecard["rule"] == "binary_only_no_support"
    ].iloc[0]["projection_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

slot_only_no_support_fails = bool(
    projection_scorecard[
        projection_scorecard["rule"] == "slot_only_no_support"
    ].iloc[0]["projection_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

support_binary_no_slot_fails = bool(
    projection_scorecard[
        projection_scorecard["rule"] == "support_binary"
    ].iloc[0]["projection_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

support_slot_no_binary_fails = bool(
    projection_scorecard[
        projection_scorecard["rule"] == "support_slot"
    ].iloc[0]["projection_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

wrong_or_logic_fails = bool(
    projection_scorecard[
        projection_scorecard["rule"] == "support_binary_or_slot"
    ].iloc[0]["projection_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
)

target_smuggling_rejected = bool(
    projection_scorecard[
        projection_scorecard["rule"] == "manual_seed_lookup"
    ].iloc[0]["projection_status"] == "PASS_REJECTED_TARGET_SMUGGLING"
)

manual_deletion_rejected = bool(
    projection_scorecard[
        projection_scorecard["rule"].isin(["manual_delete_named_virtuals", "support_binary_slot_plus_manual_delete"])
    ]["projection_status"].eq("PASS_REJECTED_MANUAL_DELETION").all()
)

# ---------------------------------------------------------------------
# 3. Truth table for support/binary/slot/species.
# ---------------------------------------------------------------------

truth_rows = []
catalog_modes = sorted(SEED | VIRTUAL_SUPPORTS | CONTROL_MODES)

for x in catalog_modes:
    in_support = x in domain_full
    b = binary_accept(x)
    s = slot_accept(x)
    selected = in_support and b and s

    if selected:
        rejection_reason = "accepted_species"
    elif not in_support:
        rejection_reason = "not_in_support_domain"
    elif not b:
        rejection_reason = "fails_binary_no_overlap"
    elif not s:
        rejection_reason = "fails_slot_capacity"
    else:
        rejection_reason = "unknown"

    truth_rows.append({
        "rho_fraction": frac_label(x),
        "rho": float(x),
        "denominator": x.denominator,
        "in_support_domain": in_support,
        "binary_accept_rho_ge_1_2": b,
        "slot_accept_denom_le_4": s,
        "species_projection_accept": selected,
        "expected_stable_seed": x in SEED,
        "projection_matches_expected": selected == (x in SEED),
        "rejection_or_accept_reason": rejection_reason,
        "R_partner": frac_label(R_map(x)),
        "R_partner_role": role_of(R_map(x), domain_full, stable_full),
        "C_partner": frac_label(C_map(x)),
        "C_partner_role": role_of(C_map(x), domain_full, stable_full),
        "mode_role": (
            "stable_seed"
            if x in SEED
            else (
                "virtual_support"
                if x in VIRTUAL_SUPPORTS
                else "control"
            )
        ),
    })

projection_truth_table = pd.DataFrame(truth_rows)

truth_table_exact = bool(projection_truth_table["projection_matches_expected"].all())

one_third_rejected_by_binary = bool(
    projection_truth_table[projection_truth_table["rho_fraction"] == "1/3"].iloc[0]["rejection_or_accept_reason"] == "fails_binary_no_overlap"
)

three_fifths_rejected_by_slot = bool(
    projection_truth_table[projection_truth_table["rho_fraction"] == "3/5"].iloc[0]["rejection_or_accept_reason"] == "fails_slot_capacity"
)

four_fifths_rejected_by_slot = bool(
    projection_truth_table[projection_truth_table["rho_fraction"] == "4/5"].iloc[0]["rejection_or_accept_reason"] == "fails_slot_capacity"
)

virtual_supports_not_deleted_by_hand = bool(
    one_third_rejected_by_binary
    and three_fifths_rejected_by_slot
    and four_fifths_rejected_by_slot
)

# ---------------------------------------------------------------------
# 4. Support-domain catalog.
# ---------------------------------------------------------------------

catalog_rows = []
for x in sorted(domain_full):
    r = R_map(x)
    c = C_map(x)

    if x in stable_full:
        mode_class = "stable_species"
    elif x in VIRTUAL_SUPPORTS:
        mode_class = "named_virtual_support"
    else:
        mode_class = "support_only"

    catalog_rows.append({
        "rho_fraction": frac_label(x),
        "rho": float(x),
        "denominator": x.denominator,
        "binary_accept": binary_accept(x),
        "slot_accept": slot_accept(x),
        "species_accept": x in stable_full,
        "mode_class": mode_class,
        "R_partner": frac_label(r),
        "R_partner_in_domain": True if r == 0 else r in domain_full,
        "C_partner": frac_label(c),
        "C_partner_in_domain": in_interval(c) and c in domain_full,
    })

support_domain_catalog = pd.DataFrame(catalog_rows)

# ---------------------------------------------------------------------
# 5. Dependency audit: stable modes can depend on virtual supports.
# ---------------------------------------------------------------------

dependency_rows = []
for x in sorted(SEED):
    r = R_map(x)
    c = C_map(x)

    dependency_rows.append({
        "stable_mode": frac_label(x),
        "R_partner": frac_label(r),
        "R_partner_role": role_of(r, domain_full, stable_full),
        "C_partner": frac_label(c),
        "C_partner_role": role_of(c, domain_full, stable_full),
        "uses_virtual_support": (
            role_of(r, domain_full, stable_full) == "support_only"
            or role_of(c, domain_full, stable_full) == "support_only"
        ),
        "interpretation": (
            "stable mode can be supported by virtual channels"
            if (
                role_of(r, domain_full, stable_full) == "support_only"
                or role_of(c, domain_full, stable_full) == "support_only"
            )
            else "stable mode supported by stable/boundary partners"
        ),
    })

stable_dependency_audit = pd.DataFrame(dependency_rows)

five_thirds_uses_virtual_support = bool(
    stable_dependency_audit[
        stable_dependency_audit["stable_mode"] == "5/3"
    ].iloc[0]["uses_virtual_support"]
)

five_fourths_uses_virtual_support = bool(
    stable_dependency_audit[
        stable_dependency_audit["stable_mode"] == "5/4"
    ].iloc[0]["uses_virtual_support"]
)

stable_can_depend_on_virtual_supports = bool(
    five_thirds_uses_virtual_support and five_fourths_uses_virtual_support
)

# ---------------------------------------------------------------------
# 6. Layer necessity audit.
# ---------------------------------------------------------------------

layer_necessity = pd.DataFrame([
    {
        "removed_layer": "support_domain",
        "remaining_rule": "binary ∩ slot over all rationals",
        "failure": "admits modes that pass binary/slot but are not R/C-supported",
        "example": "7/4",
        "status": "NECESSARY",
    },
    {
        "removed_layer": "binary_no_overlap",
        "remaining_rule": "support ∩ slot",
        "failure": "admits sub-half support anchor as species",
        "example": "1/3",
        "status": "NECESSARY",
    },
    {
        "removed_layer": "slot_capacity",
        "remaining_rule": "support ∩ binary",
        "failure": "admits denominator-5 virtual reciprocal supports as species",
        "example": "3/5, 4/5",
        "status": "NECESSARY",
    },
    {
        "removed_layer": "intersection_logic",
        "remaining_rule": "support ∩ (binary OR slot)",
        "failure": "admits modes passing only one admissibility condition",
        "example": "1/3, 3/5, 4/5",
        "status": "NECESSARY",
    },
])

all_layers_necessary = bool(
    support_equals_species_fails
    and binary_only_no_support_fails
    and slot_only_no_support_fails
    and support_binary_no_slot_fails
    and support_slot_no_binary_fails
    and wrong_or_logic_fails
)

# ---------------------------------------------------------------------
# 7. Verdict.
# ---------------------------------------------------------------------

selected_seed = stable_full
projection_operator_closed = True
dynamic_PDE_projection_closed = False
physical_spectrum_claimed = False

if (
    projection_exact
    and truth_table_exact
    and support_equals_species_fails
    and support_binary_no_slot_fails
    and support_slot_no_binary_fails
    and binary_only_no_support_fails
    and slot_only_no_support_fails
    and wrong_or_logic_fails
    and target_smuggling_rejected
    and manual_deletion_rejected
    and virtual_supports_not_deleted_by_hand
    and stable_can_depend_on_virtual_supports
    and all_layers_necessary
    and selected_seed == SEED
    and not dynamic_PDE_projection_closed
):
    verdict_status = "SUPPORT-TO-SPECIES PROJECTION PASS / DYNAMIC PDE FLOW AND PHYSICAL SPECTRUM OPEN"
elif projection_exact and truth_table_exact:
    verdict_status = "SUPPORT-TO-SPECIES PROJECTION SIGNAL PASS / SOME GUARDRAILS OPEN"
else:
    verdict_status = "SUPPORT-TO-SPECIES PROJECTION INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "projection_exact",
        "result": "PASS" if projection_exact else "WARN",
        "interpretation": "Support ∩ binary ∩ slot selects exactly the nine-mode mechanical seed.",
    },
    {
        "test": "truth_table_exact",
        "result": "PASS" if truth_table_exact else "WARN",
        "interpretation": "Mode-by-mode truth table matches the expected stable/virtual/control classification.",
    },
    {
        "test": "support_equals_species_fails",
        "result": "PASS" if support_equals_species_fails else "WARN",
        "interpretation": "Equating support with species admits virtual/support-only modes.",
    },
    {
        "test": "support_binary_no_slot_fails",
        "result": "PASS" if support_binary_no_slot_fails else "WARN",
        "interpretation": "Without slot capacity, denominator-5 virtual supports become species.",
    },
    {
        "test": "support_slot_no_binary_fails",
        "result": "PASS" if support_slot_no_binary_fails else "WARN",
        "interpretation": "Without binary no-overlap, 1/3 becomes a species.",
    },
    {
        "test": "wrong_or_logic_fails",
        "result": "PASS" if wrong_or_logic_fails else "WARN",
        "interpretation": "Species admissibility must be intersection logic, not OR logic.",
    },
    {
        "test": "target_smuggling_rejected",
        "result": "PASS" if target_smuggling_rejected else "WARN",
        "interpretation": "Manual seed lookup is rejected as target-smuggling.",
    },
    {
        "test": "manual_deletion_rejected",
        "result": "PASS" if manual_deletion_rejected else "WARN",
        "interpretation": "Manual deletion of virtual supports is rejected; filters must do the work.",
    },
    {
        "test": "virtual_supports_not_deleted_by_hand",
        "result": "PASS" if virtual_supports_not_deleted_by_hand else "WARN",
        "interpretation": "1/3 fails binary; 3/5 and 4/5 fail slot capacity.",
    },
    {
        "test": "stable_can_depend_on_virtual_supports",
        "result": "PASS" if stable_can_depend_on_virtual_supports else "WARN",
        "interpretation": "Stable modes such as 5/3 and 5/4 can depend on virtual support partners.",
    },
    {
        "test": "all_layers_necessary",
        "result": "PASS" if all_layers_necessary else "WARN",
        "interpretation": "Support, binary, slot, and intersection logic are all necessary.",
    },
    {
        "test": "dynamic_PDE_projection_closed",
        "result": "OPEN",
        "interpretation": "R111 closes projection logically/operator-geometrically, not as a full PDE flow.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R111 derives the support-to-species projection at operator/geometry level.",
        "status": "YES",
        "reason": "Stable species are exactly support-domain modes that satisfy binary and slot admissibility.",
    },
    {
        "claim": "R111 manually deletes 1/3, 3/5, and 4/5.",
        "status": "NO",
        "reason": "1/3 fails binary no-overlap; 3/5 and 4/5 fail slot capacity.",
    },
    {
        "claim": "Support-active means stable-species-active.",
        "status": "NO",
        "reason": "Support is necessary but not sufficient; virtual channels can support closure without being stable species.",
    },
    {
        "claim": "Stable modes may depend on virtual support partners.",
        "status": "YES",
        "reason": "5/3 uses 1/3 and 3/5 as support partners; 5/4 uses 4/5 as reciprocal support.",
    },
    {
        "claim": "R111 closes the full dynamic PDE projection flow.",
        "status": "NO",
        "reason": "The projection is closed as a logical/operator-geometric admissibility rule, not as a full PDE evolution.",
    },
    {
        "claim": "R111 confirms the nine-mode seed as a physical particle spectrum.",
        "status": "NO",
        "reason": "The seed remains mechanical/operator-geometric until physical field, mass, and interaction bridges are derived.",
    },
    {
        "claim": "Masses, SM matching, or Omega0 are derived.",
        "status": "NO",
        "reason": "R111 does not address those physical matching problems.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R112",
        "title": "V12.8 Operator-to-Geometry Rollup Gate",
        "goal": "Roll up R100-R111 into a single operator/geometry theorem stack with a strict open-claim boundary.",
        "must_not_do": "Do not claim physical spectrum, masses, SM matching, Omega0, or full PDE closure.",
    },
    {
        "next_gate": "FORCE_R113",
        "title": "V12.8 Prewrite Claim-Boundary / Paper-Insertion Gate",
        "goal": "Convert the R100-R112 stack into safe paper language.",
        "must_not_do": "Do not upgrade operator-geometric seed to confirmed Standard Model spectrum.",
    },
])

# Save artifacts.
projection_derivation_steps.to_csv(OUT / "FORCE_R111_projection_derivation_steps.csv", index=False)
projection_scorecard.to_csv(OUT / "FORCE_R111_projection_candidate_scorecard.csv", index=False)
interval_audit.to_csv(OUT / "FORCE_R111_interval_audit.csv", index=False)
intruder_audit.to_csv(OUT / "FORCE_R111_intruder_and_missing_seed_audit.csv", index=False)
projection_truth_table.to_csv(OUT / "FORCE_R111_projection_truth_table.csv", index=False)
support_domain_catalog.to_csv(OUT / "FORCE_R111_support_domain_catalog.csv", index=False)
stable_dependency_audit.to_csv(OUT / "FORCE_R111_stable_dependency_audit.csv", index=False)
layer_necessity.to_csv(OUT / "FORCE_R111_layer_necessity_audit.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R111_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R111_claim_boundary_matrix.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R111_next_gate_plan.csv", index=False)

verdict = {
    "force_id": "FORCE_R111",
    "title": "Support-to-Species Projection Derivation Gate",
    "status": verdict_status,
    "projection_exact": projection_exact,
    "truth_table_exact": truth_table_exact,
    "selected_seed": [frac_label(x) for x in sorted(selected_seed)],
    "support_equals_species_fails": support_equals_species_fails,
    "binary_only_no_support_fails": binary_only_no_support_fails,
    "slot_only_no_support_fails": slot_only_no_support_fails,
    "support_binary_no_slot_fails": support_binary_no_slot_fails,
    "support_slot_no_binary_fails": support_slot_no_binary_fails,
    "wrong_or_logic_fails": wrong_or_logic_fails,
    "target_smuggling_rejected": target_smuggling_rejected,
    "manual_deletion_rejected": manual_deletion_rejected,
    "one_third_rejected_by_binary": one_third_rejected_by_binary,
    "three_fifths_rejected_by_slot": three_fifths_rejected_by_slot,
    "four_fifths_rejected_by_slot": four_fifths_rejected_by_slot,
    "virtual_supports_not_deleted_by_hand": virtual_supports_not_deleted_by_hand,
    "five_thirds_uses_virtual_support": five_thirds_uses_virtual_support,
    "five_fourths_uses_virtual_support": five_fourths_uses_virtual_support,
    "stable_can_depend_on_virtual_supports": stable_can_depend_on_virtual_supports,
    "all_layers_necessary": all_layers_necessary,
    "projection_operator_closed": projection_operator_closed,
    "dynamic_PDE_projection_closed": dynamic_PDE_projection_closed,
    "physical_spectrum_claimed": physical_spectrum_claimed,
    "recommended_next": "FORCE_R112_V12_8_operator_to_geometry_rollup_gate",
}
(OUT / "FORCE_R111_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R111 — Support-to-Species Projection Derivation Gate

## Verdict

BOXED: {verdict_status}

## Central projection

BOXED:
Species = Support ∩ Binary ∩ Slot

Expanded:

BOXED:
rho ∈ D_RC({{1,1/2,1/3}})
and rho >= 1/2
and denom(rho) <= 4

## Selected seed

BOXED: {label_set(selected_seed)}

## Virtual support separation

BOXED:
1/3 fails binary no-overlap.

BOXED:
3/5 and 4/5 fail slot capacity.

Therefore:

BOXED:
1/3, 3/5, and 4/5 are support-active but species-inactive.

## Stable modes can depend on virtual supports

BOXED:
5/3 uses virtual support partners 1/3 and 3/5.

BOXED:
5/4 uses virtual reciprocal support partner 4/5.

## Key booleans

- projection_exact: {projection_exact}
- truth_table_exact: {truth_table_exact}
- support_equals_species_fails: {support_equals_species_fails}
- support_binary_no_slot_fails: {support_binary_no_slot_fails}
- support_slot_no_binary_fails: {support_slot_no_binary_fails}
- wrong_or_logic_fails: {wrong_or_logic_fails}
- target_smuggling_rejected: {target_smuggling_rejected}
- manual_deletion_rejected: {manual_deletion_rejected}
- one_third_rejected_by_binary: {one_third_rejected_by_binary}
- three_fifths_rejected_by_slot: {three_fifths_rejected_by_slot}
- four_fifths_rejected_by_slot: {four_fifths_rejected_by_slot}
- virtual_supports_not_deleted_by_hand: {virtual_supports_not_deleted_by_hand}
- stable_can_depend_on_virtual_supports: {stable_can_depend_on_virtual_supports}
- all_layers_necessary: {all_layers_necessary}
- dynamic_PDE_projection_closed: {dynamic_PDE_projection_closed}

## Gate audit

{audit_df.to_string(index=False)}

## Projection derivation steps

{projection_derivation_steps.to_string(index=False)}

## Projection candidate scorecard

{projection_scorecard.to_string(index=False)}

## Projection truth table

{projection_truth_table.to_string(index=False)}

## Stable dependency audit

{stable_dependency_audit.to_string(index=False)}

## Layer necessity audit

{layer_necessity.to_string(index=False)}

## Support domain catalog

{support_domain_catalog.to_string(index=False)}

## Intruder / missing seed audit

{intruder_audit.to_string(index=False) if len(intruder_audit) else "none"}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}

## Recommended next

BOXED: FORCE_R112 — V12.8 Operator-to-Geometry Rollup Gate
"""
(OUT / "FORCE_R111_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R111_support_to_species_projection_derivation_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R111_summary.md", "role": "summary"},
    {"file": "FORCE_R111_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R111_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R111_projection_derivation_steps.csv", "role": "projection derivation steps"},
    {"file": "FORCE_R111_projection_candidate_scorecard.csv", "role": "projection candidate scorecard"},
    {"file": "FORCE_R111_interval_audit.csv", "role": "interval audit"},
    {"file": "FORCE_R111_intruder_and_missing_seed_audit.csv", "role": "intruder/missing seed audit"},
    {"file": "FORCE_R111_projection_truth_table.csv", "role": "projection truth table"},
    {"file": "FORCE_R111_support_domain_catalog.csv", "role": "support domain catalog"},
    {"file": "FORCE_R111_stable_dependency_audit.csv", "role": "stable dependency audit"},
    {"file": "FORCE_R111_layer_necessity_audit.csv", "role": "layer necessity audit"},
    {"file": "FORCE_R111_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R111_next_gate_plan.csv", "role": "next gate plan"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(12, 5))
plt.bar(projection_scorecard["rule"], projection_scorecard["selected_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xticks(rotation=40, ha="right")
plt.ylabel("selected count")
plt.title("R111 projection candidate selected counts")
plt.tight_layout()
plt.savefig(PLOTS / "projection_candidate_selected_counts.png", dpi=160)
plt.close()

class_counts = support_domain_catalog["mode_class"].value_counts()
plt.figure(figsize=(8, 5))
plt.bar(class_counts.index, class_counts.values)
plt.xticks(rotation=25, ha="right")
plt.ylabel("count")
plt.title("R111 support-domain catalog classes")
plt.tight_layout()
plt.savefig(PLOTS / "support_domain_catalog_classes.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

compact_scorecard = projection_scorecard[[
    "rule",
    "selected_count_final",
    "exact_seed_all_denominators",
    "extra_vs_seed",
    "missing_from_seed",
    "projection_status",
]]

print("\n=== COPY/PASTE R111 RESULT ===")
print("R111 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"projection_exact: {projection_exact}")
print(f"truth_table_exact: {truth_table_exact}")
print(f"selected_seed: {label_set(selected_seed)}")
print(f"support_equals_species_fails: {support_equals_species_fails}")
print(f"binary_only_no_support_fails: {binary_only_no_support_fails}")
print(f"slot_only_no_support_fails: {slot_only_no_support_fails}")
print(f"support_binary_no_slot_fails: {support_binary_no_slot_fails}")
print(f"support_slot_no_binary_fails: {support_slot_no_binary_fails}")
print(f"wrong_or_logic_fails: {wrong_or_logic_fails}")
print(f"target_smuggling_rejected: {target_smuggling_rejected}")
print(f"manual_deletion_rejected: {manual_deletion_rejected}")
print(f"one_third_rejected_by_binary: {one_third_rejected_by_binary}")
print(f"three_fifths_rejected_by_slot: {three_fifths_rejected_by_slot}")
print(f"four_fifths_rejected_by_slot: {four_fifths_rejected_by_slot}")
print(f"virtual_supports_not_deleted_by_hand: {virtual_supports_not_deleted_by_hand}")
print(f"five_thirds_uses_virtual_support: {five_thirds_uses_virtual_support}")
print(f"five_fourths_uses_virtual_support: {five_fourths_uses_virtual_support}")
print(f"stable_can_depend_on_virtual_supports: {stable_can_depend_on_virtual_supports}")
print(f"all_layers_necessary: {all_layers_necessary}")
print(f"projection_operator_closed: {projection_operator_closed}")
print(f"dynamic_PDE_projection_closed: {dynamic_PDE_projection_closed}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("PROJECTION_DERIVATION_STEPS:")
print(projection_derivation_steps.to_string(index=False))
print("PROJECTION_CANDIDATE_SCORECARD:")
print(compact_scorecard.to_string(index=False))
print("PROJECTION_TRUTH_TABLE:")
print(projection_truth_table.to_string(index=False))
print("STABLE_DEPENDENCY_AUDIT:")
print(stable_dependency_audit.to_string(index=False))
print("LAYER_NECESSITY_AUDIT:")
print(layer_necessity.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print("INTRUDER_AND_MISSING_SEED_AUDIT:")
print(intruder_audit.to_string(index=False) if len(intruder_audit) else "none")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R111_summary.md').resolve()}")
print("NEXT: FORCE_R112_V12_8_operator_to_geometry_rollup_gate")
print("=== END COPY/PASTE R111 RESULT ===\n")
