from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R109_discrete_binary_no_overlap_variation_gate")
ZIP = Path("FORCE_R109_discrete_binary_no_overlap_variation_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R109 — Discrete Binary No-Overlap Variation Gate
#
# R108 result:
#   Locality / gauge-frame relabeling passed.
#
# Remaining open item:
#   binary no-overlap variation.
#
# R109 question:
#
#   Can rho >= 1/2 be obtained as a discrete variational/KKT
#   no-overlap condition rather than as a declared projector?
#
# Candidate:
#
#   Binary write cell width:
#
#       w = 1/2
#
#   Previous write cell:
#
#       W_0 = [0,w]
#
#   Next write cell:
#
#       W_rho = [rho, rho+w]
#
#   No-overlap inequality on the unwrapped write ledger:
#
#       g(rho) = rho - w >= 0
#
#   Minimal-advance KKT problem:
#
#       minimize 1/2 k rho^2
#       subject to rho - w >= 0
#
#   KKT Lagrangian:
#
#       L = 1/2 k rho^2 - mu (rho-w)
#
#   Conditions:
#
#       stationarity: k rho - mu = 0
#       feasibility: rho - w >= 0
#       dual feasibility: mu >= 0
#       complementarity: mu(rho-w)=0
#
#   Minimal admissible solution:
#
#       rho_* = w
#       mu_* = k w
#
#   For binary w=1/2:
#
#       rho_* = 1/2
#
#   The admissible species filter is then:
#
#       rho >= 1/2
#
# Claim boundary:
# - R109 derives the threshold from a discrete inequality/KKT setup
#   conditional on binary-cell width w=1/2.
# - R109 does not newly derive K=2 from scratch; it inherits the binary
#   predicate result from the no-overwrite record stack.
# - R109 does not close the smooth PDE derivation.
# - R109 does not derive D_perp=3, slot capacity, or support/species projection.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def R_map(x):
    return Fraction(2, 1) - x

def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x

def close_domain(anchors, max_den):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(900):
        before = set(active)
        for x in list(active):
            r = R_map(x)
            if r == 0:
                boundary_used = True
            elif in_interval(r) and r in universe:
                active.add(r)

            c = C_map(x)
            if in_interval(c) and c in universe:
                active.add(c)

        if active == before:
            break

    return active, boundary_used

def stable_by_threshold(domain, max_den, threshold, direction="ge", slot_cap=4):
    universe = rational_universe(max_den)
    stable = set()

    for x in universe:
        if x not in domain:
            continue

        if direction == "ge":
            if x < threshold:
                continue
        elif direction == "le":
            if x > threshold:
                continue
        elif direction == "none":
            pass
        else:
            raise ValueError(f"Unknown direction: {direction}")

        if slot_cap is not None and x.denominator > slot_cap:
            continue

        stable.add(x)

    return stable

def kkt_solution_for_width(w, k=Fraction(1, 1)):
    rho_star = w
    mu_star = k * w
    stationarity = k * rho_star - mu_star
    feasibility = rho_star - w
    complementarity = mu_star * (rho_star - w)
    return {
        "rho_star": rho_star,
        "mu_star": mu_star,
        "stationarity_residual": stationarity,
        "feasibility_boundary_residual": feasibility,
        "complementarity_residual": complementarity,
        "dual_feasible": mu_star >= 0,
        "primal_feasible": rho_star >= w,
    }

domain_full, boundary_used = close_domain(ANCHORS, max(DENOM_AUDITS))

# ---------------------------------------------------------------------
# 1. KKT boundary derivation for K-cell record widths.
# ---------------------------------------------------------------------

kkt_rows = []

for K in range(1, 9):
    w = Fraction(1, K)
    kkt = kkt_solution_for_width(w)
    stable = stable_by_threshold(domain_full, max(DENOM_AUDITS), threshold=w, direction="ge", slot_cap=4)

    if K == 1:
        record_status = "FAIL_UNARY_CANNOT_ANSWER_YES_NO"
    elif K == 2:
        record_status = "PASS_BINARY_MINIMAL_NONTRIVIAL"
    else:
        record_status = "FAIL_SURPLUS_RECORD_LABELS"

    kkt_rows.append({
        "K_record_cells": K,
        "cell_width_w": frac_label(w),
        "rho_star_minimal_nonoverlap": frac_label(kkt["rho_star"]),
        "mu_star": frac_label(kkt["mu_star"]),
        "stationarity_residual": frac_label(kkt["stationarity_residual"]),
        "feasibility_boundary_residual": frac_label(kkt["feasibility_boundary_residual"]),
        "complementarity_residual": frac_label(kkt["complementarity_residual"]),
        "dual_feasible": kkt["dual_feasible"],
        "primal_feasible": kkt["primal_feasible"],
        "KKT_pass": (
            kkt["stationarity_residual"] == 0
            and kkt["feasibility_boundary_residual"] == 0
            and kkt["complementarity_residual"] == 0
            and kkt["dual_feasible"]
            and kkt["primal_feasible"]
        ),
        "record_status": record_status,
        "stable_count": len(stable),
        "stable_fractions": label_set(stable),
        "exact_seed": stable == SEED,
        "extra_vs_seed": label_set(stable - SEED),
        "missing_from_seed": label_set(SEED - stable),
    })

kkt_boundary_audit = pd.DataFrame(kkt_rows)

K2_row = kkt_boundary_audit[kkt_boundary_audit["K_record_cells"] == 2].iloc[0]
K2_KKT_pass = bool(K2_row["KKT_pass"])
K2_operator_exact = bool(K2_row["exact_seed"])
K2_minimal_binary_record = bool(K2_row["record_status"] == "PASS_BINARY_MINIMAL_NONTRIVIAL")

integer_K_controls_fail = bool(
    (
        kkt_boundary_audit[
            kkt_boundary_audit["K_record_cells"] != 2
        ]["exact_seed"] == False
    ).all()
)

# ---------------------------------------------------------------------
# 2. Binary filter/control models.
# ---------------------------------------------------------------------

control_models = [
    {
        "model": "B0_no_binary_inequality",
        "description": "No binary inequality; direction none and threshold 0.",
        "threshold": Fraction(0, 1),
        "direction": "none",
        "slot_cap": 4,
        "expected": "FAIL_SUBHALF_INTRUDER",
    },
    {
        "model": "B1_unary_K1_threshold_1",
        "description": "Unary record K=1 gives w=1; too strict.",
        "threshold": Fraction(1, 1),
        "direction": "ge",
        "slot_cap": 4,
        "expected": "FAIL_MISSING_LOW_BRANCH",
    },
    {
        "model": "B2_binary_K2_threshold_1_2",
        "description": "Binary record K=2 gives w=1/2.",
        "threshold": Fraction(1, 2),
        "direction": "ge",
        "slot_cap": 4,
        "expected": "PASS_EXACT_SEED",
    },
    {
        "model": "B3_ternary_K3_threshold_1_3",
        "description": "Ternary record K=3 gives w=1/3; admits 1/3 support as species.",
        "threshold": Fraction(1, 3),
        "direction": "ge",
        "slot_cap": 4,
        "expected": "FAIL_1_3_INTRUDER",
    },
    {
        "model": "B4_quaternary_K4_threshold_1_4",
        "description": "K=4 gives surplus labels and admits 1/3.",
        "threshold": Fraction(1, 4),
        "direction": "ge",
        "slot_cap": 4,
        "expected": "FAIL_1_3_INTRUDER",
    },
    {
        "model": "B5_wrong_sign_accept_overlap",
        "description": "Wrong inequality accepts rho<=1/2 rather than rho>=1/2.",
        "threshold": Fraction(1, 2),
        "direction": "le",
        "slot_cap": 4,
        "expected": "FAIL_WRONG_SIGN",
    },
    {
        "model": "B6_no_slot_cap_control",
        "description": "Binary threshold kept but slot cap removed.",
        "threshold": Fraction(1, 2),
        "direction": "ge",
        "slot_cap": None,
        "expected": "FAIL_DENOM5_VIRTUAL_SPECIES",
    },
]

control_rows = []
interval_rows = []
intruder_rows = []

for model in control_models:
    exact_all = True
    final_stable = set()
    final_domain = set()

    for max_den in DENOM_AUDITS:
        domain, boundary = close_domain(ANCHORS, max_den)
        stable = stable_by_threshold(
            domain,
            max_den,
            threshold=model["threshold"],
            direction=model["direction"],
            slot_cap=model["slot_cap"],
        )
        final_stable = stable
        final_domain = domain

        exact = stable == SEED
        if not exact:
            exact_all = False

        interval_rows.append({
            "model": model["model"],
            "max_den": max_den,
            "threshold": frac_label(model["threshold"]),
            "direction": model["direction"],
            "slot_cap": model["slot_cap"] if model["slot_cap"] is not None else "none",
            "support_domain_count": len(domain),
            "stable_count": len(stable),
            "stable_fractions": label_set(stable),
            "exact_seed": exact,
            "extra_vs_seed": label_set(stable - SEED),
            "missing_from_seed": label_set(SEED - stable),
            "boundary_used": boundary,
        })

        if max_den == DENOM_AUDITS[-1]:
            for x in sorted(stable - SEED):
                intruder_rows.append({
                    "model": model["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": frac_label(R_map(x)),
                    "C_partner": frac_label(C_map(x)),
                    "reason": "admitted_beyond_seed",
                })
            for x in sorted(SEED - stable):
                intruder_rows.append({
                    "model": model["model"],
                    "fraction": frac_label(x),
                    "rho": float(x),
                    "denominator": x.denominator,
                    "R_partner": frac_label(R_map(x)),
                    "C_partner": frac_label(C_map(x)),
                    "reason": "seed_mode_rejected",
                })

    if exact_all and model["expected"].startswith("PASS"):
        status = "PASS_EXACT_SEED"
    elif (not exact_all) and model["expected"].startswith("FAIL"):
        status = "PASS_CONTROL_FAILED_AS_EXPECTED"
    elif exact_all and model["expected"].startswith("FAIL"):
        status = "UNEXPECTED_EXACT_SEED"
    else:
        status = "PARTIAL"

    control_rows.append({
        "model": model["model"],
        "description": model["description"],
        "threshold": frac_label(model["threshold"]),
        "direction": model["direction"],
        "slot_cap": model["slot_cap"] if model["slot_cap"] is not None else "none",
        "stable_count_final": len(final_stable),
        "stable_fractions_final": label_set(final_stable),
        "exact_seed_all_denominators": exact_all,
        "extra_vs_seed": label_set(final_stable - SEED),
        "missing_from_seed": label_set(SEED - final_stable),
        "expected": model["expected"],
        "control_status": status,
    })

binary_control_scorecard = pd.DataFrame(control_rows)
interval_audit = pd.DataFrame(interval_rows)
intruder_audit = pd.DataFrame(intruder_rows)

binary_controls_fail = bool(
    (
        binary_control_scorecard[
            binary_control_scorecard["model"] != "B2_binary_K2_threshold_1_2"
        ]["control_status"] == "PASS_CONTROL_FAILED_AS_EXPECTED"
    ).all()
)

binary_candidate_pass = bool(
    binary_control_scorecard[
        binary_control_scorecard["model"] == "B2_binary_K2_threshold_1_2"
    ].iloc[0]["control_status"] == "PASS_EXACT_SEED"
)

# ---------------------------------------------------------------------
# 3. Arbitrary width scan: honest guardrail.
# ---------------------------------------------------------------------
#
# This deliberately shows that continuous tuned widths can reproduce
# the same filter. Therefore the width must come from binary record
# cardinality, not from post-hoc tuning.

widths = [
    Fraction(1, 4), Fraction(1, 3), Fraction(2, 5),
    Fraction(7, 16), Fraction(1, 2), Fraction(3, 5),
    Fraction(2, 3), Fraction(3, 4), Fraction(1, 1)
]

width_rows = []
for w in widths:
    stable = stable_by_threshold(domain_full, max(DENOM_AUDITS), threshold=w, direction="ge", slot_cap=4)
    width_rows.append({
        "width": frac_label(w),
        "stable_count": len(stable),
        "stable_fractions": label_set(stable),
        "exact_seed": stable == SEED,
        "extra_vs_seed": label_set(stable - SEED),
        "missing_from_seed": label_set(SEED - stable),
        "valid_binary_record_width": w == Fraction(1, 2),
        "interpretation": (
            "binary-derived width"
            if w == Fraction(1, 2)
            else (
                "tuned exact width; reject unless independently derived"
                if stable == SEED
                else "control width fails exact seed"
            )
        ),
    })

arbitrary_width_scan = pd.DataFrame(width_rows)
exact_tuned_widths = arbitrary_width_scan[
    (arbitrary_width_scan["exact_seed"] == True)
    & (arbitrary_width_scan["valid_binary_record_width"] == False)
]
arbitrary_width_tuning_risk_detected = len(exact_tuned_widths) > 0

# ---------------------------------------------------------------------
# 4. Admissibility truth table.
# ---------------------------------------------------------------------

truth_rows = []
for x in sorted(SEED | VIRTUAL_SUPPORTS | {Fraction(1, 4), Fraction(7, 4), Fraction(6, 5), Fraction(7, 5)}):
    g = x - Fraction(1, 2)
    truth_rows.append({
        "rho_fraction": frac_label(x),
        "rho": float(x),
        "denominator": x.denominator,
        "in_support_domain": x in domain_full,
        "g_rho_minus_1_2": frac_label(g),
        "binary_no_overlap_feasible": g >= 0,
        "slot_accept": x.denominator <= 4,
        "stable_species": x in SEED,
        "selected_by_R109_filter": (
            x in domain_full
            and g >= 0
            and x.denominator <= 4
        ),
        "R_partner": frac_label(R_map(x)),
        "C_partner": frac_label(C_map(x)),
        "role": (
            "stable_seed"
            if x in SEED
            else (
                "virtual_support_rejected"
                if x in VIRTUAL_SUPPORTS
                else "rejected_control"
            )
        ),
    })

admissibility_truth_table = pd.DataFrame(truth_rows)

subhalf_virtual_rejected = bool(
    admissibility_truth_table[
        admissibility_truth_table["rho_fraction"] == "1/3"
    ].iloc[0]["selected_by_R109_filter"] == False
)

denom5_virtual_rejected = bool(
    (
        admissibility_truth_table[
            admissibility_truth_table["rho_fraction"].isin(["3/5", "4/5"])
        ]["selected_by_R109_filter"] == False
    ).all()
)

selected_set = {
    Fraction(row["rho_fraction"])
    for _, row in admissibility_truth_table.iterrows()
    if row["selected_by_R109_filter"]
}
truth_table_exact_seed = selected_set == SEED

# ---------------------------------------------------------------------
# 5. KKT formal statement table.
# ---------------------------------------------------------------------

kkt_formal_statement = pd.DataFrame([
    {
        "step": 1,
        "statement": "Binary record gives two cells.",
        "formula": "K=2",
        "status": "INHERITED_FROM_BINARY_PREDICATE_STACK",
    },
    {
        "step": 2,
        "statement": "Cell width is inverse record count.",
        "formula": "w=1/K=1/2",
        "status": "PASS_CONDITIONAL_ON_K2",
    },
    {
        "step": 3,
        "statement": "No-overlap inequality on unwrapped write ledger.",
        "formula": "g(rho)=rho-w>=0",
        "status": "PASS_DISCRETE_CONSTRAINT",
    },
    {
        "step": 4,
        "statement": "Minimal-advance KKT objective.",
        "formula": "min 1/2 k rho^2 subject to rho-w>=0",
        "status": "PASS_KKT_SETUP",
    },
    {
        "step": 5,
        "statement": "KKT stationarity.",
        "formula": "k rho - mu=0",
        "status": "PASS",
    },
    {
        "step": 6,
        "statement": "Complementarity selects boundary for minimal admissible write.",
        "formula": "mu(rho-w)=0 -> rho*=w",
        "status": "PASS",
    },
    {
        "step": 7,
        "statement": "Binary threshold.",
        "formula": "rho* = 1/2; admissible iff rho>=1/2",
        "status": "PASS",
    },
    {
        "step": 8,
        "statement": "Smooth PDE derivation.",
        "formula": "continuous Euler-Lagrange flow for discrete write update",
        "status": "OPEN",
    },
])

# ---------------------------------------------------------------------
# 6. Verdict.
# ---------------------------------------------------------------------

smooth_PDE_closed = False
K2_origin_newly_derived = False
width_origin_inherited_from_binary_record = True

if (
    K2_KKT_pass
    and K2_operator_exact
    and K2_minimal_binary_record
    and integer_K_controls_fail
    and binary_candidate_pass
    and binary_controls_fail
    and subhalf_virtual_rejected
    and denom5_virtual_rejected
    and truth_table_exact_seed
    and arbitrary_width_tuning_risk_detected
    and width_origin_inherited_from_binary_record
    and not smooth_PDE_closed
):
    verdict_status = "DISCRETE BINARY KKT NO-OVERLAP PASS / WIDTH ORIGIN INHERITED AND SMOOTH PDE DERIVATION OPEN"
elif K2_KKT_pass and K2_operator_exact:
    verdict_status = "DISCRETE BINARY NO-OVERLAP SIGNAL PASS / SOME GUARDRAILS OPEN"
else:
    verdict_status = "DISCRETE BINARY NO-OVERLAP VARIATION INCONCLUSIVE"

audit_df = pd.DataFrame([
    {
        "test": "K2_KKT_pass",
        "result": "PASS" if K2_KKT_pass else "WARN",
        "interpretation": "For binary width w=1/2, KKT stationarity, feasibility, dual feasibility, and complementarity pass.",
    },
    {
        "test": "K2_operator_exact",
        "result": "PASS" if K2_operator_exact else "WARN",
        "interpretation": "The binary K=2 threshold reconstructs the exact nine-mode seed with the R/C domain and slot filter.",
    },
    {
        "test": "integer_K_controls_fail",
        "result": "PASS" if integer_K_controls_fail else "WARN",
        "interpretation": "K=1 is too strict; K>=3 admits surplus/subhalf structure or otherwise fails exact recovery.",
    },
    {
        "test": "binary_controls_fail",
        "result": "PASS" if binary_controls_fail else "WARN",
        "interpretation": "No-binary, wrong-sign, no-slot, and non-binary record controls fail.",
    },
    {
        "test": "subhalf_virtual_rejected",
        "result": "PASS" if subhalf_virtual_rejected else "WARN",
        "interpretation": "The 1/3 tri-normal support channel is rejected as a species by rho>=1/2.",
    },
    {
        "test": "denom5_virtual_rejected",
        "result": "PASS" if denom5_virtual_rejected else "WARN",
        "interpretation": "3/5 and 4/5 remain rejected as species by the slot filter.",
    },
    {
        "test": "truth_table_exact_seed",
        "result": "PASS" if truth_table_exact_seed else "WARN",
        "interpretation": "The R109 admissibility truth table selects exactly the nine-mode seed.",
    },
    {
        "test": "arbitrary_width_tuning_risk_detected",
        "result": "PASS" if arbitrary_width_tuning_risk_detected else "WARN",
        "interpretation": "Arbitrary tuned widths can also work; therefore width must come from binary record cardinality, not fitting.",
    },
    {
        "test": "K2_origin_newly_derived",
        "result": "OPEN",
        "interpretation": "R109 inherits K=2 from the binary predicate/no-overwrite stack; it does not newly derive K=2 from smooth PDE.",
    },
    {
        "test": "smooth_PDE_closed",
        "result": "OPEN",
        "interpretation": "R109 is a discrete/KKT variational gate, not a smooth PDE derivation.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "R109 derives rho>=1/2 as a binary no-overlap KKT admissibility condition.",
        "status": "YES",
        "reason": "Given binary cell width w=1/2, the KKT boundary solution is rho*=1/2 and admissibility is rho>=1/2.",
    },
    {
        "claim": "R109 newly derives K=2 from scratch.",
        "status": "NO",
        "reason": "K=2 is inherited from the binary no-overwrite predicate stack; R109 derives the threshold once w=1/2 is supplied.",
    },
    {
        "claim": "R109 deletes sub-half modes by hand.",
        "status": "NO",
        "reason": "Sub-half modes violate the no-overlap inequality rho-w>=0.",
    },
    {
        "claim": "Arbitrary tuned widths are acceptable.",
        "status": "NO",
        "reason": "The scan detects tuned-width risk; acceptable width must be record-cardinality-derived.",
    },
    {
        "claim": "R109 closes the smooth PDE derivation of binary writing.",
        "status": "NO",
        "reason": "The result is a discrete/KKT variational condition, not a smooth PDE.",
    },
    {
        "claim": "R109 derives D_perp=3 or slot capacity.",
        "status": "NO",
        "reason": "Those remain assigned to the normal-bundle/slot-capacity gate.",
    },
    {
        "claim": "R109 derives support-to-species projection completely.",
        "status": "NO",
        "reason": "It contributes the binary inequality but does not derive the whole projection map.",
    },
    {
        "claim": "The nine-mode seed is a confirmed physical particle spectrum.",
        "status": "NO",
        "reason": "It remains a mechanical support seed until physical field, mass, and interaction bridges are derived.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R110",
        "title": "Normal-Bundle Dimension / Slot-Capacity Derivation Gate",
        "goal": "Pressure-test whether D_perp=3 and 1+3 slot capacity arise from local worldline-tube geometry.",
        "must_not_do": "Do not insert D_perp=3 merely because it recovers the seed.",
    },
    {
        "next_gate": "FORCE_R111",
        "title": "Support-to-Species Projection Derivation Gate",
        "goal": "Derive why support-active modes become stable species only after binary and slot filters.",
        "must_not_do": "Do not delete 1/3, 3/5, or 4/5 by hand.",
    },
])

# Save artifacts.
kkt_boundary_audit.to_csv(OUT / "FORCE_R109_K_record_KKT_boundary_audit.csv", index=False)
binary_control_scorecard.to_csv(OUT / "FORCE_R109_binary_filter_control_scorecard.csv", index=False)
interval_audit.to_csv(OUT / "FORCE_R109_interval_audit.csv", index=False)
intruder_audit.to_csv(OUT / "FORCE_R109_intruder_and_missing_seed_audit.csv", index=False)
arbitrary_width_scan.to_csv(OUT / "FORCE_R109_arbitrary_width_tuning_scan.csv", index=False)
admissibility_truth_table.to_csv(OUT / "FORCE_R109_admissibility_truth_table.csv", index=False)
kkt_formal_statement.to_csv(OUT / "FORCE_R109_KKT_formal_statement.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R109_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R109_claim_boundary_matrix.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R109_next_gate_plan.csv", index=False)

verdict = {
    "force_id": "FORCE_R109",
    "title": "Discrete Binary No-Overlap Variation Gate",
    "status": verdict_status,
    "K2_KKT_pass": K2_KKT_pass,
    "K2_operator_exact": K2_operator_exact,
    "K2_minimal_binary_record": K2_minimal_binary_record,
    "integer_K_controls_fail": integer_K_controls_fail,
    "binary_candidate_pass": binary_candidate_pass,
    "binary_controls_fail": binary_controls_fail,
    "subhalf_virtual_rejected": subhalf_virtual_rejected,
    "denom5_virtual_rejected": denom5_virtual_rejected,
    "truth_table_exact_seed": truth_table_exact_seed,
    "arbitrary_width_tuning_risk_detected": arbitrary_width_tuning_risk_detected,
    "width_origin_inherited_from_binary_record": width_origin_inherited_from_binary_record,
    "K2_origin_newly_derived": K2_origin_newly_derived,
    "smooth_PDE_closed": smooth_PDE_closed,
    "physical_spectrum_claimed": False,
    "recommended_next": "FORCE_R110_normal_bundle_dimension_slot_capacity_derivation_gate",
}
(OUT / "FORCE_R109_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R109 — Discrete Binary No-Overlap Variation Gate

## Verdict

BOXED: {verdict_status}

## Central result

Given binary write-cell width:

BOXED: w = 1/2

the no-overlap inequality is:

BOXED: g(rho)=rho-w>=0

The minimal-advance KKT problem:

BOXED: minimize 1/2 k rho^2 subject to rho-w>=0

has boundary solution:

BOXED: rho_* = w = 1/2

Therefore admissibility is:

BOXED: rho >= 1/2

## Selected seed

BOXED: {label_set(selected_set)}

## Key booleans

- K2_KKT_pass: {K2_KKT_pass}
- K2_operator_exact: {K2_operator_exact}
- K2_minimal_binary_record: {K2_minimal_binary_record}
- integer_K_controls_fail: {integer_K_controls_fail}
- binary_controls_fail: {binary_controls_fail}
- subhalf_virtual_rejected: {subhalf_virtual_rejected}
- denom5_virtual_rejected: {denom5_virtual_rejected}
- truth_table_exact_seed: {truth_table_exact_seed}
- arbitrary_width_tuning_risk_detected: {arbitrary_width_tuning_risk_detected}
- width_origin_inherited_from_binary_record: {width_origin_inherited_from_binary_record}
- smooth_PDE_closed: {smooth_PDE_closed}

## Gate audit

{audit_df.to_string(index=False)}

## K-record KKT boundary audit

{kkt_boundary_audit.to_string(index=False)}

## Binary filter controls

{binary_control_scorecard.to_string(index=False)}

## Arbitrary width tuning scan

{arbitrary_width_scan.to_string(index=False)}

## Admissibility truth table

{admissibility_truth_table.to_string(index=False)}

## KKT formal statement

{kkt_formal_statement.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}

## Intruder / missing seed audit

{intruder_audit.to_string(index=False) if len(intruder_audit) else "none"}

## Recommended next

BOXED: FORCE_R110 — Normal-Bundle Dimension / Slot-Capacity Derivation Gate
"""
(OUT / "FORCE_R109_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R109_discrete_binary_no_overlap_variation_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R109_summary.md", "role": "summary"},
    {"file": "FORCE_R109_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R109_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R109_K_record_KKT_boundary_audit.csv", "role": "K-record KKT audit"},
    {"file": "FORCE_R109_binary_filter_control_scorecard.csv", "role": "binary filter controls"},
    {"file": "FORCE_R109_interval_audit.csv", "role": "interval audit"},
    {"file": "FORCE_R109_intruder_and_missing_seed_audit.csv", "role": "intruder audit"},
    {"file": "FORCE_R109_arbitrary_width_tuning_scan.csv", "role": "arbitrary width tuning scan"},
    {"file": "FORCE_R109_admissibility_truth_table.csv", "role": "admissibility truth table"},
    {"file": "FORCE_R109_KKT_formal_statement.csv", "role": "KKT formal statement"},
    {"file": "FORCE_R109_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R109_next_gate_plan.csv", "role": "next gate plan"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(9, 5))
plt.bar(kkt_boundary_audit["K_record_cells"].astype(str), kkt_boundary_audit["stable_count"])
plt.axhline(len(SEED), linestyle="--")
plt.xlabel("K record cells")
plt.ylabel("stable count")
plt.title("R109 stable count by record cardinality K")
plt.tight_layout()
plt.savefig(PLOTS / "K_record_stable_counts.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 5))
plt.bar(binary_control_scorecard["model"], binary_control_scorecard["stable_count_final"])
plt.axhline(len(SEED), linestyle="--")
plt.xticks(rotation=35, ha="right")
plt.ylabel("stable count")
plt.title("R109 binary filter controls")
plt.tight_layout()
plt.savefig(PLOTS / "binary_filter_controls.png", dpi=160)
plt.close()

plt.figure(figsize=(9, 5))
plt.bar(arbitrary_width_scan["width"], arbitrary_width_scan["stable_count"])
plt.axhline(len(SEED), linestyle="--")
plt.xlabel("arbitrary width")
plt.ylabel("stable count")
plt.title("R109 arbitrary width tuning risk scan")
plt.tight_layout()
plt.savefig(PLOTS / "arbitrary_width_tuning_scan.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

print("\n=== COPY/PASTE R109 RESULT ===")
print("R109 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"K2_KKT_pass: {K2_KKT_pass}")
print(f"K2_operator_exact: {K2_operator_exact}")
print(f"K2_minimal_binary_record: {K2_minimal_binary_record}")
print(f"integer_K_controls_fail: {integer_K_controls_fail}")
print(f"binary_candidate_pass: {binary_candidate_pass}")
print(f"binary_controls_fail: {binary_controls_fail}")
print(f"selected_seed: {label_set(selected_set)}")
print(f"subhalf_virtual_rejected: {subhalf_virtual_rejected}")
print(f"denom5_virtual_rejected: {denom5_virtual_rejected}")
print(f"truth_table_exact_seed: {truth_table_exact_seed}")
print(f"arbitrary_width_tuning_risk_detected: {arbitrary_width_tuning_risk_detected}")
print(f"width_origin_inherited_from_binary_record: {width_origin_inherited_from_binary_record}")
print(f"K2_origin_newly_derived: {K2_origin_newly_derived}")
print(f"smooth_PDE_closed: {smooth_PDE_closed}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("K_RECORD_KKT_BOUNDARY_AUDIT:")
print(kkt_boundary_audit.to_string(index=False))
print("BINARY_FILTER_CONTROL_SCORECARD:")
print(binary_control_scorecard.to_string(index=False))
print("ARBITRARY_WIDTH_TUNING_SCAN:")
print(arbitrary_width_scan.to_string(index=False))
print("ADMISSIBILITY_TRUTH_TABLE:")
print(admissibility_truth_table.to_string(index=False))
print("KKT_FORMAL_STATEMENT:")
print(kkt_formal_statement.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print("INTRUDER_AND_MISSING_SEED_AUDIT:")
print(intruder_audit.to_string(index=False) if len(intruder_audit) else "none")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R109_summary.md').resolve()}")
print("NEXT: FORCE_R110_normal_bundle_dimension_slot_capacity_derivation_gate")
print("=== END COPY/PASTE R109 RESULT ===\n")
