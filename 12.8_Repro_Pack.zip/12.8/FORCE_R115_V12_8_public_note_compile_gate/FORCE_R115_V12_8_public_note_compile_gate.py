#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FORCE_R115 — V12.8 Public Note Compile Gate
Self-contained version.

Purpose:
  Compile the frozen V12.8 operator-geometry result into a public Markdown/HTML/PDF note
  and package the note, tables, guardrails, and manifest.

This script uses only the Python standard library.
"""

from pathlib import Path
from fractions import Fraction
import csv
import hashlib
import html as html_lib
import json
import shutil
import textwrap
import zipfile
from datetime import datetime, timezone

ROOT = Path.cwd()
OUT = Path("FORCE_R115_V12_8_public_note_compile_gate")
ZIP = Path("SFT_V12_8_public_note_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

FREEZE_ID = "SFT_V12_8_OPERATOR_GEOMETRY_FREEZE"
PUBLIC_NOTE_TITLE = "Solvency Field Theory V12.8: Operator-Geometric Support-to-Species Seed Closure"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1),
]

VIRTUAL_SUPPORTS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

def frac_label(x):
    return str(x) if isinstance(x, Fraction) else str(x)

def label_list(xs):
    return ", ".join(frac_label(x) for x in xs)

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def write_csv(path, rows, fieldnames=None):
    rows = list(rows)
    if fieldnames is None:
        if rows:
            fieldnames = list(rows[0].keys())
        else:
            fieldnames = []
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})

def table_text(rows, fieldnames=None):
    rows = list(rows)
    if not rows:
        return "none"
    if fieldnames is None:
        fieldnames = list(rows[0].keys())
    widths = {k: len(k) for k in fieldnames}
    for row in rows:
        for k in fieldnames:
            widths[k] = max(widths[k], len(str(row.get(k, ""))))
    header = " | ".join(k.ljust(widths[k]) for k in fieldnames)
    sep = "-+-".join("-" * widths[k] for k in fieldnames)
    body = []
    for row in rows:
        body.append(" | ".join(str(row.get(k, "")).ljust(widths[k]) for k in fieldnames))
    return "\n".join([header, sep] + body)

selected_seed = "{" + label_list(SEED) + "}"
canonical_formula = "Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}"

# ---------------------------------------------------------------------
# 1. Locate R114 freeze pack if present.
# ---------------------------------------------------------------------

freeze_pack_candidates = []
for p in ROOT.rglob("SFT_V12_8_operator_geometry_freeze_pack.zip"):
    try:
        if OUT in p.parents:
            continue
    except Exception:
        pass
    freeze_pack_candidates.append(p)

freeze_pack_found = len(freeze_pack_candidates) > 0
freeze_pack_path = freeze_pack_candidates[0] if freeze_pack_found else None
freeze_pack_inventory = [{
    "freeze_pack_found": str(freeze_pack_found),
    "path": str(freeze_pack_path) if freeze_pack_path else "",
    "bytes": str(freeze_pack_path.stat().st_size) if freeze_pack_path else "0",
    "sha256": sha256_file(freeze_pack_path) if freeze_pack_path else "",
}]

# ---------------------------------------------------------------------
# 2. Public-note ledger tables.
# ---------------------------------------------------------------------

gate_ledger = [
    {"gate": "R100", "public_role": "primitive anchors", "safe_status": "operator-origin candidate", "safe_sentence": "The primitive anchor set {1,1/2,1/3} is the minimal exact support-anchor set at operator level."},
    {"gate": "R101", "public_role": "tri-normal support", "safe_status": "virtual support anchor", "safe_sentence": "The 1/3 channel is support-active but not stable-species-active."},
    {"gate": "R102", "public_role": "reflection map", "safe_status": "operator map", "safe_sentence": "The reflection complement map is R(rho)=2-rho."},
    {"gate": "R103", "public_role": "reciprocal map", "safe_status": "operator map", "safe_sentence": "The reciprocal cadence-return map is C(rho)=1/rho."},
    {"gate": "R104", "public_role": "support domain", "safe_status": "support closure", "safe_sentence": "The joint R/C domain D_RC({1,1/2,1/3}) supplies support compatibility."},
    {"gate": "R105", "public_role": "implementation readiness", "safe_status": "readiness only", "safe_sentence": "The readiness gate identifies required terms and rejects lookup/root/oracle routes."},
    {"gate": "R106", "public_role": "candidate action blueprint", "safe_status": "blueprint only", "safe_sentence": "The worldline-tube phase/boundary action is a candidate blueprint, not full PDE closure."},
    {"gate": "R107", "public_role": "auxiliary variation", "safe_status": "partial variational support", "safe_sentence": "The R/C scalar auxiliary constraints have formal variational support."},
    {"gate": "R108", "public_role": "local covariance", "safe_status": "blueprint covariance", "safe_sentence": "The blueprint passes local phase-gauge and normal-frame relabeling checks."},
    {"gate": "R109", "public_role": "binary admissibility", "safe_status": "discrete KKT conditional", "safe_sentence": "Given binary write-cell width w=1/2, no-overlap gives rho>=1/2."},
    {"gate": "R110", "public_role": "slot admissibility", "safe_status": "3+1 conditional geometry", "safe_sentence": "A 1D worldline in inherited 3+1 spacetime gives D_perp=3 and slot capacity 4."},
    {"gate": "R111", "public_role": "species projection", "safe_status": "operator-geometric projection", "safe_sentence": "Stable species candidates are Support ∩ Binary ∩ Slot."},
    {"gate": "R112", "public_role": "theorem-stack rollup", "safe_status": "closed operator-geometric stack", "safe_sentence": "The R100-R111 stack selects the exact nine-mode mechanical seed."},
    {"gate": "R113", "public_role": "claim boundary", "safe_status": "paper-safe language", "safe_sentence": "The public claim boundary forbids upgrading the seed to a confirmed physical spectrum."},
    {"gate": "R114", "public_role": "freeze pack", "safe_status": "frozen appendix package", "safe_sentence": "The appendix pack freezes the theorem ledger, formula, paper insert, and guardrails."},
]

claim_boundary = [
    {"claim": "V12.8 closes an operator-geometric theorem stack.", "status": "YES", "public_wording": "V12.8 closes an operator-geometric support-to-species theorem stack selecting a nine-mode mechanical seed."},
    {"claim": "The selected seed has exactly nine modes.", "status": "YES", "public_wording": f"The selected mechanical seed is {selected_seed}."},
    {"claim": "Virtual supports are manually deleted.", "status": "NO", "public_wording": "Virtual supports fail admissibility filters while remaining support-active."},
    {"claim": "V12.8 derives a confirmed physical particle spectrum.", "status": "NO", "public_wording": "Physical particle-spectrum identification remains open."},
    {"claim": "V12.8 closes full PDE/action dynamics.", "status": "NO", "public_wording": "Full PDE/action dynamics remain open."},
    {"claim": "V12.8 derives masses, Standard Model matching, or Omega0.", "status": "NO", "public_wording": "Mass hierarchy, Standard Model matching, and Omega0 remain open."},
    {"claim": "V12.8 derives K=2 from scratch.", "status": "NO", "public_wording": "K=2 remains inherited from the binary no-overwrite predicate stack."},
    {"claim": "V12.8 derives why spacetime is 3+1.", "status": "NO", "public_wording": "The 3+1 spacetime premise remains inherited."},
]

open_problem_register = [
    {"open_item": "Full local PDE/action implementation", "status": "OPEN", "public_boundary": "The current result is operator-geometric, with partial variational support only."},
    {"open_item": "Physical particle-spectrum identification", "status": "OPEN", "public_boundary": "The nine-mode set is a mechanical/operator-geometric seed."},
    {"open_item": "Mass hierarchy and Standard Model matching", "status": "OPEN", "public_boundary": "No mass or Standard Model parameter matching is claimed."},
    {"open_item": "Omega0", "status": "OPEN", "public_boundary": "Omega0 is outside the V12.8 result."},
    {"open_item": "K=2 deeper origin", "status": "INHERITED", "public_boundary": "R109 derives rho>=1/2 conditional on binary write-cell width w=1/2."},
    {"open_item": "3+1 spacetime deeper origin", "status": "INHERITED", "public_boundary": "R110 derives D_perp=3 conditional on inherited 3+1 spacetime."},
    {"open_item": "Dynamic support-to-species PDE flow", "status": "OPEN", "public_boundary": "R111 closes projection logically/operator-geometrically, not dynamically."},
]

overclaim_guardrails = [
    {"prohibited": "V12.8 derives the physical particle spectrum.", "safe": "V12.8 selects a nine-mode mechanical/operator-geometric seed."},
    {"prohibited": "V12.8 derives the Standard Model.", "safe": "V12.8 provides an operator-geometric support scaffold for future physical matching."},
    {"prohibited": "V12.8 derives particle masses.", "safe": "Mass hierarchy and parameter matching remain open."},
    {"prohibited": "V12.8 predicts Omega0.", "safe": "Omega0 is not addressed by V12.8."},
    {"prohibited": "V12.8 closes full PDE/action dynamics.", "safe": "Full PDE/action dynamics remain open."},
    {"prohibited": "V12.8 derives K=2 from scratch.", "safe": "K=2 remains inherited."},
    {"prohibited": "V12.8 derives why spacetime is 3+1.", "safe": "The 3+1 premise remains inherited."},
]

# ---------------------------------------------------------------------
# 3. Public note Markdown.
# ---------------------------------------------------------------------

gate_rows = "\n".join(
    f"| {row['gate']} | {row['public_role']} | {row['safe_status']} |"
    for row in gate_ledger
)
guardrail_rows = "\n".join(
    f"| {row['prohibited']} | {row['safe']} |"
    for row in overclaim_guardrails
)
open_rows = "\n".join(
    f"| {row['open_item']} | {row['status']} | {row['public_boundary']} |"
    for row in open_problem_register
)

public_note_md = f"""# {PUBLIC_NOTE_TITLE}

**Freeze ID:** `{FREEZE_ID}`

## Abstract

This note records the V12.8 operator-geometric support-to-species closure result in Solvency Field Theory. Starting from the primitive support anchors `{{1, 1/2, 1/3}}`, together with the reflection map `R(rho)=2-rho` and reciprocal cadence-return map `C(rho)=1/rho`, the joint R/C support domain is projected through binary no-overlap admissibility and 3+1 worldline-tube slot admissibility. The result is a nine-mode mechanical/operator-geometric seed,

`{selected_seed}`.

This note does not identify the seed with a confirmed physical particle spectrum. Full PDE/action dynamics, physical species identification, mass hierarchy, Standard Model matching, Omega0, the deeper origin of K=2, and the deeper origin of 3+1 spacetime remain open.

## 1. Claim Boundary

The public V12.8 claim is:

> V12.8 closes an operator-geometric theorem stack selecting a nine-mode mechanical seed.

The public V12.8 claim is not:

> a completed physical particle-spectrum derivation, a complete local PDE/action theory, a mass hierarchy derivation, a Standard Model matching derivation, or an Omega0 prediction.

## 2. Primitive Anchors and Closure Maps

The primitive support anchors are

```text
A = {{1, 1/2, 1/3}}.
```

The closure maps are

```text
R(rho) = 2 - rho
C(rho) = 1 / rho
```

The joint support domain is denoted

```text
D_RC(A).
```

Support-domain membership means a mode is closure-compatible. It does not by itself mean the mode is a stable species candidate.

## 3. Species Projection

Stable species candidates are obtained by simultaneous admissibility:

```text
{canonical_formula}
```

The binary admissibility condition

```text
rho >= 1/2
```

comes from the discrete no-overlap/KKT result, conditional on inherited binary write-cell width `w=1/2`.

The slot admissibility condition

```text
denom(rho) <= 4
```

comes from a 1D worldline in inherited 3+1 spacetime. A 1D worldline has one tangent/base slot and three normal slots, giving

```text
D_perp = 3
N_slot = 1 + D_perp = 4.
```

## 4. Selected Mechanical Seed

The projection selects exactly

```text
{selected_seed}
```

This set is the V12.8 mechanical/operator-geometric seed.

## 5. Virtual Support Channels

The virtual support channels are

```text
{{1/3, 3/5, 4/5}}.
```

They remain support-active but species-inactive.

- `1/3` fails binary no-overlap because it is below `1/2`.
- `3/5` fails slot capacity because its denominator is `5`.
- `4/5` fails slot capacity because its denominator is `5`.

They are not manually removed. They fail the admissibility filters while still participating in support closure.

Stable modes may depend on virtual support partners:

- `5/3` uses `1/3` and `3/5` as support partners.
- `5/4` uses `4/5` as reciprocal support.

## 6. Gate Ledger

| Gate | Public role | Safe status |
|---|---|---|
{gate_rows}

## 7. Controls and Guardrails

The freeze stack rejects seed lookup, polynomial-root fitting, global support-table oracles, and manual deletion of virtual supports. Wrong anchors, wrong R/C maps, wrong projection logic, and wrong slot capacities fail their controls.

The overclaim guardrail is mandatory:

| Prohibited phrasing | Safe replacement |
|---|---|
{guardrail_rows}

## 8. Open Problems

| Open item | Status | Boundary |
|---|---|---|
{open_rows}

## 9. Final Public Statement

The V12.8 result is a frozen operator-geometric theorem-stack result:

```text
{canonical_formula}
```

selecting the nine-mode mechanical seed

```text
{selected_seed}
```

with physical spectrum identification, full PDE/action dynamics, masses, Standard Model matching, Omega0, K=2 origin, and 3+1 spacetime origin preserved as open or inherited boundaries.
"""

# ---------------------------------------------------------------------
# 4. HTML generation.
# ---------------------------------------------------------------------

def md_to_simple_html(md_text):
    lines = md_text.splitlines()
    out = []
    in_ul = False
    in_code = False
    code_lines = []

    def close_ul():
        nonlocal in_ul
        if in_ul:
            out.append("</ul>")
            in_ul = False

    for line in lines:
        stripped = line.strip()

        if stripped.startswith("```"):
            close_ul()
            if not in_code:
                in_code = True
                code_lines = []
            else:
                in_code = False
                out.append("<pre><code>" + html_lib.escape("\n".join(code_lines)) + "</code></pre>")
            continue

        if in_code:
            code_lines.append(line)
            continue

        if stripped == "":
            close_ul()
            continue

        if stripped.startswith("# "):
            close_ul()
            out.append(f"<h1>{html_lib.escape(stripped[2:])}</h1>")
        elif stripped.startswith("## "):
            close_ul()
            out.append(f"<h2>{html_lib.escape(stripped[3:])}</h2>")
        elif stripped.startswith("### "):
            close_ul()
            out.append(f"<h3>{html_lib.escape(stripped[4:])}</h3>")
        elif stripped.startswith("- "):
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append(f"<li>{html_lib.escape(stripped[2:])}</li>")
        elif stripped.startswith("|"):
            close_ul()
            out.append(f"<pre class='table'>{html_lib.escape(stripped)}</pre>")
        elif stripped.startswith(">"):
            close_ul()
            out.append(f"<blockquote>{html_lib.escape(stripped[1:].strip())}</blockquote>")
        else:
            close_ul()
            out.append(f"<p>{html_lib.escape(stripped)}</p>")

    close_ul()

    css = """
    body { font-family: Arial, sans-serif; line-height: 1.48; margin: 0; background: #f7f7f4; color: #1f2933; }
    article { max-width: 900px; margin: 40px auto; padding: 48px; background: white; box-shadow: 0 8px 30px rgba(0,0,0,0.08); }
    h1 { font-size: 30px; border-bottom: 2px solid #222; padding-bottom: 12px; }
    h2 { margin-top: 34px; font-size: 22px; }
    h3 { margin-top: 24px; font-size: 18px; }
    pre { background: #f1f5f9; padding: 12px; overflow-x: auto; border-left: 4px solid #64748b; }
    pre.table { white-space: pre-wrap; font-size: 12px; border-left: none; background: #fafafa; padding: 4px 8px; margin: 2px 0; }
    blockquote { border-left: 5px solid #94a3b8; padding-left: 16px; color: #334155; font-style: italic; }
    code { font-family: Consolas, monospace; }
    """
    title = html_lib.escape(PUBLIC_NOTE_TITLE)
    return f"<!doctype html><html><head><meta charset='utf-8'><title>{title}</title><style>{css}</style></head><body><article>{''.join(out)}</article></body></html>"

# ---------------------------------------------------------------------
# 5. Minimal dependency-free PDF writer.
# ---------------------------------------------------------------------

def sanitize_pdf_text(text):
    replacements = {
        "∩": " intersection ",
        "ρ": "rho",
        "≤": "<=",
        "≥": ">=",
        "Ω": "Omega",
        "τ": "tau",
        "θ": "theta",
        "⊥": "_perp",
        "–": "-",
        "—": "-",
        "“": '"',
        "”": '"',
        "’": "'",
        "‘": "'",
        "→": "->",
        "×": "x",
    }
    for k, v in replacements.items():
        text = text.replace(k, v)
    return text.encode("latin-1", "replace").decode("latin-1")

def pdf_escape(s):
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")

def markdown_to_pdf_lines(md_text):
    text = sanitize_pdf_text(md_text)
    lines = []

    for raw in text.splitlines():
        stripped = raw.strip()
        if stripped.startswith("# "):
            lines.append("")
            lines.append(stripped[2:].upper())
            lines.append("=" * min(len(stripped[2:]), 80))
        elif stripped.startswith("## "):
            lines.append("")
            lines.append(stripped[3:].upper())
            lines.append("-" * min(len(stripped[3:]), 80))
        elif stripped.startswith("### "):
            lines.append("")
            lines.append(stripped[4:])
        elif stripped.startswith("```"):
            lines.append("")
        elif stripped == "":
            lines.append("")
        else:
            wrapped = textwrap.wrap(stripped, width=88, replace_whitespace=False) or [""]
            lines.extend(wrapped)

    return lines

def write_simple_pdf(md_text, path):
    all_lines = markdown_to_pdf_lines(md_text)
    max_lines_per_page = 58
    pages = []
    current = []

    for line in all_lines:
        current.append(line)
        if len(current) >= max_lines_per_page:
            pages.append(current)
            current = []
    if current:
        pages.append(current)
    if not pages:
        pages = [["Empty document"]]

    objects = {}
    objects[1] = b"<< /Type /Catalog /Pages 2 0 R >>"
    objects[3] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"

    page_ids = []
    for i, page_lines in enumerate(pages):
        content_id = 4 + 2 * i
        page_id = 5 + 2 * i
        page_ids.append(page_id)

        content = ["BT", "/F1 10 Tf", "12 TL", "54 748 Td"]
        for line in page_lines:
            content.append(f"({pdf_escape(line)}) Tj")
            content.append("T*")
        content.append("ET")
        stream = "\n".join(content).encode("latin-1", "replace")

        objects[content_id] = (
            f"<< /Length {len(stream)} >>\nstream\n".encode("latin-1")
            + stream
            + b"\nendstream"
        )
        objects[page_id] = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
            f"/Resources << /Font << /F1 3 0 R >> >> "
            f"/Contents {content_id} 0 R >>"
        ).encode("latin-1")

    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects[2] = f"<< /Type /Pages /Kids [ {kids} ] /Count {len(page_ids)} >>".encode("latin-1")

    max_id = max(objects)
    pdf = bytearray(b"%PDF-1.4\n")
    offsets = [0] * (max_id + 1)

    for obj_id in range(1, max_id + 1):
        offsets[obj_id] = len(pdf)
        pdf.extend(f"{obj_id} 0 obj\n".encode("latin-1"))
        pdf.extend(objects[obj_id])
        pdf.extend(b"\nendobj\n")

    xref_offset = len(pdf)
    pdf.extend(f"xref\n0 {max_id + 1}\n".encode("latin-1"))
    pdf.extend(b"0000000000 65535 f \n")
    for obj_id in range(1, max_id + 1):
        pdf.extend(f"{offsets[obj_id]:010d} 00000 n \n".encode("latin-1"))

    pdf.extend(
        f"trailer\n<< /Size {max_id + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_offset}\n%%EOF\n".encode("latin-1")
    )

    path.write_bytes(bytes(pdf))

# ---------------------------------------------------------------------
# 6. Write public note artifacts.
# ---------------------------------------------------------------------

md_path = OUT / "SFT_V12_8_public_note.md"
html_path = OUT / "SFT_V12_8_public_note.html"
pdf_path = OUT / "SFT_V12_8_public_note.pdf"

md_path.write_text(public_note_md, encoding="utf-8")
html_path.write_text(md_to_simple_html(public_note_md), encoding="utf-8")
write_simple_pdf(public_note_md, pdf_path)

write_csv(OUT / "SFT_V12_8_public_note_gate_ledger.csv", gate_ledger)
write_csv(OUT / "SFT_V12_8_public_note_claim_boundary.csv", claim_boundary)
write_csv(OUT / "SFT_V12_8_public_note_open_problem_register.csv", open_problem_register)
write_csv(OUT / "SFT_V12_8_public_note_overclaim_guardrails.csv", overclaim_guardrails)
write_csv(OUT / "SFT_V12_8_public_note_freeze_pack_inventory.csv", freeze_pack_inventory)

# ---------------------------------------------------------------------
# 7. Overclaim scan.
# ---------------------------------------------------------------------

forbidden_phrases = [
    "v12.8 derives the physical particle spectrum",
    "v12.8 derives the standard model",
    "v12.8 derives particle masses",
    "v12.8 predicts omega0",
    "v12.8 closes full pde/action dynamics",
    "v12.8 derives k=2 from scratch",
    "v12.8 derives why spacetime is 3+1",
    "virtual supports are manually deleted",
]

# The public note intentionally includes prohibited phrases inside the guardrail table.
# Scan only the claim-bearing body before the guardrail section.
scan_text = public_note_md.split("## 7. Controls and Guardrails")[0].lower()

overclaim_scan = []
for phrase in forbidden_phrases:
    overclaim_scan.append({
        "file": "SFT_V12_8_public_note.md",
        "scan_scope": "claim_body_before_guardrails",
        "forbidden_phrase": phrase,
        "present": str(phrase in scan_text),
    })

write_csv(OUT / "SFT_V12_8_public_note_overclaim_scan.csv", overclaim_scan)

overclaim_scan_pass = not any(row["present"] == "True" for row in overclaim_scan)
md_exists = md_path.exists() and md_path.stat().st_size > 0
html_exists = html_path.exists() and html_path.stat().st_size > 0
pdf_exists = pdf_path.exists() and pdf_path.stat().st_size > 0
tables_exist = all(
    (OUT / name).exists()
    for name in [
        "SFT_V12_8_public_note_gate_ledger.csv",
        "SFT_V12_8_public_note_claim_boundary.csv",
        "SFT_V12_8_public_note_open_problem_register.csv",
        "SFT_V12_8_public_note_overclaim_guardrails.csv",
    ]
)
claim_boundary_present = (
    "does not identify the seed with a confirmed physical particle spectrum" in public_note_md
    and "remain open" in public_note_md
)
public_note_ready = bool(
    md_exists
    and html_exists
    and pdf_exists
    and tables_exist
    and overclaim_scan_pass
    and claim_boundary_present
)

if public_note_ready and freeze_pack_found:
    verdict_status = "V12.8 PUBLIC NOTE COMPILE PASS"
elif public_note_ready and not freeze_pack_found:
    verdict_status = "V12.8 PUBLIC NOTE COMPILE PASS / FREEZE PACK NOT FOUND LOCALLY"
else:
    verdict_status = "V12.8 PUBLIC NOTE COMPILE INCONCLUSIVE"

compile_audit = [
    {"test": "markdown_generated", "result": "PASS" if md_exists else "WARN", "interpretation": "Public note Markdown was generated."},
    {"test": "html_generated", "result": "PASS" if html_exists else "WARN", "interpretation": "Public note HTML was generated."},
    {"test": "pdf_generated", "result": "PASS" if pdf_exists else "WARN", "interpretation": "Public note PDF was generated with a dependency-free writer."},
    {"test": "tables_exist", "result": "PASS" if tables_exist else "WARN", "interpretation": "Gate ledger, claim boundary, open-problem, and guardrail tables were generated."},
    {"test": "freeze_pack_found", "result": "PASS" if freeze_pack_found else "PARTIAL", "interpretation": "R114 freeze pack found and hashed locally." if freeze_pack_found else "No R114 freeze pack was found in the current tree; note was compiled from canonical R115 constants."},
    {"test": "overclaim_scan_pass", "result": "PASS" if overclaim_scan_pass else "WARN", "interpretation": "Public note body does not contain forbidden exact overclaim phrases."},
    {"test": "claim_boundary_present", "result": "PASS" if claim_boundary_present else "WARN", "interpretation": "Public note explicitly preserves physical-spectrum and open-problem boundaries."},
    {"test": "public_note_ready", "result": "PASS" if public_note_ready else "WARN", "interpretation": "Public note is ready for review/public compilation."},
]
write_csv(OUT / "FORCE_R115_compile_audit.csv", compile_audit)

verdict = {
    "force_id": "FORCE_R115",
    "title": "V12.8 Public Note Compile Gate",
    "status": verdict_status,
    "freeze_id": FREEZE_ID,
    "public_note_title": PUBLIC_NOTE_TITLE,
    "markdown_generated": md_exists,
    "html_generated": html_exists,
    "pdf_generated": pdf_exists,
    "tables_exist": tables_exist,
    "freeze_pack_found": freeze_pack_found,
    "freeze_pack_path": str(freeze_pack_path) if freeze_pack_path else "",
    "overclaim_scan_pass": overclaim_scan_pass,
    "claim_boundary_present": claim_boundary_present,
    "public_note_ready": public_note_ready,
    "selected_seed": [frac_label(x) for x in SEED],
    "canonical_formula": canonical_formula,
    "physical_spectrum_claimed": False,
    "full_PDE_claimed_closed": False,
    "masses_SM_Omega0_claimed": False,
    "recommended_next": "review_public_note_or_freeze_V12_8_public_release",
}
(OUT / "FORCE_R115_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R115 — V12.8 Public Note Compile Gate

## Verdict

BOXED: {verdict_status}

## Public note title

BOXED: {PUBLIC_NOTE_TITLE}

## Freeze ID

BOXED: {FREEZE_ID}

## Canonical formula

BOXED:
{canonical_formula}

## Selected seed

BOXED:
{selected_seed}

## Public note outputs

- SFT_V12_8_public_note.md
- SFT_V12_8_public_note.html
- SFT_V12_8_public_note.pdf
- SFT_V12_8_public_note_gate_ledger.csv
- SFT_V12_8_public_note_claim_boundary.csv
- SFT_V12_8_public_note_open_problem_register.csv
- SFT_V12_8_public_note_overclaim_guardrails.csv

## Key booleans

- markdown_generated: {md_exists}
- html_generated: {html_exists}
- pdf_generated: {pdf_exists}
- tables_exist: {tables_exist}
- freeze_pack_found: {freeze_pack_found}
- overclaim_scan_pass: {overclaim_scan_pass}
- claim_boundary_present: {claim_boundary_present}
- public_note_ready: {public_note_ready}

## Claims not made

- physical_spectrum_claimed: False
- full_PDE_claimed_closed: False
- masses_SM_Omega0_claimed: False

## Compile audit

{table_text(compile_audit)}

## Claim boundary

{table_text(claim_boundary)}

## Open problem register

{table_text(open_problem_register)}
"""
(OUT / "FORCE_R115_summary.md").write_text(summary, encoding="utf-8")

# Manifest before zip.
manifest_rows = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_rows.append({
            "relative_path": str(p.relative_to(OUT)),
            "bytes": str(p.stat().st_size),
            "sha256": sha256_file(p),
        })
write_csv(OUT / "artifact_manifest.csv", manifest_rows)

# Copy script into output folder.
try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R115_V12_8_public_note_compile_gate.py")
except Exception:
    pass

# Zip.
if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

zip_integrity_pass = bad is None
verdict["zip_integrity_pass"] = zip_integrity_pass
(OUT / "FORCE_R115_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

print("\n=== COPY/PASTE R115 RESULT ===")
print("R115 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"FREEZE_ID: {FREEZE_ID}")
print(f"PUBLIC_NOTE_TITLE: {PUBLIC_NOTE_TITLE}")
print(f"ZIP_INTEGRITY: {'PASS' if zip_integrity_pass else bad}")
print(f"markdown_generated: {md_exists}")
print(f"html_generated: {html_exists}")
print(f"pdf_generated: {pdf_exists}")
print(f"tables_exist: {tables_exist}")
print(f"freeze_pack_found: {freeze_pack_found}")
print(f"overclaim_scan_pass: {overclaim_scan_pass}")
print(f"claim_boundary_present: {claim_boundary_present}")
print(f"public_note_ready: {public_note_ready}")
print(f"selected_seed: {selected_seed}")
print(f"canonical_formula: {canonical_formula}")
print("AUDIT:")
print(table_text(compile_audit))
print("CLAIM_BOUNDARY:")
print(table_text(claim_boundary))
print("OPEN_PROBLEM_REGISTER:")
print(table_text(open_problem_register))
print("OVERCLAIM_GUARDRAILS:")
print(table_text(overclaim_guardrails))
print("PUBLIC_NOTE_PREVIEW:")
print(public_note_md[:2400])
print(f"NOTE_MD: {md_path.resolve()}")
print(f"NOTE_HTML: {html_path.resolve()}")
print(f"NOTE_PDF: {pdf_path.resolve()}")
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R115_summary.md').resolve()}")
print("NEXT: review_public_note_or_freeze_V12_8_public_release")
print("=== END COPY/PASTE R115 RESULT ===\n")
