from pathlib import Path
from fractions import Fraction
import json
import zipfile
import shutil
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path("FORCE_R105_field_action_PDE_implementation_readiness_gate")
ZIP = Path("FORCE_R105_field_action_PDE_implementation_readiness_gate_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

# FORCE_R105 — Field/Action/PDE Implementation Readiness Gate
#
# R100:
#   {1,1/2,1/3} primitive anchor origin candidate.
#
# R101:
#   1/3 tri-normal virtual support anchor, not stable species.
#
# R102:
#   R(rho)=2-rho boundary complement.
#
# R103:
#   C(rho)=1/rho cadence-return.
#
# R104:
#   stable candidate =
#       rho in D_RC({1,1/2,1/3})
#       AND rho >= 1/2
#       AND denom(rho) <= 4
#
# R105 question:
#
#   What must a genuine local field/action/PDE implementation reproduce,
#   and which "solutions" should be rejected as target-smuggling?
#
# R105 is a readiness gate, not a field derivation.
#
# Claim boundary:
# - Does NOT derive a final PDE/action.
# - Does NOT claim confirmed physical spectrum.
# - Does NOT derive masses, SM matching, or Omega0.
# - It audits the requirements for the next real field-implementation gate.

SEED = {
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
}

ANCHORS = {Fraction(1, 1), Fraction(1, 2), Fraction(1, 3)}
VIRTUAL_SUPPORTS = {Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)}
DENOM_AUDITS = [6, 8, 10, 12, 16, 24, 32]

def frac_label(x):
    if x is None:
        return "none"
    if x == 0:
        return "0_boundary"
    if isinstance(x, Fraction):
        return str(x)
    return str(Fraction(str(round(float(x), 12))).limit_denominator(512))

def label_set(s):
    if not s:
        return "none"
    return ", ".join(frac_label(x) for x in sorted(s))

def rational_universe(max_den):
    out = set()
    for den in range(1, max_den + 1):
        for num in range(1, 2 * den + 1):
            f = Fraction(num, den)
            if f.denominator == den and f > 0 and f <= 2:
                out.add(f)
    return out

def in_interval(x):
    return x is not None and x > 0 and x <= 2

def R_map(x):
    return Fraction(2, 1) - x

def C_map(x):
    if x == 0:
        return None
    return Fraction(1, 1) / x

def close_domain(anchors, max_den):
    universe = rational_universe(max_den)
    active = {a for a in anchors if a in universe}
    boundary_used = False

    for _ in range(800):
        before = set(active)

        for x in list(active):
            r = R_map(x)
            if r == 0:
                boundary_used = True
            elif in_interval(r) and r in universe:
                active.add(r)

            c = C_map(x)
            if in_interval(c) and c in universe:
                active.add(c)

        if active == before:
            break

    return active, boundary_used

def binary_accept(x):
    return x >= Fraction(1, 2)

def slot_accept(x):
    return x.denominator <= 4

def stable_by_domain(domain, max_den):
    universe = rational_universe(max_den)
    return {
        x for x in universe
        if x in domain
        and binary_accept(x)
        and slot_accept(x)
    }

domain_full, boundary_used = close_domain(ANCHORS, max(DENOM_AUDITS))
stable_full = stable_by_domain(domain_full, max(DENOM_AUDITS))

operator_kernel_validated = stable_full == SEED
virtual_supports_present_not_stable = all(
    v in domain_full and v not in stable_full for v in VIRTUAL_SUPPORTS
)
main_intruder_excluded = Fraction(7, 4) not in domain_full and Fraction(7, 4) not in stable_full

# ---------------------------------------------------------------------
# 1. Requirements matrix.
# ---------------------------------------------------------------------

requirements = [
    {
        "requirement_id": "REQ01",
        "requirement": "Primitive identity/base cadence anchor",
        "mathematical_target": "1",
        "must_be_derived_from": "fixed cadence / self-return / identity mode",
        "forbidden_shortcut": "insert rho=1 because it is in the seed",
        "r100_r104_status": "LOCKED_OPERATOR_ORIGIN",
    },
    {
        "requirement_id": "REQ02",
        "requirement": "Binary no-overwrite anchor",
        "mathematical_target": "1/2",
        "must_be_derived_from": "minimum faithful binary write predicate",
        "forbidden_shortcut": "insert 1/2 as fitted particle value",
        "r100_r104_status": "LOCKED_OPERATOR_ORIGIN",
    },
    {
        "requirement_id": "REQ03",
        "requirement": "Tri-normal virtual support anchor",
        "mathematical_target": "1/3",
        "must_be_derived_from": "three transverse normal directions of a worldline tube",
        "forbidden_shortcut": "promote 1/3 to species or insert it as target fraction",
        "r100_r104_status": "LOCKED_OPERATOR_ORIGIN",
    },
    {
        "requirement_id": "REQ04",
        "requirement": "Reflection complement map",
        "mathematical_target": "R(rho)=2-rho",
        "must_be_derived_from": "doubled-boundary complement on [0,2]",
        "forbidden_shortcut": "choose R because it recovers the seed",
        "r100_r104_status": "LOCKED_OPERATOR_ORIGIN",
    },
    {
        "requirement_id": "REQ05",
        "requirement": "Reciprocal cadence-return map",
        "mathematical_target": "C(rho)=1/rho",
        "must_be_derived_from": "rho*C(rho)=1 cadence-return product",
        "forbidden_shortcut": "choose C because it closes the table",
        "r100_r104_status": "LOCKED_OPERATOR_ORIGIN",
    },
    {
        "requirement_id": "REQ06",
        "requirement": "Joint R/C support domain",
        "mathematical_target": "D_RC({1,1/2,1/3})",
        "must_be_derived_from": "closure under R and C from primitive anchors",
        "forbidden_shortcut": "list the nine seed modes directly",
        "r100_r104_status": "PASS_ROLLUP",
    },
    {
        "requirement_id": "REQ07",
        "requirement": "Binary no-overlap species filter",
        "mathematical_target": "rho >= 1/2",
        "must_be_derived_from": "write-footprint no-overlap update",
        "forbidden_shortcut": "delete sub-half modes by hand",
        "r100_r104_status": "LOCKED_OPERATOR_ORIGIN",
    },
    {
        "requirement_id": "REQ08",
        "requirement": "3+1 slot capacity species filter",
        "mathematical_target": "denom(rho) <= 4",
        "must_be_derived_from": "one tangent/base cadence plus three normal-frame slots",
        "forbidden_shortcut": "delete denominator-5 modes because they are inconvenient",
        "r100_r104_status": "LOCKED_OPERATOR_ORIGIN",
    },
    {
        "requirement_id": "REQ09",
        "requirement": "Virtual support/species separation",
        "mathematical_target": "1/3, 3/5, 4/5 support-active but species-inactive",
        "must_be_derived_from": "support-domain membership plus independent species filters",
        "forbidden_shortcut": "equate every support channel with a stable particle",
        "r100_r104_status": "PASS_ROLLUP",
    },
    {
        "requirement_id": "REQ10",
        "requirement": "No target-smuggling",
        "mathematical_target": "seed emerges without target list in equations",
        "must_be_derived_from": "local variables, boundary terms, closure conditions, and capacity",
        "forbidden_shortcut": "polynomial/product potential with roots at the seed",
        "r100_r104_status": "OPEN_FOR_FIELD_GATE",
    },
    {
        "requirement_id": "REQ11",
        "requirement": "Local field/action/PDE implementation",
        "mathematical_target": "Euler-Lagrange/PDE system reproducing REQ01-REQ09",
        "must_be_derived_from": "local phase/cadence field plus worldline-tube normal-bundle data",
        "forbidden_shortcut": "global ledger oracle with no local dynamics",
        "r100_r104_status": "OPEN",
    },
]

requirements_df = pd.DataFrame(requirements)
requirements_matrix_complete = len(requirements_df) == 11

# ---------------------------------------------------------------------
# 2. Candidate implementation routes.
# ---------------------------------------------------------------------

bool_cols = [
    "local_fields",
    "action_principle",
    "derives_identity_anchor",
    "derives_binary_anchor",
    "derives_trinormal_anchor",
    "derives_R_map",
    "derives_C_map",
    "derives_binary_filter",
    "derives_slot_filter",
    "generates_joint_domain",
    "separates_virtual_support_from_species",
    "exact_operator_reproduction",
    "no_target_smuggling",
    "locality_pass",
    "variational_ready",
    "PDE_ready",
    "field_derivation_closed",
]

candidates = [
    {
        "candidate_id": "P0_seed_lookup_oracle",
        "description": "Directly stores the nine-mode seed and returns it.",
        "local_fields": False,
        "action_principle": False,
        "derives_identity_anchor": False,
        "derives_binary_anchor": False,
        "derives_trinormal_anchor": False,
        "derives_R_map": False,
        "derives_C_map": False,
        "derives_binary_filter": False,
        "derives_slot_filter": False,
        "generates_joint_domain": False,
        "separates_virtual_support_from_species": False,
        "exact_operator_reproduction": True,
        "no_target_smuggling": False,
        "locality_pass": False,
        "variational_ready": False,
        "PDE_ready": False,
        "field_derivation_closed": False,
        "expected_verdict": "REJECT_TARGET_SMUGGLING",
    },
    {
        "candidate_id": "P1_polynomial_roots_at_seed",
        "description": "Potential V(rho)=prod(rho-rho_seed)^2.",
        "local_fields": False,
        "action_principle": True,
        "derives_identity_anchor": False,
        "derives_binary_anchor": False,
        "derives_trinormal_anchor": False,
        "derives_R_map": False,
        "derives_C_map": False,
        "derives_binary_filter": False,
        "derives_slot_filter": False,
        "generates_joint_domain": False,
        "separates_virtual_support_from_species": False,
        "exact_operator_reproduction": True,
        "no_target_smuggling": False,
        "locality_pass": False,
        "variational_ready": True,
        "PDE_ready": False,
        "field_derivation_closed": False,
        "expected_verdict": "REJECT_TARGET_SMUGGLING",
    },
    {
        "candidate_id": "P2_global_ledger_nonlocal_oracle",
        "description": "Global consistency oracle accepts exactly the operator kernel.",
        "local_fields": False,
        "action_principle": False,
        "derives_identity_anchor": True,
        "derives_binary_anchor": True,
        "derives_trinormal_anchor": True,
        "derives_R_map": True,
        "derives_C_map": True,
        "derives_binary_filter": True,
        "derives_slot_filter": True,
        "generates_joint_domain": True,
        "separates_virtual_support_from_species": True,
        "exact_operator_reproduction": True,
        "no_target_smuggling": False,
        "locality_pass": False,
        "variational_ready": False,
        "PDE_ready": False,
        "field_derivation_closed": False,
        "expected_verdict": "REJECT_NONLOCAL_ORACLE",
    },
    {
        "candidate_id": "P3_U1_phase_only_action",
        "description": "Local compact phase action only.",
        "local_fields": True,
        "action_principle": True,
        "derives_identity_anchor": True,
        "derives_binary_anchor": False,
        "derives_trinormal_anchor": False,
        "derives_R_map": False,
        "derives_C_map": True,
        "derives_binary_filter": False,
        "derives_slot_filter": False,
        "generates_joint_domain": False,
        "separates_virtual_support_from_species": False,
        "exact_operator_reproduction": False,
        "no_target_smuggling": True,
        "locality_pass": True,
        "variational_ready": True,
        "PDE_ready": True,
        "field_derivation_closed": False,
        "expected_verdict": "PARTIAL_NOT_ENOUGH_STRUCTURE",
    },
    {
        "candidate_id": "P4_binary_write_cell_update",
        "description": "Local binary write/no-overlap update rule.",
        "local_fields": True,
        "action_principle": False,
        "derives_identity_anchor": False,
        "derives_binary_anchor": True,
        "derives_trinormal_anchor": False,
        "derives_R_map": False,
        "derives_C_map": False,
        "derives_binary_filter": True,
        "derives_slot_filter": False,
        "generates_joint_domain": False,
        "separates_virtual_support_from_species": True,
        "exact_operator_reproduction": False,
        "no_target_smuggling": True,
        "locality_pass": True,
        "variational_ready": False,
        "PDE_ready": False,
        "field_derivation_closed": False,
        "expected_verdict": "PARTIAL_BINARY_BRANCH_ONLY",
    },
    {
        "candidate_id": "P5_normal_bundle_only",
        "description": "Worldline-tube normal-bundle geometry only.",
        "local_fields": True,
        "action_principle": True,
        "derives_identity_anchor": False,
        "derives_binary_anchor": False,
        "derives_trinormal_anchor": True,
        "derives_R_map": False,
        "derives_C_map": False,
        "derives_binary_filter": False,
        "derives_slot_filter": True,
        "generates_joint_domain": False,
        "separates_virtual_support_from_species": True,
        "exact_operator_reproduction": False,
        "no_target_smuggling": True,
        "locality_pass": True,
        "variational_ready": True,
        "PDE_ready": True,
        "field_derivation_closed": False,
        "expected_verdict": "PARTIAL_NORMAL_BRANCH_ONLY",
    },
    {
        "candidate_id": "P6_operator_as_boundary_conditions",
        "description": "Uses R100-R104 operator stack as boundary/constraint layer; no PDE yet.",
        "local_fields": True,
        "action_principle": False,
        "derives_identity_anchor": True,
        "derives_binary_anchor": True,
        "derives_trinormal_anchor": True,
        "derives_R_map": True,
        "derives_C_map": True,
        "derives_binary_filter": True,
        "derives_slot_filter": True,
        "generates_joint_domain": True,
        "separates_virtual_support_from_species": True,
        "exact_operator_reproduction": True,
        "no_target_smuggling": True,
        "locality_pass": False,
        "variational_ready": False,
        "PDE_ready": False,
        "field_derivation_closed": False,
        "expected_verdict": "READINESS_BASELINE_NOT_FIELD_IMPL",
    },
    {
        "candidate_id": "P7_coupled_worldline_tube_phase_boundary_blueprint",
        "description": "Local phase/cadence + normal-frame + boundary-complement + cadence-return action blueprint.",
        "local_fields": True,
        "action_principle": True,
        "derives_identity_anchor": True,
        "derives_binary_anchor": True,
        "derives_trinormal_anchor": True,
        "derives_R_map": True,
        "derives_C_map": True,
        "derives_binary_filter": True,
        "derives_slot_filter": True,
        "generates_joint_domain": True,
        "separates_virtual_support_from_species": True,
        "exact_operator_reproduction": True,
        "no_target_smuggling": True,
        "locality_pass": True,
        "variational_ready": True,
        "PDE_ready": False,
        "field_derivation_closed": False,
        "expected_verdict": "BEST_NEXT_BLUEPRINT_FIELD_IMPL_OPEN",
    },
    {
        "candidate_id": "P8_generic_reaction_diffusion_phase_PDE",
        "description": "Generic local PDE with phase diffusion and nonlinear source.",
        "local_fields": True,
        "action_principle": True,
        "derives_identity_anchor": True,
        "derives_binary_anchor": False,
        "derives_trinormal_anchor": False,
        "derives_R_map": False,
        "derives_C_map": False,
        "derives_binary_filter": False,
        "derives_slot_filter": False,
        "generates_joint_domain": False,
        "separates_virtual_support_from_species": False,
        "exact_operator_reproduction": False,
        "no_target_smuggling": True,
        "locality_pass": True,
        "variational_ready": True,
        "PDE_ready": True,
        "field_derivation_closed": False,
        "expected_verdict": "PARTIAL_GENERIC_TOO_WEAK",
    },
]

candidate_df = pd.DataFrame(candidates)

score_cols_core = [
    "local_fields",
    "action_principle",
    "derives_identity_anchor",
    "derives_binary_anchor",
    "derives_trinormal_anchor",
    "derives_R_map",
    "derives_C_map",
    "derives_binary_filter",
    "derives_slot_filter",
    "generates_joint_domain",
    "separates_virtual_support_from_species",
    "exact_operator_reproduction",
    "no_target_smuggling",
    "locality_pass",
    "variational_ready",
]

candidate_df["readiness_score"] = candidate_df[score_cols_core].astype(int).sum(axis=1)
candidate_df["smuggling_risk"] = candidate_df.apply(
    lambda r: "HIGH" if not r["no_target_smuggling"] else ("MEDIUM" if not r["locality_pass"] else "LOW"),
    axis=1
)
candidate_df["field_claim_allowed"] = candidate_df["field_derivation_closed"]
candidate_df["route_status"] = candidate_df.apply(
    lambda r: (
        "REJECT"
        if not r["no_target_smuggling"]
        else (
            "BEST_BLUEPRINT"
            if r["candidate_id"] == "P7_coupled_worldline_tube_phase_boundary_blueprint"
            else (
                "BASELINE_ONLY"
                if r["candidate_id"] == "P6_operator_as_boundary_conditions"
                else "PARTIAL"
            )
        )
    ),
    axis=1
)

best_row = candidate_df.sort_values(
    ["readiness_score", "no_target_smuggling", "locality_pass", "variational_ready"],
    ascending=[False, False, False, False]
).iloc[0]

best_candidate_id = best_row["candidate_id"]
best_candidate_is_blueprint = best_candidate_id == "P7_coupled_worldline_tube_phase_boundary_blueprint"
best_candidate_not_closed = not bool(best_row["field_derivation_closed"])
best_candidate_no_smuggling = bool(best_row["no_target_smuggling"])
best_candidate_local_variational = bool(best_row["locality_pass"] and best_row["variational_ready"])

# ---------------------------------------------------------------------
# 3. Fake-solution rejection audit.
# ---------------------------------------------------------------------

fake_rows = []
for _, row in candidate_df.iterrows():
    exact = bool(row["exact_operator_reproduction"])
    smuggle = not bool(row["no_target_smuggling"])
    nonlocal_oracle = not bool(row["locality_pass"]) and exact
    target_roots = row["candidate_id"] in {"P0_seed_lookup_oracle", "P1_polynomial_roots_at_seed"}

    rejected = smuggle or target_roots or nonlocal_oracle

    fake_rows.append({
        "candidate_id": row["candidate_id"],
        "exact_operator_reproduction": exact,
        "no_target_smuggling": bool(row["no_target_smuggling"]),
        "locality_pass": bool(row["locality_pass"]),
        "target_roots_or_seed_lookup": target_roots,
        "nonlocal_oracle_risk": nonlocal_oracle,
        "rejected_as_fake_solution": rejected,
        "reason": (
            "target-list smuggling"
            if target_roots
            else (
                "nonlocal exact oracle"
                if nonlocal_oracle
                else (
                    "not fake, but partial/open"
                    if not rejected
                    else "smuggling risk"
                )
            )
        ),
    })

fake_solution_audit = pd.DataFrame(fake_rows)

exact_but_smuggled_rejected = all(
    bool(r["rejected_as_fake_solution"])
    for _, r in fake_solution_audit.iterrows()
    if bool(r["exact_operator_reproduction"]) and not bool(r["no_target_smuggling"])
)

no_candidate_claims_closed = not bool(candidate_df["field_derivation_closed"].any())

# ---------------------------------------------------------------------
# 4. Field/action blueprint.
# ---------------------------------------------------------------------

blueprint_terms = [
    {
        "term_id": "S_phase",
        "symbolic_form": "∫ dτ Kθ (Dτθ - Ω)^2",
        "role": "local cadence/phase propagation",
        "must_reproduce": "identity/base cadence and cadence rate variable",
        "status": "READY_FOR_CANDIDATE_ACTION",
    },
    {
        "term_id": "S_binary",
        "symbolic_form": "Π_no-overlap[write_cell(θ_n), write_cell(θ_{n+1})]",
        "role": "binary no-overwrite update",
        "must_reproduce": "rho >= 1/2 and anchor 1/2",
        "status": "READY_AS_CONSTRAINT_TERM",
    },
    {
        "term_id": "S_normal",
        "symbolic_form": "∫ dτ KN Σ_i=1^3 ||Dτ n_i||^2",
        "role": "three transverse normal-frame directions",
        "must_reproduce": "tri-normal virtual support anchor 1/3 and slot capacity 1+3",
        "status": "READY_FOR_CANDIDATE_ACTION",
    },
    {
        "term_id": "S_R",
        "symbolic_form": "λR [ρ + ρ_R - 2]^2",
        "role": "boundary complement closure",
        "must_reproduce": "R(ρ)=2-ρ",
        "status": "READY_AS_DERIVED_CONSTRAINT_TARGET",
    },
    {
        "term_id": "S_C",
        "symbolic_form": "λC [ρ ρ_C - 1]^2",
        "role": "cadence-return reciprocal closure",
        "must_reproduce": "C(ρ)=1/ρ",
        "status": "READY_AS_DERIVED_CONSTRAINT_TARGET",
    },
    {
        "term_id": "S_slot",
        "symbolic_form": "rank_allowed = 1 tangent + 3 normal slots",
        "role": "3+1 capacity filter",
        "must_reproduce": "denom(ρ) <= 4 for stable species",
        "status": "READY_AS_TOPOLOGICAL_CAPACITY_RULE",
    },
    {
        "term_id": "S_support_species_split",
        "symbolic_form": "support_domain != species_domain",
        "role": "virtual channel separation",
        "must_reproduce": "1/3, 3/5, 4/5 support-active but species-inactive",
        "status": "READY_AS_SEPARATION_AXIOM",
    },
]

blueprint_df = pd.DataFrame(blueprint_terms)

# ---------------------------------------------------------------------
# 5. Readiness tests.
# ---------------------------------------------------------------------

readiness_tests = [
    {
        "test": "operator_kernel_validated",
        "result": "PASS" if operator_kernel_validated else "WARN",
        "interpretation": "The frozen R104 operator kernel still selects the exact nine-mode seed.",
    },
    {
        "test": "virtual_supports_present_not_stable",
        "result": "PASS" if virtual_supports_present_not_stable else "WARN",
        "interpretation": "1/3, 3/5, and 4/5 remain support channels but not stable species.",
    },
    {
        "test": "main_intruder_excluded",
        "result": "PASS" if main_intruder_excluded else "WARN",
        "interpretation": "The main 7/4 intruder remains excluded by the joint support domain.",
    },
    {
        "test": "requirements_matrix_complete",
        "result": "PASS" if requirements_matrix_complete else "WARN",
        "interpretation": "R105 enumerates the minimum field/action/PDE requirements.",
    },
    {
        "test": "exact_but_smuggled_rejected",
        "result": "PASS" if exact_but_smuggled_rejected else "WARN",
        "interpretation": "Exact seed lookup and polynomial-root routes are rejected as smuggling.",
    },
    {
        "test": "best_candidate_is_blueprint",
        "result": "PASS" if best_candidate_is_blueprint else "WARN",
        "interpretation": "The best route is the coupled worldline-tube phase/boundary blueprint.",
    },
    {
        "test": "best_candidate_no_smuggling",
        "result": "PASS" if best_candidate_no_smuggling else "WARN",
        "interpretation": "The best route uses derived operator constraints rather than the seed list.",
    },
    {
        "test": "best_candidate_local_variational",
        "result": "PASS" if best_candidate_local_variational else "WARN",
        "interpretation": "The best route has local fields and a variational-action shape.",
    },
    {
        "test": "best_candidate_not_closed",
        "result": "PASS" if best_candidate_not_closed else "WARN",
        "interpretation": "The best route is correctly not claimed as a completed field/PDE derivation.",
    },
    {
        "test": "no_candidate_claims_closed",
        "result": "PASS" if no_candidate_claims_closed else "WARN",
        "interpretation": "No candidate route falsely claims the full field/action derivation is closed.",
    },
]

audit_df = pd.DataFrame(readiness_tests)

readiness_pass = all(audit_df["result"].isin(["PASS"]))

if readiness_pass:
    verdict_status = "FIELD/ACTION/PDE IMPLEMENTATION READINESS PASS / DERIVATION STILL OPEN"
elif operator_kernel_validated and best_candidate_is_blueprint:
    verdict_status = "FIELD/ACTION/PDE READINESS SIGNAL PASS / SOME GUARDRAILS OPEN"
else:
    verdict_status = "FIELD/ACTION/PDE IMPLEMENTATION READINESS INCONCLUSIVE"

# ---------------------------------------------------------------------
# 6. Claim boundary.
# ---------------------------------------------------------------------

claim_boundary = pd.DataFrame([
    {
        "claim": "R105 closes the field/action/PDE derivation.",
        "status": "NO",
        "reason": "R105 is a readiness and guardrail audit only.",
    },
    {
        "claim": "R105 identifies what a real field implementation must reproduce.",
        "status": "YES",
        "reason": "It enumerates anchor, map, support-domain, species-filter, locality, variational, and no-smuggling requirements.",
    },
    {
        "claim": "Exact seed lookup is an acceptable derivation.",
        "status": "NO",
        "reason": "Seed lookup and polynomial-root routes are rejected as target-smuggling.",
    },
    {
        "claim": "The best next implementation route is a coupled worldline-tube phase/boundary blueprint.",
        "status": "YES",
        "reason": "It is the highest-scoring no-smuggling local/variational route, but remains open.",
    },
    {
        "claim": "Virtual support channels are stable species.",
        "status": "NO",
        "reason": "1/3, 3/5, and 4/5 remain support-active but species-inactive.",
    },
    {
        "claim": "The nine-mode seed is a confirmed physical particle spectrum.",
        "status": "NO",
        "reason": "It remains a mechanical support seed until a physical field/action/mass bridge is derived.",
    },
    {
        "claim": "Masses, SM matching, or Omega0 are derived.",
        "status": "NO",
        "reason": "Those remain future-work items.",
    },
])

next_gate_plan = pd.DataFrame([
    {
        "next_gate": "FORCE_R106",
        "title": "Candidate Worldline-Tube Phase/Boundary Action Gate",
        "goal": "Write the first explicit no-smuggling action/constraint functional using phase, normal-frame, R-complement, and C-return terms.",
        "must_not_do": "Do not insert the nine seed modes or a polynomial with seed roots.",
    },
    {
        "next_gate": "FORCE_R107",
        "title": "Euler-Lagrange / Constraint Variation Gate",
        "goal": "Check whether the R106 functional actually yields the required stationarity/constraint equations.",
        "must_not_do": "Do not assume the constraints are equations of motion without variation.",
    },
    {
        "next_gate": "FORCE_R108",
        "title": "Locality and Gauge/Frame Relabeling Gate",
        "goal": "Verify that the action is local and invariant under allowed phase/frame relabelings.",
        "must_not_do": "Do not use a global ledger oracle as hidden dynamics.",
    },
    {
        "next_gate": "FORCE_R109",
        "title": "Species vs Support Projection Gate",
        "goal": "Derive the projection from support domain to stable species domain inside the field/action setup.",
        "must_not_do": "Do not delete virtual support modes by hand.",
    },
])

# Save artifacts.
requirements_df.to_csv(OUT / "FORCE_R105_field_implementation_requirements.csv", index=False)
candidate_df.to_csv(OUT / "FORCE_R105_candidate_route_scorecard.csv", index=False)
fake_solution_audit.to_csv(OUT / "FORCE_R105_fake_solution_rejection_audit.csv", index=False)
blueprint_df.to_csv(OUT / "FORCE_R105_candidate_action_blueprint_terms.csv", index=False)
audit_df.to_csv(OUT / "FORCE_R105_gate_audit.csv", index=False)
claim_boundary.to_csv(OUT / "FORCE_R105_claim_boundary_matrix.csv", index=False)
next_gate_plan.to_csv(OUT / "FORCE_R105_next_gate_plan.csv", index=False)

support_rows = []
for x in sorted(SEED | VIRTUAL_SUPPORTS | {Fraction(1, 4), Fraction(7, 4)}):
    r = R_map(x)
    c = C_map(x)

    support_rows.append({
        "rho_fraction": frac_label(x),
        "in_joint_domain": x in domain_full,
        "stable_species": x in stable_full,
        "binary_accept": binary_accept(x),
        "slot_accept": slot_accept(x),
        "R_partner": frac_label(r),
        "R_supported": True if r == 0 else r in domain_full,
        "C_partner": frac_label(c),
        "C_supported": in_interval(c) and c in domain_full,
        "role": (
            "stable_seed"
            if x in stable_full
            else (
                "virtual_support"
                if x in VIRTUAL_SUPPORTS
                else "rejected_control"
            )
        ),
    })

support_audit = pd.DataFrame(support_rows)
support_audit.to_csv(OUT / "FORCE_R105_support_species_projection_audit.csv", index=False)

verdict = {
    "force_id": "FORCE_R105",
    "title": "Field/Action/PDE Implementation Readiness Gate",
    "status": verdict_status,
    "operator_kernel_validated": operator_kernel_validated,
    "virtual_supports_present_not_stable": virtual_supports_present_not_stable,
    "main_intruder_excluded": main_intruder_excluded,
    "requirements_matrix_complete": requirements_matrix_complete,
    "exact_but_smuggled_rejected": exact_but_smuggled_rejected,
    "best_candidate_id": best_candidate_id,
    "best_candidate_is_blueprint": best_candidate_is_blueprint,
    "best_candidate_no_smuggling": best_candidate_no_smuggling,
    "best_candidate_local_variational": best_candidate_local_variational,
    "best_candidate_not_closed": best_candidate_not_closed,
    "no_candidate_claims_closed": no_candidate_claims_closed,
    "field_action_derivation_closed": False,
    "physical_spectrum_claimed": False,
    "recommended_next": "FORCE_R106_candidate_worldline_tube_phase_boundary_action_gate",
}
(OUT / "FORCE_R105_verdict.json").write_text(json.dumps(verdict, indent=2), encoding="utf-8")

summary = f"""# FORCE_R105 — Field/Action/PDE Implementation Readiness Gate

## Verdict

BOXED: {verdict_status}

## Central result

R105 does not solve the field/action/PDE derivation.

BOXED: R105 defines the guardrails for a real implementation.

A valid implementation must reproduce:

- primitive anchors: {{1,1/2,1/3}}
- reflection complement: R(rho)=2-rho
- reciprocal cadence return: C(rho)=1/rho
- joint support domain: D_RC({{1,1/2,1/3}})
- species filters: rho>=1/2 and denom(rho)<=4
- virtual support/species separation: 1/3, 3/5, 4/5 are support-active but not stable species
- no target-smuggling
- local field/action/PDE structure

## Operator kernel check

Selected stable seed:

BOXED: {label_set(stable_full)}

operator_kernel_validated: {operator_kernel_validated}

virtual_supports_present_not_stable: {virtual_supports_present_not_stable}

main_intruder_excluded: {main_intruder_excluded}

## Best route

BOXED: {best_candidate_id}

This route is a blueprint only. It is not a closed field derivation.

## Gate audit

{audit_df.to_string(index=False)}

## Requirements

{requirements_df.to_string(index=False)}

## Candidate route scorecard

{candidate_df.to_string(index=False)}

## Fake solution rejection audit

{fake_solution_audit.to_string(index=False)}

## Candidate action blueprint terms

{blueprint_df.to_string(index=False)}

## Support/species projection audit

{support_audit.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Next gate plan

{next_gate_plan.to_string(index=False)}

## Recommended next

BOXED: FORCE_R106 — Candidate Worldline-Tube Phase/Boundary Action Gate
"""
(OUT / "FORCE_R105_summary.md").write_text(summary, encoding="utf-8")

try:
    shutil.copy2(Path(__file__).resolve(), OUT / "FORCE_R105_field_action_PDE_implementation_readiness_gate.py")
except Exception:
    pass

manifest = pd.DataFrame([
    {"file": "FORCE_R105_summary.md", "role": "summary"},
    {"file": "FORCE_R105_verdict.json", "role": "machine-readable verdict"},
    {"file": "FORCE_R105_gate_audit.csv", "role": "gate audit"},
    {"file": "FORCE_R105_field_implementation_requirements.csv", "role": "field implementation requirements"},
    {"file": "FORCE_R105_candidate_route_scorecard.csv", "role": "candidate route scorecard"},
    {"file": "FORCE_R105_fake_solution_rejection_audit.csv", "role": "fake solution rejection audit"},
    {"file": "FORCE_R105_candidate_action_blueprint_terms.csv", "role": "candidate action blueprint terms"},
    {"file": "FORCE_R105_support_species_projection_audit.csv", "role": "support/species projection audit"},
    {"file": "FORCE_R105_claim_boundary_matrix.csv", "role": "claim boundary"},
    {"file": "FORCE_R105_next_gate_plan.csv", "role": "next gate plan"},
])
manifest.to_csv(OUT / "artifact_manifest.csv", index=False)

# Plots.
plt.figure(figsize=(12, 5))
plt.bar(candidate_df["candidate_id"], candidate_df["readiness_score"])
plt.xticks(rotation=40, ha="right")
plt.ylabel("readiness score")
plt.title("R105 candidate implementation route readiness")
plt.tight_layout()
plt.savefig(PLOTS / "candidate_route_readiness_scores.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
status_counts = candidate_df["route_status"].value_counts()
plt.bar(status_counts.index, status_counts.values)
plt.xticks(rotation=25, ha="right")
plt.ylabel("count")
plt.title("R105 route status counts")
plt.tight_layout()
plt.savefig(PLOTS / "route_status_counts.png", dpi=160)
plt.close()

if ZIP.exists():
    ZIP.unlink()

with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, arcname=str(p.relative_to(OUT.parent)))

with zipfile.ZipFile(ZIP, "r") as z:
    bad = z.testzip()

compact_candidates = candidate_df[[
    "candidate_id",
    "readiness_score",
    "exact_operator_reproduction",
    "no_target_smuggling",
    "locality_pass",
    "variational_ready",
    "PDE_ready",
    "field_derivation_closed",
    "smuggling_risk",
    "route_status",
    "expected_verdict",
]]

print("\n=== COPY/PASTE R105 RESULT ===")
print("R105 COMPLETE")
print(f"VERDICT: {verdict_status}")
print(f"ZIP_INTEGRITY: {'PASS' if bad is None else bad}")
print(f"operator_kernel_validated: {operator_kernel_validated}")
print(f"selected_seed: {label_set(stable_full)}")
print(f"virtual_supports_present_not_stable: {virtual_supports_present_not_stable}")
print(f"main_intruder_excluded: {main_intruder_excluded}")
print(f"requirements_matrix_complete: {requirements_matrix_complete}")
print(f"exact_but_smuggled_rejected: {exact_but_smuggled_rejected}")
print(f"best_candidate_id: {best_candidate_id}")
print(f"best_candidate_is_blueprint: {best_candidate_is_blueprint}")
print(f"best_candidate_no_smuggling: {best_candidate_no_smuggling}")
print(f"best_candidate_local_variational: {best_candidate_local_variational}")
print(f"best_candidate_not_closed: {best_candidate_not_closed}")
print(f"no_candidate_claims_closed: {no_candidate_claims_closed}")
print("AUDIT:")
print(audit_df.to_string(index=False))
print("FIELD_IMPLEMENTATION_REQUIREMENTS:")
print(requirements_df.to_string(index=False))
print("CANDIDATE_ROUTE_SCORECARD:")
print(compact_candidates.to_string(index=False))
print("FAKE_SOLUTION_REJECTION_AUDIT:")
print(fake_solution_audit.to_string(index=False))
print("CANDIDATE_ACTION_BLUEPRINT_TERMS:")
print(blueprint_df.to_string(index=False))
print("SUPPORT_SPECIES_PROJECTION_AUDIT:")
print(support_audit.to_string(index=False))
print("CLAIM_BOUNDARY:")
print(claim_boundary.to_string(index=False))
print("NEXT_GATE_PLAN:")
print(next_gate_plan.to_string(index=False))
print(f"PACK: {ZIP.resolve()}")
print(f"SUMMARY: {(OUT / 'FORCE_R105_summary.md').resolve()}")
print("NEXT: FORCE_R106_candidate_worldline_tube_phase_boundary_action_gate")
print("=== END COPY/PASTE R105 RESULT ===\n")
