from pathlib import Path
from fractions import Fraction
import hashlib
import html as html_lib
import json
import shutil
import textwrap
import zipfile
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd()
OUT = Path("FORCE_R115_V12_8_public_note_compile_gate")
ZIP = Path("SFT_V12_8_public_note_pack.zip")

if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)
PLOTS = OUT / "plots"
PLOTS.mkdir()

FREEZE_ID = "SFT_V12_8_OPERATOR_GEOMETRY_FREEZE"
PUBLIC_NOTE_TITLE = "Solvency Field Theory V12.8: Operator-Geometric Support-to-Species Seed Closure"

SEED = [
    Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(1, 1),
    Fraction(5, 4), Fraction(4, 3), Fraction(3, 2), Fraction(5, 3), Fraction(2, 1)
]

VIRTUAL_SUPPORTS = [Fraction(1, 3), Fraction(3, 5), Fraction(4, 5)]

def frac_label(x):
    return str(x) if isinstance(x, Fraction) else str(x)

def label_list(xs):
    return ", ".join(frac_label(x) for x in xs)

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

selected_seed = "{" + label_list(SEED) + "}"
canonical_formula = "Species = D_RC({1,1/2,1/3}) ∩ {rho >= 1/2} ∩ {denom(rho) <= 4}"

# ---------------------------------------------------------------------
# 1. Locate the R114 freeze pack if present.
# ---------------------------------------------------------------------

freeze_pack_candidates = []
for p in ROOT.rglob("SFT_V12_8_operator_geometry_freeze_pack.zip"):
    if OUT not in p.parents:
        freeze_pack_candidates.append(p)

freeze_pack_found = len(freeze_pack_candidates) > 0
freeze_pack_path = freeze_pack_candidates[0] if freeze_pack_found else None

freeze_pack_inventory = pd.DataFrame([
    {
        "freeze_pack_found": freeze_pack_found,
        "path": str(freeze_pack_path) if freeze_pack_path else "",
        "bytes": freeze_pack_path.stat().st_size if freeze_pack_path else 0,
        "sha256": sha256_file(freeze_pack_path) if freeze_pack_path else "",
    }
])

# ---------------------------------------------------------------------
# 2. Public-note ledger tables.
# ---------------------------------------------------------------------

gate_ledger = pd.DataFrame([
    {
        "gate": "R100",
        "public_role": "primitive anchors",
        "safe_status": "operator-origin candidate",
        "safe_sentence": "The primitive anchor set {1,1/2,1/3} is the minimal exact support-anchor set at operator level.",
    },
    {
        "gate": "R101",
        "public_role": "tri-normal support",
        "safe_status": "virtual support anchor",
        "safe_sentence": "The 1/3 channel is support-active but not stable-species-active.",
    },
    {
        "gate": "R102",
        "public_role": "reflection map",
        "safe_status": "operator map",
        "safe_sentence": "The reflection complement map is R(rho)=2-rho.",
    },
    {
        "gate": "R103",
        "public_role": "reciprocal map",
        "safe_status": "operator map",
        "safe_sentence": "The reciprocal cadence-return map is C(rho)=1/rho.",
    },
    {
        "gate": "R104",
        "public_role": "support domain",
        "safe_status": "support closure",
        "safe_sentence": "The joint R/C domain D_RC({1,1/2,1/3}) supplies support compatibility.",
    },
    {
        "gate": "R107",
        "public_role": "auxiliary variation",
        "safe_status": "partial variational support",
        "safe_sentence": "The R/C scalar auxiliary constraints have formal variational support.",
    },
    {
        "gate": "R108",
        "public_role": "local covariance",
        "safe_status": "blueprint covariance",
        "safe_sentence": "The blueprint passes local phase-gauge and normal-frame relabeling checks.",
    },
    {
        "gate": "R109",
        "public_role": "binary admissibility",
        "safe_status": "discrete KKT conditional",
        "safe_sentence": "Given binary write-cell width w=1/2, no-overlap gives rho>=1/2.",
    },
    {
        "gate": "R110",
        "public_role": "slot admissibility",
        "safe_status": "3+1 conditional geometry",
        "safe_sentence": "A 1D worldline in inherited 3+1 spacetime gives D_perp=3 and slot capacity 4.",
    },
    {
        "gate": "R111",
        "public_role": "species projection",
        "safe_status": "operator-geometric projection",
        "safe_sentence": "Stable species candidates are Support ∩ Binary ∩ Slot.",
    },
    {
        "gate": "R112",
        "public_role": "theorem-stack rollup",
        "safe_status": "closed operator-geometric stack",
        "safe_sentence": "The R100-R111 stack selects the exact nine-mode mechanical seed.",
    },
    {
        "gate": "R113",
        "public_role": "claim boundary",
        "safe_status": "paper-safe language",
        "safe_sentence": "The public claim boundary forbids upgrading the seed to a confirmed physical spectrum.",
    },
    {
        "gate": "R114",
        "public_role": "freeze pack",
        "safe_status": "frozen appendix package",
        "safe_sentence": "The appendix pack freezes the theorem ledger, formula, paper insert, and guardrails.",
    },
])

claim_boundary = pd.DataFrame([
    {
        "claim": "V12.8 closes an operator-geometric theorem stack.",
        "status": "YES",
        "public_wording": "V12.8 closes an operator-geometric support-to-species theorem stack selecting a nine-mode mechanical seed.",
    },
    {
        "claim": "The selected seed has exactly nine modes.",
        "status": "YES",
        "public_wording": f"The selected mechanical seed is {selected_seed}.",
    },
    {
        "claim": "Virtual supports are manually deleted.",
        "status": "NO",
        "public_wording": "Virtual supports fail admissibility filters while remaining support-active.",
    },
    {
        "claim": "V12.8 derives a confirmed physical particle spectrum.",
        "status": "NO",
        "public_wording": "Physical particle-spectrum identification remains open.",
    },
    {
        "claim": "V12.8 closes full PDE/action dynamics.",
        "status": "NO",
        "public_wording": "Full PDE/action dynamics remain open.",
    },
    {
        "claim": "V12.8 derives masses, Standard Model matching, or Omega0.",
        "status": "NO",
        "public_wording": "Mass hierarchy, Standard Model matching, and Omega0 remain open.",
    },
    {
        "claim": "V12.8 derives K=2 from scratch.",
        "status": "NO",
        "public_wording": "K=2 remains inherited from the binary no-overwrite predicate stack.",
    },
    {
        "claim": "V12.8 derives why spacetime is 3+1.",
        "status": "NO",
        "public_wording": "The 3+1 spacetime premise remains inherited.",
    },
])

open_problem_register = pd.DataFrame([
    {
        "open_item": "Full local PDE/action implementation",
        "status": "OPEN",
        "public_boundary": "The current result is operator-geometric, with partial variational support only.",
    },
    {
        "open_item": "Physical particle-spectrum identification",
        "status": "OPEN",
        "public_boundary": "The nine-mode set is a mechanical/operator-geometric seed.",
    },
    {
        "open_item": "Mass hierarchy and Standard Model matching",
        "status": "OPEN",
        "public_boundary": "No mass or Standard Model parameter matching is claimed.",
    },
    {
        "open_item": "Omega0",
        "status": "OPEN",
        "public_boundary": "Omega0 is outside the V12.8 result.",
    },
    {
        "open_item": "K=2 deeper origin",
        "status": "INHERITED",
        "public_boundary": "R109 derives rho>=1/2 conditional on binary write-cell width w=1/2.",
    },
    {
        "open_item": "3+1 spacetime deeper origin",
        "status": "INHERITED",
        "public_boundary": "R110 derives D_perp=3 conditional on inherited 3+1 spacetime.",
    },
    {
        "open_item": "Dynamic support-to-species PDE flow",
        "status": "OPEN",
        "public_boundary": "R111 closes projection logically/operator-geometrically, not dynamically.",
    },
])

overclaim_guardrails = pd.DataFrame([
    {
        "prohibited": "V12.8 derives the physical particle spectrum.",
        "safe": "V12.8 selects a nine-mode mechanical/operator-geometric seed.",
    },
    {
        "prohibited": "V12.8 derives the Standard Model.",
        "safe": "V12.8 provides an operator-geometric support scaffold for future physical matching.",
    },
    {
        "prohibited": "V12.8 derives particle masses.",
        "safe": "Mass hierarchy and parameter matching remain open.",
    },
    {
        "prohibited": "V12.8 predicts Omega0.",
        "safe": "Omega0 is not addressed by V12.8.",
    },
    {
        "prohibited": "V12.8 closes full PDE/action dynamics.",
        "safe": "Full PDE/action dynamics remain open.",
    },
    {
        "prohibited": "V12.8 derives K=2 from scratch.",
        "safe": "K=2 remains inherited.",
    },
    {
        "prohibited": "V12.8 derives why spacetime is 3+1.",
        "safe": "The 3+1 premise remains inherited.",
    },
])

# ---------------------------------------------------------------------
# 3. Public note Markdown.
# ---------------------------------------------------------------------

public_note_md = ""# {PUBLIC_NOTE_TITLE}

**Freeze ID:** `{FREEZE_ID}`

## Abstract

This note records the V12.8 operator-geometric support-to-species closure result in Solvency Field Theory. Starting from the primitive support anchors `{{1, 1/2, 1/3}}`, together with the reflection map `R(rho)=2-rho` and reciprocal cadence-return map `C(rho)=1/rho`, the joint R/C support domain is projected through binary no-overlap admissibility and 3+1 worldline-tube slot admissibility. The result is a nine-mode mechanical/operator-geometric seed,

`{selected_seed}`.

This note does not identify the seed with a confirmed physical particle spectrum. Full PDE/action dynamics, physical species identification, mass hierarchy, Standard Model matching, Omega0, the deeper origin of K=2, and the deeper origin of 3+1 spacetime remain open.

## 1. Claim Boundary

The public V12.8 claim is:

> V12.8 closes an operator-geometric theorem stack selecting a nine-mode mechanical seed.

The public V12.8 claim is not:

> a completed physical particle-spectrum derivation, a complete local PDE/action theory, a mass hierarchy derivation, a Standard Model matching derivation, or an Omega0 prediction.

## 2. Primitive Anchors and Closure Maps

The primitive support anchors are

```text
A = {{1, 1/2, 1/3}}.
