# FORCE_R102 — Reflection Complement Map Origin Gate

## Verdict

BOXED: REFLECTION COMPLEMENT MAP ORIGIN PASS / FIELD-ACTION DERIVATION STILL OPEN

## Central result

R102 tests the origin of the reflection map:

BOXED: R(rho)=2-rho

Candidate origin:

BOXED: R is complement/reflection on the doubled closure interval [0,2].

## Why T=2?

In the family R_T(rho)=T-rho, the following all force T=2:

- R_T(1)=1
- R_T(2)=0_boundary
- R_T(3/2)=1/2
- R_T(5/3)=1/3

## Key booleans

- two_complement_exact_seed: True
- controls_fail: True
- T2_unique_exact_in_scan: True
- T2_satisfies_all_axioms: True
- identity_fixed_forces_T2: True
- endpoint_boundary_forces_T2: True
- binary_high_support_forces_T2: True
- trinormal_high_support_forces_T2: True

## Gate audit

                            test result                                                                                                    interpretation
       two_complement_exact_seed   PASS                                               R(rho)=2-rho with reciprocal closure recovers the exact V12.7 seed.
                   controls_fail   PASS          No-reflection, identity, wrong-T complements, scaled bad affine, and duplicate-reciprocal controls fail.
         T2_unique_exact_in_scan   PASS                                               Among tested complement totals T, only T=2 recovers the exact seed.
        identity_fixed_forces_T2   PASS                                                                                              R_T(1)=1 forces T=2.
     endpoint_boundary_forces_T2   PASS                                                                                     R_T(2)=0_boundary forces T=2.
   binary_high_support_forces_T2   PASS                                                                                          R_T(3/2)=1/2 forces T=2.
trinormal_high_support_forces_T2   PASS                                                                                          R_T(5/3)=1/3 forces T=2.
         T2_satisfies_all_axioms   PASS T=2 is involutive, fixes identity, sends endpoint to boundary, and supplies binary/tri-normal complement support.
         field_action_derivation   OPEN            R102 supports the reflection-complement map at operator level; it is not a full PDE/action derivation.

## Reflection model scorecard

                          model                                           description      R_kind    T  support_domain_count_final  stable_count_final                  stable_fractions_final  exact_seed_all_denominators extra_vs_seed            missing_from_seed  boundary_used_final                   expected                 survivor_status
        R0_no_reflection_C_only      No reflection map; only reciprocal closure acts.        none none                           4                   3                               1/2, 1, 2                        False          none 2/3, 3/4, 5/4, 4/3, 3/2, 5/3                False           FAIL_SIGNAL_LOST PASS_CONTROL_FAILED_AS_EXPECTED
      R1_identity_no_complement               Identity map R(rho)=rho; no complement.    identity none                           4                   3                               1/2, 1, 2                        False          none 2/3, 3/4, 5/4, 4/3, 3/2, 5/3                False           FAIL_SIGNAL_LOST PASS_CONTROL_FAILED_AS_EXPECTED
          R2_unit_complement_T1                         Unit complement R(rho)=1-rho. T_minus_rho    1                           6                   5                     1/2, 2/3, 1, 3/2, 2                        False          none           3/4, 5/4, 4/3, 5/3                 True             FAIL_TOO_SMALL PASS_CONTROL_FAILED_AS_EXPECTED
R3_three_halves_complement_T3_2               Intermediate complement R(rho)=3/2-rho. T_minus_rho  3/2                           8                   3                               1/2, 1, 2                        False          none 2/3, 3/4, 5/4, 4/3, 3/2, 5/3                False             FAIL_TOO_SMALL PASS_CONTROL_FAILED_AS_EXPECTED
           R4_two_complement_T2   Candidate doubled-boundary complement R(rho)=2-rho. T_minus_rho    2                          94                   9 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2                         True          none                         none                 True            PASS_EXACT_SEED                 PASS_EXACT_SEED
 R5_five_halves_complement_T5_2                  Oversized complement R(rho)=5/2-rho. T_minus_rho  5/2                           9                   5                     1/2, 2/3, 1, 3/2, 2                        False          none           3/4, 5/4, 4/3, 5/3                False          FAIL_WRONG_DOMAIN PASS_CONTROL_FAILED_AS_EXPECTED
         R6_three_complement_T3                        Large complement R(rho)=3-rho. T_minus_rho    3                           4                   3                               1/2, 1, 2                        False          none 2/3, 3/4, 5/4, 4/3, 3/2, 5/3                False          FAIL_WRONG_DOMAIN PASS_CONTROL_FAILED_AS_EXPECTED
     R7_scaled_bad_2_minus_2rho                     Bad affine control R(rho)=2-2rho.  bad_affine none                           6                   5                     1/2, 3/4, 1, 4/3, 2                        False          none           2/3, 5/4, 3/2, 5/3                 True FAIL_NON_INVOLUTIVE_SIGNAL PASS_CONTROL_FAILED_AS_EXPECTED
        R8_reciprocal_duplicate Bad control: reflection duplicated by reciprocal map. duplicate_C none                           4                   3                               1/2, 1, 2                        False          none 2/3, 3/4, 5/4, 4/3, 3/2, 5/3                False           FAIL_SIGNAL_LOST PASS_CONTROL_FAILED_AS_EXPECTED

## Complement T axiom scan

  T R_formula  support_domain_count  stable_count                        stable_fractions  exact_seed  identity_fixed_R1_eq_1  endpoint_R2_eq_0_boundary  binary_high_R3_2_eq_1_2  trinormal_high_R5_3_eq_1_3  involutive_sample_pass  axiom_count extra_vs_seed            missing_from_seed
  2   2 - rho                    94             9 1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2        True                    True                       True                     True                        True                    True            6          none                         none
  1   1 - rho                     6             5                     1/2, 2/3, 1, 3/2, 2       False                   False                      False                    False                       False                    True            1          none           3/4, 5/4, 4/3, 5/3
4/3 4/3 - rho                     7             3                               1/2, 1, 2       False                   False                      False                    False                       False                    True            1          none 2/3, 3/4, 5/4, 4/3, 3/2, 5/3
3/2 3/2 - rho                     8             3                               1/2, 1, 2       False                   False                      False                    False                       False                    True            1          none 2/3, 3/4, 5/4, 4/3, 3/2, 5/3
5/3 5/3 - rho                    15             7           1/2, 2/3, 3/4, 1, 4/3, 3/2, 2       False                   False                      False                    False                       False                    True            1          none                     5/4, 5/3
7/3 7/3 - rho                    10             5                     1/2, 3/4, 1, 4/3, 2       False                   False                      False                    False                       False                    True            1          none           2/3, 5/4, 3/2, 5/3
5/2 5/2 - rho                     9             5                     1/2, 2/3, 1, 3/2, 2       False                   False                      False                    False                       False                    True            1          none           3/4, 5/4, 4/3, 5/3
  3   3 - rho                     4             3                               1/2, 1, 2       False                   False                      False                    False                       False                    True            1          none 2/3, 3/4, 5/4, 4/3, 3/2, 5/3

## Support truth table

rho_fraction      rho  denominator  in_R2_joint_domain  binary_accept  slot_accept  stable_candidate R2_partner  R2_supported C_partner  C_supported  seed_member                        role
         1/4 0.250000            4               False          False         True             False        7/4         False         4        False        False support_or_rejected_control
         1/3 0.333333            3                True          False         True             False        5/3          True         3        False        False   tri_normal_virtual_anchor
         1/2 0.500000            2                True           True         True              True        3/2          True         2         True         True                 stable_seed
         2/3 0.666667            3                True           True         True              True        4/3          True       3/2         True         True                 stable_seed
         3/4 0.750000            4                True           True         True              True        5/4          True       4/3         True         True                 stable_seed
           1 1.000000            1                True           True         True              True          1          True         1         True         True                 stable_seed
         5/4 1.250000            4                True           True         True              True        3/4          True       4/5         True         True                 stable_seed
         4/3 1.333333            3                True           True         True              True        2/3          True       3/4         True         True                 stable_seed
         3/2 1.500000            2                True           True         True              True        1/2          True       2/3         True         True                 stable_seed
         5/3 1.666667            3                True           True         True              True        1/3          True       3/5         True         True                 stable_seed
         7/4 1.750000            4               False           True         True             False        1/4         False       4/7        False        False  boundary_rejected_intruder
           2 2.000000            1                True           True         True              True 0_boundary          True       1/2         True         True                 stable_seed

## Claim boundary

                                                          claim status                                                                                                             reason
R(rho)=2-rho has an operator-level complement-origin candidate.    YES T=2 is the unique tested complement total satisfying exact seed recovery and the identity/boundary/support axioms.
                               The reflection map is arbitrary.     NO                                                          Wrong complement totals and non-complement controls fail.
                                  R fixes the identity cadence.    YES                                                                                                            R(1)=1.
          R closes the high endpoint against the zero boundary.    YES                                                                                                   R(2)=0_boundary.
              R supplies tri-normal complement support for 5/3.    YES                                                                                                        R(5/3)=1/3.
                  R supplies binary complement support for 3/2.    YES                                                                                                        R(3/2)=1/2.
                   The full field/action origin of R is solved.     NO                                        R102 is an operator/geometric complement gate, not a PDE/action derivation.
               The reciprocal map C(rho)=1/rho is derived here.     NO                            R102 uses C as the already frozen reciprocal closure branch; R103 should test C origin.

## Theorem candidate

 layer                                                          statement         status
     1             Closure reflection is a complement map R_T(rho)=T-rho.   MODEL_FAMILY
     2                     Identity/base cadence must be fixed: R_T(1)=1.  FORCES_T_EQ_2
     3         Endpoint 2 closes to the zero boundary: R_T(2)=0_boundary.  FORCES_T_EQ_2
     4         Binary high partner closes to binary anchor: R_T(3/2)=1/2.  FORCES_T_EQ_2
     5 Tri-normal high partner closes to tri-normal anchor: R_T(5/3)=1/3.  FORCES_T_EQ_2
     6                                    Therefore T=2 and R(rho)=2-rho. CANDIDATE_PASS
     7                     Full field/action implementation remains open.           OPEN

## Remaining open item

R102 supports the reflection map at operator/geometric complement level.
It does not derive the full field/action implementation, and it does not derive C(rho)=1/rho.

## Recommended next

BOXED: FORCE_R103 — Reciprocal Cadence-Return Map Origin Gate
