#!/usr/bin/env python3
from __future__ import annotations
import subprocess, sys
from pathlib import Path

here = Path(__file__).resolve().parent
scripts = sorted(p for p in here.glob("*.py") if p.name != Path(__file__).name)
print(f"Found {len(scripts)} repro scripts")
failures = []
for p in scripts:
    print("\n" + "="*80)
    print(f"RUNNING: {p.name}")
    print("="*80)
    r = subprocess.run([sys.executable, str(p)], cwd=str(here), text=True, capture_output=True, timeout=60)
    if r.stdout:
        print(r.stdout)
    if r.stderr:
        print("STDERR:")
        print(r.stderr)
    if r.returncode:
        failures.append((p.name, r.returncode))
        print(f"FAILED: {p.name} returncode={r.returncode}")
    else:
        print(f"PASS: {p.name}")
print("\n" + "="*80)
if failures:
    print("Some scripts failed:")
    for name, err in failures:
        print(f"- {name}: {err}")
    sys.exit(1)
print("All scripts completed.")
