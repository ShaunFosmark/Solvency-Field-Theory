#!/usr/bin/env python3
"""R270R: effective diffusion from one-speed write rate times half-Compton closure radius.

D_eff = c * r_spin = c * hbar/(2mc) = hbar/(2m)
"""
from __future__ import annotations
import math

hbar = 1.054571817e-34
c = 299792458.0
masses = {
    "electron": 9.1093837139e-31,
    "muon": 1.883531627e-28,
    "proton": 1.67262192595e-27,
}
print("particle,m_kg,r_spin_m,D_eff_m2_s,hbar_over_2m")
for name, m in masses.items():
    r_spin = hbar/(2*m*c)
    D_eff = c*r_spin
    target = hbar/(2*m)
    print(f"{name},{m:.12e},{r_spin:.12e},{D_eff:.12e},{target:.12e}")
