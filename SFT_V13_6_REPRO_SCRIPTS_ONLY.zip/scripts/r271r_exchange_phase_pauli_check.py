#!/usr/bin/env python3
"""R271R: exchange phase -> same-state intensity -> write hazard."""
from __future__ import annotations

cases = [("fermion_4pi_closure", -1), ("boson_2pi_closure", +1)]
print("case,exchange_phase,same_state_amplitude_condition,same_state_intensity,write_hazard")
for name, phase in cases:
    if phase == -1:
        amp = "Psi(q,q)=-Psi(q,q)->0"
        intensity = "0"
        hazard = "0"
    else:
        amp = "Phi(q,q)=+Phi(q,q)->nonzero_allowed"
        intensity = "nonzero_allowed"
        hazard = "nonzero_allowed"
    print(f"{name},{phase},{amp},{intensity},{hazard}")
