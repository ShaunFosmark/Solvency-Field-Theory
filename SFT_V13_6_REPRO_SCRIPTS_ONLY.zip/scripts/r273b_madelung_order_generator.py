#!/usr/bin/env python3
"""R273B: Madelung/Aufbau skeleton from settlement tax (n+l, then lower n)."""
from __future__ import annotations

names = {0:"s", 1:"p", 2:"d", 3:"f"}
def cap(l): return 2*(2*l+1)
def label(n,l): return f"{n}{names[l]}"

subs = []
for n in range(1, 9):
    for l in range(0, min(n, 4)):
        subs.append((n+l, n, l, label(n,l), cap(l)))
subs.sort(key=lambda x: (x[0], x[1]))

Z = 0
print("order,subshell,n,l,n_plus_l,capacity,Z_start,Z_end")
for i, (tax, n, l, lab, c) in enumerate(subs, 1):
    if Z >= 118:
        break
    start = Z + 1
    fill = min(c, 118-Z)
    Z += fill
    print(f"{i},{lab},{n},{l},{tax},{c},{start},{Z}")
