#!/usr/bin/env python3
"""R274A: bonding versus antibonding midpoint toy."""
from __future__ import annotations

print("a,bonding_amp,bonding_intensity,antibonding_amp,antibonding_intensity")
for a in [0.1, 0.25, 0.5, 1.0]:
    bonding = a + a
    antibonding = a - a
    print(f"{a},{bonding},{bonding*bonding},{antibonding},{antibonding*antibonding}")
