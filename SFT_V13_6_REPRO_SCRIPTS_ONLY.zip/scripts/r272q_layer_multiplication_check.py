#!/usr/bin/env python3
"""R272Q: repeated layer attenuation multiplies into an exponential."""
from __future__ import annotations
import math

print("r_per_layer,N,amplitude,intensity,effective_exp_amplitude")
for r in [0.9, 0.75, 0.5, 0.25]:
    for N in [1, 2, 5, 10, 20]:
        A = r**N
        I = A*A
        eff = math.exp(N*math.log(r))
        print(f"{r},{N},{A:.8e},{I:.8e},{eff:.8e}")
print("\nMapping: r^N = exp(N ln r) = exp(-kappa d), with d=N*dx.")
