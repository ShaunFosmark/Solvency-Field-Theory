#!/usr/bin/env python3
"""R274A: H2 overlap toy using 1s Slater overlap form.

S(rho)=exp(-rho)*(1+rho+rho^2/3), rho=R/a0.
This is a correspondence toy, not a numerical SFT bond derivation.
"""
from __future__ import annotations
import math

a0_pm = 52.9177210903
def overlap(rho: float) -> float:
    return math.exp(-rho)*(1 + rho + rho*rho/3)

print("R_pm,rho_R_over_a0,overlap_S,overlap_intensity_S2")
for R_pm in [30, 50, 74, 100, 150, 200, 300, 500]:
    rho = R_pm/a0_pm
    S = overlap(rho)
    print(f"{R_pm:.3f},{rho:.6f},{S:.9e},{S*S:.9e}")
