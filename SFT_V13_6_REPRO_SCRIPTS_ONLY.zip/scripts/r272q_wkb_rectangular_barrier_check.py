#!/usr/bin/env python3
"""R272Q: WKB rectangular barrier check.

T ≈ exp(-2 kappa d), kappa = sqrt(2m(V-E))/hbar.
"""
from __future__ import annotations
import math

hbar = 1.054571817e-34
m_e = 9.1093837139e-31
eV = 1.602176634e-19

def t_wkb(m, v_minus_e_ev, d_nm):
    delta = v_minus_e_ev * eV
    d = d_nm * 1e-9
    kappa = math.sqrt(2*m*delta)/hbar
    exponent = -2*kappa*d
    return kappa, exponent, math.exp(exponent) if exponent > -745 else 0.0

print("particle,VminusE_eV,width_nm,kappa_1_m,exponent,T_wkb")
for Vme in [0.1, 0.5, 1.0, 3.0]:
    for d in [0.5, 1.0, 2.0, 5.0]:
        k, ex, T = t_wkb(m_e, Vme, d)
        print(f"electron,{Vme},{d},{k:.6e},{ex:.6e},{T:.6e}")
