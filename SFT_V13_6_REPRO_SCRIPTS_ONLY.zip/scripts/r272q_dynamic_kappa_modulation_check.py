#!/usr/bin/env python3
"""R272Q: dynamic kappa modulation as real-material enhancement/suppression."""
from __future__ import annotations
import math

d_nm = 1.0
d = d_nm * 1e-9
print("delta_kappa_1_m,width_nm,I_ratio")
for dk in [-2e9, -1e9, -5e8, 0.0, 5e8, 1e9, 2e9]:
    ratio = math.exp(-2*dk*d)
    print(f"{dk:.6e},{d_nm},{ratio:.6e}")
print("\ndelta_kappa < 0 enhances tunneling; delta_kappa > 0 suppresses it.")
