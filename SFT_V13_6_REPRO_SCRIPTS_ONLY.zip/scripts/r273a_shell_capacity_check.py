#!/usr/bin/env python3
"""R273A: shell and subshell capacity from Pauli address classes."""
from __future__ import annotations

names = {0:"s", 1:"p", 2:"d", 3:"f", 4:"g", 5:"h", 6:"i"}
def subshell_capacity(l: int) -> int:
    return 2*(2*l+1)
def shell_capacity(n: int) -> int:
    return sum(subshell_capacity(l) for l in range(n))

print("subshell capacities")
print("l,subshell,capacity")
for l in range(7):
    print(f"{l},{names.get(l, 'l'+str(l))},{subshell_capacity(l)}")
print("\nshell capacities")
print("n,capacity,2n^2")
for n in range(1, 9):
    print(f"{n},{shell_capacity(n)},{2*n*n}")
