#!/usr/bin/env python3
"""R275Q: print V13.6 gate ledger."""
from __future__ import annotations

rows = [
    ("R270Q/R270R", "Uncertainty", "D_eff = c r_spin = hbar/(2m)"),
    ("R271Q/R271R", "Pauli", "zero same-state settlement intensity/hazard"),
    ("R272Q", "Tunneling", "evanescent trans-barrier intensity"),
    ("R273A", "Shell capacity", "2(2l+1), 2n^2"),
    ("R273B", "Aufbau skeleton", "n+l settlement tax"),
    ("R274A", "First bond", "H2 shared settlement basin"),
]
print("SFT V13.6 Quantum-to-Chemistry Rollup")
for gate, title, kernel in rows:
    print(f"{gate}: {title} — {kernel}")
print("\nFreeze status: PARTIAL_PASS_MECHANISM_STACK")
