# SFT V13.6 Repro Scripts Only

Generated: 2026-07-02 22:34:34

Lightweight scripts-only repro pack for the V13.6 quantum-to-chemistry run.

Includes:
- R270R effective diffusion closure check
- R271R Pauli/exchange phase check
- R272Q tunneling WKB/layer/dynamic modulation checks
- R273A shell capacity check
- R273B Aufbau/Madelung skeleton generator
- R274A H2 overlap and bonding/antibonding toys
- R275Q gate ledger printer
- all-script runner

Run:

```bash
python scripts/run_all_v13_6_repro_scripts.py
```
