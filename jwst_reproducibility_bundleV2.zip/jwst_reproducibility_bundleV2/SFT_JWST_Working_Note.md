# SFT Working Note: JWST Early Massive Galaxies
## MOND-Like Weak-Field Enhancement and Bottom-Up Structure Formation
### Status: Internal working note for 5.4 collaboration
### Date: March 31, 2026

---

## 1. The Problem

JWST has discovered galaxies at z > 10 that are too massive, too chemically evolved,
and too dust-rich for ΛCDM to explain within the available cosmic time. Key objects:

| Object | Redshift | Stellar Mass (M☉) | SFR (M☉/yr) | Notes |
|--------|----------|-------------------|-------------|-------|
| EGS-z11-R0 (CEERS) | 11.45 | 1.6–4 × 10⁹ | 10–40 | Red, dusty, sustained SF |
| JADES-GS-z13-1 | ~13.2 | ~10⁸–10⁹ | high | One of earliest confirmed |
| JADES high-z candidates (6 new) | >11 | log M* 7.75–8.75 | sSFR 0.95–1.46 Gyr⁻¹ | Dust-poor to moderate |

The standard ΛCDM problem: at z = 13.2, the universe is ~320 Myr old. Building
10⁹ M☉ of stars in that time requires extremely efficient star formation in
pre-built dark matter halos — but the halos themselves take time to assemble.

---

## 2. What We Tested

### 2.1 Age Mechanism — NEGATIVE RESULT

We computed the age of the universe at high redshift in both ΛCDM and SFT bimodal
(w₀ = −0.837, wₐ = −0.615). Result: essentially identical.

| z | Age ΛCDM | Age SFT | Difference |
|---|----------|---------|------------|
| 10.00 | 470.1 Myr | 470.2 Myr | +0.1 Myr (+0.02%) |
| 11.45 | 390.2 Myr | 390.3 Myr | +0.1 Myr (+0.02%) |
| 13.20 | 320.2 Myr | 320.2 Myr | +0.0 Myr (+0.01%) |
| 14.00 | 294.8 Myr | 294.8 Myr | +0.0 Myr (+0.01%) |

**Conclusion: SFT's late-time dark energy modifications do not affect the
high-redshift timeline. The bimodal w(z) is irrelevant at z > 10 because
the universe is matter/radiation dominated at those epochs.**

Additionally, the recombination handoff shifts H₀ UP, which makes the
universe YOUNGER at each redshift — making the problem worse, not better.

**SFT does NOT solve the JWST early galaxy problem through the age mechanism.**

### 2.2 MOND-Like Enhancement — POSITIVE SIGNAL

SFT predicts a weak-field acceleration threshold a_SFT = cH₀/(2π) ≈ 1.05 × 10⁻¹⁰ m/s².
Below this acceleration, gravity is effectively enhanced (MOND-like regime).

The key question: at z > 10, the first baryonic overdensities are extremely
diffuse. Their internal gravitational accelerations are far below a_SFT.
Does the MOND enhancement compensate for losing dark matter's 6.4× gravitational
mass advantage?

**Results at z = 20:**

| M_gas (M☉) | g_N/a_SFT | MOND enhancement | DM factor (ΛCDM) | SFT/ΛCDM free-fall |
|------------|-----------|-----------------|-------------------|-------------------|
| 10⁶ | 0.0026 | 19.8× | 6.4× | 0.81 (SFT faster) |
| 10⁷ | 0.0055 | 13.5× | 6.4× | 0.98 (roughly equal) |
| 10⁸ | 0.012 | 9.2× | 6.4× | 1.18 (ΛCDM faster) |
| 10⁹ | 0.026 | 6.3× | 6.4× | 1.43 (ΛCDM faster) |

**Crossover mass: ~10⁵ M☉** (where MOND enhancement of 29× exceeds DM factor of 6.4×)

### 2.3 Free-Fall Timescale Comparison

| M_gas (M☉) | t_ff ΛCDM | t_ff SFT | SFT/ΛCDM | Which is faster? |
|------------|-----------|----------|-----------|-----------------|
| 10⁶ | 127.2 Myr | 102.5 Myr | 0.81 | **SFT** |
| 10⁷ | 127.2 Myr | 124.2 Myr | 0.98 | **SFT** (barely) |
| 10⁸ | 127.2 Myr | 150.5 Myr | 1.18 | ΛCDM |
| 10⁹ | 127.2 Myr | 182.3 Myr | 1.43 | ΛCDM |

---

## 3. Interpretation: Inverted Structure Formation Hierarchy

The numbers reveal a qualitatively different structure formation pathway:

**ΛCDM (top-down):**
- Dark matter halos form first through gravitational collapse
- DM provides 6.4× gravitational mass advantage at ALL scales
- Baryons fall into pre-built DM potential wells
- Large structures form relatively quickly because DM doesn't need to cool
- Formation is "scaffolding first, then fill"

**SFT (bottom-up):**
- No dark matter scaffolding exists
- Small baryonic clouds (10⁵ – 10⁷ M☉) collapse FASTER than in ΛCDM
  because the MOND enhancement (13–29×) exceeds the lost DM factor (6.4×)
- These small structures merge rapidly into larger ones
- Massive galaxies are ASSEMBLED from quickly-formed building blocks
- Formation is "small pieces fast, then merge"

The crossover at ~10⁷ M☉ means:
- Below 10⁷: SFT forms structure faster
- Above 10⁷: ΛCDM forms structure faster
- Massive galaxies at z > 10 in SFT arise from rapid merging of sub-10⁷ clumps

---

## 4. Observable Predictions (Qualitative)

If the SFT bottom-up picture is correct, JWST galaxies at z > 10 should show:

1. **Clumpy morphologies** — assembled from merging sub-units, not smooth
   monolithic profiles expected from formation inside a single large DM halo

2. **Evidence of recent merging** — tidal features, multiple nuclei, disturbed
   kinematics at high redshift

3. **Stellar population gradients** — different clumps may have slightly different
   ages if they formed independently before merging

4. **Lower dark-matter-to-baryon ratios than ΛCDM predicts** — since there is no
   DM in SFT, the dynamical mass should be closer to the baryonic mass
   (modified by the MOND enhancement)

5. **A mass function that favors rapid assembly** — more intermediate-mass
   building blocks (10⁶–10⁷ M☉) at z > 15 than ΛCDM predicts

These are qualitative predictions. Quantifying them requires the perturbation
extension (V8 Section 14.7).

---

## 5. What This Does NOT Show

This analysis has significant limitations that must be stated clearly:

- **Free-fall timescale ≠ galaxy formation time.** Real galaxy formation
  involves gas cooling, angular momentum, feedback, magnetic fields,
  radiation pressure, and chemical evolution. Free-fall is a necessary
  condition for collapse but not sufficient for galaxy formation.

- **Merger rate is not computed.** The bottom-up picture requires rapid
  merging of small structures into massive ones. The actual merger rate
  depends on the spatial distribution, relative velocities, and dynamical
  friction timescales — none of which are computed here.

- **The interpolating function is borrowed.** We use ν(x) = (1 − e^{−√x})⁻¹
  from MOND phenomenology. Whether this specific function applies at z > 10
  in primordial baryonic conditions is not established.

- **No N-body simulation exists.** The bottom-up versus top-down distinction
  is a qualitative prediction that can only be quantified through N-body
  simulations with MOND-like gravity. This is listed as an open problem
  in V8 Section 14.7.

- **The deep-MOND regime may not apply at z > 10 in the same way it
  applies at z = 0.** The acceleration threshold a_SFT = cH₀/(2π) uses
  the present-day H₀. At z = 20, H(z) is much larger. Whether the
  threshold should use H₀ or H(z) is an open question. If a_SFT scales
  with H(z), the enhancement would be larger at high z (because H is larger,
  so a_SFT is larger, and more structures are in the deep-MOND regime).

---

## 6. Honest Position Statement

**What SFT can claim:**
SFT's MOND-like weak-field enhancement produces faster gravitational collapse
for small baryonic structures (10⁵ – 10⁷ M☉) at high redshift, potentially
enabling rapid bottom-up assembly of massive galaxies through merging rather
than top-down formation in dark matter halos.

**What SFT cannot claim (yet):**
That this mechanism quantitatively explains the specific JWST objects.
The qualitative picture is promising but the quantitative calculation
requires N-body simulations with MOND-like gravity that do not yet exist.

**Recommended framing for external communication:**
"SFT does not address the JWST early galaxy problem through the age mechanism —
the expansion history at z > 10 is essentially identical to ΛCDM. However,
SFT's MOND-like weak-field enhancement produces faster gravitational collapse
for small baryonic structures, potentially enabling rapid bottom-up assembly
of massive galaxies through merging. Whether this mechanism quantitatively
accounts for the observed objects is an open question requiring N-body
simulations with MOND-like gravity."

---

## 7. Questions for 5.4

1. **Should a_SFT use H₀ or H(z) at high redshift?** If the threshold scales
   with H(z), the MOND enhancement at z = 20 would be much larger (H(z=20) ≈
   70 × H₀ in matter domination). This could dramatically change the crossover
   mass and the free-fall timescale comparison.

2. **Can the perturbation growth equation be modified with the MOND-like term?**
   Instead of δ̈ + 2Hδ̇ = 4πGρδ (standard), test δ̈ + 2Hδ̇ = 4πG_eff(δ)ρδ
   where G_eff includes the MOND enhancement for low-acceleration perturbations.
   This would give a linear growth rate comparison without needing full N-body.

3. **What does the mass function look like?** If small structures form faster
   in SFT, the halo mass function at z > 10 should be bottom-heavy compared
   to ΛCDM (more small halos, fewer large ones at a given epoch). Is there
   a simple Press-Schechter-like estimate that could capture this?

4. **Can the merger timescale be estimated?** For a population of 10⁶ M☉
   clumps at z = 20, how quickly do they merge into a 10⁹ M☉ galaxy?
   This is the rate-limiting step of the bottom-up picture.

---

## 8. Connection to V8

This analysis connects to V8 in several ways:

- **Section 4 (SPARC confirmation):** The same a_SFT = cH₀/(2π) that matches
  137 nearby galaxies also governs the weak-field enhancement at high redshift.
  The galactic and cosmological applications use the same parameter.

- **Section 12 (Strong-field closure):** At high compactness, SFT recovers GR.
  At low compactness (early, diffuse clouds), the MOND enhancement activates.
  The JWST analysis is the opposite limit of the same compactness spectrum.

- **Section 14.7 (Beyond FLRW minisuperspace):** The perturbation extension
  needed to quantify the bottom-up formation pathway is explicitly listed
  as an open problem. This working note provides the motivation and the
  specific calculation targets for that extension.

---

*Working note prepared for internal collaboration. Not for publication
without quantitative follow-up.*
