Recombination Handoff Zenodo Bundle
===================================

This bundle packages the key companion-note artifacts for the SFT recombination-handoff analysis.

Included files
--------------
1. The_Recombination_Handoff_Companion_Note_DRAFT.md
   Standalone narrative companion-note draft.

2. camb_handoff_summary.txt / .csv
   CAMB-based physical-kernel stage.

3. camb_composite_summary.txt / .csv
   Composite physical-kernel stage.

4. camb_shifted_summary.txt / .csv
   Shifted-and-broadened composite stage.

5. camb_v6_refine_summary.txt / .csv
   Local refinement around the winning family.

6. camb_v7_strict_confirm_summary.txt / .csv
   Strict-band confirmation stage.

7. camb_v7_strict_confirm_strict.csv
   Final strict-band table.

8. camb_handoff_ranked_by_H0.csv
   Ranked CAMB physical-kernel results.

9. camb_composite_ranked_by_H0.csv
   Ranked composite-kernel results.

10. camb_shifted_ranked_by_H0.csv
    Ranked shifted-composite results.

11. camb_v6_refine_ranked_by_H0.csv
    Ranked local-refinement results.

12. camb_v7_strict_confirm_ranked_by_H0.csv
    Ranked strict-confirmation results.

Suggested Zenodo layout
-----------------------
Primary item:
- The_Recombination_Handoff_Companion_Note_DRAFT.md

Supplementary bundle:
- everything else in this zip

Current headline numbers
------------------------
- Best reasonable shifted-composite handoff: about +1.15 km/s/Mpc
- Best strict-confirmed shifted-composite handoff: about +0.70 km/s/Mpc
- Provisional combined SFT-side H0 budget:
  * strict-style total: about +1.0 to +1.2 km/s/Mpc
  * broader reasonable total: about +1.4 to +1.7 km/s/Mpc

Notes
-----
- This is a proxy-level sound-horizon analysis, not a full CMB-likelihood result.
- The shifted/broadened physical kernel is phenomenological and still needs first-principles derivation.
