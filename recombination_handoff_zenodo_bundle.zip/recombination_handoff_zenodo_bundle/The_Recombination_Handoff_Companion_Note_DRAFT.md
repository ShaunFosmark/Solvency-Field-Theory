# The Recombination Handoff: Compton Maintenance Activation and the Sound Horizon

**Author:** Shaun Fosmark  
**Status:** Standalone companion note for Zenodo publication  
**Relation to broader framework:** Companion to the V8 SFT framework; not a replacement

## Abstract

The late-time V6/V8 reservoir sector of Solvency Field Theory (SFT) provides a viable account of evolving dark energy, but by itself it produces only modest leverage on the CMB-inferred H0 tension. That limitation points directly to the sound horizon: if SFT contributes appreciably to H0, part of the effect must arise during recombination rather than only at late times. This note develops and tests that possibility.

The working hypothesis is that recombination is not merely a thermodynamic cooling event but also a bookkeeping transition. In the tightly coupled radiation-plasma era, independent Compton maintenance is suppressed by rapid scattering; as recombination proceeds and the free-electron fraction falls, independent phase maintenance activates and the maintenance burden progressively transfers from the radiation bath to the cosmological boundary. We call this transition the recombination handoff.

The note is intentionally written as a progression rather than a compressed results-only report, because that progression is the result. A toy logistic handoff first establishes the existence of sound-horizon leverage. Direct raw physical triggers then fail. CAMB-derived recombination kernels reveal that the signal lives in transfer-rate structure rather than in cumulative state variables. Composite physical kernels improve the result, and shifted/broadened composite kernels ultimately outperform the original toy benchmark. A local refinement confirms stability of the winning family, and a strict-band confirmation shows that the effect survives a conservative cutoff.

The final picture is clear. A physically motivated recombination-era handoff, built from ionization-rate and opacity-rate channels and then modestly shifted and broadened, produces stable positive H0 leverage. In the broader reasonable band it reaches about +1.15 km/s/Mpc. In the strict-confirmed band it survives at about +0.70 km/s/Mpc. This does not solve the full H0 tension by itself, but it identifies a real, structured, physically interpretable contribution that complements the late-time V6/V8 sector.

## 1. Motivation

The late-time V6/V8 line established a coherent SFT reservoir sector that can reproduce evolving dark-energy behavior, but its direct effect on recombination-era H0 inference is small. That shifts attention to the sound horizon. If SFT contributes materially to H0, part of the leverage must live during recombination.

## 2. Physical argument

In the tightly coupled radiation-plasma regime, matter is not dynamically independent in the same late-time sense; rapid scattering suppresses independent maintenance. As recombination proceeds and the free-electron fraction falls, Thomson coupling weakens and matter begins to behave as dynamically independent matter rather than as a permanently forced component of the radiation bath.

The proposed SFT interpretation is that this is also a maintenance-activation event: the bookkeeping burden progressively transfers from the radiation bath toward the cosmological boundary. That is the handoff.

## 3. Test progression

### 3.1 Toy logistic handoff
A phenomenological logistic handoff centered near recombination was used as a viability probe.

**Result:** it produced substantially larger H0 leverage than the late-time reservoir alone and established that a recombination-era handoff could, in principle, move the sound horizon enough to matter.

### 3.2 Raw physical triggers fail
Direct cumulative or state-like recombination variables were then used to replace the toy logistic.

**Result:** they underperformed badly. This showed that the leverage does not live mainly in cumulative state variables; it lives in a localized transfer-rate kernel.

### 3.3 CAMB-based physical kernels
CAMB thermal histories were then used to construct physicalized rate kernels, especially:
- visibility peak,
- minus dxe over dln a,
- minus d ln(opacity) over dln a,
- logistic benchmark as control.

**Result:** the physical kernels produced real, nonzero signal. The strongest single physical channel was the ionization-rate kernel, but the logistic benchmark still outperformed any single physical kernel.

### 3.4 Composite physical kernels
The ionization-rate and opacity-rate channels were then combined.

**Result:** the mixed physical kernel outperformed either component alone. This showed that the logistic benchmark was not just arbitrary fitting; it was approximating a real mixed physical transfer process.

### 3.5 Shifted and broadened composite kernels
The physical composite was then allowed modest redshift shift and width broadening/compression while retaining the same physical content.

**Result:** this was the first stage where the physicalized kernel matched and then exceeded the toy logistic benchmark in the reasonable band.

### 3.6 Local refinement
A tighter scan around the winning region was then run.

**Result:** the optimum remained stable. The winning family stayed mildly opacity-leaning, positively shifted, and broadened. The best reasonable models reached roughly +1.15 km/s/Mpc.

### 3.7 Strict-band confirmation
Finally, the amplitude was lowered so the winning family could be tested within the strict cutoff.

**Result:** the same shifted, broadened, mixed physical family survived the strict cut and still produced about +0.70 km/s/Mpc of H0 leverage.

## 4. Results

### Best kernel family
The winning family is a mixed plasma-transfer window built from:
- an ionization-rate channel,
- an opacity-rate channel,
- with the mix tilted somewhat toward the opacity side,
- shifted positively in redshift,
- and broadened relative to the raw CAMB-derived composite.

### Best reasonable result
The strongest reasonable model is:
- `combo_w_0.30__shift_+200__stretch_1.80`, `A_h = 0.10`
- H0-equivalent about 68.890
- shift about +1.15 km/s/Mpc

### Best strict-confirmed result
The strongest strict-confirmed model is:
- `combo_w_0.30__shift_+200__stretch_1.80`, `A_h = 0.06`
- H0-equivalent about 68.443
- shift about +0.70 km/s/Mpc
- remains inside the strict H-boost cutoff

## 5. Combined H0 budget

A fair provisional SFT-side budget is:
- late-time V6/V8 contribution: about +0.3 to +0.5 km/s/Mpc
- strict-confirmed handoff: about +0.7 km/s/Mpc
- reasonable-band handoff: about +1.15 km/s/Mpc

This implies roughly:
- strict-style total: about +1.0 to +1.2 km/s/Mpc
- broader reasonable total: about +1.4 to +1.7 km/s/Mpc

This is a partial contribution, not a complete H0 solution.

## 6. What this does and does not show

### What it shows
- the recombination handoff is not a toy-only artifact;
- the relevant handoff object is a transfer-rate kernel rather than a cumulative state variable;
- a mixed physical kernel outperforms single physical channels;
- modest timing and width freedom applied to that physical mix allows it to match and exceed the toy benchmark;
- the effect survives a strict cut at about +0.70 km/s/Mpc.

### What it does not show
- this is still a proxy-level sound-horizon analysis, not a full CMB likelihood analysis;
- the shift and broadening remain phenomenological and still need first-principles derivation;
- the total SFT contribution remains partial rather than complete with respect to the full H0 discrepancy.

## 7. Connection to the broader framework

This note is a companion to the broader V8 framework. In the larger SFT program, the same broad solvency-maintenance postulate now appears across multiple regimes:
1. strong field,
2. galactic weak field,
3. late-time cosmology,
4. recombination-era sound-horizon modification.

The present note isolates the recombination-era contribution.

## 8. Conclusion

The recombination handoff began as a suspicion born from a negative result: late-time V6/V8 dynamics were clearly real, but too late to move the sound horizon very much. The subsequent progression matters because it shows toy structure being systematically replaced by increasingly physical structure without destroying the signal.

**Bottom line:** a physically motivated recombination-era SFT handoff, built from ionization-rate and opacity-rate channels and allowed modest timing/width adjustments, produces stable positive H0 leverage. The effect survives the strict cut at roughly +0.7 km/s/Mpc and reaches about +1.15 km/s/Mpc in the broader reasonable band.

## Appendix A. Methodological notes for reproducibility

All sound-horizon runs use the same basic structure:
- analytic LCDM background for the high-redshift integral,
- CAMB thermal histories for recombination-era quantities,
- explicit construction of localized kernels on a redshift grid,
- a transient modification of the expansion history of the form:
  `E_mod(z)^2 = E_LCDM(z)^2 * [1 + A_h * h(z)]`

The successful physical channels were:
- ionization-rate kernel: minus dx_e over dln a,
- opacity-rate kernel: minus d ln(opacity) over dln a.

The successful composite family is:
- `h_combo(z) = w*h_xe(z) + (1-w)*h_op(z)`

followed by peak renormalization, then modest redshift shift and width stretch.

## Suggested artifact bundle

Include:
- this note,
- CAMB-based handoff scripts,
- summary CSV and TXT files from each stage,
- strict-confirm CSV output,
- key figure pack,
- a short README documenting run order.
