# SFT V11.9 Final Scripts Repro Pack

Scripts-only repro pack for V11.9A through V11.9I.

Generated CSVs, figures, reports, and verdicts are intentionally excluded. Run the scripts locally to regenerate outputs.

Requirements:

```bash
pip install numpy pandas matplotlib
```

Suggested full run from the scripts folder:

```bash
python sft_v11_9a_spin_closure_holonomy_toy.py
python sft_v11_9b_spinor_su2_handedness_toy.py
python sft_v11_9c_spin_projection_sterngerlach_toy.py
python sft_v11_9d_compton_spin_scale_toy.py
python sft_v11_9e_magnetic_moment_counting_audit.py
python sft_v11_9f_native_anomaly_budget_toy.py
python sft_v11_9g_pauli_dirac_coupling_interface_toy.py
python sft_v11_9h_winding_multipole_output_toy.py
python sft_v11_9i_vertex_dressing_compton_lag_overlap_toy.py
```

Claim guardrail: V11.9 establishes representation, scale-alignment, Pauli/Dirac leading g=2 interface, and anomaly-scale overlap structure. It does not derive spin-statistics, Pauli exclusion, or the measured anomalous magnetic moment.
