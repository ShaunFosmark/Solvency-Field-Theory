#!/usr/bin/env python3
"""
SFT V11.9E — Magnetic Moment Counting / Topological Current Audit

Tests whether "two charge laps per one spinor closure" actually closes the
leading g=2 magnetic-moment gate.

Core result expected:
- Same-loop ordinary current accounting gives g=1.
- Literal two laps per spinor closure is already included in current frequency, so still g=1.
- g=2 can be represented conditionally by either:
    (1) extra topological current factor N_top=2, or
    (2) effective charge-current radius larger than spin/inertia radius.
These are mechanisms to investigate, not derivations.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", default="sft_v11_9e_magnetic_moment_audit_output")
    p.add_argument("--dpi", type=int, default=170)
    p.add_argument("--N", type=int, default=401)
    return p.parse_args()


c = 299_792_458.0
h = 6.62607015e-34
hbar = h / (2*np.pi)
e_charge = 1.602176634e-19

particles = [
    ("electron", 9.1093837015e-31, -e_charge),
    ("muon", 1.883531627e-28, -e_charge),
    ("tau", 3.16754e-27, -e_charge),
]


def spin_scales(m, kappa=2.0):
    omega_C = m*c*c/hbar
    omega_int = kappa*omega_C
    T_C = 2*np.pi/omega_C
    T_spinor = 4*np.pi/omega_int
    r_spin = hbar/(kappa*m*c)
    S_spin = hbar/kappa
    return omega_C, omega_int, T_C, T_spinor, r_spin, S_spin


def mu_loop(q, omega_charge, r_charge, N_top=1.0):
    return N_top * q * omega_charge * r_charge**2 / 2.0


def g_eff(mu, q, m, S):
    return 2*m*mu/(q*S)


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    model_rows = []

    for particle, m, q in particles:
        omega_C, omega_int, T_C, T_spinor, r_spin, S_spin = spin_scales(m, 2.0)
        mu_dirac_g2 = 2.0 * q/(2*m) * S_spin
        laps_per_spinor_closure = omega_int*T_spinor/(2*np.pi)

        # A: naive same loop
        mu_A = mu_loop(q, omega_int, r_spin, 1.0)
        g_A = g_eff(mu_A, q, m, S_spin)

        # B: "two laps per closure" literal audit. Same as A because omega_int already counts laps.
        mu_B = mu_loop(q, omega_int, r_spin, 1.0)
        g_B = g_eff(mu_B, q, m, S_spin)

        # C: independent topological current factor
        mu_C = mu_loop(q, omega_int, r_spin, 2.0)
        g_C = g_eff(mu_C, q, m, S_spin)

        # D: same omega, larger charge-current area. Since mu ∝ r^2, sqrt(2) radius gives g=2.
        r_D = np.sqrt(2.0)*r_spin
        mu_D = mu_loop(q, omega_int, r_D, 1.0)
        g_D = g_eff(mu_D, q, m, S_spin)

        # E: charge current has its own c-speed radius. Since mu=q c r/2, radius factor 2 gives g=2.
        r_E = 2.0*r_spin
        omega_E = c/r_E
        mu_E = mu_loop(q, omega_E, r_E, 1.0)
        g_E = g_eff(mu_E, q, m, S_spin)

        models = [
            ("A_naive_same_loop", mu_A, g_A, r_spin, omega_int, 1.0, "same charge/spin loop; ordinary current gives g=1"),
            ("B_two_laps_literal_no_extra", mu_B, g_B, r_spin, omega_int, 1.0, "two laps are already counted by current frequency; still g=1"),
            ("C_extra_topological_current_factor_2", mu_C, g_C, r_spin, omega_int, 2.0, "conditional route: independent topological current factor gives g=2"),
            ("D_separate_radius_sqrt2_same_omega", mu_D, g_D, r_D, omega_int, 1.0, "conditional route: same omega, larger current area gives g=2"),
            ("E_separate_radius_2_own_cspeed", mu_E, g_E, r_E, omega_E, 1.0, "conditional route: own c-speed current on radius 2*r_spin gives g=2"),
        ]

        for name, mu, g, r_charge, omega_charge, N_top, note in models:
            model_rows.append({
                "particle": particle,
                "mass_kg": m,
                "charge_C": q,
                "model": name,
                "kappa_spin": 2.0,
                "r_spin_m": r_spin,
                "S_spin_J_s": S_spin,
                "T_C_s": T_C,
                "T_spinor_4pi_s": T_spinor,
                "charge_laps_per_spinor_closure": laps_per_spinor_closure,
                "r_charge_m": r_charge,
                "r_charge_over_r_spin": r_charge/r_spin,
                "omega_charge_rad_s": omega_charge,
                "omega_charge_over_omega_int": omega_charge/omega_int,
                "N_topological_current_factor": N_top,
                "mu_A_m2": mu,
                "mu_over_leading_Dirac_g2": mu/mu_dirac_g2,
                "g_effective": g,
                "g_error_from_2": abs(g-2.0),
                "interpretation": note,
            })

    model_df = pd.DataFrame(model_rows)
    models_path = outdir / "v11_9e_model_summary.csv"
    model_df.to_csv(models_path, index=False)

    # sweeps: electron only, dimensionless behavior
    particle, m, q = particles[0]
    _, omega_int, _, _, r_spin, S_spin = spin_scales(m, 2.0)

    factors = np.linspace(0.25, 3.0, args.N)
    rad_rows = []
    for f in factors:
        mu_same_omega = mu_loop(q, omega_int, f*r_spin, 1.0)
        g_same_omega = g_eff(mu_same_omega, q, m, S_spin)
        omega_own = c/(f*r_spin)
        mu_own = mu_loop(q, omega_own, f*r_spin, 1.0)
        g_own = g_eff(mu_own, q, m, S_spin)
        rad_rows.append({
            "r_charge_over_r_spin": f,
            "g_same_omega_area_scaling": g_same_omega,
            "g_own_cspeed_radius_scaling": g_own,
        })
    radius_df = pd.DataFrame(rad_rows)
    radius_path = outdir / "v11_9e_radius_factor_sweep.csv"
    radius_df.to_csv(radius_path, index=False)

    top_rows = []
    for Ntop in np.linspace(0, 3.0, args.N):
        mu = mu_loop(q, omega_int, r_spin, Ntop)
        top_rows.append({"N_topological_current_factor": Ntop, "g_effective": g_eff(mu, q, m, S_spin)})
    top_df = pd.DataFrame(top_rows)
    top_path = outdir / "v11_9e_topological_current_sweep.csv"
    top_df.to_csv(top_path, index=False)

    electron = model_df[model_df["particle"] == "electron"].copy()
    g = {r["model"]: float(r["g_effective"]) for _, r in electron.iterrows()}

    verdict = pd.DataFrame([
        {"gate": "naive_same_loop_guardrail", "status": "PASS_GUARDRAIL" if abs(g["A_naive_same_loop"]-1)<1e-12 else "CHECK",
         "meaning": "same charge/spin radius with ordinary current gives g=1, not g=2", "g_effective": g["A_naive_same_loop"]},
        {"gate": "two_laps_literal_audit", "status": "DOES_NOT_CLOSE_G2" if abs(g["B_two_laps_literal_no_extra"]-1)<1e-12 else "CHECK",
         "meaning": "two charge laps per spinor closure are already counted by current frequency; alone this remains g=1", "g_effective": g["B_two_laps_literal_no_extra"]},
        {"gate": "extra_topological_current_factor", "status": "CONDITIONAL_PASS" if abs(g["C_extra_topological_current_factor_2"]-2)<1e-12 else "CHECK",
         "meaning": "an independent topological current factor N_top=2 gives leading g=2", "g_effective": g["C_extra_topological_current_factor_2"]},
        {"gate": "separate_radius_same_omega", "status": "CONDITIONAL_PASS" if abs(g["D_separate_radius_sqrt2_same_omega"]-2)<1e-12 else "CHECK",
         "meaning": "if charge-current area is larger by factor 2 at same omega, g=2", "g_effective": g["D_separate_radius_sqrt2_same_omega"]},
        {"gate": "separate_radius_own_cspeed", "status": "CONDITIONAL_PASS" if abs(g["E_separate_radius_2_own_cspeed"]-2)<1e-12 else "CHECK",
         "meaning": "if charge current runs at c on radius twice spin radius, g=2", "g_effective": g["E_separate_radius_2_own_cspeed"]},
        {"gate": "claim_level", "status": "LEADING_G2_NOT_YET_DERIVED",
         "meaning": "V11.9E identifies mechanisms that represent g=2, but SFT must justify one dynamically before closing the gate", "g_effective": np.nan},
    ])
    verdict_path = outdir / "v11_9e_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # plots
    plt.figure(figsize=(10.5, 6.2))
    plt.bar(electron["model"], electron["g_effective"])
    plt.axhline(1.0, linestyle="--", label="g=1 naive")
    plt.axhline(2.0, linestyle=":", label="g=2 Dirac leading target")
    plt.xticks(rotation=35, ha="right")
    plt.ylabel("effective g")
    plt.title("V11.9E magnetic moment accounting by model")
    plt.legend()
    plt.tight_layout()
    p_models = outdir / "v11_9e_g_by_model.png"
    plt.savefig(p_models, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(9, 5.8))
    plt.plot(radius_df["r_charge_over_r_spin"], radius_df["g_same_omega_area_scaling"], label="same omega: g=f^2")
    plt.plot(radius_df["r_charge_over_r_spin"], radius_df["g_own_cspeed_radius_scaling"], label="own c-speed: g=f")
    plt.axhline(2.0, linestyle=":", label="g=2")
    plt.axvline(np.sqrt(2), linestyle="--", label="sqrt(2)")
    plt.axvline(2.0, linestyle="--", label="2")
    plt.xlabel("r_charge / r_spin")
    plt.ylabel("effective g")
    plt.title("V11.9E radius separation required for g=2")
    plt.legend()
    plt.tight_layout()
    p_rad = outdir / "v11_9e_g_vs_radius_factor.png"
    plt.savefig(p_rad, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(9, 5.8))
    plt.plot(top_df["N_topological_current_factor"], top_df["g_effective"], label="g=N_top")
    plt.axhline(2.0, linestyle=":", label="g=2")
    plt.axvline(2.0, linestyle="--", label="N_top=2")
    plt.xlabel("extra topological current factor N_top")
    plt.ylabel("effective g")
    plt.title("V11.9E topological current factor required for g=2")
    plt.legend()
    plt.tight_layout()
    p_top = outdir / "v11_9e_g_vs_topological_current_factor.png"
    plt.savefig(p_top, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(10.5, 6.2))
    plt.bar(electron["model"], electron["mu_over_leading_Dirac_g2"])
    plt.axhline(1.0, linestyle=":", label="leading Dirac magnetic moment")
    plt.xticks(rotation=35, ha="right")
    plt.ylabel("mu / mu_Dirac(g=2)")
    plt.title("V11.9E magnetic moment ratio by model")
    plt.legend()
    plt.tight_layout()
    p_mu = outdir / "v11_9e_mu_ratio_by_model.png"
    plt.savefig(p_mu, dpi=args.dpi)
    plt.close()

    report = "# V11.9E Magnetic Moment Counting / Topological Current Audit\n\n"
    report += "This tests whether the V11.9D spinor motion picture can close the leading g=2 magnetic-moment gate.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Key result\n\nThe literal statement 'two charge laps per spinor closure' does not by itself produce g=2 if the ordinary current formula already counts lap frequency and charge and spin share the same loop radius. It remains g=1.\n\n"
    report += "## Conditional routes to g=2\n\nThe leading g=2 value can be represented if SFT supplies either an independent topological current factor N_top=2, or an effective charge-current radius larger than the spin/inertia radius. These are mechanisms to investigate, not yet derivations.\n\n"
    report += "## Guardrail\n\nThe anomalous magnetic moment beyond g=2 remains open/QED-level.\n"
    report_path = outdir / "v11_9e_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9E complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nElectron model summary:")
    print(electron[["model", "r_charge_over_r_spin", "omega_charge_over_omega_int",
                    "N_topological_current_factor", "mu_over_leading_Dirac_g2",
                    "g_effective", "interpretation"]].to_string(index=False))
    print("\nSaved files:")
    for p in [models_path, radius_path, top_path, verdict_path, report_path, p_models, p_rad, p_top, p_mu]:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
