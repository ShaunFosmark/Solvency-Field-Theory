#!/usr/bin/env python3
"""
SFT V11.9G — Pauli/Dirac Coupling Interface Toy

Purpose
-------
V11.9E showed that naive ring-current counting does NOT derive leading g=2.
The literal "two charge laps per spinor closure" statement stays g=1 if the
ordinary current formula already counts lap frequency.

V11.9G tests the more likely correct mechanism:

    g = 2 comes from spinor covariant electromagnetic coupling.

The target identity is:

    (sigma · pi)^2 = pi^2 - q hbar sigma · B

where:

    pi = p - q A

and:

    [pi_i, pi_j] = i q hbar epsilon_ijk B_k

Then:

    H = (sigma · pi)^2 / (2m)
      = pi^2/(2m) - (q hbar / 2m) sigma · B

Since S = (hbar/2) sigma, compare with:

    H_Z = - g (q/2m) S · B
        = - g (q hbar / 4m) sigma · B

So:

    g = 2

Interpretation
--------------
SFT spinor holonomy supplies the SU(2) spinor object. The EM covariant
derivative supplies the curvature coupling. The leading g=2 factor is not a
naive ring-current count; it is the Pauli/Dirac spinor coupling term.

Guardrail
---------
This does not derive the anomalous magnetic moment beyond g=2. It does not
replace QED loops.

Outputs
-------
CSV:
    v11_9g_pauli_identity_summary.csv
    v11_9g_operator_residuals.csv
    v11_9g_g_fit_scan.csv
    v11_9g_model_comparison.csv
    v11_9g_verdict.csv

Plots:
    v11_9g_identity_residual_vs_truncation.png
    v11_9g_g_fit_scan.png
    v11_9g_model_g_comparison.png
    v11_9g_landau_level_sketch.png

Run:
    python sft_v11_9g_pauli_dirac_coupling_interface_toy.py
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", default="sft_v11_9g_pauli_dirac_interface_output")
    p.add_argument("--dpi", type=int, default=170)
    p.add_argument("--N", type=int, default=32, help="oscillator truncation dimension")
    return p.parse_args()


# Dimensionless units for operator test
hbar = 1.0
q = 1.0
B = 1.0
m = 1.0

# Pauli matrices
I2 = np.eye(2, dtype=complex)
sx = np.array([[0, 1], [1, 0]], dtype=complex)
sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
sz = np.array([[1, 0], [0, -1]], dtype=complex)


def ladder_ops(N):
    a = np.zeros((N, N), dtype=complex)
    for n in range(1, N):
        a[n-1, n] = np.sqrt(n)
    adag = a.conj().T
    return a, adag


def pi_ops(N, qB=1.0):
    """
    Oscillator representation with approximate [pi_x, pi_y] = i q hbar B.
    Truncation spoils the top state only.
    """
    a, adag = ladder_ops(N)
    scale = np.sqrt(qB*hbar/2.0)
    pix = scale * (a + adag)
    piy = 1j * scale * (adag - a)
    return pix, piy


def kron_spin(spin_mat, op_mat):
    return np.kron(spin_mat, op_mat)


def bulk_projector(N, drop=2):
    """
    Project out top oscillator states where finite truncation breaks the
    canonical commutator.
    """
    Posc = np.zeros((N, N), dtype=complex)
    keep = max(N-drop, 1)
    Posc[:keep, :keep] = np.eye(keep)
    return np.kron(I2, Posc)


def fro_norm(A):
    return float(np.linalg.norm(A, ord="fro"))


def pauli_identity_operators(N):
    pix, piy = pi_ops(N, q*B)
    Iosc = np.eye(N, dtype=complex)

    sigma_dot_pi = kron_spin(sx, pix) + kron_spin(sy, piy)
    left = sigma_dot_pi @ sigma_dot_pi

    pi2 = pix @ pix + piy @ piy
    right = kron_spin(I2, pi2) - q*hbar*B*kron_spin(sz, Iosc)

    P = bulk_projector(N, drop=2)
    residual = left - right
    residual_bulk = P @ residual @ P
    right_bulk = P @ right @ P

    # commutator check
    comm = pix @ piy - piy @ pix
    comm_target = 1j*q*hbar*B*Iosc
    Posc = np.zeros((N, N), dtype=complex)
    Posc[:max(N-2, 1), :max(N-2, 1)] = np.eye(max(N-2, 1))
    comm_bulk = Posc @ (comm - comm_target) @ Posc

    return {
        "N": N,
        "left": left,
        "right": right,
        "residual": residual,
        "P": P,
        "relative_residual_full": fro_norm(residual)/(fro_norm(right)+1e-30),
        "relative_residual_bulk": fro_norm(residual_bulk)/(fro_norm(right_bulk)+1e-30),
        "commutator_relative_residual_bulk": fro_norm(comm_bulk)/(fro_norm(Posc@comm_target@Posc)+1e-30),
        "pix": pix,
        "piy": piy,
    }


def fit_g_for_N(N, g_values):
    ops = pauli_identity_operators(N)
    pix = ops["pix"]
    piy = ops["piy"]
    Iosc = np.eye(N, dtype=complex)
    pi2 = pix@pix + piy@piy

    # Pauli/Dirac Hamiltonian from sigma-dot-pi square
    H_pauli = ops["left"]/(2*m)

    # Fit against H(g)=pi^2/(2m)-g*q*hbar/(4m) sigma_z B
    P = ops["P"]
    rows = []
    for g in g_values:
        H_g = kron_spin(I2, pi2)/(2*m) - g*q*hbar*B*kron_spin(sz, Iosc)/(4*m)
        D = P@(H_pauli - H_g)@P
        denom = fro_norm(P@H_pauli@P)+1e-30
        rows.append({"g": g, "relative_error": fro_norm(D)/denom})
    df = pd.DataFrame(rows)
    best = df.loc[df["relative_error"].idxmin()]
    return df, float(best["g"]), float(best["relative_error"])


def landau_levels(N):
    """
    Simple eigenvalue sketch for Pauli Hamiltonian and scalar Hamiltonian.
    In dimensionless units. Truncation gives oscillator-like spectrum.
    """
    ops = pauli_identity_operators(N)
    pix = ops["pix"]
    piy = ops["piy"]
    Iosc = np.eye(N, dtype=complex)
    pi2 = pix@pix + piy@piy

    H_scalar = pi2/(2*m)
    H_pauli = ops["left"]/(2*m)

    eval_scalar = np.linalg.eigvalsh(H_scalar).real
    eval_pauli = np.linalg.eigvalsh(H_pauli).real
    return np.sort(eval_scalar), np.sort(eval_pauli)


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    # Analytic summary
    pauli_coeff = -q*hbar*B/(2*m)
    zeeman_coeff_general_g1 = -q*hbar*B/(4*m)
    inferred_g = pauli_coeff / zeeman_coeff_general_g1

    identity_summary = pd.DataFrame([
        {
            "identity": "(sigma dot pi)^2 = pi^2 - q hbar sigma dot B",
            "pauli_magnetic_coefficient": pauli_coeff,
            "general_zeeman_coefficient_for_g1": zeeman_coeff_general_g1,
            "inferred_g": inferred_g,
            "status": "PASS" if abs(inferred_g-2.0) < 1e-12 else "CHECK",
            "interpretation": "spinor covariant coupling supplies leading g=2",
        }
    ])
    identity_path = outdir / "v11_9g_pauli_identity_summary.csv"
    identity_summary.to_csv(identity_path, index=False)

    # Operator residuals for truncation sizes
    Ns = [8, 12, 16, 24, args.N]
    Ns = sorted(set([n for n in Ns if n >= 4]))
    residual_rows = []
    for N in Ns:
        ops = pauli_identity_operators(N)
        residual_rows.append({
            "N": N,
            "relative_residual_full": ops["relative_residual_full"],
            "relative_residual_bulk": ops["relative_residual_bulk"],
            "commutator_relative_residual_bulk": ops["commutator_relative_residual_bulk"],
            "note": "bulk residual excludes top truncation states",
        })
    residuals = pd.DataFrame(residual_rows)
    residuals_path = outdir / "v11_9g_operator_residuals.csv"
    residuals.to_csv(residuals_path, index=False)

    # g-fit scan
    g_values = np.linspace(0, 4, 801)
    fit_df, best_g, best_err = fit_g_for_N(args.N, g_values)
    fit_df.to_csv(outdir / "v11_9g_g_fit_scan.csv", index=False)

    # Model comparison
    model_comparison = pd.DataFrame([
        {
            "model": "classical_same_loop_ring",
            "g_effective": 1.0,
            "mechanism": "ordinary current and same charge/spin radius",
            "claim_status": "guardrail",
        },
        {
            "model": "inserted_topological_current_factor",
            "g_effective": 2.0,
            "mechanism": "N_top=2 inserted by hand",
            "claim_status": "conditional_not_derived",
        },
        {
            "model": "Pauli_Dirac_spinor_covariant_coupling",
            "g_effective": 2.0,
            "mechanism": "(sigma dot pi)^2 produces magnetic spin term",
            "claim_status": "interface_pass",
        },
        {
            "model": "QED_anomalous_correction",
            "g_effective": np.nan,
            "mechanism": "loop corrections beyond leading g=2",
            "claim_status": "open_not_tested_here",
        },
    ])
    model_path = outdir / "v11_9g_model_comparison.csv"
    model_comparison.to_csv(model_path, index=False)

    # Landau-level sketch
    eval_scalar, eval_pauli = landau_levels(args.N)
    nshow = min(24, len(eval_pauli))
    levels = pd.DataFrame({
        "index": np.arange(nshow),
        "scalar_level": eval_scalar[:nshow],
        "pauli_spinor_level": eval_pauli[:nshow],
    })
    levels_path = outdir / "v11_9g_landau_level_sketch.csv"
    levels.to_csv(levels_path, index=False)

    # Verdict
    max_bulk_residual = float(residuals["relative_residual_bulk"].max())
    max_comm_bulk = float(residuals["commutator_relative_residual_bulk"].max())
    verdict = pd.DataFrame([
        {
            "gate": "analytic_pauli_identity_infers_g2",
            "status": "PASS" if abs(inferred_g-2.0) < 1e-12 else "CHECK",
            "meaning": "Pauli magnetic term has coefficient corresponding to g=2",
            "value": inferred_g,
        },
        {
            "gate": "operator_identity_bulk_residual",
            "status": "PASS" if max_bulk_residual < 1e-12 else "CHECK",
            "meaning": "finite operator test confirms identity away from truncation boundary",
            "value": max_bulk_residual,
        },
        {
            "gate": "covariant_momentum_commutator",
            "status": "PASS" if max_comm_bulk < 1e-12 else "CHECK",
            "meaning": "[pi_x,pi_y]=i q hbar B in bulk gives magnetic curvature",
            "value": max_comm_bulk,
        },
        {
            "gate": "g_fit_from_spinor_hamiltonian",
            "status": "PASS" if abs(best_g-2.0) < 0.006 and best_err < 1e-12 else "CHECK",
            "meaning": "best-fit Zeeman coefficient from spinor Hamiltonian is g=2",
            "value": best_g,
        },
        {
            "gate": "claim_level",
            "status": "LEADING_G2_INTERFACE_CLOSED",
            "meaning": "leading g=2 is closed at Pauli/Dirac interface level; anomalous g-2 remains open/QED-level",
            "value": np.nan,
        },
    ])
    verdict_path = outdir / "v11_9g_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # Plots
    plt.figure(figsize=(8.8, 5.8))
    plt.plot(residuals["N"], residuals["relative_residual_full"], marker="o", label="full truncated space")
    plt.plot(residuals["N"], residuals["relative_residual_bulk"], marker="o", label="bulk projected")
    plt.plot(residuals["N"], residuals["commutator_relative_residual_bulk"], marker="o", label="commutator bulk")
    plt.yscale("log")
    plt.xlabel("oscillator truncation N")
    plt.ylabel("relative residual")
    plt.title("V11.9G Pauli identity residuals")
    plt.legend()
    plt.tight_layout()
    p_res = outdir / "v11_9g_identity_residual_vs_truncation.png"
    plt.savefig(p_res, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.8, 5.8))
    plt.plot(fit_df["g"], fit_df["relative_error"])
    plt.axvline(2.0, linestyle=":", label="g=2")
    plt.yscale("log")
    plt.xlabel("candidate g")
    plt.ylabel("relative Hamiltonian error")
    plt.title("V11.9G best-fit g from Pauli spinor Hamiltonian")
    plt.legend()
    plt.tight_layout()
    p_fit = outdir / "v11_9g_g_fit_scan.png"
    plt.savefig(p_fit, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.8, 5.8))
    comp_plot = model_comparison.dropna(subset=["g_effective"])
    plt.bar(comp_plot["model"], comp_plot["g_effective"])
    plt.axhline(1.0, linestyle="--", label="g=1")
    plt.axhline(2.0, linestyle=":", label="g=2")
    plt.xticks(rotation=30, ha="right")
    plt.ylabel("effective g")
    plt.title("V11.9G model comparison")
    plt.legend()
    plt.tight_layout()
    p_model = outdir / "v11_9g_model_g_comparison.png"
    plt.savefig(p_model, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.8, 5.8))
    plt.plot(levels["index"], levels["scalar_level"], marker="o", label="scalar pi^2/(2m)")
    plt.plot(levels["index"], levels["pauli_spinor_level"], marker="o", label="Pauli (sigma dot pi)^2/(2m)")
    plt.xlabel("sorted level index")
    plt.ylabel("dimensionless energy")
    plt.title("V11.9G spinor coupling shifts magnetic levels")
    plt.legend()
    plt.tight_layout()
    p_levels = outdir / "v11_9g_landau_level_sketch.png"
    plt.savefig(p_levels, dpi=args.dpi)
    plt.close()

    report = "# V11.9G Pauli/Dirac Coupling Interface Toy\n\n"
    report += "This tests the leading g=2 mechanism at the spinor covariant-coupling interface.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Key result\n\nThe Pauli identity (sigma dot pi)^2 = pi^2 - q hbar sigma dot B gives the magnetic spin term with coefficient corresponding to g=2. This closes leading g=2 at the Pauli/Dirac interface level, not by naive ring-current counting.\n\n"
    report += "## Guardrail\n\nThe anomalous magnetic moment beyond g=2 remains open/QED-level.\n"
    report_path = outdir / "v11_9g_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9G complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nIdentity summary:")
    print(identity_summary.to_string(index=False))
    print("\nOperator residuals:")
    print(residuals.to_string(index=False))
    print("\nBest-fit g:", best_g, "error:", best_err)
    print("\nSaved files:")
    for p in [identity_path, residuals_path, outdir / "v11_9g_g_fit_scan.csv",
              model_path, levels_path, verdict_path, report_path,
              p_res, p_fit, p_model, p_levels]:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
