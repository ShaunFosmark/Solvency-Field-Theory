#!/usr/bin/env python3
"""
SFT V11.9F — Native Anomaly Budget / Lag-Motion Correction Toy

Purpose
-------
After V11.9E, the leading g=2 gate is NOT closed by literal two-lap counting.
V11.9E found conditional routes to represent g=2, but SFT still needs a
dynamical reason for one of them.

V11.9F asks the next question:

    If the leading Dirac value g=2 is supplied by the spinor/Dirac interface,
    could SFT motion naturally create a small anomalous correction
    a = (g-2)/2 beyond the leading value?

This is a scale/budget audit, not a derivation and not a QED replacement.

Known comparator:
    The leading QED correction is the Schwinger scale:

        a_leading = alpha/(2*pi)

This toy asks whether natural SFT lag-motion scalings can land near that scale:

        a_SFT = C_lag * alpha/(2*pi)

and infers the C_lag required to match approximate reference anomalies.

Guardrail
---------
The electron anomalous magnetic moment is a precision QED observable. This toy
does NOT claim to compute it. It only checks whether SFT has a natural
dimensionless scale in the correct neighborhood.

Outputs
-------
CSV:
    v11_9f_candidate_anomaly_models.csv
    v11_9f_reference_comparison.csv
    v11_9f_coefficient_inference.csv
    v11_9f_alpha_scaling_sweep.csv
    v11_9f_verdict.csv

Plots:
    v11_9f_anomaly_model_comparison.png
    v11_9f_required_coefficient.png
    v11_9f_alpha_scaling.png
    v11_9f_relative_errors.png

Run:
    python sft_v11_9f_native_anomaly_budget_toy.py
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", default="sft_v11_9f_native_anomaly_budget_output")
    p.add_argument("--dpi", type=int, default=170)
    p.add_argument("--N", type=int, default=600)
    return p.parse_args()


# Approximate low-energy fine-structure constant.
# Use as structure-scale input, not precision metrology.
alpha = 1 / 137.035999084
pi = np.pi

# Approximate reference anomalies a=(g-2)/2.
# These are included only as scale/comparison references.
# Replace with preferred/current values for precision work.
references = [
    {
        "particle": "electron",
        "a_reference": 0.00115965218128,
        "note": "approx electron anomaly reference; precision value should be updated externally for metrology",
    },
    {
        "particle": "muon",
        "a_reference": 0.00116592061,
        "note": "approx muon anomaly reference; includes non-electron mass-dependent effects",
    },
]


def candidate_models(alpha_value: float):
    """
    Return anomaly candidates a=(g-2)/2.
    Models are dimensional-scale probes, not derivations.
    """
    return [
        {
            "model": "Dirac_leading_only",
            "a_pred": 0.0,
            "description": "no anomalous correction; g=2 exactly",
            "claim_status": "baseline",
        },
        {
            "model": "SFT_one_loop_lag_phase_alpha_over_2pi",
            "a_pred": alpha_value/(2*pi),
            "description": "one EM/lag circulation coupling alpha averaged over one 2pi phase loop",
            "claim_status": "natural_scale_candidate",
        },
        {
            "model": "raw_alpha_too_large",
            "a_pred": alpha_value,
            "description": "raw EM coupling with no loop averaging",
            "claim_status": "scale_fail_expected",
        },
        {
            "model": "alpha_over_pi",
            "a_pred": alpha_value/pi,
            "description": "loop factor 1/pi; twice Schwinger scale",
            "claim_status": "comparison",
        },
        {
            "model": "alpha_over_4pi",
            "a_pred": alpha_value/(4*pi),
            "description": "half Schwinger scale",
            "claim_status": "comparison",
        },
        {
            "model": "alpha_squared_over_2pi",
            "a_pred": alpha_value**2/(2*pi),
            "description": "second-order-only scale; too small for leading anomaly",
            "claim_status": "scale_fail_expected",
        },
    ]


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    # Candidate models
    models = pd.DataFrame(candidate_models(alpha))
    models["g_pred"] = 2 + 2*models["a_pred"]
    models_path = outdir / "v11_9f_candidate_anomaly_models.csv"
    models.to_csv(models_path, index=False)

    # Compare to reference anomalies
    comp_rows = []
    for ref in references:
        for _, m in models.iterrows():
            a_ref = ref["a_reference"]
            a_pred = float(m["a_pred"])
            abs_err = abs(a_pred - a_ref)
            rel_err = abs_err / abs(a_ref) if a_ref != 0 else np.nan
            comp_rows.append({
                "particle": ref["particle"],
                "a_reference": a_ref,
                "g_reference": 2 + 2*a_ref,
                "model": m["model"],
                "a_pred": a_pred,
                "g_pred": 2 + 2*a_pred,
                "abs_error_a": abs_err,
                "rel_error_a": rel_err,
                "reference_note": ref["note"],
                "model_status": m["claim_status"],
            })
    comp = pd.DataFrame(comp_rows)
    comp_path = outdir / "v11_9f_reference_comparison.csv"
    comp.to_csv(comp_path, index=False)

    # Coefficient inference for a = C * alpha/(2pi)
    base = alpha/(2*pi)
    infer_rows = []
    for ref in references:
        C = ref["a_reference"] / base
        infer_rows.append({
            "particle": ref["particle"],
            "a_reference": ref["a_reference"],
            "base_alpha_over_2pi": base,
            "C_required_in_a_equals_C_alpha_over_2pi": C,
            "distance_from_C1": abs(C-1.0),
            "relative_distance_from_C1": abs(C-1.0),
            "interpretation": "C near 1 means alpha/(2pi) is the right leading scale; not a derivation",
        })
    infer = pd.DataFrame(infer_rows)
    infer_path = outdir / "v11_9f_coefficient_inference.csv"
    infer.to_csv(infer_path, index=False)

    # Alpha scaling sweep
    alpha_vals = np.logspace(np.log10(alpha/100), np.log10(alpha*100), args.N)
    sweep_rows = []
    for av in alpha_vals:
        sweep_rows.append({
            "alpha": av,
            "alpha_over_2pi": av/(2*pi),
            "alpha_over_pi": av/pi,
            "alpha_over_4pi": av/(4*pi),
            "alpha_squared_over_2pi": av**2/(2*pi),
        })
    sweep = pd.DataFrame(sweep_rows)
    sweep_path = outdir / "v11_9f_alpha_scaling_sweep.csv"
    sweep.to_csv(sweep_path, index=False)

    # Verdict
    e_comp = comp[comp["particle"] == "electron"].copy()
    sch = e_comp[e_comp["model"] == "SFT_one_loop_lag_phase_alpha_over_2pi"].iloc[0]
    raw = e_comp[e_comp["model"] == "raw_alpha_too_large"].iloc[0]
    second = e_comp[e_comp["model"] == "alpha_squared_over_2pi"].iloc[0]
    e_C = infer[infer["particle"] == "electron"].iloc[0]

    verdict = pd.DataFrame([
        {
            "gate": "natural_alpha_over_2pi_scale",
            "status": "PASS_SCALE_NEIGHBORHOOD" if sch["rel_error_a"] < 0.01 else "CHECK",
            "meaning": "alpha/(2pi) lands within 1 percent of the electron anomalous moment scale",
            "value": float(sch["a_pred"]),
            "reference": float(sch["a_reference"]),
            "relative_error": float(sch["rel_error_a"]),
        },
        {
            "gate": "coefficient_near_unity",
            "status": "PASS_SCALE_NEIGHBORHOOD" if abs(float(e_C["C_required_in_a_equals_C_alpha_over_2pi"])-1) < 0.01 else "CHECK",
            "meaning": "electron reference requires C_lag close to 1 in a=C alpha/(2pi)",
            "value": float(e_C["C_required_in_a_equals_C_alpha_over_2pi"]),
            "reference": 1.0,
            "relative_error": float(abs(e_C["C_required_in_a_equals_C_alpha_over_2pi"]-1)),
        },
        {
            "gate": "raw_alpha_rejected",
            "status": "PASS_GUARDRAIL" if raw["rel_error_a"] > 1.0 else "CHECK",
            "meaning": "raw alpha without loop averaging is far too large",
            "value": float(raw["a_pred"]),
            "reference": float(raw["a_reference"]),
            "relative_error": float(raw["rel_error_a"]),
        },
        {
            "gate": "alpha_squared_only_rejected",
            "status": "PASS_GUARDRAIL" if second["rel_error_a"] > 0.9 else "CHECK",
            "meaning": "alpha^2-only scale is far too small for the leading anomaly",
            "value": float(second["a_pred"]),
            "reference": float(second["a_reference"]),
            "relative_error": float(second["rel_error_a"]),
        },
        {
            "gate": "claim_level",
            "status": "ANOMALY_NOT_DERIVED",
            "meaning": "V11.9F identifies a natural SFT-shaped alpha/(2pi) anomaly scale, but does not replace QED or derive the measured anomaly",
            "value": np.nan,
            "reference": np.nan,
            "relative_error": np.nan,
        },
    ])
    verdict_path = outdir / "v11_9f_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # Plots
    e_plot = e_comp.copy()
    plt.figure(figsize=(10.2, 6.2))
    plt.bar(e_plot["model"], e_plot["a_pred"])
    plt.axhline(float(e_plot["a_reference"].iloc[0]), linestyle=":", label="electron reference anomaly")
    plt.yscale("log")
    plt.ylabel("a = (g-2)/2")
    plt.title("V11.9F candidate anomaly scales")
    plt.xticks(rotation=35, ha="right")
    plt.legend()
    plt.tight_layout()
    p_models = outdir / "v11_9f_anomaly_model_comparison.png"
    plt.savefig(p_models, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.5, 5.8))
    plt.bar(infer["particle"], infer["C_required_in_a_equals_C_alpha_over_2pi"])
    plt.axhline(1.0, linestyle=":", label="C=1")
    plt.ylabel("C required in a = C alpha/(2pi)")
    plt.title("V11.9F inferred anomaly coefficient")
    plt.legend()
    plt.tight_layout()
    p_coeff = outdir / "v11_9f_required_coefficient.png"
    plt.savefig(p_coeff, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(9, 5.8))
    plt.plot(sweep["alpha"], sweep["alpha_over_2pi"], label="alpha/(2pi)")
    plt.plot(sweep["alpha"], sweep["alpha_over_pi"], label="alpha/pi")
    plt.plot(sweep["alpha"], sweep["alpha_over_4pi"], label="alpha/(4pi)")
    plt.plot(sweep["alpha"], sweep["alpha_squared_over_2pi"], label="alpha^2/(2pi)")
    plt.axvline(alpha, linestyle="--", label="physical alpha approx")
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("alpha")
    plt.ylabel("candidate anomaly scale")
    plt.title("V11.9F alpha-scaling audit")
    plt.legend()
    plt.tight_layout()
    p_alpha = outdir / "v11_9f_alpha_scaling.png"
    plt.savefig(p_alpha, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(10.2, 6.2))
    plt.bar(e_plot["model"], e_plot["rel_error_a"])
    plt.yscale("log")
    plt.ylabel("relative error vs electron reference")
    plt.title("V11.9F relative errors of candidate anomaly scales")
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    p_err = outdir / "v11_9f_relative_errors.png"
    plt.savefig(p_err, dpi=args.dpi)
    plt.close()

    report = "# V11.9F Native Anomaly Budget / Lag-Motion Correction Toy\n\n"
    report += "This is a scale/budget audit, not a derivation and not a QED replacement.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Key result\n\nThe natural one-loop-sized scale alpha/(2pi) lands in the electron anomaly neighborhood and requires a coefficient near unity. This suggests a plausible SFT-shaped anomaly scale but does not derive the anomaly.\n\n"
    report += "## Guardrail\n\nThe measured anomalous magnetic moment remains a precision QED observable. Any SFT-native correction must either reproduce known QED structure or be below experimental residuals.\n"
    report_path = outdir / "v11_9f_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9F complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nCoefficient inference:")
    print(infer.to_string(index=False))
    print("\nElectron comparison:")
    print(e_comp[["model","a_pred","g_pred","a_reference","rel_error_a","model_status"]].to_string(index=False))
    print("\nSaved files:")
    for p in [models_path, comp_path, infer_path, sweep_path, verdict_path, report_path, p_models, p_coeff, p_alpha, p_err]:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
