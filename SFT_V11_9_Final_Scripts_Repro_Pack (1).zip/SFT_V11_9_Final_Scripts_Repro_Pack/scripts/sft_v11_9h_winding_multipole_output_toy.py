#!/usr/bin/env python3
"""
SFT V11.9H — Winding Pattern / Multipole Output Toy

Purpose
-------
Translate Shaun's generator intuition into a safe SFT diagnostic.

Engineering intuition:
    In a generator, motion + winding geometry + coupling geometry determine
    the output field.

SFT spin translation:
    Internal Compton/lag-field circulation + closure topology + coupling
    geometry should determine the external field fingerprint.

This toy asks:
    Do different internal winding / closure / amplitude patterns produce
    distinct time-averaged magnetic-output fingerprints?

Guardrail:
    This is NOT a claim that particles are literal generators.
    It is a structural toy: current geometry and phase-current topology
    determine output multipoles.

Core objects
------------
Let U(theta) be an internal phase pattern around a circulation loop.

A bilinear phase-current proxy is:

    J_phase(theta) = Im[ U*(theta) dU/dtheta ]

This is useful because:
    U(theta+2pi) = -U(theta) for a spinor,
but:
    J_phase(theta+2pi) = J_phase(theta)

So standalone field output is insensitive to the global spinor sign but
sensitive to phase slope / handedness.

For ring-like current patterns J(theta), the magnetic dipole proxy is the DC
component:

    mu_z proxy ∝ <J(theta)>

Nonzero Fourier modes are AC/multipole/winding fingerprints.

Outputs
-------
CSV:
    v11_9h_pattern_summary.csv
    v11_9h_fourier_spectra.csv
    v11_9h_spinor_bilinear_periodicity.csv
    v11_9h_rectification_summary.csv
    v11_9h_verdict.csv

Plots:
    v11_9h_current_patterns.png
    v11_9h_fourier_spectra_heatmap.png
    v11_9h_dc_ac_rectified_outputs.png
    v11_9h_spinor_sign_vs_bilinear_current.png

Run:
    python sft_v11_9h_winding_multipole_output_toy.py
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", default="sft_v11_9h_winding_multipole_output")
    p.add_argument("--dpi", type=int, default=170)
    p.add_argument("--N", type=int, default=4096)
    p.add_argument("--mmax", type=int, default=8)
    return p.parse_args()


def phase_pattern(theta, winding=0.5, amp=None):
    if amp is None:
        amp = np.ones_like(theta)
    return amp * np.exp(1j*winding*theta)


def phase_current(theta, U):
    dU = np.gradient(U, theta, edge_order=2)
    return np.imag(np.conj(U) * dU)


def fourier_spectrum(theta, J, mmax=8):
    rows = []
    c0 = float(np.mean(J))
    rows.append({"m": 0, "a_m": c0, "b_m": 0.0, "amplitude": abs(c0), "power": c0*c0})
    for m in range(1, mmax+1):
        a = float(2*np.mean(J*np.cos(m*theta)))
        b = float(2*np.mean(J*np.sin(m*theta)))
        amp = float(np.sqrt(a*a + b*b))
        rows.append({"m": m, "a_m": a, "b_m": b, "amplitude": amp, "power": amp*amp})
    return pd.DataFrame(rows)


def pattern_library(theta):
    """
    Return ring current patterns J(theta) and the underlying U when useful.
    J is a current/output proxy; it need not be a physical steady current
    unless marked as bilinear_phase_current.
    """
    eps = 0.60

    patterns = []

    # Spinor bilinear currents from U=e^{i w theta}
    for name, w in [
        ("spinor_plus_half_bilinear", 0.5),
        ("spinor_minus_half_bilinear", -0.5),
        ("simple_integer_plus1_bilinear", 1.0),
        ("spin_3half_seed_bilinear", 1.5),
    ]:
        U = phase_pattern(theta, winding=w)
        J = phase_current(theta, U)
        patterns.append({
            "case": name,
            "U": U,
            "J": J,
            "kind": "bilinear_phase_current",
            "interpretation": f"phase-current from U=exp(i {w} theta)",
        })

    # Generator-like winding/current profiles
    J = np.ones_like(theta)
    patterns.append({
        "case": "uniform_dc_loop",
        "U": None,
        "J": J,
        "kind": "current_profile",
        "interpretation": "pure DC ring current; only dipole component",
    })

    J = 1.0 + eps*np.cos(2*theta)
    patterns.append({
        "case": "two_pole_modulated_loop",
        "U": None,
        "J": J,
        "kind": "current_profile",
        "interpretation": "DC current plus m=2 winding modulation",
    })

    J = 1.0 + eps*np.cos(4*theta)
    patterns.append({
        "case": "four_pole_modulated_loop",
        "U": None,
        "J": J,
        "kind": "current_profile",
        "interpretation": "DC current plus m=4 winding modulation",
    })

    J = np.cos(2*theta)
    patterns.append({
        "case": "pure_two_lobe_ac_zero_mean",
        "U": None,
        "J": J,
        "kind": "current_profile",
        "interpretation": "zero-mean m=2 AC winding; no DC dipole but rectified power exists",
    })

    J = 1.0 + 0.35*np.cos(2*theta) + 0.20*np.sin(3*theta)
    patterns.append({
        "case": "mixed_generator_like_winding",
        "U": None,
        "J": J,
        "kind": "current_profile",
        "interpretation": "mixed winding profile with m=2 and m=3 fingerprints",
    })

    # Spinor with amplitude/winding modulation, bilinear phase-current
    amp = np.sqrt(np.maximum(1.0 + eps*np.cos(2*theta), 1e-9))
    U = phase_pattern(theta, winding=0.5, amp=amp)
    J = phase_current(theta, U)
    patterns.append({
        "case": "spinor_half_with_two_pole_amplitude",
        "U": U,
        "J": J,
        "kind": "bilinear_phase_current",
        "interpretation": "spinor phase current weighted by m=2 amplitude modulation",
    })

    return patterns


def circular_shift_periodic(values, shift_samples):
    return np.roll(values, shift_samples)


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    # endpoint=False makes periodic Fourier averages cleaner
    theta = np.linspace(0, 2*np.pi, args.N, endpoint=False)
    patterns = pattern_library(theta)

    summary_rows = []
    spectra_rows = []
    rect_rows = []

    for p in patterns:
        case = p["case"]
        J = p["J"]
        spec = fourier_spectrum(theta, J, args.mmax)
        spec["case"] = case
        spectra_rows.extend(spec.to_dict("records"))

        nonzero = spec[spec["m"] > 0]
        dominant_nonzero = nonzero.loc[nonzero["amplitude"].idxmax()] if len(nonzero) else None
        dominant_m = int(dominant_nonzero["m"]) if dominant_nonzero is not None else 0
        dominant_amp = float(dominant_nonzero["amplitude"]) if dominant_nonzero is not None else 0.0

        dc = float(np.mean(J))
        ac_rms = float(np.sqrt(np.mean((J-dc)**2)))
        rectified_dc = float(np.mean(J*J))
        signed_dipole_proxy = dc

        summary_rows.append({
            "case": case,
            "kind": p["kind"],
            "dc_current_mean": dc,
            "signed_magnetic_dipole_proxy": signed_dipole_proxy,
            "ac_rms_non_dc": ac_rms,
            "rectified_power_mean_J2": rectified_dc,
            "dominant_nonzero_mode": dominant_m,
            "dominant_nonzero_amplitude": dominant_amp,
            "interpretation": p["interpretation"],
        })

        rect_rows.append({
            "case": case,
            "dc_output": dc,
            "ac_output_rms": ac_rms,
            "rectified_output_mean_J2": rectified_dc,
            "dc_fraction_of_rms_total": abs(dc)/(np.sqrt(np.mean(J*J))+1e-30),
        })

    summary = pd.DataFrame(summary_rows)
    spectra = pd.DataFrame(spectra_rows)
    rect = pd.DataFrame(rect_rows)

    summary_path = outdir / "v11_9h_pattern_summary.csv"
    spectra_path = outdir / "v11_9h_fourier_spectra.csv"
    rect_path = outdir / "v11_9h_rectification_summary.csv"
    summary.to_csv(summary_path, index=False)
    spectra.to_csv(spectra_path, index=False)
    rect.to_csv(rect_path, index=False)

    # Spinor sign vs bilinear periodicity check over theta in [0,4pi]
    theta4 = np.linspace(0, 4*np.pi, 2*args.N, endpoint=False)
    Uplus4 = phase_pattern(theta4, winding=0.5)
    Uminus4 = phase_pattern(theta4, winding=-0.5)
    Jplus4 = phase_current(theta4, Uplus4)
    Jminus4 = phase_current(theta4, Uminus4)

    # Compare U(theta+2pi) to -U(theta), and J(theta+2pi) to J(theta)
    half = args.N
    U_flip_err_plus = float(np.max(np.abs(Uplus4[half:] + Uplus4[:half])))
    J_period_err_plus = float(np.max(np.abs(Jplus4[half:] - Jplus4[:half])))
    U_flip_err_minus = float(np.max(np.abs(Uminus4[half:] + Uminus4[:half])))
    J_period_err_minus = float(np.max(np.abs(Jminus4[half:] - Jminus4[:half])))

    spinor_period = pd.DataFrame([
        {
            "case": "spinor_plus_half",
            "max_error_U_theta_plus_2pi_equals_minus_U": U_flip_err_plus,
            "max_error_J_theta_plus_2pi_equals_J": J_period_err_plus,
            "mean_phase_current": float(np.mean(Jplus4)),
            "handedness_sign": float(np.sign(np.mean(Jplus4))),
        },
        {
            "case": "spinor_minus_half",
            "max_error_U_theta_plus_2pi_equals_minus_U": U_flip_err_minus,
            "max_error_J_theta_plus_2pi_equals_J": J_period_err_minus,
            "mean_phase_current": float(np.mean(Jminus4)),
            "handedness_sign": float(np.sign(np.mean(Jminus4))),
        },
    ])
    spinor_path = outdir / "v11_9h_spinor_bilinear_periodicity.csv"
    spinor_period.to_csv(spinor_path, index=False)

    # Gates / verdict
    plus_mean = float(summary[summary["case"] == "spinor_plus_half_bilinear"]["dc_current_mean"].iloc[0])
    minus_mean = float(summary[summary["case"] == "spinor_minus_half_bilinear"]["dc_current_mean"].iloc[0])
    two_mode = int(summary[summary["case"] == "two_pole_modulated_loop"]["dominant_nonzero_mode"].iloc[0])
    four_mode = int(summary[summary["case"] == "four_pole_modulated_loop"]["dominant_nonzero_mode"].iloc[0])
    mixed = summary[summary["case"] == "mixed_generator_like_winding"].iloc[0]
    ac_zero = summary[summary["case"] == "pure_two_lobe_ac_zero_mean"].iloc[0]

    # spectra uniqueness: check two-pole and four-pole identify expected modes
    spectra_pass = (two_mode == 2) and (four_mode == 4) and (int(mixed["dominant_nonzero_mode"]) in [2,3])
    spinor_pass = (spinor_period[["max_error_U_theta_plus_2pi_equals_minus_U", "max_error_J_theta_plus_2pi_equals_J"]].to_numpy().max() < 5e-3)
    handed_pass = (plus_mean > 0) and (minus_mean < 0) and abs(abs(plus_mean) - abs(minus_mean)) < 5e-3
    rect_pass = abs(float(ac_zero["dc_current_mean"])) < 1e-12 and float(ac_zero["rectified_power_mean_J2"]) > 0.49

    verdict = pd.DataFrame([
        {
            "gate": "spinor_sign_invisible_to_bilinear_current",
            "status": "PASS" if spinor_pass else "CHECK",
            "meaning": "U flips at 2pi while bilinear phase-current J is 2pi-periodic",
            "value": float(spinor_period[["max_error_U_theta_plus_2pi_equals_minus_U", "max_error_J_theta_plus_2pi_equals_J"]].to_numpy().max()),
        },
        {
            "gate": "handedness_sets_current_direction",
            "status": "PASS" if handed_pass else "CHECK",
            "meaning": "opposite spinor phase slopes give opposite signed phase-current/dipole proxy",
            "value": plus_mean - minus_mean,
        },
        {
            "gate": "winding_patterns_have_distinct_spectra",
            "status": "PASS" if spectra_pass else "CHECK",
            "meaning": "different winding profiles produce distinct Fourier/multipole fingerprints",
            "value": float(two_mode + four_mode),
        },
        {
            "gate": "rectification_ac_to_dc_power",
            "status": "PASS" if rect_pass else "CHECK",
            "meaning": "zero-mean AC winding has no DC dipole but has nonzero rectified mean-square output",
            "value": float(ac_zero["rectified_power_mean_J2"]),
        },
        {
            "gate": "claim_level",
            "status": "STRUCTURAL_ANALOGY_PASS_NOT_PARTICLE_DERIVATION",
            "meaning": "generator analogy is structurally useful: motion plus winding topology shapes output fingerprints",
            "value": np.nan,
        },
    ])
    verdict_path = outdir / "v11_9h_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # Plots
    plot_cases = [
        "spinor_plus_half_bilinear",
        "spinor_minus_half_bilinear",
        "two_pole_modulated_loop",
        "four_pole_modulated_loop",
        "pure_two_lobe_ac_zero_mean",
        "mixed_generator_like_winding",
    ]

    plt.figure(figsize=(11, 6.4))
    for case in plot_cases:
        J = next(p["J"] for p in patterns if p["case"] == case)
        plt.plot(theta, J, label=case)
    plt.xlabel("theta")
    plt.ylabel("current / phase-current proxy J(theta)")
    plt.title("V11.9H internal winding/current patterns")
    plt.legend(fontsize=7)
    plt.tight_layout()
    p_patterns = outdir / "v11_9h_current_patterns.png"
    plt.savefig(p_patterns, dpi=args.dpi)
    plt.close()

    # spectra heatmap
    heat_cases = plot_cases
    heat = []
    for case in heat_cases:
        sub = spectra[spectra["case"] == case].sort_values("m")
        heat.append(sub["amplitude"].to_numpy())
    heat = np.array(heat)
    plt.figure(figsize=(9.5, 6.2))
    im = plt.imshow(heat, aspect="auto", origin="lower")
    plt.colorbar(im, label="Fourier amplitude")
    plt.yticks(np.arange(len(heat_cases)), heat_cases)
    plt.xticks(np.arange(args.mmax+1), [str(i) for i in range(args.mmax+1)])
    plt.xlabel("Fourier / multipole mode m")
    plt.title("V11.9H output spectra by winding pattern")
    plt.tight_layout()
    p_heat = outdir / "v11_9h_fourier_spectra_heatmap.png"
    plt.savefig(p_heat, dpi=args.dpi)
    plt.close()

    # DC/AC/rectified bars
    plot_rect = rect[rect["case"].isin(plot_cases)].copy()
    x = np.arange(len(plot_rect))
    width = 0.27
    plt.figure(figsize=(11, 6.4))
    plt.bar(x-width, plot_rect["dc_output"], width=width, label="DC mean / dipole proxy")
    plt.bar(x, plot_rect["ac_output_rms"], width=width, label="AC RMS")
    plt.bar(x+width, plot_rect["rectified_output_mean_J2"], width=width, label="rectified mean J^2")
    plt.xticks(x, plot_rect["case"], rotation=35, ha="right")
    plt.ylabel("output proxy")
    plt.title("V11.9H DC, AC, and rectified outputs")
    plt.legend()
    plt.tight_layout()
    p_rect = outdir / "v11_9h_dc_ac_rectified_outputs.png"
    plt.savefig(p_rect, dpi=args.dpi)
    plt.close()

    # spinor sign vs bilinear current
    plt.figure(figsize=(10, 5.8))
    plt.plot(theta4, Uplus4.real, label="Re U plus-half")
    plt.plot(theta4, Uminus4.real, label="Re U minus-half")
    plt.plot(theta4, Jplus4, label="J plus-half")
    plt.plot(theta4, Jminus4, label="J minus-half")
    plt.axvline(2*np.pi, linestyle="--", label="2pi sign flip")
    plt.xlabel("theta")
    plt.ylabel("state / bilinear current")
    plt.title("V11.9H spinor sign flip vs bilinear phase-current")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_spinor = outdir / "v11_9h_spinor_sign_vs_bilinear_current.png"
    plt.savefig(p_spinor, dpi=args.dpi)
    plt.close()

    report = "# V11.9H Winding Pattern / Multipole Output Toy\n\n"
    report += "This is a structural analogy toy inspired by generator winding intuition. It is not a claim that particles are literal generators.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Key result\n\nDifferent internal current/winding patterns produce distinct DC, AC, rectified, and Fourier/multipole output fingerprints. Spinor sign flips are invisible to bilinear standalone field output, while handedness appears as phase-current direction.\n\n"
    report += "## Guardrail\n\nThis does not derive particle magnetic moments or replace the Pauli/Dirac coupling. It provides an intuition bridge: motion plus winding topology plus coupling geometry shapes field output.\n"
    report_path = outdir / "v11_9h_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9H complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nPattern summary:")
    print(summary.to_string(index=False))
    print("\nSpinor bilinear periodicity:")
    print(spinor_period.to_string(index=False))
    print("\nSaved files:")
    for pth in [summary_path, spectra_path, spinor_path, rect_path, verdict_path, report_path,
                p_patterns, p_heat, p_rect, p_spinor]:
        print(pth)
    print(outdir)


if __name__ == "__main__":
    main()
