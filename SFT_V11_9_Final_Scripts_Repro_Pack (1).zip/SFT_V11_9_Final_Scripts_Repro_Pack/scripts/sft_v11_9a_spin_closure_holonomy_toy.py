#!/usr/bin/env python3
"""
SFT V11.9A — Spin Closure / Lag-Holonomy Toy

This is a representation test, not a derivation of physical spin.

Core gates:
  simple/integer loop: U(theta+2pi)=U(theta)
  spinor/half-twist loop: U(theta+2pi)=-U(theta), U(theta+4pi)=U(theta)

SFT-flavored form:
  dU/dtheta = i A(theta) U
  H = exp(i integral A(theta)dtheta)

Outputs:
  v11_9a_closure_summary.csv
  v11_9a_connection_robustness.csv
  v11_9a_exchange_seed.csv
  v11_9a_verdict.csv
  v11_9a_*.png
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--N", type=int, default=2048)
    p.add_argument("--outdir", type=str, default="sft_v11_9a_spin_closure_holonomy_output")
    p.add_argument("--dpi", type=int, default=170)
    p.add_argument("--seed", type=int, default=119)
    return p.parse_args()


def wrap(phi):
    return (phi + np.pi) % (2*np.pi) - np.pi


def interp_complex(theta, z, target):
    return complex(np.interp(target, theta, z.real), np.interp(target, theta, z.imag))


def classify_phase(phi):
    pm = wrap(phi)
    if abs(pm) < 1e-2:
        return "integer/simple"
    if abs(abs(pm) - np.pi) < 1e-2:
        return "half_twist/spinor"
    return "generic/nonquantized"


def analyze(theta, U, case, spinor_expected):
    U0 = interp_complex(theta, U, 0)
    U2 = interp_complex(theta, U, 2*np.pi)
    U4 = interp_complex(theta, U, 4*np.pi)
    e2_same = abs(U2 - U0)
    e2_flip = abs(U2 + U0)
    e4_same = abs(U4 - U0)
    if spinor_expected:
        ok = e2_flip < 2e-3 and e4_same < 2e-3
        expected = "spinor_4pi"
    else:
        ok = e2_same < 2e-3
        expected = "simple_2pi"
    return {
        "case": case,
        "expected_class": expected,
        "U_2pi_real": U2.real,
        "U_2pi_imag": U2.imag,
        "U_4pi_real": U4.real,
        "U_4pi_imag": U4.imag,
        "error_2pi_same": e2_same,
        "error_2pi_sign_flip": e2_flip,
        "error_4pi_same": e4_same,
        "pass_closure_gate": bool(ok),
    }


def U_direct(theta, winding):
    return np.exp(1j*winding*theta)


def A_connection(theta, winding, amp=0.0, phases=None):
    # zero-mean perturbations preserve total holonomy class
    modes = [2, 3, 5]
    if phases is None:
        phases = np.zeros(len(modes))
    A = np.full_like(theta, winding, dtype=float)
    for m, ph in zip(modes, phases):
        A += amp*np.sin(m*theta + ph)
    return A


def U_from_A(theta, A):
    dth = np.diff(theta)
    mid = 0.5*(A[1:]+A[:-1])
    integ = np.zeros_like(theta)
    integ[1:] = np.cumsum(mid*dth)
    return np.exp(1j*integ), integ


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    theta = np.linspace(0, 4*np.pi, args.N)

    rows = []
    plot_states = {}

    direct_cases = [
        ("boson_plus1", +1.0, False),
        ("boson_minus1", -1.0, False),
        ("scalar_winding0", 0.0, False),
        ("fermion_plus_half", +0.5, True),
        ("fermion_minus_half", -0.5, True),
        ("spin_3half_seed", +1.5, True),
    ]
    for case, winding, spinor in direct_cases:
        U = U_direct(theta, winding)
        plot_states[case] = U
        row = analyze(theta, U, case, spinor)
        row.update({
            "representation": "direct_phase",
            "winding": winding,
            "perturb_amp": 0.0,
            "holonomy_2pi_phase": float(wrap(2*np.pi*winding)),
            "holonomy_class": classify_phase(2*np.pi*winding),
        })
        rows.append(row)

    conn_cases = [
        ("connection_integer", +1.0, False, 0.0),
        ("connection_integer_perturbed", +1.0, False, 0.15),
        ("connection_half_twist", +0.5, True, 0.0),
        ("connection_half_twist_perturbed", +0.5, True, 0.15),
        ("connection_half_twist_minus", -0.5, True, 0.0),
    ]
    for case, winding, spinor, amp in conn_cases:
        phases = rng.uniform(0, 2*np.pi, 3)
        A = A_connection(theta, winding, amp, phases)
        U, integ = U_from_A(theta, A)
        plot_states[case] = U
        hol2 = np.interp(2*np.pi, theta, integ)
        row = analyze(theta, U, case, spinor)
        row.update({
            "representation": "lag_connection",
            "winding": winding,
            "perturb_amp": amp,
            "holonomy_2pi_phase": float(wrap(hol2)),
            "holonomy_class": classify_phase(hol2),
        })
        rows.append(row)

    closure = pd.DataFrame(rows)
    closure_path = outdir / "v11_9a_closure_summary.csv"
    closure.to_csv(closure_path, index=False)

    # Robustness under zero-mean connection wiggles
    rob = []
    amps = np.linspace(0, 0.75, 16)
    for label, winding, spinor in [("integer", 1.0, False), ("half_twist", 0.5, True)]:
        for amp in amps:
            phase_errs = []
            e2s, e2f, e4s = [], [], []
            for _ in range(50):
                phases = rng.uniform(0, 2*np.pi, 3)
                A = A_connection(theta, winding, amp, phases)
                U, integ = U_from_A(theta, A)
                r = analyze(theta, U, label, spinor)
                e2s.append(r["error_2pi_same"])
                e2f.append(r["error_2pi_sign_flip"])
                e4s.append(r["error_4pi_same"])
                hol2 = np.interp(2*np.pi, theta, integ)
                phase_errs.append(abs(wrap(hol2 - 2*np.pi*winding)))
            rob.append({
                "class": label,
                "winding": winding,
                "perturb_amp": amp,
                "trials": 50,
                "mean_error_2pi_same": float(np.mean(e2s)),
                "mean_error_2pi_sign_flip": float(np.mean(e2f)),
                "mean_error_4pi_same": float(np.mean(e4s)),
                "mean_holonomy_phase_error": float(np.mean(phase_errs)),
                "max_holonomy_phase_error": float(np.max(phase_errs)),
            })
    robustness = pd.DataFrame(rob)
    robustness_path = outdir / "v11_9a_connection_robustness.csv"
    robustness.to_csv(robustness_path, index=False)

    # Exchange-sign seed
    ex_rows = []
    for case, phase in [
        ("boson_integer_exchange", 2*np.pi),
        ("fermion_single_exchange", np.pi),
        ("fermion_double_exchange", 2*np.pi),
        ("generic_quarter_phase_seed", np.pi/2),
    ]:
        z = np.exp(1j*phase)
        ex_rows.append({
            "case": case,
            "exchange_phase_rad": phase,
            "exchange_phase_deg": np.degrees(phase),
            "phase_factor_real": float(z.real),
            "phase_factor_imag": float(z.imag),
            "is_plus_one": bool(abs(z-1) < 1e-12),
            "is_minus_one": bool(abs(z+1) < 1e-12),
        })
    exchange = pd.DataFrame(ex_rows)
    exchange_path = outdir / "v11_9a_exchange_seed.csv"
    exchange.to_csv(exchange_path, index=False)

    # Verdict
    def pass_case(name):
        return bool(closure.loc[closure.case == name, "pass_closure_gate"].iloc[0])

    simple_ok = pass_case("boson_plus1") and pass_case("connection_integer")
    spinor_ok = pass_case("fermion_plus_half") and pass_case("connection_half_twist")
    hp = float(closure.loc[closure.case == "fermion_plus_half", "holonomy_2pi_phase"].iloc[0])
    hm = float(closure.loc[closure.case == "fermion_minus_half", "holonomy_2pi_phase"].iloc[0])
    handed_ok = hp > 0 and hm < 0
    robust_ok = robustness["max_holonomy_phase_error"].max() < 2e-2
    exchange_ok = bool(exchange.loc[exchange.case == "fermion_single_exchange", "is_minus_one"].iloc[0]
                       and exchange.loc[exchange.case == "fermion_double_exchange", "is_plus_one"].iloc[0])

    verdict = pd.DataFrame([
        {"gate": "simple_2pi_closure", "status": "PASS" if simple_ok else "CHECK", "meaning": "integer/simple loops return after 2pi"},
        {"gate": "spinor_4pi_closure", "status": "PASS" if spinor_ok else "CHECK", "meaning": "half-twist loops flip at 2pi and restore at 4pi"},
        {"gate": "handedness", "status": "PASS" if handed_ok else "CHECK", "meaning": "opposite signs encode opposite handedness/projection"},
        {"gate": "zero_mean_connection_robustness", "status": "PASS" if robust_ok else "CHECK", "meaning": "zero-mean A(theta) wiggles preserve holonomy class"},
        {"gate": "exchange_sign_seed", "status": "PASS" if exchange_ok else "CHECK", "meaning": "single spinor exchange gives -1 seed; double restores +1"},
    ])
    verdict_path = outdir / "v11_9a_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # Plots
    plt.figure(figsize=(7, 7))
    for case in ["boson_plus1", "fermion_plus_half", "fermion_minus_half", "connection_half_twist_perturbed"]:
        U = plot_states[case]
        plt.plot(U.real, U.imag, label=case)
    plt.scatter([1], [0], label="start")
    plt.axhline(0, linewidth=0.7)
    plt.axvline(0, linewidth=0.7)
    plt.gca().set_aspect("equal", adjustable="box")
    plt.xlabel("Re U")
    plt.ylabel("Im U")
    plt.title("V11.9A phase paths, theta 0 to 4pi")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_phase = outdir / "v11_9a_phase_paths_complex_plane.png"
    plt.savefig(p_phase, dpi=args.dpi)
    plt.close()

    xpos = np.arange(len(closure))
    plt.figure(figsize=(11, 6.5))
    plt.bar(xpos - 0.25, closure.error_2pi_same, width=0.25, label="2pi same")
    plt.bar(xpos, closure.error_2pi_sign_flip, width=0.25, label="2pi sign flip")
    plt.bar(xpos + 0.25, closure.error_4pi_same, width=0.25, label="4pi same")
    plt.yscale("log")
    plt.xticks(xpos, closure.case, rotation=45, ha="right")
    plt.ylabel("closure error")
    plt.title("V11.9A closure errors")
    plt.legend()
    plt.tight_layout()
    p_err = outdir / "v11_9a_closure_errors.png"
    plt.savefig(p_err, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(9, 5.8))
    for cls in ["integer", "half_twist"]:
        sub = robustness[robustness["class"] == cls]
        plt.plot(sub.perturb_amp, sub.mean_holonomy_phase_error, marker="o", label=cls)
    plt.yscale("log")
    plt.xlabel("zero-mean perturbation amplitude")
    plt.ylabel("mean holonomy phase error")
    plt.title("V11.9A holonomy robustness under zero-mean A(theta) wiggles")
    plt.legend()
    plt.tight_layout()
    p_rob = outdir / "v11_9a_perturbation_robustness.png"
    plt.savefig(p_rob, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(9, 5.8))
    plt.scatter(closure.winding, closure.holonomy_2pi_phase, s=70)
    for _, r in closure.iterrows():
        plt.annotate(r.case.replace("_", "\n"), (r.winding, r.holonomy_2pi_phase), fontsize=6, xytext=(3,3), textcoords="offset points")
    plt.axhline(0, linestyle="--")
    plt.axhline(np.pi, linestyle=":")
    plt.axhline(-np.pi, linestyle=":")
    plt.xlabel("winding / mean connection")
    plt.ylabel("2pi holonomy phase wrapped")
    plt.title("V11.9A holonomy classes")
    plt.tight_layout()
    p_hol = outdir / "v11_9a_holonomy_classes.png"
    plt.savefig(p_hol, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(7, 7))
    t = np.linspace(0, 2*np.pi, 300)
    plt.plot(np.cos(t), np.sin(t), linewidth=0.8)
    plt.scatter(exchange.phase_factor_real, exchange.phase_factor_imag, s=90)
    for _, r in exchange.iterrows():
        plt.annotate(r.case.replace("_", "\n"), (r.phase_factor_real, r.phase_factor_imag), fontsize=8, xytext=(4,4), textcoords="offset points")
    plt.axhline(0, linewidth=0.7)
    plt.axvline(0, linewidth=0.7)
    plt.gca().set_aspect("equal", adjustable="box")
    plt.xlabel("Re phase factor")
    plt.ylabel("Im phase factor")
    plt.title("V11.9A exchange-sign seed")
    plt.tight_layout()
    p_ex = outdir / "v11_9a_exchange_seed.png"
    plt.savefig(p_ex, dpi=args.dpi)
    plt.close()

    report = "# V11.9A Spin Closure / Lag-Holonomy Toy\n\n"
    report += "This is a representation/seed toy, not a derivation of physical spin.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Closure summary\n\n" + closure.to_markdown(index=False) + "\n\n"
    report += "## Earned statement\n\nSFT can represent simple 2pi closure and spinor 4pi closure as distinct holonomy classes of internal Compton/lag-field circulation.\n\n"
    report += "## Guardrail\n\nThis does not derive the electron, Pauli exclusion, spin-statistics, or magnetic moments.\n"
    report_path = outdir / "v11_9a_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9A complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nClosure summary:")
    print(closure[["case","representation","winding","holonomy_class","error_2pi_same","error_2pi_sign_flip","error_4pi_same","pass_closure_gate"]].to_string(index=False))
    print("\nSaved files:")
    for p in [closure_path, robustness_path, exchange_path, verdict_path, report_path, p_phase, p_err, p_hol, p_rob, p_ex]:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
