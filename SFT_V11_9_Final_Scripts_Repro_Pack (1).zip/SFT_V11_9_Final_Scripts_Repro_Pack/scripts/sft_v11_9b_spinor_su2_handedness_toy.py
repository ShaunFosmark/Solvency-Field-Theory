#!/usr/bin/env python3
"""
SFT V11.9B — Spinor Handedness and SU(2) Closure Toy

Purpose
-------
Patch and extend V11.9A.

V11.9A showed simple 2pi closure vs spinor 4pi closure, but the handedness
gate was checked using the wrapped endpoint phase. That is the wrong diagnostic
because +pi and -pi both map to -1.

V11.9B fixes this by measuring handedness from the UNWRAPPED phase path /
phase slope.

It also upgrades the representation from scalar complex phases to actual
two-component SU(2) spinors:

    R_n(theta) = cos(theta/2) I - i sin(theta/2) (n . sigma)

Gates
-----
1. SU(2) closure:
       R(2pi) = -I
       R(4pi) =  I

2. Handedness:
       spin-up and spin-down under z-rotation have opposite unwrapped phase slopes.

3. Double cover:
       SO(3) vector rotation closes at 2pi while SU(2) spinor closes at 4pi.

4. Measurement invariance:
       psi and -psi give identical spin measurement probabilities.

5. Interference sign:
       2pi spinor rotation flips relative interference phase; 4pi restores it.

Outputs
-------
CSV:
    v11_9b_su2_closure_summary.csv
    v11_9b_handedness_summary.csv
    v11_9b_measurement_invariance.csv
    v11_9b_interference_sign.csv
    v11_9b_verdict.csv

Plots:
    v11_9b_phase_slopes.png
    v11_9b_su2_closure_errors.png
    v11_9b_bloch_double_cover.png
    v11_9b_measurement_invariance.png
    v11_9b_interference_sign.png

Run
---
    python sft_v11_9b_spinor_su2_handedness_toy.py
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--N", type=int, default=2048)
    p.add_argument("--outdir", type=str, default="sft_v11_9b_spinor_su2_output")
    p.add_argument("--dpi", type=int, default=170)
    return p.parse_args()


# Pauli matrices
I2 = np.eye(2, dtype=complex)
sx = np.array([[0, 1], [1, 0]], dtype=complex)
sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
sz = np.array([[1, 0], [0, -1]], dtype=complex)
sigmas = np.array([sx, sy, sz])


def norm_mat(A):
    return float(np.linalg.norm(A))


def normalize(v):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    if n == 0:
        raise ValueError("zero vector")
    return v / n


def su2_rotation(axis, theta):
    axis = normalize(axis)
    nsigma = axis[0]*sx + axis[1]*sy + axis[2]*sz
    return np.cos(theta/2)*I2 - 1j*np.sin(theta/2)*nsigma


def so3_rotation(axis, theta):
    axis = normalize(axis)
    x, y, z = axis
    K = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]], dtype=float)
    return np.eye(3) + np.sin(theta)*K + (1-np.cos(theta))*(K@K)


def spinor_up_z():
    return np.array([1+0j, 0+0j])


def spinor_down_z():
    return np.array([0+0j, 1+0j])


def density(psi):
    psi = psi / np.linalg.norm(psi)
    return np.outer(psi, np.conj(psi))


def bloch_vector(psi):
    rho = density(psi)
    return np.array([
        np.real(np.trace(rho @ sx)),
        np.real(np.trace(rho @ sy)),
        np.real(np.trace(rho @ sz)),
    ])


def spinor_from_bloch(n):
    """
    Spin-up eigenstate along unit vector n.
    """
    n = normalize(n)
    theta = np.arccos(np.clip(n[2], -1, 1))
    phi = np.arctan2(n[1], n[0])
    return np.array([
        np.cos(theta/2),
        np.exp(1j*phi)*np.sin(theta/2),
    ], dtype=complex)


def measurement_probabilities(psi, axis):
    axis = normalize(axis)
    ket_plus = spinor_from_bloch(axis)
    ket_minus = spinor_from_bloch(-axis)
    psi = psi / np.linalg.norm(psi)
    p_plus = abs(np.vdot(ket_plus, psi))**2
    p_minus = abs(np.vdot(ket_minus, psi))**2
    return float(p_plus), float(p_minus)


def unwrap_phase_of_component(values):
    return np.unwrap(np.angle(values))


def fit_slope(x, y):
    c = np.polyfit(x, y, 1)
    return float(c[0]), float(c[1])


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    theta = np.linspace(0, 4*np.pi, args.N)

    # ------------------------------------------------------------
    # Gate 1: SU(2) closure and SO(3) double cover
    # ------------------------------------------------------------
    axes = {
        "z": np.array([0, 0, 1.0]),
        "x": np.array([1.0, 0, 0]),
        "diagonal": normalize([1, 1, 1]),
    }

    closure_rows = []
    for name, axis in axes.items():
        R0 = su2_rotation(axis, 0)
        R2 = su2_rotation(axis, 2*np.pi)
        R4 = su2_rotation(axis, 4*np.pi)

        O0 = so3_rotation(axis, 0)
        O2 = so3_rotation(axis, 2*np.pi)
        O4 = so3_rotation(axis, 4*np.pi)

        closure_rows.append({
            "axis": name,
            "su2_error_R2pi_minus_negative_I": norm_mat(R2 + I2),
            "su2_error_R4pi_minus_I": norm_mat(R4 - I2),
            "so3_error_O2pi_minus_I": float(np.linalg.norm(O2 - np.eye(3))),
            "so3_error_O4pi_minus_I": float(np.linalg.norm(O4 - np.eye(3))),
            "pass_su2_4pi_gate": bool(norm_mat(R2 + I2) < 1e-12 and norm_mat(R4 - I2) < 1e-12),
            "pass_so3_2pi_gate": bool(np.linalg.norm(O2 - np.eye(3)) < 1e-12),
        })
    closure = pd.DataFrame(closure_rows)
    closure_path = outdir / "v11_9b_su2_closure_summary.csv"
    closure.to_csv(closure_path, index=False)

    # ------------------------------------------------------------
    # Gate 2: handedness from unwrapped phase slope
    # Under z rotation:
    #   |up>   -> exp(-i theta/2)|up>    slope -1/2
    #   |down> -> exp(+i theta/2)|down>  slope +1/2
    # ------------------------------------------------------------
    up = spinor_up_z()
    dn = spinor_down_z()
    up_component = []
    dn_component = []
    up_bloch = []
    dn_bloch = []

    for th in theta:
        R = su2_rotation([0,0,1], th)
        psi_up = R @ up
        psi_dn = R @ dn
        up_component.append(psi_up[0])
        dn_component.append(psi_dn[1])
        up_bloch.append(bloch_vector(psi_up))
        dn_bloch.append(bloch_vector(psi_dn))

    up_component = np.array(up_component)
    dn_component = np.array(dn_component)
    up_phase = unwrap_phase_of_component(up_component)
    dn_phase = unwrap_phase_of_component(dn_component)
    up_slope, up_intercept = fit_slope(theta, up_phase)
    dn_slope, dn_intercept = fit_slope(theta, dn_phase)

    handed = pd.DataFrame([
        {
            "state": "spin_up_z",
            "unwrapped_phase_slope": up_slope,
            "expected_slope": -0.5,
            "slope_error": abs(up_slope + 0.5),
            "handedness_sign": np.sign(up_slope),
        },
        {
            "state": "spin_down_z",
            "unwrapped_phase_slope": dn_slope,
            "expected_slope": +0.5,
            "slope_error": abs(dn_slope - 0.5),
            "handedness_sign": np.sign(dn_slope),
        },
    ])
    handed_path = outdir / "v11_9b_handedness_summary.csv"
    handed.to_csv(handed_path, index=False)

    # ------------------------------------------------------------
    # Gate 3: measurement invariance under global sign
    # ------------------------------------------------------------
    test_states = {
        "up_z": up,
        "down_z": dn,
        "plus_x": spinor_from_bloch([1,0,0]),
        "plus_y": spinor_from_bloch([0,1,0]),
        "diagonal": spinor_from_bloch([1,1,1]),
    }
    measurement_axes = {
        "z": np.array([0,0,1.0]),
        "x": np.array([1.0,0,0]),
        "y": np.array([0,1.0,0]),
        "diag": normalize([1,1,1]),
    }

    meas_rows = []
    for sname, psi in test_states.items():
        for aname, axis in measurement_axes.items():
            p_plus, p_minus = measurement_probabilities(psi, axis)
            p_plus_flip, p_minus_flip = measurement_probabilities(-psi, axis)
            meas_rows.append({
                "state": sname,
                "measurement_axis": aname,
                "p_plus": p_plus,
                "p_minus": p_minus,
                "p_plus_after_global_minus": p_plus_flip,
                "p_minus_after_global_minus": p_minus_flip,
                "abs_delta_p_plus": abs(p_plus - p_plus_flip),
                "abs_delta_p_minus": abs(p_minus - p_minus_flip),
                "normalization_error": abs((p_plus + p_minus) - 1.0),
            })
    measurement = pd.DataFrame(meas_rows)
    meas_path = outdir / "v11_9b_measurement_invariance.csv"
    measurement.to_csv(meas_path, index=False)

    # ------------------------------------------------------------
    # Gate 4: interference sign. A global sign is invisible alone,
    # but visible relative to a reference path.
    # Model intensity I(phi, rot) = |1 + exp(i phi) s(rot)|^2
    # where s(0)=+1, s(2pi)=-1, s(4pi)=+1.
    # ------------------------------------------------------------
    phis = np.linspace(0, 2*np.pi, 512)
    rot_states = [
        ("no_rotation", 1+0j),
        ("spinor_2pi_rotation", -1+0j),
        ("spinor_4pi_rotation", 1+0j),
    ]
    inter_rows = []
    for label, s in rot_states:
        I = np.abs(1 + np.exp(1j*phis)*s)**2
        for idx in np.linspace(0, len(phis)-1, 64).astype(int):
            inter_rows.append({
                "rotation_case": label,
                "reference_phase": float(phis[idx]),
                "intensity": float(I[idx]),
            })
    interference = pd.DataFrame(inter_rows)
    inter_path = outdir / "v11_9b_interference_sign.csv"
    interference.to_csv(inter_path, index=False)

    # ------------------------------------------------------------
    # Verdict
    # ------------------------------------------------------------
    su2_ok = bool(closure["pass_su2_4pi_gate"].all())
    so3_ok = bool(closure["pass_so3_2pi_gate"].all())
    handed_ok = bool((handed["slope_error"] < 1e-12).all() and handed["handedness_sign"].iloc[0] != handed["handedness_sign"].iloc[1])
    measurement_ok = bool(measurement[["abs_delta_p_plus", "abs_delta_p_minus"]].to_numpy().max() < 1e-12)
    interference_ok = True
    # Check that I_2pi(phi) equals I_0(phi+pi) roughly by comparing max at phi=pi vs phi=0
    I0 = np.abs(1 + np.exp(1j*phis)*(1+0j))**2
    I2 = np.abs(1 + np.exp(1j*phis)*(-1+0j))**2
    if not (abs(I0[0] - I2[np.argmin(abs(phis-np.pi))]) < 1e-2 and abs(I2[0]) < 1e-12):
        interference_ok = False

    verdict = pd.DataFrame([
        {"gate": "SU2_4pi_closure", "status": "PASS" if su2_ok else "CHECK", "meaning": "SU(2) spinor rotation gives R(2pi)=-I and R(4pi)=I"},
        {"gate": "SO3_2pi_double_cover", "status": "PASS" if so3_ok else "CHECK", "meaning": "ordinary vectors return after 2pi while spinors require 4pi"},
        {"gate": "handedness_phase_slope", "status": "PASS" if handed_ok else "CHECK", "meaning": "handedness is path slope, not wrapped endpoint phase"},
        {"gate": "measurement_global_sign_invariance", "status": "PASS" if measurement_ok else "CHECK", "meaning": "psi and -psi give identical standalone measurement probabilities"},
        {"gate": "interference_sign_visibility", "status": "PASS" if interference_ok else "CHECK", "meaning": "2pi spinor sign flip is visible in relative/interferometric phase"},
    ])
    verdict_path = outdir / "v11_9b_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # ------------------------------------------------------------
    # Plots
    # ------------------------------------------------------------
    plt.figure(figsize=(9,5.8))
    plt.plot(theta/(2*np.pi), up_phase, label="spin-up z unwrapped phase")
    plt.plot(theta/(2*np.pi), dn_phase, label="spin-down z unwrapped phase")
    plt.xlabel("rotation angle / 2pi")
    plt.ylabel("unwrapped phase [rad]")
    plt.title("V11.9B handedness from phase slope")
    plt.legend()
    plt.tight_layout()
    p_phase = outdir / "v11_9b_phase_slopes.png"
    plt.savefig(p_phase, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.5,5.8))
    xpos = np.arange(len(closure))
    plt.bar(xpos-0.2, closure["su2_error_R2pi_minus_negative_I"], width=0.2, label="||R(2pi)+I||")
    plt.bar(xpos, closure["su2_error_R4pi_minus_I"], width=0.2, label="||R(4pi)-I||")
    plt.bar(xpos+0.2, closure["so3_error_O2pi_minus_I"], width=0.2, label="||O(2pi)-I||")
    plt.yscale("log")
    plt.xticks(xpos, closure["axis"], rotation=0)
    plt.ylabel("closure error")
    plt.title("V11.9B SU(2) / SO(3) closure errors")
    plt.legend()
    plt.tight_layout()
    p_closure = outdir / "v11_9b_su2_closure_errors.png"
    plt.savefig(p_closure, dpi=args.dpi)
    plt.close()

    up_bloch = np.array(up_bloch)
    dn_bloch = np.array(dn_bloch)
    plt.figure(figsize=(7,7))
    plt.plot(up_bloch[:,0], up_bloch[:,1], label="spin-up z Bloch projection")
    plt.plot(dn_bloch[:,0], dn_bloch[:,1], label="spin-down z Bloch projection")
    plt.scatter([0], [0], label="fixed at pole in xy projection")
    plt.xlabel("<sigma_x>")
    plt.ylabel("<sigma_y>")
    plt.title("V11.9B Bloch vector unchanged by z phase rotation")
    plt.legend()
    plt.tight_layout()
    p_bloch = outdir / "v11_9b_bloch_double_cover.png"
    plt.savefig(p_bloch, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(9,5.8))
    pivot = measurement[measurement["state"].isin(["up_z", "plus_x", "diagonal"]) & (measurement["measurement_axis"].isin(["z","x","diag"]))]
    labels = pivot["state"] + " measured " + pivot["measurement_axis"]
    xpos = np.arange(len(pivot))
    plt.bar(xpos-0.2, pivot["p_plus"], width=0.4, label="psi")
    plt.bar(xpos+0.2, pivot["p_plus_after_global_minus"], width=0.4, label="-psi")
    plt.xticks(xpos, labels, rotation=35, ha="right")
    plt.ylabel("P(+)")
    plt.title("V11.9B measurement probabilities invariant under global sign")
    plt.legend()
    plt.tight_layout()
    p_meas = outdir / "v11_9b_measurement_invariance.png"
    plt.savefig(p_meas, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(9,5.8))
    for label, s in rot_states:
        I = np.abs(1 + np.exp(1j*phis)*s)**2
        plt.plot(phis, I, label=label)
    plt.xlabel("reference phase phi")
    plt.ylabel("interference intensity")
    plt.title("V11.9B spinor sign is visible only relative to a reference")
    plt.legend()
    plt.tight_layout()
    p_inter = outdir / "v11_9b_interference_sign.png"
    plt.savefig(p_inter, dpi=args.dpi)
    plt.close()

    report = "# V11.9B Spinor Handedness and SU(2) Closure Toy\n\n"
    report += "This is a representation/seed toy, not a derivation of physical spin.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Handedness\n\n" + handed.to_markdown(index=False) + "\n\n"
    report += "## SU(2) closure\n\n" + closure.to_markdown(index=False) + "\n\n"
    report += "## Earned statement\n\nHandedness is encoded in the unwrapped phase path/slope of the spinor circulation, not in the wrapped 2pi endpoint. SU(2) supplies the correct 4pi spinor closure while SO(3) supplies the ordinary 2pi vector closure.\n\n"
    report += "## Guardrail\n\nThis does not derive electron spin, Pauli exclusion, spin-statistics, or magnetic moments.\n"
    report_path = outdir / "v11_9b_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9B complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nHandedness:")
    print(handed.to_string(index=False))
    print("\nSU(2) closure:")
    print(closure.to_string(index=False))
    print("\nSaved files:")
    for p in [closure_path, handed_path, meas_path, inter_path, verdict_path, report_path, p_phase, p_closure, p_bloch, p_meas, p_inter]:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
