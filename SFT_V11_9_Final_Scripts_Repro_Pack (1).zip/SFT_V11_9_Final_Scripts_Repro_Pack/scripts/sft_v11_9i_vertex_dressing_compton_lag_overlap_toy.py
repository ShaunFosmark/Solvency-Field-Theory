#!/usr/bin/env python3
"""
SFT V11.9I — Vertex Dressing / Compton-Lag Overlap Toy

Purpose
-------
Explore whether the anomalous magnetic moment scale can be interpreted in SFT as
a dressed spinor/EM vertex overlap across one Compton phase cycle.

After V11.9G:
    leading g = 2 is closed at the Pauli/Dirac spinor-covariant interface.

After V11.9F:
    the anomaly scale a=(g-2)/2 is naturally near alpha/(2pi).

V11.9I asks:
    Can a Compton-lag / EM vertex-overlap picture naturally produce

        a_SFT = [alpha/(2pi)] * C_lag

    with C_lag near unity, without pretending to replace QED?

Interpretation
--------------
The alpha/(2pi) loop scale is modeled as:
    total EM coupling alpha distributed over one internal phase loop 2pi.

C_lag is an overlap coefficient determined by the lag/vertex kernel and by
which part of the internal spinor motion the external field samples.

Guardrail
---------
This is a mechanism-finder and scale audit, not a QED derivation.
A true anomalous moment calculation would need the full vertex form factor
F_2(0) and loop structure.

Outputs
-------
CSV:
    v11_9i_kernel_moments.csv
    v11_9i_overlap_predictions.csv
    v11_9i_required_coefficients.csv
    v11_9i_retarded_scan.csv
    v11_9i_higher_order_budget.csv
    v11_9i_verdict.csv

Plots:
    v11_9i_kernel_shapes.png
    v11_9i_overlap_coefficients.png
    v11_9i_retarded_scan_heatmap.png
    v11_9i_higher_order_budget.png

Run:
    python sft_v11_9i_vertex_dressing_compton_lag_overlap_toy.py
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", default="sft_v11_9i_vertex_dressing_overlap_output")
    p.add_argument("--dpi", type=int, default=170)
    p.add_argument("--N", type=int, default=4096)
    p.add_argument("--scanN", type=int, default=160)
    return p.parse_args()


# Approximate low-energy fine-structure constant.
alpha = 1 / 137.035999084
base = alpha / (2*np.pi)

# Approximate reference anomalies a=(g-2)/2.
references = [
    {
        "particle": "electron",
        "a_reference": 0.00115965218128,
        "status": "scale reference; update externally for precision metrology",
    },
    {
        "particle": "muon",
        "a_reference": 0.00116592061,
        "status": "scale reference; includes non-electron mass/sector effects",
    },
]


def normalize_kernel(phi, K):
    dphi = phi[1] - phi[0]
    total = np.sum(K) * dphi
    if total == 0:
        raise ValueError("zero kernel")
    return K / total


def circular_distance(phi, center):
    """distance on circle [-pi,pi)."""
    return (phi - center + np.pi) % (2*np.pi) - np.pi


def kernel_library(phi):
    kernels = []

    # Uniform one-cycle overlap: coupling spread evenly over Compton phase.
    K = np.ones_like(phi)
    kernels.append(("uniform_one_cycle", normalize_kernel(phi, K),
                    "EM coupling uniformly distributed over one 2pi Compton phase"))

    # Symmetric local overlap around zero phase.
    for width in [0.35, 0.75, 1.50]:
        d = circular_distance(phi, 0.0)
        K = np.exp(-0.5*(d/width)**2)
        kernels.append((f"symmetric_wrapped_gaussian_width_{width:g}", normalize_kernel(phi, K),
                        "symmetric localized Compton-lag overlap"))

    # Retarded one-sided lag kernel over [0,2pi).
    for tau in [0.25, 0.75, 1.50, 3.00]:
        K = np.exp(-phi/tau)
        kernels.append((f"retarded_exponential_tau_{tau:g}", normalize_kernel(phi, K),
                        "causal/retarded lag response around current phase"))

    # Delayed/shifted symmetric kernel.
    for center in [np.pi/4, np.pi/2, np.pi]:
        d = circular_distance(phi, center)
        K = np.exp(-0.5*(d/0.65)**2)
        kernels.append((f"shifted_symmetric_center_{center/np.pi:.2f}pi", normalize_kernel(phi, K),
                        "lag overlap centered away from present phase"))

    # Two-lobed overlap, useful for winding/standing-wave intuition.
    K = 1.0 + 0.45*np.cos(2*phi)
    K = np.maximum(K, 1e-9)
    kernels.append(("two_lobe_symmetric_kernel", normalize_kernel(phi, K),
                    "two-lobed internal overlap kernel"))

    return kernels


def vertex_library(phi):
    vertices = []

    # Bilinear invariant channel: spinor sign-invariant, normalized to unity.
    vertices.append(("bilinear_invariant", np.ones_like(phi),
                     "spinor-bilinear channel; global sign invisible; C=1 for any normalized kernel"))

    # Spinor phase-current channel: J = Im(U* dU) = 1/2 for U=e^{i theta/2}; normalized by 1/2.
    vertices.append(("spinor_phase_current_normalized", np.ones_like(phi),
                     "normalized spinor phase-current channel; handedness sign handled separately"))

    # Mild phase-sensitive channels.
    eps = 0.05
    vertices.append(("mild_cos_phase_sensitive_eps_0p05", 1.0 + eps*np.cos(phi),
                     "small phase-sensitive modulation of vertex response"))
    vertices.append(("mild_sin_retarded_phase_eps_0p05", 1.0 + eps*np.sin(phi),
                     "small quadrature/retarded modulation of vertex response"))

    # Winding/amplitude channels with mean unity under uniform average.
    vertices.append(("two_pole_amplitude_vertex_eps_0p10", 1.0 + 0.10*np.cos(2*phi),
                     "two-pole amplitude modulation; generator-like winding fingerprint"))
    vertices.append(("mixed_winding_vertex", 1.0 + 0.06*np.cos(2*phi) + 0.03*np.sin(3*phi),
                     "mixed winding response with m=2 and m=3 fingerprints"))

    # Phase-loss / destructive overlap candidate.
    vertices.append(("lossy_retarded_overlap_eps_0p01", 1.0 - 0.01*(1.0 - np.cos(phi)),
                     "small destructive overlap away from zero lag"))

    # Bad channels / guardrails.
    vertices.append(("raw_alpha_like_no_loop_average_guardrail", np.full_like(phi, 2*np.pi),
                     "guardrail: would turn alpha/(2pi) into raw alpha scale"))
    vertices.append(("alpha_squared_like_suppression_guardrail", np.full_like(phi, alpha),
                     "guardrail: would make leading scale alpha^2/(2pi), too small"))

    return vertices


def kernel_moments(phi, K):
    dphi = phi[1] - phi[0]
    mean_cos = float(np.sum(K*np.cos(phi))*dphi)
    mean_sin = float(np.sum(K*np.sin(phi))*dphi)
    mean_cos2 = float(np.sum(K*np.cos(2*phi))*dphi)
    mean_sin2 = float(np.sum(K*np.sin(2*phi))*dphi)
    phase_vec = mean_cos + 1j*mean_sin
    return {
        "mean_cos_phi": mean_cos,
        "mean_sin_phi": mean_sin,
        "phase_vector_abs_m1": abs(phase_vec),
        "phase_vector_arg_m1": float(np.angle(phase_vec)),
        "mean_cos_2phi": mean_cos2,
        "mean_sin_2phi": mean_sin2,
    }


def overlap_C(phi, K, V):
    dphi = phi[1] - phi[0]
    return float(np.sum(K*V)*dphi)


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    phi = np.linspace(0, 2*np.pi, args.N, endpoint=False)
    kernels = kernel_library(phi)
    vertices = vertex_library(phi)

    # Kernel moments
    km_rows = []
    for kname, K, kdesc in kernels:
        row = {
            "kernel": kname,
            "kernel_description": kdesc,
            "normalization_integral": overlap_C(phi, K, np.ones_like(phi)),
        }
        row.update(kernel_moments(phi, K))
        km_rows.append(row)
    kernel_df = pd.DataFrame(km_rows)
    kernel_path = outdir / "v11_9i_kernel_moments.csv"
    kernel_df.to_csv(kernel_path, index=False)

    # Overlap predictions
    pred_rows = []
    for kname, K, kdesc in kernels:
        for vname, V, vdesc in vertices:
            C = overlap_C(phi, K, V)
            a_pred = base*C
            pred_rows.append({
                "kernel": kname,
                "vertex": vname,
                "C_lag": C,
                "a_pred": a_pred,
                "g_pred": 2 + 2*a_pred,
                "kernel_description": kdesc,
                "vertex_description": vdesc,
                "claim_status": (
                    "natural_bilinear_scale" if vname in ["bilinear_invariant", "spinor_phase_current_normalized"] else
                    "phase_sensitive_candidate" if "eps" in vname or "winding" in vname else
                    "guardrail"
                ),
            })
    pred = pd.DataFrame(pred_rows)
    pred_path = outdir / "v11_9i_overlap_predictions.csv"
    pred.to_csv(pred_path, index=False)

    # Required coefficients
    req_rows = []
    for ref in references:
        C_req = ref["a_reference"] / base
        req_rows.append({
            "particle": ref["particle"],
            "a_reference": ref["a_reference"],
            "base_alpha_over_2pi": base,
            "C_required": C_req,
            "C_required_minus_1": C_req - 1.0,
            "percent_offset_from_1": 100*(C_req - 1.0),
            "reference_status": ref["status"],
        })
    req = pd.DataFrame(req_rows)
    req_path = outdir / "v11_9i_required_coefficients.csv"
    req.to_csv(req_path, index=False)

    # Retarded scan: K_tau ∝ exp(-phi/tau), vertex V=1+eps*cos(phi+phase)
    # Find how easy it is to get C near electron C_required with a small phase-sensitive correction.
    e_C_req = float(req[req["particle"] == "electron"]["C_required"].iloc[0])
    taus = np.logspace(np.log10(0.08), np.log10(8.0), args.scanN)
    eps_vals = np.linspace(-0.05, 0.05, args.scanN)
    scan_rows = []
    best = None
    for tau in taus:
        K = normalize_kernel(phi, np.exp(-phi/tau))
        cosmean = overlap_C(phi, K, np.cos(phi))
        for eps in eps_vals:
            C = 1.0 + eps*cosmean
            err = abs(C - e_C_req)
            row = {
                "tau": tau,
                "eps": eps,
                "kernel_mean_cos": cosmean,
                "C_lag": C,
                "abs_error_to_electron_C_required": err,
            }
            scan_rows.append(row)
            if best is None or err < best["abs_error_to_electron_C_required"]:
                best = row
    scan = pd.DataFrame(scan_rows)
    scan_path = outdir / "v11_9i_retarded_scan.csv"
    scan.to_csv(scan_path, index=False)

    # Higher order budget: how much of the difference from alpha/(2pi) is of alpha^2 size?
    # Not a QED calculation; just scale accounting.
    budget_rows = []
    for ref in references:
        delta = ref["a_reference"] - base
        budget_rows.append({
            "particle": ref["particle"],
            "a_reference": ref["a_reference"],
            "alpha_over_2pi": base,
            "delta_reference_minus_base": delta,
            "delta_over_alpha_squared": delta/(alpha*alpha),
            "delta_over_alpha_squared_over_pi": delta/(alpha*alpha/np.pi),
            "delta_over_base": delta/base,
            "interpretation": "difference from one-loop scale is naturally higher-order-sized; sign/size not derived",
        })
    budget = pd.DataFrame(budget_rows)
    budget_path = outdir / "v11_9i_higher_order_budget.csv"
    budget.to_csv(budget_path, index=False)

    # Verdict
    # Any normalized kernel with bilinear invariant gives C=1 exactly to integration precision.
    bilinear = pred[pred["vertex"] == "bilinear_invariant"]
    bilinear_max_err = float(np.max(np.abs(bilinear["C_lag"] - 1.0)))
    raw_guard = pred[pred["vertex"] == "raw_alpha_like_no_loop_average_guardrail"]
    raw_C_mean = float(raw_guard["C_lag"].mean())
    small_guard = pred[pred["vertex"] == "alpha_squared_like_suppression_guardrail"]
    small_C_mean = float(small_guard["C_lag"].mean())
    best_err = float(best["abs_error_to_electron_C_required"])
    best_eps = float(best["eps"])
    best_tau = float(best["tau"])

    verdict = pd.DataFrame([
        {
            "gate": "normalized_bilinear_overlap_gives_C1",
            "status": "PASS_MECHANISM_SCALE" if bilinear_max_err < 1e-12 else "CHECK",
            "meaning": "any normalized Compton-lag kernel gives C_lag=1 for spinor-bilinear invariant vertex",
            "value": bilinear_max_err,
        },
        {
            "gate": "electron_required_C_near_1",
            "status": "PASS_SCALE_NEIGHBORHOOD" if abs(e_C_req-1.0) < 0.01 else "CHECK",
            "meaning": "electron anomaly reference requires only a per-mille correction to C=1",
            "value": e_C_req,
        },
        {
            "gate": "retarded_small_correction_can_match_C",
            "status": "CONDITIONAL_PASS" if best_err < 5e-5 and abs(best_eps) < 0.05 else "CHECK",
            "meaning": "a mild retarded phase-sensitive correction can match required C, but this is not a derivation",
            "value": best_err,
        },
        {
            "gate": "raw_alpha_guardrail",
            "status": "PASS_GUARDRAIL" if abs(raw_C_mean - 2*np.pi) < 1e-12 else "CHECK",
            "meaning": "without loop averaging the correction would be raw alpha, too large",
            "value": raw_C_mean,
        },
        {
            "gate": "alpha_squared_only_guardrail",
            "status": "PASS_GUARDRAIL" if abs(small_C_mean - alpha) < 1e-12 else "CHECK",
            "meaning": "alpha-suppressed vertex alone is too small for leading anomaly",
            "value": small_C_mean,
        },
        {
            "gate": "claim_level",
            "status": "OVERLAP_MECHANISM_SCALE_PASS_NOT_QED_DERIVATION",
            "meaning": "Compton-lag overlap naturally gives the alpha/(2pi) scale; the measured anomaly remains underived",
            "value": np.nan,
        },
    ])
    verdict_path = outdir / "v11_9i_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # Plots
    plt.figure(figsize=(11, 6.2))
    for kname, K, _ in kernels[:8]:
        plt.plot(phi, K, label=kname)
    plt.xlabel("Compton phase offset phi")
    plt.ylabel("normalized kernel K(phi)")
    plt.title("V11.9I Compton-lag overlap kernel shapes")
    plt.legend(fontsize=7)
    plt.tight_layout()
    p_kernels = outdir / "v11_9i_kernel_shapes.png"
    plt.savefig(p_kernels, dpi=args.dpi)
    plt.close()

    # Bar plot selected overlap coefficients for a representative subset
    selected = pred[
        pred["kernel"].isin(["uniform_one_cycle", "retarded_exponential_tau_0.75", "symmetric_wrapped_gaussian_width_0.75"])
        & pred["vertex"].isin(["bilinear_invariant", "mild_cos_phase_sensitive_eps_0p05",
                               "two_pole_amplitude_vertex_eps_0p10",
                               "raw_alpha_like_no_loop_average_guardrail",
                               "alpha_squared_like_suppression_guardrail"])
    ].copy()
    selected["label"] = selected["kernel"] + "\n" + selected["vertex"]
    plt.figure(figsize=(12, 6.5))
    plt.bar(np.arange(len(selected)), selected["C_lag"])
    plt.axhline(1.0, linestyle=":", label="C=1")
    plt.axhline(e_C_req, linestyle="--", label="electron C required")
    plt.yscale("log")
    plt.xticks(np.arange(len(selected)), selected["label"], rotation=45, ha="right", fontsize=7)
    plt.ylabel("C_lag")
    plt.title("V11.9I overlap coefficients")
    plt.legend()
    plt.tight_layout()
    p_overlap = outdir / "v11_9i_overlap_coefficients.png"
    plt.savefig(p_overlap, dpi=args.dpi)
    plt.close()

    # Retarded scan heatmap
    pivot = scan.pivot(index="eps", columns="tau", values="abs_error_to_electron_C_required")
    plt.figure(figsize=(9, 6.4))
    im = plt.imshow(np.log10(pivot.values + 1e-12), aspect="auto", origin="lower",
                    extent=[np.log10(taus.min()), np.log10(taus.max()), eps_vals.min(), eps_vals.max()])
    plt.colorbar(im, label="log10 abs error to electron C")
    plt.scatter([np.log10(best_tau)], [best_eps], marker="x", s=80, label="best")
    plt.xlabel("log10 tau")
    plt.ylabel("epsilon")
    plt.title("V11.9I retarded kernel correction scan")
    plt.legend()
    plt.tight_layout()
    p_scan = outdir / "v11_9i_retarded_scan_heatmap.png"
    plt.savefig(p_scan, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.8, 5.8))
    plt.bar(budget["particle"], np.abs(budget["delta_over_alpha_squared"]))
    plt.ylabel("|delta from alpha/(2pi)| / alpha^2")
    plt.title("V11.9I higher-order-sized residual budget")
    plt.tight_layout()
    p_budget = outdir / "v11_9i_higher_order_budget.png"
    plt.savefig(p_budget, dpi=args.dpi)
    plt.close()

    report = "# V11.9I Vertex Dressing / Compton-Lag Overlap Toy\n\n"
    report += "This is a mechanism-finder and scale audit, not a QED derivation.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Key result\n\nA normalized spinor-bilinear Compton-lag overlap naturally gives C_lag=1 in a = [alpha/(2pi)] C_lag. The electron reference requires only a per-mille correction from C=1. Mild retarded phase-sensitive corrections can match that coefficient, but this is not a derivation.\n\n"
    report += "## Guardrail\n\nThe anomalous magnetic moment remains a precision QED observable unless SFT reproduces the full vertex form factor structure or predicts a residual below experimental bounds.\n"
    report_path = outdir / "v11_9i_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9I complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nRequired coefficients:")
    print(req.to_string(index=False))
    print("\nBest retarded scan match:")
    print(pd.DataFrame([best]).to_string(index=False))
    print("\nHigher-order budget:")
    print(budget.to_string(index=False))
    print("\nSaved files:")
    for p in [kernel_path, pred_path, req_path, scan_path, budget_path, verdict_path, report_path,
              p_kernels, p_overlap, p_scan, p_budget]:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
