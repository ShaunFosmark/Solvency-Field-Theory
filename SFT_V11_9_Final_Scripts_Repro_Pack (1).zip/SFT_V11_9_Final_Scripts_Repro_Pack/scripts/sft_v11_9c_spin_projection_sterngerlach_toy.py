#!/usr/bin/env python3
"""
SFT V11.9C — Spin Projection / Stern-Gerlach Geometry Toy

Purpose
-------
V11.9A/B established 2pi vs 4pi closure, SU(2) spinor structure, and
handedness as unwrapped phase slope. V11.9C tests whether that same
representation supports the standard spin projection geometry.

Core gate:
    For a spin-up state along axis n measured along axis m,

        P(+_m | +_n) = cos^2(gamma/2) = (1 + n·m)/2
        P(-_m | +_n) = sin^2(gamma/2) = (1 - n·m)/2

where gamma is the angle between n and m.

SFT translation:
    spin-up/down are opposite projections of internal spinor holonomy
    relative to a chosen measurement axis.

Guardrail:
    This is a representation/projection test, not a derivation of the Born rule.

Outputs
-------
CSV:
    v11_9c_projection_probabilities.csv
    v11_9c_axis_sweep.csv
    v11_9c_sequential_measurements.csv
    v11_9c_noncommutativity.csv
    v11_9c_verdict.csv

Plots:
    v11_9c_cos2_projection_curve.png
    v11_9c_bloch_axis_projection.png
    v11_9c_sequential_measurement_tree.png
    v11_9c_noncommutativity.png

Run:
    python sft_v11_9c_spin_projection_sterngerlach_toy.py
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", type=str, default="sft_v11_9c_spin_projection_output")
    p.add_argument("--N", type=int, default=361, help="angle sweep samples")
    p.add_argument("--dpi", type=int, default=170)
    return p.parse_args()


# Pauli matrices
sx = np.array([[0, 1], [1, 0]], dtype=complex)
sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
sz = np.array([[1, 0], [0, -1]], dtype=complex)


def normalize(v):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    if n == 0:
        raise ValueError("zero vector")
    return v/n


def spinor_plus(axis):
    """
    Spin-up eigenstate along unit vector axis.
    """
    n = normalize(axis)
    theta = np.arccos(np.clip(n[2], -1, 1))
    phi = np.arctan2(n[1], n[0])
    return np.array([
        np.cos(theta/2),
        np.exp(1j*phi)*np.sin(theta/2)
    ], dtype=complex)


def spinor_minus(axis):
    return spinor_plus(-normalize(axis))


def density(psi):
    psi = psi / np.linalg.norm(psi)
    return np.outer(psi, np.conj(psi))


def bloch(psi):
    rho = density(psi)
    return np.array([
        float(np.real(np.trace(rho @ sx))),
        float(np.real(np.trace(rho @ sy))),
        float(np.real(np.trace(rho @ sz))),
    ])


def prob_plus(psi, axis):
    ket = spinor_plus(axis)
    psi = psi/np.linalg.norm(psi)
    return float(abs(np.vdot(ket, psi))**2)


def prob_minus(psi, axis):
    ket = spinor_minus(axis)
    psi = psi/np.linalg.norm(psi)
    return float(abs(np.vdot(ket, psi))**2)


def angle_between(a, b):
    a = normalize(a); b = normalize(b)
    return float(np.arccos(np.clip(np.dot(a,b), -1, 1)))


def projector_plus(axis):
    k = spinor_plus(axis)
    return np.outer(k, np.conj(k))


def projector_minus(axis):
    k = spinor_minus(axis)
    return np.outer(k, np.conj(k))


def commutator_norm(axis_a, axis_b):
    Pa = projector_plus(axis_a)
    Pb = projector_plus(axis_b)
    C = Pa@Pb - Pb@Pa
    return float(np.linalg.norm(C))


def sequential_path_probability(initial_axis, measurements):
    """
    measurements: list of (axis, outcome) where outcome is +1 or -1.
    Projectively update state after each measurement.

    Initial state is spin-up along initial_axis.
    """
    psi = spinor_plus(initial_axis)
    prob = 1.0
    path_rows = []
    for step, (axis, outcome) in enumerate(measurements, start=1):
        if outcome == +1:
            p = prob_plus(psi, axis)
            psi = spinor_plus(axis)
        elif outcome == -1:
            p = prob_minus(psi, axis)
            psi = spinor_minus(axis)
        else:
            raise ValueError("outcome must be +1 or -1")
        prob *= p
        path_rows.append({
            "step": step,
            "outcome": outcome,
            "conditional_probability": p,
            "cumulative_probability": prob,
            "post_bloch_x": bloch(psi)[0],
            "post_bloch_y": bloch(psi)[1],
            "post_bloch_z": bloch(psi)[2],
        })
    return prob, path_rows


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    axes = {
        "z": np.array([0,0,1.0]),
        "minus_z": np.array([0,0,-1.0]),
        "x": np.array([1.0,0,0]),
        "minus_x": np.array([-1.0,0,0]),
        "y": np.array([0,1.0,0]),
        "diag": normalize([1,1,1]),
    }

    # ------------------------------------------------------------
    # Gate 1: direct projection probability matrix
    # ------------------------------------------------------------
    rows = []
    for sname, saxis in axes.items():
        psi = spinor_plus(saxis)
        n_bloch = bloch(psi)
        for mname, maxis in axes.items():
            gamma = angle_between(saxis, maxis)
            p_p = prob_plus(psi, maxis)
            p_m = prob_minus(psi, maxis)
            expected_p = 0.5*(1 + np.dot(normalize(saxis), normalize(maxis)))
            expected_m = 1 - expected_p
            rows.append({
                "state_plus_axis": sname,
                "measurement_axis": mname,
                "angle_gamma_rad": gamma,
                "angle_gamma_deg": np.degrees(gamma),
                "p_plus": p_p,
                "p_minus": p_m,
                "expected_p_plus": expected_p,
                "expected_p_minus": expected_m,
                "abs_error_p_plus": abs(p_p - expected_p),
                "abs_error_p_minus": abs(p_m - expected_m),
                "normalization_error": abs((p_p+p_m)-1.0),
                "state_bloch_x": n_bloch[0],
                "state_bloch_y": n_bloch[1],
                "state_bloch_z": n_bloch[2],
            })
    proj = pd.DataFrame(rows)
    proj_path = outdir / "v11_9c_projection_probabilities.csv"
    proj.to_csv(proj_path, index=False)

    # ------------------------------------------------------------
    # Gate 2: continuous angle sweep z-state measured in xz plane
    # ------------------------------------------------------------
    sweep_rows = []
    angles = np.linspace(0, np.pi, args.N)
    psi_z = spinor_plus(axes["z"])
    for gamma in angles:
        m = np.array([np.sin(gamma), 0, np.cos(gamma)])
        p = prob_plus(psi_z, m)
        exp_p = np.cos(gamma/2)**2
        sweep_rows.append({
            "gamma_rad": gamma,
            "gamma_deg": np.degrees(gamma),
            "p_plus": p,
            "expected_cos2_half_angle": exp_p,
            "abs_error": abs(p-exp_p),
        })
    sweep = pd.DataFrame(sweep_rows)
    sweep_path = outdir / "v11_9c_axis_sweep.csv"
    sweep.to_csv(sweep_path, index=False)

    # ------------------------------------------------------------
    # Gate 3: sequential Stern-Gerlach style measurements
    # ------------------------------------------------------------
    seq_specs = [
        ("z_then_z_plus", axes["z"], [(axes["z"], +1)]),
        ("z_then_x_plus", axes["z"], [(axes["x"], +1)]),
        ("z_then_x_plus_then_z_plus", axes["z"], [(axes["x"], +1), (axes["z"], +1)]),
        ("z_then_x_plus_then_z_minus", axes["z"], [(axes["x"], +1), (axes["z"], -1)]),
        ("z_then_x_minus_then_z_plus", axes["z"], [(axes["x"], -1), (axes["z"], +1)]),
        ("z_then_diag_plus_then_z_plus", axes["z"], [(axes["diag"], +1), (axes["z"], +1)]),
    ]
    seq_rows = []
    for name, initial, meas in seq_specs:
        p, steps = sequential_path_probability(initial, meas)
        for r in steps:
            r2 = dict(r)
            r2.update({
                "sequence": name,
                "final_probability": p,
                "n_steps": len(meas),
            })
            seq_rows.append(r2)
    seq = pd.DataFrame(seq_rows)
    seq_path = outdir / "v11_9c_sequential_measurements.csv"
    seq.to_csv(seq_path, index=False)

    # ------------------------------------------------------------
    # Gate 4: noncommutativity of projectors
    # ------------------------------------------------------------
    non_rows = []
    axis_names = list(axes.keys())
    for a in axis_names:
        for b in axis_names:
            normC = commutator_norm(axes[a], axes[b])
            gamma = angle_between(axes[a], axes[b])
            # For rank-1 spin-1/2 projectors, commutator norm tracks sin(gamma)/sqrt(2)
            expected_scale = abs(np.sin(gamma))/np.sqrt(2)
            non_rows.append({
                "axis_a": a,
                "axis_b": b,
                "angle_gamma_deg": np.degrees(gamma),
                "commutator_norm": normC,
                "expected_sin_gamma_over_sqrt2": expected_scale,
                "abs_error": abs(normC - expected_scale),
            })
    noncom = pd.DataFrame(non_rows)
    non_path = outdir / "v11_9c_noncommutativity.csv"
    noncom.to_csv(non_path, index=False)

    # ------------------------------------------------------------
    # Verdict
    # ------------------------------------------------------------
    max_proj_err = max(proj["abs_error_p_plus"].max(), proj["abs_error_p_minus"].max())
    max_sweep_err = sweep["abs_error"].max()
    max_norm_err = proj["normalization_error"].max()
    max_non_err = noncom["abs_error"].max()

    # Specific sequential checks
    p_zx_zplus = seq[(seq["sequence"] == "z_then_x_plus_then_z_plus") & (seq["step"] == 2)]["cumulative_probability"].iloc[0]
    p_zx_zminus = seq[(seq["sequence"] == "z_then_x_plus_then_z_minus") & (seq["step"] == 2)]["cumulative_probability"].iloc[0]
    seq_ok = abs(p_zx_zplus - 0.25) < 1e-12 and abs(p_zx_zminus - 0.25) < 1e-12

    verdict = pd.DataFrame([
        {
            "gate": "projection_cos2_half_angle",
            "status": "PASS" if max_proj_err < 1e-12 and max_sweep_err < 1e-12 else "CHECK",
            "meaning": "P(+_m|+_n)=cos^2(gamma/2)=(1+n dot m)/2",
            "max_error": max(max_proj_err, max_sweep_err),
        },
        {
            "gate": "probability_normalization",
            "status": "PASS" if max_norm_err < 1e-12 else "CHECK",
            "meaning": "P(+)+P(-)=1 for every measurement axis",
            "max_error": max_norm_err,
        },
        {
            "gate": "sequential_measurement_reset",
            "status": "PASS" if seq_ok else "CHECK",
            "meaning": "z -> x -> z branches give 1/4 path probabilities after state reset",
            "max_error": max(abs(p_zx_zplus-0.25), abs(p_zx_zminus-0.25)),
        },
        {
            "gate": "projector_noncommutativity",
            "status": "PASS" if max_non_err < 1e-12 else "CHECK",
            "meaning": "different spin-axis projectors generally do not commute",
            "max_error": max_non_err,
        },
    ])
    verdict_path = outdir / "v11_9c_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # ------------------------------------------------------------
    # Plots
    # ------------------------------------------------------------
    plt.figure(figsize=(8.8,5.8))
    plt.plot(sweep["gamma_deg"], sweep["p_plus"], label="spinor projection")
    plt.plot(sweep["gamma_deg"], sweep["expected_cos2_half_angle"], linestyle="--", label="cos^2(gamma/2)")
    plt.xlabel("axis angle gamma [deg]")
    plt.ylabel("P(+)")
    plt.title("V11.9C spin projection probability")
    plt.legend()
    plt.tight_layout()
    p_curve = outdir / "v11_9c_cos2_projection_curve.png"
    plt.savefig(p_curve, dpi=args.dpi)
    plt.close()

    # Bloch axis projection bar selected
    sel = proj[(proj["state_plus_axis"]=="z") & (proj["measurement_axis"].isin(["z","x","minus_z","diag"]))].copy()
    plt.figure(figsize=(8.8,5.8))
    xpos = np.arange(len(sel))
    plt.bar(xpos-0.2, sel["p_plus"], width=0.4, label="P(+)")
    plt.bar(xpos+0.2, sel["p_minus"], width=0.4, label="P(-)")
    plt.xticks(xpos, sel["measurement_axis"])
    plt.ylabel("probability")
    plt.title("V11.9C spin-up z measured along different axes")
    plt.legend()
    plt.tight_layout()
    p_bloch = outdir / "v11_9c_bloch_axis_projection.png"
    plt.savefig(p_bloch, dpi=args.dpi)
    plt.close()

    # Sequential measurement tree-like bar
    seq_final = seq.groupby("sequence").tail(1).copy()
    plt.figure(figsize=(10,5.8))
    plt.bar(seq_final["sequence"], seq_final["cumulative_probability"])
    plt.xticks(rotation=35, ha="right")
    plt.ylabel("path probability")
    plt.title("V11.9C sequential Stern-Gerlach path probabilities")
    plt.tight_layout()
    p_seq = outdir / "v11_9c_sequential_measurement_tree.png"
    plt.savefig(p_seq, dpi=args.dpi)
    plt.close()

    # Noncommutativity heatmap
    pivot = noncom.pivot(index="axis_a", columns="axis_b", values="commutator_norm").loc[axis_names, axis_names]
    plt.figure(figsize=(7.4,6.4))
    im = plt.imshow(pivot.values, origin="lower")
    plt.colorbar(im, label="||[P_a, P_b]||")
    plt.xticks(np.arange(len(axis_names)), axis_names, rotation=45, ha="right")
    plt.yticks(np.arange(len(axis_names)), axis_names)
    plt.title("V11.9C spin-axis projector noncommutativity")
    plt.tight_layout()
    p_non = outdir / "v11_9c_noncommutativity.png"
    plt.savefig(p_non, dpi=args.dpi)
    plt.close()

    report = "# V11.9C Spin Projection / Stern-Gerlach Geometry Toy\n\n"
    report += "This is a representation/projection test, not a derivation of the Born rule.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Earned statement\n\nThe SU(2) spinor-holonomy representation supports the standard Stern-Gerlach projection geometry: spin-up/down are projections of internal holonomy relative to a chosen measurement axis, with P(+)=cos^2(gamma/2).\n\n"
    report += "## Guardrail\n\nThis does not derive measurement collapse, Born probabilities, electron spin, spin-statistics, Pauli exclusion, or magnetic moment.\n"
    report_path = outdir / "v11_9c_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9C complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nSelected projection table:")
    print(sel[["state_plus_axis","measurement_axis","angle_gamma_deg","p_plus","p_minus","expected_p_plus","abs_error_p_plus"]].to_string(index=False))
    print("\nSaved files:")
    for p in [proj_path, sweep_path, seq_path, non_path, verdict_path, report_path, p_curve, p_bloch, p_seq, p_non]:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
