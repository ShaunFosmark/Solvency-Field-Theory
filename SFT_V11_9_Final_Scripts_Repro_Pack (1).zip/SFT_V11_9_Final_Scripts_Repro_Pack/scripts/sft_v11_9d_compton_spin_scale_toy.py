#!/usr/bin/env python3
"""
SFT V11.9D — Compton Spin-Scale Toy

Purpose
-------
V11.9A/B/C established:
  A: 2pi vs 4pi closure topology
  B: SU(2) spinor closure, handedness, measurement sign guardrail
  C: Stern-Gerlach projection geometry

V11.9D asks the next physical-scale question:

    Can c-speed Compton/lag-field circulation plus 4pi spinor closure
    naturally land on the spin scale hbar/2?

Toy model
---------
Compton angular frequency:

    omega_C = m c^2 / hbar

Let the internal circulation angular rate be:

    omega_int = kappa * omega_C

If the internal circulation is c-speed:

    r = c / omega_int = hbar / (kappa m c)

The mechanical angular-momentum scale is:

    L = m c r = hbar / kappa

Therefore:

    kappa = 1 -> L = hbar
    kappa = 2 -> L = hbar/2

Spinor closure time:
    A spinor requires 4pi angular advance to return to itself:

        T_spinor_4pi = 4pi / omega_int

The Compton period is:

        T_C = 2pi / omega_C

So:

        T_spinor_4pi / T_C = 2 / kappa

Thus kappa=2 also makes spinor 4pi closure occur in one Compton period.

This is a scale-alignment toy, not a derivation of spin, g=2, or magnetic moment.

Outputs
-------
CSV:
    v11_9d_particle_scale_summary.csv
    v11_9d_kappa_sweep.csv
    v11_9d_magnetic_moment_guardrail.csv
    v11_9d_verdict.csv

Plots:
    v11_9d_spin_scale_vs_kappa.png
    v11_9d_closure_time_vs_kappa.png
    v11_9d_radius_vs_mass.png
    v11_9d_magnetic_moment_guardrail.png

Run:
    python sft_v11_9d_compton_spin_scale_toy.py
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", type=str, default="sft_v11_9d_compton_spin_scale_output")
    p.add_argument("--dpi", type=int, default=170)
    p.add_argument("--N", type=int, default=600, help="kappa sweep samples")
    return p.parse_args()


# Exact SI constants where exact by definition.
c = 299_792_458.0
h = 6.62607015e-34
hbar = h / (2*np.pi)
e_charge = 1.602176634e-19

# Approximate rest masses in kg.
particles = [
    {"particle": "electron", "mass_kg": 9.1093837015e-31, "charge_C": -e_charge, "elementary_status": "elementary_lepton"},
    {"particle": "muon", "mass_kg": 1.883531627e-28, "charge_C": -e_charge, "elementary_status": "elementary_lepton"},
    {"particle": "tau", "mass_kg": 3.16754e-27, "charge_C": -e_charge, "elementary_status": "elementary_lepton"},
]


def scales(m, kappa):
    omega_C = m*c*c/hbar
    T_C = 2*np.pi/omega_C
    omega_int = kappa*omega_C
    r = c/omega_int
    L = m*c*r
    T_2pi_simple = 2*np.pi/omega_int
    T_4pi_spinor = 4*np.pi/omega_int
    return {
        "omega_C_rad_s": omega_C,
        "T_C_s": T_C,
        "omega_int_rad_s": omega_int,
        "r_cspeed_m": r,
        "reduced_compton_radius_m": hbar/(m*c),
        "L_SI_J_s": L,
        "L_over_hbar": L/hbar,
        "T_2pi_simple_s": T_2pi_simple,
        "T_4pi_spinor_s": T_4pi_spinor,
        "T_2pi_simple_over_T_C": T_2pi_simple/T_C,
        "T_4pi_spinor_over_T_C": T_4pi_spinor/T_C,
    }


def naive_ring_magnetic_moment(m, q, kappa):
    """
    Classical ring-current guardrail.

    For a charge q moving at speed c in a circle of radius r:
        mu = q c r / 2
        L  = m c r
        g_naive = 2m mu / (q L) = 1

    This is expected to FAIL the electron g≈2 gate and is logged as an open guardrail.
    """
    s = scales(m, kappa)
    r = s["r_cspeed_m"]
    L = s["L_SI_J_s"]
    mu = q*c*r/2
    g_naive = (2*m*mu)/(q*L) if q != 0 and L != 0 else np.nan
    mu_dirac_spinhalf = q*hbar/(2*m)  # g=2 with S=hbar/2 gives q hbar/(2m)
    mu_ratio_to_dirac_spinhalf = mu/mu_dirac_spinhalf if mu_dirac_spinhalf != 0 else np.nan
    return {
        "mu_naive_A_m2": mu,
        "g_naive_ring": g_naive,
        "mu_dirac_spinhalf_A_m2": mu_dirac_spinhalf,
        "mu_ratio_to_dirac_spinhalf": mu_ratio_to_dirac_spinhalf,
    }


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------
    # Particle scale summary for key kappa values
    # ------------------------------------------------------------
    key_kappas = [
        (1.0, "Compton angular rate: L=hbar"),
        (2.0, "spinor-aligned / zitter-like rate: L=hbar/2"),
    ]

    rows = []
    mag_rows = []
    for p in particles:
        for kappa, label in key_kappas:
            s = scales(p["mass_kg"], kappa)
            mrow = naive_ring_magnetic_moment(p["mass_kg"], p["charge_C"], kappa)
            rows.append({
                **p,
                "kappa": kappa,
                "case_label": label,
                **s,
            })
            mag_rows.append({
                "particle": p["particle"],
                "mass_kg": p["mass_kg"],
                "charge_C": p["charge_C"],
                "kappa": kappa,
                "case_label": label,
                **mrow,
                "guardrail_interpretation": "naive ring gives g=1; electron g≈2 remains open",
            })

    summary = pd.DataFrame(rows)
    summary_path = outdir / "v11_9d_particle_scale_summary.csv"
    summary.to_csv(summary_path, index=False)

    magnetic = pd.DataFrame(mag_rows)
    mag_path = outdir / "v11_9d_magnetic_moment_guardrail.csv"
    magnetic.to_csv(mag_path, index=False)

    # ------------------------------------------------------------
    # Kappa sweep, mass-independent dimensionless ratios
    # ------------------------------------------------------------
    kappas = np.logspace(np.log10(0.25), np.log10(8.0), args.N)
    sweep_rows = []
    for kappa in kappas:
        sweep_rows.append({
            "kappa": kappa,
            "L_over_hbar": 1.0/kappa,
            "T_simple_2pi_over_T_C": 1.0/kappa,
            "T_spinor_4pi_over_T_C": 2.0/kappa,
            "r_over_reduced_compton": 1.0/kappa,
            "naive_ring_g": 1.0,
            "naive_mu_over_dirac_spinhalf": 1.0/kappa,
        })
    sweep = pd.DataFrame(sweep_rows)
    sweep_path = outdir / "v11_9d_kappa_sweep.csv"
    sweep.to_csv(sweep_path, index=False)

    # ------------------------------------------------------------
    # Verdict gates
    # ------------------------------------------------------------
    k2 = summary[summary["kappa"] == 2.0]
    k1 = summary[summary["kappa"] == 1.0]

    mass_independence_error_k2 = float(np.max(np.abs(k2["L_over_hbar"] - 0.5)))
    closure_alignment_error_k2 = float(np.max(np.abs(k2["T_4pi_spinor_over_T_C"] - 1.0)))
    k1_hbar_error = float(np.max(np.abs(k1["L_over_hbar"] - 1.0)))
    radius_half_error_k2 = float(np.max(np.abs(k2["r_cspeed_m"]/k2["reduced_compton_radius_m"] - 0.5)))
    naive_g_error_from_2 = float(np.max(np.abs(magnetic[magnetic["kappa"] == 2.0]["g_naive_ring"] - 2.0)))

    verdict = pd.DataFrame([
        {
            "gate": "Compton_rate_gives_hbar_scale",
            "status": "PASS" if k1_hbar_error < 1e-14 else "CHECK",
            "meaning": "kappa=1 gives L/hbar=1 for c-speed circulation at reduced Compton radius",
            "error": k1_hbar_error,
        },
        {
            "gate": "spinor_aligned_rate_gives_hbar_over_2",
            "status": "PASS" if mass_independence_error_k2 < 1e-14 else "CHECK",
            "meaning": "kappa=2 gives L/hbar=1/2 independent of particle mass",
            "error": mass_independence_error_k2,
        },
        {
            "gate": "spinor_4pi_closure_matches_Compton_period",
            "status": "PASS" if closure_alignment_error_k2 < 1e-14 else "CHECK",
            "meaning": "kappa=2 makes 4pi spinor closure time equal one Compton period",
            "error": closure_alignment_error_k2,
        },
        {
            "gate": "spinor_radius_half_reduced_Compton",
            "status": "PASS" if radius_half_error_k2 < 1e-14 else "CHECK",
            "meaning": "kappa=2 gives r = hbar/(2mc)",
            "error": radius_half_error_k2,
        },
        {
            "gate": "magnetic_moment_guardrail",
            "status": "OPEN_NOT_DERIVED",
            "meaning": "naive charged ring gives g=1, not electron g≈2; magnetic moment remains open",
            "error": naive_g_error_from_2,
        },
    ])
    verdict_path = outdir / "v11_9d_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    # ------------------------------------------------------------
    # Plots
    # ------------------------------------------------------------
    plt.figure(figsize=(8.8,5.8))
    plt.plot(sweep["kappa"], sweep["L_over_hbar"], label="L/hbar = 1/kappa")
    plt.axhline(1.0, linestyle="--", label="hbar")
    plt.axhline(0.5, linestyle=":", label="hbar/2")
    plt.axvline(1.0, linestyle="--", label="kappa=1")
    plt.axvline(2.0, linestyle=":", label="kappa=2")
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("kappa = omega_int / omega_C")
    plt.ylabel("L / hbar")
    plt.title("V11.9D c-speed Compton circulation angular-momentum scale")
    plt.legend()
    plt.tight_layout()
    p_spin = outdir / "v11_9d_spin_scale_vs_kappa.png"
    plt.savefig(p_spin, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.8,5.8))
    plt.plot(sweep["kappa"], sweep["T_simple_2pi_over_T_C"], label="simple 2pi closure / T_C")
    plt.plot(sweep["kappa"], sweep["T_spinor_4pi_over_T_C"], label="spinor 4pi closure / T_C")
    plt.axhline(1.0, linestyle="--", label="one Compton period")
    plt.axvline(2.0, linestyle=":", label="kappa=2")
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("kappa = omega_int / omega_C")
    plt.ylabel("closure time / T_C")
    plt.title("V11.9D spinor 4pi closure aligns with Compton period at kappa=2")
    plt.legend()
    plt.tight_layout()
    p_closure = outdir / "v11_9d_closure_time_vs_kappa.png"
    plt.savefig(p_closure, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.8,5.8))
    for kappa, label in key_kappas:
        sub = summary[summary["kappa"] == kappa]
        plt.scatter(sub["mass_kg"], sub["r_cspeed_m"], label=f"kappa={kappa}: {label}")
        for _, r in sub.iterrows():
            plt.annotate(r["particle"], (r["mass_kg"], r["r_cspeed_m"]), fontsize=8, xytext=(4,4), textcoords="offset points")
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("mass [kg]")
    plt.ylabel("c-speed circulation radius [m]")
    plt.title("V11.9D radius scales inversely with mass")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_radius = outdir / "v11_9d_radius_vs_mass.png"
    plt.savefig(p_radius, dpi=args.dpi)
    plt.close()

    plt.figure(figsize=(8.8,5.8))
    plt.plot(sweep["kappa"], sweep["naive_ring_g"], label="naive charged ring g")
    plt.axhline(2.0, linestyle="--", label="electron leading g≈2 target")
    plt.xscale("log")
    plt.xlabel("kappa")
    plt.ylabel("g")
    plt.title("V11.9D magnetic moment guardrail: naive ring gives g=1")
    plt.legend()
    plt.tight_layout()
    p_g = outdir / "v11_9d_magnetic_moment_guardrail.png"
    plt.savefig(p_g, dpi=args.dpi)
    plt.close()

    report = "# V11.9D Compton Spin-Scale Toy\n\n"
    report += "This is a scale-alignment toy, not a derivation of electron spin or g=2.\n\n"
    report += "## Verdict\n\n" + verdict.to_markdown(index=False) + "\n\n"
    report += "## Key result\n\nFor c-speed internal circulation with omega_int = kappa omega_C, L/hbar = 1/kappa. Therefore kappa=2 gives L=hbar/2 and simultaneously makes the 4pi spinor closure time equal one Compton period.\n\n"
    report += "## Guardrail\n\nA naive charged ring gives g=1, not g=2. Magnetic moment remains an open gate.\n"
    report_path = outdir / "v11_9d_report.md"
    report_path.write_text(report, encoding="utf-8")

    print("V11.9D complete.")
    print("\nVerdict:")
    print(verdict.to_string(index=False))
    print("\nKey scale summary:")
    print(summary[["particle","kappa","case_label","r_cspeed_m","L_over_hbar","T_4pi_spinor_over_T_C"]].to_string(index=False))
    print("\nMagnetic guardrail:")
    print(magnetic[["particle","kappa","g_naive_ring","mu_ratio_to_dirac_spinhalf","guardrail_interpretation"]].to_string(index=False))
    print("\nSaved files:")
    for p in [summary_path, sweep_path, mag_path, verdict_path, report_path, p_spin, p_closure, p_radius, p_g]:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
