# SFT V13.5 Repro Scripts Only

Generated: 2026-07-01 00:12:55

This zip contains only the scripts for the V13.5 entanglement/Bell-singlet repro chain.

Included scripts:
- `r267b_chsh_stress_test.py`
- `r267c_kernel_uniqueness_check.py`
- `r267d_tensor_projection_check.py`
- `r267e_born_race_check.py`
- `r267e2_microattempt_hazard_check.py`
- `run_all_v13_5_entanglement_scripts.py`
- `build_sft_13_5_entanglement_pdf.py`

No generated PDFs, markdown source, result CSVs, gate packs, or report outputs are included.
