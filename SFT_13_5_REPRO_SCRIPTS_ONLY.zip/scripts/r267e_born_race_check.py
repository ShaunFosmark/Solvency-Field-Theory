#!/usr/bin/env python3
"""R267E Born race check.

For competing exponential hazards lambda_i = Gamma * I_i,
the probability that channel i fires first is lambda_i / sum(lambda).
This script verifies the formula analytically and with a small Monte Carlo.
"""
from __future__ import annotations
import random, math

def analytic(intensities):
    s=sum(intensities)
    return [x/s for x in intensities]

def monte_carlo(intensities, trials=200000, seed=267):
    random.seed(seed)
    counts=[0]*len(intensities)
    for _ in range(trials):
        # exponential race: T_i = -ln(U)/lambda_i
        times=[-math.log(max(random.random(),1e-15))/lam for lam in intensities]
        k=min(range(len(times)), key=lambda i: times[i])
        counts[k]+=1
    return [c/trials for c in counts]

def main():
    tests=[
        [1,1],
        [1,3],
        [0.2,0.3,0.5],
        [0.01,0.09,0.9],
    ]
    print("intensities,analytic,monte_carlo")
    for xs in tests:
        print(xs, analytic(xs), monte_carlo(xs, trials=50000))
if __name__=="__main__":
    main()
