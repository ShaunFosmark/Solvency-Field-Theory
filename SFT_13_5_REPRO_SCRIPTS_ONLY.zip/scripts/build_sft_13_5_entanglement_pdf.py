#!/usr/bin/env python3
"""Build SFT_13_5_Entanglement.pdf from SFT_13_5_Entanglement.md.

Requires:
  pip install reportlab

Usage:
  python scripts/build_sft_13_5_entanglement_pdf.py --markdown SFT_13_5_Entanglement.md --output SFT_13_5_Entanglement.pdf

This script is intentionally minimal and portable. It builds a readable PDF
from the markdown source; exact pagination may vary by environment.
"""
from __future__ import annotations

import argparse
import re
import textwrap
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Preformatted

def wrap_token(s: str, width: int = 78) -> str:
    out = []
    for line in str(s).splitlines():
        if len(line) <= width:
            out.append(line)
        else:
            out.extend(textwrap.wrap(line, width=width, break_long_words=True, break_on_hyphens=False))
    return "\n".join(out)

def escape_xml(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--markdown", default="SFT_13_5_Entanglement.md")
    ap.add_argument("--output", default="SFT_13_5_Entanglement.pdf")
    args = ap.parse_args()

    md_path = Path(args.markdown)
    if not md_path.exists():
        raise SystemExit(f"missing markdown source: {md_path}")

    md = md_path.read_text(encoding="utf-8")

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TitleCenter", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=24, leading=29, alignment=TA_CENTER, spaceAfter=18))
    styles.add(ParagraphStyle(name="SubTitleCenter", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=16, leading=20, alignment=TA_CENTER, spaceAfter=16))
    styles.add(ParagraphStyle(name="SectionHeading", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=16, leading=20, spaceBefore=16, spaceAfter=10))
    styles.add(ParagraphStyle(name="SubHeading", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=12.5, leading=15, spaceBefore=10, spaceAfter=6))
    styles.add(ParagraphStyle(name="BodySFT", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.8, leading=13.2, spaceAfter=6))
    styles.add(ParagraphStyle(name="Verdict", parent=styles["BodyText"], fontName="Courier", fontSize=7.2, leading=8.8, leftIndent=8, rightIndent=8, backColor=colors.HexColor("#f3f3f3"), borderColor=colors.HexColor("#cccccc"), borderWidth=0.25, borderPadding=6, spaceBefore=4, spaceAfter=8))
    styles.add(ParagraphStyle(name="Quote", parent=styles["BodyText"], fontName="Helvetica-Oblique", fontSize=10, leading=13, leftIndent=16, rightIndent=16, textColor=colors.HexColor("#333333"), spaceBefore=6, spaceAfter=8))
    styles.add(ParagraphStyle(name="Equation", parent=styles["BodyText"], fontName="Courier", fontSize=8.6, leading=10.6, leftIndent=18, spaceBefore=3, spaceAfter=6))

    def para(text: str, style: str = "BodySFT"):
        return Paragraph(escape_xml(text), styles[style])

    def pre(text: str, style: str = "Equation"):
        return Preformatted(wrap_token(text, 78), styles[style], maxLineLength=78)

    story = []
    story.append(Spacer(1, 1.0 * inch))
    story.append(Paragraph("Solvency Field Theory V13.5", styles["TitleCenter"]))
    story.append(Paragraph("Entanglement, Bell Correlations,<br/>and Settlement-Write Measurement", styles["SubTitleCenter"]))
    story.append(PageBreak())

    lines = md.splitlines()
    buffer = []
    in_code = False
    code_lines = []

    def flush_buffer():
        nonlocal buffer
        if buffer:
            text = " ".join(x.strip() for x in buffer if x.strip())
            if text:
                story.append(para(text))
            buffer = []

    for raw in lines:
        stripped = raw.rstrip().strip()
        if stripped.startswith("```"):
            flush_buffer()
            if not in_code:
                in_code = True
                code_lines = []
            else:
                story.append(Paragraph(escape_xml(wrap_token("\n".join(code_lines), 78)).replace("\n", "<br/>"), styles["Verdict"]))
                in_code = False
            continue
        if in_code:
            code_lines.append(raw.rstrip())
            continue
        if not stripped:
            flush_buffer()
            continue
        if stripped.startswith("# "):
            flush_buffer()
            story.append(PageBreak())
            story.append(Paragraph(escape_xml(stripped[2:].strip()), styles["SectionHeading"]))
            continue
        if stripped.startswith("## "):
            flush_buffer()
            story.append(Paragraph(escape_xml(stripped[3:].strip()), styles["SubHeading"]))
            continue
        if stripped.startswith("### "):
            flush_buffer()
            story.append(Paragraph(escape_xml(stripped[4:].strip()), styles["SubHeading"]))
            continue
        if len(stripped) > 80 and "_" in stripped and stripped.count(" ") < 4:
            flush_buffer()
            story.append(pre(stripped, "Verdict"))
            continue
        if any(tok in stripped for tok in ["=", "->", "P(", "E(", "C_ij", "lambda_", "sum_", "|S|"]) and len(stripped) < 125:
            flush_buffer()
            story.append(pre(stripped.replace("\\", "")))
            continue
        buffer.append(stripped)
    flush_buffer()

    def on_page(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#555555"))
        canvas.drawString(0.72 * inch, 0.45 * inch, "SFT V13.5 Entanglement")
        canvas.drawRightString(7.78 * inch, 0.45 * inch, f"Page {doc.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(str(args.output), pagesize=LETTER, rightMargin=0.65*inch, leftMargin=0.65*inch, topMargin=0.65*inch, bottomMargin=0.72*inch)
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
    print(args.output)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
