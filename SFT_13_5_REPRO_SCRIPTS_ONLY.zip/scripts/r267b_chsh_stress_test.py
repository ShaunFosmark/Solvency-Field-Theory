#!/usr/bin/env python3
"""R267B CHSH/no-signaling stress test for the singlet target kernel."""
from __future__ import annotations
import math
from itertools import product
OUTCOMES = [-1, +1]

def prob(A: int, B: int, theta: float) -> float:
    return 0.25 * (1.0 - A * B * math.cos(theta))

def corr(theta: float) -> float:
    return sum(A * B * prob(A, B, theta) for A, B in product(OUTCOMES, OUTCOMES))

def marginals(theta: float):
    pA = {A: sum(prob(A, B, theta) for B in OUTCOMES) for A in OUTCOMES}
    pB = {B: sum(prob(A, B, theta) for A in OUTCOMES) for B in OUTCOMES}
    return pA, pB

def chsh(a: float, ap: float, b: float, bp: float) -> float:
    return corr(a-b) + corr(a-bp) + corr(ap-b) - corr(ap-bp)

def main() -> int:
    print("theta_deg,E(theta),target,no_signal_A,no_signal_B")
    for th in [0, math.pi/6, math.pi/4, math.pi/2, math.pi]:
        E = corr(th)
        target = -math.cos(th)
        pA, pB = marginals(th)
        noA = all(abs(v - 0.5) < 1e-12 for v in pA.values())
        noB = all(abs(v - 0.5) < 1e-12 for v in pB.values())
        print(f"{math.degrees(th):.6f},{E:.12f},{target:.12f},{noA},{noB}")
    a, ap, b, bp = 0.0, math.pi/2, math.pi/4, -math.pi/4
    S = chsh(a, ap, b, bp)
    print(f"\nCHSH S = {S:.12f}")
    print(f"|S| = {abs(S):.12f}")
    print(f"2*sqrt(2) = {2*math.sqrt(2):.12f}")
    print("local hidden-variable bound = 2.000000000000")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
