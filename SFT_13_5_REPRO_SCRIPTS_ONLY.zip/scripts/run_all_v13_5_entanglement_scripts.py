#!/usr/bin/env python3
"""Run the SFT V13.5 entanglement repro scripts.

This is a scripts-only repro bundle. It does not include generated PDFs,
gate reports, CSVs, or result archives. Running these scripts regenerates
the numerical checks for the V13.5 Bell/singlet/hazard chain.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

SCRIPTS = [
    "r267b_chsh_stress_test.py",
    "r267c_kernel_uniqueness_check.py",
    "r267d_tensor_projection_check.py",
    "r267e_born_race_check.py",
    "r267e2_microattempt_hazard_check.py",
]

def main() -> int:
    here = Path(__file__).resolve().parent
    rc_total = 0
    for name in SCRIPTS:
        path = here / name
        if not path.exists():
            print(f"[MISSING] {name}")
            rc_total = 1
            continue
        print(f"\n=== running {name} ===")
        rc = subprocess.call([sys.executable, str(path)])
        if rc != 0:
            print(f"[FAILED] {name} exit={rc}")
            rc_total = rc_total or rc
    return rc_total

if __name__ == "__main__":
    raise SystemExit(main())
