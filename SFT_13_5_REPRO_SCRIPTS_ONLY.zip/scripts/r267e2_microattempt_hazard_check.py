#!/usr/bin/env python3
"""R267E2 microattempt hazard check.

Demonstrates:
1. additive microattempt counts imply lambda proportional to intensity;
2. exponential race produces probabilities proportional to hazards;
3. nonlinear hazard rules violate additivity over split support.
"""
from __future__ import annotations
import random, math

def linear_hazards(intensities, gamma=1.0):
    return [gamma*x for x in intensities]

def race_probs(hazards):
    s=sum(hazards)
    return [h/s for h in hazards]

def mc_race(hazards, trials=50000, seed=2672):
    random.seed(seed)
    counts=[0]*len(hazards)
    for _ in range(trials):
        times=[-math.log(max(random.random(),1e-15))/h for h in hazards]
        k=min(range(len(times)), key=lambda i: times[i])
        counts[k]+=1
    return [c/trials for c in counts]

def split_additivity_demo():
    I_total=1.0
    split=[0.5,0.5]
    lin_total=I_total
    lin_split=sum(split)
    non_total=I_total**2
    non_split=sum(x**2 for x in split)
    return lin_total, lin_split, non_total, non_split

def main():
    tests=[[1,1],[1,3],[0.2,0.3,0.5],[0.01,0.09,0.9]]
    print("intensities,linear_hazards,analytic_probs,mc_probs")
    for xs in tests:
        h=linear_hazards(xs)
        print(xs, h, race_probs(h), mc_race(h, trials=30000))
    print()
    lt,ls,nt,ns=split_additivity_demo()
    print("split_additivity_demo")
    print(f"linear total={lt}, linear split sum={ls}")
    print(f"nonlinear p=2 total={nt}, nonlinear split sum={ns}")
if __name__=="__main__":
    main()
