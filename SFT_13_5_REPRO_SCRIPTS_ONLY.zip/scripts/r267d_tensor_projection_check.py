#!/usr/bin/env python3
"""R267D tensor projection check."""
from __future__ import annotations
import math
import random

def dot(a,b): return sum(x*y for x,y in zip(a,b))
def norm(v):
    n=math.sqrt(dot(v,v))
    return tuple(x/n for x in v)
def E(a,b):
    # C_ij = -delta_ij
    return -dot(a,b)

def random_unit():
    z=random.uniform(-1,1)
    t=random.uniform(0,2*math.pi)
    r=math.sqrt(1-z*z)
    return (r*math.cos(t), r*math.sin(t), z)

def main():
    print("case,dot,E,target")
    tests=[
        ((1,0,0),(1,0,0)),
        ((1,0,0),(0,1,0)),
        ((1,0,0),(-1,0,0)),
        (norm((1,1,0)), norm((1,-1,0))),
    ]
    for i,(a,b) in enumerate(tests):
        print(f"{i},{dot(a,b):.12f},{E(a,b):.12f},{-dot(a,b):.12f}")
    print("random_checks")
    for i in range(5):
        a,b=random_unit(),random_unit()
        print(f"{i},{dot(a,b):.12f},{E(a,b):.12f}")
if __name__ == "__main__":
    main()
