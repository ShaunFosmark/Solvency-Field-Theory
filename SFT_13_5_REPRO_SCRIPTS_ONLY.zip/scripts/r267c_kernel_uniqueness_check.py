#!/usr/bin/env python3
"""R267C kernel uniqueness/no-signaling/CHSH check."""
from __future__ import annotations
import math
from itertools import product
OUT = [-1, 1]

def P(A, B, dot):
    return 0.25 * (1 - A*B*dot)

def E(dot):
    return sum(A*B*P(A,B,dot) for A,B in product(OUT, OUT))

def check(dot):
    pA = {A: sum(P(A,B,dot) for B in OUT) for A in OUT}
    pB = {B: sum(P(A,B,dot) for A in OUT) for B in OUT}
    return E(dot), pA, pB

def chsh(a, ap, b, bp):
    def corr(x,y): return -math.cos(x-y)
    return corr(a,b)+corr(a,bp)+corr(ap,b)-corr(ap,bp)

def main():
    print("dot,E,target,pA(+),pA(-),pB(+),pB(-)")
    for dot in [-1,-0.5,0,0.5,1]:
        e,pA,pB = check(dot)
        print(f"{dot:.3f},{e:.12f},{-dot:.12f},{pA[1]:.12f},{pA[-1]:.12f},{pB[1]:.12f},{pB[-1]:.12f}")
    S = chsh(0, math.pi/2, math.pi/4, -math.pi/4)
    print(f"CHSH_abs={abs(S):.12f}")
    print(f"2sqrt2={2*math.sqrt(2):.12f}")
if __name__ == "__main__":
    main()
