"""Core, comparison-free SFT numerical-G calculation.

This module contains no measured G, electron gravitational correspondence,
hard-coded beta edge, or fitted optical normalization.  It derives the conditional c=1 prediction
from the frozen operator constants and the external inertial electron mass.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Callable

# Frozen SFT/operator input.
L_EFF = 9.097814727066048
SETTLEMENT_RANK = 3
OCCUPIED_RANK = 1
MINIMAL_OPTICAL_NORMALIZATION_C = 1.0  # Explicit postulate, not a theorem.

# Exact SI constants and frozen inertial-electron input.
H_EXACT = 6.62607015e-34
HBAR_EXACT = H_EXACT / (2.0 * math.pi)
C_EXACT = 299_792_458.0
M_E_FROZEN_KG = 9.1093837139e-31


@dataclass(frozen=True)
class ThresholdSocket:
    q_star: float
    p_coh: float
    u_star: float
    k_star: float
    map_derivative: float
    stable: bool
    beta_center: float
    beta_positive: float
    beta_half_window: float
    lane_positive: int
    lane_negative: int


@dataclass(frozen=True)
class RegisterHandoff:
    q_star: float
    settlement_rank: int
    occupied_rank: int
    chi_e: float
    availability_eigenvalues: tuple[float, float, float]


@dataclass(frozen=True)
class GPrediction:
    l_eff: float
    d6: float
    b6: float
    chi_e: float
    optical_normalization_c: float
    gamma_e: float
    epsilon_e: float
    hbar: float
    c_si: float
    electron_mass_kg: float
    g_si: float


def p_coh_pi(q: float) -> float:
    """Frozen recurrence coherence at phase pi."""
    return ((1.0 - q) / (1.0 + q)) ** 2


def dp_coh_pi(q: float) -> float:
    p = p_coh_pi(q)
    return -4.0 * p / (1.0 - q * q)


def threshold_residual(q: float) -> float:
    """Reduced exact threshold equation.

    At the limiting matter/light socket P_coh(q) * u = 1/3.  Substituting
    u=1/(3 P_coh) into K=3pi/4+(L_eff/4)u gives

        q = exp[-(3pi/4) P_coh(q) - L_eff/12].
    """
    p = p_coh_pi(q)
    return q - math.exp(-(3.0 * math.pi / 4.0) * p - L_EFF / 12.0)


def bisect_root(
    function: Callable[[float], float],
    left: float,
    right: float,
    iterations: int = 160,
) -> float:
    f_left = function(left)
    f_right = function(right)
    if f_left == 0.0:
        return left
    if f_right == 0.0:
        return right
    if f_left * f_right > 0.0:
        raise ValueError(f"Root is not bracketed on [{left}, {right}].")
    for _ in range(iterations):
        midpoint = 0.5 * (left + right)
        f_mid = function(midpoint)
        if f_left * f_mid <= 0.0:
            right = midpoint
            f_right = f_mid
        else:
            left = midpoint
            f_left = f_mid
    return 0.5 * (left + right)


def scan_roots(
    function: Callable[[float], float],
    start: float = 1e-12,
    stop: float = 1.0 - 1e-12,
    intervals: int = 200_000,
) -> list[float]:
    roots: list[float] = []
    x_left = start
    f_left = function(x_left)
    width = (stop - start) / intervals
    for index in range(1, intervals + 1):
        x_right = start + index * width
        f_right = function(x_right)
        if f_left * f_right < 0.0:
            root = bisect_root(function, x_left, x_right)
            if not roots or abs(root - roots[-1]) > 1e-10:
                roots.append(root)
        x_left, f_left = x_right, f_right
    return roots


def solve_threshold_socket() -> ThresholdSocket:
    roots = scan_roots(threshold_residual)
    if not roots:
        raise RuntimeError("No recurrence root found.")

    candidates: list[ThresholdSocket] = []
    for q in roots:
        p = p_coh_pi(q)
        u = 1.0 / (3.0 * p)
        k = 3.0 * math.pi / 4.0 + (L_EFF / 4.0) * u
        derivative = -k * dp_coh_pi(q) * q
        stable = abs(derivative) < 1.0

        # Positive-edge weak lane k=2. Beta is reconstructed after q and u; no beta decimal is an input.
        phase_angle = 2.0 * math.pi - math.acos(1.0 - u)
        beta_positive = phase_angle - 4.0 * math.pi / 3.0
        beta_center = math.pi / 3.0
        while beta_positive < 0.0:
            beta_positive += 2.0 * math.pi
        while beta_positive >= 2.0 * math.pi:
            beta_positive -= 2.0 * math.pi

        candidates.append(
            ThresholdSocket(
                q_star=q,
                p_coh=p,
                u_star=u,
                k_star=k,
                map_derivative=derivative,
                stable=stable,
                beta_center=beta_center,
                beta_positive=beta_positive,
                beta_half_window=beta_positive - beta_center,
                lane_positive=2,
                lane_negative=0,
            )
        )

    stable_candidates = [item for item in candidates if item.stable]
    if len(stable_candidates) != 1:
        raise RuntimeError(
            f"Expected one stable recurrence root; found {len(stable_candidates)}."
        )
    return stable_candidates[0]


def build_register_handoff(socket: ThresholdSocket) -> RegisterHandoff:
    chi = 1.0 - (OCCUPIED_RANK / SETTLEMENT_RANK) * socket.q_star
    eigenvalues = (1.0 - socket.q_star, 1.0, 1.0)
    return RegisterHandoff(
        q_star=socket.q_star,
        settlement_rank=SETTLEMENT_RANK,
        occupied_rank=OCCUPIED_RANK,
        chi_e=chi,
        availability_eigenvalues=eigenvalues,
    )


def predict_numerical_g(
    handoff: RegisterHandoff,
    optical_normalization_c: float = MINIMAL_OPTICAL_NORMALIZATION_C,
) -> GPrediction:
    if optical_normalization_c <= 0.0:
        raise ValueError("The universal optical normalization must be positive.")

    d6 = math.exp(3.0 * L_EFF)
    b6 = (d6 / (2.0 * math.pi)) ** 2
    gamma_e = optical_normalization_c * handoff.chi_e * b6

    # Resolved large-route optical branch:
    #   a(rho) -> 3/20,
    #   alpha_theta = 1/(16 pi^2),
    #   Gamma = 64 alpha_theta rho^2/(pi a),
    #   epsilon = 1/(rho sqrt(pi Gamma)).
    # Eliminating rho gives the exact asymptotic expression below.
    epsilon_e = math.sqrt(80.0 / (3.0 * math.pi**4)) / gamma_e

    g_si = epsilon_e**2 * HBAR_EXACT * C_EXACT / M_E_FROZEN_KG**2
    return GPrediction(
        l_eff=L_EFF,
        d6=d6,
        b6=b6,
        chi_e=handoff.chi_e,
        optical_normalization_c=optical_normalization_c,
        gamma_e=gamma_e,
        epsilon_e=epsilon_e,
        hbar=HBAR_EXACT,
        c_si=C_EXACT,
        electron_mass_kg=M_E_FROZEN_KG,
        g_si=g_si,
    )


def to_dict(instance: object) -> dict:
    return asdict(instance)
