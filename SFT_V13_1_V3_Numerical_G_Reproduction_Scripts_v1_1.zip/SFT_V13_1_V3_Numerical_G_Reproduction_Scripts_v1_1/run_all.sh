#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 run_all.py
python3 verify_expected_results.py
