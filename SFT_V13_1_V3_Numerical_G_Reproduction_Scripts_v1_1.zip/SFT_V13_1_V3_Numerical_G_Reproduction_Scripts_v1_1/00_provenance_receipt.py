from __future__ import annotations
import csv, json
from pathlib import Path
import mpmath as mp

L_EFF_TEXT = "9.097814727066048"

def main() -> None:
    mp.mp.dps = 100
    L = mp.mpf(L_EFF_TEXT)
    P = lambda q: ((1-q)/(1+q))**2
    F = lambda q: q-mp.e**(-(3*mp.pi/4)*P(q)-L/12)
    q = mp.findroot(F,(mp.mpf(".08"),mp.mpf(".11")))
    p = P(q)
    u = 1/(3*p)
    K = 3*mp.pi/4 + L*u/4
    derivative = -K*(-4*p/(1-q*q))*q
    shift = mp.pi/3-mp.acos(1-u)
    payload = {
        "dependency_order": [
            "P_coh(q,pi)",
            "q_star from reduced threshold recurrence",
            "u_star=1/(3P_coh)",
            "beta edges from lane geometry"
        ],
        "beta_is_input": False,
        "measured_G_is_input": False,
        "q_star": mp.nstr(q,80),
        "P_coh": mp.nstr(p,80),
        "u_star": mp.nstr(u,80),
        "K_star": mp.nstr(K,80),
        "map_derivative": mp.nstr(derivative,80),
        "stable": abs(derivative)<1,
        "beta_center": mp.nstr(mp.pi/3,80),
        "beta_minus": mp.nstr(mp.pi/3-shift,80),
        "beta_plus": mp.nstr(mp.pi/3+shift,80),
        "beta_half_window": mp.nstr(shift,80),
        "beta_half_window_15dp": f"{float(shift):.15f}",
        "superseded_decimal": "0.021432753081799",
    }
    output=Path("outputs"); output.mkdir(exist_ok=True)
    (output/"provenance_receipt.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
    rows=[
        (2010,"6.67384e-11","0.00080e-11","https://physics.nist.gov/cuu/Constants/ArchiveASCII/allascii_2010.txt"),
        (2014,"6.67408e-11","0.00031e-11","https://physics.nist.gov/cuu/Constants/ArchiveASCII/allascii_2014.txt"),
        (2018,"6.67430e-11","0.00015e-11","https://physics.nist.gov/cuu/Constants/ArchiveASCII/allascii_2018.txt"),
        (2022,"6.67430e-11","0.00015e-11","https://physics.nist.gov/cuu/Constants/Table/allascii.txt"),
    ]
    with (output/"codata_drift.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["adjustment","G_central_SI","standard_uncertainty_SI","official_NIST_source"]); w.writerows(rows)
    print(json.dumps(payload,indent=2))

if __name__=="__main__": main()
