from __future__ import annotations

import json
from pathlib import Path

from sft_g_core import build_register_handoff, solve_threshold_socket, to_dict


def main() -> None:
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)
    socket = solve_threshold_socket()
    handoff = build_register_handoff(socket)
    payload = to_dict(handoff)
    payload["formula"] = "chi_e=(1/3)Tr(I_3-q_star P_e)=1-q_star/3"
    payload["claim_boundary"] = (
        "Retained amplitude is withheld at the pre-norm support-operator level."
    )
    (output_dir / "register_handoff.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
