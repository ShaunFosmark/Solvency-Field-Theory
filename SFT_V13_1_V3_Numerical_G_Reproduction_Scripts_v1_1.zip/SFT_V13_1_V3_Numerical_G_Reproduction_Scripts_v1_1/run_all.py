from __future__ import annotations

import importlib.util
import json
from pathlib import Path

SCRIPTS = [
    "00_provenance_receipt.py",
    "01_threshold_socket.py",
    "02_register_handoff.py",
    "03_numerical_g_prediction.py",
    "04_candidate_grammar_audit.py",
    "05_claim_boundary_audit.py",
]


def run_script(path: Path) -> None:
    module_name = "repro_" + path.stem.replace("-", "_")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.main()


def main() -> None:
    root = Path(__file__).resolve().parent
    output_dir = root / "outputs"
    output_dir.mkdir(exist_ok=True)

    # Run from the pack directory so every script writes to one output folder.
    import os
    os.chdir(root)

    for filename in SCRIPTS:
        print(f"\n=== Running {filename} ===")
        run_script(root / filename)

    prediction = json.loads(
        (output_dir / "numerical_g_prediction.json").read_text(encoding="utf-8")
    )
    claim = json.loads(
        (output_dir / "claim_boundary.json").read_text(encoding="utf-8")
    )
    provenance = json.loads((output_dir / "provenance_receipt.json").read_text(encoding="utf-8"))
    summary = {
        "beta_half_window": provenance["beta_half_window"],
        "q_star": json.loads(
            (output_dir / "threshold_socket.json").read_text(encoding="utf-8")
        )["q_star"],
        "chi_e": prediction["chi_e"],
        "Gamma_e": prediction["gamma_e"],
        "epsilon_e": prediction["epsilon_e"],
        "G_SI": prediction["g_si"],
        "claim_status": prediction["status"],
        "fully_derived_numerical_G": claim["full_derivation_status"][
            "fully_derived_numerical_G"
        ],
    }
    (output_dir / "reproduction_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print("\n=== Reproduction summary ===")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
