from __future__ import annotations

import csv
import math
from pathlib import Path

from comparison_inputs import (
    GAMMA_E_FROZEN_COMPARISON,
    G_FROZEN_COMPARISON_SI,
)
from sft_g_core import (
    build_register_handoff,
    predict_numerical_g,
    solve_threshold_socket,
)


def candidate_rows(q: float) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for label, retained in (("amplitude", q), ("intensity", q * q)):
        eigenvalues = (1.0 - retained, 1.0, 1.0)
        candidates = {
            "normalized_trace": sum(eigenvalues) / 3.0,
            "determinant": math.prod(eigenvalues),
            "geometric_mean": math.prod(eigenvalues) ** (1.0 / 3.0),
            "normalized_schatten_2": math.sqrt(
                sum(value * value for value in eigenvalues) / 3.0
            ),
            "minimum_eigenvalue": min(eigenvalues),
            "maximum_eigenvalue": max(eigenvalues),
        }
        for functional, quotient in candidates.items():
            rows.append(
                {
                    "representation": label,
                    "functional": functional,
                    "quotient": quotient,
                    "generated_before_comparison": True,
                }
            )
    return rows


def main() -> None:
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)

    socket = solve_threshold_socket()
    base_handoff = build_register_handoff(socket)
    identity_prediction = predict_numerical_g(base_handoff)

    rows = candidate_rows(socket.q_star)
    for row in rows:
        quotient = float(row["quotient"])
        gamma = quotient * identity_prediction.b6
        epsilon = math.sqrt(80.0 / (3.0 * math.pi**4)) / gamma
        g_value = (
            epsilon**2
            * identity_prediction.hbar
            * identity_prediction.c_si
            / identity_prediction.electron_mass_kg**2
        )
        row.update(
            {
                "Gamma": gamma,
                "Gamma_relative_error_to_frozen_comparison": (
                    gamma / GAMMA_E_FROZEN_COMPARISON - 1.0
                ),
                "G_SI": g_value,
                "G_relative_error_to_frozen_comparison": (
                    g_value / G_FROZEN_COMPARISON_SI - 1.0
                ),
            }
        )

    rows.sort(key=lambda item: abs(float(item["G_relative_error_to_frozen_comparison"])))
    path = output_dir / "candidate_grammar.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {path}")
    print("Best preregistered standard scalar:")
    print(rows[0])


if __name__ == "__main__":
    main()
