from __future__ import annotations

import json
from pathlib import Path

from sft_g_core import (
    build_register_handoff,
    predict_numerical_g,
    solve_threshold_socket,
    to_dict,
)


def main() -> None:
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)

    socket = solve_threshold_socket()
    handoff = build_register_handoff(socket)
    prediction = predict_numerical_g(handoff, optical_normalization_c=1.0)
    payload = to_dict(prediction)
    payload.update(
        {
            "formula_gamma": (
                "Gamma_e=(1-q_star/3)*(exp(3*L_eff)/(2*pi))^2"
            ),
            "formula_epsilon": (
                "epsilon_e=sqrt(80/(3*pi^4))/Gamma_e"
            ),
            "formula_G": "G=epsilon_e^2*hbar*c/m_e^2",
            "status": "CONDITIONAL_ZERO_CONTINUOUS_PARAMETER_PREDICTION",
            "explicit_postulate": "minimal optical normalization c=1",
            "not_claimed": "full derivation of the universal normalization c",
        }
    )
    (output_dir / "numerical_g_prediction.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
