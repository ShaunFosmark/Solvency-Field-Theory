from __future__ import annotations

import json
from pathlib import Path

from sft_g_core import solve_threshold_socket, to_dict


def main() -> None:
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)
    socket = solve_threshold_socket()
    payload = to_dict(socket)
    (output_dir / "threshold_socket.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
