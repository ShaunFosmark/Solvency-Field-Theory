"""External comparison-only values. Never imported by candidate generation."""
GAMMA_E_FROZEN_COMPARISON = 1.250089751361e22
G_FROZEN_COMPARISON_SI = 6.67430e-11
G_RELATIVE_UNCERTAINTY_WINDOW = 22e-6
CODATA_HISTORY = [
    {"adjustment":2010,"G":6.67384e-11,"u":0.00080e-11},
    {"adjustment":2014,"G":6.67408e-11,"u":0.00031e-11},
    {"adjustment":2018,"G":6.67430e-11,"u":0.00015e-11},
    {"adjustment":2022,"G":6.67430e-11,"u":0.00015e-11},
]
