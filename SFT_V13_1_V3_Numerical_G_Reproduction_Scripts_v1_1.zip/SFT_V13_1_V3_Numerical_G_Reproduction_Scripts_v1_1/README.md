# SFT V13.1-V3 Numerical-G Reproduction Scripts v1.1

This lean pack reproduces the live conditional numerical-G result and closes the q*/beta provenance receipt. It contains no exploratory gate history.

## Dependency order

1. Define `P_coh(q,pi)=((1-q)/(1+q))^2`.
2. Solve the reduced exact threshold recurrence
   `q=exp[-(3pi/4)P_coh(q)-L_eff/12]`.
3. Select the unique stable root `q_star`.
4. Derive `u_star=1/(3P_coh)`.
5. Derive the conjugate beta edges from `u_k=1-cos(beta+2pi k/3)`.
6. Build `chi_e=1-q_star/3`, `Gamma_e`, `epsilon_e`, and conditional `G_0`.

The beta edge is an output. It is not accepted as an input. The corrected 15-decimal edge is `0.021432753081800`; the earlier `...1799` decimal is superseded.

## Claim boundary

The result is a comparison-separated, target-excluded calculation under the explicit minimal optical-normalization postulate `c=1`. The project was not historically ignorant of measured G, so this pack avoids an unqualified claim of historical blindness.

## Requirements

- Python 3.10+
- `pip install -r requirements.txt`

## Run

```bash
python run_all.py
python verify_expected_results.py
```

Outputs include the high-precision provenance receipt, CODATA-drift table, threshold socket, register handoff, candidate grammar, claim-boundary audit, and numerical-G receipt.

Official CODATA comparison sources are listed in `CODATA_DRIFT.csv`. Measured G remains isolated in comparison-only code and never enters candidate generation.
