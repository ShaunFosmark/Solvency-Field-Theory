from __future__ import annotations

import json
import math
from pathlib import Path

from comparison_inputs import (
    G_FROZEN_COMPARISON_SI,
    G_RELATIVE_UNCERTAINTY_WINDOW,
)
from sft_g_core import (
    build_register_handoff,
    predict_numerical_g,
    solve_threshold_socket,
)


def main() -> None:
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)

    socket = solve_threshold_socket()
    handoff = build_register_handoff(socket)
    identity = predict_numerical_g(handoff, optical_normalization_c=1.0)

    ratio = identity.g_si / G_FROZEN_COMPARISON_SI
    c_anchor_gamma_convention = math.sqrt(ratio)
    c_anchor_inverse_convention = 1.0 / c_anchor_gamma_convention
    payload = {
        "identity_track": {
            "c": 1.0,
            "uses_measured_G_to_generate_prediction": False,
            "G_SI": identity.g_si,
            "relative_difference_to_frozen_comparison": ratio - 1.0,
            "inside_22ppm_comparison_window": (
                abs(ratio - 1.0) < G_RELATIVE_UNCERTAINTY_WINDOW
            ),
            "status": "conditional zero-parameter prediction",
        },
        "one_anchor_control": {
            "c_anchor_for_Gamma_equals_c_times_capacity": c_anchor_gamma_convention,
            "inverse_coefficient_if_written_as_capacity_equals_c_times_Gamma": c_anchor_inverse_convention,
            "uses_measured_G": True,
            "status": "calibration control; never a prediction of G",
        },
        "full_derivation_status": {
            "universal_optical_normalization_c_derived": False,
            "fully_derived_numerical_G": False,
            "remaining_open": "independent theorem fixing c=1",
        },
    }
    (output_dir / "claim_boundary.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
