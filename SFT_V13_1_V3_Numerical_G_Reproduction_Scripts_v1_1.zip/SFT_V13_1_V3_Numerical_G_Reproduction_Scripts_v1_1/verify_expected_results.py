from __future__ import annotations
import json, math, subprocess, sys
from pathlib import Path

def main():
    root=Path(__file__).resolve().parent
    if not (root/"outputs/reproduction_summary.json").exists():
        subprocess.run([sys.executable,str(root/"run_all.py")],cwd=root,check=True)
    exp=json.loads((root/"EXPECTED_RESULTS.json").read_text())
    prov=json.loads((root/"outputs/provenance_receipt.json").read_text())
    pred=json.loads((root/"outputs/numerical_g_prediction.json").read_text())
    assert prov["beta_is_input"] is False
    assert prov["measured_G_is_input"] is False
    assert prov["beta_half_window_15dp"]==exp["beta_half_window_15dp"]
    assert abs(float(prov["q_star"])-float(exp["q_star_high_precision"]))<5e-16
    assert abs(pred["gamma_e"]/float(exp["Gamma_e_high_precision"])-1)<5e-15
    assert abs(pred["g_si"]/float(exp["G_SI_high_precision"])-1)<5e-15
    print("PASS: provenance, beta derivation, and numerical-G receipt reproduce within floating-point tolerance.")
if __name__=="__main__": main()
