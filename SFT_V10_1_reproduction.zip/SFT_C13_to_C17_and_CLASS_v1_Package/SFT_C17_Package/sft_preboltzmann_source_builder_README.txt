Run:
python sft_preboltzmann_source_builder.py --out-dir preboltzmann_run

What it does:
- builds Lambda(z), Phi_eq(z), beta_Q(z), and k_c(z)
- builds the actual source tables S(k,z) implied by C16
- writes background/source CSVs and diagnostic plots

Why this is the first code to run:
This is the final pre-CLASS/CAMB step. It generates the exact source history
tables that a real Boltzmann implementation would consume.

Bring back:
- sft_preboltzmann_source_summary.txt
- sft_preboltzmann_source_metadata.json

If these look sensible, the next stage is solver integration.
