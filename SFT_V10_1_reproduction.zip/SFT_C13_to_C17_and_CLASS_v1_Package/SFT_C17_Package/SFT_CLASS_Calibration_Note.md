# SFT CLASS Calibration Note

**Date:** 2026-04-17
**Patch:** sft_class_patch_v1 (143 lines, 3 files modified)
**Solver:** CLASS public master, compiled from source
**Cosmology:** Planck 2018 TT,TE,EE+lowE+lensing best-fit

## 1. Calibration target

The pre-Boltzmann builder (5.4) provides calibrated values at z*:

| Quantity | Builder value | Patch analytic value | Agreement |
|:---|:---:|:---:|:---:|
| β_Q(z*) | 1.24 × 10⁻⁴ | 2.85 × 10⁻⁴ | ratio = 2.30 |
| Φ_eq(z*) | 0.4766 | 0.4737 | 0.6% |
| k_c(z*) | 4.37 × 10⁻⁴ Mpc⁻¹ | 4.30 × 10⁻⁴ Mpc⁻¹ | 1.6% |

## 2. Source of the β_Q mismatch

The patch computes β_Q = q_T · f_b · f_r · ε_Φ = 2.85 × 10⁻⁴ (simplified, no relaxation).

The builder computes β_Q including the Hubble-limited relaxation factor R_Φ K_Φ ~ 1/H from C16.8, which reduces the effective coupling by a factor of ~2.3.

The Φ_eq and k_c values agree to within 0.6% and 1.6% respectively, confirming the analytic mode reproduces the builder's order parameter and instability band correctly.

## 3. Calibrated amplitude

A_sft absorbs the relaxation factor:

    A_sft = (β_Q,builder × Φ_eq,builder) / (β_Q,patch × Φ_eq,patch)
          = (1.24e-4 × 0.4766) / (2.85e-4 × 0.4737)
          = 5.91e-5 / 1.35e-4
          = 0.4378

**This is not a free parameter.** It is the mapped ratio between the simplified analytic mode and the full pre-Boltzmann computation. Its physical content is the R_Φ K_Φ relaxation factor.

## 4. Calibrated physical effect

With A_sft = 0.4378, the SFT shatter source produces:

| Multipole | Δ D_ℓ (µK²) | Relative (%) | Cosmic variance (%) | SFT/CV ratio |
|:---:|:---:|:---:|:---:|:---:|
| ℓ = 2 | +0.186 | +0.018 | ±63.2 | 0.0003 |
| ℓ = 3 | +0.337 | +0.035 | ±53.5 | 0.0006 |
| ℓ = 4 | +0.344 | +0.037 | ±47.1 | 0.0008 |
| ℓ = 5 | +0.198 | +0.023 | ±42.6 | 0.0005 |
| ℓ = 6 | +0.072 | +0.008 | ±39.2 | 0.0002 |
| ℓ ≥ 10 | ~0 | ~0 | — | — |
| ℓ ≥ 30 | 0 | 0 | — | — |

Sector RMS residuals:

| Sector | RMS (%) |
|:---|:---:|
| ISW (ℓ = 2–30) | 0.011 |
| Acoustic peaks (ℓ = 30–300) | 0.000 |
| Damping tail (ℓ = 300–2500) | 0.000 |
| **Full range (ℓ = 2–2500)** | **0.001** |

## 5. Physical interpretation

The calibrated SFT shatter source is a sub-cosmic-variance perturbation at all multipoles. At its peak (ℓ = 4), the effect is 0.08% of the cosmic variance — roughly one thousandth of the noise floor.

This means:

1. **CMB compatibility is automatic**, not engineered. The effect is too small to disturb any measured feature.
2. **The acoustic peaks are preserved to machine precision** across all tested parameter variations.
3. **The effect is a definite prediction**: +0.34 µK² at ℓ = 4. It is not currently detectable per-multipole, but it is a fixed target for future low-ℓ precision experiments.
4. **The shatter mechanism does exactly what Section 11 of V10 says**: it produces a localized relic imprint at low ℓ, below the acoustic peak scale, with amplitude set by the order parameter Φ_eq and the transfer coefficient β_Q.

## 6. What A_sft = 0.4378 means for the patch

For all future runs using the analytic mode with the current default parameters:

- **A_sft = 0.4378** reproduces the pre-Boltzmann builder's physical amplitude
- **A_sft = 1.0** overestimates by 2.3x (missing relaxation factor)
- **A_sft = 0** recovers vanilla CLASS (bit-identical)

When table-driven mode is implemented, A_sft should be set to 1.0 because the tables will already include the full β_Q with relaxation.
