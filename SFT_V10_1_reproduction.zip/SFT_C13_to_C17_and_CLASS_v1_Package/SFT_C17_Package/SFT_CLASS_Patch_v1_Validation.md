# SFT CLASS Patch v1 — Validation Report

## What this patch does

Injects the SFT shatter source (C13-C16) as an additive scalar temperature
source into the CLASS Boltzmann solver. The source term is:

    S_SFT(k,τ) = A_sft · g(τ) · β_Q(τ) · (k/a)² · Φ_eq(τ) · η_k · W(k/k_c)

where:
- g(τ) = visibility-like Gaussian window centered on z_center
- β_Q = q_T · f_b · f_r · ε_Φ  (from C16)
- Φ_eq = sqrt(A/λ · (Λ-1))  for Λ>1  (from C13)
- η_k = A_seed · exp(-k²/2k₀²)  (Gaussian seed spectrum)
- W(k/k_c) = step function at instability band cutoff (from C16.9)
- k_c = (a/c_χ) · sqrt(A_inst · (Λ-1))

## Files modified (143-line patch)

1. `include/perturbations.h` — Added SFT fields to struct perturbations
2. `source/input.c` — Added parameter defaults and .ini parsing
3. `source/perturbations.c` — Added source injection after gauge-specific blocks

Files NOT touched: transfer.c, Python wrapper, primordial module.

## Validation results

### Test 1: Zero-source recovery (sft_shatter_source = no)
- Result: BIT-IDENTICAL to vanilla CLASS
- Status: PASSED ✓

### Test 1b: Zero amplitude (sft_shatter_source = yes, A_sft = 0)
- Result: BIT-IDENTICAL to vanilla CLASS
- Status: PASSED ✓

### Test 2: Source activation (A_sft = 1e-5, sigma_z = 20)
- Max relative diff: 8.50e-09 at ell = 4
- Effect concentrated at ell 2-10 (low-k band)
- Acoustic peaks (ell > 30) completely untouched
- Status: PASSED ✓

### Test 3: Strong source (A_sft = 1.0, sigma_z = 20)
- Max relative diff: 8.50e-04 at ell = 4
- Linear scaling confirmed (1e5 amplitude ratio → 1e5 effect ratio)
- Effect profile: ell=2 (+0.04%), ell=4 (+0.085%), ell=10 (~0), ell>30 (zero)
- Status: PASSED ✓

### Test 4: k-band validation
- With k_c ≈ 4.3e-4 Mpc⁻¹ (matching 5.4's pre-Boltzmann value)
- Effect maps to ell ~ 3-6 via ell ≈ k · D_A
- Broader k0 does NOT extend effect to higher ell (instability band dominates)
- Status: PASSED ✓ — k_c is the physical selection, as C16.9 predicts

### Test 5: Visibility window comparison (narrow/standard/broad)
- narrow (sigma_z=5):   peak effect +2.24e-04 at ell=4
- standard (sigma_z=20): peak effect +8.50e-04 at ell=4
- broad (sigma_z=200):  peak effect +8.18e-03 at ell=4
- Broad/narrow ratio: ~36x at peak, growing to ~27000x at ell=10
- Confirms C15 thin-shell diagnostic: narrow source → thin-shell valid;
  broad source → thin-shell breaks down
- Status: PASSED ✓

## How to apply this patch

    cd class_public
    git apply sft_class_patch_v1.patch
    make clean && make class

Then add the SFT parameter block to your .ini file (see sft_class_v1_explanatory_block.ini).

## What to do next (per 5.4's validation ladder)

1. ✓ Zero-source recovery
2. ✓ Source activation and linear scaling
3. ✓ k-band validation against pre-Boltzmann k_c
4. ✓ Visibility window thin-shell comparison
5. TODO: Calibrate A_sft against pre-Boltzmann builder absolute amplitudes
6. TODO: Table-driven mode (load β_Q, Φ_eq, k_c from external files)
7. TODO: Compare TT residual to Planck 2018
8. TODO: Parameter exploration for ε_Φ sensitivity

## Computed background values at z=1100

With default parameters (lambda0=0.4, lambda1=1.0, Td=6500, p=2):
- T_physical = 2999.975 K
- f(T) = 0.824
- Λ = 1.224 (above critical → shatter active)
- Φ_eq = 0.473
- k_c = 4.3e-4 Mpc⁻¹  (matches 5.4's 4.37e-4)

These values confirm the analytic mode is reproducing the pre-Boltzmann
builder's calibrated history.
