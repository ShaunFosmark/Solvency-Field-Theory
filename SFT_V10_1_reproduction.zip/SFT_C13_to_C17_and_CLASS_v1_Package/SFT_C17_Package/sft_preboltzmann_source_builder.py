#!/usr/bin/env python3
"""
SFT pre-Boltzmann source builder
--------------------------------

Purpose
-------
Build the exact source tables that a future CLASS/CAMB implementation would need,
without yet modifying a Boltzmann solver.

This script computes:

1) The shatter control law
       Lambda(z) = Lambda0 + Lambda1 * f(T(z))

2) The broken-phase order parameter
       Phi_eq(z) = sqrt(max(Lambda(z)-1, 0))

3) The first-principles C16 source coefficient
       beta_Q(z) = q_T * f_b(z) * f_r(z) * epsilon_phi / H(z)

   using the Hubble-limited relaxation closure.

4) The instability-selected cutoff scale
       k_c(z) = [a(z)/c_chi] * sqrt(A * max(Lambda(z)-1, 0))

5) A family of source tables
       S_SFT(k,z) ~ g(z) * beta_Q(z) * [k^2 / a(z)^2] * deltaPhi_k(z)

   with deltaPhi_k(z) suppressed outside the unstable band k < k_c(z).

Outputs
-------
- background_history.csv
- source_grid.csv
- source_summary.txt
- source_metadata.json
- diagnostic plots

This is the correct first code step before touching CLASS/CAMB.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt


def visibility_gaussian(z, z_star, sigma_z):
    g = np.exp(-0.5 * ((z - z_star) / sigma_z) ** 2)
    norm = np.trapezoid(g, z)
    return g / norm if norm > 0 else g


def decoupling_fraction(T, Td, p):
    return 1.0 / (1.0 + (T / Td) ** p)


def H_of_z(z, H0, Omega_m, Omega_r):
    Ez = np.sqrt(Omega_r * (1.0 + z) ** 4 + Omega_m * (1.0 + z) ** 3)
    return H0 * Ez


def smooth_step(x, sharpness=8.0):
    # bounded mask that approximates a step near x=1
    return 1.0 / (1.0 + np.exp(sharpness * (x - 1.0)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", default=".")
    parser.add_argument("--z-min", type=float, default=500.0)
    parser.add_argument("--z-max", type=float, default=3000.0)
    parser.add_argument("--nz", type=int, default=1600)

    # Shatter control law
    parser.add_argument("--tcmb0", type=float, default=2.725)
    parser.add_argument("--lambda0", type=float, default=0.4)
    parser.add_argument("--lambda1", type=float, default=1.0)
    parser.add_argument("--Td", type=float, default=6500.0)
    parser.add_argument("--p", type=float, default=2.0)

    # Background expansion (arbitrary but consistent units for the prototype)
    parser.add_argument("--H0", type=float, default=1.0e-4)
    parser.add_argument("--Omega-m", type=float, default=0.31)
    parser.add_argument("--Omega-r", type=float, default=9.0e-5)

    # C16 beta_Q factorization
    parser.add_argument("--qT", type=float, default=0.25)
    parser.add_argument("--fb0", type=float, default=0.15)
    parser.add_argument("--fr0", type=float, default=0.30)
    parser.add_argument("--epsilon-phi", type=float, default=1.0/(4.0*np.pi*np.pi))

    # optional mild redshift evolution of f_b and f_r
    parser.add_argument("--fb-power", type=float, default=0.0)
    parser.add_argument("--fr-power", type=float, default=0.0)

    # instability band / stiffness
    parser.add_argument("--A-instability", type=float, default=1.0)
    parser.add_argument("--c-chi", type=float, default=1.0)
    parser.add_argument("--mask-sharpness", type=float, default=10.0)

    # seed spectrum
    parser.add_argument("--A-seed", type=float, default=1.0)
    parser.add_argument("--k0", type=float, default=0.10)
    parser.add_argument("--k-min", type=float, default=0.005)
    parser.add_argument("--k-max", type=float, default=0.50)
    parser.add_argument("--nk", type=int, default=60)

    # source localization
    parser.add_argument("--z-star", type=float, default=1089.0)
    parser.add_argument("--sigma-z", type=float, default=20.0)

    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    z = np.linspace(args.z_min, args.z_max, args.nz)
    a = 1.0 / (1.0 + z)
    T = args.tcmb0 * (1.0 + z)

    f = decoupling_fraction(T, args.Td, args.p)
    Lambda = args.lambda0 + args.lambda1 * f
    Lambda_minus_1 = np.clip(Lambda - 1.0, 0.0, None)
    Phi_eq = np.sqrt(Lambda_minus_1)

    H = H_of_z(z, args.H0, args.Omega_m, args.Omega_r)

    # beta_Q factorization from C16 with Hubble-limited relaxation closure
    fb = args.fb0 * ((1.0 + z) / (1.0 + args.z_star)) ** args.fb_power
    fr = args.fr0 * ((1.0 + z) / (1.0 + args.z_star)) ** args.fr_power
    betaQ = args.qT * fb * fr * args.epsilon_phi / H

    # instability-selected scale
    kc = (a / args.c_chi) * np.sqrt(args.A_instability * Lambda_minus_1)

    # source localization
    g = visibility_gaussian(z, args.z_star, args.sigma_z)

    k_vals = np.linspace(args.k_min, args.k_max, args.nk)
    eta_seed = args.A_seed * np.exp(-0.5 * (k_vals / args.k0) ** 2)

    # build source grid S(k,z)
    source_grid = np.zeros((len(k_vals), len(z)))
    unstable_fraction = np.zeros_like(k_vals)

    for i, k in enumerate(k_vals):
        unstable_mask = smooth_step(k / np.maximum(kc, 1e-15), sharpness=args.mask_sharpness)
        deltaPhi_k = Phi_eq * eta_seed[i] * unstable_mask
        source_grid[i, :] = g * betaQ * (k ** 2) * deltaPhi_k / np.maximum(a * a, 1e-30)
        unstable_fraction[i] = np.trapezoid(unstable_mask, z) / (z[-1] - z[0])

    # representative integrated source amplitude
    source_integrated = np.trapezoid(source_grid, z, axis=1)

    # Save background history
    background_csv = out_dir / "sft_preboltzmann_background_history.csv"
    with background_csv.open("w", newline="", encoding="utf-8") as fcsv:
        writer = csv.writer(fcsv)
        writer.writerow([
            "z", "a", "T_K", "f_decouple", "Lambda", "Phi_eq",
            "H", "fb", "fr", "betaQ", "kc", "visibility_g"
        ])
        for row in zip(z, a, T, f, Lambda, Phi_eq, H, fb, fr, betaQ, kc, g):
            writer.writerow(row)

    # Save source grid in long form
    source_csv = out_dir / "sft_preboltzmann_source_grid.csv"
    with source_csv.open("w", newline="", encoding="utf-8") as fcsv:
        writer = csv.writer(fcsv)
        writer.writerow([
            "k", "z", "eta_seed", "Phi_eq", "kc", "unstable_mask_fraction_of_one",
            "betaQ", "visibility_g", "source_Skz"
        ])
        for i, k in enumerate(k_vals):
            unstable_mask = smooth_step(k / np.maximum(kc, 1e-15), sharpness=args.mask_sharpness)
            for j in range(len(z)):
                writer.writerow([
                    k, z[j], eta_seed[i], Phi_eq[j], kc[j], unstable_mask[j],
                    betaQ[j], g[j], source_grid[i, j]
                ])

    # Summary
    z_cross = float(np.interp(1.0, Lambda[::-1], z[::-1])) if np.any(Lambda >= 1.0) else math.nan
    zstar_idx = int(np.argmin(np.abs(z - args.z_star)))
    Phi_star = float(Phi_eq[zstar_idx])
    beta_star = float(betaQ[zstar_idx])
    kc_star = float(kc[zstar_idx])

    k_peak_idx = int(np.argmax(np.abs(source_integrated)))
    k_peak = float(k_vals[k_peak_idx])
    source_peak = float(source_integrated[k_peak_idx])

    lines = []
    lines.append("==================================================")
    lines.append("SFT PRE-BOLTZMANN SOURCE BUILDER")
    lines.append("==================================================")
    lines.append("")
    lines.append("Goal:")
    lines.append("  Build the exact background and source tables needed before a real")
    lines.append("  CLASS/CAMB implementation.")
    lines.append("")
    lines.append("Control law:")
    lines.append("  Lambda(z) = Lambda0 + Lambda1 * f(T(z))")
    lines.append("  f(T)      = 1 / (1 + (T/Td)^p)")
    lines.append("  Phi_eq(z) = sqrt(max(Lambda(z)-1, 0))")
    lines.append("")
    lines.append("C16 source coefficient:")
    lines.append("  beta_Q(z) = qT * f_b(z) * f_r(z) * epsilon_phi / H(z)")
    lines.append("")
    lines.append("Instability band:")
    lines.append("  k_c(z) = [a(z)/c_chi] * sqrt(A * max(Lambda(z)-1,0))")
    lines.append("")
    lines.append("Source table:")
    lines.append("  S(k,z) ~ g(z) * beta_Q(z) * [k^2/a(z)^2] * deltaPhi_k(z)")
    lines.append("")
    lines.append("Parameters:")
    lines.append(f"  Lambda0          = {args.lambda0}")
    lines.append(f"  Lambda1          = {args.lambda1}")
    lines.append(f"  Td [K]           = {args.Td}")
    lines.append(f"  p                = {args.p}")
    lines.append(f"  qT               = {args.qT}")
    lines.append(f"  fb0              = {args.fb0}")
    lines.append(f"  fr0              = {args.fr0}")
    lines.append(f"  epsilon_phi      = {args.epsilon_phi}")
    lines.append(f"  z*               = {args.z_star}")
    lines.append(f"  sigma_z          = {args.sigma_z}")
    lines.append("")
    lines.append("Derived checkpoints:")
    lines.append(f"  z_cross (Lambda=1)   = {z_cross:.9g}")
    lines.append(f"  Phi_eq(z*)           = {Phi_star:.9g}")
    lines.append(f"  beta_Q(z*)           = {beta_star:.9g}")
    lines.append(f"  k_c(z*)              = {kc_star:.9g}")
    lines.append(f"  peak integrated k    = {k_peak:.9g}")
    lines.append(f"  peak integrated src  = {source_peak:.9g}")
    lines.append("")
    lines.append("Interpretation:")
    lines.append("  - This is the last pre-solver step.")
    lines.append("  - If these tables look physically sensible, they are exactly what should")
    lines.append("    be fed into a future CLASS/CAMB source implementation.")
    lines.append("  - The next stage is code integration, not more symbolic closure.")
    lines.append("")
    if np.any(Lambda > 1.0) and np.any(source_integrated != 0.0):
        lines.append("VERDICT: SOURCE TABLES SUCCESSFULLY BUILT")
    else:
        lines.append("VERDICT: SOURCE TABLE BUILD IS DEGENERATE IN THIS PARAMETER CHOICE")

    summary_text = "\n".join(lines)
    summary_path = out_dir / "sft_preboltzmann_source_summary.txt"
    summary_path.write_text(summary_text, encoding="utf-8")

    meta = {
        "lambda0": args.lambda0,
        "lambda1": args.lambda1,
        "Td_K": args.Td,
        "p": args.p,
        "qT": args.qT,
        "fb0": args.fb0,
        "fr0": args.fr0,
        "epsilon_phi": args.epsilon_phi,
        "z_star": args.z_star,
        "sigma_z": args.sigma_z,
        "z_cross": z_cross,
        "Phi_eq_at_zstar": Phi_star,
        "betaQ_at_zstar": beta_star,
        "kc_at_zstar": kc_star,
        "peak_integrated_k": k_peak,
        "peak_integrated_source": source_peak,
    }
    meta_path = out_dir / "sft_preboltzmann_source_metadata.json"
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    # Plots
    plt.figure(figsize=(8, 5))
    plt.plot(z, Lambda, label="Lambda(z)")
    plt.plot(z, Phi_eq, label="Phi_eq(z)")
    plt.axhline(1.0, linestyle="--")
    plt.axvline(args.z_star, linestyle=":", label="z*")
    plt.gca().invert_xaxis()
    plt.xlabel("z")
    plt.ylabel("Amplitude")
    plt.title("Shatter control law and order parameter")
    plt.legend()
    plt.tight_layout()
    p1 = out_dir / "sft_preboltzmann_control.png"
    plt.savefig(p1, dpi=180)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.plot(z, betaQ, label="beta_Q(z)")
    plt.plot(z, kc, label="k_c(z)")
    plt.axvline(args.z_star, linestyle=":", label="z*")
    plt.gca().invert_xaxis()
    plt.xlabel("z")
    plt.ylabel("Amplitude")
    plt.title("beta_Q and instability cutoff")
    plt.legend()
    plt.tight_layout()
    p2 = out_dir / "sft_preboltzmann_beta_kc.png"
    plt.savefig(p2, dpi=180)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.plot(z, g, label="visibility g(z)")
    plt.gca().invert_xaxis()
    plt.xlabel("z")
    plt.ylabel("Normalized amplitude")
    plt.title("Source localization window")
    plt.legend()
    plt.tight_layout()
    p3 = out_dir / "sft_preboltzmann_visibility.png"
    plt.savefig(p3, dpi=180)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.plot(k_vals, source_integrated)
    plt.xlabel("k")
    plt.ylabel("Integrated source amplitude")
    plt.title("Integrated SFT source by mode")
    plt.tight_layout()
    p4 = out_dir / "sft_preboltzmann_integrated_source.png"
    plt.savefig(p4, dpi=180)
    plt.close()

    print(summary_text)
    print()
    print(f"Wrote: {summary_path}")
    print(f"Wrote: {background_csv}")
    print(f"Wrote: {source_csv}")
    print(f"Wrote: {meta_path}")
    print(f"Wrote: {p1}")
    print(f"Wrote: {p2}")
    print(f"Wrote: {p3}")
    print(f"Wrote: {p4}")


if __name__ == "__main__":
    main()
