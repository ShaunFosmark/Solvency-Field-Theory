#!/usr/bin/env python3
from pathlib import Path
import argparse
import csv
import json
import math

import numpy as np
import matplotlib.pyplot as plt

try:
    from scipy.special import spherical_jn
except Exception as exc:
    raise RuntimeError("This script requires scipy.special.spherical_jn") from exc


def visibility_gaussian(z, z_star, sigma_z):
    g = np.exp(-0.5 * ((z - z_star) / sigma_z) ** 2)
    norm = np.trapz(g, z)
    return g / norm if norm > 0 else g


def beta_q_ansatz(z, beta0, z_star, beta_power, beta_width):
    base = beta0 * ((1.0 + z) / (1.0 + z_star)) ** beta_power
    if beta_width is None or beta_width <= 0:
        return base
    gauss = np.exp(-0.5 * ((z - z_star) / beta_width) ** 2)
    return base * gauss


def decoupling_fraction(T, Td, p):
    return 1.0 / (1.0 + (T / Td) ** p)


def eta_of_z(z, H0, Omega_m, Omega_r):
    Ez = np.sqrt(Omega_r * (1.0 + z) ** 4 + Omega_m * (1.0 + z) ** 3)
    Hz = H0 * Ez
    deta_dz = -1.0 / Hz
    eta = np.zeros_like(z)
    for i in range(len(z) - 2, -1, -1):
        dz = z[i + 1] - z[i]
        eta[i] = eta[i + 1] - 0.5 * (deta_dz[i + 1] + deta_dz[i]) * dz
    return eta, deta_dz


parser = argparse.ArgumentParser()
parser.add_argument("--out-dir", default=".")
parser.add_argument("--z-min", type=float, default=500.0)
parser.add_argument("--z-max", type=float, default=3000.0)
parser.add_argument("--nz", type=int, default=1200)

parser.add_argument("--tcmb0", type=float, default=2.725)
parser.add_argument("--lambda0", type=float, default=0.4)
parser.add_argument("--lambda1", type=float, default=1.0)
parser.add_argument("--Td", type=float, default=6500.0)
parser.add_argument("--p", type=float, default=2.0)

parser.add_argument("--z-star", type=float, default=1089.0)
parser.add_argument("--sigma-z", type=float, default=80.0)

parser.add_argument("--beta0", type=float, default=3.0e-4)
parser.add_argument("--beta-power", type=float, default=0.0)
parser.add_argument("--beta-width", type=float, default=0.0)

parser.add_argument("--H0", type=float, default=1.0)
parser.add_argument("--Omega-m", type=float, default=0.31)
parser.add_argument("--Omega-r", type=float, default=9.0e-5)

parser.add_argument("--A-seed", type=float, default=1.0)
parser.add_argument("--k0", type=float, default=0.02)
parser.add_argument("--k-min", type=float, default=0.001)
parser.add_argument("--k-max", type=float, default=0.15)
parser.add_argument("--nk", type=int, default=150)

parser.add_argument("--ell", type=int, default=200)
args = parser.parse_args()

out_dir = Path(args.out_dir)
out_dir.mkdir(parents=True, exist_ok=True)

z = np.linspace(args.z_min, args.z_max, args.nz)
T = args.tcmb0 * (1.0 + z)

f = decoupling_fraction(T, args.Td, args.p)
Lambda = args.lambda0 + args.lambda1 * f
Phi_eq = np.sqrt(np.clip(Lambda - 1.0, 0.0, None))

eta, deta_dz = eta_of_z(z, args.H0, args.Omega_m, args.Omega_r)
eta0 = eta[0]

g = visibility_gaussian(z, args.z_star, args.sigma_z)
beta_width = args.beta_width if args.beta_width > 0 else None
betaQ = beta_q_ansatz(z, args.beta0, args.z_star, args.beta_power, beta_width)

zstar_idx = int(np.argmin(np.abs(z - args.z_star)))
eta_star = float(eta[zstar_idx])
Phi_star = float(Phi_eq[zstar_idx])
beta_shell = float(betaQ[zstar_idx])

k_vals = np.linspace(args.k_min, args.k_max, args.nk)
eta_seed = args.A_seed * np.exp(-0.5 * (k_vals / args.k0) ** 2)

theta_full = np.zeros_like(k_vals)
theta_thin = np.zeros_like(k_vals)

shell_prefactor = np.trapz(g * betaQ / (1.0 + z) ** 2 * np.abs(deta_dz), z)

for i, k in enumerate(k_vals):
    deltaPhi_k = Phi_eq * eta_seed[i]
    source = g * betaQ * (k ** 2) * deltaPhi_k / (1.0 + z) ** 2 * np.abs(deta_dz)
    bessel = spherical_jn(args.ell, k * (eta0 - eta))
    theta_full[i] = np.trapz(source * bessel, z)

    deltaPhi_star = Phi_star * eta_seed[i]
    theta_thin[i] = shell_prefactor * (k ** 2) * deltaPhi_star * spherical_jn(args.ell, k * (eta0 - eta_star))

ratio = np.full_like(k_vals, np.nan)
mask = np.abs(theta_thin) > 1e-20
ratio[mask] = theta_full[mask] / theta_thin[mask]

finite_ratio = ratio[np.isfinite(ratio)]
median_ratio = float(np.median(finite_ratio)) if finite_ratio.size else math.nan
mad_ratio = float(np.median(np.abs(finite_ratio - median_ratio))) if finite_ratio.size else math.nan

history_csv = out_dir / "sft_toy_boltzmann_history.csv"
with history_csv.open("w", newline="", encoding="utf-8") as fcsv:
    writer = csv.writer(fcsv)
    writer.writerow(["z", "T_K", "f_decouple", "Lambda", "Phi_eq", "visibility_g", "betaQ", "eta", "abs_deta_dz"])
    for row in zip(z, T, f, Lambda, Phi_eq, g, betaQ, eta, np.abs(deta_dz)):
        writer.writerow(row)

modes_csv = out_dir / "sft_toy_boltzmann_modes.csv"
with modes_csv.open("w", newline="", encoding="utf-8") as fcsv:
    writer = csv.writer(fcsv)
    writer.writerow(["k", "eta_seed", "theta_full", "theta_thin", "ratio_full_to_thin"])
    for row in zip(k_vals, eta_seed, theta_full, theta_thin, ratio):
        writer.writerow(row)

plt.figure(figsize=(8, 5))
plt.plot(z, Lambda, label="Lambda(z)")
plt.plot(z, Phi_eq, label="Phi_eq(z)")
plt.axvline(args.z_star, linestyle="--", label="z*")
plt.gca().invert_xaxis()
plt.xlabel("z")
plt.ylabel("Amplitude")
plt.title("SFT shatter control law and order parameter")
plt.legend()
plt.tight_layout()
plot1 = out_dir / "sft_toy_boltzmann_control.png"
plt.savefig(plot1, dpi=180)
plt.close()

plt.figure(figsize=(8, 5))
plt.plot(z, g, label="visibility g(z)")
norm_beta = betaQ / np.max(betaQ) if np.max(betaQ) > 0 else betaQ
plt.plot(z, norm_beta, label="betaQ(z) / max")
plt.gca().invert_xaxis()
plt.xlabel("z")
plt.ylabel("Normalized amplitude")
plt.title("Visibility and betaQ ansatz")
plt.legend()
plt.tight_layout()
plot2 = out_dir / "sft_toy_boltzmann_visibility.png"
plt.savefig(plot2, dpi=180)
plt.close()

plt.figure(figsize=(8, 5))
plt.plot(k_vals, theta_full, label="full LOS integral")
plt.plot(k_vals, theta_thin, label="thin-shell approximation")
plt.xlabel("k")
plt.ylabel(f"Theta_ell, ell={args.ell}")
plt.title("Full vs thin-shell toy SFT transfer")
plt.legend()
plt.tight_layout()
plot3 = out_dir / "sft_toy_boltzmann_full_vs_thin.png"
plt.savefig(plot3, dpi=180)
plt.close()

plt.figure(figsize=(8, 5))
plt.plot(k_vals, ratio)
plt.axhline(1.0, linestyle="--")
plt.xlabel("k")
plt.ylabel("full / thin")
plt.title("Thin-shell recovery test")
plt.tight_layout()
plot4 = out_dir / "sft_toy_boltzmann_ratio.png"
plt.savefig(plot4, dpi=180)
plt.close()

lines = []
lines.append("==================================================")
lines.append("SFT TOY BOLTZMANN / LINE-OF-SIGHT BRIDGE TEST")
lines.append("==================================================")
lines.append("")
lines.append("Goal:")
lines.append("  Test whether the visibility-weighted SFT source kernel reduces to the")
lines.append("  previously used thin-shell scaling in an appropriate limit.")
lines.append("")
lines.append("Model ingredients:")
lines.append("  Lambda(z) = Lambda0 + Lambda1 * f(T(z))")
lines.append("  f(T)      = 1 / (1 + (T/Td)^p)")
lines.append("  Phi_eq(z) = sqrt(max(Lambda(z) - 1, 0))")
lines.append("  deltaPhi_k(z) = Phi_eq(z) * eta_k")
lines.append("  eta_k = A_seed * exp[-(k/k0)^2 / 2]")
lines.append("  S_SFT(k,z) ~ g(z) * betaQ(z) * k^2 * deltaPhi_k(z) / (1+z)^2 * |deta/dz|")
lines.append("")
lines.append("Parameters:")
lines.append(f"  Lambda0      = {args.lambda0}")
lines.append(f"  Lambda1      = {args.lambda1}")
lines.append(f"  Td [K]       = {args.Td}")
lines.append(f"  p            = {args.p}")
lines.append(f"  z*           = {args.z_star}")
lines.append(f"  sigma_z      = {args.sigma_z}")
lines.append(f"  beta0        = {args.beta0}")
lines.append(f"  beta_power   = {args.beta_power}")
lines.append(f"  beta_width   = {args.beta_width}")
lines.append(f"  ell          = {args.ell}")
lines.append("")
lines.append("Derived checkpoint values:")
lines.append(f"  Phi_eq(z*)   = {Phi_star:.9g}")
lines.append(f"  betaQ(z*)    = {beta_shell:.9g}")
lines.append(f"  shell coeff  = {shell_prefactor:.9g}")
lines.append(f"  median(full/thin) over finite modes = {median_ratio:.9g}")
lines.append(f"  MAD(full/thin)                     = {mad_ratio:.9g}")
lines.append("")
lines.append("Interpretation:")
lines.append("  - If full/thin stays O(1) over a broad k-range, then the old Kcmb bridge")
lines.append("    is plausibly the thin-shell limit of a real transfer kernel.")
lines.append("  - If full/thin varies wildly or collapses, then the thin-shell approximation")
lines.append("    is too crude and the source history cannot be compressed into one Kcmb.")
lines.append("  - This is still a toy LOS test, not a full Boltzmann hierarchy.")
lines.append("")
if np.isfinite(median_ratio) and 0.3 <= abs(median_ratio) <= 3.0:
    lines.append("VERDICT: THIN-SHELL LIMIT LOOKS STRUCTURALLY PLAUSIBLE")
else:
    lines.append("VERDICT: THIN-SHELL LIMIT LOOKS STRAINED IN THIS TOY SETUP")

summary_text = "\n".join(lines)
summary_path = out_dir / "sft_toy_boltzmann_summary.txt"
summary_path.write_text(summary_text, encoding="utf-8")

meta = {
    "lambda0": args.lambda0,
    "lambda1": args.lambda1,
    "Td_K": args.Td,
    "p": args.p,
    "z_star": args.z_star,
    "sigma_z": args.sigma_z,
    "beta0": args.beta0,
    "beta_power": args.beta_power,
    "beta_width": args.beta_width,
    "ell": args.ell,
    "Phi_eq_at_zstar": Phi_star,
    "betaQ_at_zstar": beta_shell,
    "shell_prefactor": shell_prefactor,
    "median_ratio_full_to_thin": median_ratio,
    "mad_ratio_full_to_thin": mad_ratio,
    "plots": [str(plot1.name), str(plot2.name), str(plot3.name), str(plot4.name)],
}
meta_path = out_dir / "sft_toy_boltzmann_metadata.json"
meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

print(summary_text)
print()
print(f"Wrote: {summary_path}")
print(f"Wrote: {history_csv}")
print(f"Wrote: {modes_csv}")
print(f"Wrote: {meta_path}")
print(f"Wrote: {plot1}")
print(f"Wrote: {plot2}")
print(f"Wrote: {plot3}")
print(f"Wrote: {plot4}")
