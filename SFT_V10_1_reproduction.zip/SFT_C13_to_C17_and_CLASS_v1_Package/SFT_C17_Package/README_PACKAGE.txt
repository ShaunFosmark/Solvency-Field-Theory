SFT C13-C17 package

Contents:
- C13-C14: Field-Theoretic Shatter
- C15: Minimal Boltzmann Tie-In
- C16: First-Principles Origin of beta_Q
- C17: CLASS Validation and Calibration
- Numerical implementation spec
- CLASS v1 patch, validation note, calibration note, sweep summary
- Pre-Boltzmann and toy Boltzmann bridge scripts

Recommended reading order:
1. SFT_C13_C14_Field_Theoretic_Shatter.pdf
2. SFT_C15_Minimal_Boltzmann_Tie_In.pdf
3. SFT_C16_First_Principles_BetaQ.pdf
4. SFT_C17_CLASS_Validation_and_Calibration.pdf
5. SFT_Numerical_Implementation_Spec.pdf

The analytic CLASS baseline normalization frozen in C17 is:
A_sft = 0.4378
