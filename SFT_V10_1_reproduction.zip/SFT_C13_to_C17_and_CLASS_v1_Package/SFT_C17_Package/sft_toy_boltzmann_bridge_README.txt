Run:
python sft_toy_boltzmann_bridge.py --out-dir toy_boltzmann_run

What it does:
- builds the shatter control law Lambda(z)
- builds Phi_eq(z) = sqrt(max(Lambda-1, 0))
- defines a toy SFT photon source kernel with visibility weighting
- computes a line-of-sight multipole amplitude Theta_l(k)
- compares the full LOS result to the thin-shell approximation

Main question:
Does the old Kcmb-style bridge look like the thin-shell limit of a real transfer kernel?

Key outputs:
- sft_toy_boltzmann_summary.txt
- sft_toy_boltzmann_metadata.json
- sft_toy_boltzmann_history.csv
- sft_toy_boltzmann_modes.csv
- four diagnostic PNG plots
