# SFT CLASS Focused Exploration — Results

**Baseline:** A_sft = 0.4378 (pre-Boltzmann calibrated), Planck 2018 cosmology
**Date:** 2026-04-17
**Total runs:** 18

---

## Phase 1: ε_Φ × c_χ Amplitude-Position Map

A_sft = 0.4378, A_inst = 1, σ_z = 20. Sweep ε_Φ ∈ {0.5, 1, 2, 5} × 1/(4π²) against c_χ ∈ {1.0, 0.3, 0.1}.

| ε_Φ mult | c_χ | peak ℓ | Δ D_ℓ (µK²) | peak (%) | ISW RMS (%) | acoustic RMS (%) | full RMS (%) | SFT/CV |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 0.5× | 1.0 | 4 | +0.18 | +0.020 | 0.006 | 0.000 | 0.001 | 0.0004 |
| 0.5× | 0.3 | 16 | +1.94 | +0.226 | 0.126 | 0.000 | 0.014 | 0.0092 |
| 0.5× | 0.1 | 30 | +9.20 | +0.872 | 0.613 | 0.193 | 0.090 | 0.0481 |
| **1.0×** | **1.0** | **4** | **+0.37** | **+0.040** | **0.012** | **0.000** | **0.001** | **0.0008** |
| 1.0× | 0.3 | 16 | +3.89 | +0.452 | 0.253 | 0.000 | 0.027 | 0.0184 |
| 1.0× | 0.1 | 30 | +18.60 | +1.761 | 1.235 | 0.392 | 0.182 | 0.0973 |
| 2.0× | 1.0 | 4 | +0.73 | +0.080 | 0.023 | 0.000 | 0.003 | 0.0017 |
| 2.0× | 0.3 | 16 | +7.80 | +0.907 | 0.507 | 0.000 | 0.055 | 0.0368 |
| 2.0× | 0.1 | 31 | +38.55 | +3.596 | 2.504 | 0.811 | 0.373 | 0.2018 |
| 5.0× | 1.0 | 4 | +1.84 | +0.200 | 0.058 | 0.000 | 0.006 | 0.0042 |
| 5.0× | 0.3 | 16 | +19.67 | +2.287 | 1.276 | 0.000 | 0.137 | 0.0929 |
| 5.0× | 0.1 | 31 | +102.31 | +9.543 | 6.520 | 2.234 | 0.999 | 0.5356 |

### Key findings — Phase 1

1. **At the physical baseline (ε_Φ = 1/(4π²), c_χ = 1.0), the effect is 0.04% at ℓ=4 with SFT/CV = 0.0008.** This is the calibrated physical prediction.

2. **Peak ℓ is controlled by c_χ, not ε_Φ.** All c_χ = 1.0 runs peak at ℓ = 4. All c_χ = 0.3 runs peak at ℓ = 16. All c_χ = 0.1 runs peak at ℓ = 30–31. The ε_Φ multiplier changes amplitude, not location.

3. **ε_Φ enters linearly** (confirmed again at calibrated amplitude). Doubling ε_Φ doubles the peak effect.

4. **Sub-cosmic-variance condition:** SFT/CV < 1 everywhere in the grid. Even at 5× ε_Φ with c_χ = 0.1 (the most aggressive corner), SFT/CV = 0.54.

5. **Acoustic peaks are preserved** across all 12 runs. The acoustic RMS is zero for c_χ ≥ 0.3 and only nonzero at c_χ = 0.1 where the active range extends to ℓ ~ 120–146 (bleeding into the ℓ = 30 boundary of the ISW sector).

---

## Phase 2: A_instability Degeneracy Check

A_sft = 0.4378, ε_Φ = 1/(4π²), c_χ = 1.0, σ_z = 20. Sweep A_inst ∈ {1, 10, 100}.

| A_inst | k_c (Mpc⁻¹) | peak ℓ | Δ D_ℓ (µK²) | peak (%) | ISW RMS (%) | SFT/CV | active ℓ |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | 4.30e-04 | 4 | +0.37 | +0.040 | 0.012 | 0.0008 | 2–8 |
| 10 | 1.36e-03 | 15 | +3.59 | +0.423 | 0.226 | 0.0167 | 2–24 |
| 100 | 4.30e-03 | 30 | +18.60 | +1.761 | 1.235 | 0.0973 | 2–119 |

### Key findings — Phase 2

**The C16.9 band-selection rule holds at the calibrated amplitude.**

Compare Phase 2 A_inst=100 (c_χ=1) to Phase 1 ε_Φ=1×, c_χ=0.1:
- Both have k_c = 4.30e-03 Mpc⁻¹
- Both peak at ℓ = 30
- Both give peak effect = +18.6 µK² (+1.76%)
- Both give ISW RMS = 1.23%
- **Identical to 4 significant figures.**

This confirms k_c ∝ √A_inst / c_χ at the calibrated physical normalization. The degeneracy is exact, as predicted.

---

## Phase 3: Source Width Check

A_sft = 0.4378, ε_Φ = 1/(4π²), c_χ = 1.0, A_inst = 1. Sweep σ_z ∈ {5, 20, 200}.

| σ_z | peak ℓ | Δ D_ℓ (µK²) | peak (%) | ISW RMS (%) | SFT/CV | active ℓ |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 5 | 4 | +0.09 | +0.010 | 0.003 | 0.0002 | 2–8 |
| 20 | 4 | +0.37 | +0.040 | 0.012 | 0.0008 | 2–8 |
| 200 | 4 | +3.58 | +0.390 | 0.146 | 0.0083 | 2–27 |

### Key findings — Phase 3

1. **Thin-shell diagnostic confirmed at calibrated amplitude.** Narrow source (σ_z=5) gives 4× smaller effect than standard (σ_z=20). Broad source (σ_z=200) gives 10× larger.

2. **Peak ℓ does not change with σ_z.** All three runs peak at ℓ=4. The instability band k_c controls location; the visibility width controls amplitude.

3. **All three remain sub-cosmic-variance.** Even σ_z=200 gives SFT/CV = 0.008.

4. **The C15 story holds:** the thin-shell approximation is valid for narrow recombination-localized sources, and the physical SFT source (σ_z ~ 20) is firmly in the thin-shell-valid regime.

---

## Global Summary

| Property | Result |
|:---|:---|
| Calibrated physical effect | +0.34 µK² at ℓ = 4 |
| SFT/CV at baseline | 0.0008 (sub-cosmic-variance by ~1000×) |
| ε_Φ scaling | linear (confirmed at calibrated amplitude) |
| Band position control | k_c ∝ √A_inst / c_χ (confirmed exactly) |
| A_inst / c_χ degeneracy | exact to 4 significant figures |
| Visibility width effect | amplitude only, no position shift |
| Acoustic peaks | preserved in all 18 runs |
| Sub-CV condition | satisfied in all 18 runs |
| C15 thin-shell | confirmed at calibrated amplitude |
| C16.9 band selection | confirmed at calibrated amplitude |
