# SFT Companion Verification Bundle

This bundle is the supporting package for the companion note on the passive structural ledger channel in SFT.

## What this bundle is meant to verify

The core empirical claims are:

1. The active baryonic/BH channel alone saturates too shallow in `w0`.
2. Adding a passive **virialized halo structure** baseline (`M200c`) shifts `w0` monotonically in the correct direction while preserving a useful negative `wa`.
3. The resulting Pantheon-adjacent ridge is stable under targeted confirmation sweeps.
4. The passive channel is **necessary** (ablation) and **structurally specific** (`m200c` works; raw `dm` does not).

## Recommended reading order

1. `SFT_companion_note_passive_structural_channel.docx`
2. `SFT_arXiv_Note_V6_Unified_edit.pdf`
3. `results/01_active_only_ultratight_refinement_*`
4. `results/02_first_halo_baseline_*`
5. `results/03_expanded_halo_baseline_*`
6. `results/04_stronger_m200c_baseline_*`
7. `results/05_confirmation_ridge_*`
8. `results/06_passive_ablation_summary.txt`
9. `results/07_dm_vs_m200c_robustness_summary.txt`

## Key interpretation

The fair pipeline increasingly selected a two-channel picture:

- **Active channel**: baryonic/BH ledger stress controls the redshift evolution (`wa`).
- **Passive channel**: virialized halo occupancy (`M200c`-based) supplies the missing depth in `w0`.

Ablation shows the passive channel is necessary. Robustness testing shows the successful passive proxy is not raw dark-matter inventory (`Sum_DM_Msun`) but virialized halo structure (`Sum_M200c_Msun`).
