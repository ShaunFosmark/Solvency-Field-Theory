# SFT_MASTER_ACTION_II_DERIVATION_RC1

Generated: 2026-07-05 06:38:47

Status: RELEASE_CANDIDATE_READY_FOR_REVIEW

Main deliverables:
- SFT_Master_Action_II_Derivation_RC1.docx
- SFT_Master_Action_II_Derivation_RC1.pdf
- Solvency_Field_Theory_Master_Action_II_Derivation_RC1.md

Claim boundary: architecture earned; exact microscopic settlement operator open.
