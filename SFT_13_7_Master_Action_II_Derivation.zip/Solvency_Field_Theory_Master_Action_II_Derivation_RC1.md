# Solvency Field Theory Master Action II Derivation

## Native Write Rules, Continuum Action, and Observable Readouts

**Status:** Release candidate for review - architecture earned; microscopic settlement operator open

---

## Abstract

Master Action II assembles the current mathematical architecture of Solvency Field Theory (SFT). It does not claim a completed final microscopic Lagrangian. It states the earned structure: native write rules, an eight-term continuum action, a separate readout map, the central settlement equation candidate, recovery status, normalization watchlist, and open targets.

The compact action is:

    S_SFT = S_worldline + S_settlement + S_admissibility + S_frame + S_branch + S_port + S_rigid + S_vertices.

The central settlement equation candidate is:

    Delta ln D_set = P_coh L_eff u - Phi_relax.

This equation is the current best compact form of the settlement mechanism: coherence-weighted compounding minus local relaxation tax equals log-depth change. The action architecture is earned. The exact microscopic settlement accounting operator remains open.

# 1. The three-layer architecture

SFT is presented in three layers. Each layer has a different job.

Layer 1 - Native write rules. The native ontology is not a field theory on a background spacetime. The native objects are write histories, settlement records, and accounting rules. Layer 1 asks: given the current write record, which next writes are legal?

Layer 2 - SFT continuum action. The continuum action S_SFT is the paper-facing mathematical formulation used for calculation. It is the coarse-grained limit of discrete write accounting over many local write cycles. It is SFT's action presentation, not a translation into LambdaCDM.

Layer 3 - SM/GR/LambdaCDM correspondence. This is the translation layer connecting SFT terms and readouts to Standard Model, General Relativity, and LambdaCDM language. This layer exists for comparison with known physics. It is not the native ontology.

The firewall is essential: SM/GR language may appear in the correspondence layer, but it cannot be imported backward as the native theory.

# 2. The compact action

The Master Action II continuum action is:

    S_SFT = S_worldline + S_settlement + S_admissibility + S_frame + S_branch + S_port + S_rigid + S_vertices.        (1)

There are eight action terms.

Each term describes something the universe does:

- particles tick and write;
- settlement accumulates;
- writes must be legal;
- directional holonomy costs energy;
- branches flip;
- ports complete;
- history resists change;
- interactions satisfy protected admissibility rules.

There is no S_readouts action term. Readouts do not contribute to dynamics. They are the instruction manual for extracting predictions from S_SFT.

# 3. Derivation standard for every S term

Every action term must be documented with six checks:

1. What it is.
2. Why it must exist.
3. What it is made of.
4. What it produces.
5. Where it was earned.
6. What remains open.

No symbol without definition. No term without mechanical origin. No hidden rescue parameter.

# 4. S_worldline - worldline histories

What it is. The maintained-history sector. Particles execute local ticks at Compton cadence while satisfying the one-speed budget.

Why it must exist. Without worldline histories, nothing writes. Without writes, no settlement record forms. The worldline sector is the source of all later settlement accounting.

What it is made of. The source current is:

    J_ops^mu(x) = sum_i int d tau_i nu_C,i u_i^mu delta_g^4(x - X_i(tau_i)).        (2)

The Compton cadence is:

    nu_C = m c^2 / h.        (3)

The one-speed budget is represented by the still-open covariant constraint:

    C_1c[X_i, phi_C,i] = 0.        (4)

A schematic continuum form is:

    S_worldline = sum_i int d tau_i [ L_hist(X_i, phi_C,i, nu_C,i) + mu_i C_1c(X_i, phi_C,i) ].        (5)

What it produces. J_ops feeds settlement, admissibility, frame/branch/port sectors, vertices, and readouts.

Where it was earned. V12.11 preserved J_ops. V12.12 established the locally real particle ontology. V12.13 connected closure cadence to mass. MA2-G4 reframed the ontology as write records.

What remains open. The exact covariant C_1c and the full L_hist form.

Correspondence. Matter/source current and stress-energy translation. This is correspondence language, not native ontology.

# 5. S_settlement - settlement record

What it is. The accumulated write history at each support location: settlement depth, coherence, debt, and compounding.

Why it must exist. Writes are permanent. Without a settlement record, writes would leave no geometry. The accumulated record is what gravity, mass, expansion, participation, quantum support, and lensing read.

What it is made of. The native/readout objects include:

    W_rec, L_set, D_set, Q_set, K_set, P_coh, V_compound, Gamma_settle, Phi_relax.

The weak-field compactness readout must recover:

    C_A(E,r) = A_write E / (hbar c r).        (6)

The G-root relation is:

    G = A_write c^3 / hbar.        (7)

The central settlement equation candidate is:

    Delta ln D_set = P_coh L_eff u - Phi_relax.        (8)

with:

    L_eff = 3 pi - (1/2) ln(25/13) = 9.097814727066048.        (9)

The first term is coherence-weighted compounding. The second term is local relaxation or maintenance tax. For ratios, common Phi_relax cancels. Absolute scales require Phi_relax / H_settle.

What it produces. Gravity, compactness, clock lag, mass hierarchy ratios, galactic participation, expansion accounting, quantum support, and lensing depth.

Where it was earned. V13.1 compactness and G-root. V13.2 expansion/write-capacity readout. V12.13 L_eff. Fork08 participation. MA2-G7C minimal toy equation.

What remains open. This is the central open target: the exact microscopic settlement accounting operator K_set / A_set, the nonlinear compounding functional V_compound, the microscopic P_coh projector, Phi_relax, Gamma_settle, and H_settle.

Correspondence. Weak-field compactness, clock lag, metric/curvature translation. Einstein-Hilbert recovery is a correspondence/recovery target, not a native action import.

# 6. S_admissibility - legal write constraints

What it is. The legal-next-write gate. A mathematical next state is physical only if it is admissible.

Why it must exist. SFT is a theory of legal writes. No-overwrite, one-speed, compactness ceiling, charge conservation, branch selection, and port completion are not optional assumptions. They are write-legality conditions.

What it is made of. The schematic projector stack is:

    Pi_allowed = Pi_NOW Pi_1c Pi_clear Pi_stab Pi_C<=1/2 Pi_charge Pi_branch Pi_port Pi_vertex.        (10)

The compactness ceiling is explicit:

    Pi_C<=1/2 : C_A <= 1/2.        (11)

Below the ceiling:

    C_A = D_raw.        (12)

At C_A = 1/2, further local deepening is not allowed. Additional writes are rejected, redirected, or horizon-screened; the saturated support region grows laterally rather than deepening.

What it produces. Arrow of time, no-overwrite, black-hole horizon ceiling, conservation gates, confinement gates, and legal vertices.

Where it was earned. V12.11 support/NOW sectors. R173 clearance/stability blockers. V13.1 black-hole ceiling. MA2-G5 correction placing the ceiling in admissibility. MA2-G7B rejection of soft saturators.

What remains open. C_1c, C_clear, G_stab, and the exact horizon-redirection implementation.

Correspondence. Constraint/gauge/horizon language in standard physics. Correspondence only.

# 7. S_frame - directional holonomy / electromagnetism

What it is. The energy cost of directional settlement curvature. This is the electromagnetic continuum sector.

Why it must exist. The worldline tube has charge/framing phase theta_g. Local relabeling of theta_g cannot be physical, so a compensating connection A_mu is required. The curvature F_mu_nu is the first relabeling-invariant physical object. Smoothness and sign symmetry force the leading cost to be quadratic.

What it is made of.

    S_frame = int d^4x [ -(K_EM/4) F_mu_nu F^mu_nu + J_theta^mu A_mu ].        (13)

where:

    F_mu_nu = partial_mu A_nu - partial_nu A_mu.        (14)

What it produces. Coulomb potential, magnetic fields, radiation, Lorentz force, Maxwell dynamics, current conservation.

Where it was earned. R261F two independent phases. R262F Maxwell curvature. R262B classical EM. R262C conservation. R262D alpha location.

What remains open. K_EM, exact alpha normalization, QED loop translation.

Correspondence. U(1)_EM gauge theory / QED.

# 8. S_branch - branch transitions / weak structure

What it is. The branch/mode transition sector. This is the structural weak-sector kernel.

Why it must exist. Some interactions change closure mode. Branch-changing writes are real events, and non-commuting branch flips require a non-Abelian continuum shadow.

What it is made of. A schematic form is:

    S_branch = int d^4x [ -(K_W/4) W_a,mu,nu W_a^mu,nu + J_branch,a^mu W_a,mu + selector terms ].        (15)

The access selector is:

    s = epsilon_U eta_C chi.        (16)

What it produces. Weak branch transitions, parity/chirality structure, W/Z-like readouts.

Where it was earned. R265F weak kernel and R268F native action stack.

What remains open. Weak coupling constants, Weinberg angle, W/Z masses, mixing matrices, decay rates, quantitative electroweak completion.

Correspondence. SU(2)_L x U(1)_Y electroweak theory.

# 9. S_port - port topology / strong structure

What it is. The port/topology completion sector. This is the structural strong-sector kernel.

Why it must exist. Fractional winding addresses are incomplete. A single quark's address is not externally admissible. Legal strong-sector writes require complete port/color bundles.

What it is made of. A schematic form is:

    S_port = int d^4x [ -(K_C/4) G_A,mu,nu G_A^mu,nu + port-completion / singlet projectors ].        (17)

What it produces. Color completeness, confinement topology, and hadron admissibility.

Where it was earned. R264F strong topology and R268F native action stack.

What remains open. Full SU(3) dynamics, gluon self-interactions, asymptotic freedom, strong coupling, hadron spectrum.

Correspondence. SU(3)_c color gauge theory / QCD.

# 10. S_rigid - frame-rigidity loading

What it is. The frame-rigidity and history-maintenance sector.

Why it must exist. Written frame, branch, and history commitments cost energy to maintain. That cost contributes to mass and rigidity.

What it is made of. A schematic form is:

    S_rigid = int d^4x [ - V_rigid(Phi_relax, D_set, Q_set, frame commitments) ].        (18)

What it produces. Absolute mass-scale target, W/Z mass target, rigidity resonance target, possible participation/running targets.

Where it was earned. R266F mass/rigidity mechanism, R268F native stack, V12.13 reinforcement/relaxation bridge.

What remains open. H_settle, Phi_relax, Gamma_settle, absolute mass scale, and rigidity resonance derivation.

Correspondence. Higgs-like frame-maintenance/rigidity sector. This is structural correspondence, not an imported Higgs field ontology.

# 11. S_vertices - interaction vertices

What it is. The legal interaction-write sector.

Why it must exist. A scattering, decay, pair-production, or annihilation event is a common-write event. A vertex exists only if all relevant legality rules are simultaneously satisfied.

What it is made of.

    Pi_vertex = Pi_charge Pi_momentum Pi_branch Pi_port Pi_settlement.        (19)

Equivalently, an interaction is admissible only if charge/winding, settlement-momentum, branch selection, port completion, support overlap, and no-overwrite are all preserved.

What it produces. Conservation laws, selection rules, forbidden transitions, and the perturbative vertex translation.

Where it was earned. R261.5F, R262C, R264F, R265F, R260B-R269F.

What remains open. Exact perturbative vertex factors, coupling constants, loop translation, cross sections, decay rates.

Correspondence. Feynman-rule and QFT vertex language.

# 12. The central settlement equation

The current strongest compact candidate for the settlement accounting law is:

    Delta ln D_set = P_coh L_eff u - Phi_relax.        (20)

Three terms, one equation.

P_coh L_eff u is coherence-weighted compounding. P_coh measures recurrent temporal structure in the source history, expected natively as autocorrelation or spectral recurrence of J_ops. L_eff is the compounding gain per closure cycle from the 3:2 sector structure. u is the mode/support coordinate.

Phi_relax is local relaxation or support-maintenance tax. It is not simply H / nu_C. It must be derived from local support capacity and the microscopic settlement-response operator H_settle.

This equation is not yet derived from first principles. It is the minimal functional form that currently satisfies all known structural constraints: particle mass ratios, galactic participation, weak-field compactness, hard black-hole ceiling, and expansion accounting.

# 13. Observable readouts

Readouts are projections of S_SFT. They are not action terms.

1. Gravity. Scalar settlement depth gives compactness:

    C_A = A_write E / (hbar c r),    a = -c^2 grad C_A.

2. Expansion. Global write rate over boundary capacity:

    H = Ndot_write / I_write.

3. Mass. Per-worldline settlement recurrence:

    Delta ln D_set = P_coh L_eff u - Phi_relax.

4. Participation. Coherence projection:

    lambda_eff = sum_j w_j p_j lambda_j,
    p_gas = V_src^2 / (V_src^2 + 3 sigma_1D^2).

5. Electromagnetism. Directional curvature from S_frame gives Coulomb, Lorentz, and radiation readouts.

6. Strong binding. Port completion topology gives confinement and color-complete composites.

7. Weak transitions. Branch curvature and selector structure give weak transition readouts.

8. Frame-rigidity masses. Historical loading from S_rigid targets W/Z and rigidity-resonance masses.

9. Quantum support. Settlement intensity and admissibility support wavefunction, Born-rule, tunneling, uncertainty, exclusion, and Bell-contextual readouts at their current conditional/partial status.

10. Lensing. Path-integrated settlement depth is reserved for a future lensing export after normalization.

# 14. SM/GR/LambdaCDM correspondence

The correspondence layer translates SFT terms and readouts into established physics language. It is not the native theory.

S_worldline corresponds to matter/source current and stress-energy translation.

S_settlement corresponds to weak-field compactness, clock lag, metric/curvature translation, and gravity recovery targets.

S_admissibility corresponds to constraints, legality conditions, conservation gates, and horizon conditions.

S_frame corresponds to U(1)_EM / QED structure; the form is earned, the normalization is open.

S_branch corresponds to SU(2)-like weak branch structure; quantitative electroweak completion is open.

S_port corresponds to SU(3)-like color topology; full QCD dynamics are open.

S_rigid corresponds structurally to Higgs-like frame-maintenance and mass loading; the microscopic operator is open.

S_vertices corresponds to Feynman-rule / interaction-vertex translation; exact factors are open.

# 15. Recovery audit

MA2-G6 verdict:

    STRUCTURAL PASS WITH OPEN BLOCKERS.

Meaning:

- earned sectors recover earned results;
- structural sectors remain structural;
- partial sectors remain partial;
- open targets are named rather than hidden;
- no fake-complete formulas were inserted.

The major blockers are:

    C_1c, C_clear, G_stab, K_set, P_coh, V_compound,
    Phi_relax / Gamma_settle / H_settle, C_1/2, K_EM,
    QCD/EW quantitative completion.

# 16. Normalization watchlist

Two normalization families remain important but not frozen.

Alpha framework. The 1/(16 pi^2) directional projection framework is structurally located and repeatedly supported. The exact microscopic alpha normalization and running exponent remain open.

Pi_lambda candidate. The candidate:

    Pi_lambda = 1/(6 pi^2)

survives as a strong watchlist item because:

    1 + L_eff/(6 pi^2) = 1.153633559451,

close to the rough global lambda* about 1.156.

It is not derived. It remains in tension with the endpoint / scale-height value lambda_star about 1.1994. The required bridge factor must be earned, not inserted.

Killed shortcuts:

- lambda = 1 + L_eff;
- simple N_eff^(1/4)/(6 pi^2) correction;
- claiming 6 pi^2 from one post-hoc decomposition;
- using scale-height correction as a fit factor.

# 17. Open targets

The open targets collapse into a few deep cores.

Core A - compounding/coherence/saturation. This includes V_compound, K_set, P_coh, G_stab, and C_A ceiling mechanics. The question is: what is the nonlinear settlement accounting law from Compton scale to galactic and cosmological scale?

Core B - relaxation/rigidity/normalization. This includes Gamma_settle, Phi_relax, H_settle, K_EM, absolute mass scale, and rigidity masses. The question is: what is the microscopic settlement-response operator?

Formalism gaps. C_1c and C_clear need explicit action-level enforcement.

Downstream completion. Full QCD and electroweak quantitative dynamics require the operator cores.

Future tests. SPARC rerun with lambda = 1 + L_eff/(6 pi^2), scale-height bridge reconstruction, lensing export, and horizon redirection mechanics.

# 18. Final statement

Master Action II is not the final completion of SFT.

It is the current earned architecture:

    native write rules -> S_SFT -> observable readouts -> SM/GR/LambdaCDM correspondence.

The compact action is:

    S_SFT = S_worldline + S_settlement + S_admissibility + S_frame + S_branch + S_port + S_rigid + S_vertices.        (21)

The central settlement equation candidate is:

    Delta ln D_set = P_coh L_eff u - Phi_relax.        (22)

Eight terms. One equation. Ten readouts.

Architecture earned. Operator open.

# Acknowledgments and provenance

The MA2 gate program was developed collaboratively across the SFT research workflow. The G0-G8 audit/drafting chain was assembled with ChatGPT/5.5. The three-layer presentation, readout/action separation, and operator-investigation framing were cross-checked against Opus-style review notes. The SPARC participation thread and Fork08 readout are preserved as separate empirical/numerical track inputs.

This document should be read as a research architecture and derivation scaffold, not a claim of final physical completion.
