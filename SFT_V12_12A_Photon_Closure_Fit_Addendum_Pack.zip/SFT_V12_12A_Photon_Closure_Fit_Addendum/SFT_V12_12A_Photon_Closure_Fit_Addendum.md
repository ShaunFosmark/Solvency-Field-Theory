# SFT V12.12A - Photon Closure-Fit Addendum

## The 4pi Compton-Wavelength Bridge

Generated: 2026-06-16T22:43:42Z

### Verdict

```text
PASS_PHOTON_COMPTON_WAVELENGTH_EQUALS_FERMION_4PI_CLOSURE_PATH
SETTLEMENT_FORCE_REMAINS_OPEN
```

---

## Abstract

This addendum strengthens the V12.12 particle program by identifying a precise geometric bridge between the open photon branch and the closed spin-half fermion branch. For any spin-half branch obeying

\[
r_{\rm spin}=\frac{\hbar}{2mc},
\]

a photon with rest-energy scale

\[
E_\gamma=mc^2
\]

has wavelength

\[
\lambda_\gamma=\frac{hc}{E_\gamma}=\frac{h}{mc}.
\]

But

\[
4\pi r_{\rm spin}
=
4\pi\frac{\hbar}{2mc}
=
\frac{h}{mc}.
\]

Therefore,

\[
\boxed{\lambda_\gamma(E=mc^2)=4\pi r_{\rm spin}}.
\]

The photon does not merely have enough energy. Its open longitudinal phase scale exactly matches the full \(4\pi\) spinor closure path of the corresponding fermion branch. Formation is therefore sharpened as a wavelength-to-closure matching condition. This does not derive the microscopic settlement force that stabilizes closure. That force remains open.

---

# 1. The identity

For a V12.12 spin-half branch,

\[
r_{\rm spin}=\frac{\hbar}{2mc}.
\]

The ordinary spatial length of one \(2\pi\) loop is

\[
2\pi r_{\rm spin}
=
2\pi\frac{\hbar}{2mc}
=
\frac{h}{2mc}
=
\frac{\lambda_C}{2}.
\]

Thus one ordinary circular turn is half the Compton wavelength.

The full spinor closure is \(4\pi\), so the closure path length is

\[
L_{4\pi}
=
4\pi r_{\rm spin}
=
4\pi\frac{\hbar}{2mc}
=
\frac{h}{mc}
=
\lambda_C.
\]

For a photon at rest-energy scale \(E_\gamma=mc^2\),

\[
\lambda_\gamma
=
\frac{hc}{E_\gamma}
=
\frac{h}{mc}
=
\lambda_C.
\]

Therefore,

\[
\boxed{\lambda_\gamma=L_{4\pi}=4\pi r_{\rm spin}}.
\]

This is the V12.12A closure-fit identity.

---

# 2. Electron numerical closure

For the electron,

\[
m_ec^2=0.51099895\ \mathrm{MeV}.
\]

The rest-energy photon wavelength is

\[
\lambda_\gamma
\approx
2.426310239e-12\ \mathrm{m}
=
2426.310\ \mathrm{fm}.
\]

The electron spin radius is

\[
r_{\rm spin,e}
=
\frac{\hbar}{2m_ec}
\approx
1.930796339e-13\ \mathrm{m}
=
193.080\ \mathrm{fm}.
\]

The full spinor closure path is

\[
4\pi r_{\rm spin,e}
\approx
2.426310237e-12\ \mathrm{m}
=
2426.310\ \mathrm{fm}.
\]

Thus,

```text
0.511 MeV photon wavelength
=
electron full 4pi spinor closure path
```

within numerical precision.

The required path curvature is

\[
\kappa_{\rm path}
=
\frac{1}{r_{\rm spin,e}}
\approx
5.179210e+12\ \mathrm{m}^{-1}.
\]

This is path curvature: how tightly the real c-speed energy must turn. It is not the same as ordinary weak-field spacetime curvature.

---

# 3. Pair-production wording

Free electron-positron pair production requires total center-of-momentum energy

\[
2m_ec^2
\approx
1.022\ \mathrm{MeV}.
\]

Therefore the conservation-safe V12.12A statement is:

```text
Two head-on photons at the electron rest-energy scale
can supply two matched 4pi closure lengths:
one for the electron branch
and one for the positron branch.
```

A single isolated photon cannot become one free electron in empty space. That remains forbidden by R183 momentum-conservation reasoning.

For two null inputs,

\[
M^2c^4=2E_1E_2(1-\cos\theta).
\]

For equal head-on photons with \(E_1=E_2=mc^2\) and \(\theta=\pi\),

\[
M=2m.
\]

That is exactly the pair threshold.

---

# 4. Mechanical interpretation

In V12.12 language:

```text
Open photon branch:
    real energy at c with longitudinal phase scale lambda_gamma

Closed fermion branch:
    same energy folded into a 4pi spinor maintenance path

Closure fit:
    lambda_gamma = L_4pi
```

Formation is not only energy accounting. It is geometric fit:

```text
open phase length
matches
closed spinor maintenance length
```

The photon is not "crammed" into an arbitrary orbit. At the rest-energy scale of the branch, its wavelength already equals the full spinor closure path.

---

# 5. What this addendum does not solve

The closure-fit identity explains the geometric compatibility between photon and fermion branch.

It does **not** derive the microscopic settlement force that keeps the branch closed.

The naive Newtonian self-energy diagnostic gives

\[
E_G\sim \frac{Gm_e^2}{r_{\rm spin,e}}
\approx
2.868e-58\ \mathrm{J}.
\]

The electron rest energy is

\[
m_ec^2\approx 8.187e-14\ \mathrm{J}.
\]

The ratio is

\[
\frac{E_G}{m_ec^2}
\approx
3.504e-45.
\]

So ordinary weak-field gravity is short by a factor of about

\[
2.854e+44.
\]

No factor-of-two relativistic correction can fix this. Therefore:

```text
The 4pi identity solves the closure-fit geometry.

The stabilizing settlement law remains the deepest open problem.
```

The R183 stability targets remain:

\[
E_{\rm env}(r_0)=0,
\]

\[
E_{\rm env}'(r_0)=\frac{Jc}{r_0^2},
\]

\[
E_{\rm env}''(r_0)>-\frac{2Jc}{r_0^3}.
\]

---

# 6. General branch table

The identity is not electron-specific. It follows for any spin-half branch with

\[
r_{\rm spin}=\frac{\hbar}{2mc}.
\]

The numerical examples below are branch-scale illustrations.

| branch   |   rest_energy_MeV |   photon_wavelength_at_E_equals_mc2_m |   spin_radius_hbar_over_2mc_m |   4pi_spinor_closure_path_m |   lambda_minus_4pi_path_fraction |   path_curvature_1_over_r_spin_m_inv |
|:---------|------------------:|--------------------------------------:|------------------------------:|----------------------------:|---------------------------------:|-------------------------------------:|
| electron |          0.510999 |                           2.42631e-12 |                   1.9308e-13  |                 2.42631e-12 |                      6.12719e-10 |                          5.17921e+12 |
| muon     |        105.658    |                           1.17344e-14 |                   9.33797e-16 |                 1.17344e-14 |                      6.12719e-10 |                          1.0709e+15  |
| tau      |       1776.86     |                           6.97771e-16 |                   5.55269e-17 |                 6.97771e-16 |                      6.12719e-10 |                          1.80093e+16 |

---

# 7. Claim boundary matrix

| topic                      | claim                                                                                                              | status                        | boundary                                                                                                        |
|:---------------------------|:-------------------------------------------------------------------------------------------------------------------|:------------------------------|:----------------------------------------------------------------------------------------------------------------|
| Closure-fit identity       | For any spin-half branch with r_spin=hbar/(2mc), a photon with E=mc^2 has lambda=h/(mc)=4pi r_spin.                | DERIVED_IDENTITY              | Kinematic/geometric identity only; not a full formation amplitude.                                              |
| Electron threshold meaning | A 0.511 MeV photon has wavelength equal to the electron branch's full 4pi spinor closure path.                     | SIGNATURE_RESULT              | Free pair production still needs total center-of-momentum energy 2m_e c^2 and conservation-compatible geometry. |
| Pair-production threshold  | Two head-on photons of electron rest-energy scale can supply two matched closure paths, one for e- and one for e+. | CONSERVATION_SAFE             | Single isolated photon cannot become one free massive particle in empty space.                                  |
| 2pi vs 4pi                 | One ordinary 2pi spatial loop is lambda_C/2; full spinor closure is 4pi and equals lambda_C.                       | PRECISION_LOCK                | Do not call the ordinary circumference the full Compton wavelength.                                             |
| Photon extent              | Wavelength is the longitudinal phase/closure-fit scale.                                                            | REALITY_LOCKED_INTERPRETATION | Do not claim every photon wavepacket has physical length exactly one wavelength.                                |
| Settlement force           | The identity explains geometric fit, not the stabilizing force.                                                    | OPEN                          | Microscopic settlement law remains the deep open problem.                                                       |
| Ordinary gravity           | Naive Gm^2/r is ~45 orders too weak for electron closure.                                                          | NEGATIVE_RESULT               | No factor-of-two ultrarelativistic correction can fix this.                                                     |

---

# 8. Equation index

| id                 | equation                              | meaning                                                    |
|:-------------------|:--------------------------------------|:-----------------------------------------------------------|
| spin_radius        | r_spin = hbar/(2mc)                   | Fermion branch centerline radius from V12.12/R176.         |
| photon_wavelength  | lambda_gamma(E=mc^2)=hc/(mc^2)=h/(mc) | Rest-energy photon wavelength.                             |
| closure_fit        | lambda_gamma(E=mc^2)=4pi r_spin       | Signature closure-fit identity.                            |
| ordinary_loop      | 2pi r_spin=lambda_C/2                 | One ordinary spatial loop is half the Compton wavelength.  |
| full_spinor_path   | 4pi r_spin=lambda_C                   | Full spinor closure path equals the Compton wavelength.    |
| path_curvature     | kappa_path=1/r_spin=2mc/hbar          | Path curvature required for closed c-speed branch.         |
| two_null_threshold | M^2 c^4=2E1E2(1-cos theta)            | R183 formation guardrail for two null inputs.              |
| head_on_equal      | E1=E2=mc^2, theta=pi => M=2m          | Two equal head-on photons produce total invariant mass 2m. |
| naive_gravity      | E_G ~ Gm^2/r_spin                     | Ordinary weak-field self-energy diagnostic.                |

---

# 9. Addendum statement for V12.12

```text
At the rest-energy scale of a spin-half branch,
the open photon wavelength equals the full 4pi closed spinor path.

The photon-to-particle threshold is therefore a closure-fit condition:
open phase length matches closed maintenance length.

This identity explains geometric fit,
not the microscopic settlement force.
```

This is the V12.12A photon closure-fit bridge.
