# sft_sparc_rotmod_test_v1.py
#
# Purpose:
#   Full SPARC ROTMOD first-pass comparison of candidate interpolating functions.
#
#   This uses the per-galaxy ROTMOD files instead of only the RAR summary table.
#
# What it does:
#   1) loads all *_rotmod.dat files in a folder
#   2) parses radius, Vobs, eVobs, Vgas, Vdisk, Vbul
#   3) builds baryonic acceleration:
#        Vbar^2 = Vgas*|Vgas| + Yd*Vdisk*|Vdisk| + Yb*Vbul*|Vbul|
#   4) predicts V(r) for:
#        - exp_benchmark
#        - solvency_quad
#        - simple
#        - standard
#   5) compares models with:
#        - fixed global M/L
#        - floating global M/L
#        - fixed or floating a0
#        - floating lambda for solvency_quad
#
# Outputs:
#   ./sft_sparc_rotmod_test_v1/
#
# Notes:
#   - This is a first-pass population fit, not a full per-galaxy bespoke fit.
#   - It uses global disk and bulge M/L values for fairness and speed.
#   - Place the SPARC ROTMOD files in a local folder and update ROTMOD_DIR.
#
# Run:
#   python sft_sparc_rotmod_test_v1.py

import os
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
# USER SETTINGS
# ============================================================
ROTMOD_DIR = r"./sparc_database"  # update to your local SPARC ROTMOD folder
YDISK_FIXED = 0.5
YBULGE_FIXED = 0.7
MAX_FILES = None

# ============================================================
# OUTPUT
# ============================================================
BASE_DIR = os.getcwd()
OUTDIR = os.path.join(BASE_DIR, "sft_sparc_rotmod_test_v1")
os.makedirs(OUTDIR, exist_ok=True)

# ============================================================
# CONSTANTS
# ============================================================
KPC_M = 3.085677581491367e19
C = 2.99792458e8
MPC_M = 3.085677581491367e22
H0_KM_S_MPC = 67.74
H0 = H0_KM_S_MPC * 1000.0 / MPC_M
A0_SFT = C * H0 / (2.0 * math.pi)

# ============================================================
# INTERPOLATING FUNCTIONS
# ============================================================
def nu_exp(x):
    x = np.asarray(x, dtype=float)
    return 1.0 / np.maximum(1.0 - np.exp(-np.sqrt(np.maximum(x, 1e-300))), 1e-300)

def nu_solvency_quad(x, lam):
    x = np.asarray(x, dtype=float)
    return np.sqrt(1.0 + lam / np.maximum(x, 1e-300))

def nu_simple(x):
    x = np.asarray(x, dtype=float)
    return 0.5 * (1.0 + np.sqrt(1.0 + 4.0 / np.maximum(x, 1e-300)))

def nu_standard(x):
    x = np.asarray(x, dtype=float)
    return np.sqrt(0.5 + 0.5 * np.sqrt(1.0 + 4.0 / np.maximum(x, 1e-300) ** 2))

def gpred_from_model(gbar, a0, model_name, lam=2.0):
    x = gbar / a0
    if model_name == "exp_benchmark":
        nu = nu_exp(x)
    elif model_name == "solvency_quad":
        nu = nu_solvency_quad(x, lam)
    elif model_name == "simple":
        nu = nu_simple(x)
    elif model_name == "standard":
        nu = nu_standard(x)
    else:
        raise ValueError(f"Unknown model: {model_name}")
    return gbar * nu

# ============================================================
# FILE PARSING
# ============================================================
def numeric_tokens(line):
    vals = []
    for tok in line.strip().split():
        try:
            vals.append(float(tok))
        except ValueError:
            pass
    return vals

def parse_rotmod_file(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            vals = numeric_tokens(line)
            if len(vals) >= 5:
                rows.append(vals)

    if len(rows) == 0:
        return None

    parsed = []
    for vals in rows:
        r = vals[0]
        vobs = vals[1] if len(vals) > 1 else np.nan
        evobs = vals[2] if len(vals) > 2 else np.nan
        vgas = vals[3] if len(vals) > 3 else 0.0
        vdisk = vals[4] if len(vals) > 4 else 0.0
        vbul = vals[5] if len(vals) > 5 else 0.0
        parsed.append([r, vobs, evobs, vgas, vdisk, vbul])

    df = pd.DataFrame(parsed, columns=["r_kpc", "vobs_kms", "evobs_kms", "vgas_kms", "vdisk_kms", "vbul_kms"])
    return df

def load_all_rotmods(folder):
    files = [f for f in os.listdir(folder) if f.lower().endswith("_rotmod.dat")]
    files = sorted(files)
    if MAX_FILES is not None:
        files = files[:MAX_FILES]

    all_dfs = []
    bad_files = []

    for fname in files:
        path = os.path.join(folder, fname)
        try:
            df = parse_rotmod_file(path)
            if df is None or len(df) == 0:
                bad_files.append(fname)
                continue
            df["galaxy_file"] = fname
            all_dfs.append(df)
        except Exception:
            bad_files.append(fname)

    if len(all_dfs) == 0:
        raise RuntimeError("No usable ROTMOD files were parsed.")

    big = pd.concat(all_dfs, ignore_index=True)
    return big, files, bad_files

# ============================================================
# BUILD GLOBAL DATA ARRAYS
# ============================================================
rotmod_df, used_files, bad_files = load_all_rotmods(ROTMOD_DIR)

for c in ["r_kpc", "vobs_kms", "evobs_kms", "vgas_kms", "vdisk_kms", "vbul_kms"]:
    rotmod_df[c] = pd.to_numeric(rotmod_df[c], errors="coerce")

rotmod_df = rotmod_df[np.isfinite(rotmod_df["r_kpc"]) & np.isfinite(rotmod_df["vobs_kms"])]
rotmod_df = rotmod_df[rotmod_df["r_kpc"] > 0]
rotmod_df = rotmod_df[rotmod_df["vobs_kms"] > 0].copy()

if "evobs_kms" not in rotmod_df.columns:
    rotmod_df["evobs_kms"] = np.nan

median_err = np.nanmedian(rotmod_df["evobs_kms"].values)
if not np.isfinite(median_err) or median_err <= 0:
    median_err = 5.0
rotmod_df["evobs_kms"] = rotmod_df["evobs_kms"].fillna(median_err)
rotmod_df.loc[rotmod_df["evobs_kms"] <= 0, "evobs_kms"] = median_err

r_m = rotmod_df["r_kpc"].values * KPC_M
vobs = rotmod_df["vobs_kms"].values
evobs = rotmod_df["evobs_kms"].values
vgas = rotmod_df["vgas_kms"].fillna(0.0).values
vdisk = rotmod_df["vdisk_kms"].fillna(0.0).values
vbul = rotmod_df["vbul_kms"].fillna(0.0).values
gal_names = rotmod_df["galaxy_file"].values

# ============================================================
# MODEL EVALUATION
# ============================================================
def compute_vbar2_kms2(ydisk, ybulge):
    return (
        vgas * np.abs(vgas) +
        ydisk * vdisk * np.abs(vdisk) +
        ybulge * vbul * np.abs(vbul)
    )

def evaluate_model(model_name, ydisk, ybulge, a0, lam=2.0):
    vbar2_kms2 = compute_vbar2_kms2(ydisk, ybulge)

    mask = np.isfinite(vbar2_kms2) & (vbar2_kms2 > 0) & np.isfinite(vobs) & (vobs > 0) & np.isfinite(evobs) & (evobs > 0)
    if not np.any(mask):
        return None

    vbar2_m2s2 = vbar2_kms2[mask] * 1.0e6
    gbar = vbar2_m2s2 / r_m[mask]

    gpred = gpred_from_model(gbar, a0, model_name, lam=lam)
    vpred = np.sqrt(np.maximum(gpred * r_m[mask], 1e-300)) / 1000.0

    resid_v = vobs[mask] - vpred
    chi2 = float(np.sum((resid_v / evobs[mask]) ** 2))
    chi2_dof = chi2 / max(len(vpred) - 1, 1)

    log_resid = np.log10(vobs[mask]) - np.log10(np.maximum(vpred, 1e-300))
    rms_logv = float(np.sqrt(np.mean(log_resid ** 2)))
    mad_logv = float(np.median(np.abs(log_resid)))
    bias_logv = float(np.mean(log_resid))

    high = gbar >= 1e-10
    low = gbar < 1e-10
    high_bias = float(np.mean(log_resid[high])) if np.any(high) else np.nan
    low_bias = float(np.mean(log_resid[low])) if np.any(low) else np.nan

    return {
        "chi2": chi2,
        "chi2_dof_proxy": chi2_dof,
        "rms_log10_v": rms_logv,
        "mad_log10_v": mad_logv,
        "bias_log10_v": bias_logv,
        "bias_high_gbar": high_bias,
        "bias_low_gbar": low_bias,
        "n_points": int(np.sum(mask)),
        "mask": mask,
        "vpred": vpred,
        "gbar": gbar,
    }

# ============================================================
# FITTING
# ============================================================
def fit_model(model_name, float_ml=False, float_a0=False, float_lam=False):
    if float_ml:
        ydisk_grid = np.linspace(0.2, 1.0, 9)
        ybulge_grid = np.linspace(0.2, 1.4, 9)
    else:
        ydisk_grid = [YDISK_FIXED]
        ybulge_grid = [YBULGE_FIXED]

    if float_a0:
        a0_grid = np.geomspace(A0_SFT / 3.0, A0_SFT * 3.0, 25)
    else:
        a0_grid = [A0_SFT]

    if model_name == "solvency_quad" and float_lam:
        lam_grid = np.geomspace(0.25, 4.0, 17)
    else:
        lam_grid = [2.0]

    best = None
    n_eval = 0

    for yd in ydisk_grid:
        for yb in ybulge_grid:
            for a0 in a0_grid:
                for lam in lam_grid:
                    n_eval += 1
                    sc = evaluate_model(model_name, yd, yb, a0, lam=lam)
                    if sc is None:
                        continue

                    row = {
                        "model": model_name,
                        "ydisk_fit": float(yd),
                        "ybulge_fit": float(yb),
                        "a0_fit_m_s2": float(a0),
                        "lambda_fit": float(lam),
                        **{k: v for k, v in sc.items() if k not in ["mask", "vpred", "gbar"]},
                    }

                    if best is None or row["chi2_dof_proxy"] < best["chi2_dof_proxy"]:
                        best = row

    if best is not None:
        best["n_grid_eval"] = n_eval
    return best

models = ["exp_benchmark", "solvency_quad", "simple", "standard"]

fixed_rows = []
for model in models:
    print(f"[run] fixed ML / fixed a0 / model={model}")
    fixed_rows.append(fit_model(model, float_ml=False, float_a0=False, float_lam=False))

float_ml_rows = []
for model in models:
    print(f"[run] floating ML / fixed a0 / model={model}")
    float_ml_rows.append(fit_model(model, float_ml=True, float_a0=False, float_lam=False))

float_all_rows = []
for model in models:
    print(f"[run] floating ML / floating a0 / model={model}")
    float_all_rows.append(fit_model(model, float_ml=True, float_a0=True, float_lam=(model == "solvency_quad")))

fixed_df = pd.DataFrame(fixed_rows)
fixed_df["fit_mode"] = "fixed_ML_fixed_a0"

float_ml_df = pd.DataFrame(float_ml_rows)
float_ml_df["fit_mode"] = "float_ML_fixed_a0"

float_all_df = pd.DataFrame(float_all_rows)
float_all_df["fit_mode"] = "float_ML_float_a0"

summary_df = pd.concat([fixed_df, float_ml_df, float_all_df], ignore_index=True)
summary_df = summary_df.sort_values(["fit_mode", "chi2_dof_proxy"]).reset_index(drop=True)
summary_df.to_csv(os.path.join(OUTDIR, "rotmod_fit_summary.csv"), index=False)

pred_rows = []
for _, row in float_all_df.iterrows():
    model = row["model"]
    yd = row["ydisk_fit"]
    yb = row["ybulge_fit"]
    a0 = row["a0_fit_m_s2"]
    lam = row["lambda_fit"]

    sc = evaluate_model(model, yd, yb, a0, lam=lam)
    if sc is None:
        continue

    mask = sc["mask"]
    vpred = sc["vpred"]
    gbar = sc["gbar"]

    tmp = pd.DataFrame({
        "model": model,
        "galaxy_file": gal_names[mask],
        "r_kpc": rotmod_df["r_kpc"].values[mask],
        "vobs_kms": vobs[mask],
        "evobs_kms": evobs[mask],
        "vpred_kms": vpred,
        "gbar_m_s2": gbar,
        "log_resid_v": np.log10(vobs[mask]) - np.log10(np.maximum(vpred, 1e-300)),
    })
    pred_rows.append(tmp)

pred_df = pd.concat(pred_rows, ignore_index=True)
pred_df.to_csv(os.path.join(OUTDIR, "rotmod_bestfit_predictions.csv"), index=False)

plt.figure(figsize=(10, 6))
for _, row in float_all_df.iterrows():
    model = row["model"]
    sub = pred_df[pred_df["model"] == model]
    plt.scatter(sub["gbar_m_s2"], sub["log_resid_v"], s=5, alpha=0.25, label=model)

plt.xscale("log")
plt.axhline(0.0, linestyle="--")
plt.xlabel("gbar [m/s^2]")
plt.ylabel("log10(Vobs) - log10(Vpred)")
plt.title("SPARC ROTMOD residuals by model")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUTDIR, "rotmod_residuals_by_model.png"), dpi=160)
plt.close()

lines = []
lines.append("SFT SPARC ROTMOD test V1")
lines.append("=" * 80)
lines.append(f"ROTMOD directory: {ROTMOD_DIR}")
lines.append(f"Files parsed: {len(used_files)}")
lines.append(f"Bad/unparsed files: {len(bad_files)}")
lines.append(f"Total data points used: {len(rotmod_df)}")
lines.append("")
if len(bad_files) > 0:
    lines.append("[Bad/unparsed files]")
    lines.extend(bad_files[:50])
    lines.append("")

lines.append("Models tested:")
lines.append("  - exp_benchmark : 1 / (1 - exp(-sqrt(x)))")
lines.append("  - solvency_quad : sqrt(1 + lambda/x)")
lines.append("  - simple        : MOND simple control")
lines.append("  - standard      : MOND standard control")
lines.append("")
lines.append("[Fixed ML, fixed a0]")
lines.append(fixed_df.sort_values("chi2_dof_proxy").to_string(index=False))
lines.append("")
lines.append("[Floating global ML, fixed a0]")
lines.append(float_ml_df.sort_values("chi2_dof_proxy").to_string(index=False))
lines.append("")
lines.append("[Floating global ML, floating a0]")
lines.append(float_all_df.sort_values("chi2_dof_proxy").to_string(index=False))

with open(os.path.join(OUTDIR, "rotmod_fit_summary.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("\n".join(lines))
print(f"\nSaved outputs to: {OUTDIR}")
