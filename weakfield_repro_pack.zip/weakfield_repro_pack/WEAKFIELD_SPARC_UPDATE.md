# V8 Weak-Field SPARC Update

## Weak-field sector: derived variable, derived scale, constrained transition family

The weak-field sector can now be stated more strongly and more honestly than in earlier drafts.

The local screen-energy formulation identifies the transition variable directly. For a spherical screen of area \(A=4\pi r^2\), entropy \(S=A/(4\ell_P^2)\), and Unruh temperature \(T=\hbar g/(2\pi c k_B)\), the screen energy scale is \(E_{\rm scr}=2TS\). Evaluated on the baryonic Newtonian field \(g_{\rm bar}=GM(r)/r^2\), this reproduces the enclosed rest-energy scale. The resulting local control variable is therefore not borrowed phenomenology but

\[
x \equiv \frac{E_{\rm scr}(g_{\rm bar})}{E_{\rm scr}(a_{\rm SFT})} = \frac{g_{\rm bar}}{a_{\rm SFT}},
\]

with

\[
a_{\rm SFT} = \frac{cH_0}{2\pi}.
\]

This is the first major closure of the weak-field attack surface: the transition variable and acceleration scale are internal to the framework.

The next question is the shape of the transition. A minimal quadrature response law motivates the solvency family

\[
\nu(x) = \sqrt{1 + \frac{\lambda}{x}},
\qquad
 g_{\rm eff} = \nu(x)\,g_{\rm bar},
\]

which reproduces the Newtonian limit at high acceleration and the deep weak-field scaling \(g_{\rm eff}\propto \sqrt{g_{\rm bar} a_{\rm SFT}}\) at low acceleration. However, the exact value of \(\lambda\) is not fixed by the present derivation.

This distinction is now constrained directly by data.

In the RAR-level SPARC test, the rigid quadrature form with \(\lambda=2\) was too stiff, while a softened solvency family remained competitive once \(a_0\) and \(\lambda\) were allowed to float. The stronger result came from the full SPARC ROTMOD population test across 175 galaxies and 3389 data points. In that test, the rigid \(\lambda=2\) form was again too stiff, but the solvency family with floated global mass-to-light ratios, floated \(a_0\), and floated \(\lambda\) remained viable. The best-fit solvency-family parameters were

\[
a_0 \approx 1.05\times 10^{-10}\,{\rm m\,s^{-2}},
\qquad
\lambda \approx 1.19,
\]

while the best phenomenological benchmark still fit somewhat better overall. In other words, the data do not support the rigid quadrature coefficient as an exact prediction, but they do support the underlying solvency-family structure and recover an acceleration scale that lands directly on the SFT value within the resolution of the population fit.

The correct weak-field claim is therefore now much sharper:

> SFT derives the transition variable \(x=g_{\rm bar}/a_{\rm SFT}\) and the acceleration scale \(a_{\rm SFT}=cH_0/(2\pi)\) from the local screen/count formulation. SPARC data then constrain the remaining open part of the weak-field sector: the exact transition profile. A rigid quadrature form is too stiff, but the softened solvency family remains reasonably competitive in full SPARC ROTMOD tests and is constrained to \(\lambda\approx 1.19\).

This is not yet a full derivation of the exact interpolating function. But it is no longer accurate to say that the weak-field sector is merely borrowing MOND phenomenology. The transition variable is internal, the scale is internal, the functional family is theory-motivated, and the data have reduced the remaining freedom to a single coefficient.
