# sft_sparc_rar_test_v4.py
#
# Purpose:
#   Valid first-pass SPARC/RAR test for candidate interpolating functions
#   using the "Data Behind Figure 2" table.
#
# File format:
#   col1 = gbar   = log10 baryonic acceleration [m/s^2]
#   col2 = e_gbar
#   col3 = gobs   = log10 observed acceleration [m/s^2]
#   col4 = e_gobs
#
# Outputs:
#   ./sft_sparc_rar_test_v4/
#
# Run:
#   python sft_sparc_rar_test_v4.py

import os
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

DATA_FILE = "RAR_All_Data.txt"

BASE_DIR = os.getcwd()
OUTDIR = os.path.join(BASE_DIR, "sft_sparc_rar_test_v4")
os.makedirs(OUTDIR, exist_ok=True)

# ============================================================
# Load the fixed-format RAR table
# ============================================================
def load_rar_table(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Could not find {path}")

    rows = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            parts = s.split()
            if len(parts) != 4:
                continue
            try:
                vals = [float(x) for x in parts]
                rows.append(vals)
            except ValueError:
                continue

    if len(rows) == 0:
        raise RuntimeError("No numeric data rows found.")

    df = pd.DataFrame(rows, columns=["gbar_log10", "e_gbar", "gobs_log10", "e_gobs"])
    return df

df = load_rar_table(os.path.join(BASE_DIR, DATA_FILE))

gbar = 10.0 ** df["gbar_log10"].values   # m/s^2
gobs = 10.0 ** df["gobs_log10"].values   # m/s^2

# ============================================================
# Candidate interpolating functions
# ============================================================
def nu_exp(x):
    x = np.asarray(x, dtype=float)
    return 1.0 / np.maximum(1.0 - np.exp(-np.sqrt(np.maximum(x, 1e-300))), 1e-300)

def nu_solvency_quad(x, lam):
    x = np.asarray(x, dtype=float)
    return np.sqrt(1.0 + lam / np.maximum(x, 1e-300))

def nu_simple(x):
    x = np.asarray(x, dtype=float)
    return 0.5 * (1.0 + np.sqrt(1.0 + 4.0 / np.maximum(x, 1e-300)))

def nu_standard(x):
    x = np.asarray(x, dtype=float)
    return np.sqrt(0.5 + 0.5 * np.sqrt(1.0 + 4.0 / np.maximum(x, 1e-300)**2))

def gpred_from_model(gbar, a0, model_name, lam=2.0):
    x = gbar / a0
    if model_name == "exp_benchmark":
        nu = nu_exp(x)
    elif model_name == "solvency_quad":
        nu = nu_solvency_quad(x, lam)
    elif model_name == "simple":
        nu = nu_simple(x)
    elif model_name == "standard":
        nu = nu_standard(x)
    else:
        raise ValueError(f"Unknown model: {model_name}")
    return gbar * nu

# ============================================================
# Fit/scoring
# ============================================================
def score_model(gbar, gobs, a0, model_name, lam=2.0):
    gpred = gpred_from_model(gbar, a0, model_name, lam=lam)

    mask = np.isfinite(gbar) & np.isfinite(gobs) & np.isfinite(gpred) & (gbar > 0) & (gobs > 0) & (gpred > 0)
    gb = gbar[mask]
    go = gobs[mask]
    gp = gpred[mask]

    resid = np.log10(go) - np.log10(gp)

    rms_log = float(np.sqrt(np.mean(resid**2)))
    mad_log = float(np.median(np.abs(resid)))
    bias_all = float(np.mean(resid))

    high = gb >= 1e-10
    low = gb < 1e-10

    high_bias = float(np.mean(resid[high])) if np.any(high) else np.nan
    low_bias = float(np.mean(resid[low])) if np.any(low) else np.nan

    return {
        "rms_log10": rms_log,
        "mad_log10": mad_log,
        "bias_all": bias_all,
        "bias_high_gbar": high_bias,
        "bias_low_gbar": low_bias,
        "n_points": int(len(go)),
        "gpred": gp
    }

def fit_model(gbar, gobs, model_name, float_a0=False, float_lam=False):
    c = 2.99792458e8
    H0_km_s_Mpc = 67.74
    Mpc_m = 3.085677581491367e22
    H0 = H0_km_s_Mpc * 1000.0 / Mpc_m
    a0_sft = c * H0 / (2.0 * math.pi)

    if not float_a0:
        a0_grid = [a0_sft]
    else:
        a0_grid = np.geomspace(a0_sft / 5.0, a0_sft * 5.0, 121)

    if model_name == "solvency_quad" and float_lam:
        lam_grid = np.geomspace(0.25, 8.0, 121)
    else:
        lam_grid = [2.0]

    best = None

    for a0 in a0_grid:
        for lam in lam_grid:
            sc = score_model(gbar, gobs, a0, model_name, lam=lam)
            row = {
                "model": model_name,
                "a0_fit_m_s2": float(a0),
                "lambda_fit": float(lam),
                **{k: v for k, v in sc.items() if k != "gpred"}
            }
            if best is None or row["rms_log10"] < best["rms_log10"]:
                best = row

    return best

models = ["exp_benchmark", "solvency_quad", "simple", "standard"]

fixed_rows = []
for model in models:
    fixed_rows.append(fit_model(gbar, gobs, model, float_a0=False, float_lam=False))

float_rows = []
for model in models:
    float_rows.append(fit_model(gbar, gobs, model, float_a0=True, float_lam=(model == "solvency_quad")))

fixed_df = pd.DataFrame(fixed_rows)
float_df = pd.DataFrame(float_rows)
fixed_df["fit_mode"] = "fixed_a0"
float_df["fit_mode"] = "float_a0"

summary_df = pd.concat([fixed_df, float_df], ignore_index=True)
summary_df = summary_df.sort_values(["fit_mode", "rms_log10"]).reset_index(drop=True)
summary_df.to_csv(os.path.join(OUTDIR, "rar_fit_summary.csv"), index=False)

pred_rows = []
for _, row in float_df.iterrows():
    model = row["model"]
    a0 = row["a0_fit_m_s2"]
    lam = row["lambda_fit"]
    gpred = gpred_from_model(gbar, a0, model, lam=lam)
    tmp = pd.DataFrame({
        "model": model,
        "gbar_log10": np.log10(gbar),
        "gobs_log10": np.log10(gobs),
        "gpred_log10": np.log10(gpred),
        "log_resid": np.log10(gobs) - np.log10(gpred)
    })
    pred_rows.append(tmp)

pred_df = pd.concat(pred_rows, ignore_index=True)
pred_df.to_csv(os.path.join(OUTDIR, "rar_bestfit_predictions.csv"), index=False)

order = np.argsort(gbar)

plt.figure(figsize=(10, 6))
plt.scatter(gbar, gobs, s=6, alpha=0.25, label="RAR data")

for _, row in float_df.iterrows():
    model = row["model"]
    a0 = row["a0_fit_m_s2"]
    lam = row["lambda_fit"]
    gpred = gpred_from_model(gbar[order], a0, model, lam=lam)
    plt.plot(gbar[order], gpred, linewidth=2, label=model)

plt.xscale("log")
plt.yscale("log")
plt.xlabel("gbar [m/s^2]")
plt.ylabel("gobs [m/s^2]")
plt.title("SPARC RAR data vs candidate interpolating functions")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUTDIR, "rar_data_vs_models.png"), dpi=160)
plt.close()

plt.figure(figsize=(10, 6))
for _, row in float_df.iterrows():
    model = row["model"]
    sub = pred_df[pred_df["model"] == model].sort_values("gbar_log10")
    plt.scatter(10**sub["gbar_log10"], sub["log_resid"], s=6, alpha=0.25, label=model)

plt.xscale("log")
plt.axhline(0.0, linestyle="--")
plt.xlabel("gbar [m/s^2]")
plt.ylabel("log10(gobs) - log10(gpred)")
plt.title("RAR residuals vs baryonic acceleration")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUTDIR, "rar_residuals_vs_gbar.png"), dpi=160)
plt.close()

lines = []
lines.append("SFT SPARC RAR test V4")
lines.append("=" * 80)
lines.append(f"Loaded file: {DATA_FILE}")
lines.append(f"N points: {len(df)}")
lines.append("Columns used:")
lines.append("  gbar_log10 = log10 baryonic acceleration [m/s^2]")
lines.append("  gobs_log10 = log10 observed acceleration [m/s^2]")
lines.append("")
lines.append("Models tested:")
lines.append("  - exp_benchmark : 1 / (1 - exp(-sqrt(x)))")
lines.append("  - solvency_quad : sqrt(1 + lambda/x)")
lines.append("  - simple        : MOND simple control")
lines.append("  - standard      : MOND standard control")
lines.append("")
lines.append("[Fixed a0 results]")
lines.append(fixed_df.sort_values("rms_log10").to_string(index=False))
lines.append("")
lines.append("[Floating a0 results]")
lines.append(float_df.sort_values("rms_log10").to_string(index=False))

with open(os.path.join(OUTDIR, "rar_fit_summary.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("\n".join(lines))
print(f"\nSaved outputs to: {OUTDIR}")
