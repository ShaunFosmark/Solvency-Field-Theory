WEAK-FIELD / SPARC REPRODUCIBILITY PACK
=======================================

Purpose
-------
This is a lean reproducibility pack for the weak-field/SPARC update.
It is not the full project archive. It contains the two test scripts and the
summary outputs needed to verify the current weak-field claims.

Contents
--------
1. WEAKFIELD_SPARC_UPDATE.md
   Short writeup of the current weak-field/SPARC result.

2. sft_sparc_rar_test_v4.py
   First-pass SPARC RAR test using the official 'Data Behind Figure 2' table.

3. rar_fit_summary.txt
4. rar_fit_summary.csv
   Output summaries from the valid RAR run.

5. sft_sparc_rotmod_test_v1.py
   First-pass full SPARC ROTMOD population test across the 175 galaxy files.
   Note: update ROTMOD_DIR near the top of the script to point to your local
   SPARC ROTMOD folder before running.

6. rotmod_fit_summary.txt
7. rotmod_fit_summary.csv
   Output summaries from the full ROTMOD run.

8. threshold_audit_summary.txt
9. threshold_audit_scores.csv
   Small supporting note on how the threshold branches are assigned publication
   roles (lower-bound / fiducial / strongest case).

Current claim boundary
----------------------
What is supported:
- The weak-field transition variable x = g_bar / a_SFT is the right backbone.
- The scale a_SFT = c H0 / (2 pi) is strongly supported.
- The solvency-family transition nu(x) = sqrt(1 + lambda/x) is viable.
- The rigid lambda = 2 quadrature form is too stiff.
- A softened family remains reasonably competitive in full SPARC tests.

What is still open:
- The exact derivation of lambda.
- A geometry-aware derivation that distinguishes spherical-screen theory from
  the effective coefficient inferred from disk galaxies.

Minimal rerun instructions
--------------------------
RAR:
- Put RAR_All_Data.txt in the same folder as sft_sparc_rar_test_v4.py
- Run: python sft_sparc_rar_test_v4.py

ROTMOD:
- Download the SPARC database with the *_rotmod.dat files
- Set ROTMOD_DIR in sft_sparc_rotmod_test_v1.py to the local folder
- Run: python sft_sparc_rotmod_test_v1.py

Notes
-----
- These are first-pass population tests, not full bespoke per-galaxy modeling.
- The weak-field update should be presented as a serious mechanism result, not
  as a final exact derivation of the SPARC transition law.
