#!/usr/bin/env python3
"""
SFT V13.3 quick repro script.

This script regenerates the main numerical anchors used in the R251A-R257A
First Locally Real Atom gate sequence. It is intentionally compact; the full
result tables/reports are included in ../results.
"""

import math, json
from pathlib import Path

HBARC_MEV_FM = 197.3269804
alpha = 1/137.035999084
L_eff = 9.097814727066048

m_e_MeV = 0.51099895
m_u_MeV = 2.2
m_d_MeV = 4.7
m_p_MeV = 938.2720813
proton_radius_fm = 0.84

def r_spin_fm(mass_MeV):
    return HBARC_MEV_FM/(2*mass_MeV)

def u_for_field(target_MeV, base_MeV):
    return math.log1p(target_MeV/base_MeV)/L_eff

m_uud_seed = 2*m_u_MeV + m_d_MeV
E_proton_field_MeV = m_p_MeV - m_uud_seed

m_e_eV = m_e_MeV*1e6
m_p_eV = m_p_MeV*1e6
mu_eV = (m_e_eV*m_p_eV)/(m_e_eV+m_p_eV)
hbarc_eV_fm = HBARC_MEV_FM*1e6
a_mu_fm = hbarc_eV_fm/(mu_eV*alpha)
a_mu_pm = a_mu_fm/1000
E_bind_eV = mu_eV*alpha**2/2
H_mass_MeV = m_p_MeV + m_e_MeV - E_bind_eV/1e6

anchors = {
    "stability_band": {
        "electron_MeV": m_e_MeV,
        "up_quark_MeV": m_u_MeV,
        "down_quark_MeV": m_d_MeV,
        "down_over_electron_mass_factor": m_d_MeV/m_e_MeV,
        "r_spin_fm": {
            "electron": r_spin_fm(m_e_MeV),
            "up": r_spin_fm(m_u_MeV),
            "down": r_spin_fm(m_d_MeV),
        },
    },
    "proton": {
        "uud_seed_MeV": m_uud_seed,
        "proton_mass_MeV": m_p_MeV,
        "field_target_MeV": E_proton_field_MeV,
        "field_fraction": E_proton_field_MeV/m_p_MeV,
        "sigma_single_1fm_GeV_per_fm": E_proton_field_MeV/1000,
        "field_target_hbarc_per_fm_units": E_proton_field_MeV/HBARC_MEV_FM,
        "three_link_per_link_hbarc_units": (E_proton_field_MeV/3)/HBARC_MEV_FM,
        "L_eff_u_three_link_hbarc_base": u_for_field(E_proton_field_MeV, 3*HBARC_MEV_FM),
    },
    "hydrogen": {
        "alpha_input": alpha,
        "mu_over_me": mu_eV/m_e_eV,
        "a_mu_pm": a_mu_pm,
        "binding_eV": E_bind_eV,
        "hydrogen_mass_MeV": H_mass_MeV,
        "proton_radius_over_a_mu": proton_radius_fm/a_mu_fm,
        "electron_orbital_over_electron_rspin": a_mu_fm/r_spin_fm(m_e_MeV),
    },
    "claim_boundary": {
        "promoted": "leading hydrogen assembly with alpha input and guarded proton interior",
        "open": ["alpha derivation", "proton baryon/confinement kernel", "full spectrum", "chemistry"],
    },
}

print(json.dumps(anchors, indent=2))
Path("v13_3_quick_repro_summary.json").write_text(json.dumps(anchors, indent=2))
