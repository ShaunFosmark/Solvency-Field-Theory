# SFT_V13_3_R252A_Quark_Confinement_Toy_Gate

Generated: 2026-06-28T06:10:55Z

Branch:

```text
SFT V13.3 — The First Locally Real Atom
```

## Verdict

```text
PARTIAL_PASS_R252A_QUARK_CONFINEMENT_TOY_GATE_READY_RAW_GA_COMPACTNESS_AT_1FM_FAILS_AS_CONFINEMENT_MECHANISM_NUCLEAR_SETTLEMENT_SUPPORT_SCALE_IDENTIFIED_EBIND_TARGET_929MEV_SIGMA_REQUIRED_0_929GEV_PER_FM_THREE_LINK_TARGET_310MEV_PER_LINK_HBARC_OVER_FM_ORDER_UNITY_SCALE_MATCHES_TOY_REQUIREMENT_UUD_CHARGE_PLUS_ONE_BOOKKEEPING_PASSES_CONFINEMENT_REQUIRES_STRING_TUBE_OR_NONLINEAR_SETTLEMENT_KERNEL_NOT_DERIVED_R253A_READY
```

## Core result

R252A runs the first quark-confinement toy gate.

The result is a productive partial pass:

```text
raw G_A compactness at 1 fm fails
but the required nuclear settlement scale is cleanly identified
```

So confinement cannot be explained as ordinary gravity-side compactness using:

```text
C_A = G_A M/(c^2 r)
```

At 1 fm:

```text
C_A(uud seed) = 1.205e-41
C_A(proton total) = 1.242e-39
```

This is far too small to confine anything.

Therefore the toy gate forces the right conclusion:

```text
quark confinement requires a nuclear settlement/support kernel,
not raw long-range gravity compactness.
```

## Compression clue

Using:

```text
r_spin = hbar/(2mc)
```

the isolated current-mass spin radii are:

```text
up quark:   44.847 fm
down quark: 20.992 fm
uud seed:   10.842 fm
```

A proton-scale support region is ~1 fm.

So the quark seeds are forced far inside their isolated closure radii:

```text
up:   44.85x inside 1 fm
down: 20.99x inside 1 fm
uud:  10.84x inside 1 fm
```

This supports the interpretation that a proton is not three isolated quark orbits sitting next to each other. It is a compact shared support structure whose field energy dominates.

## Energy target

Current-mass seed:

```text
2m_u + m_d = 9.100 MeV
```

Proton mass:

```text
m_p = 938.272 MeV
```

Missing confinement/field/settlement energy:

```text
E_bind,target = 929.172 MeV
```

Non-seed fraction:

```text
99.030%
```

Total-to-seed ratio:

```text
m_p/(2m_u+m_d) = 103.107
```

## Settlement tension requirement

If the missing proton energy is stored across a ~1 fm support scale, the required linear support/tension scale is:

```text
sigma_settle,target = 929.172 MeV/fm = 0.929 GeV/fm
```

For a three-link toy support:

```text
E_link,target = 309.724 MeV/link
```

At 1 fm:

```text
hbar c / 1 fm = 197.327 MeV
```

so:

```text
E_link/(hbar c/fm) = 1.570
```

This is important: the required support energy is not absurd in nuclear natural units. It is order-unity-to-few in `hbar c/r` units.

## Potential-model result

A pure `1/r` potential can bind but does not confine:

```text
V ~ -k/r
```

weakens with distance.

Confinement needs a rising separation cost:

```text
V ~ sigma r
```

or a three-body tube/junction support whose energy grows with attempted separation.

Therefore R252A promotes the target form:

```text
E_settle,confine ~ sigma_settle L_support + junction/nonlinear terms
```

with:

```text
sigma_settle ~ 0.93 GeV/fm
```

to be derived later.

## Charge bookkeeping

The proton exterior charge bookkeeping passes:

```text
+2/3 + +2/3 - 1/3 = +1
```

This does not solve confinement or color. It prepares R254A, the directional settlement / Coulomb well gate.

## Claim boundary

Promoted:

```text
raw G_A compactness is not the confinement mechanism
confinement requires a nuclear settlement/support kernel
the missing proton-energy target is ~929 MeV
the required 1 fm support/tension target is ~0.93 GeV/fm
uud exterior charge bookkeeping gives +1
```

Open:

```text
derive sigma_settle
derive three-body support topology
derive proton mass from settlement field energy
derive color/confinement rules
```

Blocked:

```text
raw gravity compactness confines quarks
1/r attraction alone confines quarks
R252A derives full confinement
```

## Next gate

R253A — Proton Settlement-Energy Gate.
