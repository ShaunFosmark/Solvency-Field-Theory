# SFT_V13_3_R252A_Quark_Confinement_Toy_Gate

Quark confinement toy gate for SFT V13.3 — The First Locally Real Atom.
