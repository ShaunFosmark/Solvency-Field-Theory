# SFT_V13_3_R255A_Electron_Orbital_Equilibrium_Gate

Generated: 2026-06-28T21:24:58Z

Branch:

```text
SFT V13.3 — The First Locally Real Atom
```

## Verdict

```text
PASS_R255A_ELECTRON_ORBITAL_EQUILIBRIUM_GATE_READY_DIRECTIONAL_SETTLEMENT_ATTRACTION_MINUS_1_OVER_R_FROM_R254A_BALANCED_BY_ELECTRON_CLOSURE_SUPPORT_COST_PLUS_1_OVER_R2_GIVES_FINITE_MINIMUM_BOHR_RADIUS_A0_52_9177PM_INFINITE_PROTON_AND_A_MU_52_9465PM_REDUCED_MASS_RECOVERED_WITH_ALPHA_INPUT_BINDING_13_6057EV_INFINITE_PROTON_AND_13_5983EV_REDUCED_MASS_RECOVERED_VIRIAL_2K_PLUS_V_ZERO_COLLAPSE_PREVENTION_PASSES_ALPHA_NOT_DERIVED_FULL_HYDROGEN_ASSEMBLY_DEFERRED_R256A_READY
```

## Purpose

R255A tests whether the attractive well from R254A produces a stable electron orbit when balanced against the electron's closure-maintenance/support-domain cost.

R254A supplied:

```text
V_dir(r) ∝ -1/r
```

R255A adds:

```text
K_conf(r) ∝ +1/r^2
```

and minimizes the total energy.

## Native settlement balance

The SFT translation is:

```text
directional settlement attraction:
    V_dir(r) = - alpha hbar c / r

electron closure support cost:
    K_conf(r) = hbar^2/(2 mu r^2)

total:
    E(r) = hbar^2/(2 mu r^2) - alpha hbar c/r
```

The `-1/r` term pulls the electron inward.

The `+1/r^2` term prevents collapse because localizing the electron support domain too tightly raises its closure-maintenance cost.

## Equilibrium derivation

Minimize:

```text
dE/dr = -hbar^2/(mu r^3) + alpha hbar c/r^2 = 0
```

This gives:

```text
r = hbar/(mu c alpha)
```

So the Bohr radius follows from the balance.

At the minimum:

```text
K = + mu c^2 alpha^2/2
V = - mu c^2 alpha^2
E = - mu c^2 alpha^2/2
```

The virial relation is:

```text
2K + V = 0
```

## Numerical result

Using alpha as input:

```text
alpha = 0.007297352569284
```

Infinite-proton approximation:

```text
a0 = 52.917721074 pm
E_bind = 13.605693123 eV
```

Reduced-mass hydrogen:

```text
mu/m_e = 0.999455679421
a_mu = 52.946540966 pm
E_bind,mu = 13.598287264 eV
```

At equilibrium:

```text
K = +13.598287264 eV
V = -27.196574528 eV
E_total = -13.598287264 eV
2K+V = 0.000e+00 eV
```

## What passed

R255A passes the structural and numerical gate:

```text
-1/r attraction plus +1/r^2 support cost creates a stable finite minimum
the minimum gives the Bohr radius with alpha input
the minimized energy gives 13.6 eV binding with alpha input
the electron does not collapse into the proton
```

## Guardrails

R255A does not derive alpha.

R255A does not derive the full hydrogen spectrum.

R255A does not include fine structure, Lamb shift, hyperfine splitting, relativistic corrections, or electron spin coupling.

R255A does not assemble the full atom. That is R256A.

## Claim boundary

Promoted:

```text
Bohr radius and 13.6 eV binding follow from settlement balance with alpha input.
The functional form is correct.
The numbers match at leading nonrelativistic order.
```

Open:

```text
alpha derivation
full spectrum
full hydrogen assembly
```

## Next gate

R256A — Hydrogen Atom Assembly Gate.
