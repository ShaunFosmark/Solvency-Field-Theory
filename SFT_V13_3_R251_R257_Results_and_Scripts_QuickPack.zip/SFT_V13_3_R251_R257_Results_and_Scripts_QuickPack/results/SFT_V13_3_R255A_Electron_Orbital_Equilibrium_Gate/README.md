# SFT_V13_3_R255A_Electron_Orbital_Equilibrium_Gate

Electron orbital equilibrium gate for SFT V13.3 — The First Locally Real Atom.
