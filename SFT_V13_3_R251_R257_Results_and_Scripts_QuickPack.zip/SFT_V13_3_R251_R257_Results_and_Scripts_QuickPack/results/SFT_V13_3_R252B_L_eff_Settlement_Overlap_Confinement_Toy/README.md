# SFT_V13_3_R252B_L_eff_Settlement_Overlap_Confinement_Toy

L_eff settlement-overlap confinement toy for SFT V13.3 — The First Locally Real Atom.
