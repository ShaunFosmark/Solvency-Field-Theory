# SFT V13.3 — The First Locally Real Atom

## R257A — First Locally Real Atom Rollup Freeze

Generated: 2026-06-28T21:38:41Z

## Verdict

```text
PASS_R257A_V13_3_FIRST_LOCALLY_REAL_ATOM_ROLLUP_FREEZE_READY_R251_TO_R256_CHAIN_FROZEN_STABILITY_BAND_TO_HYDROGEN_ASSEMBLY_ELECTRON_UP_DOWN_PERSISTENT_BUILDERS_IDENTIFIED_EFFECTIVE_PROTON_INTERIOR_GUARDED_DIRECTIONAL_COULOMB_WELL_AND_ELECTRON_SUPPORT_BALANCE_RECOVER_HYDROGEN_A_MU_52_9465PM_BINDING_13_5983EV_NEUTRAL_PROTON_ELECTRON_STRUCTURE_ASSEMBLED_AT_LEADING_NONRELATIVISTIC_ORDER_WITH_ALPHA_INPUT_ALPHA_PROTON_BARYON_KERNEL_FULL_SPECTRUM_AND_CHEMISTRY_DEFERRED_NEXT_TRACKS_READY
```

## Frozen thesis

```text
SFT V13.3 assembles the first locally real atom at leading nonrelativistic order.
```

The assembly is not a full derivation of every ingredient. It is a guarded construction chain:

```text
persistent charged builders
    -> effective confined proton
    -> directional +1 exterior settlement well
    -> electron closure/support equilibrium
    -> neutral hydrogen atom
```

## One-sentence freeze

```text
A guarded effective proton provides a +1 directional settlement source; an electron supplies a -1 persistent closure; directional attraction gives a 1/r well; electron support maintenance gives a 1/r^2 collapse barrier; the balance gives the Bohr radius and 13.6 eV binding, forming neutral hydrogen.
```

## What V13.3 froze

### 1. Stability band

The stable charged matter universe is built from a narrow ground-state band:

```text
electron: 0.51099895 MeV
up quark: ~2.2 MeV
down quark: ~4.7 MeV
```

The target is no longer “derive the particle zoo.”

The sharper target is:

```text
derive the minimum viable compactness for each charge/spin/confinement family.
```

### 2. Proton as guarded effective source

The proton seed accounting is:

```text
2m_u + m_d = 9.100 MeV
m_p = 938.272081 MeV
E_field,target = 929.172081 MeV
```

R252-R253 do not derive the proton, but they define a viable nuclear settlement target. The proton may be used as a guarded effective source for atomic assembly:

```text
charge = +1
mass = 938.272081 MeV
interior kernel = open
```

### 3. Directional exterior

R254A established the Coulomb-shape well from conserved directional settlement flux:

```text
field ~ 1/r^2
potential ~ 1/r
```

with standard translation:

```text
V(r)=q_1 q_2 alpha hbar c/r
```

For proton-electron:

```text
q_p q_e = -1
```

so the well is attractive.

### 4. Electron orbital equilibrium

R255A froze the balance:

```text
E(r)=hbar^2/(2mu r^2)-alpha hbar c/r
```

Minimization gives:

```text
a_mu = hbar/(mu c alpha)
E_bind = mu c^2 alpha^2/2
```

Numerically, with alpha as input:

```text
a_mu = 52.946540966 pm
E_bind = 13.598287264 eV
```

### 5. Hydrogen assembly

R256A assembled the neutral atom:

```text
effective proton + electron -> hydrogen
+1 + (-1) = 0
```

The leading mass-energy is:

```text
m_H c^2 ≈ 938.783066651713 MeV
```

The scale separation passes:

```text
r_p/a_mu = 1.586506e-05
```

So the proton interior is negligible for the leading electronic shell.

## Claim boundary

Promoted:

```text
leading hydrogen assembly
Bohr radius and 13.6 eV binding with alpha input
directional settlement Coulomb shape
electron support-cost collapse prevention
effective-proton exterior field
```

Open:

```text
alpha derivation
proton baryon junction / confinement kernel
full hydrogen spectrum
fine structure, hyperfine, Lamb shift, relativistic corrections
molecules and chemistry
```

Blocked:

```text
alpha already derived
proton fully derived
full QCD/hadron spectrum solved
full hydrogen spectroscopy derived
chemistry derived
```

## Next tracks

```text
R258A — write V13.3 first-atom paper
R257B — alpha derivation target gate
R257C — hydrogen spectrum extension
R253C — baryon junction / triple-overlap kernel
R259A — H2 / chemistry toy gate
```

## Final preservation statement

R257A freezes SFT V13.3 as the first locally real atom construction. The R251-R256 chain identifies the persistent charged builders, treats the proton as a guarded effective +1 confined settlement source, derives the Coulomb-shape directional exterior, balances the electron's -1/r attraction against +1/r^2 closure support cost, and assembles neutral hydrogen with a_mu≈52.9465 pm and binding≈13.5983 eV using alpha as input. The result is leading nonrelativistic hydrogen, not alpha, not the proton interior, not full spectroscopy, and not chemistry.
