# SFT_V13_3_R257A_First_Locally_Real_Atom_Rollup_Freeze

Rollup freeze pack for SFT V13.3 — The First Locally Real Atom.
Generated: 2026-06-28T21:38:41Z
