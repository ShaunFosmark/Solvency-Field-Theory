# SFT_V13_3_R254A_Directional_Settlement_Coulomb_Well_Gate

Directional settlement / Coulomb well gate for SFT V13.3 — The First Locally Real Atom.
