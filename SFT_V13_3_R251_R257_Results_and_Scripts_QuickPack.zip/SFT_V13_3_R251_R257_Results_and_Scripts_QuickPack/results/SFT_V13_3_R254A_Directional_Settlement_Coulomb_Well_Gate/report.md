# SFT_V13_3_R254A_Directional_Settlement_Coulomb_Well_Gate

Generated: 2026-06-28T21:17:25Z

Branch:

```text
SFT V13.3 — The First Locally Real Atom
```

## Verdict

```text
PASS_R254A_DIRECTIONAL_SETTLEMENT_COULOMB_WELL_GATE_READY_EFFECTIVE_PROTON_PLUS_ONE_SOURCE_ACCEPTED_WITH_INTERIOR_KERNEL_GUARDRAIL_DIRECTIONAL_SETTLEMENT_FLUX_IN_3D_GIVES_FIELD_1_OVER_R2_AND_POTENTIAL_1_OVER_R_ELECTRON_PROTON_SIGN_BOOKKEEPING_ATTRACTIVE_PROTON_POINT_SOURCE_APPROXIMATION_AT_BOHR_RADIUS_PASSES_RP_OVER_A0_1_59E_MINUS5_ALPHA_USED_AS_NORMALIZATION_INPUT_NOT_DERIVED_BOHR_EQUILIBRIUM_DEFERRED_R255A_READY
```

## Purpose

R254A moves the V13.3 atom program outward.

R252--R253 made the proton usable as an effective confined settlement object:

```text
mass ≈ 938.27 MeV
charge = +1
interior settlement/confinement kernel = open
```

R254A asks:

```text
Given an effective +1 proton,
does native SFT directional settlement give a Coulomb-like exterior well
for a -1 electron?
```

## Native shape argument

Assume a conserved directional settlement source `Q`.

In 3 spatial dimensions, the flux through an enclosing sphere is constant:

```text
Phi_Q = constant
A(r) = 4 pi r^2
```

Therefore the exterior field density scales as:

```text
D(r) proportional 1/r^2
```

The potential is the radial integral of the field:

```text
V(r) proportional 1/r
```

So the Coulomb shape follows from conserved directional settlement flux in 3D.

## Translation

The standard readable translation is:

```text
V(r) = q_1 q_2 alpha hbar c / r
F(r) = -dV/dr
```

For a proton-electron pair:

```text
q_p = +1
q_e = -1
q_p q_e = -1
```

So the well is attractive.

## Atomic scale check

Bohr radius:

```text
a0 = 52917.721090 fm = 52.917721090 pm
```

Proton radius reference:

```text
r_p ≈ 0.84 fm
```

Scale ratio:

```text
r_p/a0 = 1.587370e-05
a0/r_p = 62997.287
```

So the proton interior is negligible for the leading atomic exterior field. Treating the proton as a pointlike +1 directional source is valid for R254A.

## Normalization with alpha input

R254A does not derive alpha.

Using alpha as input:

```text
alpha = 0.007297352569284
```

the potential at the Bohr radius is:

```text
V(a0) = -27.211386238 eV
```

The hydrogen binding energy requires the kinetic/confinement balance:

```text
E_bind ≈ 13.6 eV
```

That equilibrium is deferred to R255A.

## What R254A establishes

Promoted:

```text
effective proton can be used as +1 exterior source
directional settlement flux gives field ~1/r^2
potential has Coulomb shape ~1/r
electron-proton sign is attractive
proton interior is negligible at atomic radius
```

Open:

```text
alpha derivation
electron orbital equilibrium
full hydrogen assembly
proton internal kernel
```

Blocked:

```text
alpha derived
hydrogen assembled
proton interior solved
```

## Next gate

R255A — Electron Orbital Equilibrium Gate.
