# SFT_V13_3_R253B_Opus_Three_Body_Overlap_Pion_Ratio_Toy

Generated: 2026-06-28T21:02:01Z

Branch: `SFT V13.3 — The First Locally Real Atom`

## Verdict

`PARTIAL_PASS_R253B_OPUS_THREE_BODY_OVERLAP_PION_RATIO_TOY_READY_PROTON_TO_PION_TOTAL_RATIO_6_72_TO_6_95_EXCEEDS_SIMPLE_THREE_LINK_RATIO_3_REQUIRED_THREE_BODY_OVERLAP_ENHANCEMENT_ETA3_ABOUT_2_22_TO_2_42_IDENTIFIED_LEFF_TOY_PION_ONE_LINK_U_ABOUT_0_056_TO_0_059_PROTON_THREE_LINK_U_ABOUT_0_104_DELTA_U_ABOUT_0_045_TO_0_049_TOY_CONSISTENT_NOT_DERIVATION_TRIPLE_OVERLAP_OR_JUNCTION_TERM_REQUIRED`

## Purpose

This is Opus's separate companion test. It asks whether the proton-to-pion ratio supports a three-body overlap/junction term beyond three independent links.

## Pion ratio

`m_p/m_pi0 = 6.951`

`m_p/m_pi± = 6.723`

A naive one-link pion and three-link proton predicts a ratio near `3`. The actual total-mass ratio is about `6.7--7.0`, so the simple three-link picture is low by about `2.241--2.317`.

## Field ratio

Using the proton field target:

`E_p,field = 929.172 MeV`

and pion total masses as one-link references:

`eta3(pi0 total) = 2.295`

`eta3(pi± total) = 2.219`

Subtracting a current u+d seed from the pion gives:

`eta3(pi0 field) = 2.418`

`eta3(pi± field) = 2.335`

So the needed three-body enhancement is roughly:

`eta3 ≈ 2.2 to 2.4`

## L_eff comparison

With `E = E_base[exp(L_eff u)-1]` and `E_base=hbar c/fm`:

`u_pion ≈ 0.058796 to 0.057287` using total pion mass.

For the proton three-link field target:

`u_proton,3link ≈ 0.103734`

So the extra completion is only:

`delta_u ≈ 0.044938 to 0.046447`

## Result

A proton is not modeled well as just three independent pion-like links. It needs a three-body overlap/junction enhancement of about 2.2--2.4, or equivalently a small extra L_eff completion beyond the pion one-link state.

## Claim boundary

Promoted: proton/pion ratio is a useful three-body diagnostic.

Blocked: proton mass derivation, pion derivation, QCD spectrum solution.
