# SFT_V13_3_R253B_Opus_Three_Body_Overlap_Pion_Ratio_Toy

Opus proton/pion overlap toy gate.
