# SFT_V13_3_R251A_Stability_Band_Minimum_Viable_Compactness

Generated: 2026-06-28T05:55:48Z

Branch:

```text
SFT V13.3 — The First Locally Real Atom
```

## Verdict

```text
PASS_R251A_V13_3_STABILITY_BAND_MINIMUM_VIABLE_COMPACTNESS_READY_FIRST_LOCALLY_REAL_ATOM_BRANCH_OPENED_PERSISTENT_CHARGED_BUILDERS_ELECTRON_UP_DOWN_MAP_TO_0_511_TO_4_7MEV_BAND_FACTOR_9_2_RSPIN_BAND_193_TO_21FM_NEUTRINO_LOW_COMPACTNESS_DEFAULT_STABILITY_AND_HEAVY_FERMION_EXCITED_CLOSURE_DECAY_CLASSIFICATIONS_ADDED_MINIMUM_VIABLE_COMPACTNESS_FRAMED_AS_SPECIES_MAP_TARGET_NOT_DERIVED_PROTON_UUD_938MEV_BINDING_DOMINANCE_FLAGGED_R252A_TO_R256A_HYDROGEN_SEQUENCE_READY
```

## Core result

R251A opens the V13.3 particle-to-atom branch.

The new branch target is not merely:

```text
derive four fermion masses
```

but:

```text
derive the minimum viable compactness for each persistent charge / spin / confinement family.
```

The stable charged builder band is narrow:

```text
electron: 0.51099895 MeV
up quark: ~2.2 MeV
down quark: ~4.7 MeV
```

This spans only:

```text
down/electron = 9.19767
```

less than one order of magnitude.

Using:

```text
r_spin = hbar/(2mc)
```

the corresponding spin radii are:

```text
electron: 193.08 fm
up quark: 44.847 fm
down quark: 20.9922 fm
```

## Stability-band interpretation

R251A promotes the following as the V13.3 program hypothesis:

```text
The persistent charged builders are ground-state closure modes.
Their masses are minimum viable compactness thresholds for their charge/spin/confinement families.
```

Heavy fermions are not dismissed as fake. They are classified as real but unstable higher closure modes.

```text
muon / tau: higher -1 charged-lepton closures
charm / top: higher +2/3 quark closures
strange / bottom: higher -1/3 quark closures
```

They decay because lower compatible closure modes exist.

Neutrinos are classified separately:

```text
below the charged stability band
neutral/low-compactness sector
stable/effectively stable by no-lower-state/default
flavor oscillation caveat retained
```

## Proton clue

The proton target is immediate.

Current-mass seed:

```text
2 up + 1 down = 9.1 MeV
```

Proton mass:

```text
m_p = 938.272 MeV
```

Ratio:

```text
m_p/(2m_u+m_d) = 103.107
```

Non-seed fraction:

```text
99.0301%
```

This is a prime SFT target because the proton mass is dominated by confinement/field/settlement energy, not by the current quark seed masses.

R251A does not derive this. It marks it as the R253A target.

## V13.3 gate sequence

```text
R251A — Stability Band / Minimum Viable Compactness
R252A — Quark Confinement Toy Gate
R253A — Proton Settlement-Energy Gate
R254A — Directional Settlement / Coulomb Well Gate
R255A — Electron Orbital Equilibrium Gate
R256A — Hydrogen Atom Assembly Gate
```

## Claim boundary

Promoted:

```text
stable charged builder band = electron/up/down
band width ~9.2 in mass
minimum viable compactness is the species-map target
heavy fermions are real unstable excited closures
proton mass dominance by binding/field energy is the next major test target
```

Open:

```text
minimum viable compactness derivation
quark confinement mechanism
proton mass mechanism
alpha
full hydrogen assembly
```

Blocked:

```text
heavy fermions are fake
proton mass already derived
alpha already derived
full atom already built
```

## Next gate

R252A — Quark Confinement Toy Gate.
