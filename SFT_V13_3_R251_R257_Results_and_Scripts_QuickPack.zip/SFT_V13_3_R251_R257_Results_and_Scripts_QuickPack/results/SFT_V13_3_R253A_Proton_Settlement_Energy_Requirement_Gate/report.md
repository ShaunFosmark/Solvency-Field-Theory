# SFT_V13_3_R253A_Proton_Settlement_Energy_Requirement_Gate

Generated: 2026-06-28T21:02:01Z

Branch: `SFT V13.3 — The First Locally Real Atom`

## Verdict

`PARTIAL_PASS_R253A_PROTON_SETTLEMENT_ENERGY_REQUIREMENT_GATE_READY_CONSERVATIVE_ACCOUNTING_SEPARATES_SOURCE_SEED_AND_FIELD_ENERGY_UUD_SEED_9_1MEV_PROTON_938_27MEV_FIELD_TARGET_929_17MEV_GEOMETRY_SUPPORT_SCAN_SHOWS_REQUIRED_SIGMA_DEPENDS_ON_TOPOLOGY_SINGLE_1FM_0_929GEV_PER_FM_Y_SIDE_1FM_0_536GEV_PER_FM_DELTA_SIDE_1FM_0_310GEV_PER_FM_PROTON_FIELD_TARGET_EQUALS_4_71_HBARC_PER_FM_TOTAL_OR_1_57_HBARC_PER_FM_PER_THREE_LINK_SUPPORT_REQUIREMENT_DEFINED_NOT_DERIVED`

## Purpose

This is the conservative 5.5 version. It does not assume the L_eff overlap kernel. It asks what any proton settlement-energy kernel must supply.

## Accounting

`2m_u + m_d = 9.100 MeV`

`m_p = 938.272 MeV`

So the required field/settlement energy is:

`E_field = 929.172 MeV`

That is `103.107` times the seed scale, with `99.030%` of the proton mass outside the simple current-mass seed.

## Natural-unit check

At 1 fm, `hbar c / fm = 197.327 MeV`.

So:

`E_field/(hbar c/fm) = 4.709`

For three equal links:

`E_link = 309.724 MeV = 1.570 (hbar c/fm)`

The target is order-one-to-few in nuclear natural units.

## Geometry scan

Required support tension depends on topology:

`single 1 fm support: 0.929 GeV/fm`

`Y-junction, side 1 fm: 0.536 GeV/fm`

`Delta triangle, side 1 fm: 0.310 GeV/fm`

## Claim boundary

Promoted: target energy and support requirements.

Blocked: proton mass derivation, exact topology, full QCD equivalence.

Companion gate: R253B.
