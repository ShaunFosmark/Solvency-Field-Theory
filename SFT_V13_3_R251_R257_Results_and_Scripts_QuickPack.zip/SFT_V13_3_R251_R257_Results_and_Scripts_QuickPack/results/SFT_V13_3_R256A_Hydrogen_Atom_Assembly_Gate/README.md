# SFT_V13_3_R256A_Hydrogen_Atom_Assembly_Gate

Hydrogen atom assembly gate for SFT V13.3 — The First Locally Real Atom.
