# SFT_V13_3_R256A_Hydrogen_Atom_Assembly_Gate

Generated: 2026-06-28T21:28:20Z

Branch:

```text
SFT V13.3 — The First Locally Real Atom
```

## Verdict

```text
PASS_R256A_HYDROGEN_ATOM_ASSEMBLY_GATE_READY_FIRST_LOCALLY_REAL_ATOM_ASSEMBLED_AT_LEADING_NONRELATIVISTIC_ORDER_FROM_R251_TO_R255_CHAIN_EFFECTIVE_PROTON_PLUS_ONE_AND_ELECTRON_MINUS_ONE_FORM_NEUTRAL_BOUND_SETTLEMENT_STRUCTURE_BOHR_RADIUS_A_MU_52_9465PM_AND_BINDING_13_5983EV_RECOVERED_WITH_ALPHA_INPUT_SCALE_SEPARATION_PASSES_RP_OVER_A_MU_1_586E_MINUS5_BINDING_FRACTION_SMALL_PROTON_INTERIOR_GUARDED_ALPHA_AND_BARYON_KERNEL_NOT_DERIVED_FULL_SPECTRUM_AND_CHEMISTRY_DEFERRED
```

## Purpose

R256A chains the V13.3 gates into the first leading-order atom.

The goal is not full spectroscopy, chemistry, alpha derivation, or a proton interior derivation.

The goal is:

```text
Can SFT assemble a neutral hydrogen atom from a locally real proton source and electron closure?
```

## Inputs from prior gates

```text
R251A:
    persistent charged builders: electron, up, down

R252A/R252B:
    confinement cannot be raw gravity compactness;
    nuclear settlement support target is viable as a toy

R253A/R253B:
    proton can be treated as a guarded effective +1 confined settlement source

R254A:
    directional settlement from +1 source gives 1/r exterior well

R255A:
    electron support cost +1/r^2 balances -1/r attraction,
    giving Bohr radius and 13.6 eV binding with alpha input
```

## Assembly

The hydrogen atom is assembled as:

```text
effective proton:
    charge = +1
    mass = 938.272081300 MeV
    internal kernel = open / guarded

electron:
    charge = -1
    mass = 0.51099895 MeV
    closure/support equilibrium around proton

total:
    charge = 0
    bound neutral atom
```

## Energy budget

Proton mass-energy:

```text
m_p c^2 = 938.272081300 MeV
```

Electron mass-energy:

```text
m_e c^2 = 0.51099895 MeV
```

Hydrogen binding energy:

```text
E_bind = 13.598287264 eV
       = 0.000013598287 MeV
```

Hydrogen leading mass-energy:

```text
m_H c^2 ≈ 938.783066651713 MeV
```

The binding is tiny relative to the rest mass:

```text
E_bind/(m_H c^2) = 1.448502e-08
```

## Radius and scale hierarchy

Reduced-mass Bohr radius:

```text
a_mu = 52.946540966 pm
     = 52946.540966 fm
```

Proton radius reference:

```text
r_p ≈ 0.84 fm
```

Scale separation:

```text
r_p/a_mu = 1.586506e-05
```

So the proton interior is invisible to the leading electronic shell.

Electron internal spin-radius scale:

```text
r_spin,e = 193.079634 fm
```

Electron orbital/support radius relative to internal scale:

```text
a_mu/r_spin,e = 274.221262
```

This cleanly separates electron internal closure from atomic orbital support.

## What passed

R256A passes the leading atom assembly gate:

```text
charge neutrality:
    +1 - 1 = 0

exterior field:
    V(r) ~ -1/r

support balance:
    K(r) ~ +1/r^2

stable radius:
    a_mu = 52.946540966 pm

binding:
    E_bind = 13.598287264 eV
```

## Claim boundary

Promoted:

```text
SFT can assemble leading-order hydrogen from the R251-R255 chain.
The atom is a neutral bound settlement structure.
The electronic ground-state radius and binding follow from settlement balance with alpha input.
```

Open:

```text
alpha derivation
proton baryon junction/confinement kernel
full hydrogen spectrum
fine structure
Lamb shift
hyperfine splitting
relativistic corrections
molecules / chemistry
```

## Final R256A statement

V13.3 has now assembled the first locally real atom at leading order:

```text
a guarded confined proton provides a +1 directional settlement source;
an electron supplies a -1 persistent closure;
directional attraction gives a 1/r well;
electron support maintenance gives a 1/r^2 collapse barrier;
the balance gives the Bohr radius and 13.6 eV binding;
the total structure is neutral hydrogen.
```
