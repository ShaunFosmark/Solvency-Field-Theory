# SFT V13.3 R251-R257 Quick Pack

Generated: 2026-06-28T21:48:57Z

Branch: **SFT V13.3 — The First Locally Real Atom**

## Included gates

1. R251A — Stability Band / Minimum Viable Compactness
2. R252A — Quark Confinement Toy Gate
3. R252B — L_eff Settlement-Overlap Confinement Toy
4. R253A — Proton Settlement-Energy Requirement Gate
5. R253B — Opus Three-Body Overlap / Pion Ratio Toy
6. R254A — Directional Settlement / Coulomb Well Gate
7. R255A — Electron Orbital Equilibrium Gate
8. R256A — Hydrogen Atom Assembly Gate
9. R257A — First Locally Real Atom Rollup Freeze

## Important note on scripts

The full generated reports and CSV result tables are in `results/`.
A compact repro script is included at:

```text
scripts/v13_3_quick_repro.py
```

It regenerates the main numerical anchors: stability-band radii, proton settlement-energy target, L_eff toy u-value, Bohr radius, hydrogen binding energy, and key claim boundaries.

## Frozen claim

SFT V13.3 assembles leading-order hydrogen from a guarded effective proton and electron closure using settlement mechanics, with alpha as input.

## Guardrails

Alpha is not derived.
The proton baryon/confinement kernel is not derived.
Full hydrogen spectroscopy is not derived.
Chemistry is not derived.
