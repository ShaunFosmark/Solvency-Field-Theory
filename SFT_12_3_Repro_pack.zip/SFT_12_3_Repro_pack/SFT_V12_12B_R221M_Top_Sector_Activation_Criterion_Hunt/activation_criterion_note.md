
# R221M Top-Sector Activation Criterion Hunt Note

Generated: 2026-06-20T04:45:29Z

## Frozen input

D-scale law:

    M_i = G_i exp[(3pi - 1/2 ln(25/13)) u_i]

D-scale endpoint:

    17871.48862357384

## R220 full-closure candidate

    K_top = 4pi + 2pi = 6pi

where:

    4pi = spatial/spinor curvature closure
    2pi = frame/gauge phase closure

## R221 activation criterion candidate

At the saturated endpoint of the D-scale trace lane, the least additional
no-overwrite completion that closes both real support sectors is exactly one
full untaxed closure cycle:

    one extra K_top = 6pi

Why not zero?

    zero leaves the high sector without terminal full support/frame closure.

Why not half?

    3pi does not close both 4pi and 2pi sectors.

Why not two?

    two full layers duplicate the terminal write and violate minimal next-write.

Why not taxed?

    the D-scale amplitude tax belongs to internal branch participation.
    the top closure is a terminal completion load.

## Diagnostic

    predicted_top_e = 336869.6242111989
    predicted_vs_target = 0.9937157056377548
    exact_gap_minus_6pi = 0.11920527907177458

## Boundary

This is a criterion candidate, not a full action theorem.
Top/e is not solved.
No species map.
No V12.13 promotion.
