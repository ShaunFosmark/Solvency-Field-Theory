#!/usr/bin/env python3
"""
SFT V12.12B R205M — Self-Generated Boundary Dilution Feedback Gate

Clean local version:
- one Python file
- one run folder
- one ZIP
- no plotting
- no embedded markdown code fences
- no species labels
- no empirical mass table
"""

from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R205M_Self_Generated_Boundary_Dilution_Feedback_Gate"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865
SIX_PI = 6.0 * math.pi
THREE_PI = 3.0 * math.pi
HALF_K_REQ = K_REQ / 2.0

RHO0 = 0.5
RHO_SPAN = 4.0

SEED_MODES = [
    Fraction(1, 2),
    Fraction(2, 3),
    Fraction(3, 4),
    Fraction(1, 1),
    Fraction(5, 4),
    Fraction(4, 3),
    Fraction(3, 2),
    Fraction(5, 3),
    Fraction(2, 1),
]

D_PERP = 3


def utc_now_iso() -> str:
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def frac_str(f: Fraction) -> str:
    if f.denominator == 1:
        return str(f.numerator)
    return f"{f.numerator}/{f.denominator}"


def balanced_occupancy(m: int, n: int) -> list[int]:
    active = min(max(n, 1), D_PERP)
    q, r = divmod(m, active)
    occ = [q + 1 if i < r else q for i in range(active)]
    occ += [0] * (D_PERP - len(occ))
    occ.sort(reverse=True)
    return occ


def shape_stats(occ: list[int]) -> dict:
    total = sum(occ)
    probs = [x / total for x in occ] if total else [0.0, 0.0, 0.0]

    l2 = math.sqrt(sum(p * p for p in probs))
    iso = 1.0 / D_PERP

    eccentricity = 0.0
    if total:
        eccentricity = math.sqrt(sum((p - iso) ** 2 for p in probs)) / math.sqrt(2.0 / 3.0)

    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    entropy_norm = entropy / math.log(D_PERP)
    entropy_deficit = 1.0 - entropy_norm

    return {
        "shape_l2_norm": l2,
        "eccentricity_norm": eccentricity,
        "entropy_norm": entropy_norm,
        "entropy_deficit": entropy_deficit,
    }


def build_modes() -> pd.DataFrame:
    rows = []

    for rho in SEED_MODES:
        m = rho.numerator
        n = rho.denominator
        occ = balanced_occupancy(m, n)
        stats = shape_stats(occ)

        rows.append({
            "rho": frac_str(rho),
            "rho_float": float(rho),
            "m": m,
            "N": n,
            "occupancy_vector": "(" + ",".join(str(x) for x in occ) + ")",
            "occ0": occ[0],
            "occ1": occ[1],
            "occ2": occ[2],
            "shape_l2_norm": stats["shape_l2_norm"],
            "eccentricity_norm": stats["eccentricity_norm"],
            "entropy_norm": stats["entropy_norm"],
            "entropy_deficit": stats["entropy_deficit"],
            "u_logrho": math.log(float(rho) / RHO0) / math.log(RHO_SPAN),
        })

    return pd.DataFrame(rows).sort_values("rho_float").reset_index(drop=True)


def fibonacci_sphere(n: int = 300) -> np.ndarray:
    pts = []
    phi = math.pi * (3.0 - math.sqrt(5.0))

    for i in range(n):
        y = 1.0 - (i / float(n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - y * y))
        theta = phi * i
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        pts.append([x, y, z])

    return np.array(pts, dtype=float)


SPHERE_POINTS = fibonacci_sphere(300)
RHAT = SPHERE_POINTS.copy()


def ring_basis(axis_index: int) -> tuple[np.ndarray, np.ndarray]:
    if axis_index == 0:
        return np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])
    if axis_index == 1:
        return np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])
    return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])


def source_points_ring(
    occ: list[int],
    ring_radius: float = 0.55,
    n_per_ring: int = 36,
) -> tuple[np.ndarray, np.ndarray]:
    positions = []
    weights = []

    for axis_index, weight in enumerate(occ):
        if weight <= 0:
            continue

        e1, e2 = ring_basis(axis_index)

        for j in range(n_per_ring):
            t = 2.0 * math.pi * j / n_per_ring
            point = ring_radius * (math.cos(t) * e1 + math.sin(t) * e2)
            positions.append(point)
            weights.append(weight / n_per_ring)

    return np.array(positions, dtype=float), np.array(weights, dtype=float)


def eval_ring_geometry(
    occ: list[int],
    softening: float = 0.12,
    ring_radius: float = 0.55,
) -> dict:
    pos, weights = source_points_ring(occ, ring_radius=ring_radius)

    potentials = []
    grad_mags = []
    abs_radial_curvatures = []

    for x, rh in zip(SPHERE_POINTS, RHAT):
        d = x[None, :] - pos
        d2 = np.sum(d * d, axis=1) + softening ** 2
        R = np.sqrt(d2)

        potential = np.sum(weights / R)

        grad = np.sum((-weights[:, None] * d) / (R[:, None] ** 3), axis=0)
        grad_mag = np.linalg.norm(grad)

        rd = d @ rh
        hess_radial = np.sum(weights * (-1.0 / (R ** 3) + 3.0 * (rd ** 2) / (R ** 5)))

        potentials.append(float(potential))
        grad_mags.append(float(grad_mag))
        abs_radial_curvatures.append(abs(float(hess_radial)))

    return {
        "mean_potential": float(np.mean(potentials)),
        "mean_gradient_magnitude": float(np.mean(grad_mags)),
        "mean_abs_radial_curvature": float(np.mean(abs_radial_curvatures)),
        "p95_abs_radial_curvature": float(np.quantile(abs_radial_curvatures, 0.95)),
    }


def add_geometry_signal(modes: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in modes.iterrows():
        occ = [int(row["occ0"]), int(row["occ1"]), int(row["occ2"])]
        obs = eval_ring_geometry(occ)

        rec = row.to_dict()
        rec.update(obs)
        rows.append(rec)

    df = pd.DataFrame(rows)

    for col in [
        "mean_potential",
        "mean_gradient_magnitude",
        "mean_abs_radial_curvature",
        "p95_abs_radial_curvature",
    ]:
        base = df.loc[df["rho"] == "1/2", col].iloc[0]
        df[col + "_ratio_to_rho_half"] = df[col] / base

    df["G_i_geometry_ratio"] = df["mean_abs_radial_curvature_ratio_to_rho_half"]
    return df


def target_power_exponent(target_span: float) -> float:
    return math.log(target_span) / math.log(RHO_SPAN)


P_D = target_power_exponent(D_TARGET)
P_TOP = target_power_exponent(TOP_E_TARGET)
P_HALF_6PI = (SIX_PI / 2.0) / math.log(RHO_SPAN)
P_HALF_KREQ = (K_REQ / 2.0) / math.log(RHO_SPAN)


def add_targets(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    out["target_D_rhopower"] = (out["rho_float"] / RHO0) ** P_D
    out["target_top_e_rhopower"] = (out["rho_float"] / RHO0) ** P_TOP
    out["target_half_6pi_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_6PI
    out["target_half_Kreq_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_KREQ

    return out


def feedback_model_outputs(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    model_specs = [
        ("geometry_only", "M = G"),
        ("half_6pi_feedback", "M = G * exp(3pi*u)"),
        ("half_Kreq_feedback", "M = G * exp((Kreq/2)*u)"),
        ("full_6pi_feedback", "M = G * exp(6pi*u)"),
        ("capacity_eta_3_4_cubic", "M = G / (1 - 0.75*u)^3"),
        ("capacity_eta_15_16_cubic", "M = G / (1 - 15/16*u)^3"),
    ]

    for _, row in df.iterrows():
        G = float(row["G_i_geometry_ratio"])
        u = float(row["u_logrho"])

        for model_id, formula in model_specs:
            if model_id == "geometry_only":
                M = G
            elif model_id == "half_6pi_feedback":
                M = G * math.exp(THREE_PI * u)
            elif model_id == "half_Kreq_feedback":
                M = G * math.exp(HALF_K_REQ * u)
            elif model_id == "full_6pi_feedback":
                M = G * math.exp(SIX_PI * u)
            elif model_id == "capacity_eta_3_4_cubic":
                M = G / ((1.0 - 0.75 * u) ** 3)
            elif model_id == "capacity_eta_15_16_cubic":
                M = G / ((1.0 - (15.0 / 16.0) * u) ** 3)
            else:
                raise ValueError(model_id)

            rows.append({
                "rho": row["rho"],
                "rho_float": row["rho_float"],
                "m": int(row["m"]),
                "N": int(row["N"]),
                "occupancy_vector": row["occupancy_vector"],
                "G_i_geometry_ratio": G,
                "u_logrho": u,
                "model_id": model_id,
                "formula": formula,
                "model_ratio_to_rho_half": M,
                "target_D_rhopower": row["target_D_rhopower"],
                "target_top_e_rhopower": row["target_top_e_rhopower"],
                "residual_log_vs_D": math.log(M / row["target_D_rhopower"]) if M > 0 else np.nan,
                "residual_log_vs_top_e": math.log(M / row["target_top_e_rhopower"]) if M > 0 else np.nan,
            })

    return pd.DataFrame(rows)


def required_feedback_loads(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    targets = [
        ("D_rhopower", "target_D_rhopower"),
        ("top_e_rhopower", "target_top_e_rhopower"),
        ("half_6pi_rhopower", "target_half_6pi_rhopower"),
        ("half_Kreq_rhopower", "target_half_Kreq_rhopower"),
    ]

    for _, row in df.iterrows():
        G = float(row["G_i_geometry_ratio"])
        u = float(row["u_logrho"])

        for target_name, target_col in targets:
            target = float(row[target_col])

            if abs(u) < 1e-12:
                L_required = np.nan
            else:
                L_required = math.log(target / G) / u

            rows.append({
                "rho": row["rho"],
                "rho_float": row["rho_float"],
                "m": int(row["m"]),
                "N": int(row["N"]),
                "G_i_geometry_ratio": G,
                "u_logrho": u,
                "target_name": target_name,
                "target_ratio": target,
                "L_required": L_required,
                "L_required_minus_3pi": L_required - THREE_PI if not np.isnan(L_required) else np.nan,
                "L_required_minus_Kreq_half": L_required - HALF_K_REQ if not np.isnan(L_required) else np.nan,
            })

    return pd.DataFrame(rows)


def summarize_models(models: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for model_id, grp in models.groupby("model_id"):
        ordered = grp.sort_values("rho_float")

        endpoint = float(ordered["model_ratio_to_rho_half"].iloc[-1])
        span = float(ordered["model_ratio_to_rho_half"].max() / ordered["model_ratio_to_rho_half"].min())

        rmse_D = float(np.sqrt(np.nanmean(ordered["residual_log_vs_D"] ** 2)))
        rmse_top = float(np.sqrt(np.nanmean(ordered["residual_log_vs_top_e"] ** 2)))

        rows.append({
            "model_id": model_id,
            "endpoint_rho2": endpoint,
            "span_max_over_min": span,
            "rmse_log_vs_D_target": rmse_D,
            "rmse_log_vs_top_e_target": rmse_top,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
        })

    return pd.DataFrame(rows).sort_values("rmse_log_vs_D_target")


def summarize_required_L(required: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for target, grp in required.dropna(subset=["L_required"]).groupby("target_name"):
        ordered = grp.sort_values("rho_float")
        vals = ordered["L_required"].to_numpy(float)

        rows.append({
            "target_name": target,
            "mean_L_required": float(np.mean(vals)),
            "std_L_required": float(np.std(vals)),
            "cv_L_required": float(np.std(vals) / abs(np.mean(vals))) if np.mean(vals) else np.nan,
            "endpoint_L_required_rho2": float(ordered["L_required"].iloc[-1]),
            "endpoint_minus_3pi": float(ordered["L_required"].iloc[-1] - THREE_PI),
            "endpoint_minus_Kreq_half": float(ordered["L_required"].iloc[-1] - HALF_K_REQ),
        })

    return pd.DataFrame(rows)


def build_gate_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "gate": "tick_rate_cancellation",
            "test": "If reinforcement and dilution are per-cycle terms multiplied by nu_C, tick rate cancels in equilibrium.",
            "status": "FORMALIZED",
            "boundary": "Needs native R_i and B_i."
        },
        {
            "gate": "self_generated_dilution",
            "test": "Gamma_settle as local boundary-capacity dilution from the particle's own writes.",
            "status": "CANDIDATE",
            "boundary": "Must derive dilution law from area-write rule."
        },
        {
            "gate": "linear_control",
            "test": "Geometry-only settlement remains weak.",
            "status": "EXPECTED_FAIL",
            "boundary": "Confirms need for feedback."
        },
        {
            "gate": "half_action_feedback",
            "test": "M = G exp(3pi u) tested as forward toy.",
            "status": "CANDIDATE",
            "boundary": "Not derived unless R_i/B_i produce it."
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need native equation and null wins."
        },
    ])


def build_claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "Gamma_settle can be interpreted as self-generated boundary-capacity dilution.",
            "status": "CANDIDATE",
            "boundary": "Sharper than arbitrary relaxation."
        },
        {
            "category": "Preserved",
            "claim": "Half-action feedback is a concrete forward target.",
            "status": "CANDIDATE",
            "boundary": "Motivated by R203 inverse shape."
        },
        {
            "category": "Rejected",
            "claim": "R205M derives the particle mass hierarchy.",
            "status": "NO",
            "boundary": "Toy feedback only."
        },
        {
            "category": "Rejected",
            "claim": "R205M maps modes to Standard Model species.",
            "status": "NO",
            "boundary": "No species labels used."
        },
        {
            "category": "Open",
            "claim": "Native feedback equation from master action.",
            "status": "OPEN",
            "boundary": "Main next gate."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def build_report(
    created_utc: str,
    verdict: str,
    model_summary: pd.DataFrame,
    L_summary: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
    geometry_endpoint: float,
) -> str:
    return f"""
# SFT V12.12B R205M — Self-Generated Boundary Dilution Feedback Gate

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R205M tests the proposed native opponent term:
Gamma_settle is local boundary-capacity dilution generated by the particle's own writes.

The particle's ticks do two things:
1. local compounding:
   closed energy returns through its own settlement dip and reinforces it

2. local capacity dilution:
   the same writes add local boundary capacity and dilute or absorb the settlement

Mechanical rewrite:
Old skeleton:
dS/dt = nu_C Delta_close - Gamma_settle S

R205M cycle form:
dS_i/dt = nu_i dS_i/dn
dS_i/dn = R_i(S_i) - B_i(S_i)

If both terms are per-cycle terms multiplied by the same tick rate, equilibrium is:
R_i(S_i) = B_i(S_i)

Feedback coordinate:
u_i = log(rho_i / rho_0) / log(4)
rho_0 = 1/2

Toy forward family:
M_i = G_i * Feedback(u_i)

where G_i is the ring Green geometry ratio.

Key constants:
D target context      = {D_TARGET}
top/e target context  = {TOP_E_TARGET}
6pi                   = {SIX_PI}
3pi                   = {THREE_PI}
K_req / 2             = {HALF_K_REQ}
R202-like G(rho=2)    = {geometry_endpoint}

Forward model summary:
{model_summary.to_string(index=False)}

Required exponential load summary:
{L_summary.to_string(index=False)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
The half-action feedback toy is:
M_i = G_i * exp(3pi * u_i)

This is not a derivation. It is a forward candidate suggested by the R203 inverse shape.

The native derivation still has to show why the self-generated dilution/reinforcement balance produces the half-action coefficient.

Ruling:
No V12.13 promotion.

Next recommended run:
R206M — Native Area-Write Dilution Law Derivation Attempt

Question:
Can the rule "each phase rotation adds one boundary area" produce B_i(S_i), the local capacity-dilution term, without fitting?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    modes = build_modes()
    geometry = add_geometry_signal(modes)
    target_geometry = add_targets(geometry)

    models = feedback_model_outputs(target_geometry)
    required = required_feedback_loads(target_geometry)

    model_summary = summarize_models(models)
    L_summary = summarize_required_L(required)
    gates = build_gate_matrix()
    claims = build_claim_boundary()

    verdict = (
        "PARTIAL_PASS_SELF_GENERATED_BOUNDARY_DILUTION_FORMALIZED_"
        "HALF_ACTION_FEEDBACK_TESTED_AS_FORWARD_CANDIDATE_"
        "NATIVE_DILUTION_LAW_NOT_DERIVED_NO_V12_13"
    )

    geometry_endpoint = float(geometry.sort_values("rho_float").iloc[-1]["G_i_geometry_ratio"])

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "sixpi": SIX_PI,
            "threepi": THREE_PI,
            "K_req_half": HALF_K_REQ,
            "p_D": P_D,
            "p_top": P_TOP,
            "p_half_6pi": P_HALF_6PI,
            "p_half_Kreq": P_HALF_KREQ,
        },
        "geometry_endpoint": {
            "rho2_G_i_geometry_ratio": geometry_endpoint
        },
        "best_forward_models_by_D_rmse": model_summary.head(6).to_dict(orient="records"),
        "required_feedback_load_summary": L_summary.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R206M - Native Area-Write Dilution Law Derivation Attempt",
    }

    modes.to_csv(tables / "R205M_mode_geometry_inputs.csv", index=False)
    geometry.to_csv(tables / "R205M_geometry_signal.csv", index=False)
    models.to_csv(tables / "R205M_forward_feedback_model_outputs.csv", index=False)
    model_summary.to_csv(tables / "R205M_forward_model_summary.csv", index=False)
    required.to_csv(tables / "R205M_required_feedback_loads_by_mode.csv", index=False)
    L_summary.to_csv(tables / "R205M_required_feedback_load_summary.csv", index=False)
    gates.to_csv(tables / "R205M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R205M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        model_summary=model_summary,
        L_summary=L_summary,
        gates=gates,
        claims=claims,
        geometry_endpoint=geometry_endpoint,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(final_payload, indent=2))


if __name__ == "__main__":
    main()
