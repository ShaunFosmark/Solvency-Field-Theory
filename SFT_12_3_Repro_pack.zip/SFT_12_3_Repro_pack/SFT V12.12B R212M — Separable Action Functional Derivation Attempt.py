#!/usr/bin/env python3
"""
SFT V12.12B R212M — Separable Action Functional Derivation Attempt

Purpose:
    Try to move the R210/R211 3:2 result from "good bookkeeping"
    toward a separable-action statement.

Question:
    Can the master-action structure be written or approximated as two
    separable amplitude sectors:

        WHERE sector:
            spatial settlement support in 3 dimensions

        HOW sector:
            phase refresh from 2 closure completions

    so that the effective feedback law is:

        M_i = G_i * exp(L_eff * u_i)

        L_eff = 3π - 1/2 ln(25/13)

Core idea:
    If the quadratic/linearized action decomposes into two projector sectors,

        P_space, rank 3
        P_phase, rank 2

    and the amplitude participation is computed by sector trace weights,

        W_space = Tr(P_space) = 3
        W_phase = Tr(P_phase) = 2

    then

        p_space = 3/5
        p_phase = 2/5
        N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13
        tax = 1/2 ln(25/13)
        L_eff = 3π - 1/2 ln(25/13)

Critical null:
    If the same five components are treated as five independent equal channels,
    then N_eff = 5 and the endpoint fails. So the key premise is not the count
    3+2 alone. The key premise is grouping into two action sectors.

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - no V12.13 promotion inside this run

Outputs:
    SFT_V12_12B_R212M_Separable_Action_Functional_Derivation_Attempt/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R212M.py

    SFT_V12_12B_R212M_Separable_Action_Functional_Derivation_Attempt_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R212M_Separable_Action_Functional_Derivation_Attempt"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
SQRT2 = math.sqrt(2.0)
PHI = (1.0 + math.sqrt(5.0)) / 2.0

TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi
HALF_K_REQ = K_REQ / 2.0

RHO0 = 0.5
RHO_SPAN = 4.0

SEED_MODES = [
    Fraction(1, 2),
    Fraction(2, 3),
    Fraction(3, 4),
    Fraction(1, 1),
    Fraction(5, 4),
    Fraction(4, 3),
    Fraction(3, 2),
    Fraction(5, 3),
    Fraction(2, 1),
]

D_PERP = 3


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def frac_str(f: Fraction) -> str:
    if f.denominator == 1:
        return str(f.numerator)
    return f"{f.numerator}/{f.denominator}"


def balanced_occupancy(m: int, n: int) -> list[int]:
    active = min(max(n, 1), D_PERP)
    q, r = divmod(m, active)

    occ = [q + 1 if i < r else q for i in range(active)]
    occ += [0] * (D_PERP - len(occ))
    occ.sort(reverse=True)

    return occ


def shape_stats(occ: list[int]) -> dict:
    total = sum(occ)
    probs = [x / total for x in occ] if total else [0.0, 0.0, 0.0]

    l2 = math.sqrt(sum(p * p for p in probs))
    iso = 1.0 / D_PERP

    eccentricity = 0.0
    if total:
        eccentricity = math.sqrt(sum((p - iso) ** 2 for p in probs)) / math.sqrt(2.0 / 3.0)

    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    entropy_norm = entropy / math.log(D_PERP)
    entropy_deficit = 1.0 - entropy_norm

    active_slots = sum(1 for x in occ if x > 0)
    max_occ = max(occ) if occ else 0
    slot_fill_fraction = active_slots / D_PERP

    return {
        "shape_l2_norm": l2,
        "eccentricity_norm": eccentricity,
        "entropy_norm": entropy_norm,
        "entropy_deficit": entropy_deficit,
        "active_slots": active_slots,
        "max_occ": max_occ,
        "slot_fill_fraction": slot_fill_fraction,
    }


def build_modes() -> pd.DataFrame:
    rows = []

    for rho in SEED_MODES:
        m = rho.numerator
        n = rho.denominator
        occ = balanced_occupancy(m, n)
        stats = shape_stats(occ)

        rows.append({
            "rho": frac_str(rho),
            "rho_float": float(rho),
            "m": m,
            "N": n,
            "occupancy_vector": "(" + ",".join(str(x) for x in occ) + ")",
            "occ0": occ[0],
            "occ1": occ[1],
            "occ2": occ[2],
            "active_slots": stats["active_slots"],
            "max_occ": stats["max_occ"],
            "slot_fill_fraction": stats["slot_fill_fraction"],
            "shape_l2_norm": stats["shape_l2_norm"],
            "eccentricity_norm": stats["eccentricity_norm"],
            "entropy_norm": stats["entropy_norm"],
            "entropy_deficit": stats["entropy_deficit"],
            "u_logrho": math.log(float(rho) / RHO0) / math.log(RHO_SPAN),
        })

    return pd.DataFrame(rows).sort_values("rho_float").reset_index(drop=True)


def fibonacci_sphere(n: int = 300) -> np.ndarray:
    pts = []
    phi = math.pi * (3.0 - math.sqrt(5.0))

    for i in range(n):
        y = 1.0 - (i / float(n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - y * y))
        theta = phi * i
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        pts.append([x, y, z])

    return np.array(pts, dtype=float)


SPHERE_POINTS = fibonacci_sphere(300)
RHAT = SPHERE_POINTS.copy()


def ring_basis(axis_index: int) -> tuple[np.ndarray, np.ndarray]:
    if axis_index == 0:
        return np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])
    if axis_index == 1:
        return np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])
    return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])


def source_points_ring(
    occ: list[int],
    ring_radius: float = 0.55,
    n_per_ring: int = 36,
) -> tuple[np.ndarray, np.ndarray]:
    positions = []
    weights = []

    for axis_index, weight in enumerate(occ):
        if weight <= 0:
            continue

        e1, e2 = ring_basis(axis_index)

        for j in range(n_per_ring):
            t = 2.0 * math.pi * j / n_per_ring
            point = ring_radius * (math.cos(t) * e1 + math.sin(t) * e2)
            positions.append(point)
            weights.append(weight / n_per_ring)

    return np.array(positions, dtype=float), np.array(weights, dtype=float)


def eval_ring_geometry(
    occ: list[int],
    softening: float = 0.12,
    ring_radius: float = 0.55,
) -> dict:
    pos, weights = source_points_ring(occ, ring_radius=ring_radius)

    potentials = []
    grad_mags = []
    abs_radial_curvatures = []

    for x, rh in zip(SPHERE_POINTS, RHAT):
        d = x[None, :] - pos
        d2 = np.sum(d * d, axis=1) + softening ** 2
        R = np.sqrt(d2)

        potential = np.sum(weights / R)

        grad = np.sum((-weights[:, None] * d) / (R[:, None] ** 3), axis=0)
        grad_mag = np.linalg.norm(grad)

        rd = d @ rh
        hess_radial = np.sum(weights * (-1.0 / (R ** 3) + 3.0 * (rd ** 2) / (R ** 5)))

        potentials.append(float(potential))
        grad_mags.append(float(grad_mag))
        abs_radial_curvatures.append(abs(float(hess_radial)))

    return {
        "mean_potential": float(np.mean(potentials)),
        "mean_gradient_magnitude": float(np.mean(grad_mags)),
        "mean_abs_radial_curvature": float(np.mean(abs_radial_curvatures)),
        "p95_abs_radial_curvature": float(np.quantile(abs_radial_curvatures, 0.95)),
    }


def add_geometry_signal(modes: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in modes.iterrows():
        occ = [int(row["occ0"]), int(row["occ1"]), int(row["occ2"])]
        obs = eval_ring_geometry(occ)

        rec = row.to_dict()
        rec.update(obs)
        rows.append(rec)

    df = pd.DataFrame(rows)

    for col in [
        "mean_potential",
        "mean_gradient_magnitude",
        "mean_abs_radial_curvature",
        "p95_abs_radial_curvature",
    ]:
        base = df.loc[df["rho"] == "1/2", col].iloc[0]
        df[col + "_ratio_to_rho_half"] = df[col] / base

    df["G_i_geometry_ratio"] = df["mean_abs_radial_curvature_ratio_to_rho_half"]
    return df


def target_power_exponent(target_span: float) -> float:
    return math.log(target_span) / math.log(RHO_SPAN)


P_D = target_power_exponent(D_TARGET)
P_TOP = target_power_exponent(TOP_E_TARGET)
P_HALF_6PI = (SIX_PI / 2.0) / math.log(RHO_SPAN)
P_HALF_KREQ = (K_REQ / 2.0) / math.log(RHO_SPAN)


def add_targets(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    out["target_D_rhopower"] = (out["rho_float"] / RHO0) ** P_D
    out["target_top_e_rhopower"] = (out["rho_float"] / RHO0) ** P_TOP
    out["target_half_6pi_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_6PI
    out["target_half_Kreq_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_KREQ

    return out


def amplitude_tax_from_shares(shares: list[float]) -> dict:
    arr = np.array(shares, dtype=float)
    arr = arr[arr > 0]

    if arr.size == 0:
        return {
            "N_eff": 1.0,
            "amplitude_tax": 0.0,
            "c_ln2": 0.0,
            "share_string": "()",
            "p_high": np.nan,
            "p_low": np.nan,
            "imbalance": np.nan,
            "participation_sum_squares": 1.0,
        }

    arr = arr / np.sum(arr)
    sumsq = float(np.sum(arr * arr))
    N_eff = 1.0 / sumsq
    amplitude_tax = 0.5 * math.log(N_eff)
    c_ln2 = amplitude_tax / LN2

    sorted_arr = sorted(arr.tolist(), reverse=True)
    if len(sorted_arr) >= 2:
        p_high = sorted_arr[0]
        p_low = sorted_arr[1]
        imbalance = p_high - p_low
    else:
        p_high = sorted_arr[0]
        p_low = 0.0
        imbalance = p_high

    return {
        "N_eff": N_eff,
        "amplitude_tax": amplitude_tax,
        "c_ln2": c_ln2,
        "share_string": "(" + ",".join(f"{x:.12g}" for x in arr.tolist()) + ")",
        "p_high": p_high,
        "p_low": p_low,
        "imbalance": imbalance,
        "participation_sum_squares": sumsq,
    }


def required_D_split_from_geometry(geometry_endpoint: float) -> dict:
    L_required = math.log(D_TARGET / geometry_endpoint)
    tax_required = THREE_PI - L_required
    c_required = tax_required / LN2
    N_eff = math.exp(2.0 * tax_required)

    if 1.0 <= N_eff <= 2.0:
        sumsq = 1.0 / N_eff
        y2 = max(0.0, (sumsq - 0.5) / 2.0)
        y = math.sqrt(y2)
        p_high = 0.5 + y
        p_low = 0.5 - y
        possible = True
    else:
        p_high = np.nan
        p_low = np.nan
        possible = False

    return {
        "L_required_endpoint": L_required,
        "tax_required": tax_required,
        "c_required": c_required,
        "N_eff_required": N_eff,
        "two_channel_possible": possible,
        "p_high_required": p_high,
        "p_low_required": p_low,
        "imbalance_required": p_high - p_low if possible else np.nan,
    }


def projector_audit() -> pd.DataFrame:
    P_space = np.diag([1.0, 1.0, 1.0, 0.0, 0.0])
    P_phase = np.diag([0.0, 0.0, 0.0, 1.0, 1.0])
    I = np.eye(5)

    audits = []

    matrices = [
        ("P_space", P_space, "three-dimensional spatial support projector"),
        ("P_phase", P_phase, "two-dimensional phase-refresh projector"),
        ("P_total", P_space + P_phase, "full 3+2 projector sum"),
    ]

    for name, M, reading in matrices:
        rank = int(np.linalg.matrix_rank(M))
        trace = float(np.trace(M))
        idem_error = float(np.linalg.norm(M @ M - M))
        symmetry_error = float(np.linalg.norm(M - M.T))

        audits.append({
            "matrix": name,
            "reading": reading,
            "rank": rank,
            "trace": trace,
            "idempotence_error_norm": idem_error,
            "symmetry_error_norm": symmetry_error,
            "is_projector": bool(idem_error < 1e-12 and symmetry_error < 1e-12),
        })

    orthogonality_error = float(np.linalg.norm(P_space @ P_phase))
    completeness_error = float(np.linalg.norm((P_space + P_phase) - I))

    audits.append({
        "matrix": "P_space_P_phase_orthogonality",
        "reading": "space and phase sectors are orthogonal blocks in the separable approximation",
        "rank": np.nan,
        "trace": np.nan,
        "idempotence_error_norm": orthogonality_error,
        "symmetry_error_norm": np.nan,
        "is_projector": bool(orthogonality_error < 1e-12),
    })

    audits.append({
        "matrix": "P_space_plus_P_phase_completeness",
        "reading": "space plus phase spans the 3+2 audit vector space",
        "rank": np.nan,
        "trace": np.nan,
        "idempotence_error_norm": completeness_error,
        "symmetry_error_norm": np.nan,
        "is_projector": bool(completeness_error < 1e-12),
    })

    return pd.DataFrame(audits)


def sector_models(geometry_endpoint: float) -> pd.DataFrame:
    req = required_D_split_from_geometry(geometry_endpoint)
    p_req = req["p_high_required"]

    rows = [
        {
            "model_id": "separable_projector_trace_3_to_2",
            "family": "separable_action",
            "shares": [3.0, 2.0],
            "uses_D_to_define": False,
            "native_prior": 10.0,
            "mechanical_reading": "sector trace weights from rank(P_space)=3 and rank(P_phase)=2",
            "proof_status": "conditional_pass_if_sector_trace_coarse_graining_is_valid",
        },
        {
            "model_id": "ungrouped_five_eigenchannels_null",
            "family": "null",
            "shares": [1.0, 1.0, 1.0, 1.0, 1.0],
            "uses_D_to_define": False,
            "native_prior": 4.0,
            "mechanical_reading": "five equal independent eigenchannels",
            "proof_status": "null_control",
        },
        {
            "model_id": "equal_two_sector_sqrt2",
            "family": "binary_base",
            "shares": [1.0, 1.0],
            "uses_D_to_define": False,
            "native_prior": 7.0,
            "mechanical_reading": "two equal sectors, no 3:2 trace weighting",
            "proof_status": "lower_order_binary_approximation",
        },
        {
            "model_id": "sqrt_rank_3_to_2",
            "family": "amplitude_count_control",
            "shares": [math.sqrt(3.0), math.sqrt(2.0)],
            "uses_D_to_define": False,
            "native_prior": 6.0,
            "mechanical_reading": "sector amplitudes from square roots of ranks rather than traces",
            "proof_status": "control",
        },
        {
            "model_id": "spinor_frame_sqrt_4pi_2pi_bridge",
            "family": "spinor_frame_bridge",
            "shares": [math.sqrt(FOUR_PI), math.sqrt(TWO_PI)],
            "uses_D_to_define": False,
            "native_prior": 8.0,
            "mechanical_reading": "sector amplitudes from sqrt(4π) spinor and sqrt(2π) frame closures",
            "proof_status": "supportive_bridge",
        },
        {
            "model_id": "spinor_frame_4pi_2pi_load",
            "family": "spinor_frame_bridge",
            "shares": [FOUR_PI, TWO_PI],
            "uses_D_to_define": False,
            "native_prior": 7.0,
            "mechanical_reading": "sector weights from direct 4π and 2π closure loads",
            "proof_status": "control_bridge",
        },
        {
            "model_id": "three_plus_one_support_tangent",
            "family": "3plus1_control",
            "shares": [3.0, 1.0],
            "uses_D_to_define": False,
            "native_prior": 5.0,
            "mechanical_reading": "3 spatial support versus 1 tangent/write channel",
            "proof_status": "control",
        },
        {
            "model_id": "D_inferred_split_diagnostic",
            "family": "diagnostic_only",
            "shares": [p_req, 1.0 - p_req],
            "uses_D_to_define": True,
            "native_prior": -8.0,
            "mechanical_reading": "split inferred from D endpoint",
            "proof_status": "diagnostic_only_uses_D",
        },
    ]

    out = []

    for row in rows:
        tax = amplitude_tax_from_shares(row["shares"])
        rec = dict(row)
        rec.update({
            "shares_normalized": tax["share_string"],
            "N_eff": tax["N_eff"],
            "amplitude_tax": tax["amplitude_tax"],
            "c_ln2": tax["c_ln2"],
            "L_eff": THREE_PI - tax["amplitude_tax"],
            "p_high": tax["p_high"],
            "p_low": tax["p_low"],
            "imbalance": tax["imbalance"],
            "distance_to_required_p_high": abs(tax["p_high"] - p_req) if not np.isnan(p_req) else np.nan,
            "closed_form_hint": closed_form_hint(row["model_id"]),
        })
        out.append(rec)

    return pd.DataFrame(out)


def closed_form_hint(model_id: str) -> str:
    if model_id == "separable_projector_trace_3_to_2":
        return "L_eff = 3pi - 1/2 ln(25/13)"
    if model_id == "ungrouped_five_eigenchannels_null":
        return "L_eff = 3pi - 1/2 ln5"
    if model_id == "equal_two_sector_sqrt2":
        return "L_eff = 3pi - 1/2 ln2"
    if model_id == "spinor_frame_4pi_2pi_load":
        return "L_eff = 3pi - 1/2 ln(9/5)"
    return "L_eff = 3pi - 1/2 ln(N_eff)"


def evaluate_models(df: pd.DataFrame, models: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in df.iterrows():
        G = float(row["G_i_geometry_ratio"])
        u = float(row["u_logrho"])

        for _, model in models.iterrows():
            L_eff = float(model["L_eff"])
            ratio = G * math.exp(L_eff * u)

            rows.append({
                "rho": row["rho"],
                "rho_float": row["rho_float"],
                "m": int(row["m"]),
                "N": int(row["N"]),
                "occupancy_vector": row["occupancy_vector"],
                "G_i_geometry_ratio": G,
                "u_logrho": u,
                "model_id": model["model_id"],
                "family": model["family"],
                "proof_status": model["proof_status"],
                "uses_D_to_define": bool(model["uses_D_to_define"]),
                "native_prior": float(model["native_prior"]),
                "mechanical_reading": model["mechanical_reading"],
                "closed_form_hint": model["closed_form_hint"],
                "shares_normalized": model["shares_normalized"],
                "N_eff": float(model["N_eff"]),
                "amplitude_tax": float(model["amplitude_tax"]),
                "c_ln2": float(model["c_ln2"]),
                "L_eff": L_eff,
                "p_high": float(model["p_high"]),
                "p_low": float(model["p_low"]),
                "imbalance": float(model["imbalance"]),
                "model_ratio_to_rho_half": ratio,
                "target_D_rhopower": row["target_D_rhopower"],
                "target_top_e_rhopower": row["target_top_e_rhopower"],
                "residual_log_vs_D": math.log(ratio / row["target_D_rhopower"]) if ratio > 0 else np.nan,
                "residual_log_vs_top_e": math.log(ratio / row["target_top_e_rhopower"]) if ratio > 0 else np.nan,
            })

    return pd.DataFrame(rows)


def summarize_models(outputs: pd.DataFrame, models: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for model_id, grp in outputs.groupby("model_id"):
        ordered = grp.sort_values("rho_float")
        endpoint = float(ordered["model_ratio_to_rho_half"].iloc[-1])
        span = float(ordered["model_ratio_to_rho_half"].max() / ordered["model_ratio_to_rho_half"].min())
        rmse_D = float(np.sqrt(np.nanmean(ordered["residual_log_vs_D"] ** 2)))
        rmse_top = float(np.sqrt(np.nanmean(ordered["residual_log_vs_top_e"] ** 2)))

        model = models[models["model_id"] == model_id].iloc[0]
        endpoint_log_error_abs = abs(math.log(endpoint / D_TARGET)) if endpoint > 0 else np.inf

        score = float(model["native_prior"])

        if endpoint_log_error_abs < 0.001:
            score += 6.0
        elif endpoint_log_error_abs < 0.01:
            score += 5.0
        elif endpoint_log_error_abs < 0.03:
            score += 4.0
        elif endpoint_log_error_abs < 0.1:
            score += 3.0
        elif endpoint_log_error_abs < 0.25:
            score += 2.0
        elif endpoint_log_error_abs < 0.5:
            score += 1.0

        if rmse_D < 0.60:
            score += 3.0
        elif rmse_D < 0.70:
            score += 2.0
        elif rmse_D < 0.85:
            score += 1.0

        if bool(model["uses_D_to_define"]):
            score -= 12.0
        if "null" in str(model["family"]):
            score -= 1.0
        if "control" in str(model["proof_status"]):
            score -= 1.0

        rows.append({
            "model_id": model_id,
            "family": model["family"],
            "proof_status": model["proof_status"],
            "uses_D_to_define": bool(model["uses_D_to_define"]),
            "native_prior": float(model["native_prior"]),
            "mechanical_reading": model["mechanical_reading"],
            "closed_form_hint": model["closed_form_hint"],
            "shares_normalized": model["shares_normalized"],
            "p_high": float(model["p_high"]),
            "p_low": float(model["p_low"]),
            "imbalance": float(model["imbalance"]),
            "N_eff": float(model["N_eff"]),
            "amplitude_tax": float(model["amplitude_tax"]),
            "c_ln2": float(model["c_ln2"]),
            "L_eff": float(model["L_eff"]),
            "endpoint_rho2": endpoint,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
            "endpoint_log_error_vs_D_abs": endpoint_log_error_abs,
            "span_max_over_min": span,
            "rmse_log_vs_D_target": rmse_D,
            "rmse_log_vs_top_e_target": rmse_top,
            "distance_to_required_p_high": float(model["distance_to_required_p_high"]),
            "combined_score": score,
        })

    return pd.DataFrame(rows).sort_values("combined_score", ascending=False)


def coupling_sensitivity(geometry_endpoint: float) -> pd.DataFrame:
    rows = []

    ratios = [0.75, 0.85, 0.9, 0.95, 1.0, 1.05, 1.1, 1.15, 1.25]
    for r in ratios:
        k_space = r
        k_phase = 1.0

        W_space = 3.0 * k_space
        W_phase = 2.0 * k_phase

        tax = amplitude_tax_from_shares([W_space, W_phase])
        L_eff = THREE_PI - tax["amplitude_tax"]
        endpoint = geometry_endpoint * math.exp(L_eff)

        rows.append({
            "k_space_over_k_phase": r,
            "W_space": W_space,
            "W_phase": W_phase,
            "p_high": tax["p_high"],
            "p_low": tax["p_low"],
            "N_eff": tax["N_eff"],
            "amplitude_tax": tax["amplitude_tax"],
            "L_eff": L_eff,
            "endpoint_rho2": endpoint,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
            "interpretation": "tests stability if spatial and phase sector normalizations are not equal",
        })

    return pd.DataFrame(rows).sort_values("endpoint_log_error_vs_D_abs")


def separability_gate_matrix() -> pd.DataFrame:
    rows = [
        {
            "gate": "projector_ranks",
            "test": "P_space rank 3 and P_phase rank 2.",
            "status": "PASS_FORMAL",
            "boundary": "Formal 3+2 audit vector space, not full field action."
        },
        {
            "gate": "orthogonal_sector_blocks",
            "test": "P_space P_phase = 0.",
            "status": "PASS_FORMAL",
            "boundary": "Assumes separable approximation."
        },
        {
            "gate": "sector_trace_weights",
            "test": "Use Tr(P_space):Tr(P_phase)=3:2 as amplitude-sector weights.",
            "status": "CONDITIONAL_PASS",
            "boundary": "This is the key premise; needs derivation from master action."
        },
        {
            "gate": "ungrouped_eigenchannel_null",
            "test": "Treat all five components as independent equal eigenchannels.",
            "status": "FAILS_ENDPOINT",
            "boundary": "Supports grouping necessity but does not prove grouping."
        },
        {
            "gate": "equal_sector_normalization",
            "test": "Assume equal per-component normalization between spatial and phase sectors.",
            "status": "OPEN",
            "boundary": "Sensitivity audit included; full action must fix normalization."
        },
        {
            "gate": "spinor_frame_bridge",
            "test": "sqrt(4π):sqrt(2π) bridge remains nearby.",
            "status": "SUPPORTIVE",
            "boundary": "Bridge, not primary proof."
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need full action proof and prediction nulls."
        },
    ]

    return pd.DataFrame(rows)


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "The compact D-scale lane is M_i = G_i exp(L_eff u_i).",
            "status": "PRESERVED",
            "boundary": "D-scale lane only."
        },
        {
            "category": "Preserved",
            "claim": "A separable projector audit gives rank(P_space):rank(P_phase)=3:2.",
            "status": "FORMAL_PASS",
            "boundary": "Formal audit, not full field-theory derivation."
        },
        {
            "category": "Preserved",
            "claim": "Sector trace weighting gives L_eff = 3π - 1/2 ln(25/13).",
            "status": "CONDITIONAL_PASS",
            "boundary": "Depends on sector-trace amplitude participation premise."
        },
        {
            "category": "Observed",
            "claim": "Ungrouped five-eigenchannel interpretation fails the endpoint compared to grouped sector trace.",
            "status": "SUPPORTS_GROUPING",
            "boundary": "Failure of null is not proof."
        },
        {
            "category": "Open",
            "claim": "The master action forces equal per-component normalization of spatial and phase sectors.",
            "status": "OPEN",
            "boundary": "Must be derived next."
        },
        {
            "category": "Rejected",
            "claim": "R212M proves the mass hierarchy.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no full action proof."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def build_report(
    created_utc: str,
    verdict: str,
    required_split: dict,
    projector_df: pd.DataFrame,
    model_summary: pd.DataFrame,
    sensitivity: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R212M — Separable Action Functional Derivation Attempt

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R212M tests whether the WHERE/HOW 3:2 grouping can be represented as a separable action-sector projector structure.

Compact lane:
M_i = G_i * exp(L_eff * u_i)

Candidate coefficient:
L_eff = 3pi - 1/2 ln(25/13)

Formal separable projector structure:
P_space has rank 3.
P_phase has rank 2.
P_space P_phase = 0.
P_space + P_phase = I_5.

If amplitude participation is computed from sector trace weights:
W_space = Tr(P_space) = 3
W_phase = Tr(P_phase) = 2

Then:
N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13
tax = 1/2 ln(25/13)
L_eff = 3pi - 1/2 ln(25/13)

D-required endpoint split:
{json.dumps(json_safe(required_split), indent=2)}

Projector audit:
{projector_df.to_string(index=False)}

Model summary:
{model_summary.to_string(index=False)}

Coupling sensitivity:
{sensitivity.to_string(index=False)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
R212M gives a formal action-sector route to the 3:2 grouping:
spatial support and phase refresh can be represented as orthogonal projector sectors with ranks 3 and 2.

The result remains conditional because the full master action still has to justify three things:
1. the spatial and phase sectors are separable at the relevant linearized level,
2. the sector weights enter by trace/rank rather than five independent eigenchannels,
3. spatial and phase components have equal per-component normalization.

The ungrouped five-channel null fails the endpoint, so grouping is necessary.
The grouped trace model remains the lead D-scale coefficient candidate.

Ruling:
No V12.13 promotion.

Next recommended run:
R213M — Sector Normalization and Cross-Term Null Audit

Question:
Can unequal spatial/phase normalization or cross-sector coupling destroy the 3:2 coefficient, or does the action protect the trace-weighted split?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    modes = build_modes()
    geometry = add_geometry_signal(modes)
    target_geometry = add_targets(geometry)

    geometry_endpoint = float(target_geometry.sort_values("rho_float").iloc[-1]["G_i_geometry_ratio"])
    required_split = required_D_split_from_geometry(geometry_endpoint)

    projectors = projector_audit()
    models = sector_models(geometry_endpoint)
    outputs = evaluate_models(target_geometry, models)
    model_summary = summarize_models(outputs, models)
    sensitivity = coupling_sensitivity(geometry_endpoint)

    gates = separability_gate_matrix()
    claims = claim_boundary()

    lead = model_summary[model_summary["model_id"] == "separable_projector_trace_3_to_2"].iloc[0]
    null = model_summary[model_summary["model_id"] == "ungrouped_five_eigenchannels_null"].iloc[0]
    bridge = model_summary[model_summary["model_id"] == "spinor_frame_sqrt_4pi_2pi_bridge"].iloc[0]

    verdict = (
        "PARTIAL_PASS_SEPARABLE_PROJECTOR_ACTION_ROUTE_FORMALIZED_"
        "TRACE_WEIGHTED_3_TO_2_REPRODUCES_LEAD_COEFFICIENT_"
        "UNGROUPED_EIGENCHANNEL_NULL_FAILS_"
        "FULL_NORMALIZATION_AND_CROSS_TERM_PROOF_OPEN_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "compact_formula": "M_i = G_i * exp(L_eff * u_i)",
        "candidate_law": "L_eff = 3*pi - 0.5*ln(25/13)",
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "three_pi": THREE_PI,
            "ln2": LN2,
            "sqrt2": SQRT2,
            "half_ln_25_over_13": 0.5 * math.log(25.0 / 13.0),
            "three_pi_minus_half_ln_25_over_13": THREE_PI - 0.5 * math.log(25.0 / 13.0),
            "N_eff_3_to_2": 25.0 / 13.0,
            "K_req_half": HALF_K_REQ,
            "p_D": P_D,
            "p_top": P_TOP,
        },
        "D_required_endpoint_split": required_split,
        "lead_separable_projector_trace_result": lead.to_dict(),
        "ungrouped_five_eigenchannel_null_result": null.to_dict(),
        "spinor_frame_bridge_result": bridge.to_dict(),
        "best_models": model_summary.to_dict(orient="records"),
        "coupling_sensitivity_best": sensitivity.head(5).to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R213M - Sector Normalization and Cross-Term Null Audit",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R212M_model_summary.csv",
            "tables/R212M_coupling_sensitivity.csv",
            "Any traceback if the run failed."
        ],
    }

    modes.to_csv(tables / "R212M_mode_geometry_inputs.csv", index=False)
    geometry.to_csv(tables / "R212M_geometry_signal.csv", index=False)
    target_geometry.to_csv(tables / "R212M_target_geometry.csv", index=False)
    projectors.to_csv(tables / "R212M_projector_audit.csv", index=False)
    models.to_csv(tables / "R212M_sector_models.csv", index=False)
    outputs.to_csv(tables / "R212M_model_outputs.csv", index=False)
    model_summary.to_csv(tables / "R212M_model_summary.csv", index=False)
    sensitivity.to_csv(tables / "R212M_coupling_sensitivity.csv", index=False)
    gates.to_csv(tables / "R212M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R212M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        required_split=required_split,
        projector_df=projectors,
        model_summary=model_summary,
        sensitivity=sensitivity,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
