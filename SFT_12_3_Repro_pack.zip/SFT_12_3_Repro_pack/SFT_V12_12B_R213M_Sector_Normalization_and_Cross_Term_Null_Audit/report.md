
# SFT V12.12B R213M — Sector Normalization and Cross-Term Null Audit

Generated: 2026-06-18T04:02:54Z

Verdict:
PARTIAL_PASS_TRACE_WEIGHTED_3_TO_2_SURVIVES_NORMALIZATION_DRIFT_IN_TOLERANCE_BAND_CROSS_TERMS_SAFE_ONLY_UNDER_PROTECTED_SECTOR_TRACE_RULE_UNPROTECTED_EIGENCHANNEL_NULL_REMAINS_CONTROL_TRACE_PROTECTION_MECHANISM_OPEN_NO_V12_13

Purpose:
R213M tests whether the R212 trace-weighted 3:2 coefficient is fragile under spatial/phase normalization drift and cross-sector terms.

Lead compact lane:
M_i = G_i * exp(L_eff * u_i)

Lead coefficient:
L_eff = 3pi - 1/2 ln(25/13)

D-required endpoint split:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "two_channel_possible": true,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446,
  "imbalance_required": 0.20165774222211108
}

Baseline models:
                        model_id          family                                   shares  uses_D_to_define  native_prior                               mechanical_reading          proof_status               shares_normalized    N_eff  amplitude_tax    c_ln2    L_eff   p_high    p_low  endpoint_rho2  endpoint_vs_D_factor  endpoint_log_error_vs_D_abs
          protected_trace_3_to_2 protected_trace                               [3.0, 2.0]             False          10.0 protected sector trace weights rank 3 and rank 2        lead_candidate                       (0.6,0.4) 1.923077       0.326963 0.471708 9.097815 0.600000 0.400000   17871.488624              0.999680                     0.000320
spinor_frame_sqrt_4pi_2pi_bridge          bridge [3.5449077018110318, 2.5066282746310002]             False           8.0                       sqrt 4π and sqrt 2π bridge     supportive_bridge (0.585786437627,0.414213562373) 1.942809       0.332067 0.479072 9.092711 0.585786 0.414214   17780.501218              0.994590                     0.005424
          equal_two_sector_sqrt2     binary_base                               [1.0, 1.0]             False           7.0                                two equal sectors lower_order_candidate                       (0.5,0.5) 2.000000       0.346574 0.500000 9.078204 0.500000 0.500000   17524.436390              0.980267                     0.019930
     unprotected_five_equal_null            null                [1.0, 1.0, 1.0, 1.0, 1.0]             False           4.0             five independent equal eigenchannels          null_control           (0.2,0.2,0.2,0.2,0.2) 5.000000       0.804719 1.160964 8.620059 0.200000 0.200000   11083.426741              0.619975                     0.478076

Scan summary:
{
  "best_normalization_trace_model": {
    "scan_type": "normalization_drift_trace_protected",
    "k_space_over_k_phase": 1.005,
    "epsilon_cross": 0.0,
    "W_space": 3.0149999999999997,
    "W_phase": 2.0,
    "p_high": 0.6011964107676969,
    "p_low": 0.39880358923230314,
    "N_eff": 1.9212981442259394,
    "amplitude_tax": 0.3265005371800268,
    "L_eff": 9.098277423589353,
    "endpoint_rho2": 17879.759612557624,
    "endpoint_vs_D_factor": 1.0001426913468703,
    "endpoint_log_error_vs_D_abs": 0.00014268116742838103
  },
  "normalization_log_error_le_0p01_band": {
    "count": 44,
    "min_k_space_over_k_phase": 0.89,
    "max_k_space_over_k_phase": 1.105
  },
  "cross_scan_equal_norm_stability": {
    "trace_error_min": 0.00032001535587697285,
    "trace_error_max": 0.00032001535587697285,
    "eigen_error_min": 0.3766053158712506,
    "eigen_error_max": 0.4780757378695954
  },
  "safe_cross_term_region_trace_model": {
    "count": 81,
    "max_epsilon_cross": 0.16,
    "max_cross_leakage_ratio": 0.09898335096271692,
    "k_min": 0.9,
    "k_max": 1.1
  },
  "best_unprotected_eigenchannel_cross_model": {
    "k_space_over_k_phase": 0.9,
    "epsilon_cross": 0.75,
    "cross_leakage_ratio": 0.5045308061821902,
    "positive_definite": true,
    "min_eigenvalue": 0.19833518108135445,
    "max_eigenvalue": 1.7016648189186454,
    "trace_p_high": 0.574468085106383,
    "trace_N_eff": 1.95659875996457,
    "trace_L_eff": 9.089174141134151,
    "trace_endpoint_vs_D_factor": 0.9910794252567574,
    "trace_endpoint_log_error_vs_D_abs": 0.008960601287773408,
    "eigen_N_eff": 3.976597659765978,
    "eigen_L_eff": 8.734564663599162,
    "eigen_endpoint_vs_D_factor": 0.695190007411751,
    "eigen_endpoint_log_error_vs_D_abs": 0.3635700788227627,
    "eigenvalues": "(0.198335181081,0.9,0.9,1,1.70166481892)"
  }
}

Gate matrix:
                                 gate                                                                          test              status                                                                                                                                  boundary
                      baseline_3_to_2                    Trace-weighted rank 3:2 model reproduces lead coefficient.                PASS                                                                                   Still conditional on action protecting trace weighting.
                  normalization_drift                                                Allow k_space/k_phase to vary. PASS_WITH_TOLERANCE                                  log-error<=0.01 band: {'count': 44, 'min_k_space_over_k_phase': 0.89, 'max_k_space_over_k_phase': 1.105}
          cross_terms_protected_trace                     Cross terms added but trace-sector coefficient protected.    PASS_CONDITIONAL                                                                                Only valid if action projects coefficient by sector trace.
cross_terms_unprotected_eigenchannels                             Cross terms treated as independent eigenchannels.             CONTROL                                                                        Eigenchannel treatment is a null/control, not the protected model.
                    safe_cross_region Region with leakage<=0.10, positive definite H, and endpoint log error<=0.01.  PASS_REGION_EXISTS safe region summary: {'count': 81, 'max_epsilon_cross': 0.16, 'max_cross_leakage_ratio': 0.09898335096271692, 'k_min': 0.9, 'k_max': 1.1}
                               V12_13                                                                    Promotion.                  NO                                                                Need action-level derivation of trace protection and sector normalization.

Claim boundary:
 category                                                                             claim          status                                                        boundary
Preserved                             The compact D-scale lane is M_i = G_i exp(L_eff u_i).       PRESERVED                                              D-scale lane only.
Preserved           Trace-weighted 3:2 sector model remains the lead coefficient candidate.       PRESERVED                    Requires action protection of sector traces.
 Observed        Small normalization drift does not instantly destroy the D-scale endpoint. DIAGNOSTIC_PASS                         Tolerance does not prove normalization.
 Observed Cross terms are safe only if the action projects the coefficient by sector trace.     CONDITIONAL Unprotected eigenchannel interpretation remains a null/control.
     Open          The full master action suppresses or renormalizes cross-sector coupling.            OPEN                                               Needs derivation.
 Rejected                                                  R213M proves the mass hierarchy.              NO         No species map, no top/e closure, no full action proof.
Promotion                                                                 V12.13 promotion.              NO                                                 Not yet earned.

Interpretation:
R213M distinguishes two ideas.

Protected trace model:
The coefficient is computed from sector traces. Cross terms can exist in the Hessian, but the amplitude tax is protected by projection onto the spatial and phase sectors. In this model, the 3:2 coefficient survives cross terms as long as sector trace projection remains valid.

Unprotected eigenchannel model:
The Hessian eigenchannels are treated as independent amplitude channels. This is a null/control because it abandons the R212 grouping premise. It tests what happens if cross terms destroy the sector decomposition.

The result should be read as a protection audit, not a final proof. If the action really protects sector trace weighting, the 3:2 lane is robust. If the action does not protect it, the coefficient can drift.

Ruling:
No V12.13 promotion.

Next recommended run:
R214M — Trace-Protection Mechanism Derivation Gate

Question:
Can no-overwrite support bookkeeping, gauge covariance, or projector invariance force the coefficient to depend on sector traces rather than mixed eigenchannels?
