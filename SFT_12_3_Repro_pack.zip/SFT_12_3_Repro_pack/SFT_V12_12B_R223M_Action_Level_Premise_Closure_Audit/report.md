
# SFT V12.12B R223M — Action-Level Premise Closure Audit

Generated: 2026-06-20T04:47:15Z

Verdict:
PARTIAL_PASS_ACTION_LEVEL_PREMISE_CLOSURE_AUDIT_TIGHTENS_R222_THEOREM_A3_BOTH_SECTOR_TERMINAL_CLOSURE_PROMOTED_TO_FORMAL_ACTION_ROUTE_A5_UNTAXED_TERMINAL_COMPLETION_PROMOTED_TO_ACTION_CATEGORY_SEPARATION_ROUTE_A1_SATURATION_GETS_ACTION_BOUNDARY_ROUTE_BUT_REMAINS_GLOBAL_ACTION_OPEN_TOP_E_NOT_SOLVED_NO_SPECIES_MAP_NO_V12_13

Purpose:
R223M audits A1, A3, and A5 from the R222 symbolic conditional theorem.

A1 saturation routes:
                      route_id                       premise                                                                                                                                                                      route  uses_top_to_define  uses_D_to_define         formal_status  supports_A1                                    reject_reason                                                                     risk  base_score  premise_score
          A1_u_domain_endpoint D-scale trace lane saturation                                                                Treat u as a normalized trace-lane coordinate with admissible domain 0 <= u <= 1. Saturation occurs at u=1.               False             False ACTION_BOUNDARY_ROUTE         True                                                  The global action must still derive the u-domain and endpoint condition.         8.0           19.0
    A1_trace_capacity_endpoint D-scale trace lane saturation The R218 trace-variational lane exhausts internal branch participation capacity; terminal completion becomes admissible only after internal trace compounding is complete.               False             False      MECHANICAL_ROUTE         True                                                                        Capacity exhaustion needs action-level definition.         7.0           13.0
       A1_exact_D_endpoint_fit D-scale trace lane saturation                                                                                                                 Declare saturation because endpoint numerically matches D.               False              True  REJECT_AS_DERIVATION        False  Uses D diagnostic and cannot define saturation.                                                            Fitting risk.        -6.0           -7.0
A1_top_e_backsolved_saturation D-scale trace lane saturation                                                                                                                                Declare saturation from top/e gap behavior.                True             False  REJECT_AS_DERIVATION        False Uses top/e context and cannot define saturation.                                                       Hard fitting risk.        -8.0          -13.0

A3 sector closure tests:
                      test_id                         completion         K  space_closed  phase_closed  terminal_state  single_sector_gap                      status                                                                  ruling  base_score  top_prediction_factor  top_prediction_percent_error  premise_score
          both_sector_closure 4π spatial/spinor + 2π frame/gauge 18.849556          True          True            True              False PROMOTE_FORMAL_ACTION_ROUTE Only both-sector closure can be terminal under real-support completion.        12.0               0.993716                     -0.628429           23.0
               space_only_4pi             4π spatial/spinor only 12.566371          True         False           False               True           REJECT_INCOMPLETE                                   Leaves frame/gauge phase sector open.         1.0               0.662477                    -33.752286           12.0
               phase_only_2pi                2π frame/gauge only  6.283185         False          True           False               True           REJECT_INCOMPLETE                            Leaves spatial/spinor curvature sector open.         1.0               0.331239                    -66.876143           12.0
duplicate_both_sector_closure                two copies of 4π+2π 37.699112          True          True           False              False            REJECT_DUPLICATE                     Terminal closure is duplicated rather than minimal.         0.0               1.987431                     98.743141           11.0
              half_action_3pi               3π half-action proxy  9.424778         False         False           False               True           REJECT_INCOMPLETE                        Does not equal closure of both physical sectors.         1.0               0.496858                    -50.314215            8.0
          no_terminal_closure            zero additional closure  0.000000         False         False           False               True         REJECT_UNDERCLOSURE                                                 No terminal completion.        -2.0               0.052718                    -94.728174            5.0

A5 tax separation tests:
                         test_id                category                                                                              description    N_eff       tax         K                        status                                                        ruling  base_score  predicted_top_e_vs_target_factor  top_e_percent_error  premise_score
      terminal_completion_Neff_1     terminal_completion Terminal closure is a deterministic completion, not a branch-sharing amplitude ensemble. 1.000000  0.000000 18.849556 PROMOTE_ACTION_CATEGORY_ROUTE           Untaxed terminal completion is category-consistent.        12.0                          0.993716            -0.628429           23.0
D_scale_branch_participation_tax    branch_participation   D-scale internal trace lane has two protected sectors with shares 3:2 and N_eff=25/13. 1.923077  0.326963  9.097815        VALID_FOR_D_SCALE_ONLY Tax belongs to branch participation, not terminal completion.         9.0                          0.479621           -52.037908           17.0
    taxed_minus_terminal_control category_mixing_control                                         Apply D-scale tax to terminal closure: 6π - tax. 1.923077  0.326963 18.522593             REJECT_AS_PRIMARY            Reuses branch tax in terminal completion category.         1.0                          0.976479            -2.352123           12.0
     taxed_plus_terminal_control category_mixing_control                                           Add D-scale tax to terminal closure: 6π + tax. 1.923077 -0.326963 19.176519             REJECT_AS_PRIMARY Adds branch tax to terminal completion without action reason.         1.0                          1.010953             1.095264           12.0
        exact_gap_as_tax_control   forbidden_fit_control                                             Infer an effective tax from exact top/e gap.      NaN -0.119205 18.968761          REJECT_AS_DERIVATION                    Uses top/e and cannot define terminal tax.        -8.0                          1.000000             0.000000           -9.0

Premise closure matrix:
axiom_id                      premise         before_R223            best_R223_route                         after_R223  score                                                                             remaining_gap                         promotion
      A1           D-scale saturation   ASSUMED_FROM_R218       A1_u_domain_endpoint ACTION_BOUNDARY_ROUTE_PARTIAL_PASS   19.0                   Global action still must derive u-domain endpoint/saturation condition.                 PARTIAL_PROMOTION
      A2      No-overwrite minimality    SFT_CORE_PREMISE                  unchanged             CORE_PREMISE_PRESERVED    NaN                          Needs final embedding in full action, but not the focus of R223.                         PRESERVED
      A3 Both-sector terminal closure CONDITIONAL_PREMISE        both_sector_closure        PROMOTE_FORMAL_ACTION_ROUTE   23.0    Need theorem that top terminal state necessarily requires no open real support sector.   PROMOTED_TO_FORMAL_ACTION_ROUTE
      A4   Full closure measure 4π+2π         FORMAL_PASS                  unchanged              FORMAL_PASS_PRESERVED    NaN                                 Tie closure measure to terminal load term in full action.                         PRESERVED
      A5  Terminal completion untaxed    CONDITIONAL_PASS terminal_completion_Neff_1      PROMOTE_ACTION_CATEGORY_ROUTE   23.0 Need explicit action split between branch participation tax and terminal completion term. PROMOTED_TO_ACTION_CATEGORY_ROUTE

Theorem status after audit:
theorem_id                                                                statement               before_R223                          after_R223  stronger_after_R223                                                                                                why_stronger                                                                                      still_missing  top_e_closed  V12_13
        T1 A1-A5 imply unique minimal nonzero untaxed terminal completion K_top=6π. SYMBOLIC_CONDITIONAL_PASS SYMBOLIC_CONDITIONAL_PASS_TIGHTENED                 True A3 promoted to formal action route; A5 promoted to action category route; A1 gets an action-boundary route. Full global action derivation of A1 endpoint, A3 terminal necessity, and A5 explicit action split.         False   False

Residual analysis:
                             quantity         value                ruling                                               comment
                  exact_gap_minus_6pi      0.119205  OPEN_DIAGNOSTIC_ONLY     Residual remains after lead 6π theorem candidate.
                percent_gap_above_6pi      0.632404  OPEN_DIAGNOSTIC_ONLY   Do not fit until premises are fully action-derived.
                sixpi_predicted_top_e 336869.624211 DIAGNOSTIC_SUPPORTIVE Prediction from frozen D endpoint times one 6π layer.
      sixpi_predicted_top_e_vs_target      0.993716 DIAGNOSTIC_SUPPORTIVE                     Top/e context is diagnostic only.
legacy_Kreq_predicted_top_e_vs_target      0.995879     SUPPORTIVE_BRIDGE     K_req remains supportive but not theorem-derived.

Open claims ledger:
                         open_claim                  status                                                                                         current_best_route                                                                why_open                                                                   required_next  promotion_blocker
        global_action_A1_saturation OPEN_PARTIALLY_NARROWED                                                               u-domain endpoint / trace-capacity endpoint. R223 gives an action-boundary route but not a global variational proof.                  Write saturation as a boundary condition in the master action.               True
global_action_A3_terminal_necessity OPEN_PARTIALLY_NARROWED                                               terminal state cannot leave either real support sector open.        R223 promotes this as formal action route but not final theorem. Show top terminal state requires no open spatial/spinor or frame/gauge support.               True
         global_action_A5_tax_split OPEN_PARTIALLY_NARROWED branch participation tax applies to internal trace compounding; terminal completion has N_eff=1 and tax=0.            R223 promotes category separation but not full action split.      Write separate action terms for branch participation and terminal closure.               True
                       residual_gap                    OPEN                                                                                 Residual 0.6324% above 6π.               Do not fit residual before global action premise closure.                                                        Defer residual analysis.               True
                        species_map                    OPEN                                                                                                  Deferred.                                                 No species labels used.                                          Later species map constraint skeleton.               True
              prediction_null_suite                    OPEN                                                                                             Not addressed.                                       No external no-retuning test yet.                                                    Build prediction/null suite.               True
                   V12_13_promotion                      NO                                                                                              Not eligible.             Top/e not fully closed and species/predictions remain open.                                                                   No promotion.               True

Claim boundary matrix:
     category                                                                       claim status                                                        safe_wording
Allowed claim R223M tightens the symbolic conditional theorem by auditing A1, A3, and A5.    YES                                Theorem tightened, not fully closed.
Allowed claim                          A3 is promoted to a formal action-route candidate.    YES           Terminal closure cannot leave a real support sector open.
Allowed claim                  A5 is promoted to an action-category separation candidate.    YES Branch tax and terminal completion are different action categories.
Allowed claim                                A1 receives a partial action-boundary route.    YES      Saturation as u-domain endpoint remains to be globally proven.
Blocked claim                                                            Top/e is solved.     NO                     Global action closure and residual remain open.
Blocked claim                                 The full global action theorem is complete.     NO                        A1/A3/A5 still need final action derivation.
Blocked claim                                                     Species map is derived.     NO                                           Species map remains open.
Blocked claim                                                         V12.13 is promoted.     NO                                                No V12.13 promotion.

Interpretation:
R223M tightens the R222 theorem. A3 is promoted from a conditional premise to a formal action-route candidate because a terminal real-support completion cannot leave either spatial/spinor or frame/gauge support open. A5 is promoted to an action-category separation candidate because D-scale branch participation tax and terminal deterministic completion are different action categories. A1 receives a plausible action-boundary route via a normalized trace-lane endpoint u=1, but remains the main global-action burden.

Ruling:
Symbolic theorem tightened.
A1/A3/A5 not fully action-proven.
Top/e not solved.
No species map.
No V12.13 promotion.

Next recommended run:
R224M — Master-Action Patch for Saturation and Terminal Completion Terms

Question:
Can the action be patched with separate internal branch-participation and terminal-completion terms so that A1 and A5 become explicit?
