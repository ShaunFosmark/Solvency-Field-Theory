
# SFT V12.12B R210M — 3:2 Support Count and Spinor-Frame Origin Gate

Generated: 2026-06-18T02:51:16Z

Verdict:
PARTIAL_PASS_OPUS_3_SPATIAL_2_PHASE_GROUPING_SURVIVES_NUMERIC_GATE_L_EFF_SHARPENED_TO_3PI_MINUS_HALF_LN_25_OVER_13_GROUPING_PREMISE_NOT_ACTION_PROVEN_NO_V12_13

Purpose:
R210M tests Opus's 3 spatial support : 2 phase closure decomposition together with the spinor-frame alternatives.

Compact formula:
M_i = G_i * exp(L_eff * u_i)

Coefficient:
L_eff = 3pi - amplitude_tax

Amplitude tax:
N_eff = 1 / sum(p_a^2)
amplitude_tax = 1/2 ln(N_eff)

Opus grouped 3:2:
shares = 3:2
p = 3/5 and 2/5
N_eff = 25/13
amplitude_tax = 1/2 ln(25/13)
L_eff = 3pi - 1/2 ln(25/13)

D-required endpoint split:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "two_channel_possible": true,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446,
  "imbalance_required": 0.20165774222211108
}

Opus 3:2 result:
mechanism_id                                      opus_3_spatial_2_phase_grouped
mechanism_family                                                     opus_3plus2
native_status                     conditional_pass_if_grouping_is_action_derived
uses_D_to_define                                                           False
mechanical_reading             three spatial support coordinates grouped agai...
closed_form_tax_hint            tax = 1/2 ln(25/13), L_eff = 3pi - 1/2 ln(25/13)
native_score_prior                                                           9.0
shares_normalized                                                      (0.6,0.4)
p_high                                                                       0.6
p_low                                                                        0.4
imbalance                                                                    0.2
N_eff                                                                   1.923077
amplitude_tax                                                           0.326963
c_ln2                                                                   0.471708
L_eff                                                                   9.097815
endpoint_rho2                                                       17871.488624
endpoint_vs_D_factor                                                     0.99968
endpoint_vs_top_e_factor                                                0.052718
endpoint_log_error_vs_D_abs                                              0.00032
span_max_over_min                                                   17871.488624
rmse_log_vs_D_target                                                    0.718964
rmse_log_vs_top_e_target                                                1.475658
distance_to_required_p_high                                             0.000829
distance_to_equal_split                                                      0.1
distance_to_3_to_2                                                           0.0
combined_score                                                              16.0

Equal two-channel sqrt2 result:
mechanism_id                                 equal_two_channel_sqrt2
mechanism_family                                      binary_support
native_status                         clean_minimal_binary_candidate
uses_D_to_define                                               False
mechanical_reading             two equal orthogonal support channels
closed_form_tax_hint            tax = 1/2 ln2, L_eff = 3pi - 1/2 ln2
native_score_prior                                               8.0
shares_normalized                                          (0.5,0.5)
p_high                                                           0.5
p_low                                                            0.5
imbalance                                                        0.0
N_eff                                                            2.0
amplitude_tax                                               0.346574
c_ln2                                                            0.5
L_eff                                                       9.078204
endpoint_rho2                                            17524.43639
endpoint_vs_D_factor                                        0.980267
endpoint_vs_top_e_factor                                    0.051695
endpoint_log_error_vs_D_abs                                  0.01993
span_max_over_min                                        17524.43639
rmse_log_vs_D_target                                        0.710228
rmse_log_vs_top_e_target                                    1.487449
distance_to_required_p_high                                 0.100829
distance_to_equal_split                                          0.0
distance_to_3_to_2                                               0.1
combined_score                                                  13.0

Spinor-frame sqrt(4pi):sqrt(2pi) result:
mechanism_id                                     spinor_frame_sqrt_4pi_2pi_split
mechanism_family                                                    spinor_frame
native_status                              amplitude_candidate_from_spinor_frame
uses_D_to_define                                                           False
mechanical_reading             amplitude split proportional to square roots o...
closed_form_tax_hint                                         tax = 1/2 ln(N_eff)
native_score_prior                                                           7.5
shares_normalized                                (0.585786437627,0.414213562373)
p_high                                                                  0.585786
p_low                                                                   0.414214
imbalance                                                               0.171573
N_eff                                                                   1.942809
amplitude_tax                                                           0.332067
c_ln2                                                                   0.479072
L_eff                                                                   9.092711
endpoint_rho2                                                       17780.501218
endpoint_vs_D_factor                                                     0.99459
endpoint_vs_top_e_factor                                                 0.05245
endpoint_log_error_vs_D_abs                                             0.005424
span_max_over_min                                                   17780.501218
rmse_log_vs_D_target                                                    0.716679
rmse_log_vs_top_e_target                                                1.478726
distance_to_required_p_high                                             0.015042
distance_to_equal_split                                                 0.085786
distance_to_3_to_2                                                      0.014214
combined_score                                                              13.5

Best mechanism summary:
                   mechanism_id mechanism_family                                  native_status  uses_D_to_define                                                                                mechanical_reading                             closed_form_tax_hint  native_score_prior               shares_normalized   p_high    p_low  imbalance    N_eff  amplitude_tax    c_ln2    L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_vs_top_e_factor  endpoint_log_error_vs_D_abs  span_max_over_min  rmse_log_vs_D_target  rmse_log_vs_top_e_target  distance_to_required_p_high  distance_to_equal_split  distance_to_3_to_2  combined_score
 opus_3_spatial_2_phase_grouped      opus_3plus2 conditional_pass_if_grouping_is_action_derived             False                   three spatial support coordinates grouped against two phase closure completions tax = 1/2 ln(25/13), L_eff = 3pi - 1/2 ln(25/13)                 9.0                       (0.6,0.4) 0.600000 0.400000   0.200000 1.923077       0.326963 0.471708 9.097815   17871.488624              0.999680                  0.052718                     0.000320       17871.488624              0.718964                  1.475658                     0.000829                 0.100000            0.000000            16.0
spinor_frame_sqrt_4pi_2pi_split     spinor_frame          amplitude_candidate_from_spinor_frame             False                            amplitude split proportional to square roots of 4π and 2π load sectors                              tax = 1/2 ln(N_eff)                 7.5 (0.585786437627,0.414213562373) 0.585786 0.414214   0.171573 1.942809       0.332067 0.479072 9.092711   17780.501218              0.994590                  0.052450                     0.005424       17780.501218              0.716679                  1.478726                     0.015042                 0.085786            0.014214            13.5
        equal_two_channel_sqrt2   binary_support                 clean_minimal_binary_candidate             False                                                             two equal orthogonal support channels             tax = 1/2 ln2, L_eff = 3pi - 1/2 ln2                 8.0                       (0.5,0.5) 0.500000 0.500000   0.000000 2.000000       0.346574 0.500000 9.078204   17524.436390              0.980267                  0.051695                     0.019930       17524.436390              0.710228                  1.487449                     0.100829                 0.000000            0.100000            13.0
            opus_sqrt_count_3_2      opus_3plus2                      amplitude_count_candidate             False three spatial and two phase sectors combine internally in quadrature before channel participation                              tax = 1/2 ln(N_eff)                 7.0 (0.550510257217,0.449489742783) 0.550510 0.449490   0.101021 1.979796       0.341497 0.492676 9.083281   17613.629113              0.985256                  0.051958                     0.014854       17613.629113              0.712479                  1.484396                     0.050319                 0.050510            0.049490            12.0
spinor_frame_4pi_2pi_load_split     spinor_frame                       candidate_from_R193_R194             False                    support split proportional to 4π spinor curvature load and 2π frame phase load                                tax = 1/2 ln(9/5)                 7.0 (0.666666666667,0.333333333333) 0.666667 0.333333   0.333333 1.800000       0.293893 0.423998 9.130885   18472.377901              1.033292                  0.054491                     0.032750       18472.377901              0.733949                  1.455805                     0.065838                 0.166667            0.066667            11.0
      three_plus_one_sqrt_split   3plus1_support                amplitude_candidate_from_3plus1             False                                                 sqrt(3) support envelope versus 1 tangent channel                              tax = 1/2 ln(N_eff)                 5.5 (0.633974596216,0.366025403784) 0.633975 0.366025   0.267949 1.866025       0.311905 0.449984 9.112873   18142.631570              1.014847                  0.053518                     0.014738       18142.631570              0.725749                  1.466614                     0.033146                 0.133975            0.033975            10.5
    four_equal_channel_full_ln2   binary_support                          curve_shape_candidate             False                                        two independent equal binary splits or four equal channels                              tax = 1/2 ln(N_eff)                 5.0           (0.25,0.25,0.25,0.25) 0.250000 0.250000   0.000000 4.000000       0.693147 1.000000 8.731631   12391.647808              0.693153                  0.036554                     0.366504       12391.647808              0.579575                  1.697676                     0.350829                 0.250000            0.350000             9.0
     three_plus_one_count_split   3plus1_support           candidate_from_3plus1_slot_structure             False                                      3 normal/support directions versus 1 tangent/write direction                              tax = 1/2 ln(N_eff)                 5.0                     (0.75,0.25) 0.750000 0.250000   0.500000 1.600000       0.235002 0.339036 9.189776   19592.915518              1.095972                  0.057796                     0.091641       19592.915518              0.761366                  1.420545                     0.149171                 0.250000            0.150000             9.0
    opus_5_components_ungrouped opus_3plus2_null                  null_control_against_grouping             False                three spatial plus two phase components treated as five independent equal channels                                    tax = 1/2 ln5                 5.0           (0.2,0.2,0.2,0.2,0.2) 0.200000 0.200000   0.000000 5.000000       0.804719 1.160964 8.620059   11083.426741              0.619975                  0.032694                     0.478076       11083.426741              0.550147                  1.765976                     0.400829                 0.300000            0.400000             6.0
           golden_ratio_control          control                             control_not_native             False                                                                        golden ratio split control                              tax = 1/2 ln(N_eff)                 1.0   (0.61803398875,0.38196601125) 0.618034 0.381966   0.236068 1.894427       0.319458 0.460881 9.105320   18006.118249              1.007211                  0.053115                     0.007185       18006.118249              0.722338                  1.471149                     0.017205                 0.118034            0.018034             5.0
       opus_intensity_count_3_2 opus_3plus2_null                  control_likely_too_imbalanced             False                                                                intensity-like square of 3:2 count                              tax = 1/2 ln(N_eff)                 3.0 (0.692307692308,0.307692307692) 0.692308 0.307692   0.384615 1.742268       0.277594 0.400483 9.147184   18775.934952              1.050272                  0.055386                     0.049049       18775.934952              0.741447                  1.446033                     0.091479                 0.192308            0.092308             4.0
    D_inferred_split_diagnostic  diagnostic_only                         diagnostic_only_uses_D              True                                                                    split inferred from D endpoint                              tax = 1/2 ln(N_eff)                -8.0 (0.600828871111,0.399171128889) 0.600829 0.399171   0.201658 1.921846       0.326643 0.471247 9.098135   17877.208690              1.000000                  0.052735                     0.000000       17877.208690              0.719108                  1.475466                     0.000000                 0.100829            0.000829           -13.0

Pairwise focus:
                    mechanism_a                     mechanism_b  delta_endpoint_log_error_abs_a_minus_b  delta_rmse_D_a_minus_b  delta_combined_score_a_minus_b
 opus_3_spatial_2_phase_grouped     opus_5_components_ungrouped                               -0.477756                0.168818                            10.0
 opus_3_spatial_2_phase_grouped             opus_sqrt_count_3_2                               -0.014534                0.006486                             4.0
 opus_3_spatial_2_phase_grouped spinor_frame_sqrt_4pi_2pi_split                               -0.005104                0.002285                             2.5
 opus_3_spatial_2_phase_grouped spinor_frame_4pi_2pi_load_split                               -0.032430               -0.014985                             5.0
    opus_5_components_ungrouped             opus_sqrt_count_3_2                                0.463222               -0.162332                            -6.0
    opus_5_components_ungrouped spinor_frame_sqrt_4pi_2pi_split                                0.472652               -0.166533                            -7.5
    opus_5_components_ungrouped spinor_frame_4pi_2pi_load_split                                0.445326               -0.183803                            -5.0
            opus_sqrt_count_3_2 spinor_frame_sqrt_4pi_2pi_split                                0.009429               -0.004201                            -1.5
            opus_sqrt_count_3_2 spinor_frame_4pi_2pi_load_split                               -0.017896               -0.021471                             1.0
        equal_two_channel_sqrt2  opus_3_spatial_2_phase_grouped                                0.019610               -0.008737                            -3.0
        equal_two_channel_sqrt2     opus_5_components_ungrouped                               -0.458145                0.160081                             7.0
        equal_two_channel_sqrt2             opus_sqrt_count_3_2                                0.005077               -0.002251                             1.0
        equal_two_channel_sqrt2 spinor_frame_sqrt_4pi_2pi_split                                0.014506               -0.006452                            -0.5
        equal_two_channel_sqrt2 spinor_frame_4pi_2pi_load_split                               -0.012820               -0.023722                             2.0
spinor_frame_4pi_2pi_load_split spinor_frame_sqrt_4pi_2pi_split                                0.027326                0.017270                            -2.5

Gate matrix:
                        gate                                                                                test             status                                                                  boundary
             compact_formula                                                            M_i = G_i exp(L_eff u_i)          PRESERVED                                D-scale lane only, not full mass spectrum.
opus_3_support_2_phase_count 3 spatial support coordinates and 2 phase closure completions define 3:2 without D.   CONDITIONAL_PASS Requires proving these five components group into two amplitude channels.
               grouping_null     Treat 3+2 components as five equal independent channels instead of grouped 3:2.            CONTROL                      If five-channel control wins, Opus grouping weakens.
         spinor_frame_bridge                            Compare 4π:2π and sqrt(4π):sqrt(2π) spinor-frame splits.             TESTED                                     Can support or compete with Opus 3:2.
              D_independence                               Candidate shares must be defined before D comparison. PASS_FOR_OPUS_3TO2                                      D still used for diagnostic scoring.
                       top_e                                                                      Top/e closure.               OPEN                                                 No top/e closure claimed.
                      V12_13                                                                          Promotion.                 NO                        Need action-level derivation and prediction nulls.

Claim boundary:
 category                                                                             claim                  status                                                        boundary
Preserved                             The compact D-scale lane is M_i = G_i exp(L_eff u_i).               PRESERVED                                              D-scale lane only.
Preserved Opus 3 spatial : 2 phase grouping gives the near-exact 3:2 split without using D.        CONDITIONAL_PASS Only if grouping into two amplitude channels is action-derived.
 Observed                     For 3:2, amplitude tax is 1/2 ln(25/13), not exactly 1/2 ln2. LOCKED_NUMERIC_IDENTITY                                  This sharpens the coefficient.
 Observed                     Equal sqrt2 remains clean but less endpoint-precise than 3:2.          LIVE_CANDIDATE                               May be lower-order approximation.
 Rejected                                                  R210M proves the mass hierarchy.                      NO        No species map, no top/e closure, no action-level proof.
Promotion                                                                 V12.13 promotion.                      NO                                                 Not yet earned.

Interpretation:
Opus's 3 spatial : 2 phase channel-count hypothesis survives the numerical gate.

The coefficient is not exactly 3pi - 1/2 ln2.
It is sharper:

L_eff = 3pi - 1/2 ln(25/13)

This is equivalent to a grouped 3:2 amplitude participation tax.

The five-component ungrouped null is important:
if the three spatial and two phase components are treated as five equal independent channels, the tax becomes 1/2 ln5, which is too large for the D-scale endpoint. Therefore the key open premise is grouping, not counting.

Ruling:
No V12.13 promotion.

Next recommended run:
R211M — Action-Level 3:2 Grouping Proof Attempt

Question:
Can the action force three spatial support coordinates into one settlement-support channel and two phase closures into one refresh channel?
