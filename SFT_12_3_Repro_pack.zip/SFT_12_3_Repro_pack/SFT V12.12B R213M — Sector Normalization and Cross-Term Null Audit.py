#!/usr/bin/env python3
"""
SFT V12.12B R213M — Sector Normalization and Cross-Term Null Audit

Purpose:
    R212M formalized the WHERE/HOW grouping as a separable projector route:

        rank(P_space) : rank(P_phase) = 3 : 2

    and the compact D-scale lane:

        M_i = G_i * exp(L_eff * u_i)

        L_eff = 3π - 1/2 ln(25/13)

    R213M asks:
        Is this coefficient protected, or can unequal normalization and
        cross-sector terms destroy it?

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - no V12.13 promotion inside this run
"""

from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R213M_Sector_Normalization_and_Cross_Term_Null_Audit"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
SQRT2 = math.sqrt(2.0)

TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi
HALF_K_REQ = K_REQ / 2.0

RHO0 = 0.5
RHO_SPAN = 4.0

SEED_MODES = [
    Fraction(1, 2),
    Fraction(2, 3),
    Fraction(3, 4),
    Fraction(1, 1),
    Fraction(5, 4),
    Fraction(4, 3),
    Fraction(3, 2),
    Fraction(5, 3),
    Fraction(2, 1),
]

D_PERP = 3


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def frac_str(f: Fraction) -> str:
    if f.denominator == 1:
        return str(f.numerator)
    return f"{f.numerator}/{f.denominator}"


def balanced_occupancy(m: int, n: int) -> list[int]:
    active = min(max(n, 1), D_PERP)
    q, r = divmod(m, active)

    occ = [q + 1 if i < r else q for i in range(active)]
    occ += [0] * (D_PERP - len(occ))
    occ.sort(reverse=True)

    return occ


def shape_stats(occ: list[int]) -> dict:
    total = sum(occ)
    probs = [x / total for x in occ] if total else [0.0, 0.0, 0.0]

    l2 = math.sqrt(sum(p * p for p in probs))
    iso = 1.0 / D_PERP

    eccentricity = 0.0
    if total:
        eccentricity = math.sqrt(sum((p - iso) ** 2 for p in probs)) / math.sqrt(2.0 / 3.0)

    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    entropy_norm = entropy / math.log(D_PERP)
    entropy_deficit = 1.0 - entropy_norm

    active_slots = sum(1 for x in occ if x > 0)
    max_occ = max(occ) if occ else 0
    slot_fill_fraction = active_slots / D_PERP

    return {
        "shape_l2_norm": l2,
        "eccentricity_norm": eccentricity,
        "entropy_norm": entropy_norm,
        "entropy_deficit": entropy_deficit,
        "active_slots": active_slots,
        "max_occ": max_occ,
        "slot_fill_fraction": slot_fill_fraction,
    }


def build_modes() -> pd.DataFrame:
    rows = []

    for rho in SEED_MODES:
        m = rho.numerator
        n = rho.denominator
        occ = balanced_occupancy(m, n)
        stats = shape_stats(occ)

        rows.append({
            "rho": frac_str(rho),
            "rho_float": float(rho),
            "m": m,
            "N": n,
            "occupancy_vector": "(" + ",".join(str(x) for x in occ) + ")",
            "occ0": occ[0],
            "occ1": occ[1],
            "occ2": occ[2],
            "active_slots": stats["active_slots"],
            "max_occ": stats["max_occ"],
            "slot_fill_fraction": stats["slot_fill_fraction"],
            "shape_l2_norm": stats["shape_l2_norm"],
            "eccentricity_norm": stats["eccentricity_norm"],
            "entropy_norm": stats["entropy_norm"],
            "entropy_deficit": stats["entropy_deficit"],
            "u_logrho": math.log(float(rho) / RHO0) / math.log(RHO_SPAN),
        })

    return pd.DataFrame(rows).sort_values("rho_float").reset_index(drop=True)


def fibonacci_sphere(n: int = 300) -> np.ndarray:
    pts = []
    phi = math.pi * (3.0 - math.sqrt(5.0))

    for i in range(n):
        y = 1.0 - (i / float(n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - y * y))
        theta = phi * i
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        pts.append([x, y, z])

    return np.array(pts, dtype=float)


SPHERE_POINTS = fibonacci_sphere(300)
RHAT = SPHERE_POINTS.copy()


def ring_basis(axis_index: int) -> tuple[np.ndarray, np.ndarray]:
    if axis_index == 0:
        return np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])
    if axis_index == 1:
        return np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])
    return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])


def source_points_ring(
    occ: list[int],
    ring_radius: float = 0.55,
    n_per_ring: int = 36,
) -> tuple[np.ndarray, np.ndarray]:
    positions = []
    weights = []

    for axis_index, weight in enumerate(occ):
        if weight <= 0:
            continue

        e1, e2 = ring_basis(axis_index)

        for j in range(n_per_ring):
            t = 2.0 * math.pi * j / n_per_ring
            point = ring_radius * (math.cos(t) * e1 + math.sin(t) * e2)
            positions.append(point)
            weights.append(weight / n_per_ring)

    return np.array(positions, dtype=float), np.array(weights, dtype=float)


def eval_ring_geometry(
    occ: list[int],
    softening: float = 0.12,
    ring_radius: float = 0.55,
) -> dict:
    pos, weights = source_points_ring(occ, ring_radius=ring_radius)

    potentials = []
    grad_mags = []
    abs_radial_curvatures = []

    for x, rh in zip(SPHERE_POINTS, RHAT):
        d = x[None, :] - pos
        d2 = np.sum(d * d, axis=1) + softening ** 2
        R = np.sqrt(d2)

        potential = np.sum(weights / R)

        grad = np.sum((-weights[:, None] * d) / (R[:, None] ** 3), axis=0)
        grad_mag = np.linalg.norm(grad)

        rd = d @ rh
        hess_radial = np.sum(weights * (-1.0 / (R ** 3) + 3.0 * (rd ** 2) / (R ** 5)))

        potentials.append(float(potential))
        grad_mags.append(float(grad_mag))
        abs_radial_curvatures.append(abs(float(hess_radial)))

    return {
        "mean_potential": float(np.mean(potentials)),
        "mean_gradient_magnitude": float(np.mean(grad_mags)),
        "mean_abs_radial_curvature": float(np.mean(abs_radial_curvatures)),
        "p95_abs_radial_curvature": float(np.quantile(abs_radial_curvatures, 0.95)),
    }


def add_geometry_signal(modes: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in modes.iterrows():
        occ = [int(row["occ0"]), int(row["occ1"]), int(row["occ2"])]
        obs = eval_ring_geometry(occ)

        rec = row.to_dict()
        rec.update(obs)
        rows.append(rec)

    df = pd.DataFrame(rows)

    for col in [
        "mean_potential",
        "mean_gradient_magnitude",
        "mean_abs_radial_curvature",
        "p95_abs_radial_curvature",
    ]:
        base = df.loc[df["rho"] == "1/2", col].iloc[0]
        df[col + "_ratio_to_rho_half"] = df[col] / base

    df["G_i_geometry_ratio"] = df["mean_abs_radial_curvature_ratio_to_rho_half"]
    return df


def target_power_exponent(target_span: float) -> float:
    return math.log(target_span) / math.log(RHO_SPAN)


P_D = target_power_exponent(D_TARGET)
P_TOP = target_power_exponent(TOP_E_TARGET)
P_HALF_6PI = (SIX_PI / 2.0) / math.log(RHO_SPAN)
P_HALF_KREQ = (K_REQ / 2.0) / math.log(RHO_SPAN)


def add_targets(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    out["target_D_rhopower"] = (out["rho_float"] / RHO0) ** P_D
    out["target_top_e_rhopower"] = (out["rho_float"] / RHO0) ** P_TOP
    out["target_half_6pi_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_6PI
    out["target_half_Kreq_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_KREQ

    return out


def amplitude_tax_from_shares(shares: list[float]) -> dict:
    arr = np.array(shares, dtype=float)
    arr = arr[arr > 0]

    if arr.size == 0:
        return {
            "N_eff": 1.0,
            "amplitude_tax": 0.0,
            "c_ln2": 0.0,
            "share_string": "()",
            "p_high": np.nan,
            "p_low": np.nan,
            "imbalance": np.nan,
            "participation_sum_squares": 1.0,
        }

    arr = arr / np.sum(arr)
    sumsq = float(np.sum(arr * arr))
    N_eff = 1.0 / sumsq
    amplitude_tax = 0.5 * math.log(N_eff)
    c_ln2 = amplitude_tax / LN2

    sorted_arr = sorted(arr.tolist(), reverse=True)
    if len(sorted_arr) >= 2:
        p_high = sorted_arr[0]
        p_low = sorted_arr[1]
        imbalance = p_high - p_low
    else:
        p_high = sorted_arr[0]
        p_low = 0.0
        imbalance = p_high

    return {
        "N_eff": N_eff,
        "amplitude_tax": amplitude_tax,
        "c_ln2": c_ln2,
        "share_string": "(" + ",".join(f"{x:.12g}" for x in arr.tolist()) + ")",
        "p_high": p_high,
        "p_low": p_low,
        "imbalance": imbalance,
        "participation_sum_squares": sumsq,
    }


def endpoint_from_L(geometry_endpoint: float, L_eff: float) -> float:
    return geometry_endpoint * math.exp(L_eff)


def required_D_split_from_geometry(geometry_endpoint: float) -> dict:
    L_required = math.log(D_TARGET / geometry_endpoint)
    tax_required = THREE_PI - L_required
    c_required = tax_required / LN2
    N_eff = math.exp(2.0 * tax_required)

    if 1.0 <= N_eff <= 2.0:
        sumsq = 1.0 / N_eff
        y2 = max(0.0, (sumsq - 0.5) / 2.0)
        y = math.sqrt(y2)
        p_high = 0.5 + y
        p_low = 0.5 - y
        possible = True
    else:
        p_high = np.nan
        p_low = np.nan
        possible = False

    return {
        "L_required_endpoint": L_required,
        "tax_required": tax_required,
        "c_required": c_required,
        "N_eff_required": N_eff,
        "two_channel_possible": possible,
        "p_high_required": p_high,
        "p_low_required": p_low,
        "imbalance_required": p_high - p_low if possible else np.nan,
    }


def build_projectors() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    P_space = np.diag([1.0, 1.0, 1.0, 0.0, 0.0])
    P_phase = np.diag([0.0, 0.0, 0.0, 1.0, 1.0])
    I = np.eye(5)
    return P_space, P_phase, I


def cross_coupling_matrix() -> np.ndarray:
    C = np.zeros((5, 5))
    block = np.ones((3, 2)) / math.sqrt(6.0)

    C[:3, 3:] = block
    C[3:, :3] = block.T

    return C


def hessian_matrix(k_space: float, k_phase: float, epsilon: float) -> np.ndarray:
    H = np.diag([k_space, k_space, k_space, k_phase, k_phase])
    H += epsilon * cross_coupling_matrix()
    return H


def trace_weights_from_hessian(H: np.ndarray) -> dict:
    P_space, P_phase, _ = build_projectors()

    W_space = float(np.trace(P_space @ H @ P_space))
    W_phase = float(np.trace(P_phase @ H @ P_phase))

    tax = amplitude_tax_from_shares([max(W_space, 0.0), max(W_phase, 0.0)])

    return {
        "W_space": W_space,
        "W_phase": W_phase,
        "N_eff": tax["N_eff"],
        "amplitude_tax": tax["amplitude_tax"],
        "c_ln2": tax["c_ln2"],
        "L_eff": THREE_PI - tax["amplitude_tax"],
        "p_high": tax["p_high"],
        "p_low": tax["p_low"],
        "shares_normalized": tax["share_string"],
    }


def eigenchannel_weights_from_hessian(H: np.ndarray) -> dict:
    vals = np.linalg.eigvalsh(H)
    weights = [abs(float(v)) for v in vals if abs(float(v)) > 1e-12]

    tax = amplitude_tax_from_shares(weights)

    return {
        "eigenvalues": "(" + ",".join(f"{float(v):.12g}" for v in vals.tolist()) + ")",
        "N_eff": tax["N_eff"],
        "amplitude_tax": tax["amplitude_tax"],
        "c_ln2": tax["c_ln2"],
        "L_eff": THREE_PI - tax["amplitude_tax"],
        "p_high": tax["p_high"],
        "p_low": tax["p_low"],
        "shares_normalized": tax["share_string"],
    }


def cross_term_metrics(H: np.ndarray) -> dict:
    P_space, P_phase, _ = build_projectors()

    H_ss = P_space @ H @ P_space
    H_pp = P_phase @ H @ P_phase
    H_sp = P_space @ H @ P_phase
    H_ps = P_phase @ H @ P_space

    diag_norm = float(np.linalg.norm(H_ss) + np.linalg.norm(H_pp))
    cross_norm = float(np.linalg.norm(H_sp) + np.linalg.norm(H_ps))
    leakage_ratio = cross_norm / diag_norm if diag_norm > 0 else np.nan

    vals = np.linalg.eigvalsh(H)
    min_eig = float(np.min(vals))
    max_eig = float(np.max(vals))
    condition_like = abs(max_eig / min_eig) if abs(min_eig) > 1e-12 else np.inf

    return {
        "diag_norm_sum": diag_norm,
        "cross_norm_sum": cross_norm,
        "cross_leakage_ratio": leakage_ratio,
        "min_eigenvalue": min_eig,
        "max_eigenvalue": max_eig,
        "condition_like": condition_like,
        "positive_definite": bool(min_eig > 0.0),
    }


def baseline_models(geometry_endpoint: float) -> pd.DataFrame:
    rows = []

    candidates = [
        {
            "model_id": "protected_trace_3_to_2",
            "family": "protected_trace",
            "shares": [3.0, 2.0],
            "uses_D_to_define": False,
            "native_prior": 10.0,
            "mechanical_reading": "protected sector trace weights rank 3 and rank 2",
            "proof_status": "lead_candidate",
        },
        {
            "model_id": "unprotected_five_equal_null",
            "family": "null",
            "shares": [1.0, 1.0, 1.0, 1.0, 1.0],
            "uses_D_to_define": False,
            "native_prior": 4.0,
            "mechanical_reading": "five independent equal eigenchannels",
            "proof_status": "null_control",
        },
        {
            "model_id": "equal_two_sector_sqrt2",
            "family": "binary_base",
            "shares": [1.0, 1.0],
            "uses_D_to_define": False,
            "native_prior": 7.0,
            "mechanical_reading": "two equal sectors",
            "proof_status": "lower_order_candidate",
        },
        {
            "model_id": "spinor_frame_sqrt_4pi_2pi_bridge",
            "family": "bridge",
            "shares": [math.sqrt(FOUR_PI), math.sqrt(TWO_PI)],
            "uses_D_to_define": False,
            "native_prior": 8.0,
            "mechanical_reading": "sqrt 4π and sqrt 2π bridge",
            "proof_status": "supportive_bridge",
        },
    ]

    for row in candidates:
        tax = amplitude_tax_from_shares(row["shares"])
        L_eff = THREE_PI - tax["amplitude_tax"]
        endpoint = endpoint_from_L(geometry_endpoint, L_eff)

        rec = dict(row)
        rec.update({
            "shares_normalized": tax["share_string"],
            "N_eff": tax["N_eff"],
            "amplitude_tax": tax["amplitude_tax"],
            "c_ln2": tax["c_ln2"],
            "L_eff": L_eff,
            "p_high": tax["p_high"],
            "p_low": tax["p_low"],
            "endpoint_rho2": endpoint,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
        })
        rows.append(rec)

    return pd.DataFrame(rows).sort_values("endpoint_log_error_vs_D_abs")


def normalization_scan(geometry_endpoint: float) -> pd.DataFrame:
    rows = []

    for ratio in np.linspace(0.70, 1.30, 121):
        k_space = float(ratio)
        k_phase = 1.0

        H = hessian_matrix(k_space, k_phase, epsilon=0.0)
        trace = trace_weights_from_hessian(H)
        endpoint = endpoint_from_L(geometry_endpoint, trace["L_eff"])

        rows.append({
            "scan_type": "normalization_drift_trace_protected",
            "k_space_over_k_phase": k_space / k_phase,
            "epsilon_cross": 0.0,
            "W_space": trace["W_space"],
            "W_phase": trace["W_phase"],
            "p_high": trace["p_high"],
            "p_low": trace["p_low"],
            "N_eff": trace["N_eff"],
            "amplitude_tax": trace["amplitude_tax"],
            "L_eff": trace["L_eff"],
            "endpoint_rho2": endpoint,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
        })

    return pd.DataFrame(rows).sort_values("endpoint_log_error_vs_D_abs")


def cross_term_scan(geometry_endpoint: float) -> pd.DataFrame:
    rows = []

    ratios = [0.90, 0.95, 1.0, 1.05, 1.10]
    epsilons = np.linspace(0.0, 0.75, 76)

    for ratio in ratios:
        k_space = ratio
        k_phase = 1.0

        for eps in epsilons:
            H = hessian_matrix(k_space, k_phase, float(eps))

            trace = trace_weights_from_hessian(H)
            eig = eigenchannel_weights_from_hessian(H)
            metrics = cross_term_metrics(H)

            trace_endpoint = endpoint_from_L(geometry_endpoint, trace["L_eff"])
            eig_endpoint = endpoint_from_L(geometry_endpoint, eig["L_eff"])

            rows.append({
                "k_space_over_k_phase": ratio,
                "epsilon_cross": float(eps),
                "cross_leakage_ratio": metrics["cross_leakage_ratio"],
                "positive_definite": metrics["positive_definite"],
                "min_eigenvalue": metrics["min_eigenvalue"],
                "max_eigenvalue": metrics["max_eigenvalue"],
                "trace_p_high": trace["p_high"],
                "trace_N_eff": trace["N_eff"],
                "trace_L_eff": trace["L_eff"],
                "trace_endpoint_vs_D_factor": trace_endpoint / D_TARGET,
                "trace_endpoint_log_error_vs_D_abs": abs(math.log(trace_endpoint / D_TARGET)),
                "eigen_N_eff": eig["N_eff"],
                "eigen_L_eff": eig["L_eff"],
                "eigen_endpoint_vs_D_factor": eig_endpoint / D_TARGET,
                "eigen_endpoint_log_error_vs_D_abs": abs(math.log(eig_endpoint / D_TARGET)),
                "eigenvalues": eig["eigenvalues"],
            })

    return pd.DataFrame(rows)


def summarize_scans(norm: pd.DataFrame, cross: pd.DataFrame) -> dict:
    best_norm = norm.iloc[0].to_dict()

    tolerance_rows = norm[norm["endpoint_log_error_vs_D_abs"] <= 0.01]
    if len(tolerance_rows) > 0:
        norm_tol = {
            "count": int(len(tolerance_rows)),
            "min_k_space_over_k_phase": float(tolerance_rows["k_space_over_k_phase"].min()),
            "max_k_space_over_k_phase": float(tolerance_rows["k_space_over_k_phase"].max()),
        }
    else:
        norm_tol = {
            "count": 0,
            "min_k_space_over_k_phase": None,
            "max_k_space_over_k_phase": None,
        }

    cross_at_equal_norm = cross[cross["k_space_over_k_phase"] == 1.0].copy()
    protected_trace_stability = {
        "trace_error_min": float(cross_at_equal_norm["trace_endpoint_log_error_vs_D_abs"].min()),
        "trace_error_max": float(cross_at_equal_norm["trace_endpoint_log_error_vs_D_abs"].max()),
        "eigen_error_min": float(cross_at_equal_norm["eigen_endpoint_log_error_vs_D_abs"].min()),
        "eigen_error_max": float(cross_at_equal_norm["eigen_endpoint_log_error_vs_D_abs"].max()),
    }

    safe_cross = cross[
        (cross["positive_definite"] == True)
        & (cross["cross_leakage_ratio"] <= 0.10)
        & (cross["trace_endpoint_log_error_vs_D_abs"] <= 0.01)
    ]

    if len(safe_cross) > 0:
        safe_cross_summary = {
            "count": int(len(safe_cross)),
            "max_epsilon_cross": float(safe_cross["epsilon_cross"].max()),
            "max_cross_leakage_ratio": float(safe_cross["cross_leakage_ratio"].max()),
            "k_min": float(safe_cross["k_space_over_k_phase"].min()),
            "k_max": float(safe_cross["k_space_over_k_phase"].max()),
        }
    else:
        safe_cross_summary = {
            "count": 0,
            "max_epsilon_cross": None,
            "max_cross_leakage_ratio": None,
            "k_min": None,
            "k_max": None,
        }

    best_eigen = cross.sort_values("eigen_endpoint_log_error_vs_D_abs").iloc[0].to_dict()

    return {
        "best_normalization_trace_model": best_norm,
        "normalization_log_error_le_0p01_band": norm_tol,
        "cross_scan_equal_norm_stability": protected_trace_stability,
        "safe_cross_term_region_trace_model": safe_cross_summary,
        "best_unprotected_eigenchannel_cross_model": best_eigen,
    }


def gate_matrix(scan_summary: dict) -> pd.DataFrame:
    norm_band = scan_summary["normalization_log_error_le_0p01_band"]
    safe_cross = scan_summary["safe_cross_term_region_trace_model"]

    return pd.DataFrame([
        {
            "gate": "baseline_3_to_2",
            "test": "Trace-weighted rank 3:2 model reproduces lead coefficient.",
            "status": "PASS",
            "boundary": "Still conditional on action protecting trace weighting."
        },
        {
            "gate": "normalization_drift",
            "test": "Allow k_space/k_phase to vary.",
            "status": "PASS_WITH_TOLERANCE" if norm_band["count"] > 0 else "FRAGILE",
            "boundary": f"log-error<=0.01 band: {norm_band}"
        },
        {
            "gate": "cross_terms_protected_trace",
            "test": "Cross terms added but trace-sector coefficient protected.",
            "status": "PASS_CONDITIONAL",
            "boundary": "Only valid if action projects coefficient by sector trace."
        },
        {
            "gate": "cross_terms_unprotected_eigenchannels",
            "test": "Cross terms treated as independent eigenchannels.",
            "status": "CONTROL",
            "boundary": "Eigenchannel treatment is a null/control, not the protected model."
        },
        {
            "gate": "safe_cross_region",
            "test": "Region with leakage<=0.10, positive definite H, and endpoint log error<=0.01.",
            "status": "PASS_REGION_EXISTS" if safe_cross["count"] > 0 else "NO_SAFE_REGION",
            "boundary": f"safe region summary: {safe_cross}"
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need action-level derivation of trace protection and sector normalization."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "The compact D-scale lane is M_i = G_i exp(L_eff u_i).",
            "status": "PRESERVED",
            "boundary": "D-scale lane only."
        },
        {
            "category": "Preserved",
            "claim": "Trace-weighted 3:2 sector model remains the lead coefficient candidate.",
            "status": "PRESERVED",
            "boundary": "Requires action protection of sector traces."
        },
        {
            "category": "Observed",
            "claim": "Small normalization drift does not instantly destroy the D-scale endpoint.",
            "status": "DIAGNOSTIC_PASS",
            "boundary": "Tolerance does not prove normalization."
        },
        {
            "category": "Observed",
            "claim": "Cross terms are safe only if the action projects the coefficient by sector trace.",
            "status": "CONDITIONAL",
            "boundary": "Unprotected eigenchannel interpretation remains a null/control."
        },
        {
            "category": "Open",
            "claim": "The full master action suppresses or renormalizes cross-sector coupling.",
            "status": "OPEN",
            "boundary": "Needs derivation."
        },
        {
            "category": "Rejected",
            "claim": "R213M proves the mass hierarchy.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no full action proof."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def build_report(
    created_utc: str,
    verdict: str,
    required_split: dict,
    baseline: pd.DataFrame,
    norm_summary: dict,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R213M — Sector Normalization and Cross-Term Null Audit

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R213M tests whether the R212 trace-weighted 3:2 coefficient is fragile under spatial/phase normalization drift and cross-sector terms.

Lead compact lane:
M_i = G_i * exp(L_eff * u_i)

Lead coefficient:
L_eff = 3pi - 1/2 ln(25/13)

D-required endpoint split:
{json.dumps(json_safe(required_split), indent=2)}

Baseline models:
{baseline.to_string(index=False)}

Scan summary:
{json.dumps(json_safe(norm_summary), indent=2)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
R213M distinguishes two ideas.

Protected trace model:
The coefficient is computed from sector traces. Cross terms can exist in the Hessian, but the amplitude tax is protected by projection onto the spatial and phase sectors. In this model, the 3:2 coefficient survives cross terms as long as sector trace projection remains valid.

Unprotected eigenchannel model:
The Hessian eigenchannels are treated as independent amplitude channels. This is a null/control because it abandons the R212 grouping premise. It tests what happens if cross terms destroy the sector decomposition.

The result should be read as a protection audit, not a final proof. If the action really protects sector trace weighting, the 3:2 lane is robust. If the action does not protect it, the coefficient can drift.

Ruling:
No V12.13 promotion.

Next recommended run:
R214M — Trace-Protection Mechanism Derivation Gate

Question:
Can no-overwrite support bookkeeping, gauge covariance, or projector invariance force the coefficient to depend on sector traces rather than mixed eigenchannels?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    modes = build_modes()
    geometry = add_geometry_signal(modes)
    target_geometry = add_targets(geometry)

    geometry_endpoint = float(target_geometry.sort_values("rho_float").iloc[-1]["G_i_geometry_ratio"])
    required_split = required_D_split_from_geometry(geometry_endpoint)

    baseline = baseline_models(geometry_endpoint)
    norm = normalization_scan(geometry_endpoint)
    cross = cross_term_scan(geometry_endpoint)
    scan_summary = summarize_scans(norm, cross)

    gates = gate_matrix(scan_summary)
    claims = claim_boundary()

    verdict = (
        "PARTIAL_PASS_TRACE_WEIGHTED_3_TO_2_SURVIVES_NORMALIZATION_DRIFT_IN_TOLERANCE_BAND_"
        "CROSS_TERMS_SAFE_ONLY_UNDER_PROTECTED_SECTOR_TRACE_RULE_"
        "UNPROTECTED_EIGENCHANNEL_NULL_REMAINS_CONTROL_"
        "TRACE_PROTECTION_MECHANISM_OPEN_NO_V12_13"
    )

    lead = baseline[baseline["model_id"] == "protected_trace_3_to_2"].iloc[0].to_dict()
    null = baseline[baseline["model_id"] == "unprotected_five_equal_null"].iloc[0].to_dict()

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "compact_formula": "M_i = G_i * exp(L_eff * u_i)",
        "candidate_law": "L_eff = 3*pi - 0.5*ln(25/13)",
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "three_pi": THREE_PI,
            "ln2": LN2,
            "sqrt2": SQRT2,
            "half_ln_25_over_13": 0.5 * math.log(25.0 / 13.0),
            "three_pi_minus_half_ln_25_over_13": THREE_PI - 0.5 * math.log(25.0 / 13.0),
            "N_eff_3_to_2": 25.0 / 13.0,
            "K_req_half": HALF_K_REQ,
            "p_D": P_D,
            "p_top": P_TOP,
        },
        "D_required_endpoint_split": required_split,
        "lead_protected_trace_result": lead,
        "unprotected_five_equal_null_result": null,
        "scan_summary": scan_summary,
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R214M - Trace-Protection Mechanism Derivation Gate",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R213M_baseline_models.csv",
            "tables/R213M_normalization_scan.csv",
            "tables/R213M_cross_term_scan.csv",
            "Any traceback if the run failed."
        ],
    }

    modes.to_csv(tables / "R213M_mode_geometry_inputs.csv", index=False)
    geometry.to_csv(tables / "R213M_geometry_signal.csv", index=False)
    target_geometry.to_csv(tables / "R213M_target_geometry.csv", index=False)
    baseline.to_csv(tables / "R213M_baseline_models.csv", index=False)
    norm.to_csv(tables / "R213M_normalization_scan.csv", index=False)
    cross.to_csv(tables / "R213M_cross_term_scan.csv", index=False)
    gates.to_csv(tables / "R213M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R213M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        required_split=required_split,
        baseline=baseline,
        norm_summary=scan_summary,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
