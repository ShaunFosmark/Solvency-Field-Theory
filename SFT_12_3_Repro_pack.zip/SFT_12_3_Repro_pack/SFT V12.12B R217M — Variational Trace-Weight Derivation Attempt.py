#!/usr/bin/env python3
"""
SFT V12.12B R217M — Variational Trace-Weight Derivation Attempt

Purpose:
    R216M wrote the canonical 3+2 master-action patch candidate:

        Q = (X1, X2, X3 ; Phi_spinor, Phi_frame)

        X_i          = x_i / r_*
        Phi_spinor   = phi_spinor / 4π
        Phi_frame    = phi_frame  / 2π

        dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2

    R217M asks:

        Can the sector trace rule be obtained from the quadratic variation
        of the action?

Core variational idea:
    Let the local quadratic action variation be

        δ²S = 1/2 δQᵀ H δQ

    with protected projectors:

        P_space = diag(1,1,1,0,0)
        P_phase = diag(0,0,0,1,1)

    For isotropic canonical fluctuations inside each sector,

        <δ²S_space> = 1/2 σ² Tr(P_space H P_space)
        <δ²S_phase> = 1/2 σ² Tr(P_phase H P_phase)

    Therefore the variational sector weights are traces, not eigenchannel counts.

For the R216 canonical metric H = I_5:

        W_space = Tr(P_space H P_space) = 3
        W_phase = Tr(P_phase H P_phase) = 2

    so:

        N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13
        L_eff = 3π - 1/2 ln(25/13)

This run tests:
    1. analytic second-variation trace rule,
    2. Monte Carlo fluctuation confirmation,
    3. cross-term expectation cancellation for independent zero-mean sectors,
    4. raw-radian control rejection,
    5. five-eigenchannel null rejection.

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - no V12.13 promotion inside this run

Outputs:
    SFT_V12_12B_R217M_Variational_Trace_Weight_Derivation_Attempt/
        report.md
        variational_patch_note.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R217M.py

    SFT_V12_12B_R217M_Variational_Trace_Weight_Derivation_Attempt_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R217M_Variational_Trace_Weight_Derivation_Attempt"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

G_ENDPOINT_RHO2 = 2.0


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def amplitude_tax_from_shares(shares: list[float]) -> dict:
    arr = np.array(shares, dtype=float)
    arr = arr[arr > 0]

    if arr.size == 0:
        return {
            "shares_normalized": "()",
            "N_eff": 1.0,
            "amplitude_tax": 0.0,
            "c_ln2": 0.0,
            "p_high": None,
            "p_low": None,
            "participation_sum_squares": 1.0,
        }

    arr = arr / np.sum(arr)
    sumsq = float(np.sum(arr * arr))
    N_eff = 1.0 / sumsq
    amplitude_tax = 0.5 * math.log(N_eff)

    sorted_arr = sorted(arr.tolist(), reverse=True)

    return {
        "shares_normalized": "(" + ",".join(f"{x:.12g}" for x in arr.tolist()) + ")",
        "N_eff": N_eff,
        "amplitude_tax": amplitude_tax,
        "c_ln2": amplitude_tax / LN2,
        "p_high": sorted_arr[0],
        "p_low": sorted_arr[1] if len(sorted_arr) > 1 else 0.0,
        "participation_sum_squares": sumsq,
    }


def endpoint_from_L(L_eff: float) -> float:
    return G_ENDPOINT_RHO2 * math.exp(L_eff)


def endpoint_record(label: str, shares: list[float], status: str, native_prior: float, uses_D_to_define: bool) -> dict:
    tax = amplitude_tax_from_shares(shares)
    L_eff = THREE_PI - tax["amplitude_tax"]
    endpoint = endpoint_from_L(L_eff)

    rec = {
        "model_id": label,
        "status": status,
        "native_prior": native_prior,
        "uses_D_to_define": uses_D_to_define,
        "shares_input": "(" + ",".join(f"{x:.12g}" for x in shares) + ")",
        "L_eff": L_eff,
        "endpoint_rho2": endpoint,
        "endpoint_vs_D_factor": endpoint / D_TARGET,
        "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
        "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
    }
    rec.update(tax)

    score = native_prior
    err = rec["endpoint_log_error_vs_D_abs"]

    if err < 0.001:
        score += 6.0
    elif err < 0.01:
        score += 5.0
    elif err < 0.03:
        score += 4.0
    elif err < 0.1:
        score += 3.0
    elif err < 0.5:
        score += 1.0

    if uses_D_to_define:
        score -= 12.0
    if "null" in status.lower():
        score -= 4.0
    if "control" in status.lower():
        score -= 2.0

    rec["combined_score"] = score
    return rec


def required_D_k() -> dict:
    L_required = math.log(D_TARGET / G_ENDPOINT_RHO2)
    tax_required = THREE_PI - L_required
    N_eff_required = math.exp(2.0 * tax_required)
    c_required = tax_required / LN2

    if 1.0 <= N_eff_required <= 2.0:
        sumsq = 1.0 / N_eff_required
        y2 = max(0.0, (sumsq - 0.5) / 2.0)
        y = math.sqrt(y2)
        p_high = 0.5 + y
        p_low = 0.5 - y
        k_required = (2.0 * p_high) / (3.0 * (1.0 - p_high))
    else:
        p_high = None
        p_low = None
        k_required = None

    return {
        "L_required_endpoint": L_required,
        "tax_required": tax_required,
        "c_required_ln2_units": c_required,
        "N_eff_required": N_eff_required,
        "p_high_required": p_high,
        "p_low_required": p_low,
        "k_space_over_k_phase_required": k_required,
        "k_required_minus_1": None if k_required is None else k_required - 1.0,
        "k_required_percent_offset_from_equal": None if k_required is None else 100.0 * (k_required - 1.0),
    }


def projectors() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    P_space = np.diag([1.0, 1.0, 1.0, 0.0, 0.0])
    P_phase = np.diag([0.0, 0.0, 0.0, 1.0, 1.0])
    I5 = np.eye(5)
    return P_space, P_phase, I5


def cross_coupling_matrix() -> np.ndarray:
    C = np.zeros((5, 5))
    block = np.ones((3, 2)) / math.sqrt(6.0)
    C[:3, 3:] = block
    C[3:, :3] = block.T
    return C


def hessian_cases() -> dict[str, dict]:
    req = required_D_k()
    k_req = req["k_space_over_k_phase_required"]

    return {
        "canonical_R216_patch_H_I5": {
            "H": np.eye(5),
            "status": "LEAD_VARIATIONAL_PATCH",
            "native_prior": 12.0,
            "uses_D_to_define": False,
            "interpretation": "R216 canonical cycle-normalized 3+2 metric; second variation Hessian is I_5",
        },
        "D_exact_diagnostic_H": {
            "H": np.diag([k_req, k_req, k_req, 1.0, 1.0]),
            "status": "DIAGNOSTIC_ONLY_USES_D",
            "native_prior": -8.0,
            "uses_D_to_define": True,
            "interpretation": "D-exact diagnostic metric; not allowed to define the law",
        },
        "raw_radian_control_H": {
            "H": np.diag([1.0, 1.0, 1.0, FOUR_PI, TWO_PI]),
            "status": "CONTROL_RAW_RADIAN_DOUBLE_COUNTS_CLOSURE",
            "native_prior": 1.0,
            "uses_D_to_define": False,
            "interpretation": "control: raw phase periods are treated as metric weights; expected to fail as native patch",
        },
        "canonical_plus_cross_eps_0p10": {
            "H": np.eye(5) + 0.10 * cross_coupling_matrix(),
            "status": "CROSS_TERM_TEST",
            "native_prior": 8.0,
            "uses_D_to_define": False,
            "interpretation": "canonical metric plus mild cross-sector Hessian term",
        },
        "canonical_plus_cross_eps_0p25": {
            "H": np.eye(5) + 0.25 * cross_coupling_matrix(),
            "status": "CROSS_TERM_TEST",
            "native_prior": 6.0,
            "uses_D_to_define": False,
            "interpretation": "canonical metric plus stronger cross-sector Hessian term",
        },
        "five_equal_eigenchannel_null": {
            "H": np.eye(5),
            "status": "NULL_WRONG_BOOKKEEPING",
            "native_prior": 1.0,
            "uses_D_to_define": False,
            "interpretation": "same canonical Hessian but interpreted as five independent channels instead of two sector traces",
        },
    }


def sector_trace_weights(H: np.ndarray) -> dict:
    P_space, P_phase, _ = projectors()

    W_space = float(np.trace(P_space @ H @ P_space))
    W_phase = float(np.trace(P_phase @ H @ P_phase))

    grouped = endpoint_record(
        "sector_trace",
        [abs(W_space), abs(W_phase)],
        "TRACE_RULE",
        0.0,
        False,
    )

    return {
        "W_space": W_space,
        "W_phase": W_phase,
        "N_eff": grouped["N_eff"],
        "amplitude_tax": grouped["amplitude_tax"],
        "L_eff": grouped["L_eff"],
        "endpoint_vs_D_factor": grouped["endpoint_vs_D_factor"],
        "endpoint_log_error_vs_D_abs": grouped["endpoint_log_error_vs_D_abs"],
        "shares_normalized": grouped["shares_normalized"],
    }


def eigenchannel_weights(H: np.ndarray) -> dict:
    vals = np.linalg.eigvalsh(H)
    shares = [abs(float(v)) for v in vals if abs(float(v)) > 1e-12]

    eig = endpoint_record(
        "eigenchannel",
        shares,
        "EIGENCHANNEL",
        0.0,
        False,
    )

    return {
        "eigenvalues": "(" + ",".join(f"{float(v):.12g}" for v in vals.tolist()) + ")",
        "N_eff": eig["N_eff"],
        "amplitude_tax": eig["amplitude_tax"],
        "L_eff": eig["L_eff"],
        "endpoint_vs_D_factor": eig["endpoint_vs_D_factor"],
        "endpoint_log_error_vs_D_abs": eig["endpoint_log_error_vs_D_abs"],
        "shares_normalized": eig["shares_normalized"],
    }


def analytic_variational_audit() -> pd.DataFrame:
    P_space, P_phase, _ = projectors()
    rows = []

    for case_id, info in hessian_cases().items():
        H = info["H"]
        trace = sector_trace_weights(H)
        eig = eigenchannel_weights(H)

        cross_norm = float(np.linalg.norm(P_space @ H @ P_phase) + np.linalg.norm(P_phase @ H @ P_space))
        diag_norm = float(np.linalg.norm(P_space @ H @ P_space) + np.linalg.norm(P_phase @ H @ P_phase))
        cross_ratio = cross_norm / diag_norm if diag_norm > 0 else np.nan

        # Expected quadratic action for isotropic canonical sector fluctuations:
        # E[1/2 δQ_s^T H δQ_s] = 1/2 σ² Tr(P_s H P_s)
        expected_space_action_sigma1 = 0.5 * trace["W_space"]
        expected_phase_action_sigma1 = 0.5 * trace["W_phase"]

        rows.append({
            "case_id": case_id,
            "status": info["status"],
            "interpretation": info["interpretation"],
            "uses_D_to_define": bool(info["uses_D_to_define"]),
            "W_space_trace": trace["W_space"],
            "W_phase_trace": trace["W_phase"],
            "expected_space_action_sigma1": expected_space_action_sigma1,
            "expected_phase_action_sigma1": expected_phase_action_sigma1,
            "expected_action_ratio_space_to_phase": expected_space_action_sigma1 / expected_phase_action_sigma1 if expected_phase_action_sigma1 != 0 else np.nan,
            "trace_N_eff": trace["N_eff"],
            "trace_L_eff": trace["L_eff"],
            "trace_endpoint_vs_D": trace["endpoint_vs_D_factor"],
            "trace_log_error_vs_D": trace["endpoint_log_error_vs_D_abs"],
            "eigen_N_eff": eig["N_eff"],
            "eigen_L_eff": eig["L_eff"],
            "eigen_endpoint_vs_D": eig["endpoint_vs_D_factor"],
            "eigen_log_error_vs_D": eig["endpoint_log_error_vs_D_abs"],
            "eigenvalues": eig["eigenvalues"],
            "cross_norm": cross_norm,
            "cross_ratio": cross_ratio,
        })

    return pd.DataFrame(rows)


def monte_carlo_variational_audit(n_samples: int = 200000, seed: int = 217) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    P_space, P_phase, _ = projectors()

    rows = []

    for case_id, info in hessian_cases().items():
        H = info["H"]

        # Sector-only fluctuations.
        qs = np.zeros((n_samples, 5))
        qp = np.zeros((n_samples, 5))

        qs[:, :3] = rng.normal(0.0, 1.0, size=(n_samples, 3))
        qp[:, 3:] = rng.normal(0.0, 1.0, size=(n_samples, 2))

        # Independent full fluctuations.
        q_full = qs + qp

        S_space = 0.5 * np.einsum("ni,ij,nj->n", qs, H, qs)
        S_phase = 0.5 * np.einsum("ni,ij,nj->n", qp, H, qp)
        S_full = 0.5 * np.einsum("ni,ij,nj->n", q_full, H, q_full)
        S_cross = S_full - S_space - S_phase

        trace = sector_trace_weights(H)

        analytic_space = 0.5 * trace["W_space"]
        analytic_phase = 0.5 * trace["W_phase"]

        rows.append({
            "case_id": case_id,
            "mean_S_space_MC": float(np.mean(S_space)),
            "mean_S_phase_MC": float(np.mean(S_phase)),
            "mean_S_cross_MC": float(np.mean(S_cross)),
            "mean_S_full_MC": float(np.mean(S_full)),
            "analytic_S_space": analytic_space,
            "analytic_S_phase": analytic_phase,
            "space_MC_minus_analytic": float(np.mean(S_space) - analytic_space),
            "phase_MC_minus_analytic": float(np.mean(S_phase) - analytic_phase),
            "space_to_phase_ratio_MC": float(np.mean(S_space) / np.mean(S_phase)),
            "space_to_phase_ratio_analytic": analytic_space / analytic_phase if analytic_phase != 0 else np.nan,
            "abs_cross_mean_over_full_mean": abs(float(np.mean(S_cross))) / abs(float(np.mean(S_full))) if abs(float(np.mean(S_full))) > 0 else np.nan,
        })

    return pd.DataFrame(rows)


def scorecard(analytic: pd.DataFrame, mc: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in analytic.iterrows():
        case_id = row["case_id"]
        mc_row = mc[mc["case_id"] == case_id].iloc[0]

        status = row["status"]
        native_prior = {
            "LEAD_VARIATIONAL_PATCH": 12.0,
            "DIAGNOSTIC_ONLY_USES_D": -8.0,
            "CONTROL_RAW_RADIAN_DOUBLE_COUNTS_CLOSURE": 1.0,
            "CROSS_TERM_TEST": 7.0,
            "NULL_WRONG_BOOKKEEPING": 1.0,
        }.get(status, 0.0)

        err = float(row["trace_log_error_vs_D"])
        score = native_prior

        if err < 0.001:
            score += 6.0
        elif err < 0.01:
            score += 5.0
        elif err < 0.03:
            score += 4.0
        elif err < 0.1:
            score += 3.0
        elif err < 0.5:
            score += 1.0

        if bool(row["uses_D_to_define"]):
            score -= 12.0
        if "NULL" in str(status):
            score -= 4.0
        if "CONTROL" in str(status):
            score -= 2.0

        variational_match = (
            abs(float(mc_row["space_MC_minus_analytic"])) < 0.02
            and abs(float(mc_row["phase_MC_minus_analytic"])) < 0.02
        )

        if variational_match:
            score += 2.0

        rows.append({
            "case_id": case_id,
            "status": status,
            "combined_score": score,
            "uses_D_to_define": bool(row["uses_D_to_define"]),
            "trace_N_eff": row["trace_N_eff"],
            "trace_L_eff": row["trace_L_eff"],
            "trace_endpoint_vs_D": row["trace_endpoint_vs_D"],
            "trace_log_error_vs_D": row["trace_log_error_vs_D"],
            "eigen_N_eff": row["eigen_N_eff"],
            "eigen_endpoint_vs_D": row["eigen_endpoint_vs_D"],
            "cross_ratio": row["cross_ratio"],
            "space_to_phase_ratio_analytic": row["expected_action_ratio_space_to_phase"],
            "space_to_phase_ratio_MC": mc_row["space_to_phase_ratio_MC"],
            "mean_cross_action_MC": mc_row["mean_S_cross_MC"],
            "abs_cross_mean_over_full_mean": mc_row["abs_cross_mean_over_full_mean"],
            "variational_MC_confirms_trace": bool(variational_match),
        })

    return pd.DataFrame(rows).sort_values("combined_score", ascending=False)


def variational_premise_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "premise": "quadratic_second_variation",
            "statement": "The local patch admits δ²S = 1/2 δQᵀ H δQ.",
            "status": "PATCH_PASS",
            "boundary": "This is the quadratic local variation of the R216 patch."
        },
        {
            "premise": "canonical_Hessian",
            "statement": "For the R216 canonical metric, H = I_5.",
            "status": "PATCH_PASS",
            "boundary": "Requires accepting cycle-normalized coordinates."
        },
        {
            "premise": "isotropic_sector_fluctuations",
            "statement": "Allowed fluctuations are isotropic inside the spatial and phase sectors.",
            "status": "SYMMETRY_SUPPORTED",
            "boundary": "Uses R214 rotational/gauge covariance argument."
        },
        {
            "premise": "trace_expectation_identity",
            "statement": "E[δQ_sᵀ H δQ_s] = σ² Tr(P_s H P_s).",
            "status": "PASS_FORMAL",
            "boundary": "This is the mathematical trace derivation."
        },
        {
            "premise": "cross_expectation_cancellation",
            "statement": "Independent zero-mean spatial and phase fluctuations make mean cross action vanish.",
            "status": "PASS_MC_AND_FORMAL",
            "boundary": "Cross terms can still matter if sectors are dynamically correlated."
        },
        {
            "premise": "sector_weight_result",
            "statement": "For H=I_5, W_space=3 and W_phase=2.",
            "status": "PASS",
            "boundary": "D-scale lane only."
        },
        {
            "premise": "variational_trace_weight",
            "statement": "The trace rule arises from second variation, not from an added postulate.",
            "status": "CONDITIONAL_PASS",
            "boundary": "Conditional on the R216 patch being the correct local action measure."
        },
        {
            "premise": "V12_13",
            "statement": "Promote final version.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no prediction/null suite."
        },
    ])


def gate_matrix(score: pd.DataFrame, analytic: pd.DataFrame, mc: pd.DataFrame) -> pd.DataFrame:
    lead = score[score["case_id"] == "canonical_R216_patch_H_I5"].iloc[0]
    raw = score[score["case_id"] == "raw_radian_control_H"].iloc[0]
    null = score[score["case_id"] == "five_equal_eigenchannel_null"].iloc[0]
    cross01 = score[score["case_id"] == "canonical_plus_cross_eps_0p10"].iloc[0]
    cross025 = score[score["case_id"] == "canonical_plus_cross_eps_0p25"].iloc[0]

    return pd.DataFrame([
        {
            "gate": "second_variation_written",
            "test": "δ²S = 1/2 δQᵀ H δQ with R216 canonical Q.",
            "status": "PASS_PATCH",
            "boundary": "Patch-level second variation, not full global action."
        },
        {
            "gate": "trace_identity",
            "test": "Sector expected quadratic action equals 1/2 trace.",
            "status": "PASS",
            "boundary": "Formal and Monte Carlo confirmed."
        },
        {
            "gate": "lead_canonical_trace",
            "test": "Canonical H=I_5 gives W_space=3 and W_phase=2.",
            "status": "PASS",
            "boundary": f"endpoint_vs_D={lead['trace_endpoint_vs_D']}"
        },
        {
            "gate": "cross_term_expectation",
            "test": "Cross terms have near-zero mean for independent sector fluctuations.",
            "status": "PASS_DIAGNOSTIC",
            "boundary": f"eps0.10 cross mean ratio={cross01['abs_cross_mean_over_full_mean']}, eps0.25 cross mean ratio={cross025['abs_cross_mean_over_full_mean']}"
        },
        {
            "gate": "raw_radian_control",
            "test": "Raw phase periods treated as Hessian weights.",
            "status": "FAILS_AS_NATIVE",
            "boundary": f"endpoint_vs_D={raw['trace_endpoint_vs_D']}; double-counts closure periods."
        },
        {
            "gate": "five_eigenchannel_null",
            "test": "Five independent eigenchannels rather than sector traces.",
            "status": "FAILS_AS_PRIMARY",
            "boundary": f"endpoint_vs_D={null['trace_endpoint_vs_D']}"
        },
        {
            "gate": "variational_derivation_status",
            "test": "Trace rule appears from second variation of the canonical patch.",
            "status": "CONDITIONAL_PASS",
            "boundary": "Still conditional on R216 canonical patch being accepted as local action measure."
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need species map, top/e closure, and prediction/null suite."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "The compact D-scale lane remains M_i = G_i exp(L_eff u_i).",
            "status": "PRESERVED",
            "boundary": "D-scale lane only."
        },
        {
            "category": "Preserved",
            "claim": "The R216 canonical 3+2 patch has a quadratic variation with H=I_5.",
            "status": "PATCH_PASS",
            "boundary": "Patch-level result."
        },
        {
            "category": "Preserved",
            "claim": "The trace-weight rule follows from expected second variation under isotropic sector fluctuations.",
            "status": "CONDITIONAL_PASS",
            "boundary": "Conditional on canonical patch and independent sector fluctuations."
        },
        {
            "category": "Observed",
            "claim": "Monte Carlo sector fluctuations confirm the trace expectation identity.",
            "status": "DIAGNOSTIC_PASS",
            "boundary": "Numerical confirmation of the formal identity."
        },
        {
            "category": "Rejected",
            "claim": "Raw-radian phase weights are the canonical Hessian weights.",
            "status": "NO",
            "boundary": "Rejected as closure-period double counting."
        },
        {
            "category": "Rejected",
            "claim": "Five independent eigenchannels are the correct amplitude bookkeeping.",
            "status": "NO",
            "boundary": "Rejected if protected sectors are physical."
        },
        {
            "category": "Open",
            "claim": "This proves the full particle mass hierarchy.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no prediction/null suite."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def variational_patch_note(created_utc: str) -> str:
    return f"""
# R217M Variational Trace-Weight Patch Note

Generated: {created_utc}

This note records the patch-level variational derivation attempted in R217M.

## Starting point

Use the R216 canonical audit vector:

    Q = (X1, X2, X3 ; Phi_spinor, Phi_frame)

with:

    X_i = x_i / r_*
    Phi_spinor = phi_spinor / 4pi
    Phi_frame  = phi_frame  / 2pi

and canonical metric:

    dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2

## Quadratic variation

The local quadratic action variation is:

    delta^2 S = 1/2 delta Q^T H delta Q

For the canonical patch:

    H = I_5

## Projectors

Let:

    P_space = diag(1,1,1,0,0)
    P_phase = diag(0,0,0,1,1)

## Trace identity

For isotropic fluctuations in a sector with covariance sigma^2 P_s:

    E[delta Q_s^T H delta Q_s] = sigma^2 Tr(P_s H P_s)

Therefore:

    E[delta^2 S_s] = 1/2 sigma^2 Tr(P_s H P_s)

For H = I_5:

    W_space = Tr(P_space H P_space) = 3
    W_phase = Tr(P_phase H P_phase) = 2

## Amplitude tax

Using the sector variation weights:

    N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13

and:

    L_eff = 3pi - 1/2 ln(25/13)

## Claim boundary

This derives the trace rule from the second variation of the canonical patch.
It remains conditional on the R216 patch being the correct local master-action measure.
It does not assign species.
It does not close top/e.
It does not promote V12.13.
"""


def build_report(
    created_utc: str,
    verdict: str,
    req: dict,
    analytic: pd.DataFrame,
    mc: pd.DataFrame,
    score: pd.DataFrame,
    premises: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R217M — Variational Trace-Weight Derivation Attempt

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R217M tests whether the sector trace rule can be obtained from the quadratic variation of the R216 canonical patch.

D-required normalization diagnostic:
{json.dumps(json_safe(req), indent=2)}

Analytic variational audit:
{analytic.to_string(index=False)}

Monte Carlo variational audit:
{mc.to_string(index=False)}

Scorecard:
{score.to_string(index=False)}

Premise matrix:
{premises.to_string(index=False)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
The trace rule is no longer merely a bookkeeping instruction. At the patch level, it follows from the expected quadratic variation of isotropic sector fluctuations:

E[delta^2 S_s] = 1/2 sigma^2 Tr(P_s H P_s).

For the R216 canonical patch H=I_5, this gives W_space=3 and W_phase=2. The resulting N_eff is 25/13 and the D-scale coefficient remains L_eff = 3pi - 1/2 ln(25/13).

Cross terms have near-zero mean under independent zero-mean sector fluctuations, supporting the protected trace rule.

The raw-radian control remains rejected as double-counting closure periods. The five-eigenchannel null remains rejected if protected sectors are physical.

Ruling:
No V12.13 promotion.

Next recommended run:
R218M — D-Scale Law Freeze Candidate and Remaining-Open-Claims Ledger

Question:
Is the D-scale hierarchy law now mature enough to freeze as a conditional paper-grade law candidate, while explicitly reserving species map, top/e closure, and prediction/null suite as open?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    req = required_D_k()
    analytic = analytic_variational_audit()
    mc = monte_carlo_variational_audit()
    score = scorecard(analytic, mc)
    premises = variational_premise_matrix()
    gates = gate_matrix(score, analytic, mc)
    claims = claim_boundary()

    lead = score[score["case_id"] == "canonical_R216_patch_H_I5"].iloc[0].to_dict()
    raw = score[score["case_id"] == "raw_radian_control_H"].iloc[0].to_dict()
    null = score[score["case_id"] == "five_equal_eigenchannel_null"].iloc[0].to_dict()

    verdict = (
        "PARTIAL_PASS_VARIATIONAL_TRACE_RULE_DERIVED_FROM_CANONICAL_PATCH_SECOND_VARIATION_"
        "SECTOR_WEIGHTS_3_AND_2_FOLLOW_FROM_HESSIAN_TRACES_"
        "CROSS_TERMS_AVERAGE_OUT_FOR_INDEPENDENT_ZERO_MEAN_SECTOR_FLUCTUATIONS_"
        "RAW_RADIAN_AND_FIVE_EIGENCHANNEL_NULLS_REJECTED_"
        "SPECIES_TOP_E_AND_PREDICTION_SUITE_OPEN_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "compact_formula": "M_i = G_i exp(L_eff u_i)",
        "candidate_law": "L_eff = 3*pi - 0.5*ln(25/13)",
        "variational_trace_rule": {
            "quadratic_variation": "delta^2 S = 1/2 delta Q^T H delta Q",
            "canonical_H": "I_5",
            "trace_identity": "E[delta^2 S_s] = 1/2 sigma^2 Tr(P_s H P_s)",
            "W_space": 3.0,
            "W_phase": 2.0,
            "N_eff": 25.0 / 13.0,
        },
        "D_required_normalization": req,
        "lead_variational_patch_result": lead,
        "raw_radian_control_result": raw,
        "five_eigenchannel_null_result": null,
        "scorecard": score.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R218M - D-Scale Law Freeze Candidate and Remaining-Open-Claims Ledger",
        "paste_back_to_chat": [
            "summary.json",
            "variational_patch_note.md",
            "tables/R217M_analytic_variational_audit.csv",
            "tables/R217M_monte_carlo_variational_audit.csv",
            "tables/R217M_scorecard.csv",
            "Any traceback if the run failed."
        ],
    }

    analytic.to_csv(tables / "R217M_analytic_variational_audit.csv", index=False)
    mc.to_csv(tables / "R217M_monte_carlo_variational_audit.csv", index=False)
    score.to_csv(tables / "R217M_scorecard.csv", index=False)
    premises.to_csv(tables / "R217M_variational_premise_matrix.csv", index=False)
    gates.to_csv(tables / "R217M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R217M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        req=req,
        analytic=analytic,
        mc=mc,
        score=score,
        premises=premises,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "variational_patch_note.md").write_text(variational_patch_note(created_utc), encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
