
# SFT V12.12B R215M — Canonical Sector Normalization Derivation Gate

Generated: 2026-06-18T04:31:15Z

Verdict:
PARTIAL_PASS_CANONICAL_EQUAL_SECTOR_NORMALIZATION_IS_LEAD_NATIVE_CHOICE_D_REQUIRED_K_IS_WITHIN_0P35_PERCENT_OF_EQUAL_UNIT_METRIC_FINITE_NORMALIZATION_TOLERANCE_BAND_CONFIRMED_MASTER_ACTION_CANONICAL_METRIC_STATEMENT_STILL_OPEN_NO_V12_13

Purpose:
R215M tests whether equal per-component normalization between spatial support and phase refresh sectors is a native canonical choice.

Lead compact lane:
M_i = G_i * exp(L_eff * u_i)

Lead coefficient:
L_eff = 3pi - 1/2 ln(25/13)

Canonical equal normalization:
k_space/k_phase = 1

D-required normalization:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required_ln2_units": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446,
  "k_space_over_k_phase_required": 1.0034608010243735,
  "k_required_minus_1": 0.0034608010243735166,
  "k_required_percent_offset_from_equal": 0.34608010243735166
}

Candidate normalization scorecard:
                                model_id                           status  uses_D_to_define  native_prior  k_space_over_k_phase  W_space  W_phase    L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_log_error_vs_D_abs  endpoint_vs_top_e_factor               shares_normalized    N_eff  amplitude_tax    c_ln2   p_high    p_low  participation_sum_squares  combined_score
           canonical_equal_per_component            lead_native_candidate             False          10.0              1.000000 3.000000      2.0 9.097815   17871.488624              0.999680                     0.000320                  0.052718                       (0.6,0.4) 1.923077       0.326963 0.471708 0.600000 0.400000                   0.520000            16.0
  spinor_frame_sqrt_4pi_2pi_equivalent_k                supportive_bridge             False           8.0              0.942809 2.828427      2.0 9.092711   17780.501218              0.994590                     0.005424                  0.052450 (0.585786437627,0.414213562373) 1.942809       0.332067 0.479072 0.585786 0.414214                   0.514719            13.0
spinor_frame_direct_4pi_2pi_equivalent_k supportive_but_less_exact_bridge             False           6.5              1.333333 4.000000      2.0 9.130885   18472.377901              1.033292                     0.032750                  0.054491 (0.666666666667,0.333333333333) 1.800000       0.293893 0.423998 0.666667 0.333333                   0.555556             9.5
nearby_half_percent_spatial_lift_control               diagnostic_control             False           2.0              1.005000 3.015000      2.0 9.098277   17879.759613              1.000143                     0.000143                  0.052743 (0.601196410768,0.398803589232) 1.921298       0.326501 0.471041 0.601196 0.398804                   0.520481             6.0
       three_plus_one_support_tangent_k2                   3plus1_control             False           4.0              2.000000 6.000000      2.0 9.189776   19592.915518              1.095972                     0.091641                  0.057796                     (0.75,0.25) 1.600000       0.235002 0.339036 0.750000 0.250000                   0.625000             5.0
          phase_dominant_inverse_control                          control             False           2.0              0.500000 1.500000      2.0 9.088306   17702.354011              0.990219                     0.009829                  0.052219 (0.428571428571,0.571428571429) 1.960000       0.336472 0.485427 0.571429 0.428571                   0.510204             5.0
           D_inferred_exact_k_diagnostic           diagnostic_only_uses_D              True          -8.0              1.003461 3.010382      2.0 9.098135   17877.208690              1.000000                     0.000000                  0.052735 (0.600828871111,0.399171128889) 1.921846       0.326643 0.471247 0.600829 0.399171                   0.520333           -14.0

Best scan row:
{
  "model_id": "scan_k",
  "status": "scan",
  "uses_D_to_define": false,
  "native_prior": 0.0,
  "k_space_over_k_phase": 1.0030000000000001,
  "W_space": 3.0090000000000003,
  "W_phase": 2.0,
  "L_eff": 9.098092068988105,
  "endpoint_rho2": 17876.445823966696,
  "endpoint_vs_D_factor": 0.9999573274766784,
  "endpoint_log_error_vs_D_abs": 4.267343381959969e-05,
  "endpoint_vs_top_e_factor": 0.05273287853677491,
  "shares_normalized": "(0.600718706329,0.399281293671)",
  "N_eff": 1.9220105191625514,
  "amplitude_tax": 0.3266858917812735,
  "c_ln2": 0.47130811600123185,
  "p_high": 0.6007187063286086,
  "p_low": 0.3992812936713915,
  "participation_sum_squares": 0.520288515609017
}

Gate matrix:
                         gate                                                  test                status                                                                   boundary
       canonical_equal_metric Does k_space/k_phase=1 give the lead 3:2 coefficient?                  PASS                                           endpoint_vs_D=0.9996800358435753
                 D_required_k     How far is D-required k from equal normalization? VERY_CLOSE_DIAGNOSTIC          k_required=1.0034608010243735, percent offset=0.34608010243735166
normalization_tolerance_0p001              k band with endpoint log error <= 0.001.      PASS_BAND_EXISTS                              {'min_k': 0.993, 'max_k': 1.014, 'count': 22}
 normalization_tolerance_0p01               k band with endpoint log error <= 0.01.      PASS_BAND_EXISTS                             {'min_k': 0.887, 'max_k': 1.107, 'count': 221}
                bridge_models       Do spinor-frame alternatives remain supportive?            SUPPORTIVE sqrt(4pi):sqrt(2pi) remains close but not as clean as canonical trace 3:2.
             D_inferred_model                    Exact D k is kept diagnostic-only.  REJECT_AS_DERIVATION                                             diagnostic endpoint factor=1.0
                       V12_13                                            Promotion.                    NO  Need explicit master-action normalization term and prediction/null tests.

Claim boundary:
 category                                                                                          claim              status                                               boundary
Preserved                                     The compact D-scale lane remains M_i = G_i exp(L_eff u_i).           PRESERVED                                     D-scale lane only.
Preserved          Canonical equal per-component normalization gives the trace-weighted 3:2 coefficient.    CONDITIONAL_PASS   Requires full master-action normalization statement.
 Observed                                                 D-required k_space/k_phase is very close to 1.     DIAGNOSTIC_PASS         D-required k cannot be used to define the law.
 Observed                          A finite k tolerance band surrounds the equal-normalization solution. SUPPORTS_ROBUSTNESS                          Robustness is not derivation.
     Open The master action explicitly fixes the canonical unit metric across spatial and phase sectors.                OPEN             This remains the paper-grade proof target.
 Rejected                                                 R215M proves the full particle mass hierarchy.                  NO No species map, no top/e closure, no prediction suite.
Promotion                                                                              V12.13 promotion.                  NO                                        Not yet earned.

Interpretation:
R215M supports canonical equal per-component normalization as the lead native choice.

The D-required k_space/k_phase is extremely close to unity, so the native k=1 law is not an arbitrary tuning. However, the exact D-optimal k remains diagnostic-only and cannot define the law.

The main remaining proof is to write the master action in canonical dimensionless variables and show that spatial support components and phase-refresh components carry the same unit coefficient in the action ledger.

Ruling:
No V12.13 promotion.

Next recommended run:
R216M — Master-Action Canonical Normalization Patch Attempt

Question:
Can the master action be patched or rewritten with an explicit canonical 3+2 metric:
delta q^T delta q = sum_i dX_i^2 + sum_a dPhi_a^2,
so the equal per-component normalization is not assumed but stated as the canonical action measure?
