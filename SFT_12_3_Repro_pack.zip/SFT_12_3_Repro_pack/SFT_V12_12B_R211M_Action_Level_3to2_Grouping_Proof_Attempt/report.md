
# SFT V12.12B R211M — Action-Level 3:2 Grouping Proof Attempt

Generated: 2026-06-18T03:10:41Z

Verdict:
PARTIAL_PASS_WHERE_HOW_3_TO_2_GROUPING_SUPPORTED_BY_ACTION_PREMISE_AUDIT_UNGROUPED_5_COMPONENT_NULL_FAILS_ENDPOINT_SPINOR_FRAME_BRIDGE_SUPPORTIVE_FULL_ACTION_PROOF_STILL_OPEN_NO_V12_13

Purpose:
R211M tests Opus's WHERE/HOW grouping and the spinor-frame bridge together.

Compact formula:
M_i = G_i * exp(L_eff * u_i)

Opus WHERE/HOW candidate:
WHERE channel = three spatial support dimensions.
HOW channel = two phase closure completions.
Channel ratio = 3:2.

Coefficient:
L_eff = 3pi - 1/2 ln(25/13)

D-required endpoint split:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "two_channel_possible": true,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446,
  "imbalance_required": 0.20165774222211108
}

Opus WHERE/HOW grouped result:
mechanism_id                                       opus_where_how_grouped_3_to_2
mechanism_family                                                  opus_where_how
native_status                     conditional_pass_if_grouping_is_action_derived
uses_D_to_define                                                           False
mechanical_reading             WHERE channel has 3 spatial support dimensions...
grouping_claim                 spatial components form one Green-connected su...
closed_form_tax_hint            tax = 1/2 ln(25/13), L_eff = 3pi - 1/2 ln(25/13)
native_score_prior                                                           9.0
shares_normalized                                                      (0.6,0.4)
p_high                                                                       0.6
p_low                                                                        0.4
imbalance                                                                    0.2
N_eff                                                                   1.923077
amplitude_tax                                                           0.326963
c_ln2                                                                   0.471708
L_eff                                                                   9.097815
endpoint_rho2                                                       17871.488624
endpoint_vs_D_factor                                                     0.99968
endpoint_vs_top_e_factor                                                0.052718
endpoint_log_error_vs_D_abs                                              0.00032
span_max_over_min                                                   17871.488624
rmse_log_vs_D_target                                                    0.718964
rmse_log_vs_top_e_target                                                1.475658
distance_to_required_p_high                                             0.000829
distance_to_equal_split                                                      0.1
distance_to_3_to_2                                                           0.0
combined_score                                                              16.0

Spinor-frame bridge result:
mechanism_id                                 my_spinor_frame_sqrt_4pi_2pi_bridge
mechanism_family                                             spinor_frame_bridge
native_status                  bridge_candidate_if_phase_load_amplitudes_set_...
uses_D_to_define                                                           False
mechanical_reading             amplitude split proportional to sqrt(4π spinor...
grouping_claim                 spinor and frame closure sectors directly set ...
closed_form_tax_hint                        tax = 1/2 ln(N_eff[sqrt4pi:sqrt2pi])
native_score_prior                                                           8.0
shares_normalized                                (0.585786437627,0.414213562373)
p_high                                                                  0.585786
p_low                                                                   0.414214
imbalance                                                               0.171573
N_eff                                                                   1.942809
amplitude_tax                                                           0.332067
c_ln2                                                                   0.479072
L_eff                                                                   9.092711
endpoint_rho2                                                       17780.501218
endpoint_vs_D_factor                                                     0.99459
endpoint_vs_top_e_factor                                                 0.05245
endpoint_log_error_vs_D_abs                                             0.005424
span_max_over_min                                                   17780.501218
rmse_log_vs_D_target                                                    0.716679
rmse_log_vs_top_e_target                                                1.478726
distance_to_required_p_high                                             0.015042
distance_to_equal_split                                                 0.085786
distance_to_3_to_2                                                      0.014214
combined_score                                                              14.0

Ungrouped five-component null result:
mechanism_id                               opus_five_independent_components_null
mechanism_family                                                   grouping_null
native_status                            null_control_against_where_how_grouping
uses_D_to_define                                                           False
mechanical_reading             three spatial and two phase components treated...
grouping_claim                      no grouping; five equal independent channels
closed_form_tax_hint                                               tax = 1/2 ln5
native_score_prior                                                           4.0
shares_normalized                                          (0.2,0.2,0.2,0.2,0.2)
p_high                                                                       0.2
p_low                                                                        0.2
imbalance                                                                    0.0
N_eff                                                                        5.0
amplitude_tax                                                           0.804719
c_ln2                                                                   1.160964
L_eff                                                                   8.620059
endpoint_rho2                                                       11083.426741
endpoint_vs_D_factor                                                    0.619975
endpoint_vs_top_e_factor                                                0.032694
endpoint_log_error_vs_D_abs                                             0.478076
span_max_over_min                                                   11083.426741
rmse_log_vs_D_target                                                    0.550147
rmse_log_vs_top_e_target                                                1.765976
distance_to_required_p_high                                             0.400829
distance_to_equal_split                                                      0.3
distance_to_3_to_2                                                           0.4
combined_score                                                               5.0

Action premise score:
                            candidate  action_premise_score  hard_fail_present           status                                                                                                                                                                                                                                                                                                                                                                       notes
        opus_where_how_grouped_3_to_2                    11              False CONDITIONAL_LIVE                                                                                D_independent_definition:PASS | uses_existing_SFT_counts:PASS_3_SPATIAL_2_PHASE | spatial_connectedness:PASS_IF_GREEN_FIELD_SINGLE | phase_common_orbit:PASS_IF_COMMON_ORBIT_REFRESH | where_how_separation:PASS | amplitude_participation:CONDITIONAL_PASS | action_level_status:NOT_PROVEN
  my_spinor_frame_sqrt_4pi_2pi_bridge                     9              False CONDITIONAL_LIVE                                                                                              D_independent_definition:PASS | uses_existing_SFT_counts:PASS_4PI_2PI | spatial_connectedness:NOT_PRIMARY | phase_common_orbit:PASS_PHASE_SECTOR | where_how_separation:PARTIAL_PHASE_ONLY | amplitude_participation:PASS_AMPLITUDE_WEIGHTING | action_level_status:NOT_PROVEN
              equal_two_channel_sqrt2                     2              False  WEAK_OR_CONTROL                                                                                                                D_independent_definition:PASS | uses_existing_SFT_counts:PARTIAL_BINARY_ONLY | spatial_connectedness:UNSPECIFIED | phase_common_orbit:UNSPECIFIED | where_how_separation:UNSPECIFIED | amplitude_participation:PASS_MINIMAL | action_level_status:NOT_PROVEN
opus_five_independent_components_null                    -3               True  WEAK_OR_CONTROL D_independent_definition:PASS | uses_existing_SFT_counts:PASS_3PLUS2_BUT_NO_GROUPING | spatial_connectedness:FAIL_TREATS_SPACE_AS_THREE_SEPARATE_FIELDS | phase_common_orbit:FAIL_TREATS_PHASES_AS_SEPARATE_UNGROUPED_CHANNELS | where_how_separation:FAIL_NO_WHERE_HOW_GROUPING | amplitude_participation:PASS_AS_CONTROL_BUT_WRONG_GROUPING | action_level_status:CONTROL

Best mechanism summary:
                         mechanism_id       mechanism_family                                          native_status  uses_D_to_define                                                                        mechanical_reading                                                                                       grouping_claim                             closed_form_tax_hint  native_score_prior               shares_normalized   p_high    p_low  imbalance    N_eff  amplitude_tax    c_ln2    L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_vs_top_e_factor  endpoint_log_error_vs_D_abs  span_max_over_min  rmse_log_vs_D_target  rmse_log_vs_top_e_target  distance_to_required_p_high  distance_to_equal_split  distance_to_3_to_2  combined_score
        opus_where_how_grouped_3_to_2         opus_where_how         conditional_pass_if_grouping_is_action_derived             False          WHERE channel has 3 spatial support dimensions; HOW channel has 2 closure phases spatial components form one Green-connected support channel; phase closures form one refresh channel tax = 1/2 ln(25/13), L_eff = 3pi - 1/2 ln(25/13)                 9.0                       (0.6,0.4) 0.600000 0.400000   0.200000 1.923077       0.326963 0.471708 9.097815   17871.488624              0.999680                  0.052718                     0.000320       17871.488624              0.718964                  1.475658                     0.000829                 0.100000            0.000000            16.0
  my_spinor_frame_sqrt_4pi_2pi_bridge    spinor_frame_bridge bridge_candidate_if_phase_load_amplitudes_set_channels             False                        amplitude split proportional to sqrt(4π spinor) and sqrt(2π frame)                                spinor and frame closure sectors directly set amplitude participation             tax = 1/2 ln(N_eff[sqrt4pi:sqrt2pi])                 8.0 (0.585786437627,0.414213562373) 0.585786 0.414214   0.171573 1.942809       0.332067 0.479072 9.092711   17780.501218              0.994590                  0.052450                     0.005424       17780.501218              0.716679                  1.478726                     0.015042                 0.085786            0.014214            14.0
              equal_two_channel_sqrt2         binary_support                         clean_minimal_binary_candidate             False                                                     two equal orthogonal support channels                                                               binary support only, no 3:2 refinement             tax = 1/2 ln2, L_eff = 3pi - 1/2 ln2                 7.5                       (0.5,0.5) 0.500000 0.500000   0.000000 2.000000       0.346574 0.500000 9.078204   17524.436390              0.980267                  0.051695                     0.019930       17524.436390              0.710228                  1.487449                     0.100829                 0.000000            0.100000            12.5
      spinor_frame_4pi_2pi_load_split    spinor_frame_bridge                                   load_split_candidate             False                            support split proportional to 4π spinor load and 2π frame load                                                phase-sector loads set support participation directly                                tax = 1/2 ln(9/5)                 7.0 (0.666666666667,0.333333333333) 0.666667 0.333333   0.333333 1.800000       0.293893 0.423998 9.130885   18472.377901              1.033292                  0.054491                     0.032750       18472.377901              0.733949                  1.455805                     0.065838                 0.166667            0.066667            11.0
               opus_sqrt_count_3_to_2 opus_where_how_control                                amplitude_count_control             False three spatial and two phase sectors combine internally in quadrature before participation                                                        counts enter as square-root sector amplitudes                              tax = 1/2 ln(N_eff)                 6.0 (0.550510257217,0.449489742783) 0.550510 0.449490   0.101021 1.979796       0.341497 0.492676 9.083281   17613.629113              0.985256                  0.051958                     0.014854       17613.629113              0.712479                  1.484396                     0.050319                 0.050510            0.049490             9.0
       three_plus_one_support_tangent         3plus1_control                                         3plus1_control             False                              3 normal/support directions versus 1 tangent/write direction                                                spatial support versus one tangent time/write channel                              tax = 1/2 ln(N_eff)                 5.0                     (0.75,0.25) 0.750000 0.250000   0.500000 1.600000       0.235002 0.339036 9.189776   19592.915518              1.095972                  0.057796                     0.091641       19592.915518              0.761366                  1.420545                     0.149171                 0.250000            0.150000             7.0
          four_equal_channel_full_ln2         binary_control                                    curve_shape_control             False                                      two independent binary splits or four equal channels                                                                              two equal binary splits                              tax = 1/2 ln(N_eff)                 4.0           (0.25,0.25,0.25,0.25) 0.250000 0.250000   0.000000 4.000000       0.693147 1.000000 8.731631   12391.647808              0.693153                  0.036554                     0.366504       12391.647808              0.579575                  1.697676                     0.350829                 0.250000            0.350000             6.0
opus_five_independent_components_null          grouping_null                null_control_against_where_how_grouping             False         three spatial and two phase components treated as five independent equal channels                                                         no grouping; five equal independent channels                                    tax = 1/2 ln5                 4.0           (0.2,0.2,0.2,0.2,0.2) 0.200000 0.200000   0.000000 5.000000       0.804719 1.160964 8.620059   11083.426741              0.619975                  0.032694                     0.478076       11083.426741              0.550147                  1.765976                     0.400829                 0.300000            0.400000             5.0
                 golden_ratio_control                control                                     control_not_native             False                                                                golden ratio split control                                                                                    numerical control                              tax = 1/2 ln(N_eff)                 1.0   (0.61803398875,0.38196601125) 0.618034 0.381966   0.236068 1.894427       0.319458 0.460881 9.105320   18006.118249              1.007211                  0.053115                     0.007185       18006.118249              0.722338                  1.471149                     0.017205                 0.118034            0.018034             5.0
          D_inferred_split_diagnostic        diagnostic_only                                 diagnostic_only_uses_D              True                                                            split inferred from D endpoint                                                                                           not native                              tax = 1/2 ln(N_eff)                -8.0 (0.600828871111,0.399171128889) 0.600829 0.399171   0.201658 1.921846       0.326643 0.471247 9.098135   17877.208690              1.000000                  0.052735                     0.000000       17877.208690              0.719108                  1.475466                     0.000000                 0.100829            0.000829           -13.0

Pairwise focus:
                          mechanism_a                           mechanism_b  delta_endpoint_log_error_abs_a_minus_b  delta_rmse_D_a_minus_b  delta_combined_score_a_minus_b
        opus_where_how_grouped_3_to_2       spinor_frame_4pi_2pi_load_split                               -0.032430               -0.014985                             5.0
  my_spinor_frame_sqrt_4pi_2pi_bridge         opus_where_how_grouped_3_to_2                                0.005104               -0.002285                            -2.0
  my_spinor_frame_sqrt_4pi_2pi_bridge opus_five_independent_components_null                               -0.472652                0.166533                             9.0
  my_spinor_frame_sqrt_4pi_2pi_bridge                opus_sqrt_count_3_to_2                               -0.009429                0.004201                             5.0
  my_spinor_frame_sqrt_4pi_2pi_bridge       spinor_frame_4pi_2pi_load_split                               -0.027326               -0.017270                             3.0
              equal_two_channel_sqrt2         opus_where_how_grouped_3_to_2                                0.019610               -0.008737                            -3.5
              equal_two_channel_sqrt2   my_spinor_frame_sqrt_4pi_2pi_bridge                                0.014506               -0.006452                            -1.5
              equal_two_channel_sqrt2 opus_five_independent_components_null                               -0.458145                0.160081                             7.5
              equal_two_channel_sqrt2                opus_sqrt_count_3_to_2                                0.005077               -0.002251                             3.5
              equal_two_channel_sqrt2       spinor_frame_4pi_2pi_load_split                               -0.012820               -0.023722                             1.5
opus_five_independent_components_null         opus_where_how_grouped_3_to_2                                0.477756               -0.168818                           -11.0
opus_five_independent_components_null                opus_sqrt_count_3_to_2                                0.463222               -0.162332                            -4.0
opus_five_independent_components_null       spinor_frame_4pi_2pi_load_split                                0.445326               -0.183803                            -6.0
               opus_sqrt_count_3_to_2         opus_where_how_grouped_3_to_2                                0.014534               -0.006486                            -7.0
               opus_sqrt_count_3_to_2       spinor_frame_4pi_2pi_load_split                               -0.017896               -0.021471                            -2.0

Gate matrix:
                         gate                                                                              test                 status                                                                boundary
              compact_formula                                                          M_i = G_i exp(L_eff u_i)              PRESERVED                              D-scale lane only, not full mass spectrum.
      opus_where_how_grouping Three spatial support dimensions group as WHERE; two phase closures group as HOW.       CONDITIONAL_PASS Requires master-action proof that these are the two amplitude channels.
ungrouped_five_component_null                          Treat 3+2 components as five equal independent channels. FAILS_ENDPOINT_SHARPLY                Supports grouping necessity but does not prove grouping.
          spinor_frame_bridge                                                sqrt(4π):sqrt(2π) amplitude split.      SUPPORTIVE_BRIDGE                             Close to D but not as exact as grouped 3:2.
           action_level_proof                                Does R211 prove the grouping from the full action?                NOT_YET                         R211 is a proof-attempt audit, not final proof.
                        top_e                                                                    Top/e closure.                   OPEN                                               No top/e closure claimed.
                       V12_13                                                                        Promotion.                     NO        Requires action-level grouping proof plus prediction/null tests.

Claim boundary:
 category                                                                             claim            status                                                 boundary
Preserved                             The compact D-scale lane is M_i = G_i exp(L_eff u_i).         PRESERVED                                       D-scale lane only.
Preserved                         Opus WHERE/HOW grouping gives L_eff = 3π - 1/2 ln(25/13).  CONDITIONAL_PASS              Grouping must still be derived from action.
 Observed Ungrouped five-channel interpretation fails the endpoint compared to grouped 3:2. SUPPORTS_GROUPING                Failure of null is not proof of grouping.
 Observed        Spinor-frame sqrt(4π):sqrt(2π) supports the same coefficient neighborhood. SUPPORTIVE_BRIDGE                                     Not as exact as 3:2.
 Rejected                                                  R211M proves the mass hierarchy.                NO No species map, no top/e closure, no final action proof.
Promotion                                                                 V12.13 promotion.                NO                                          Not yet earned.

Interpretation:
R211M supports Opus's grouping, but does not yet complete the action-level proof.

The key positive result is that the 3 spatial : 2 phase decomposition is D-independent and gives the near-exact coefficient:

L_eff = 3pi - 1/2 ln(25/13)

The key null result is that treating the same five components as five independent equal channels fails the endpoint sharply. Therefore the issue is not the count alone; the issue is the grouping into two amplitude channels.

The spinor-frame sqrt(4pi):sqrt(2pi) bridge remains supportive because it lands in the same coefficient neighborhood and uses closure-sector amplitudes rather than D.

Ruling:
No V12.13 promotion.

Next recommended run:
R212M — Separable Action Functional Derivation Attempt

Question:
Can the master action be written or approximated as a separable spatial-support functional times a phase-refresh functional, forcing exactly two amplitude channels with 3:2 weights?
