#!/usr/bin/env python3
"""
SFT V12.12B R206M — Native Area-Write Dilution Law Derivation Attempt

Purpose:
    Test whether the rule "each phase rotation adds one boundary area"
    can produce a local capacity-dilution / feedback load near the
    half-action scale found in R203/R205.

Core question:
    Can a native area-write balance generate an effective exponential
    feedback load near 3π without using particle masses, species labels,
    or fitting to D/top-e targets?

Outputs:
    SFT_V12_12B_R206M_Native_Area_Write_Dilution_Law_Derivation_Attempt/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R206M.py

    SFT_V12_12B_R206M_Native_Area_Write_Dilution_Law_Derivation_Attempt_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R206M_Native_Area_Write_Dilution_Law_Derivation_Attempt"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi
HALF_K_REQ = K_REQ / 2.0
LN2 = math.log(2.0)

RHO0 = 0.5
RHO_SPAN = 4.0

SEED_MODES = [
    Fraction(1, 2),
    Fraction(2, 3),
    Fraction(3, 4),
    Fraction(1, 1),
    Fraction(5, 4),
    Fraction(4, 3),
    Fraction(3, 2),
    Fraction(5, 3),
    Fraction(2, 1),
]

D_PERP = 3


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def frac_str(f: Fraction) -> str:
    if f.denominator == 1:
        return str(f.numerator)
    return f"{f.numerator}/{f.denominator}"


def balanced_occupancy(m: int, n: int) -> list[int]:
    active = min(max(n, 1), D_PERP)
    q, r = divmod(m, active)
    occ = [q + 1 if i < r else q for i in range(active)]
    occ += [0] * (D_PERP - len(occ))
    occ.sort(reverse=True)
    return occ


def shape_stats(occ: list[int]) -> dict:
    total = sum(occ)
    probs = [x / total for x in occ] if total else [0.0, 0.0, 0.0]

    l2 = math.sqrt(sum(p * p for p in probs))
    iso = 1.0 / D_PERP

    eccentricity = 0.0
    if total:
        eccentricity = math.sqrt(sum((p - iso) ** 2 for p in probs)) / math.sqrt(2.0 / 3.0)

    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    entropy_norm = entropy / math.log(D_PERP)
    entropy_deficit = 1.0 - entropy_norm

    active_slots = sum(1 for x in occ if x > 0)
    max_occ = max(occ) if occ else 0
    slot_fill_fraction = active_slots / D_PERP

    return {
        "shape_l2_norm": l2,
        "eccentricity_norm": eccentricity,
        "entropy_norm": entropy_norm,
        "entropy_deficit": entropy_deficit,
        "active_slots": active_slots,
        "max_occ": max_occ,
        "slot_fill_fraction": slot_fill_fraction,
    }


def build_modes() -> pd.DataFrame:
    rows = []

    for rho in SEED_MODES:
        m = rho.numerator
        n = rho.denominator
        occ = balanced_occupancy(m, n)
        stats = shape_stats(occ)

        rows.append({
            "rho": frac_str(rho),
            "rho_float": float(rho),
            "m": m,
            "N": n,
            "occupancy_vector": "(" + ",".join(str(x) for x in occ) + ")",
            "occ0": occ[0],
            "occ1": occ[1],
            "occ2": occ[2],
            "active_slots": stats["active_slots"],
            "max_occ": stats["max_occ"],
            "slot_fill_fraction": stats["slot_fill_fraction"],
            "shape_l2_norm": stats["shape_l2_norm"],
            "eccentricity_norm": stats["eccentricity_norm"],
            "entropy_norm": stats["entropy_norm"],
            "entropy_deficit": stats["entropy_deficit"],
            "u_logrho": math.log(float(rho) / RHO0) / math.log(RHO_SPAN),
        })

    return pd.DataFrame(rows).sort_values("rho_float").reset_index(drop=True)


def fibonacci_sphere(n: int = 300) -> np.ndarray:
    pts = []
    phi = math.pi * (3.0 - math.sqrt(5.0))

    for i in range(n):
        y = 1.0 - (i / float(n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - y * y))
        theta = phi * i
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        pts.append([x, y, z])

    return np.array(pts, dtype=float)


SPHERE_POINTS = fibonacci_sphere(300)
RHAT = SPHERE_POINTS.copy()


def ring_basis(axis_index: int) -> tuple[np.ndarray, np.ndarray]:
    if axis_index == 0:
        return np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])
    if axis_index == 1:
        return np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])
    return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])


def source_points_ring(
    occ: list[int],
    ring_radius: float = 0.55,
    n_per_ring: int = 36,
) -> tuple[np.ndarray, np.ndarray]:
    positions = []
    weights = []

    for axis_index, weight in enumerate(occ):
        if weight <= 0:
            continue

        e1, e2 = ring_basis(axis_index)

        for j in range(n_per_ring):
            t = 2.0 * math.pi * j / n_per_ring
            point = ring_radius * (math.cos(t) * e1 + math.sin(t) * e2)
            positions.append(point)
            weights.append(weight / n_per_ring)

    return np.array(positions, dtype=float), np.array(weights, dtype=float)


def eval_ring_geometry(
    occ: list[int],
    softening: float = 0.12,
    ring_radius: float = 0.55,
) -> dict:
    pos, weights = source_points_ring(occ, ring_radius=ring_radius)

    potentials = []
    grad_mags = []
    abs_radial_curvatures = []

    for x, rh in zip(SPHERE_POINTS, RHAT):
        d = x[None, :] - pos
        d2 = np.sum(d * d, axis=1) + softening ** 2
        R = np.sqrt(d2)

        potential = np.sum(weights / R)

        grad = np.sum((-weights[:, None] * d) / (R[:, None] ** 3), axis=0)
        grad_mag = np.linalg.norm(grad)

        rd = d @ rh
        hess_radial = np.sum(weights * (-1.0 / (R ** 3) + 3.0 * (rd ** 2) / (R ** 5)))

        potentials.append(float(potential))
        grad_mags.append(float(grad_mag))
        abs_radial_curvatures.append(abs(float(hess_radial)))

    return {
        "mean_potential": float(np.mean(potentials)),
        "mean_gradient_magnitude": float(np.mean(grad_mags)),
        "mean_abs_radial_curvature": float(np.mean(abs_radial_curvatures)),
        "p95_abs_radial_curvature": float(np.quantile(abs_radial_curvatures, 0.95)),
    }


def add_geometry_signal(modes: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in modes.iterrows():
        occ = [int(row["occ0"]), int(row["occ1"]), int(row["occ2"])]
        obs = eval_ring_geometry(occ)

        rec = row.to_dict()
        rec.update(obs)
        rows.append(rec)

    df = pd.DataFrame(rows)

    for col in [
        "mean_potential",
        "mean_gradient_magnitude",
        "mean_abs_radial_curvature",
        "p95_abs_radial_curvature",
    ]:
        base = df.loc[df["rho"] == "1/2", col].iloc[0]
        df[col + "_ratio_to_rho_half"] = df[col] / base

    df["G_i_geometry_ratio"] = df["mean_abs_radial_curvature_ratio_to_rho_half"]
    return df


def target_power_exponent(target_span: float) -> float:
    return math.log(target_span) / math.log(RHO_SPAN)


P_D = target_power_exponent(D_TARGET)
P_TOP = target_power_exponent(TOP_E_TARGET)
P_HALF_6PI = (SIX_PI / 2.0) / math.log(RHO_SPAN)
P_HALF_KREQ = (K_REQ / 2.0) / math.log(RHO_SPAN)


def add_targets(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    out["target_D_rhopower"] = (out["rho_float"] / RHO0) ** P_D
    out["target_top_e_rhopower"] = (out["rho_float"] / RHO0) ** P_TOP
    out["target_half_6pi_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_6PI
    out["target_half_Kreq_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_KREQ

    return out


def native_area_write_candidates(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in df.iterrows():
        rho_float = float(row["rho_float"])
        u = float(row["u_logrho"])
        m = int(row["m"])
        n = int(row["N"])
        active_slots = int(row["active_slots"])
        max_occ = int(row["max_occ"])
        eccentricity = float(row["eccentricity_norm"])
        entropy_deficit = float(row["entropy_deficit"])
        slot_fill_fraction = float(row["slot_fill_fraction"])
        G = float(row["G_i_geometry_ratio"])

        compactness_u = u
        area_write_u = u
        area_write_sqrt_u = math.sqrt(max(u, 0.0))
        support_pressure = u * (1.0 + entropy_deficit)
        slot_pressure = u * (1.0 + slot_fill_fraction)
        concentration_pressure = u * (1.0 + eccentricity)
        max_occ_pressure = u * max_occ
        m_over_n_pressure = u * rho_float
        active_slot_pressure = u * active_slots / D_PERP

        candidate_coordinates = [
            ("u_logrho", compactness_u, "u = log(rho/rho0)/log4"),
            ("area_write_u", area_write_u, "same as u; one normalized area-write compression coordinate"),
            ("area_write_sqrt_u", area_write_sqrt_u, "sqrt(u), slower-start capacity coordinate"),
            ("support_pressure", support_pressure, "u * (1 + entropy_deficit)"),
            ("slot_pressure", slot_pressure, "u * (1 + active_slots/3)"),
            ("concentration_pressure", concentration_pressure, "u * (1 + eccentricity_norm)"),
            ("max_occ_pressure", max_occ_pressure, "u * max_occupancy"),
            ("rho_pressure", m_over_n_pressure, "u * rho"),
            ("active_slot_pressure", active_slot_pressure, "u * active_slots/3"),
        ]

        native_load_constants = [
            ("two_pi", TWO_PI, "2pi phase-holonomy load"),
            ("three_pi", THREE_PI, "half-action load"),
            ("four_pi", FOUR_PI, "spinor curvature-crossing load"),
            ("six_pi", SIX_PI, "full 4pi+2pi additive support load"),
            ("Kreq_half", HALF_K_REQ, "half of K_req diagnostic"),
            ("three_pi_minus_ln2_over2", THREE_PI - 0.5 * LN2, "3pi minus half ln2 correction"),
            ("three_pi_minus_ln2", THREE_PI - LN2, "3pi minus ln2 correction"),
        ]

        for coord_name, coord_value, coord_formula in candidate_coordinates:
            for load_name, load_value, load_note in native_load_constants:
                feedback_factor = math.exp(load_value * coord_value)
                model_ratio = G * feedback_factor

                rows.append({
                    "rho": row["rho"],
                    "rho_float": rho_float,
                    "m": m,
                    "N": n,
                    "occupancy_vector": row["occupancy_vector"],
                    "G_i_geometry_ratio": G,
                    "u_logrho": u,
                    "coord_name": coord_name,
                    "coord_value": coord_value,
                    "coord_formula": coord_formula,
                    "load_name": load_name,
                    "load_value": load_value,
                    "load_note": load_note,
                    "model_ratio_to_rho_half": model_ratio,
                    "target_D_rhopower": row["target_D_rhopower"],
                    "target_top_e_rhopower": row["target_top_e_rhopower"],
                    "residual_log_vs_D": math.log(model_ratio / row["target_D_rhopower"]) if model_ratio > 0 else np.nan,
                    "residual_log_vs_top_e": math.log(model_ratio / row["target_top_e_rhopower"]) if model_ratio > 0 else np.nan,
                    "endpoint_context": "diagnostic_only_not_a_fit",
                })

    return pd.DataFrame(rows)


def summarize_area_write_candidates(candidates: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for (coord_name, load_name), grp in candidates.groupby(["coord_name", "load_name"]):
        ordered = grp.sort_values("rho_float")
        endpoint = float(ordered["model_ratio_to_rho_half"].iloc[-1])
        span = float(ordered["model_ratio_to_rho_half"].max() / ordered["model_ratio_to_rho_half"].min())

        rmse_D = float(np.sqrt(np.nanmean(ordered["residual_log_vs_D"] ** 2)))
        rmse_top = float(np.sqrt(np.nanmean(ordered["residual_log_vs_top_e"] ** 2)))

        rows.append({
            "coord_name": coord_name,
            "load_name": load_name,
            "endpoint_rho2": endpoint,
            "span_max_over_min": span,
            "rmse_log_vs_D_target": rmse_D,
            "rmse_log_vs_top_e_target": rmse_top,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
        })

    return pd.DataFrame(rows).sort_values("rmse_log_vs_D_target")


def required_native_loads(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    targets = [
        ("D_rhopower", "target_D_rhopower"),
        ("top_e_rhopower", "target_top_e_rhopower"),
        ("half_6pi_rhopower", "target_half_6pi_rhopower"),
        ("half_Kreq_rhopower", "target_half_Kreq_rhopower"),
    ]

    coords = [
        ("u_logrho", lambda r: float(r["u_logrho"])),
        ("support_pressure", lambda r: float(r["u_logrho"]) * (1.0 + float(r["entropy_deficit"]))),
        ("slot_pressure", lambda r: float(r["u_logrho"]) * (1.0 + float(r["slot_fill_fraction"]))),
        ("concentration_pressure", lambda r: float(r["u_logrho"]) * (1.0 + float(r["eccentricity_norm"]))),
    ]

    for _, row in df.iterrows():
        G = float(row["G_i_geometry_ratio"])

        for coord_name, coord_fn in coords:
            x = coord_fn(row)

            for target_name, target_col in targets:
                target = float(row[target_col])

                if abs(x) < 1e-12:
                    L_required = np.nan
                else:
                    L_required = math.log(target / G) / x

                rows.append({
                    "rho": row["rho"],
                    "rho_float": row["rho_float"],
                    "m": int(row["m"]),
                    "N": int(row["N"]),
                    "G_i_geometry_ratio": G,
                    "coord_name": coord_name,
                    "coord_value": x,
                    "target_name": target_name,
                    "target_ratio": target,
                    "L_required": L_required,
                    "L_required_minus_3pi": L_required - THREE_PI if not np.isnan(L_required) else np.nan,
                    "L_required_minus_Kreq_half": L_required - HALF_K_REQ if not np.isnan(L_required) else np.nan,
                    "L_required_minus_three_pi_minus_ln2_over2": L_required - (THREE_PI - 0.5 * LN2) if not np.isnan(L_required) else np.nan,
                    "L_required_minus_three_pi_minus_ln2": L_required - (THREE_PI - LN2) if not np.isnan(L_required) else np.nan,
                })

    return pd.DataFrame(rows)


def summarize_required_native_loads(required: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for (coord_name, target_name), grp in required.dropna(subset=["L_required"]).groupby(["coord_name", "target_name"]):
        ordered = grp.sort_values("rho_float")
        vals = ordered["L_required"].to_numpy(float)

        rows.append({
            "coord_name": coord_name,
            "target_name": target_name,
            "mean_L_required": float(np.mean(vals)),
            "std_L_required": float(np.std(vals)),
            "cv_L_required": float(np.std(vals) / abs(np.mean(vals))) if np.mean(vals) else np.nan,
            "endpoint_L_required_rho2": float(ordered["L_required"].iloc[-1]),
            "endpoint_minus_3pi": float(ordered["L_required"].iloc[-1] - THREE_PI),
            "endpoint_minus_Kreq_half": float(ordered["L_required"].iloc[-1] - HALF_K_REQ),
            "endpoint_minus_three_pi_minus_ln2_over2": float(ordered["L_required"].iloc[-1] - (THREE_PI - 0.5 * LN2)),
            "endpoint_minus_three_pi_minus_ln2": float(ordered["L_required"].iloc[-1] - (THREE_PI - LN2)),
        })

    return pd.DataFrame(rows).sort_values(["target_name", "cv_L_required"])


def area_write_gate_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "gate": "area_write_rule",
            "test": "Use one boundary-area write per phase rotation as source of local dilution coordinate.",
            "status": "FORMALIZED_TOY",
            "boundary": "Coordinate choices tested; none are action-derived yet."
        },
        {
            "gate": "native_load_constants",
            "test": "Test 2pi, 3pi, 4pi, 6pi, Kreq/2, and simple ln2-corrected half-action loads.",
            "status": "EXECUTED",
            "boundary": "D/top targets used only for diagnostics."
        },
        {
            "gate": "half_action_nearness",
            "test": "Does the best non-fitted area-write lane land near D-scale?",
            "status": "CANDIDATE",
            "boundary": "Nearness is not derivation."
        },
        {
            "gate": "ln2_correction",
            "test": "Check whether missing D endpoint load is closer to 3pi - ln2/2 or 3pi - ln2.",
            "status": "DIAGNOSTIC",
            "boundary": "A correction needs mechanical origin before promotion."
        },
        {
            "gate": "top_e",
            "test": "Check full top/e context.",
            "status": "OPEN",
            "boundary": "Top/e still needs additional structure."
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need native derivation of coordinate and load coefficient."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "Area-write dilution is a viable native candidate for Gamma_settle.",
            "status": "CANDIDATE",
            "boundary": "Not yet derived from the master action."
        },
        {
            "category": "Preserved",
            "claim": "Half-action-scale feedback remains the leading D-scale lane.",
            "status": "CANDIDATE",
            "boundary": "Diagnostic target only."
        },
        {
            "category": "Observed",
            "claim": "The D endpoint required load is near 3pi and also near simple ln2-corrected variants.",
            "status": "DIAGNOSTIC",
            "boundary": "Correction term is not promoted."
        },
        {
            "category": "Rejected",
            "claim": "R206M derives the particle mass hierarchy.",
            "status": "NO",
            "boundary": "No species map and no native coefficient proof."
        },
        {
            "category": "Rejected",
            "claim": "R206M solves top/e.",
            "status": "NO",
            "boundary": "Top/e needs another layer."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def build_report(
    created_utc: str,
    verdict: str,
    geometry_endpoint: float,
    best_candidates: pd.DataFrame,
    required_summary: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R206M — Native Area-Write Dilution Law Derivation Attempt

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R206M tests whether the rule "each phase rotation adds one boundary area"
can produce a local capacity-dilution feedback law near the half-action scale.

This is not a mass derivation. It is a mechanism gate.

Core proposal:
Gamma_settle is the local boundary-capacity dilution generated by the particle's own writes.

Per-cycle form:
dS_i/dt = nu_i dS_i/dn
dS_i/dn = R_i(S_i) - B_i(S_i)

R_i is local self-reinforcement.
B_i is local boundary-capacity dilution.

If both terms are per-cycle and both are multiplied by nu_i, tick rate cancels in the equilibrium condition:
R_i(S_i) = B_i(S_i)

R206M tests candidate area-write coordinates and native load constants.

Key constants:
D target context       = {D_TARGET}
top/e target context   = {TOP_E_TARGET}
2pi                    = {TWO_PI}
3pi                    = {THREE_PI}
4pi                    = {FOUR_PI}
6pi                    = {SIX_PI}
K_req / 2              = {HALF_K_REQ}
3pi - ln2/2            = {THREE_PI - 0.5 * LN2}
3pi - ln2              = {THREE_PI - LN2}
R202-like G(rho=2)     = {geometry_endpoint}

Best candidate area-write lanes by D diagnostic:
{best_candidates.to_string(index=False)}

Required native load summary:
{required_summary.to_string(index=False)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
R206M should be judged by whether a simple native area-write coordinate and a non-fitted load constant land near the D-scale diagnostic.

A near hit is not a derivation.
A native derivation still requires deriving the coordinate and coefficient from the master action and no-overwrite area accounting.

Ruling:
No V12.13 promotion.

Next recommended run:
R207M — Area-Write Coefficient Origin Audit

Question:
Can the correction between the D-required endpoint load and 3pi be explained by binary branching, sqrt2 amplitude degeneracy, or one-area dilution geometry without using D as input?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    modes = build_modes()
    geometry = add_geometry_signal(modes)
    target_geometry = add_targets(geometry)

    candidates = native_area_write_candidates(target_geometry)
    candidate_summary = summarize_area_write_candidates(candidates)

    required = required_native_loads(target_geometry)
    required_summary = summarize_required_native_loads(required)

    gates = area_write_gate_matrix()
    claims = claim_boundary()

    geometry_endpoint = float(geometry.sort_values("rho_float").iloc[-1]["G_i_geometry_ratio"])

    best_candidates = candidate_summary.head(12).copy()

    verdict = (
        "PARTIAL_PASS_AREA_WRITE_DILUTION_COORDINATES_TESTED_"
        "HALF_ACTION_AND_LN2_CORRECTED_LOADS_REMAIN_LIVE_"
        "NATIVE_COEFFICIENT_NOT_DERIVED_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "two_pi": TWO_PI,
            "three_pi": THREE_PI,
            "four_pi": FOUR_PI,
            "six_pi": SIX_PI,
            "K_req_half": HALF_K_REQ,
            "three_pi_minus_ln2_over2": THREE_PI - 0.5 * LN2,
            "three_pi_minus_ln2": THREE_PI - LN2,
            "p_D": P_D,
            "p_top": P_TOP,
            "p_half_6pi": P_HALF_6PI,
            "p_half_Kreq": P_HALF_KREQ,
        },
        "geometry_endpoint": {
            "rho2_G_i_geometry_ratio": geometry_endpoint
        },
        "best_area_write_candidates_by_D_rmse": best_candidates.to_dict(orient="records"),
        "required_native_load_summary": required_summary.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R207M - Area-Write Coefficient Origin Audit",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R206M_area_write_candidate_summary.csv",
            "tables/R206M_required_native_load_summary.csv",
            "Any traceback if the run failed."
        ],
    }

    modes.to_csv(tables / "R206M_mode_geometry_inputs.csv", index=False)
    geometry.to_csv(tables / "R206M_geometry_signal.csv", index=False)
    candidates.to_csv(tables / "R206M_area_write_candidate_outputs.csv", index=False)
    candidate_summary.to_csv(tables / "R206M_area_write_candidate_summary.csv", index=False)
    required.to_csv(tables / "R206M_required_native_loads_by_mode.csv", index=False)
    required_summary.to_csv(tables / "R206M_required_native_load_summary.csv", index=False)
    gates.to_csv(tables / "R206M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R206M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        geometry_endpoint=geometry_endpoint,
        best_candidates=best_candidates,
        required_summary=required_summary,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(final_payload, indent=2))


if __name__ == "__main__":
    main()
