
# SFT V12.12B R208M — Binary/Sqrt2 Amplitude Degeneracy Mechanism Test

Generated: 2026-06-18T02:22:36Z

Verdict:
PARTIAL_PASS_SQRT2_TAX_CONDITIONALLY_DERIVED_FROM_EQUAL_TWO_CHANNEL_AMPLITUDE_ACCOUNTING_D_ENDPOINT_COMPATIBLE_TWO_CHANNEL_PREMISE_NOT_YET_ACTION_DERIVED_NO_V12_13

Purpose:
R208M tests whether the sqrt2 correction can be derived from two-channel area-write amplitude accounting.

Core derivation:
For two orthogonal channels with shares p and 1-p:

N_eff = 1 / (p^2 + (1-p)^2)

tax = 1/2 ln(N_eff)

For p = 1/2:

N_eff = 2
tax = 1/2 ln2 = ln(sqrt2)

Therefore:

L_eff = 3pi - 1/2 ln2

This derives the sqrt2 tax conditionally.
It does not prove the two-channel premise.

Key constants:
D target context        = 17877.208689571427
top/e target context    = 339000.0
3pi                     = 9.42477796076938
ln2                     = 0.6931471805599453
1/2 ln2                 = 0.34657359027997264
3pi - 1/2 ln2           = 9.078204370489408
sqrt2                   = 1.4142135623730951

Mechanism summary:
                   mechanism_id mechanism_family                                           mechanical_reading                                       native_status  mode_dependent  mean_N_eff  mean_amplitude_tax  mean_c_ln2  mean_L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_vs_top_e_factor  endpoint_log_error_vs_D  span_max_over_min  rmse_log_vs_D_target  rmse_log_vs_top_e_target
equal_four_channel_full_ln2_tax binary_amplitude   two independent equal binary splits or four equal channels                           candidate_for_curve_shape           False    4.000000            0.693147    1.000000    8.731631   12391.647808              0.693153                  0.036554                -0.366504       12391.647808              0.579575                  1.697676
        equal_three_channel_tax    multi_channel                                         three equal channels                                             control           False    3.000000            0.549306    0.792481    8.875472   14308.642395              0.800385                  0.042208                -0.222663       14308.642395              0.627586                  1.610035
   mode_active_slot_equal_split   mode_occupancy       active slots treated as equal amplitude-write branches                            mode_dependent_candidate            True    2.111111            0.321152    0.463325    9.103626   24783.295616              1.386307                  0.073107                 0.326643       24783.295616              0.633764                  1.435989
    equal_two_channel_sqrt2_tax binary_amplitude one write distributed equally across two orthogonal channels conditional_derivation_if_two_channel_premise_holds           False    2.000000            0.346574    0.500000    9.078204   17524.436390              0.980267                  0.051695                -0.019930       17524.436390              0.710228                  1.487449
        sixty_forty_two_channel binary_amplitude                  slightly imbalanced two-channel write split                       diagnostic_control_not_fitted           False    1.923077            0.326963    0.471708    9.097815   17871.488624              0.999680                  0.052718                -0.000320       17871.488624              0.718964                  1.475658
   mode_top_two_occupancy_split   mode_occupancy                          two largest occupancy channels only                            mode_dependent_candidate            True    1.622222            0.219342    0.316444    9.205436   24783.295616              1.386307                  0.073107                 0.326643       24783.295616              0.720015                  1.379983
    mode_dominant_vs_rest_split   mode_occupancy          dominant occupancy channel versus remaining support                            mode_dependent_candidate            True    1.605128            0.214984    0.310157    9.209793   24783.295616              1.386307                  0.073107                 0.326643       24783.295616              0.721877                  1.380602
     seventy_thirty_two_channel binary_amplitude                  strongly imbalanced two-channel write split                                             control           False    1.724138            0.272364    0.392938    9.152414   18874.395623              1.055780                  0.055677                 0.054280       18874.395623              0.743868                  1.442900
           no_split_half_action          control              pure half-action feedback with no amplitude tax                                             control           False    1.000000            0.000000    0.000000    9.424778   24783.295616              1.386307                  0.073107                 0.326643       24783.295616              0.878440                  1.281258

Required channel inference:
       target_name  mean_c_required  std_c_required  endpoint_c_required_rho2  endpoint_N_eff_required  endpoint_two_channel_possible  endpoint_p_high_required  endpoint_p_low_required  endpoint_imbalance_required  endpoint_distance_to_equal_sqrt2  endpoint_distance_to_full_binary
        D_rhopower         2.248638        1.698617                  0.471247                 1.921846                           True                  0.600829                 0.399171                     0.201658                          0.028753                      5.287534e-01
half_Kreq_rhopower         2.747792        1.698617                  0.970401                 3.839190                          False                       NaN                      NaN                          NaN                          0.470401                      2.959904e-02
 half_6pi_rhopower         2.777391        1.698617                  1.000000                 4.000000                          False                       NaN                      NaN                          NaN                          0.500000                      2.220446e-16
    top_e_rhopower        -1.996454        1.698617                 -3.773845                 0.005345                          False                       NaN                      NaN                          NaN                          4.273845                      4.773845e+00

Random split null summary:
{
  "random_split_count": 2500,
  "best_random_endpoint": {
    "sample_id": 430.0,
    "p": 0.6008812485814792,
    "p_high": 0.6008812485814792,
    "p_low": 0.3991187514185208,
    "N_eff": 1.9217684477412489,
    "amplitude_tax": 0.3266229143250496,
    "c_ln2": 0.4712172587374498,
    "L_eff": 9.09815504644433,
    "endpoint_rho2": 17877.57167250219,
    "endpoint_vs_D_factor": 1.0000203042285327,
    "endpoint_log_error_vs_D": 2.0304022404661314e-05,
    "rmse_log_vs_D_target": 0.719116931963065,
    "rmse_log_vs_top_e_target": 1.4754538343962167
  },
  "median_endpoint_log_error_vs_D": 0.09166868724812527,
  "p05_endpoint_log_error_vs_D": 0.005288126038395817,
  "p95_endpoint_log_error_vs_D": 0.3007241854733825,
  "equal_two_channel_c_ln2": 0.5,
  "fraction_random_with_endpoint_error_better_than_equal_split": 0.2944
}

Gate matrix:
                 gate                                                                              test           status                                                          boundary
 sqrt2_tax_derivation                Does equal two-channel amplitude accounting produce tax = 1/2 ln2? CONDITIONAL_PASS Requires proving the two support channels are real in the action.
           D_endpoint Does the two-channel sqrt2 tax land near the D endpoint without using D as input?  PASS_DIAGNOSTIC          D used only after the prediction as a diagnostic target.
       required_split                                Infer two-channel split implied by the D endpoint.       DIAGNOSTIC                  Inference uses D and cannot count as derivation.
mode_dependent_splits                    Do occupancy-derived split taxes naturally improve the result?           TESTED   Mode-dependent variants are not promoted unless action-derived.
    random_split_null                                 Compare equal split to random two-channel splits.          CONTROL                               Random closeness is not derivation.
               V12_13                                                                        Promotion.               NO      Need native support-channel derivation and prediction nulls.

Claim boundary:
 category                                                           claim           status                                                      boundary
Preserved Equal two-channel amplitude accounting derives tax = ln(sqrt2). CONDITIONAL_PASS           Only if the two-channel support premise is derived.
Preserved      The D endpoint remains strongly compatible with sqrt2 tax.  DIAGNOSTIC_PASS                              Compatibility is not derivation.
 Observed           D-required split is close to equal two-channel split.       DIAGNOSTIC                                 Uses D, therefore not native.
 Rejected                                R208M proves the mass hierarchy.               NO No species map, no top/e closure, no final action derivation.
 Rejected                    R208M proves the two support channels exist.               NO   It derives the consequence of the premise, not the premise.
Promotion                                               V12.13 promotion.               NO                                               Not yet earned.

Interpretation:
R208M conditionally derives the sqrt2 tax from equal two-channel amplitude participation.

This is a mechanism success only if the two channels are later derived from the master action, spinor support, frame holonomy, or boundary write bookkeeping.

The strongest safe statement is:
If a closed-particle write is split across two equal orthogonal support channels, the feedback load is reduced by ln(sqrt2), giving:

L_eff = 3pi - 1/2 ln2

This matches the D-scale endpoint very closely, but D was not used to derive the tax.

Ruling:
No V12.13 promotion.

Next recommended run:
R209M — Two-Channel Support Origin Gate

Question:
Can the two orthogonal support channels be derived from the 4pi spinor closure, frame/gauge holonomy, or no-overwrite boundary write accounting?
