#!/usr/bin/env python3
"""
SFT V12.12B R221M — Top-Sector Activation Criterion Hunt

Purpose:
    R220M strengthened the top/e lane by deriving

        K_top = 4π + 2π = 6π

    as a formal full-closure candidate without using top/e.

    But R220M left the key open proof:

        Why exactly one extra full 6π closure/load layer?

    R221M tests candidate activation criteria:

        1. zero extra layers
        2. one extra full 6π layer
        3. two extra full 6π layers
        4. taxed one-extra layer
        5. legacy K_req bridge
        6. exact top/e gap diagnostic

Core hypothesis:
    The frozen D-scale law is an internal trace-variational compounding lane:

        M_i = G_i exp[(3π - 1/2 ln(25/13)) u_i]

    The top-sector endpoint may require a terminal external completion load:

        K_top = 4π + 2π = 6π

    The activation criterion is:

        At the saturated endpoint of the D-scale trace lane, the least additional
        no-overwrite completion that closes both real support sectors is exactly
        one full untaxed closure cycle: 4π spinor/spatial curvature closure plus
        2π frame/gauge phase closure.

    This rule must be tested against nulls:
        - zero extra layer undercloses
        - two layers overcloses/duplicates the terminal write
        - taxed layer wrongly reuses D-scale branch participation tax
        - exact top/e gap is diagnostic-only

Rules:
    - no species labels
    - no empirical particle mass fitting
    - top/e is diagnostic context only
    - exact top/e gap cannot define the law
    - no V12.13 promotion

Outputs:
    SFT_V12_12B_R221M_Top_Sector_Activation_Criterion_Hunt/
        report.md
        activation_criterion_note.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R221M.py

    SFT_V12_12B_R221M_Top_Sector_Activation_Criterion_Hunt_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R221M_Top_Sector_Activation_Criterion_Hunt"

# Diagnostic contexts from R218-R220.
D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF_FREEZE = 25.0 / 13.0
AMPLITUDE_TAX_FREEZE = 0.5 * math.log(N_EFF_FREEZE)
L_EFF_FREEZE = THREE_PI - AMPLITUDE_TAX_FREEZE
G_ENDPOINT_RHO2 = 2.0
D_SCALE_ENDPOINT = G_ENDPOINT_RHO2 * math.exp(L_EFF_FREEZE)

TOP_GAP_EXACT = TOP_E_TARGET / D_SCALE_ENDPOINT
TOP_GAP_LOG = math.log(TOP_GAP_EXACT)

SQRT2_HALF_ACTION_K_DIAGNOSTIC = 2.0 * (math.log(D_TARGET) - 0.5 * LN2)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def top_prediction(multiplier: float) -> dict:
    predicted = D_SCALE_ENDPOINT * multiplier
    factor = predicted / TOP_E_TARGET
    log_error = abs(math.log(factor)) if factor > 0 else float("inf")

    return {
        "multiplier": multiplier,
        "log_multiplier": math.log(multiplier) if multiplier > 0 else None,
        "predicted_top_e_scale": predicted,
        "predicted_top_e_vs_target_factor": factor,
        "top_e_log_error_abs": log_error,
        "top_e_percent_error": 100.0 * (factor - 1.0),
        "residual_multiplier_to_exact_gap": TOP_GAP_EXACT - multiplier,
        "residual_percent_of_exact_gap": 100.0 * ((TOP_GAP_EXACT - multiplier) / TOP_GAP_EXACT),
    }


def activation_candidate_rows() -> list[dict]:
    return [
        {
            "model_id": "one_extra_6pi_minimal_terminal_closure",
            "status": "LEAD_ACTIVATION_CANDIDATE",
            "activation_rule": "At D-scale saturation, the least nonzero no-overwrite terminal completion that closes both real support sectors is one full untaxed closure: 4π+2π.",
            "multiplier": SIX_PI,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "is_control": False,
            "derivable_without_top": True,
            "full_closure_4pi_plus_2pi": True,
            "minimal_nonzero_layer": True,
            "no_overwrite_minimal_next_write": True,
            "terminal_untaxed_completion": True,
            "avoids_duplicate_D_scale": True,
            "reject_reason": "",
            "native_prior": 16.0,
        },
        {
            "model_id": "zero_extra_layer_null",
            "status": "UNDERCLOSURE_NULL",
            "activation_rule": "No additional top-sector completion after D-scale saturation.",
            "multiplier": 1.0,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "is_control": True,
            "derivable_without_top": True,
            "full_closure_4pi_plus_2pi": False,
            "minimal_nonzero_layer": False,
            "no_overwrite_minimal_next_write": False,
            "terminal_untaxed_completion": False,
            "avoids_duplicate_D_scale": True,
            "reject_reason": "Leaves saturated high sector without terminal support/frame closure.",
            "native_prior": 2.0,
        },
        {
            "model_id": "two_extra_6pi_layers_null",
            "status": "OVERCLOSURE_NULL",
            "activation_rule": "Apply two full terminal 6π layers.",
            "multiplier": SIX_PI * SIX_PI,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "is_control": True,
            "derivable_without_top": True,
            "full_closure_4pi_plus_2pi": True,
            "minimal_nonzero_layer": False,
            "no_overwrite_minimal_next_write": False,
            "terminal_untaxed_completion": True,
            "avoids_duplicate_D_scale": False,
            "reject_reason": "Duplicates terminal closure/write and violates minimal next-write principle.",
            "native_prior": 3.0,
        },
        {
            "model_id": "one_extra_3pi_half_layer_null",
            "status": "HALF_CLOSURE_UNDERLOAD_NULL",
            "activation_rule": "Only one 3π half-action layer activates.",
            "multiplier": THREE_PI,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "is_control": True,
            "derivable_without_top": True,
            "full_closure_4pi_plus_2pi": False,
            "minimal_nonzero_layer": True,
            "no_overwrite_minimal_next_write": True,
            "terminal_untaxed_completion": False,
            "avoids_duplicate_D_scale": True,
            "reject_reason": "Does not close both 4π spinor/spatial and 2π frame/gauge sectors.",
            "native_prior": 4.0,
        },
        {
            "model_id": "taxed_6pi_minus_amplitude_tax_control",
            "status": "TAXED_COMPLETION_CONTROL",
            "activation_rule": "Top closure reuses D-scale amplitude tax: 6π - 1/2 ln(25/13).",
            "multiplier": SIX_PI - AMPLITUDE_TAX_FREEZE,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "is_control": True,
            "derivable_without_top": True,
            "full_closure_4pi_plus_2pi": True,
            "minimal_nonzero_layer": True,
            "no_overwrite_minimal_next_write": True,
            "terminal_untaxed_completion": False,
            "avoids_duplicate_D_scale": True,
            "reject_reason": "Reapplies branch-participation tax to a terminal completion load.",
            "native_prior": 5.0,
        },
        {
            "model_id": "taxed_6pi_plus_amplitude_tax_control",
            "status": "TAXED_COMPLETION_CONTROL",
            "activation_rule": "Top closure adds D-scale amplitude tax: 6π + 1/2 ln(25/13).",
            "multiplier": SIX_PI + AMPLITUDE_TAX_FREEZE,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "is_control": True,
            "derivable_without_top": True,
            "full_closure_4pi_plus_2pi": True,
            "minimal_nonzero_layer": True,
            "no_overwrite_minimal_next_write": True,
            "terminal_untaxed_completion": False,
            "avoids_duplicate_D_scale": True,
            "reject_reason": "Adds D-scale tax to terminal completion load without action reason.",
            "native_prior": 5.0,
        },
        {
            "model_id": "two_times_frozen_L_eff_control",
            "status": "REUSE_D_SCALE_LOAD_CONTROL",
            "activation_rule": "Top sector reuses the frozen D-scale taxed load: 2*L_eff.",
            "multiplier": 2.0 * L_EFF_FREEZE,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "is_control": True,
            "derivable_without_top": True,
            "full_closure_4pi_plus_2pi": False,
            "minimal_nonzero_layer": True,
            "no_overwrite_minimal_next_write": True,
            "terminal_untaxed_completion": False,
            "avoids_duplicate_D_scale": False,
            "reject_reason": "Confuses internal trace-compounding load with terminal full-closure load.",
            "native_prior": 4.0,
        },
        {
            "model_id": "legacy_K_req_bridge",
            "status": "SUPPORTIVE_DIAGNOSTIC_BRIDGE",
            "activation_rule": "Use legacy K_req as the high-sector load.",
            "multiplier": K_REQ,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "is_control": False,
            "derivable_without_top": False,
            "full_closure_4pi_plus_2pi": False,
            "minimal_nonzero_layer": True,
            "no_overwrite_minimal_next_write": True,
            "terminal_untaxed_completion": True,
            "avoids_duplicate_D_scale": True,
            "reject_reason": "Supportive bridge only; K_req origin not derived here.",
            "native_prior": 8.0,
        },
        {
            "model_id": "sqrt2_half_action_K_diagnostic",
            "status": "DIAGNOSTIC_USES_D",
            "activation_rule": "K = 2(ln D - 1/2 ln2).",
            "multiplier": SQRT2_HALF_ACTION_K_DIAGNOSTIC,
            "uses_top_to_define": False,
            "uses_D_to_define": True,
            "is_control": True,
            "derivable_without_top": False,
            "full_closure_4pi_plus_2pi": False,
            "minimal_nonzero_layer": True,
            "no_overwrite_minimal_next_write": True,
            "terminal_untaxed_completion": True,
            "avoids_duplicate_D_scale": True,
            "reject_reason": "Uses D diagnostic relation; not a native top-sector trigger.",
            "native_prior": 4.0,
        },
        {
            "model_id": "exact_top_gap_diagnostic",
            "status": "DIAGNOSTIC_ONLY_USES_TOP",
            "activation_rule": "Use exact top/e gap.",
            "multiplier": TOP_GAP_EXACT,
            "uses_top_to_define": True,
            "uses_D_to_define": False,
            "is_control": True,
            "derivable_without_top": False,
            "full_closure_4pi_plus_2pi": False,
            "minimal_nonzero_layer": False,
            "no_overwrite_minimal_next_write": False,
            "terminal_untaxed_completion": False,
            "avoids_duplicate_D_scale": True,
            "reject_reason": "Uses top/e target and cannot define the theory.",
            "native_prior": -14.0,
        },
    ]


def candidate_score(row: dict) -> dict:
    rec = dict(row)
    rec.update(top_prediction(float(row["multiplier"])))

    score = float(row["native_prior"])

    # Mechanism score.
    if row["derivable_without_top"]:
        score += 4.0
    if row["full_closure_4pi_plus_2pi"]:
        score += 5.0
    if row["minimal_nonzero_layer"]:
        score += 4.0
    if row["no_overwrite_minimal_next_write"]:
        score += 3.0
    if row["terminal_untaxed_completion"]:
        score += 3.0
    if row["avoids_duplicate_D_scale"]:
        score += 2.0

    # Diagnostic match score. This is weaker than mechanism score.
    err = rec["top_e_log_error_abs"]
    if err < 0.001:
        score += 5.0
    elif err < 0.005:
        score += 4.0
    elif err < 0.01:
        score += 3.0
    elif err < 0.03:
        score += 2.0
    elif err < 0.10:
        score += 1.0

    # Penalties.
    if row["uses_top_to_define"]:
        score -= 20.0
    if row["uses_D_to_define"]:
        score -= 8.0
    if row["is_control"]:
        score -= 3.0
    if "NULL" in row["status"]:
        score -= 4.0
    if "DIAGNOSTIC_ONLY_USES_TOP" in row["status"]:
        score -= 8.0
    if "OVERCLOSURE" in row["status"]:
        score -= 6.0
    if "UNDERCLOSURE" in row["status"]:
        score -= 6.0
    if "HALF_CLOSURE" in row["status"]:
        score -= 4.0

    rec["activation_score"] = score
    return rec


def activation_scorecard() -> pd.DataFrame:
    rows = [candidate_score(r) for r in activation_candidate_rows()]
    return pd.DataFrame(rows).sort_values("activation_score", ascending=False).reset_index(drop=True)


def activation_gate_matrix(scorecard: pd.DataFrame) -> pd.DataFrame:
    lead = scorecard[scorecard["model_id"] == "one_extra_6pi_minimal_terminal_closure"].iloc[0]
    zero = scorecard[scorecard["model_id"] == "zero_extra_layer_null"].iloc[0]
    two = scorecard[scorecard["model_id"] == "two_extra_6pi_layers_null"].iloc[0]
    half = scorecard[scorecard["model_id"] == "one_extra_3pi_half_layer_null"].iloc[0]
    minus_tax = scorecard[scorecard["model_id"] == "taxed_6pi_minus_amplitude_tax_control"].iloc[0]
    plus_tax = scorecard[scorecard["model_id"] == "taxed_6pi_plus_amplitude_tax_control"].iloc[0]
    exact = scorecard[scorecard["model_id"] == "exact_top_gap_diagnostic"].iloc[0]

    return pd.DataFrame([
        {
            "gate": "native_activation_rule",
            "test": "Can a rule select one extra 6π without top/e?",
            "status": "PARTIAL_PASS",
            "evidence": "Minimal terminal no-overwrite full closure selects one untaxed 4π+2π completion.",
            "boundary": "Still a criterion candidate, not a full action theorem."
        },
        {
            "gate": "lead_candidate",
            "test": "One extra 6π terminal completion.",
            "status": "LEAD",
            "evidence": f"activation_score={lead['activation_score']}, predicted_factor={lead['predicted_top_e_vs_target_factor']}",
            "boundary": "Top/e diagnostic supportive only."
        },
        {
            "gate": "zero_layer_null",
            "test": "No additional closure after D-scale saturation.",
            "status": "REJECT_UNDERCLOSURE",
            "evidence": f"factor={zero['predicted_top_e_vs_target_factor']}, reason={zero['reject_reason']}",
            "boundary": "Fails closure-completion premise."
        },
        {
            "gate": "two_layer_null",
            "test": "Two full 6π layers.",
            "status": "REJECT_OVERCLOSURE",
            "evidence": f"factor={two['predicted_top_e_vs_target_factor']}, reason={two['reject_reason']}",
            "boundary": "Violates minimal next-write premise."
        },
        {
            "gate": "half_layer_null",
            "test": "One extra 3π half-layer.",
            "status": "REJECT_HALF_CLOSURE",
            "evidence": f"factor={half['predicted_top_e_vs_target_factor']}, reason={half['reject_reason']}",
            "boundary": "Does not close both support sectors."
        },
        {
            "gate": "taxed_variant_controls",
            "test": "6π ± amplitude tax.",
            "status": "REJECT_AS_PRIMARY",
            "evidence": f"minus_tax_factor={minus_tax['predicted_top_e_vs_target_factor']}, plus_tax_factor={plus_tax['predicted_top_e_vs_target_factor']}",
            "boundary": "Terminal completion is not branch participation."
        },
        {
            "gate": "exact_gap_boundary",
            "test": "Exact top/e gap.",
            "status": "REJECT_AS_DERIVATION",
            "evidence": f"uses_top_to_define={exact['uses_top_to_define']}, activation_score={exact['activation_score']}",
            "boundary": "Diagnostic only."
        },
        {
            "gate": "top_e_solved",
            "test": "Does R221 solve top/e?",
            "status": "NO",
            "evidence": "Activation criterion is sharpened but not a full action theorem; residual remains open.",
            "boundary": "No V12.13."
        },
    ])


def layer_count_audit() -> pd.DataFrame:
    rows = []
    for n in [0, 0.5, 1, 2, 3]:
        if n == 0:
            multiplier = 1.0
            interpretation = "zero extra layer"
        elif n == 0.5:
            multiplier = THREE_PI
            interpretation = "half closure layer"
        else:
            multiplier = SIX_PI ** n
            interpretation = f"{n} full 6π layers"

        pred = top_prediction(multiplier)
        rows.append({
            "layer_count": n,
            "interpretation": interpretation,
            **pred,
            "ruling": (
                "UNDERCLOSURE" if n == 0 else
                "HALF_UNDERCLOSURE" if n == 0.5 else
                "LEAD_MINIMAL_TERMINAL_LAYER" if n == 1 else
                "OVERCLOSURE"
            ),
        })

    return pd.DataFrame(rows)


def residual_analysis() -> pd.DataFrame:
    residual = TOP_GAP_EXACT - SIX_PI
    log_residual = TOP_GAP_LOG - math.log(SIX_PI)

    rows = [
        {
            "quantity": "exact_gap_minus_6pi",
            "value": residual,
            "interpretation": "absolute multiplier residual after one 6π layer",
            "ruling": "OPEN_DIAGNOSTIC_ONLY",
        },
        {
            "quantity": "percent_gap_above_6pi",
            "value": 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0),
            "interpretation": "exact gap is this percent above 6π",
            "ruling": "OPEN_DIAGNOSTIC_ONLY",
        },
        {
            "quantity": "log_gap_minus_log_6pi",
            "value": log_residual,
            "interpretation": "log residual",
            "ruling": "OPEN_DIAGNOSTIC_ONLY",
        },
        {
            "quantity": "residual_over_amplitude_tax",
            "value": residual / AMPLITUDE_TAX_FREEZE,
            "interpretation": "checks whether residual naturally equals D-scale amplitude tax fraction",
            "ruling": "NO_PROMOTION",
        },
        {
            "quantity": "residual_over_ln2",
            "value": residual / LN2,
            "interpretation": "checks binary relation",
            "ruling": "NO_PROMOTION",
        },
        {
            "quantity": "residual_over_2pi",
            "value": residual / TWO_PI,
            "interpretation": "checks phase-cycle fraction",
            "ruling": "NO_PROMOTION",
        },
    ]

    return pd.DataFrame(rows)


def proof_status_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "claim": "6π can be derived without top/e.",
            "status": "PASS_FORMAL",
            "evidence": "6π = 4π + 2π from full support/frame closure.",
            "boundary": "Candidate multiplier only."
        },
        {
            "claim": "Exactly one layer is selected by a native criterion.",
            "status": "PARTIAL_PASS",
            "evidence": "Minimal nonzero no-overwrite terminal completion selects one layer over zero/two.",
            "boundary": "Needs full action theorem."
        },
        {
            "claim": "The layer is untaxed.",
            "status": "CONDITIONAL_PASS",
            "evidence": "Terminal completion load is not branch participation; taxed controls weaker.",
            "boundary": "Needs action-level distinction between completion load and amplitude tax."
        },
        {
            "claim": "Top/e is closed.",
            "status": "NO",
            "evidence": "Residual remains and activation rule is not yet full theorem.",
            "boundary": "No V12.13."
        },
        {
            "claim": "Species map is derived.",
            "status": "NO",
            "evidence": "No species labels used.",
            "boundary": "Deferred."
        },
    ])


def open_claims_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "open_claim": "full_action_theorem_for_activation",
            "status": "OPEN",
            "current_best_candidate": "Minimal nonzero no-overwrite terminal closure selects exactly one 6π layer.",
            "why_open": "R221 scores this rule but does not prove it from a full variational action.",
            "required_next": "Promote criterion into a symbolic theorem or demote to heuristic.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "residual_gap",
            "status": "OPEN",
            "current_best_candidate": "Top/e diagnostic gap is 0.632% above 6π.",
            "why_open": "Could be correction, target context, or approximate coincidence.",
            "required_next": "Only analyze after activation theorem is settled.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "K_req_origin",
            "status": "OPEN",
            "current_best_candidate": "K_req supportive bridge.",
            "why_open": "K_req remains close to exact gap but lacks native activation derivation.",
            "required_next": "Either recover K_req from action or demote it.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "species_map",
            "status": "OPEN",
            "current_best_candidate": "Deferred.",
            "why_open": "Avoid species fitting until top-sector rule is bounded.",
            "required_next": "Build species map constraints later.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "prediction_null_suite",
            "status": "OPEN",
            "current_best_candidate": "Not addressed.",
            "why_open": "No blind prediction/null test yet.",
            "required_next": "Build no-retuning test suite.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "V12_13_promotion",
            "status": "NO",
            "current_best_candidate": "Not eligible.",
            "why_open": "Top/e not closed, species/predictions open.",
            "required_next": "No promotion.",
            "promotion_blocker": True,
        },
    ])


def claim_boundary_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Allowed claim",
            "claim": "R221M identifies a native activation criterion candidate for exactly one extra 6π layer.",
            "status": "YES",
            "safe_wording": "Criterion candidate, not full theorem."
        },
        {
            "category": "Allowed claim",
            "claim": "Zero, half, two-layer, taxed, and exact-gap alternatives are rejected or demoted as primary rules.",
            "status": "YES",
            "safe_wording": "Under current criterion scoring."
        },
        {
            "category": "Allowed claim",
            "claim": "One extra 6π remains the lead top/e structural candidate.",
            "status": "YES",
            "safe_wording": "Lead structural candidate."
        },
        {
            "category": "Blocked claim",
            "claim": "Top/e is solved.",
            "status": "NO",
            "safe_wording": "Top-sector activation still needs full action theorem and residual remains open."
        },
        {
            "category": "Blocked claim",
            "claim": "Exact top/e gap defines the law.",
            "status": "NO",
            "safe_wording": "Diagnostic only."
        },
        {
            "category": "Blocked claim",
            "claim": "Species map is derived.",
            "status": "NO",
            "safe_wording": "Species map remains open."
        },
        {
            "category": "Blocked claim",
            "claim": "V12.13 is promoted.",
            "status": "NO",
            "safe_wording": "No V12.13 promotion."
        },
    ])


def activation_note_text(created_utc: str) -> str:
    return f"""
# R221M Top-Sector Activation Criterion Hunt Note

Generated: {created_utc}

## Frozen input

D-scale law:

    M_i = G_i exp[(3pi - 1/2 ln(25/13)) u_i]

D-scale endpoint:

    {D_SCALE_ENDPOINT}

## R220 full-closure candidate

    K_top = 4pi + 2pi = 6pi

where:

    4pi = spatial/spinor curvature closure
    2pi = frame/gauge phase closure

## R221 activation criterion candidate

At the saturated endpoint of the D-scale trace lane, the least additional
no-overwrite completion that closes both real support sectors is exactly one
full untaxed closure cycle:

    one extra K_top = 6pi

Why not zero?

    zero leaves the high sector without terminal full support/frame closure.

Why not half?

    3pi does not close both 4pi and 2pi sectors.

Why not two?

    two full layers duplicate the terminal write and violate minimal next-write.

Why not taxed?

    the D-scale amplitude tax belongs to internal branch participation.
    the top closure is a terminal completion load.

## Diagnostic

    predicted_top_e = {D_SCALE_ENDPOINT * SIX_PI}
    predicted_vs_target = {(D_SCALE_ENDPOINT * SIX_PI) / TOP_E_TARGET}
    exact_gap_minus_6pi = {TOP_GAP_EXACT - SIX_PI}

## Boundary

This is a criterion candidate, not a full action theorem.
Top/e is not solved.
No species map.
No V12.13 promotion.
"""


def build_report(
    created_utc: str,
    verdict: str,
    scorecard: pd.DataFrame,
    gates: pd.DataFrame,
    layer_audit: pd.DataFrame,
    residuals: pd.DataFrame,
    proof_status: pd.DataFrame,
    open_claims: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R221M — Top-Sector Activation Criterion Hunt

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R221M tests why exactly one extra 6π top-sector layer should activate.

Frozen D-scale endpoint:
{D_SCALE_ENDPOINT}

Top/e exact diagnostic gap:
{TOP_GAP_EXACT}

Activation scorecard:
{scorecard.to_string(index=False)}

Activation gate matrix:
{gates.to_string(index=False)}

Layer-count audit:
{layer_audit.to_string(index=False)}

Residual analysis:
{residuals.to_string(index=False)}

Proof status ledger:
{proof_status.to_string(index=False)}

Open claims ledger:
{open_claims.to_string(index=False)}

Claim boundary matrix:
{claims.to_string(index=False)}

Interpretation:
R221M sharpens the one-extra-6π rule into a native activation criterion candidate:

At the saturated endpoint of the D-scale trace lane, the least additional no-overwrite completion that closes both real support sectors is exactly one full untaxed 4π+2π closure layer.

The rule rejects zero extra layers as underclosure, one half-layer as incomplete closure, two full layers as overclosure/duplicate terminal write, and taxed variants as confusing terminal completion with D-scale branch participation.

This strengthens the top/e structural lane but still does not solve top/e. The remaining gap is a full action theorem for the activation criterion and the small residual above 6π.

Ruling:
Top-sector activation criterion candidate preserved.
Top/e not solved.
No species map.
No V12.13 promotion.

Next recommended run:
R222M — Activation Criterion Symbolic Theorem Attempt

Question:
Can the minimal nonzero no-overwrite terminal completion rule be written as a symbolic lemma from the master action assumptions?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    scorecard = activation_scorecard()
    gates = activation_gate_matrix(scorecard)
    layer_audit = layer_count_audit()
    residuals = residual_analysis()
    proof_status = proof_status_ledger()
    open_claims = open_claims_ledger()
    claims = claim_boundary_matrix()

    lead = scorecard[scorecard["model_id"] == "one_extra_6pi_minimal_terminal_closure"].iloc[0].to_dict()
    zero = scorecard[scorecard["model_id"] == "zero_extra_layer_null"].iloc[0].to_dict()
    two = scorecard[scorecard["model_id"] == "two_extra_6pi_layers_null"].iloc[0].to_dict()
    half = scorecard[scorecard["model_id"] == "one_extra_3pi_half_layer_null"].iloc[0].to_dict()
    exact = scorecard[scorecard["model_id"] == "exact_top_gap_diagnostic"].iloc[0].to_dict()

    verdict = (
        "PARTIAL_PASS_TOP_SECTOR_ACTIVATION_CRITERION_CANDIDATE_IDENTIFIED_"
        "MINIMAL_NONZERO_NO_OVERWRITE_TERMINAL_COMPLETION_SELECTS_ONE_UNTAXED_6PI_LAYER_"
        "ZERO_HALF_TWO_TAXED_AND_EXACT_GAP_ALTERNATIVES_REJECTED_OR_DEMOTED_AS_PRIMARY_"
        "FULL_ACTION_THEOREM_AND_RESIDUAL_OPEN_NO_SPECIES_MAP_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "R218_frozen_D_scale_law": {
            "compact_formula": "M_i = G_i exp[(3*pi - 0.5*ln(25/13)) u_i]",
            "L_eff_numeric": L_EFF_FREEZE,
            "N_eff": N_EFF_FREEZE,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "endpoint_vs_D_factor": D_SCALE_ENDPOINT / D_TARGET,
        },
        "activation_criterion_candidate": {
            "rule": "At D-scale saturation, select the least nonzero no-overwrite terminal completion that closes both real support sectors.",
            "selected_layer": "one extra untaxed K_top = 4*pi + 2*pi = 6*pi",
            "K_top_numeric": SIX_PI,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
        },
        "lead_candidate": lead,
        "zero_layer_null": zero,
        "half_layer_null": half,
        "two_layer_null": two,
        "exact_gap_diagnostic": exact,
        "top_e_context": {
            "top_e_target_context": TOP_E_TARGET,
            "exact_multiplier_gap": TOP_GAP_EXACT,
            "exact_gap_log": TOP_GAP_LOG,
            "gap_minus_6pi": TOP_GAP_EXACT - SIX_PI,
            "gap_percent_above_6pi": 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0),
        },
        "scorecard": scorecard.to_dict(orient="records"),
        "proof_status": proof_status.to_dict(orient="records"),
        "open_claims": open_claims.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "Activation criterion candidate preserved; top/e not solved; no V12.13.",
        "next_recommended": "R222M - Activation Criterion Symbolic Theorem Attempt",
        "paste_back_to_chat": [
            "summary.json",
            "activation_criterion_note.md",
            "tables/R221M_activation_scorecard.csv",
            "tables/R221M_activation_gate_matrix.csv",
            "tables/R221M_layer_count_audit.csv",
            "Any traceback if the run failed."
        ],
    }

    scorecard.to_csv(tables / "R221M_activation_scorecard.csv", index=False)
    gates.to_csv(tables / "R221M_activation_gate_matrix.csv", index=False)
    layer_audit.to_csv(tables / "R221M_layer_count_audit.csv", index=False)
    residuals.to_csv(tables / "R221M_residual_analysis.csv", index=False)
    proof_status.to_csv(tables / "R221M_proof_status_ledger.csv", index=False)
    open_claims.to_csv(tables / "R221M_open_claims_ledger.csv", index=False)
    claims.to_csv(tables / "R221M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        scorecard=scorecard,
        gates=gates,
        layer_audit=layer_audit,
        residuals=residuals,
        proof_status=proof_status,
        open_claims=open_claims,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "activation_criterion_note.md").write_text(activation_note_text(created_utc), encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
