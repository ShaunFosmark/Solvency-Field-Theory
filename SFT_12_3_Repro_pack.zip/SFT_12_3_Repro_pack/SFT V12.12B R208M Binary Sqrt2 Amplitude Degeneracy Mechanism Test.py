#!/usr/bin/env python3
"""
SFT V12.12B R208M — Binary/Sqrt2 Amplitude Degeneracy Mechanism Test

Purpose:
    R207M identified the ln2 correction family and found that the best
    D-endpoint candidate is:

        L_eff = 3π - 1/2 ln2

    which is equivalent to a sqrt2 amplitude tax.

    R208M asks:
        Can sqrt2 / half-ln2 be derived from two-channel area-write accounting
        without using D as input?

Core mechanism tested:
    If one coherent settlement write is distributed across two orthogonal
    support channels with normalized shares p and 1-p, then the effective
    channel participation is:

        N_eff = 1 / (p^2 + (1-p)^2)

    and the amplitude tax is:

        tax = 1/2 ln(N_eff)

    For equal channels p = 1/2:

        N_eff = 2
        tax = 1/2 ln2 = ln(sqrt2)

    Therefore:

        L_eff = 3π - 1/2 ln2

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - no V12.13 promotion

Outputs:
    SFT_V12_12B_R208M_Binary_Sqrt2_Amplitude_Degeneracy_Mechanism_Test/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R208M.py

    SFT_V12_12B_R208M_Binary_Sqrt2_Amplitude_Degeneracy_Mechanism_Test_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R208M_Binary_Sqrt2_Amplitude_Degeneracy_Mechanism_Test"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
SQRT2 = math.sqrt(2.0)

TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi
HALF_K_REQ = K_REQ / 2.0

RHO0 = 0.5
RHO_SPAN = 4.0

SEED_MODES = [
    Fraction(1, 2),
    Fraction(2, 3),
    Fraction(3, 4),
    Fraction(1, 1),
    Fraction(5, 4),
    Fraction(4, 3),
    Fraction(3, 2),
    Fraction(5, 3),
    Fraction(2, 1),
]

D_PERP = 3


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def frac_str(f: Fraction) -> str:
    if f.denominator == 1:
        return str(f.numerator)
    return f"{f.numerator}/{f.denominator}"


def balanced_occupancy(m: int, n: int) -> list[int]:
    active = min(max(n, 1), D_PERP)
    q, r = divmod(m, active)

    occ = [q + 1 if i < r else q for i in range(active)]
    occ += [0] * (D_PERP - len(occ))
    occ.sort(reverse=True)

    return occ


def shape_stats(occ: list[int]) -> dict:
    total = sum(occ)
    probs = [x / total for x in occ] if total else [0.0, 0.0, 0.0]

    l2 = math.sqrt(sum(p * p for p in probs))
    iso = 1.0 / D_PERP

    eccentricity = 0.0
    if total:
        eccentricity = math.sqrt(sum((p - iso) ** 2 for p in probs)) / math.sqrt(2.0 / 3.0)

    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    entropy_norm = entropy / math.log(D_PERP)
    entropy_deficit = 1.0 - entropy_norm

    active_slots = sum(1 for x in occ if x > 0)
    max_occ = max(occ) if occ else 0
    slot_fill_fraction = active_slots / D_PERP

    return {
        "shape_l2_norm": l2,
        "eccentricity_norm": eccentricity,
        "entropy_norm": entropy_norm,
        "entropy_deficit": entropy_deficit,
        "active_slots": active_slots,
        "max_occ": max_occ,
        "slot_fill_fraction": slot_fill_fraction,
    }


def build_modes() -> pd.DataFrame:
    rows = []

    for rho in SEED_MODES:
        m = rho.numerator
        n = rho.denominator
        occ = balanced_occupancy(m, n)
        stats = shape_stats(occ)

        rows.append({
            "rho": frac_str(rho),
            "rho_float": float(rho),
            "m": m,
            "N": n,
            "occupancy_vector": "(" + ",".join(str(x) for x in occ) + ")",
            "occ0": occ[0],
            "occ1": occ[1],
            "occ2": occ[2],
            "active_slots": stats["active_slots"],
            "max_occ": stats["max_occ"],
            "slot_fill_fraction": stats["slot_fill_fraction"],
            "shape_l2_norm": stats["shape_l2_norm"],
            "eccentricity_norm": stats["eccentricity_norm"],
            "entropy_norm": stats["entropy_norm"],
            "entropy_deficit": stats["entropy_deficit"],
            "u_logrho": math.log(float(rho) / RHO0) / math.log(RHO_SPAN),
        })

    return pd.DataFrame(rows).sort_values("rho_float").reset_index(drop=True)


def fibonacci_sphere(n: int = 300) -> np.ndarray:
    pts = []
    phi = math.pi * (3.0 - math.sqrt(5.0))

    for i in range(n):
        y = 1.0 - (i / float(n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - y * y))
        theta = phi * i
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        pts.append([x, y, z])

    return np.array(pts, dtype=float)


SPHERE_POINTS = fibonacci_sphere(300)
RHAT = SPHERE_POINTS.copy()


def ring_basis(axis_index: int) -> tuple[np.ndarray, np.ndarray]:
    if axis_index == 0:
        return np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])
    if axis_index == 1:
        return np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])
    return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])


def source_points_ring(
    occ: list[int],
    ring_radius: float = 0.55,
    n_per_ring: int = 36,
) -> tuple[np.ndarray, np.ndarray]:
    positions = []
    weights = []

    for axis_index, weight in enumerate(occ):
        if weight <= 0:
            continue

        e1, e2 = ring_basis(axis_index)

        for j in range(n_per_ring):
            t = 2.0 * math.pi * j / n_per_ring
            point = ring_radius * (math.cos(t) * e1 + math.sin(t) * e2)
            positions.append(point)
            weights.append(weight / n_per_ring)

    return np.array(positions, dtype=float), np.array(weights, dtype=float)


def eval_ring_geometry(
    occ: list[int],
    softening: float = 0.12,
    ring_radius: float = 0.55,
) -> dict:
    pos, weights = source_points_ring(occ, ring_radius=ring_radius)

    potentials = []
    grad_mags = []
    abs_radial_curvatures = []

    for x, rh in zip(SPHERE_POINTS, RHAT):
        d = x[None, :] - pos
        d2 = np.sum(d * d, axis=1) + softening ** 2
        R = np.sqrt(d2)

        potential = np.sum(weights / R)

        grad = np.sum((-weights[:, None] * d) / (R[:, None] ** 3), axis=0)
        grad_mag = np.linalg.norm(grad)

        rd = d @ rh
        hess_radial = np.sum(weights * (-1.0 / (R ** 3) + 3.0 * (rd ** 2) / (R ** 5)))

        potentials.append(float(potential))
        grad_mags.append(float(grad_mag))
        abs_radial_curvatures.append(abs(float(hess_radial)))

    return {
        "mean_potential": float(np.mean(potentials)),
        "mean_gradient_magnitude": float(np.mean(grad_mags)),
        "mean_abs_radial_curvature": float(np.mean(abs_radial_curvatures)),
        "p95_abs_radial_curvature": float(np.quantile(abs_radial_curvatures, 0.95)),
    }


def add_geometry_signal(modes: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in modes.iterrows():
        occ = [int(row["occ0"]), int(row["occ1"]), int(row["occ2"])]
        obs = eval_ring_geometry(occ)

        rec = row.to_dict()
        rec.update(obs)
        rows.append(rec)

    df = pd.DataFrame(rows)

    for col in [
        "mean_potential",
        "mean_gradient_magnitude",
        "mean_abs_radial_curvature",
        "p95_abs_radial_curvature",
    ]:
        base = df.loc[df["rho"] == "1/2", col].iloc[0]
        df[col + "_ratio_to_rho_half"] = df[col] / base

    df["G_i_geometry_ratio"] = df["mean_abs_radial_curvature_ratio_to_rho_half"]
    return df


def target_power_exponent(target_span: float) -> float:
    return math.log(target_span) / math.log(RHO_SPAN)


P_D = target_power_exponent(D_TARGET)
P_TOP = target_power_exponent(TOP_E_TARGET)
P_HALF_6PI = (SIX_PI / 2.0) / math.log(RHO_SPAN)
P_HALF_KREQ = (K_REQ / 2.0) / math.log(RHO_SPAN)


def add_targets(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    out["target_D_rhopower"] = (out["rho_float"] / RHO0) ** P_D
    out["target_top_e_rhopower"] = (out["rho_float"] / RHO0) ** P_TOP
    out["target_half_6pi_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_6PI
    out["target_half_Kreq_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_KREQ

    return out


def amplitude_tax_from_shares(shares: list[float]) -> dict:
    arr = np.array(shares, dtype=float)
    arr = arr[arr > 0]

    if arr.size == 0:
        return {
            "N_eff": 1.0,
            "amplitude_tax": 0.0,
            "c_ln2": 0.0,
            "share_string": "()",
            "participation_sum_squares": 1.0,
        }

    arr = arr / np.sum(arr)
    sumsq = float(np.sum(arr * arr))
    N_eff = 1.0 / sumsq
    amplitude_tax = 0.5 * math.log(N_eff)
    c_ln2 = amplitude_tax / LN2

    return {
        "N_eff": N_eff,
        "amplitude_tax": amplitude_tax,
        "c_ln2": c_ln2,
        "share_string": "(" + ",".join(f"{x:.12g}" for x in arr.tolist()) + ")",
        "participation_sum_squares": sumsq,
    }


def split_from_c_for_two_channels(c_value: float) -> dict:
    tax = c_value * LN2
    N_eff = math.exp(2.0 * tax)

    possible = 1.0 <= N_eff <= 2.0

    if not possible:
        return {
            "c_value": c_value,
            "tax": tax,
            "N_eff": N_eff,
            "two_channel_possible": False,
            "p_high": np.nan,
            "p_low": np.nan,
            "imbalance": np.nan,
        }

    sumsq = 1.0 / N_eff
    y2 = max(0.0, (sumsq - 0.5) / 2.0)
    y = math.sqrt(y2)

    p_high = 0.5 + y
    p_low = 0.5 - y

    return {
        "c_value": c_value,
        "tax": tax,
        "N_eff": N_eff,
        "two_channel_possible": True,
        "p_high": p_high,
        "p_low": p_low,
        "imbalance": p_high - p_low,
    }


def mechanism_tax_candidates(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    base_candidates = [
        {
            "mechanism_id": "no_split_half_action",
            "mechanism_family": "control",
            "shares": [1.0],
            "mechanical_reading": "pure half-action feedback with no amplitude tax",
            "native_status": "control"
        },
        {
            "mechanism_id": "equal_two_channel_sqrt2_tax",
            "mechanism_family": "binary_amplitude",
            "shares": [0.5, 0.5],
            "mechanical_reading": "one write distributed equally across two orthogonal channels",
            "native_status": "conditional_derivation_if_two_channel_premise_holds"
        },
        {
            "mechanism_id": "equal_four_channel_full_ln2_tax",
            "mechanism_family": "binary_amplitude",
            "shares": [0.25, 0.25, 0.25, 0.25],
            "mechanical_reading": "two independent equal binary splits or four equal channels",
            "native_status": "candidate_for_curve_shape"
        },
        {
            "mechanism_id": "equal_three_channel_tax",
            "mechanism_family": "multi_channel",
            "shares": [1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0],
            "mechanical_reading": "three equal channels",
            "native_status": "control"
        },
        {
            "mechanism_id": "sixty_forty_two_channel",
            "mechanism_family": "binary_amplitude",
            "shares": [0.6, 0.4],
            "mechanical_reading": "slightly imbalanced two-channel write split",
            "native_status": "diagnostic_control_not_fitted"
        },
        {
            "mechanism_id": "seventy_thirty_two_channel",
            "mechanism_family": "binary_amplitude",
            "shares": [0.7, 0.3],
            "mechanical_reading": "strongly imbalanced two-channel write split",
            "native_status": "control"
        },
    ]

    for cand in base_candidates:
        tax = amplitude_tax_from_shares(cand["shares"])
        rows.append({
            "mechanism_id": cand["mechanism_id"],
            "mechanism_family": cand["mechanism_family"],
            "mechanical_reading": cand["mechanical_reading"],
            "native_status": cand["native_status"],
            "mode_dependent": False,
            "source": "fixed_channel_accounting",
            "shares": tax["share_string"],
            "N_eff": tax["N_eff"],
            "amplitude_tax": tax["amplitude_tax"],
            "c_ln2": tax["c_ln2"],
            "L_eff": THREE_PI - tax["amplitude_tax"],
        })

    for _, row in df.iterrows():
        occ = [float(row["occ0"]), float(row["occ1"]), float(row["occ2"])]
        occ_total = sum(occ)

        if occ_total > 0:
            dominant_rest = [occ[0], occ[1] + occ[2]]
            active_equal = [1.0] * int(row["active_slots"])

            if occ[1] > 0:
                top_two = [occ[0], occ[1]]
            else:
                top_two = [occ[0]]

            mode_candidates = [
                {
                    "mechanism_id": "mode_dominant_vs_rest_split",
                    "mechanism_family": "mode_occupancy",
                    "shares": dominant_rest,
                    "mechanical_reading": "dominant occupancy channel versus remaining support",
                    "native_status": "mode_dependent_candidate"
                },
                {
                    "mechanism_id": "mode_active_slot_equal_split",
                    "mechanism_family": "mode_occupancy",
                    "shares": active_equal,
                    "mechanical_reading": "active slots treated as equal amplitude-write branches",
                    "native_status": "mode_dependent_candidate"
                },
                {
                    "mechanism_id": "mode_top_two_occupancy_split",
                    "mechanism_family": "mode_occupancy",
                    "shares": top_two,
                    "mechanical_reading": "two largest occupancy channels only",
                    "native_status": "mode_dependent_candidate"
                },
            ]

            for cand in mode_candidates:
                tax = amplitude_tax_from_shares(cand["shares"])

                rows.append({
                    "mechanism_id": cand["mechanism_id"],
                    "mechanism_family": cand["mechanism_family"],
                    "mechanical_reading": cand["mechanical_reading"],
                    "native_status": cand["native_status"],
                    "mode_dependent": True,
                    "source": "mode_" + str(row["rho"]),
                    "rho": row["rho"],
                    "rho_float": row["rho_float"],
                    "shares": tax["share_string"],
                    "N_eff": tax["N_eff"],
                    "amplitude_tax": tax["amplitude_tax"],
                    "c_ln2": tax["c_ln2"],
                    "L_eff": THREE_PI - tax["amplitude_tax"],
                })

    return pd.DataFrame(rows)


def evaluate_mechanisms(df: pd.DataFrame, fixed_and_mode_taxes: pd.DataFrame) -> pd.DataFrame:
    rows = []

    fixed = fixed_and_mode_taxes[fixed_and_mode_taxes["mode_dependent"] == False].copy()
    mode_dep = fixed_and_mode_taxes[fixed_and_mode_taxes["mode_dependent"] == True].copy()

    for _, row in df.iterrows():
        G = float(row["G_i_geometry_ratio"])
        u = float(row["u_logrho"])

        for _, mech in fixed.iterrows():
            L_eff = float(mech["L_eff"])
            ratio = G * math.exp(L_eff * u)

            rows.append({
                "rho": row["rho"],
                "rho_float": row["rho_float"],
                "m": int(row["m"]),
                "N": int(row["N"]),
                "occupancy_vector": row["occupancy_vector"],
                "G_i_geometry_ratio": G,
                "u_logrho": u,
                "mechanism_id": mech["mechanism_id"],
                "mechanism_family": mech["mechanism_family"],
                "mechanical_reading": mech["mechanical_reading"],
                "native_status": mech["native_status"],
                "mode_dependent": False,
                "shares": mech["shares"],
                "N_eff": float(mech["N_eff"]),
                "amplitude_tax": float(mech["amplitude_tax"]),
                "c_ln2": float(mech["c_ln2"]),
                "L_eff": L_eff,
                "model_ratio_to_rho_half": ratio,
                "target_D_rhopower": row["target_D_rhopower"],
                "target_top_e_rhopower": row["target_top_e_rhopower"],
                "residual_log_vs_D": math.log(ratio / row["target_D_rhopower"]) if ratio > 0 else np.nan,
                "residual_log_vs_top_e": math.log(ratio / row["target_top_e_rhopower"]) if ratio > 0 else np.nan,
            })

        matches = mode_dep[mode_dep["rho"] == row["rho"]]
        for _, mech in matches.iterrows():
            L_eff = float(mech["L_eff"])
            ratio = G * math.exp(L_eff * u)

            rows.append({
                "rho": row["rho"],
                "rho_float": row["rho_float"],
                "m": int(row["m"]),
                "N": int(row["N"]),
                "occupancy_vector": row["occupancy_vector"],
                "G_i_geometry_ratio": G,
                "u_logrho": u,
                "mechanism_id": mech["mechanism_id"],
                "mechanism_family": mech["mechanism_family"],
                "mechanical_reading": mech["mechanical_reading"],
                "native_status": mech["native_status"],
                "mode_dependent": True,
                "shares": mech["shares"],
                "N_eff": float(mech["N_eff"]),
                "amplitude_tax": float(mech["amplitude_tax"]),
                "c_ln2": float(mech["c_ln2"]),
                "L_eff": L_eff,
                "model_ratio_to_rho_half": ratio,
                "target_D_rhopower": row["target_D_rhopower"],
                "target_top_e_rhopower": row["target_top_e_rhopower"],
                "residual_log_vs_D": math.log(ratio / row["target_D_rhopower"]) if ratio > 0 else np.nan,
                "residual_log_vs_top_e": math.log(ratio / row["target_top_e_rhopower"]) if ratio > 0 else np.nan,
            })

    return pd.DataFrame(rows)


def summarize_mechanisms(outputs: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for mechanism_id, grp in outputs.groupby("mechanism_id"):
        ordered = grp.sort_values("rho_float")
        endpoint = float(ordered["model_ratio_to_rho_half"].iloc[-1])
        span = float(ordered["model_ratio_to_rho_half"].max() / ordered["model_ratio_to_rho_half"].min())
        rmse_D = float(np.sqrt(np.nanmean(ordered["residual_log_vs_D"] ** 2)))
        rmse_top = float(np.sqrt(np.nanmean(ordered["residual_log_vs_top_e"] ** 2)))

        first = ordered.iloc[0]
        mean_tax = float(np.nanmean(ordered["amplitude_tax"]))
        mean_c = float(np.nanmean(ordered["c_ln2"]))
        mean_N_eff = float(np.nanmean(ordered["N_eff"]))

        rows.append({
            "mechanism_id": mechanism_id,
            "mechanism_family": first["mechanism_family"],
            "mechanical_reading": first["mechanical_reading"],
            "native_status": first["native_status"],
            "mode_dependent": bool(first["mode_dependent"]),
            "mean_N_eff": mean_N_eff,
            "mean_amplitude_tax": mean_tax,
            "mean_c_ln2": mean_c,
            "mean_L_eff": THREE_PI - mean_tax,
            "endpoint_rho2": endpoint,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
            "endpoint_log_error_vs_D": math.log(endpoint / D_TARGET) if endpoint > 0 else np.nan,
            "span_max_over_min": span,
            "rmse_log_vs_D_target": rmse_D,
            "rmse_log_vs_top_e_target": rmse_top,
        })

    return pd.DataFrame(rows).sort_values("rmse_log_vs_D_target")


def required_channel_inference(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    targets = [
        ("D_rhopower", "target_D_rhopower"),
        ("top_e_rhopower", "target_top_e_rhopower"),
        ("half_6pi_rhopower", "target_half_6pi_rhopower"),
        ("half_Kreq_rhopower", "target_half_Kreq_rhopower"),
    ]

    for _, row in df.iterrows():
        G = float(row["G_i_geometry_ratio"])
        u = float(row["u_logrho"])

        for target_name, target_col in targets:
            target = float(row[target_col])

            if abs(u) < 1e-12:
                L_required = np.nan
                tax_required = np.nan
                c_required = np.nan
                split_info = {
                    "N_eff": np.nan,
                    "two_channel_possible": False,
                    "p_high": np.nan,
                    "p_low": np.nan,
                    "imbalance": np.nan,
                }
            else:
                L_required = math.log(target / G) / u
                tax_required = THREE_PI - L_required
                c_required = tax_required / LN2
                split_info = split_from_c_for_two_channels(c_required)

            rows.append({
                "rho": row["rho"],
                "rho_float": row["rho_float"],
                "m": int(row["m"]),
                "N": int(row["N"]),
                "G_i_geometry_ratio": G,
                "u_logrho": u,
                "target_name": target_name,
                "target_ratio": target,
                "L_required": L_required,
                "tax_required": tax_required,
                "c_required_ln2_units": c_required,
                "N_eff_required": split_info["N_eff"],
                "two_channel_possible": split_info["two_channel_possible"],
                "p_high_required": split_info["p_high"],
                "p_low_required": split_info["p_low"],
                "imbalance_required": split_info["imbalance"],
                "distance_c_to_equal_sqrt2": abs(c_required - 0.5) if not np.isnan(c_required) else np.nan,
                "distance_c_to_full_binary": abs(c_required - 1.0) if not np.isnan(c_required) else np.nan,
            })

    return pd.DataFrame(rows)


def summarize_required_channel_inference(req: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for target_name, grp in req.dropna(subset=["c_required_ln2_units"]).groupby("target_name"):
        ordered = grp.sort_values("rho_float")
        endpoint = ordered.iloc[-1]
        vals = ordered["c_required_ln2_units"].to_numpy(float)

        rows.append({
            "target_name": target_name,
            "mean_c_required": float(np.mean(vals)),
            "std_c_required": float(np.std(vals)),
            "endpoint_c_required_rho2": float(endpoint["c_required_ln2_units"]),
            "endpoint_N_eff_required": float(endpoint["N_eff_required"]),
            "endpoint_two_channel_possible": bool(endpoint["two_channel_possible"]),
            "endpoint_p_high_required": float(endpoint["p_high_required"]) if not np.isnan(endpoint["p_high_required"]) else np.nan,
            "endpoint_p_low_required": float(endpoint["p_low_required"]) if not np.isnan(endpoint["p_low_required"]) else np.nan,
            "endpoint_imbalance_required": float(endpoint["imbalance_required"]) if not np.isnan(endpoint["imbalance_required"]) else np.nan,
            "endpoint_distance_to_equal_sqrt2": float(endpoint["distance_c_to_equal_sqrt2"]),
            "endpoint_distance_to_full_binary": float(endpoint["distance_c_to_full_binary"]),
        })

    return pd.DataFrame(rows).sort_values("endpoint_distance_to_equal_sqrt2")


def random_split_null(df: pd.DataFrame, n: int = 2500, seed: int = 208) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []

    for k in range(n):
        p = float(rng.uniform(0.0, 1.0))
        tax_info = amplitude_tax_from_shares([p, 1.0 - p])
        L_eff = THREE_PI - float(tax_info["amplitude_tax"])

        model_vals = []
        residuals_D = []
        residuals_top = []

        for _, row in df.iterrows():
            G = float(row["G_i_geometry_ratio"])
            u = float(row["u_logrho"])
            ratio = G * math.exp(L_eff * u)
            model_vals.append(ratio)

            residuals_D.append(math.log(ratio / float(row["target_D_rhopower"])))
            residuals_top.append(math.log(ratio / float(row["target_top_e_rhopower"])))

        endpoint = model_vals[-1]

        rows.append({
            "sample_id": k,
            "p": p,
            "p_high": max(p, 1.0 - p),
            "p_low": min(p, 1.0 - p),
            "N_eff": tax_info["N_eff"],
            "amplitude_tax": tax_info["amplitude_tax"],
            "c_ln2": tax_info["c_ln2"],
            "L_eff": L_eff,
            "endpoint_rho2": endpoint,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_log_error_vs_D": abs(math.log(endpoint / D_TARGET)),
            "rmse_log_vs_D_target": float(np.sqrt(np.nanmean(np.array(residuals_D) ** 2))),
            "rmse_log_vs_top_e_target": float(np.sqrt(np.nanmean(np.array(residuals_top) ** 2))),
        })

    return pd.DataFrame(rows).sort_values("endpoint_log_error_vs_D")


def random_null_summary(nulls: pd.DataFrame) -> dict:
    equal_tax = amplitude_tax_from_shares([0.5, 0.5])
    equal_c = equal_tax["c_ln2"]

    best = nulls.iloc[0].to_dict()

    return {
        "random_split_count": int(len(nulls)),
        "best_random_endpoint": best,
        "median_endpoint_log_error_vs_D": float(nulls["endpoint_log_error_vs_D"].median()),
        "p05_endpoint_log_error_vs_D": float(nulls["endpoint_log_error_vs_D"].quantile(0.05)),
        "p95_endpoint_log_error_vs_D": float(nulls["endpoint_log_error_vs_D"].quantile(0.95)),
        "equal_two_channel_c_ln2": equal_c,
        "fraction_random_with_endpoint_error_better_than_equal_split": float(
            np.mean(nulls["endpoint_log_error_vs_D"] < abs(math.log(0.9802669250222167)))
        ),
    }


def gate_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "gate": "sqrt2_tax_derivation",
            "test": "Does equal two-channel amplitude accounting produce tax = 1/2 ln2?",
            "status": "CONDITIONAL_PASS",
            "boundary": "Requires proving the two support channels are real in the action."
        },
        {
            "gate": "D_endpoint",
            "test": "Does the two-channel sqrt2 tax land near the D endpoint without using D as input?",
            "status": "PASS_DIAGNOSTIC",
            "boundary": "D used only after the prediction as a diagnostic target."
        },
        {
            "gate": "required_split",
            "test": "Infer two-channel split implied by the D endpoint.",
            "status": "DIAGNOSTIC",
            "boundary": "Inference uses D and cannot count as derivation."
        },
        {
            "gate": "mode_dependent_splits",
            "test": "Do occupancy-derived split taxes naturally improve the result?",
            "status": "TESTED",
            "boundary": "Mode-dependent variants are not promoted unless action-derived."
        },
        {
            "gate": "random_split_null",
            "test": "Compare equal split to random two-channel splits.",
            "status": "CONTROL",
            "boundary": "Random closeness is not derivation."
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need native support-channel derivation and prediction nulls."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "Equal two-channel amplitude accounting derives tax = ln(sqrt2).",
            "status": "CONDITIONAL_PASS",
            "boundary": "Only if the two-channel support premise is derived."
        },
        {
            "category": "Preserved",
            "claim": "The D endpoint remains strongly compatible with sqrt2 tax.",
            "status": "DIAGNOSTIC_PASS",
            "boundary": "Compatibility is not derivation."
        },
        {
            "category": "Observed",
            "claim": "D-required split is close to equal two-channel split.",
            "status": "DIAGNOSTIC",
            "boundary": "Uses D, therefore not native."
        },
        {
            "category": "Rejected",
            "claim": "R208M proves the mass hierarchy.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no final action derivation."
        },
        {
            "category": "Rejected",
            "claim": "R208M proves the two support channels exist.",
            "status": "NO",
            "boundary": "It derives the consequence of the premise, not the premise."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def build_report(
    created_utc: str,
    verdict: str,
    mechanism_summary: pd.DataFrame,
    req_summary: pd.DataFrame,
    random_summary: dict,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R208M — Binary/Sqrt2 Amplitude Degeneracy Mechanism Test

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R208M tests whether the sqrt2 correction can be derived from two-channel area-write amplitude accounting.

Core derivation:
For two orthogonal channels with shares p and 1-p:

N_eff = 1 / (p^2 + (1-p)^2)

tax = 1/2 ln(N_eff)

For p = 1/2:

N_eff = 2
tax = 1/2 ln2 = ln(sqrt2)

Therefore:

L_eff = 3pi - 1/2 ln2

This derives the sqrt2 tax conditionally.
It does not prove the two-channel premise.

Key constants:
D target context        = {D_TARGET}
top/e target context    = {TOP_E_TARGET}
3pi                     = {THREE_PI}
ln2                     = {LN2}
1/2 ln2                 = {0.5 * LN2}
3pi - 1/2 ln2           = {THREE_PI - 0.5 * LN2}
sqrt2                   = {SQRT2}

Mechanism summary:
{mechanism_summary.to_string(index=False)}

Required channel inference:
{req_summary.to_string(index=False)}

Random split null summary:
{json.dumps(random_summary, indent=2)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
R208M conditionally derives the sqrt2 tax from equal two-channel amplitude participation.

This is a mechanism success only if the two channels are later derived from the master action, spinor support, frame holonomy, or boundary write bookkeeping.

The strongest safe statement is:
If a closed-particle write is split across two equal orthogonal support channels, the feedback load is reduced by ln(sqrt2), giving:

L_eff = 3pi - 1/2 ln2

This matches the D-scale endpoint very closely, but D was not used to derive the tax.

Ruling:
No V12.13 promotion.

Next recommended run:
R209M — Two-Channel Support Origin Gate

Question:
Can the two orthogonal support channels be derived from the 4pi spinor closure, frame/gauge holonomy, or no-overwrite boundary write accounting?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    modes = build_modes()
    geometry = add_geometry_signal(modes)
    target_geometry = add_targets(geometry)

    taxes = mechanism_tax_candidates(target_geometry)
    outputs = evaluate_mechanisms(target_geometry, taxes)
    mechanism_summary = summarize_mechanisms(outputs)

    req = required_channel_inference(target_geometry)
    req_summary = summarize_required_channel_inference(req)

    nulls = random_split_null(target_geometry)
    null_summary = random_null_summary(nulls)

    gates = gate_matrix()
    claims = claim_boundary()

    equal_two = mechanism_summary[mechanism_summary["mechanism_id"] == "equal_two_channel_sqrt2_tax"].iloc[0]
    d_req = req_summary[req_summary["target_name"] == "D_rhopower"].iloc[0]

    verdict = (
        "PARTIAL_PASS_SQRT2_TAX_CONDITIONALLY_DERIVED_FROM_EQUAL_TWO_CHANNEL_AMPLITUDE_ACCOUNTING_"
        "D_ENDPOINT_COMPATIBLE_TWO_CHANNEL_PREMISE_NOT_YET_ACTION_DERIVED_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "three_pi": THREE_PI,
            "ln2": LN2,
            "half_ln2": 0.5 * LN2,
            "sqrt2": SQRT2,
            "three_pi_minus_half_ln2": THREE_PI - 0.5 * LN2,
            "K_req_half": HALF_K_REQ,
            "p_D": P_D,
            "p_top": P_TOP,
        },
        "equal_two_channel_result": {
            "mechanism_id": str(equal_two["mechanism_id"]),
            "mean_N_eff": float(equal_two["mean_N_eff"]),
            "mean_amplitude_tax": float(equal_two["mean_amplitude_tax"]),
            "mean_c_ln2": float(equal_two["mean_c_ln2"]),
            "mean_L_eff": float(equal_two["mean_L_eff"]),
            "endpoint_rho2": float(equal_two["endpoint_rho2"]),
            "endpoint_vs_D_factor": float(equal_two["endpoint_vs_D_factor"]),
            "endpoint_log_error_vs_D": float(equal_two["endpoint_log_error_vs_D"]),
            "rmse_log_vs_D_target": float(equal_two["rmse_log_vs_D_target"]),
        },
        "D_required_two_channel_inference": {
            "endpoint_c_required_rho2": float(d_req["endpoint_c_required_rho2"]),
            "endpoint_N_eff_required": float(d_req["endpoint_N_eff_required"]),
            "endpoint_two_channel_possible": bool(d_req["endpoint_two_channel_possible"]),
            "endpoint_p_high_required": float(d_req["endpoint_p_high_required"]),
            "endpoint_p_low_required": float(d_req["endpoint_p_low_required"]),
            "endpoint_imbalance_required": float(d_req["endpoint_imbalance_required"]),
            "endpoint_distance_to_equal_sqrt2": float(d_req["endpoint_distance_to_equal_sqrt2"]),
        },
        "best_mechanisms_by_D_rmse": mechanism_summary.head(12).to_dict(orient="records"),
        "required_channel_inference_summary": req_summary.to_dict(orient="records"),
        "random_split_null_summary": null_summary,
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R209M - Two-Channel Support Origin Gate",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R208M_mechanism_summary.csv",
            "tables/R208M_required_channel_inference_summary.csv",
            "Any traceback if the run failed."
        ],
    }

    modes.to_csv(tables / "R208M_mode_geometry_inputs.csv", index=False)
    geometry.to_csv(tables / "R208M_geometry_signal.csv", index=False)
    taxes.to_csv(tables / "R208M_mechanism_tax_candidates.csv", index=False)
    outputs.to_csv(tables / "R208M_mechanism_model_outputs.csv", index=False)
    mechanism_summary.to_csv(tables / "R208M_mechanism_summary.csv", index=False)
    req.to_csv(tables / "R208M_required_channel_inference_by_mode.csv", index=False)
    req_summary.to_csv(tables / "R208M_required_channel_inference_summary.csv", index=False)
    nulls.to_csv(tables / "R208M_random_two_channel_split_null.csv", index=False)
    gates.to_csv(tables / "R208M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R208M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        mechanism_summary=mechanism_summary.head(12),
        req_summary=req_summary,
        random_summary=null_summary,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(final_payload, indent=2))


if __name__ == "__main__":
    main()
