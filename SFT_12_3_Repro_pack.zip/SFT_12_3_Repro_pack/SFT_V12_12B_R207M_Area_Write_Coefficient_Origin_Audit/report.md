
# SFT V12.12B R207M — Area-Write Coefficient Origin Audit

Generated: 2026-06-18T02:13:39Z

Verdict:
PARTIAL_PASS_LN2_CORRECTION_FAMILY_IDENTIFIED_SQRT2_AMPLITUDE_DEGENERACY_LEADS_D_ENDPOINT_BINARY_BRANCH_SPLIT_REMAINS_CURVE_SHAPE_CANDIDATE_NATIVE_ORIGIN_NOT_DERIVED_NO_V12_13

Purpose:
R206M found that the D-scale endpoint is very close to:
G_i * exp((3pi - 1/2 ln2) * u_i)

and the whole-curve shape leaned toward:
G_i * exp((3pi - ln2) * u_i)

R207M tests whether the correction to 3pi behaves like an ln2-family correction:
3pi - c ln2

Key diagnostic constants:
D target context      = 17877.208689571427
top/e target context  = 339000.0
3pi                   = 9.42477796076938
ln2                   = 0.6931471805599453
1/2 ln2               = 0.34657359027997264
3pi - 1/2 ln2         = 9.078204370489408
3pi - ln2             = 8.731630780209434
K_req / 2             = 9.445294449043432

Best origin scorecard:
            coord_name                  origin_id  correction_c_ln2  load_value  endpoint_vs_D_factor  rmse_log_vs_D_target  endpoint_error_log_abs                                       mechanical_reading  score                              ruling
              u_logrho sqrt2_amplitude_degeneracy          0.500000    9.078204              0.980267              0.710228                0.019930  half-action feedback divided by sqrt2 amplitude channel   10.0 diagnostic_candidate_not_derivation
                sqrt_u sqrt2_amplitude_degeneracy          0.500000    9.078204              0.980267              1.977401                0.019930  half-action feedback divided by sqrt2 amplitude channel    6.5 diagnostic_candidate_not_derivation
              u_logrho        binary_branch_split          1.000000    8.731631              0.693153              0.579575                0.366504 half-action feedback divided by a binary branch factor 2    6.0 diagnostic_candidate_not_derivation
              u_logrho three_quarter_binary_split          0.750000    8.904918              0.824303              0.638612                0.193217                             intermediate branch dilution    5.0 diagnostic_candidate_not_derivation
              u_logrho       quarter_binary_split          0.250000    9.251491              1.165740              0.791012                0.153356                          weak binary dilution correction    4.0 diagnostic_candidate_not_derivation
              u_logrho                       none          0.000000    9.424778              1.386307              0.878440                0.326643                                pure half-action feedback    4.0 diagnostic_candidate_not_derivation
              u_logrho                  Kreq_half         -0.029599    9.445294              1.415043              0.889140                0.347160                                 half of K_req diagnostic    4.0 diagnostic_candidate_not_derivation
              u_logrho          two_binary_splits          2.000000    8.038484              0.346577              0.543158                1.059651                  two independent binary dilution factors    4.0 diagnostic_candidate_not_derivation
         slot_pressure sqrt2_amplitude_degeneracy          0.500000    9.078204             20.209196              5.137729                3.006138  half-action feedback divided by sqrt2 amplitude channel    4.0 diagnostic_candidate_not_derivation
      support_pressure sqrt2_amplitude_degeneracy          0.500000    9.078204           8589.312686              3.645659                9.058274  half-action feedback divided by sqrt2 amplitude channel    3.5 diagnostic_candidate_not_derivation
concentration_pressure sqrt2_amplitude_degeneracy          0.500000    9.078204           8589.312686              3.982196                9.058274  half-action feedback divided by sqrt2 amplitude channel    3.5 diagnostic_candidate_not_derivation
           u_times_rho sqrt2_amplitude_degeneracy          0.500000    9.078204           8589.312686              4.141479                9.058274  half-action feedback divided by sqrt2 amplitude channel    3.5 diagnostic_candidate_not_derivation

Best model summary by D diagnostic:
            coord_name                  origin_id                                       mechanical_reading  correction_c_ln2  load_value  endpoint_rho2  endpoint_vs_D_factor  endpoint_vs_top_e_factor  span_max_over_min  rmse_log_vs_D_target  rmse_log_vs_top_e_target                                          claim_boundary
              u_logrho          two_binary_splits                  two independent binary dilution factors          2.000000    8.038484    6195.823904              0.346577                  0.018277        6195.823904              0.543158                  2.125429                              likely too much correction
              u_logrho        binary_branch_split half-action feedback divided by a binary branch factor 2          1.000000    8.731631   12391.647808              0.693153                  0.036554       12391.647808              0.579575                  1.697676                best R206 curve-shape RMSE; endpoint low
              u_logrho three_quarter_binary_split                             intermediate branch dilution          0.750000    8.904918   14736.235740              0.824303                  0.043470       14736.235740              0.638612                  1.592157                          interpolation only; not native
              u_logrho sqrt2_amplitude_degeneracy  half-action feedback divided by sqrt2 amplitude channel          0.500000    9.078204   17524.436390              0.980267                  0.051695       17524.436390              0.710228                  1.487449 best D endpoint match in R206; origin still not derived
              u_logrho       quarter_binary_split                          weak binary dilution correction          0.250000    9.251491   20840.184442              1.165740                  0.061475       20840.184442              0.791012                  1.383735          tests whether correction is smaller than sqrt2
              u_logrho                       none                                pure half-action feedback          0.000000    9.424778   24783.295616              1.386307                  0.073107       24783.295616              0.878440                  1.281258           overshoots D endpoint; no dilution correction
              u_logrho                  Kreq_half                                 half of K_req diagnostic         -0.029599    9.445294   25297.013635              1.415043                  0.074622       25297.013635              0.889140                  1.269221                     uses K_req context; diagnostic only
                sqrt_u                     two_pi                                      phase holonomy only          4.532360    6.283185    1070.983311              0.059908                  0.003159        1742.790605              1.310473                  2.811304                                 too weak for D endpoint
concentration_pressure                     two_pi                                      phase holonomy only          4.532360    6.283185  573502.626273             32.080099                  1.691748      573502.626273              1.328882                  1.423562                                 too weak for D endpoint
      support_pressure                     two_pi                                      phase holonomy only          4.532360    6.283185  573502.626273             32.080099                  1.691748      573502.626273              1.368442                  1.936191                                 too weak for D endpoint
              u_logrho                     two_pi                                      phase holonomy only          4.532360    6.283185    1070.983311              0.059908                  0.003159        1169.847333              1.399125                  3.228746                                 too weak for D endpoint
                sqrt_u          two_binary_splits                  two independent binary dilution factors          2.000000    8.038484    6195.823904              0.346577                  0.018277        8946.770768              1.440330                  1.838081                              likely too much correction

Required correction summary:
            coord_name        target_name  mean_c_required  std_c_required  cv_c_required  endpoint_c_required_rho2  endpoint_distance_to_c_0_5  endpoint_distance_to_c_1  endpoint_distance_to_c_2
              u_logrho         D_rhopower         2.248638        1.698617       0.755398                  0.471247                    0.028753              5.287534e-01                  1.528753
         slot_pressure         D_rhopower         6.803124        2.121795       0.311885                  3.752705                    3.252705              2.752705e+00                  1.752705
concentration_pressure         D_rhopower         5.637515        1.168121       0.207205                  7.034163                    6.534163              6.034163e+00                  5.034163
      support_pressure         D_rhopower         4.892239        1.681004       0.343606                  7.034163                    6.534163              6.034163e+00                  5.034163
              u_logrho  half_6pi_rhopower         2.777391        1.698617       0.611587                  1.000000                    0.500000              2.220446e-16                  1.000000
         slot_pressure  half_6pi_rhopower         7.113767        2.070757       0.291091                  4.149270                    3.649270              3.149270e+00                  2.149270
concentration_pressure  half_6pi_rhopower         6.018700        1.101648       0.183038                  7.298540                    6.798540              6.298540e+00                  5.298540
      support_pressure  half_6pi_rhopower         5.309093        1.595368       0.300497                  7.298540                    6.798540              6.298540e+00                  5.298540
              u_logrho half_Kreq_rhopower         2.747792        1.698617       0.618175                  0.970401                    0.470401              2.959904e-02                  1.029599
         slot_pressure half_Kreq_rhopower         7.096378        2.073610       0.292207                  4.127071                    3.627071              3.127071e+00                  2.127071
concentration_pressure half_Kreq_rhopower         5.997362        1.105293       0.184297                  7.283741                    6.783741              6.283741e+00                  5.283741
      support_pressure half_Kreq_rhopower         5.285758        1.600105       0.302720                  7.283741                    6.783741              6.283741e+00                  5.283741
         slot_pressure     top_e_rhopower         4.309133        2.536160       0.588555                  0.568886                    0.068886              4.311139e-01                  1.431114
              u_logrho     top_e_rhopower        -1.996454        1.698617       0.850817                 -3.773845                    4.273845              4.773845e+00                  5.773845
concentration_pressure     top_e_rhopower         2.577171        1.768291       0.686137                  4.911618                    4.411618              3.911618e+00                  2.911618
      support_pressure     top_e_rhopower         1.545534        2.420224       1.565947                  4.911618                    4.411618              3.911618e+00                  2.911618

Gate matrix:
                      gate                                                                test                    status                                             boundary
                ln2_origin Can the correction to 3pi be written as c ln2 with c near 1/2 or 1?                    TESTED             Numeric match only; no native proof yet.
sqrt2_amplitude_degeneracy                     3pi - 1/2 ln2 corresponds to division by sqrt2.            LIVE_CANDIDATE Strong endpoint match; mechanical origin still open.
       binary_branch_split                             3pi - ln2 corresponds to division by 2.            LIVE_CANDIDATE             Better curve RMSE in R206; endpoint low.
               full_action                                 4pi or 6pi as feedback coefficient. REJECT_AS_DIRECT_FEEDBACK                   Too strong for D-scale diagnostic.
                     top_e                                               Top/e target closure.                      OPEN                   Top/e still needs extra structure.
                    V12_13                                                          Promotion.                        NO    Need native derivation of correction coefficient.

Claim boundary:
 category                                                                       claim          status                                     boundary
Preserved The correction to 3pi is naturally expressible as an ln2-family correction. DIAGNOSTIC_PASS                   Numerical diagnostic only.
Preserved             sqrt2 amplitude degeneracy is the leading D-endpoint candidate.  LIVE_CANDIDATE                             Not yet derived.
Preserved                  binary branch split remains live for curve-shape behavior.  LIVE_CANDIDATE                     Endpoint under-shoots D.
 Rejected                                           R207M derives the mass hierarchy.              NO No species map, no native coefficient proof.
 Rejected                                                         R207M solves top/e.              NO                   Top/e needs another layer.
Promotion                                                           V12.13 promotion.              NO                              Not yet earned.

Interpretation:
The correction is not random-looking. It lands in the ln2 family.

The best D endpoint candidate is:
3pi - 1/2 ln2

Mechanical reading:
half-action feedback divided by sqrt2 amplitude degeneracy.

The best curve-shape clue from R206 leaned toward:
3pi - ln2

Mechanical reading:
half-action feedback divided by a full binary branch factor.

This is a strong diagnostic, not a derivation.

Ruling:
No V12.13 promotion.

Next recommended run:
R208M — Binary/Sqrt2 Amplitude Degeneracy Mechanism Test

Question:
Can sqrt2 or binary branch dilution be derived from the per-cycle area-write accounting,
without using D as input?
