#!/usr/bin/env python3
"""
SFT V12.12B R223M — Action-Level Premise Closure Audit

Purpose:
    R222M wrote the symbolic conditional theorem:

        A1. D-scale trace lane is saturated.
        A2. No-overwrite minimality applies.
        A3. Top terminal completion must close both real support sectors.
        A4. Full support closure measure is 4π + 2π.
        A5. Terminal completion is untaxed.

    Therefore:

        K_top = 4π + 2π = 6π

    R223M audits the remaining weak premises:

        A1 — Can D-scale saturation be stated as an action-level endpoint condition?
        A3 — Can both-sector terminal closure be forced by support closure logic?
        A5 — Can untaxed terminal completion be separated from D-scale amplitude tax?

Rules:
    - no species labels
    - no empirical particle mass fitting
    - top/e is diagnostic context only
    - exact top/e gap cannot define the law
    - no V12.13 promotion

Expected result:
    A3 and A5 may strengthen.
    A1 likely remains the main open action-level blocker.

Outputs:
    SFT_V12_12B_R223M_Action_Level_Premise_Closure_Audit/
        report.md
        premise_closure_note.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R223M.py

    SFT_V12_12B_R223M_Action_Level_Premise_Closure_Audit_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R223M_Action_Level_Premise_Closure_Audit"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF_FREEZE = 25.0 / 13.0
AMPLITUDE_TAX_FREEZE = 0.5 * math.log(N_EFF_FREEZE)
L_EFF_FREEZE = THREE_PI - AMPLITUDE_TAX_FREEZE
G_ENDPOINT_RHO2 = 2.0
D_SCALE_ENDPOINT = G_ENDPOINT_RHO2 * math.exp(L_EFF_FREEZE)

TOP_GAP_EXACT = TOP_E_TARGET / D_SCALE_ENDPOINT
TOP_GAP_LOG = math.log(TOP_GAP_EXACT)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def top_prediction(multiplier: float) -> dict:
    predicted = D_SCALE_ENDPOINT * multiplier
    factor = predicted / TOP_E_TARGET
    log_error = abs(math.log(factor)) if factor > 0 else float("inf")

    return {
        "multiplier": multiplier,
        "log_multiplier": math.log(multiplier) if multiplier > 0 else None,
        "predicted_top_e_scale": predicted,
        "predicted_top_e_vs_target_factor": factor,
        "top_e_log_error_abs": log_error,
        "top_e_percent_error": 100.0 * (factor - 1.0),
        "residual_multiplier_to_exact_gap": TOP_GAP_EXACT - multiplier,
        "residual_percent_of_exact_gap": 100.0 * ((TOP_GAP_EXACT - multiplier) / TOP_GAP_EXACT),
    }


def score_premise(
    base: float,
    formal: bool = False,
    action_route: bool = False,
    no_top_fit: bool = True,
    no_D_fit: bool = True,
    rejects_nulls: bool = False,
    still_open: bool = True,
) -> float:
    score = base

    if formal:
        score += 4.0
    if action_route:
        score += 5.0
    if no_top_fit:
        score += 2.0
    else:
        score -= 10.0
    if no_D_fit:
        score += 2.0
    else:
        score -= 6.0
    if rejects_nulls:
        score += 3.0
    if still_open:
        score -= 2.0

    return score


def A1_saturation_routes() -> pd.DataFrame:
    rows = [
        {
            "route_id": "A1_u_domain_endpoint",
            "premise": "D-scale trace lane saturation",
            "route": "Treat u as a normalized trace-lane coordinate with admissible domain 0 <= u <= 1. Saturation occurs at u=1.",
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "formal_status": "ACTION_BOUNDARY_ROUTE",
            "supports_A1": True,
            "reject_reason": "",
            "risk": "The global action must still derive the u-domain and endpoint condition.",
            "base_score": 8.0,
        },
        {
            "route_id": "A1_trace_capacity_endpoint",
            "premise": "D-scale trace lane saturation",
            "route": "The R218 trace-variational lane exhausts internal branch participation capacity; terminal completion becomes admissible only after internal trace compounding is complete.",
            "uses_top_to_define": False,
            "uses_D_to_define": False,
            "formal_status": "MECHANICAL_ROUTE",
            "supports_A1": True,
            "reject_reason": "",
            "risk": "Capacity exhaustion needs action-level definition.",
            "base_score": 7.0,
        },
        {
            "route_id": "A1_exact_D_endpoint_fit",
            "premise": "D-scale trace lane saturation",
            "route": "Declare saturation because endpoint numerically matches D.",
            "uses_top_to_define": False,
            "uses_D_to_define": True,
            "formal_status": "REJECT_AS_DERIVATION",
            "supports_A1": False,
            "reject_reason": "Uses D diagnostic and cannot define saturation.",
            "risk": "Fitting risk.",
            "base_score": -6.0,
        },
        {
            "route_id": "A1_top_e_backsolved_saturation",
            "premise": "D-scale trace lane saturation",
            "route": "Declare saturation from top/e gap behavior.",
            "uses_top_to_define": True,
            "uses_D_to_define": False,
            "formal_status": "REJECT_AS_DERIVATION",
            "supports_A1": False,
            "reject_reason": "Uses top/e context and cannot define saturation.",
            "risk": "Hard fitting risk.",
            "base_score": -8.0,
        },
    ]

    out = []
    for row in rows:
        formal = row["formal_status"] in ["ACTION_BOUNDARY_ROUTE", "MECHANICAL_ROUTE"]
        action_route = row["formal_status"] == "ACTION_BOUNDARY_ROUTE"
        still_open = row["supports_A1"]
        row["premise_score"] = score_premise(
            base=row["base_score"],
            formal=formal,
            action_route=action_route,
            no_top_fit=not row["uses_top_to_define"],
            no_D_fit=not row["uses_D_to_define"],
            rejects_nulls=not row["supports_A1"],
            still_open=still_open,
        )
        out.append(row)

    return pd.DataFrame(out).sort_values("premise_score", ascending=False).reset_index(drop=True)


def A3_sector_closure_tests() -> pd.DataFrame:
    rows = [
        {
            "test_id": "both_sector_closure",
            "completion": "4π spatial/spinor + 2π frame/gauge",
            "K": SIX_PI,
            "space_closed": True,
            "phase_closed": True,
            "terminal_state": True,
            "single_sector_gap": False,
            "status": "PROMOTE_FORMAL_ACTION_ROUTE",
            "ruling": "Only both-sector closure can be terminal under real-support completion.",
            "base_score": 12.0,
        },
        {
            "test_id": "space_only_4pi",
            "completion": "4π spatial/spinor only",
            "K": FOUR_PI,
            "space_closed": True,
            "phase_closed": False,
            "terminal_state": False,
            "single_sector_gap": True,
            "status": "REJECT_INCOMPLETE",
            "ruling": "Leaves frame/gauge phase sector open.",
            "base_score": 1.0,
        },
        {
            "test_id": "phase_only_2pi",
            "completion": "2π frame/gauge only",
            "K": TWO_PI,
            "space_closed": False,
            "phase_closed": True,
            "terminal_state": False,
            "single_sector_gap": True,
            "status": "REJECT_INCOMPLETE",
            "ruling": "Leaves spatial/spinor curvature sector open.",
            "base_score": 1.0,
        },
        {
            "test_id": "half_action_3pi",
            "completion": "3π half-action proxy",
            "K": THREE_PI,
            "space_closed": False,
            "phase_closed": False,
            "terminal_state": False,
            "single_sector_gap": True,
            "status": "REJECT_INCOMPLETE",
            "ruling": "Does not equal closure of both physical sectors.",
            "base_score": 1.0,
        },
        {
            "test_id": "no_terminal_closure",
            "completion": "zero additional closure",
            "K": 0.0,
            "space_closed": False,
            "phase_closed": False,
            "terminal_state": False,
            "single_sector_gap": True,
            "status": "REJECT_UNDERCLOSURE",
            "ruling": "No terminal completion.",
            "base_score": -2.0,
        },
        {
            "test_id": "duplicate_both_sector_closure",
            "completion": "two copies of 4π+2π",
            "K": 2.0 * SIX_PI,
            "space_closed": True,
            "phase_closed": True,
            "terminal_state": False,
            "single_sector_gap": False,
            "status": "REJECT_DUPLICATE",
            "ruling": "Terminal closure is duplicated rather than minimal.",
            "base_score": 0.0,
        },
    ]

    out = []
    for row in rows:
        row["top_prediction_factor"] = top_prediction(row["K"])["predicted_top_e_vs_target_factor"] if row["K"] > 0 else D_SCALE_ENDPOINT / TOP_E_TARGET
        row["top_prediction_percent_error"] = 100.0 * (row["top_prediction_factor"] - 1.0)
        row["premise_score"] = score_premise(
            base=row["base_score"],
            formal=row["space_closed"] or row["phase_closed"],
            action_route=row["terminal_state"],
            no_top_fit=True,
            no_D_fit=True,
            rejects_nulls=not row["terminal_state"],
            still_open=row["terminal_state"],
        )
        out.append(row)

    return pd.DataFrame(out).sort_values("premise_score", ascending=False).reset_index(drop=True)


def A5_tax_separation_tests() -> pd.DataFrame:
    rows = [
        {
            "test_id": "terminal_completion_Neff_1",
            "category": "terminal_completion",
            "description": "Terminal closure is a deterministic completion, not a branch-sharing amplitude ensemble.",
            "N_eff": 1.0,
            "tax": 0.0,
            "K": SIX_PI,
            "status": "PROMOTE_ACTION_CATEGORY_ROUTE",
            "ruling": "Untaxed terminal completion is category-consistent.",
            "base_score": 12.0,
        },
        {
            "test_id": "D_scale_branch_participation_tax",
            "category": "branch_participation",
            "description": "D-scale internal trace lane has two protected sectors with shares 3:2 and N_eff=25/13.",
            "N_eff": N_EFF_FREEZE,
            "tax": AMPLITUDE_TAX_FREEZE,
            "K": L_EFF_FREEZE,
            "status": "VALID_FOR_D_SCALE_ONLY",
            "ruling": "Tax belongs to branch participation, not terminal completion.",
            "base_score": 9.0,
        },
        {
            "test_id": "taxed_minus_terminal_control",
            "category": "category_mixing_control",
            "description": "Apply D-scale tax to terminal closure: 6π - tax.",
            "N_eff": N_EFF_FREEZE,
            "tax": AMPLITUDE_TAX_FREEZE,
            "K": SIX_PI - AMPLITUDE_TAX_FREEZE,
            "status": "REJECT_AS_PRIMARY",
            "ruling": "Reuses branch tax in terminal completion category.",
            "base_score": 1.0,
        },
        {
            "test_id": "taxed_plus_terminal_control",
            "category": "category_mixing_control",
            "description": "Add D-scale tax to terminal closure: 6π + tax.",
            "N_eff": N_EFF_FREEZE,
            "tax": -AMPLITUDE_TAX_FREEZE,
            "K": SIX_PI + AMPLITUDE_TAX_FREEZE,
            "status": "REJECT_AS_PRIMARY",
            "ruling": "Adds branch tax to terminal completion without action reason.",
            "base_score": 1.0,
        },
        {
            "test_id": "exact_gap_as_tax_control",
            "category": "forbidden_fit_control",
            "description": "Infer an effective tax from exact top/e gap.",
            "N_eff": None,
            "tax": SIX_PI - TOP_GAP_EXACT,
            "K": TOP_GAP_EXACT,
            "status": "REJECT_AS_DERIVATION",
            "ruling": "Uses top/e and cannot define terminal tax.",
            "base_score": -8.0,
        },
    ]

    out = []
    for row in rows:
        pred = top_prediction(row["K"]) if row["K"] > 0 else {}
        row["predicted_top_e_vs_target_factor"] = pred.get("predicted_top_e_vs_target_factor")
        row["top_e_percent_error"] = pred.get("top_e_percent_error")

        row["premise_score"] = score_premise(
            base=row["base_score"],
            formal=True,
            action_route=row["status"] == "PROMOTE_ACTION_CATEGORY_ROUTE",
            no_top_fit=row["status"] != "REJECT_AS_DERIVATION",
            no_D_fit=True,
            rejects_nulls=row["status"].startswith("REJECT"),
            still_open=row["status"] == "PROMOTE_ACTION_CATEGORY_ROUTE",
        )
        out.append(row)

    return pd.DataFrame(out).sort_values("premise_score", ascending=False).reset_index(drop=True)


def premise_closure_matrix(A1: pd.DataFrame, A3: pd.DataFrame, A5: pd.DataFrame) -> pd.DataFrame:
    best_A1 = A1.iloc[0].to_dict()
    best_A3 = A3.iloc[0].to_dict()
    best_A5 = A5.iloc[0].to_dict()

    return pd.DataFrame([
        {
            "axiom_id": "A1",
            "premise": "D-scale saturation",
            "before_R223": "ASSUMED_FROM_R218",
            "best_R223_route": best_A1["route_id"],
            "after_R223": "ACTION_BOUNDARY_ROUTE_PARTIAL_PASS",
            "score": best_A1["premise_score"],
            "remaining_gap": "Global action still must derive u-domain endpoint/saturation condition.",
            "promotion": "PARTIAL_PROMOTION",
        },
        {
            "axiom_id": "A2",
            "premise": "No-overwrite minimality",
            "before_R223": "SFT_CORE_PREMISE",
            "best_R223_route": "unchanged",
            "after_R223": "CORE_PREMISE_PRESERVED",
            "score": None,
            "remaining_gap": "Needs final embedding in full action, but not the focus of R223.",
            "promotion": "PRESERVED",
        },
        {
            "axiom_id": "A3",
            "premise": "Both-sector terminal closure",
            "before_R223": "CONDITIONAL_PREMISE",
            "best_R223_route": best_A3["test_id"],
            "after_R223": "PROMOTE_FORMAL_ACTION_ROUTE",
            "score": best_A3["premise_score"],
            "remaining_gap": "Need theorem that top terminal state necessarily requires no open real support sector.",
            "promotion": "PROMOTED_TO_FORMAL_ACTION_ROUTE",
        },
        {
            "axiom_id": "A4",
            "premise": "Full closure measure 4π+2π",
            "before_R223": "FORMAL_PASS",
            "best_R223_route": "unchanged",
            "after_R223": "FORMAL_PASS_PRESERVED",
            "score": None,
            "remaining_gap": "Tie closure measure to terminal load term in full action.",
            "promotion": "PRESERVED",
        },
        {
            "axiom_id": "A5",
            "premise": "Terminal completion untaxed",
            "before_R223": "CONDITIONAL_PASS",
            "best_R223_route": best_A5["test_id"],
            "after_R223": "PROMOTE_ACTION_CATEGORY_ROUTE",
            "score": best_A5["premise_score"],
            "remaining_gap": "Need explicit action split between branch participation tax and terminal completion term.",
            "promotion": "PROMOTED_TO_ACTION_CATEGORY_ROUTE",
        },
    ])


def theorem_status_after_audit(premises: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame([
        {
            "theorem_id": "T1",
            "statement": "A1-A5 imply unique minimal nonzero untaxed terminal completion K_top=6π.",
            "before_R223": "SYMBOLIC_CONDITIONAL_PASS",
            "after_R223": "SYMBOLIC_CONDITIONAL_PASS_TIGHTENED",
            "stronger_after_R223": True,
            "why_stronger": "A3 promoted to formal action route; A5 promoted to action category route; A1 gets an action-boundary route.",
            "still_missing": "Full global action derivation of A1 endpoint, A3 terminal necessity, and A5 explicit action split.",
            "top_e_closed": False,
            "V12_13": False,
        }
    ])


def residual_analysis() -> pd.DataFrame:
    residual = TOP_GAP_EXACT - SIX_PI
    return pd.DataFrame([
        {
            "quantity": "exact_gap_minus_6pi",
            "value": residual,
            "ruling": "OPEN_DIAGNOSTIC_ONLY",
            "comment": "Residual remains after lead 6π theorem candidate."
        },
        {
            "quantity": "percent_gap_above_6pi",
            "value": 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0),
            "ruling": "OPEN_DIAGNOSTIC_ONLY",
            "comment": "Do not fit until premises are fully action-derived."
        },
        {
            "quantity": "sixpi_predicted_top_e",
            "value": D_SCALE_ENDPOINT * SIX_PI,
            "ruling": "DIAGNOSTIC_SUPPORTIVE",
            "comment": "Prediction from frozen D endpoint times one 6π layer."
        },
        {
            "quantity": "sixpi_predicted_top_e_vs_target",
            "value": (D_SCALE_ENDPOINT * SIX_PI) / TOP_E_TARGET,
            "ruling": "DIAGNOSTIC_SUPPORTIVE",
            "comment": "Top/e context is diagnostic only."
        },
        {
            "quantity": "legacy_Kreq_predicted_top_e_vs_target",
            "value": (D_SCALE_ENDPOINT * K_REQ) / TOP_E_TARGET,
            "ruling": "SUPPORTIVE_BRIDGE",
            "comment": "K_req remains supportive but not theorem-derived."
        },
    ])


def open_claims_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "open_claim": "global_action_A1_saturation",
            "status": "OPEN_PARTIALLY_NARROWED",
            "current_best_route": "u-domain endpoint / trace-capacity endpoint.",
            "why_open": "R223 gives an action-boundary route but not a global variational proof.",
            "required_next": "Write saturation as a boundary condition in the master action.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "global_action_A3_terminal_necessity",
            "status": "OPEN_PARTIALLY_NARROWED",
            "current_best_route": "terminal state cannot leave either real support sector open.",
            "why_open": "R223 promotes this as formal action route but not final theorem.",
            "required_next": "Show top terminal state requires no open spatial/spinor or frame/gauge support.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "global_action_A5_tax_split",
            "status": "OPEN_PARTIALLY_NARROWED",
            "current_best_route": "branch participation tax applies to internal trace compounding; terminal completion has N_eff=1 and tax=0.",
            "why_open": "R223 promotes category separation but not full action split.",
            "required_next": "Write separate action terms for branch participation and terminal closure.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "residual_gap",
            "status": "OPEN",
            "current_best_route": "Residual 0.6324% above 6π.",
            "why_open": "Do not fit residual before global action premise closure.",
            "required_next": "Defer residual analysis.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "species_map",
            "status": "OPEN",
            "current_best_route": "Deferred.",
            "why_open": "No species labels used.",
            "required_next": "Later species map constraint skeleton.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "prediction_null_suite",
            "status": "OPEN",
            "current_best_route": "Not addressed.",
            "why_open": "No external no-retuning test yet.",
            "required_next": "Build prediction/null suite.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "V12_13_promotion",
            "status": "NO",
            "current_best_route": "Not eligible.",
            "why_open": "Top/e not fully closed and species/predictions remain open.",
            "required_next": "No promotion.",
            "promotion_blocker": True,
        },
    ])


def claim_boundary_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Allowed claim",
            "claim": "R223M tightens the symbolic conditional theorem by auditing A1, A3, and A5.",
            "status": "YES",
            "safe_wording": "Theorem tightened, not fully closed."
        },
        {
            "category": "Allowed claim",
            "claim": "A3 is promoted to a formal action-route candidate.",
            "status": "YES",
            "safe_wording": "Terminal closure cannot leave a real support sector open."
        },
        {
            "category": "Allowed claim",
            "claim": "A5 is promoted to an action-category separation candidate.",
            "status": "YES",
            "safe_wording": "Branch tax and terminal completion are different action categories."
        },
        {
            "category": "Allowed claim",
            "claim": "A1 receives a partial action-boundary route.",
            "status": "YES",
            "safe_wording": "Saturation as u-domain endpoint remains to be globally proven."
        },
        {
            "category": "Blocked claim",
            "claim": "Top/e is solved.",
            "status": "NO",
            "safe_wording": "Global action closure and residual remain open."
        },
        {
            "category": "Blocked claim",
            "claim": "The full global action theorem is complete.",
            "status": "NO",
            "safe_wording": "A1/A3/A5 still need final action derivation."
        },
        {
            "category": "Blocked claim",
            "claim": "Species map is derived.",
            "status": "NO",
            "safe_wording": "Species map remains open."
        },
        {
            "category": "Blocked claim",
            "claim": "V12.13 is promoted.",
            "status": "NO",
            "safe_wording": "No V12.13 promotion."
        },
    ])


def premise_closure_note_text(created_utc: str) -> str:
    return f"""
# R223M Action-Level Premise Closure Audit Note

Generated: {created_utc}

## Starting theorem from R222

A1-A5 imply:

    K_top = 4pi + 2pi = 6pi

with top/e diagnostic:

    D_scale_endpoint * 6pi = {D_SCALE_ENDPOINT * SIX_PI}
    factor_vs_top_e_context = {(D_SCALE_ENDPOINT * SIX_PI) / TOP_E_TARGET}

## R223 premise audit

A1 — D-scale saturation:
    Strengthened to an action-boundary route:
        u is a normalized trace-lane coordinate with 0 <= u <= 1.
        Saturation is the endpoint u=1.
    Still open:
        global action must derive the u-domain endpoint.

A3 — both-sector terminal closure:
    Promoted to formal action-route candidate:
        terminal completion cannot leave either real support sector open.
        both spatial/spinor 4pi and frame/gauge 2pi must close.

A5 — terminal completion untaxed:
    Promoted to action-category separation candidate:
        D-scale amplitude tax belongs to branch participation.
        terminal completion is deterministic full closure with N_eff=1 and tax=0.

## Updated theorem status

    SYMBOLIC_CONDITIONAL_PASS_TIGHTENED

Still not:
    full global action theorem
    top/e closure
    species map
    V12.13 promotion
"""


def build_report(
    created_utc: str,
    verdict: str,
    A1: pd.DataFrame,
    A3: pd.DataFrame,
    A5: pd.DataFrame,
    premise_matrix: pd.DataFrame,
    theorem_status: pd.DataFrame,
    residuals: pd.DataFrame,
    open_claims: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R223M — Action-Level Premise Closure Audit

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R223M audits A1, A3, and A5 from the R222 symbolic conditional theorem.

A1 saturation routes:
{A1.to_string(index=False)}

A3 sector closure tests:
{A3.to_string(index=False)}

A5 tax separation tests:
{A5.to_string(index=False)}

Premise closure matrix:
{premise_matrix.to_string(index=False)}

Theorem status after audit:
{theorem_status.to_string(index=False)}

Residual analysis:
{residuals.to_string(index=False)}

Open claims ledger:
{open_claims.to_string(index=False)}

Claim boundary matrix:
{claims.to_string(index=False)}

Interpretation:
R223M tightens the R222 theorem. A3 is promoted from a conditional premise to a formal action-route candidate because a terminal real-support completion cannot leave either spatial/spinor or frame/gauge support open. A5 is promoted to an action-category separation candidate because D-scale branch participation tax and terminal deterministic completion are different action categories. A1 receives a plausible action-boundary route via a normalized trace-lane endpoint u=1, but remains the main global-action burden.

Ruling:
Symbolic theorem tightened.
A1/A3/A5 not fully action-proven.
Top/e not solved.
No species map.
No V12.13 promotion.

Next recommended run:
R224M — Master-Action Patch for Saturation and Terminal Completion Terms

Question:
Can the action be patched with separate internal branch-participation and terminal-completion terms so that A1 and A5 become explicit?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    A1 = A1_saturation_routes()
    A3 = A3_sector_closure_tests()
    A5 = A5_tax_separation_tests()
    premise_matrix = premise_closure_matrix(A1, A3, A5)
    theorem_status = theorem_status_after_audit(premise_matrix)
    residuals = residual_analysis()
    open_claims = open_claims_ledger()
    claims = claim_boundary_matrix()

    verdict = (
        "PARTIAL_PASS_ACTION_LEVEL_PREMISE_CLOSURE_AUDIT_TIGHTENS_R222_THEOREM_"
        "A3_BOTH_SECTOR_TERMINAL_CLOSURE_PROMOTED_TO_FORMAL_ACTION_ROUTE_"
        "A5_UNTAXED_TERMINAL_COMPLETION_PROMOTED_TO_ACTION_CATEGORY_SEPARATION_ROUTE_"
        "A1_SATURATION_GETS_ACTION_BOUNDARY_ROUTE_BUT_REMAINS_GLOBAL_ACTION_OPEN_"
        "TOP_E_NOT_SOLVED_NO_SPECIES_MAP_NO_V12_13"
    )

    best_A1 = A1.iloc[0].to_dict()
    best_A3 = A3.iloc[0].to_dict()
    best_A5 = A5.iloc[0].to_dict()

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "theorem_status": "SYMBOLIC_CONDITIONAL_PASS_TIGHTENED",
        "R222_theorem": {
            "statement": "A1-A5 imply unique minimal nonzero untaxed terminal completion K_top=4*pi+2*pi=6*pi.",
            "K_top_numeric": SIX_PI,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
        },
        "best_A1_route": best_A1,
        "best_A3_route": best_A3,
        "best_A5_route": best_A5,
        "premise_closure_matrix": premise_matrix.to_dict(orient="records"),
        "top_e_context": {
            "top_e_target_context": TOP_E_TARGET,
            "sixpi_predicted_top_e": D_SCALE_ENDPOINT * SIX_PI,
            "sixpi_predicted_top_e_vs_target": (D_SCALE_ENDPOINT * SIX_PI) / TOP_E_TARGET,
            "exact_multiplier_gap": TOP_GAP_EXACT,
            "gap_minus_6pi": TOP_GAP_EXACT - SIX_PI,
            "gap_percent_above_6pi": 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0),
        },
        "residuals": residuals.to_dict(orient="records"),
        "open_claims": open_claims.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "Theorem tightened; top/e not solved; no V12.13.",
        "next_recommended": "R224M - Master-Action Patch for Saturation and Terminal Completion Terms",
        "paste_back_to_chat": [
            "summary.json",
            "premise_closure_note.md",
            "tables/R223M_premise_closure_matrix.csv",
            "tables/R223M_A1_saturation_routes.csv",
            "tables/R223M_A3_sector_closure_tests.csv",
            "tables/R223M_A5_tax_separation_tests.csv",
            "Any traceback if the run failed."
        ],
    }

    A1.to_csv(tables / "R223M_A1_saturation_routes.csv", index=False)
    A3.to_csv(tables / "R223M_A3_sector_closure_tests.csv", index=False)
    A5.to_csv(tables / "R223M_A5_tax_separation_tests.csv", index=False)
    premise_matrix.to_csv(tables / "R223M_premise_closure_matrix.csv", index=False)
    theorem_status.to_csv(tables / "R223M_theorem_status_after_audit.csv", index=False)
    residuals.to_csv(tables / "R223M_residual_analysis.csv", index=False)
    open_claims.to_csv(tables / "R223M_open_claims_ledger.csv", index=False)
    claims.to_csv(tables / "R223M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        A1=A1,
        A3=A3,
        A5=A5,
        premise_matrix=premise_matrix,
        theorem_status=theorem_status,
        residuals=residuals,
        open_claims=open_claims,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "premise_closure_note.md").write_text(premise_closure_note_text(created_utc), encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
