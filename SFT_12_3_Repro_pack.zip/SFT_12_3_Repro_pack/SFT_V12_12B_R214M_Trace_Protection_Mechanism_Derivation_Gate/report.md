
# SFT V12.12B R214M — Trace-Protection Mechanism Derivation Gate

Generated: 2026-06-18T04:22:39Z

Verdict:
PARTIAL_PASS_SYMMETRY_INCOMMENSURABILITY_SUPPORTS_BLOCK_TRACE_PROTECTION_SO3_SO2_PROJECTION_SUPPRESSES_CROSS_TERMS_AND_PRESERVES_SECTOR_TRACES_MIXED_EIGENCHANNEL_NULL_REJECTED_AS_WRONG_BOOKKEEPING_IF_SECTORS_PHYSICAL_EQUAL_SECTOR_NORMALIZATION_OPEN_NO_V12_13

Purpose:
R214M compares Opus's incommensurable-sector symmetry argument with the projector-trace protection mechanism.

Lead compact lane:
M_i = G_i * exp(L_eff * u_i)

Lead candidate:
L_eff = 3pi - 1/2 ln(25/13)

D-required split:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required_ln2_units": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446
}

Mechanism scorecard:
               mechanism                                  status  native_prior  combined_score               shares_normalized    N_eff  amplitude_tax    c_ln2    L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_log_error_vs_D_abs
  trace_protected_3_to_2 lead_if_symmetry_trace_protection_holds            10              16                       (0.6,0.4) 1.923077       0.326963 0.471708 9.097815   17871.488624              0.999680                     0.000320
sqrt_4pi_sqrt_2pi_bridge          supportive_spinor_frame_bridge             8              13 (0.585786437627,0.414213562373) 1.942809       0.332067 0.479072 9.092711   17780.501218              0.994590                     0.005424
 equal_two_channel_sqrt2        lower_order_binary_approximation             6              10                       (0.5,0.5) 2.000000       0.346574 0.500000 9.078204   17524.436390              0.980267                     0.019930
   direct_4pi_2pi_bridge        supportive_but_less_exact_bridge             7              10 (0.666666666667,0.333333333333) 1.800000       0.293893 0.423998 9.130885   18472.377901              1.033292                     0.032750
  five_eigenchannel_null             null_control_fails_grouping             2              -1           (0.2,0.2,0.2,0.2,0.2) 5.000000       0.804719 1.160964 8.620059   11083.426741              0.619975                     0.478076

Symmetry audit summary:
{
  "raw_cross_norm_mean": 2.4641245360243156,
  "projected_cross_norm_mean": 0.1197474407508633,
  "raw_invariance_error_mean": 2.8919426065831804,
  "projected_invariance_error_mean": 0.16320979129103144,
  "projected_space_anisotropy_mean": 0.03744948548123509,
  "projected_phase_anisotropy_mean": 0.060091152466302145,
  "lead_trace_model": {
    "mechanism": "trace_protected_3_to_2",
    "status": "lead_if_symmetry_trace_protection_holds",
    "native_prior": 10,
    "combined_score": 16,
    "shares_normalized": "(0.6,0.4)",
    "N_eff": 1.923076923076923,
    "amplitude_tax": 0.32696323370333197,
    "c_ln2": 0.4717082358168162,
    "L_eff": 9.097814727066048,
    "endpoint_rho2": 17871.48862357384,
    "endpoint_vs_D_factor": 0.9996800358435753,
    "endpoint_log_error_vs_D_abs": 0.00032001535587697285
  },
  "mixed_eigenchannel_null": {
    "mechanism": "five_eigenchannel_null",
    "status": "null_control_fails_grouping",
    "native_prior": 2,
    "combined_score": -1,
    "shares_normalized": "(0.2,0.2,0.2,0.2,0.2)",
    "N_eff": 4.999999999999999,
    "amplitude_tax": 0.8047189562170501,
    "c_ln2": 1.160964047443681,
    "L_eff": 8.62005900455233,
    "endpoint_rho2": 11083.426740695197,
    "endpoint_vs_D_factor": 0.6199752395999412,
    "endpoint_log_error_vs_D_abs": 0.4780757378695954
  }
}

Gate matrix:
                                  gate                                                                         test           status                                                                                      boundary
          incommensurable_sector_split       Spatial and phase objects transform under independent symmetry groups.      PASS_FORMAL                             Formal representation argument, not yet full master-action proof.
symmetry_projection_erases_cross_terms       Group-averaging over SO(3)xSO(2) suppresses spatial-phase cross block.             WEAK                                                max projected cross norm = 0.21267992234968935
                       sector_isotropy Symmetry projection makes spatial and phase blocks isotropic within sectors.             WEAK                    space anisotropy 0.11234845644370524, phase anisotropy 0.18027345739890643
                      trace_invariance              Trace is invariant under allowed within-sector basis rotations.      PASS_FORMAL                        This protects the coefficient if sector-trace rule is the action rule.
            equal_sector_normalization                                       Does symmetry force k_space = k_phase?             OPEN Symmetry protects blocks and traces, but does not by itself force equal sector normalization.
               mixed_eigenchannel_null                           Treat mixed eigenchannels as independent channels. FAILS_AS_PRIMARY                This is the null model rejected by R213/R214 if symmetry sectors are physical.
                                V12_13                                                                   Promotion.               NO                         Need action-level normalization derivation and prediction/null tests.

Claim boundary:
 category                                                                                                   claim          status                                                               boundary
Preserved                                                   The compact D-scale lane is M_i = G_i exp(L_eff u_i).       PRESERVED                                                     D-scale lane only.
Preserved Symmetry/incommensurability gives a formal route to block protection between spatial and phase sectors.     FORMAL_PASS                             Still not a full master-action derivation.
Preserved                                                 Allowed within-sector rotations preserve sector traces.            PASS                     Trace rule still needs action-level justification.
 Observed      Symmetry projection suppresses spatial-phase cross terms and sector anisotropy in the audit model. DIAGNOSTIC_PASS        Numerical group averaging supports the representation argument.
     Open              Symmetry alone forces equal per-component normalization between spatial and phase sectors.            OPEN                                   This remains the main missing proof.
 Rejected                                                                   R214M proves the full mass hierarchy.              NO No species map, no top/e closure, no final action normalization proof.
Promotion                                                                                       V12.13 promotion.              NO                                                        Not yet earned.

Interpretation:
R214M supports the trace-protection route.

Opus's idea supplies the physical reason cross-sector mixing is forbidden:
spatial support and phase closure are incommensurable objects with different
transformation laws. They live in different representation sectors.

The projector-trace mechanism supplies the invariant coefficient rule:
inside each sector, basis changes do not affect the sector trace. Therefore
the trace-weighted 3:2 split is protected if the action uses sector traces.

The mixed-eigenchannel model is rejected as the wrong bookkeeping if these
symmetry sectors are physical.

Remaining open proof:
symmetry protects block structure and traces, but it does not automatically
force equal per-component normalization between space and phase sectors. That
normalization must still come from the master action, no-overwrite accounting,
or a canonical kinetic normalization.

Ruling:
No V12.13 promotion.

Next recommended run:
R215M — Canonical Sector Normalization Derivation Gate

Question:
Can the action normalize spatial support and phase refresh sectors with the same per-component weight, turning the formal trace protection into the final D-scale coefficient law?
