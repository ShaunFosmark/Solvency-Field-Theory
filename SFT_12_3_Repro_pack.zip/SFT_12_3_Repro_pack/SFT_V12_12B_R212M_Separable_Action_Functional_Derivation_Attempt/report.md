
# SFT V12.12B R212M — Separable Action Functional Derivation Attempt

Generated: 2026-06-18T03:31:43Z

Verdict:
PARTIAL_PASS_SEPARABLE_PROJECTOR_ACTION_ROUTE_FORMALIZED_TRACE_WEIGHTED_3_TO_2_REPRODUCES_LEAD_COEFFICIENT_UNGROUPED_EIGENCHANNEL_NULL_FAILS_FULL_NORMALIZATION_AND_CROSS_TERM_PROOF_OPEN_NO_V12_13

Purpose:
R212M tests whether the WHERE/HOW 3:2 grouping can be represented as a separable action-sector projector structure.

Compact lane:
M_i = G_i * exp(L_eff * u_i)

Candidate coefficient:
L_eff = 3pi - 1/2 ln(25/13)

Formal separable projector structure:
P_space has rank 3.
P_phase has rank 2.
P_space P_phase = 0.
P_space + P_phase = I_5.

If amplitude participation is computed from sector trace weights:
W_space = Tr(P_space) = 3
W_phase = Tr(P_phase) = 2

Then:
N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13
tax = 1/2 ln(25/13)
L_eff = 3pi - 1/2 ln(25/13)

D-required endpoint split:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "two_channel_possible": true,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446,
  "imbalance_required": 0.20165774222211108
}

Projector audit:
                           matrix                                                                      reading  rank  trace  idempotence_error_norm  symmetry_error_norm  is_projector
                          P_space                                  three-dimensional spatial support projector   3.0    3.0                     0.0                  0.0          True
                          P_phase                                      two-dimensional phase-refresh projector   2.0    2.0                     0.0                  0.0          True
                          P_total                                                       full 3+2 projector sum   5.0    5.0                     0.0                  0.0          True
    P_space_P_phase_orthogonality space and phase sectors are orthogonal blocks in the separable approximation   NaN    NaN                     0.0                  NaN          True
P_space_plus_P_phase_completeness                            space plus phase spans the 3+2 audit vector space   NaN    NaN                     0.0                  NaN          True

Model summary:
                         model_id                  family                                              proof_status  uses_D_to_define  native_prior                                                 mechanical_reading            closed_form_hint               shares_normalized   p_high    p_low  imbalance    N_eff  amplitude_tax    c_ln2    L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_vs_top_e_factor  endpoint_log_error_vs_D_abs  span_max_over_min  rmse_log_vs_D_target  rmse_log_vs_top_e_target  distance_to_required_p_high  combined_score
 separable_projector_trace_3_to_2        separable_action conditional_pass_if_sector_trace_coarse_graining_is_valid             False          10.0      sector trace weights from rank(P_space)=3 and rank(P_phase)=2 L_eff = 3pi - 1/2 ln(25/13)                       (0.6,0.4) 0.600000 0.400000   0.200000 1.923077       0.326963 0.471708 9.097815   17871.488624              0.999680                  0.052718                     0.000320       17871.488624              0.718964                  1.475658                     0.000829            17.0
 spinor_frame_sqrt_4pi_2pi_bridge     spinor_frame_bridge                                         supportive_bridge             False           8.0 sector amplitudes from sqrt(4π) spinor and sqrt(2π) frame closures L_eff = 3pi - 1/2 ln(N_eff) (0.585786437627,0.414213562373) 0.585786 0.414214   0.171573 1.942809       0.332067 0.479072 9.092711   17780.501218              0.994590                  0.052450                     0.005424       17780.501218              0.716679                  1.478726                     0.015042            14.0
           equal_two_sector_sqrt2             binary_base                          lower_order_binary_approximation             False           7.0                          two equal sectors, no 3:2 trace weighting       L_eff = 3pi - 1/2 ln2                       (0.5,0.5) 0.500000 0.500000   0.000000 2.000000       0.346574 0.500000 9.078204   17524.436390              0.980267                  0.051695                     0.019930       17524.436390              0.710228                  1.487449                     0.100829            12.0
        spinor_frame_4pi_2pi_load     spinor_frame_bridge                                            control_bridge             False           7.0                 sector weights from direct 4π and 2π closure loads   L_eff = 3pi - 1/2 ln(9/5) (0.666666666667,0.333333333333) 0.666667 0.333333   0.333333 1.800000       0.293893 0.423998 9.130885   18472.377901              1.033292                  0.054491                     0.032750       18472.377901              0.733949                  1.455805                     0.065838            10.0
                 sqrt_rank_3_to_2 amplitude_count_control                                                   control             False           6.0    sector amplitudes from square roots of ranks rather than traces L_eff = 3pi - 1/2 ln(N_eff) (0.550510257217,0.449489742783) 0.550510 0.449490   0.101021 1.979796       0.341497 0.492676 9.083281   17613.629113              0.985256                  0.051958                     0.014854       17613.629113              0.712479                  1.484396                     0.050319            10.0
   three_plus_one_support_tangent          3plus1_control                                                   control             False           5.0                   3 spatial support versus 1 tangent/write channel L_eff = 3pi - 1/2 ln(N_eff)                     (0.75,0.25) 0.750000 0.250000   0.500000 1.600000       0.235002 0.339036 9.189776   19592.915518              1.095972                  0.057796                     0.091641       19592.915518              0.761366                  1.420545                     0.149171             8.0
ungrouped_five_eigenchannels_null                    null                                              null_control             False           4.0                               five equal independent eigenchannels       L_eff = 3pi - 1/2 ln5           (0.2,0.2,0.2,0.2,0.2) 0.200000 0.200000   0.000000 5.000000       0.804719 1.160964 8.620059   11083.426741              0.619975                  0.032694                     0.478076       11083.426741              0.550147                  1.765976                     0.400829             6.0
      D_inferred_split_diagnostic         diagnostic_only                                    diagnostic_only_uses_D              True          -8.0                                     split inferred from D endpoint L_eff = 3pi - 1/2 ln(N_eff) (0.600828871111,0.399171128889) 0.600829 0.399171   0.201658 1.921846       0.326643 0.471247 9.098135   17877.208690              1.000000                  0.052735                     0.000000       17877.208690              0.719108                  1.475466                     0.000000           -13.0

Coupling sensitivity:
 k_space_over_k_phase  W_space  W_phase   p_high    p_low    N_eff  amplitude_tax    L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_log_error_vs_D_abs                                                           interpretation
                 1.00     3.00      2.0 0.600000 0.400000 1.923077       0.326963 9.097815   17871.488624              0.999680                     0.000320 tests stability if spatial and phase sector normalizations are not equal
                 1.05     3.15      2.0 0.611650 0.388350 1.905010       0.322244 9.102534   17956.034924              1.004409                     0.004400 tests stability if spatial and phase sector normalizations are not equal
                 0.95     2.85      2.0 0.587629 0.412371 1.940400       0.331447 9.093331   17791.534822              0.995208                     0.004804 tests stability if spatial and phase sector normalizations are not equal
                 0.90     2.70      2.0 0.574468 0.425532 1.956599       0.335604 9.089174   17717.733713              0.991079                     0.008961 tests stability if spatial and phase sector normalizations are not equal
                 1.10     3.30      2.0 0.622642 0.377358 1.886501       0.317362 9.107416   18043.905190              1.009325                     0.009281 tests stability if spatial and phase sector normalizations are not equal
                 0.85     2.55      2.0 0.560440 0.439560 1.971197       0.339321 9.085457   17652.003531              0.987403                     0.012677 tests stability if spatial and phase sector normalizations are not equal
                 1.15     3.45      2.0 0.633028 0.366972 1.867788       0.312377 9.112401   18134.068714              1.014368                     0.014266 tests stability if spatial and phase sector normalizations are not equal
                 0.75     2.25      2.0 0.529412 0.470588 1.993103       0.344846 9.079931   17554.729302              0.981961                     0.018203 tests stability if spatial and phase sector normalizations are not equal
                 1.25     3.75      2.0 0.652174 0.347826 1.830450       0.302281 9.122497   18318.088064              1.024662                     0.024362 tests stability if spatial and phase sector normalizations are not equal

Gate matrix:
                       gate                                                                        test           status                                                        boundary
            projector_ranks                                          P_space rank 3 and P_phase rank 2.      PASS_FORMAL           Formal 3+2 audit vector space, not full field action.
   orthogonal_sector_blocks                                                        P_space P_phase = 0.      PASS_FORMAL                                Assumes separable approximation.
       sector_trace_weights                Use Tr(P_space):Tr(P_phase)=3:2 as amplitude-sector weights. CONDITIONAL_PASS   This is the key premise; needs derivation from master action.
ungrouped_eigenchannel_null               Treat all five components as independent equal eigenchannels.   FAILS_ENDPOINT        Supports grouping necessity but does not prove grouping.
 equal_sector_normalization Assume equal per-component normalization between spatial and phase sectors.             OPEN Sensitivity audit included; full action must fix normalization.
        spinor_frame_bridge                                    sqrt(4π):sqrt(2π) bridge remains nearby.       SUPPORTIVE                                      Bridge, not primary proof.
                     V12_13                                                                  Promotion.               NO                    Need full action proof and prediction nulls.

Claim boundary:
 category                                                                                           claim            status                                                 boundary
Preserved                                           The compact D-scale lane is M_i = G_i exp(L_eff u_i).         PRESERVED                                       D-scale lane only.
Preserved                              A separable projector audit gives rank(P_space):rank(P_phase)=3:2.       FORMAL_PASS          Formal audit, not full field-theory derivation.
Preserved                                        Sector trace weighting gives L_eff = 3π - 1/2 ln(25/13).  CONDITIONAL_PASS Depends on sector-trace amplitude participation premise.
 Observed Ungrouped five-eigenchannel interpretation fails the endpoint compared to grouped sector trace. SUPPORTS_GROUPING                            Failure of null is not proof.
     Open        The master action forces equal per-component normalization of spatial and phase sectors.              OPEN                                    Must be derived next.
 Rejected                                                                R212M proves the mass hierarchy.                NO  No species map, no top/e closure, no full action proof.
Promotion                                                                               V12.13 promotion.                NO                                          Not yet earned.

Interpretation:
R212M gives a formal action-sector route to the 3:2 grouping:
spatial support and phase refresh can be represented as orthogonal projector sectors with ranks 3 and 2.

The result remains conditional because the full master action still has to justify three things:
1. the spatial and phase sectors are separable at the relevant linearized level,
2. the sector weights enter by trace/rank rather than five independent eigenchannels,
3. spatial and phase components have equal per-component normalization.

The ungrouped five-channel null fails the endpoint, so grouping is necessary.
The grouped trace model remains the lead D-scale coefficient candidate.

Ruling:
No V12.13 promotion.

Next recommended run:
R213M — Sector Normalization and Cross-Term Null Audit

Question:
Can unequal spatial/phase normalization or cross-sector coupling destroy the 3:2 coefficient, or does the action protect the trace-weighted split?
