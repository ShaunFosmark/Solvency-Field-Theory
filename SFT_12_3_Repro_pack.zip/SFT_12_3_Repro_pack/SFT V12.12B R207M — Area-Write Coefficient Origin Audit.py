#!/usr/bin/env python3
"""
SFT V12.12B R207M — Area-Write Coefficient Origin Audit

Purpose:
    R206M found that the D-scale endpoint is very close to:

        geometry * exp((3π - 1/2 ln2) * u)

    while the best whole-curve diagnostic leaned toward:

        geometry * exp((3π - ln2) * u)

    R207M asks:
        Why ln2?
        Why 1/2 ln2?

    Candidate origins tested:
        - sqrt2 amplitude degeneracy
        - binary branch split
        - two-orientation averaging
        - no-overwrite capacity doubling
        - 3+1 slot dilution
        - half-action normalization
        - no correction
        - full ln2 correction
        - half ln2 correction

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e used only as diagnostic target contexts
    - no V12.13 promotion

Outputs:
    SFT_V12_12B_R207M_Area_Write_Coefficient_Origin_Audit/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R207M.py

    SFT_V12_12B_R207M_Area_Write_Coefficient_Origin_Audit_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R207M_Area_Write_Coefficient_Origin_Audit"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
SQRT2 = math.sqrt(2.0)

TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi
HALF_K_REQ = K_REQ / 2.0

RHO0 = 0.5
RHO_SPAN = 4.0

SEED_MODES = [
    Fraction(1, 2),
    Fraction(2, 3),
    Fraction(3, 4),
    Fraction(1, 1),
    Fraction(5, 4),
    Fraction(4, 3),
    Fraction(3, 2),
    Fraction(5, 3),
    Fraction(2, 1),
]

D_PERP = 3


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def frac_str(f: Fraction) -> str:
    if f.denominator == 1:
        return str(f.numerator)
    return f"{f.numerator}/{f.denominator}"


def balanced_occupancy(m: int, n: int) -> list[int]:
    active = min(max(n, 1), D_PERP)
    q, r = divmod(m, active)

    occ = [q + 1 if i < r else q for i in range(active)]
    occ += [0] * (D_PERP - len(occ))
    occ.sort(reverse=True)

    return occ


def shape_stats(occ: list[int]) -> dict:
    total = sum(occ)
    probs = [x / total for x in occ] if total else [0.0, 0.0, 0.0]

    l2 = math.sqrt(sum(p * p for p in probs))
    iso = 1.0 / D_PERP

    eccentricity = 0.0
    if total:
        eccentricity = math.sqrt(sum((p - iso) ** 2 for p in probs)) / math.sqrt(2.0 / 3.0)

    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    entropy_norm = entropy / math.log(D_PERP)
    entropy_deficit = 1.0 - entropy_norm

    active_slots = sum(1 for x in occ if x > 0)
    max_occ = max(occ) if occ else 0
    slot_fill_fraction = active_slots / D_PERP

    return {
        "shape_l2_norm": l2,
        "eccentricity_norm": eccentricity,
        "entropy_norm": entropy_norm,
        "entropy_deficit": entropy_deficit,
        "active_slots": active_slots,
        "max_occ": max_occ,
        "slot_fill_fraction": slot_fill_fraction,
    }


def build_modes() -> pd.DataFrame:
    rows = []

    for rho in SEED_MODES:
        m = rho.numerator
        n = rho.denominator
        occ = balanced_occupancy(m, n)
        stats = shape_stats(occ)

        rows.append({
            "rho": frac_str(rho),
            "rho_float": float(rho),
            "m": m,
            "N": n,
            "occupancy_vector": "(" + ",".join(str(x) for x in occ) + ")",
            "occ0": occ[0],
            "occ1": occ[1],
            "occ2": occ[2],
            "active_slots": stats["active_slots"],
            "max_occ": stats["max_occ"],
            "slot_fill_fraction": stats["slot_fill_fraction"],
            "shape_l2_norm": stats["shape_l2_norm"],
            "eccentricity_norm": stats["eccentricity_norm"],
            "entropy_norm": stats["entropy_norm"],
            "entropy_deficit": stats["entropy_deficit"],
            "u_logrho": math.log(float(rho) / RHO0) / math.log(RHO_SPAN),
        })

    return pd.DataFrame(rows).sort_values("rho_float").reset_index(drop=True)


def fibonacci_sphere(n: int = 300) -> np.ndarray:
    pts = []
    phi = math.pi * (3.0 - math.sqrt(5.0))

    for i in range(n):
        y = 1.0 - (i / float(n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - y * y))
        theta = phi * i
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        pts.append([x, y, z])

    return np.array(pts, dtype=float)


SPHERE_POINTS = fibonacci_sphere(300)
RHAT = SPHERE_POINTS.copy()


def ring_basis(axis_index: int) -> tuple[np.ndarray, np.ndarray]:
    if axis_index == 0:
        return np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])
    if axis_index == 1:
        return np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])
    return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])


def source_points_ring(
    occ: list[int],
    ring_radius: float = 0.55,
    n_per_ring: int = 36,
) -> tuple[np.ndarray, np.ndarray]:
    positions = []
    weights = []

    for axis_index, weight in enumerate(occ):
        if weight <= 0:
            continue

        e1, e2 = ring_basis(axis_index)

        for j in range(n_per_ring):
            t = 2.0 * math.pi * j / n_per_ring
            point = ring_radius * (math.cos(t) * e1 + math.sin(t) * e2)
            positions.append(point)
            weights.append(weight / n_per_ring)

    return np.array(positions, dtype=float), np.array(weights, dtype=float)


def eval_ring_geometry(
    occ: list[int],
    softening: float = 0.12,
    ring_radius: float = 0.55,
) -> dict:
    pos, weights = source_points_ring(occ, ring_radius=ring_radius)

    potentials = []
    grad_mags = []
    abs_radial_curvatures = []

    for x, rh in zip(SPHERE_POINTS, RHAT):
        d = x[None, :] - pos
        d2 = np.sum(d * d, axis=1) + softening ** 2
        R = np.sqrt(d2)

        potential = np.sum(weights / R)

        grad = np.sum((-weights[:, None] * d) / (R[:, None] ** 3), axis=0)
        grad_mag = np.linalg.norm(grad)

        rd = d @ rh
        hess_radial = np.sum(weights * (-1.0 / (R ** 3) + 3.0 * (rd ** 2) / (R ** 5)))

        potentials.append(float(potential))
        grad_mags.append(float(grad_mag))
        abs_radial_curvatures.append(abs(float(hess_radial)))

    return {
        "mean_potential": float(np.mean(potentials)),
        "mean_gradient_magnitude": float(np.mean(grad_mags)),
        "mean_abs_radial_curvature": float(np.mean(abs_radial_curvatures)),
        "p95_abs_radial_curvature": float(np.quantile(abs_radial_curvatures, 0.95)),
    }


def add_geometry_signal(modes: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in modes.iterrows():
        occ = [int(row["occ0"]), int(row["occ1"]), int(row["occ2"])]
        obs = eval_ring_geometry(occ)

        rec = row.to_dict()
        rec.update(obs)
        rows.append(rec)

    df = pd.DataFrame(rows)

    for col in [
        "mean_potential",
        "mean_gradient_magnitude",
        "mean_abs_radial_curvature",
        "p95_abs_radial_curvature",
    ]:
        base = df.loc[df["rho"] == "1/2", col].iloc[0]
        df[col + "_ratio_to_rho_half"] = df[col] / base

    df["G_i_geometry_ratio"] = df["mean_abs_radial_curvature_ratio_to_rho_half"]
    return df


def target_power_exponent(target_span: float) -> float:
    return math.log(target_span) / math.log(RHO_SPAN)


P_D = target_power_exponent(D_TARGET)
P_TOP = target_power_exponent(TOP_E_TARGET)
P_HALF_6PI = (SIX_PI / 2.0) / math.log(RHO_SPAN)
P_HALF_KREQ = (K_REQ / 2.0) / math.log(RHO_SPAN)


def add_targets(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    out["target_D_rhopower"] = (out["rho_float"] / RHO0) ** P_D
    out["target_top_e_rhopower"] = (out["rho_float"] / RHO0) ** P_TOP
    out["target_half_6pi_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_6PI
    out["target_half_Kreq_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_KREQ

    return out


def coefficient_origin_candidates() -> pd.DataFrame:
    rows = [
        {
            "origin_id": "none",
            "correction_c_ln2": 0.0,
            "load_value": THREE_PI,
            "mechanical_reading": "pure half-action feedback",
            "claim_boundary": "overshoots D endpoint; no dilution correction"
        },
        {
            "origin_id": "sqrt2_amplitude_degeneracy",
            "correction_c_ln2": 0.5,
            "load_value": THREE_PI - 0.5 * LN2,
            "mechanical_reading": "half-action feedback divided by sqrt2 amplitude channel",
            "claim_boundary": "best D endpoint match in R206; origin still not derived"
        },
        {
            "origin_id": "binary_branch_split",
            "correction_c_ln2": 1.0,
            "load_value": THREE_PI - LN2,
            "mechanical_reading": "half-action feedback divided by a binary branch factor 2",
            "claim_boundary": "best R206 curve-shape RMSE; endpoint low"
        },
        {
            "origin_id": "two_binary_splits",
            "correction_c_ln2": 2.0,
            "load_value": THREE_PI - 2.0 * LN2,
            "mechanical_reading": "two independent binary dilution factors",
            "claim_boundary": "likely too much correction"
        },
        {
            "origin_id": "quarter_binary_split",
            "correction_c_ln2": 0.25,
            "load_value": THREE_PI - 0.25 * LN2,
            "mechanical_reading": "weak binary dilution correction",
            "claim_boundary": "tests whether correction is smaller than sqrt2"
        },
        {
            "origin_id": "three_quarter_binary_split",
            "correction_c_ln2": 0.75,
            "load_value": THREE_PI - 0.75 * LN2,
            "mechanical_reading": "intermediate branch dilution",
            "claim_boundary": "interpolation only; not native"
        },
        {
            "origin_id": "Kreq_half",
            "correction_c_ln2": (THREE_PI - HALF_K_REQ) / LN2,
            "load_value": HALF_K_REQ,
            "mechanical_reading": "half of K_req diagnostic",
            "claim_boundary": "uses K_req context; diagnostic only"
        },
        {
            "origin_id": "two_pi",
            "correction_c_ln2": (THREE_PI - TWO_PI) / LN2,
            "load_value": TWO_PI,
            "mechanical_reading": "phase holonomy only",
            "claim_boundary": "too weak for D endpoint"
        },
        {
            "origin_id": "four_pi",
            "correction_c_ln2": (THREE_PI - FOUR_PI) / LN2,
            "load_value": FOUR_PI,
            "mechanical_reading": "spinor curvature crossing load",
            "claim_boundary": "too strong if used as feedback coefficient"
        },
        {
            "origin_id": "six_pi",
            "correction_c_ln2": (THREE_PI - SIX_PI) / LN2,
            "load_value": SIX_PI,
            "mechanical_reading": "full support load as feedback coefficient",
            "claim_boundary": "far too strong"
        },
    ]

    return pd.DataFrame(rows)


def coordinate_candidates(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in df.iterrows():
        u = float(row["u_logrho"])

        candidates = [
            {
                "coord_name": "u_logrho",
                "coord_value": u,
                "coord_reading": "normalized compression coordinate"
            },
            {
                "coord_name": "slot_pressure",
                "coord_value": u * (1.0 + float(row["slot_fill_fraction"])),
                "coord_reading": "area-write coordinate weighted by active slot fill"
            },
            {
                "coord_name": "support_pressure",
                "coord_value": u * (1.0 + float(row["entropy_deficit"])),
                "coord_reading": "area-write coordinate weighted by support entropy deficit"
            },
            {
                "coord_name": "concentration_pressure",
                "coord_value": u * (1.0 + float(row["eccentricity_norm"])),
                "coord_reading": "area-write coordinate weighted by anisotropic concentration"
            },
            {
                "coord_name": "sqrt_u",
                "coord_value": math.sqrt(max(u, 0.0)),
                "coord_reading": "slower-start square-root area-write coordinate"
            },
            {
                "coord_name": "u_times_rho",
                "coord_value": u * float(row["rho_float"]),
                "coord_reading": "compression coordinate weighted by rho"
            },
        ]

        for cand in candidates:
            rec = row.to_dict()
            rec.update(cand)
            rows.append(rec)

    return pd.DataFrame(rows)


def evaluate_origin_candidates(coord_df: pd.DataFrame, origins: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, coord_row in coord_df.iterrows():
        G = float(coord_row["G_i_geometry_ratio"])
        x = float(coord_row["coord_value"])

        for _, origin in origins.iterrows():
            load_value = float(origin["load_value"])
            ratio = G * math.exp(load_value * x)

            rows.append({
                "rho": coord_row["rho"],
                "rho_float": coord_row["rho_float"],
                "m": int(coord_row["m"]),
                "N": int(coord_row["N"]),
                "occupancy_vector": coord_row["occupancy_vector"],
                "G_i_geometry_ratio": G,
                "coord_name": coord_row["coord_name"],
                "coord_value": x,
                "coord_reading": coord_row["coord_reading"],
                "origin_id": origin["origin_id"],
                "correction_c_ln2": float(origin["correction_c_ln2"]),
                "load_value": load_value,
                "mechanical_reading": origin["mechanical_reading"],
                "claim_boundary": origin["claim_boundary"],
                "model_ratio_to_rho_half": ratio,
                "target_D_rhopower": coord_row["target_D_rhopower"],
                "target_top_e_rhopower": coord_row["target_top_e_rhopower"],
                "residual_log_vs_D": math.log(ratio / coord_row["target_D_rhopower"]) if ratio > 0 else np.nan,
                "residual_log_vs_top_e": math.log(ratio / coord_row["target_top_e_rhopower"]) if ratio > 0 else np.nan,
            })

    return pd.DataFrame(rows)


def summarize_origin_models(outputs: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for (coord_name, origin_id), grp in outputs.groupby(["coord_name", "origin_id"]):
        ordered = grp.sort_values("rho_float")
        endpoint = float(ordered["model_ratio_to_rho_half"].iloc[-1])
        span = float(ordered["model_ratio_to_rho_half"].max() / ordered["model_ratio_to_rho_half"].min())
        rmse_D = float(np.sqrt(np.nanmean(ordered["residual_log_vs_D"] ** 2)))
        rmse_top = float(np.sqrt(np.nanmean(ordered["residual_log_vs_top_e"] ** 2)))

        first = ordered.iloc[0]

        rows.append({
            "coord_name": coord_name,
            "origin_id": origin_id,
            "mechanical_reading": first["mechanical_reading"],
            "correction_c_ln2": float(first["correction_c_ln2"]),
            "load_value": float(first["load_value"]),
            "endpoint_rho2": endpoint,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
            "span_max_over_min": span,
            "rmse_log_vs_D_target": rmse_D,
            "rmse_log_vs_top_e_target": rmse_top,
            "claim_boundary": first["claim_boundary"],
        })

    return pd.DataFrame(rows).sort_values("rmse_log_vs_D_target")


def required_correction_by_mode(df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    targets = [
        ("D_rhopower", "target_D_rhopower"),
        ("top_e_rhopower", "target_top_e_rhopower"),
        ("half_6pi_rhopower", "target_half_6pi_rhopower"),
        ("half_Kreq_rhopower", "target_half_Kreq_rhopower"),
    ]

    coord_fns = [
        ("u_logrho", lambda r: float(r["u_logrho"])),
        ("slot_pressure", lambda r: float(r["u_logrho"]) * (1.0 + float(r["slot_fill_fraction"]))),
        ("support_pressure", lambda r: float(r["u_logrho"]) * (1.0 + float(r["entropy_deficit"]))),
        ("concentration_pressure", lambda r: float(r["u_logrho"]) * (1.0 + float(r["eccentricity_norm"]))),
    ]

    for _, row in df.iterrows():
        G = float(row["G_i_geometry_ratio"])

        for coord_name, coord_fn in coord_fns:
            x = coord_fn(row)

            for target_name, target_col in targets:
                target = float(row[target_col])

                if abs(x) < 1e-12:
                    L_required = np.nan
                    c_required = np.nan
                else:
                    L_required = math.log(target / G) / x
                    c_required = (THREE_PI - L_required) / LN2

                rows.append({
                    "rho": row["rho"],
                    "rho_float": row["rho_float"],
                    "m": int(row["m"]),
                    "N": int(row["N"]),
                    "G_i_geometry_ratio": G,
                    "coord_name": coord_name,
                    "coord_value": x,
                    "target_name": target_name,
                    "target_ratio": target,
                    "L_required": L_required,
                    "c_required_in_3pi_minus_c_ln2": c_required,
                    "distance_to_c_0": abs(c_required - 0.0) if not np.isnan(c_required) else np.nan,
                    "distance_to_c_0_5": abs(c_required - 0.5) if not np.isnan(c_required) else np.nan,
                    "distance_to_c_1": abs(c_required - 1.0) if not np.isnan(c_required) else np.nan,
                    "distance_to_c_2": abs(c_required - 2.0) if not np.isnan(c_required) else np.nan,
                })

    return pd.DataFrame(rows)


def summarize_required_correction(required: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for (coord_name, target_name), grp in required.dropna(subset=["c_required_in_3pi_minus_c_ln2"]).groupby(["coord_name", "target_name"]):
        ordered = grp.sort_values("rho_float")
        cvals = ordered["c_required_in_3pi_minus_c_ln2"].to_numpy(float)

        endpoint_c = float(ordered["c_required_in_3pi_minus_c_ln2"].iloc[-1])

        rows.append({
            "coord_name": coord_name,
            "target_name": target_name,
            "mean_c_required": float(np.mean(cvals)),
            "std_c_required": float(np.std(cvals)),
            "cv_c_required": float(np.std(cvals) / abs(np.mean(cvals))) if np.mean(cvals) else np.nan,
            "endpoint_c_required_rho2": endpoint_c,
            "endpoint_distance_to_c_0_5": abs(endpoint_c - 0.5),
            "endpoint_distance_to_c_1": abs(endpoint_c - 1.0),
            "endpoint_distance_to_c_2": abs(endpoint_c - 2.0),
        })

    return pd.DataFrame(rows).sort_values(["target_name", "endpoint_distance_to_c_0_5"])


def origin_scorecard(summary: pd.DataFrame, correction_summary: pd.DataFrame) -> pd.DataFrame:
    rows = []

    d_endpoint = correction_summary[
        (correction_summary["coord_name"] == "u_logrho") &
        (correction_summary["target_name"] == "D_rhopower")
    ]

    endpoint_c_D = None
    if len(d_endpoint):
        endpoint_c_D = float(d_endpoint.iloc[0]["endpoint_c_required_rho2"])

    for _, row in summary.iterrows():
        coord = row["coord_name"]
        origin = row["origin_id"]
        c = float(row["correction_c_ln2"])
        endpoint_vs_D = float(row["endpoint_vs_D_factor"])
        rmse_D = float(row["rmse_log_vs_D_target"])
        endpoint_error_log = abs(math.log(endpoint_vs_D)) if endpoint_vs_D > 0 else np.inf

        score = 0.0

        if coord == "u_logrho":
            score += 2.0
        if origin == "sqrt2_amplitude_degeneracy":
            score += 2.0
        if origin == "binary_branch_split":
            score += 1.0
        if endpoint_error_log < 0.05:
            score += 3.0
        elif endpoint_error_log < 0.15:
            score += 2.0
        elif endpoint_error_log < 0.4:
            score += 1.0

        if rmse_D < 0.65:
            score += 2.0
        elif rmse_D < 0.9:
            score += 1.0

        if endpoint_c_D is not None and abs(c - endpoint_c_D) < 0.1:
            score += 2.0

        if origin in {"four_pi", "six_pi"}:
            score -= 2.0
        if coord not in {"u_logrho", "slot_pressure"}:
            score -= 0.5

        rows.append({
            "coord_name": coord,
            "origin_id": origin,
            "correction_c_ln2": c,
            "load_value": float(row["load_value"]),
            "endpoint_vs_D_factor": endpoint_vs_D,
            "rmse_log_vs_D_target": rmse_D,
            "endpoint_error_log_abs": endpoint_error_log,
            "mechanical_reading": row["mechanical_reading"],
            "score": score,
            "ruling": "diagnostic_candidate_not_derivation",
        })

    return pd.DataFrame(rows).sort_values("score", ascending=False)


def gate_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "gate": "ln2_origin",
            "test": "Can the correction to 3pi be written as c ln2 with c near 1/2 or 1?",
            "status": "TESTED",
            "boundary": "Numeric match only; no native proof yet."
        },
        {
            "gate": "sqrt2_amplitude_degeneracy",
            "test": "3pi - 1/2 ln2 corresponds to division by sqrt2.",
            "status": "LIVE_CANDIDATE",
            "boundary": "Strong endpoint match; mechanical origin still open."
        },
        {
            "gate": "binary_branch_split",
            "test": "3pi - ln2 corresponds to division by 2.",
            "status": "LIVE_CANDIDATE",
            "boundary": "Better curve RMSE in R206; endpoint low."
        },
        {
            "gate": "full_action",
            "test": "4pi or 6pi as feedback coefficient.",
            "status": "REJECT_AS_DIRECT_FEEDBACK",
            "boundary": "Too strong for D-scale diagnostic."
        },
        {
            "gate": "top_e",
            "test": "Top/e target closure.",
            "status": "OPEN",
            "boundary": "Top/e still needs extra structure."
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need native derivation of correction coefficient."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "The correction to 3pi is naturally expressible as an ln2-family correction.",
            "status": "DIAGNOSTIC_PASS",
            "boundary": "Numerical diagnostic only."
        },
        {
            "category": "Preserved",
            "claim": "sqrt2 amplitude degeneracy is the leading D-endpoint candidate.",
            "status": "LIVE_CANDIDATE",
            "boundary": "Not yet derived."
        },
        {
            "category": "Preserved",
            "claim": "binary branch split remains live for curve-shape behavior.",
            "status": "LIVE_CANDIDATE",
            "boundary": "Endpoint under-shoots D."
        },
        {
            "category": "Rejected",
            "claim": "R207M derives the mass hierarchy.",
            "status": "NO",
            "boundary": "No species map, no native coefficient proof."
        },
        {
            "category": "Rejected",
            "claim": "R207M solves top/e.",
            "status": "NO",
            "boundary": "Top/e needs another layer."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def build_report(
    created_utc: str,
    verdict: str,
    best_scorecard: pd.DataFrame,
    best_summary: pd.DataFrame,
    correction_summary: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R207M — Area-Write Coefficient Origin Audit

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R206M found that the D-scale endpoint is very close to:
G_i * exp((3pi - 1/2 ln2) * u_i)

and the whole-curve shape leaned toward:
G_i * exp((3pi - ln2) * u_i)

R207M tests whether the correction to 3pi behaves like an ln2-family correction:
3pi - c ln2

Key diagnostic constants:
D target context      = {D_TARGET}
top/e target context  = {TOP_E_TARGET}
3pi                   = {THREE_PI}
ln2                   = {LN2}
1/2 ln2               = {0.5 * LN2}
3pi - 1/2 ln2         = {THREE_PI - 0.5 * LN2}
3pi - ln2             = {THREE_PI - LN2}
K_req / 2             = {HALF_K_REQ}

Best origin scorecard:
{best_scorecard.to_string(index=False)}

Best model summary by D diagnostic:
{best_summary.to_string(index=False)}

Required correction summary:
{correction_summary.to_string(index=False)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
The correction is not random-looking. It lands in the ln2 family.

The best D endpoint candidate is:
3pi - 1/2 ln2

Mechanical reading:
half-action feedback divided by sqrt2 amplitude degeneracy.

The best curve-shape clue from R206 leaned toward:
3pi - ln2

Mechanical reading:
half-action feedback divided by a full binary branch factor.

This is a strong diagnostic, not a derivation.

Ruling:
No V12.13 promotion.

Next recommended run:
R208M — Binary/Sqrt2 Amplitude Degeneracy Mechanism Test

Question:
Can sqrt2 or binary branch dilution be derived from the per-cycle area-write accounting,
without using D as input?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    modes = build_modes()
    geometry = add_geometry_signal(modes)
    target_geometry = add_targets(geometry)

    origins = coefficient_origin_candidates()
    coords = coordinate_candidates(target_geometry)
    outputs = evaluate_origin_candidates(coords, origins)
    model_summary = summarize_origin_models(outputs)

    req = required_correction_by_mode(target_geometry)
    req_summary = summarize_required_correction(req)

    scorecard = origin_scorecard(model_summary, req_summary)

    gates = gate_matrix()
    claims = claim_boundary()

    best_scorecard = scorecard.head(12).copy()
    best_summary = model_summary.head(12).copy()

    verdict = (
        "PARTIAL_PASS_LN2_CORRECTION_FAMILY_IDENTIFIED_"
        "SQRT2_AMPLITUDE_DEGENERACY_LEADS_D_ENDPOINT_"
        "BINARY_BRANCH_SPLIT_REMAINS_CURVE_SHAPE_CANDIDATE_"
        "NATIVE_ORIGIN_NOT_DERIVED_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "three_pi": THREE_PI,
            "ln2": LN2,
            "half_ln2": 0.5 * LN2,
            "three_pi_minus_half_ln2": THREE_PI - 0.5 * LN2,
            "three_pi_minus_ln2": THREE_PI - LN2,
            "K_req_half": HALF_K_REQ,
            "p_D": P_D,
            "p_top": P_TOP,
            "p_half_6pi": P_HALF_6PI,
            "p_half_Kreq": P_HALF_KREQ,
        },
        "best_origin_scorecard": best_scorecard.to_dict(orient="records"),
        "best_model_summary_by_D_rmse": best_summary.to_dict(orient="records"),
        "required_correction_summary": req_summary.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R208M - Binary/Sqrt2 Amplitude Degeneracy Mechanism Test",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R207M_origin_scorecard.csv",
            "tables/R207M_required_correction_summary.csv",
            "Any traceback if the run failed."
        ],
    }

    modes.to_csv(tables / "R207M_mode_geometry_inputs.csv", index=False)
    geometry.to_csv(tables / "R207M_geometry_signal.csv", index=False)
    origins.to_csv(tables / "R207M_coefficient_origin_candidates.csv", index=False)
    coords.to_csv(tables / "R207M_coordinate_candidates_by_mode.csv", index=False)
    outputs.to_csv(tables / "R207M_origin_candidate_model_outputs.csv", index=False)
    model_summary.to_csv(tables / "R207M_origin_model_summary.csv", index=False)
    req.to_csv(tables / "R207M_required_correction_by_mode.csv", index=False)
    req_summary.to_csv(tables / "R207M_required_correction_summary.csv", index=False)
    scorecard.to_csv(tables / "R207M_origin_scorecard.csv", index=False)
    gates.to_csv(tables / "R207M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R207M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        best_scorecard=best_scorecard,
        best_summary=best_summary,
        correction_summary=req_summary,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(final_payload, indent=2))


if __name__ == "__main__":
    main()
