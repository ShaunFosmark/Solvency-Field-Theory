#!/usr/bin/env python3
"""
SFT V12.12B R222M — Activation Criterion Symbolic Theorem Attempt

Purpose:
    R221M identified the lead top-sector activation criterion candidate:

        At D-scale saturation, select the least nonzero no-overwrite terminal
        completion that closes both real support sectors.

    This selects:

        K_top = 4π + 2π = 6π

    R222M asks whether this can be written as a symbolic theorem/lemma rather
    than only a scored criterion.

Theorem target:
    Given:
        A1. D-scale trace lane is saturated.
        A2. No-overwrite requires the next admissible write to be minimal.
        A3. Top-sector terminal completion must close both real support sectors.
        A4. Full real support closure requires 4π spinor/spatial closure plus
            2π frame/gauge closure.
        A5. Terminal completion is not branch participation, so it is untaxed.

    Then:
        The unique minimal nonzero terminal completion is:

            K_top = 4π + 2π = 6π

    and the admissible layer count is exactly one.

Rules:
    - no species labels
    - no empirical particle mass fitting
    - top/e is diagnostic context only
    - exact top/e gap cannot define the law
    - no V12.13 promotion

Outputs:
    SFT_V12_12B_R222M_Activation_Criterion_Symbolic_Theorem_Attempt/
        report.md
        symbolic_theorem_note.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R222M.py

    SFT_V12_12B_R222M_Activation_Criterion_Symbolic_Theorem_Attempt_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R222M_Activation_Criterion_Symbolic_Theorem_Attempt"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF_FREEZE = 25.0 / 13.0
AMPLITUDE_TAX_FREEZE = 0.5 * math.log(N_EFF_FREEZE)
L_EFF_FREEZE = THREE_PI - AMPLITUDE_TAX_FREEZE
G_ENDPOINT_RHO2 = 2.0
D_SCALE_ENDPOINT = G_ENDPOINT_RHO2 * math.exp(L_EFF_FREEZE)

TOP_GAP_EXACT = TOP_E_TARGET / D_SCALE_ENDPOINT
TOP_GAP_LOG = math.log(TOP_GAP_EXACT)

SQRT2_HALF_ACTION_K_DIAGNOSTIC = 2.0 * (math.log(D_TARGET) - 0.5 * LN2)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def top_prediction(multiplier: float) -> dict:
    predicted = D_SCALE_ENDPOINT * multiplier
    factor = predicted / TOP_E_TARGET
    log_error = abs(math.log(factor)) if factor > 0 else float("inf")

    return {
        "multiplier": multiplier,
        "log_multiplier": math.log(multiplier) if multiplier > 0 else None,
        "predicted_top_e_scale": predicted,
        "predicted_top_e_vs_target_factor": factor,
        "top_e_log_error_abs": log_error,
        "top_e_percent_error": 100.0 * (factor - 1.0),
        "residual_multiplier_to_exact_gap": TOP_GAP_EXACT - multiplier,
        "residual_percent_of_exact_gap": 100.0 * ((TOP_GAP_EXACT - multiplier) / TOP_GAP_EXACT),
    }


def axiom_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "axiom_id": "A1",
            "name": "D_scale_saturation",
            "statement": "The trace-variational D-scale lane has reached its saturated endpoint.",
            "status": "ASSUMED_FROM_R218",
            "role": "Creates the condition under which a terminal top-sector completion may be considered.",
            "risk": "Saturation criterion is inherited, not newly proven here."
        },
        {
            "axiom_id": "A2",
            "name": "no_overwrite_minimality",
            "statement": "A next admissible write cannot overwrite prior ledger support and must be the least nonzero completion satisfying required closure.",
            "status": "SFT_CORE_PREMISE",
            "role": "Selects one minimal layer rather than zero, two, or arbitrary layers.",
            "risk": "Needs final embedding in global action."
        },
        {
            "axiom_id": "A3",
            "name": "both_sector_terminal_closure",
            "statement": "A terminal high-sector completion must close both real support sectors: spatial/spinor curvature and frame/gauge phase.",
            "status": "CONDITIONAL_PREMISE",
            "role": "Rejects half-closure and single-sector closure alternatives.",
            "risk": "Top-sector necessity of both-sector closure remains the key theorem burden."
        },
        {
            "axiom_id": "A4",
            "name": "full_closure_measure",
            "statement": "Full real support closure has measure 4π + 2π: 4π from spatial/spinor curvature closure and 2π from frame/gauge phase closure.",
            "status": "FORMAL_PASS",
            "role": "Derives K_top = 6π without top/e input.",
            "risk": "The closure measure is formal; action-level force still must be tied to terminal load."
        },
        {
            "axiom_id": "A5",
            "name": "terminal_completion_untaxed",
            "statement": "Terminal completion is a full closure/load, not branch participation, so the D-scale amplitude tax is not reapplied.",
            "status": "CONDITIONAL_PASS",
            "role": "Rejects 6π ± amplitude-tax controls as primary rules.",
            "risk": "Needs explicit action-level distinction between branch tax and terminal completion."
        },
    ])


def theorem_steps() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "step": 1,
            "claim": "At saturation, a terminal completion candidate may be evaluated.",
            "depends_on": "A1",
            "result": "Top-sector completion problem becomes admissible.",
            "status": "PASS_CONDITIONAL"
        },
        {
            "step": 2,
            "claim": "The next write must be nonzero if terminal closure is required.",
            "depends_on": "A2,A3",
            "result": "Zero extra layer is rejected.",
            "status": "PASS_CONDITIONAL"
        },
        {
            "step": 3,
            "claim": "The completion must close both real support sectors.",
            "depends_on": "A3",
            "result": "Half-layer and single-sector closures are rejected.",
            "status": "PASS_CONDITIONAL"
        },
        {
            "step": 4,
            "claim": "The minimal both-sector full closure has measure 4π + 2π.",
            "depends_on": "A4",
            "result": "K_top = 6π.",
            "status": "PASS_FORMAL"
        },
        {
            "step": 5,
            "claim": "No-overwrite minimality selects one instance of the minimal full closure.",
            "depends_on": "A2,A4",
            "result": "Two or more layers are rejected as duplicate terminal writes.",
            "status": "PASS_CONDITIONAL"
        },
        {
            "step": 6,
            "claim": "Terminal completion is untaxed.",
            "depends_on": "A5",
            "result": "Taxed 6π variants are demoted as controls.",
            "status": "CONDITIONAL_PASS"
        },
        {
            "step": 7,
            "claim": "Therefore the selected terminal top-sector load is exactly one untaxed 6π layer.",
            "depends_on": "A1,A2,A3,A4,A5",
            "result": "K_top = 6π.",
            "status": "THEOREM_CANDIDATE"
        },
    ])


def theorem_candidate_record() -> dict:
    rec = top_prediction(SIX_PI)
    rec.update({
        "theorem_id": "T1",
        "theorem_name": "minimal_nonzero_terminal_completion_selects_one_6pi",
        "formal_statement": "If D-scale saturation holds, no-overwrite minimality applies, both real support sectors must terminally close, full support closure is 4π+2π, and terminal completion is untaxed, then the unique minimal nonzero terminal completion is one K_top=6π layer.",
        "selected_multiplier": "K_top = 4*pi + 2*pi = 6*pi",
        "selected_layer_count": 1,
        "uses_top_to_define": False,
        "uses_D_to_define": False,
        "theorem_status": "SYMBOLIC_CONDITIONAL_PASS",
        "missing_for_full_theorem": "A1/A3/A5 still need full global action derivation.",
    })
    return rec


def alternative_record(
    model_id: str,
    multiplier: float,
    rule: str,
    status: str,
    rejection_logic: str,
    uses_top_to_define: bool = False,
    uses_D_to_define: bool = False,
) -> dict:
    rec = top_prediction(multiplier)
    rec.update({
        "model_id": model_id,
        "rule": rule,
        "status": status,
        "rejection_logic": rejection_logic,
        "uses_top_to_define": uses_top_to_define,
        "uses_D_to_define": uses_D_to_define,
    })

    score = 0.0
    err = rec["top_e_log_error_abs"]

    if err < 0.005:
        score += 4.0
    elif err < 0.01:
        score += 3.0
    elif err < 0.03:
        score += 2.0
    elif err < 0.10:
        score += 1.0

    if status.startswith("REJECT"):
        score -= 8.0
    if uses_top_to_define:
        score -= 20.0
    if uses_D_to_define:
        score -= 8.0

    rec["alternative_score"] = score
    return rec


def alternative_matrix() -> pd.DataFrame:
    rows = [
        alternative_record(
            "zero_layer_null",
            1.0,
            "K_top = 1",
            "REJECT_UNDERCLOSURE",
            "Contradicts A3 if terminal both-sector closure is required."
        ),
        alternative_record(
            "half_layer_3pi_null",
            THREE_PI,
            "K_top = 3π",
            "REJECT_HALF_CLOSURE",
            "Does not close both 4π and 2π sectors."
        ),
        alternative_record(
            "one_6pi_theorem_candidate",
            SIX_PI,
            "K_top = 4π + 2π",
            "LEAD_THEOREM_CANDIDATE",
            "Selected by A1-A5."
        ),
        alternative_record(
            "two_6pi_layers_null",
            SIX_PI * SIX_PI,
            "K_top = (6π)^2",
            "REJECT_OVERCLOSURE",
            "Violates minimal next-write; duplicates terminal completion."
        ),
        alternative_record(
            "taxed_minus_control",
            SIX_PI - AMPLITUDE_TAX_FREEZE,
            "K_top = 6π - 1/2 ln(25/13)",
            "REJECT_AS_PRIMARY",
            "Reapplies D-scale branch participation tax to terminal completion."
        ),
        alternative_record(
            "taxed_plus_control",
            SIX_PI + AMPLITUDE_TAX_FREEZE,
            "K_top = 6π + 1/2 ln(25/13)",
            "REJECT_AS_PRIMARY",
            "Adds D-scale branch participation tax to terminal completion without action reason."
        ),
        alternative_record(
            "legacy_K_req_bridge",
            K_REQ,
            "K_top = K_req",
            "SUPPORTIVE_DIAGNOSTIC_BRIDGE",
            "Close to 6π and exact gap, but not derived by this theorem."
        ),
        alternative_record(
            "sqrt2_half_action_K_diagnostic",
            SQRT2_HALF_ACTION_K_DIAGNOSTIC,
            "K = 2(ln D - 1/2 ln2)",
            "DIAGNOSTIC_USES_D",
            "Uses D relation, not a native terminal activation theorem.",
            uses_D_to_define=True,
        ),
        alternative_record(
            "exact_gap_forbidden",
            TOP_GAP_EXACT,
            "K_top = top/e divided by D-scale endpoint",
            "REJECT_AS_DERIVATION",
            "Uses top/e and cannot define the law.",
            uses_top_to_define=True,
        ),
    ]

    return pd.DataFrame(rows).sort_values("alternative_score", ascending=False).reset_index(drop=True)


def theorem_gate_matrix() -> pd.DataFrame:
    theorem = theorem_candidate_record()

    return pd.DataFrame([
        {
            "gate": "symbolic_derivation_written",
            "test": "Are premises A1-A5 and proof steps written explicitly?",
            "status": "PASS",
            "evidence": "Axiom matrix and theorem steps generated.",
            "boundary": "Conditional theorem, not final global action theorem."
        },
        {
            "gate": "derives_6pi_without_top",
            "test": "Does theorem derive K_top without top/e?",
            "status": "PASS",
            "evidence": "K_top = 4π + 2π = 6π from support closure.",
            "boundary": "Candidate top-sector load."
        },
        {
            "gate": "selects_exactly_one_layer",
            "test": "Does theorem reject zero and two layers?",
            "status": "PASS_CONDITIONAL",
            "evidence": "Zero violates nonzero terminal closure; two violates minimal next-write.",
            "boundary": "Depends on A2/A3."
        },
        {
            "gate": "rejects_half_layer",
            "test": "Does theorem reject 3π?",
            "status": "PASS_CONDITIONAL",
            "evidence": "3π does not close both 4π and 2π sectors.",
            "boundary": "Depends on A3/A4."
        },
        {
            "gate": "untaxed_completion",
            "test": "Does theorem distinguish terminal completion from D-scale branch tax?",
            "status": "PARTIAL_PASS",
            "evidence": "A5 states terminal completion is untaxed.",
            "boundary": "A5 still needs action-level proof."
        },
        {
            "gate": "top_e_diagnostic_match",
            "test": "Does theorem candidate remain near top/e diagnostic?",
            "status": "PASS_DIAGNOSTIC",
            "evidence": f"predicted factor={theorem['predicted_top_e_vs_target_factor']}, error={theorem['top_e_percent_error']}%",
            "boundary": "Diagnostic only."
        },
        {
            "gate": "full_action_theorem",
            "test": "Are all premises derived from full master action?",
            "status": "FAIL_OPEN",
            "evidence": "A1/A3/A5 are conditional or inherited.",
            "boundary": "Blocks top/e closure and V12.13."
        },
        {
            "gate": "top_e_closed",
            "test": "Is top/e solved?",
            "status": "NO",
            "evidence": "Residual and full theorem remain open.",
            "boundary": "No V12.13."
        },
    ])


def residual_analysis() -> pd.DataFrame:
    residual = TOP_GAP_EXACT - SIX_PI
    log_residual = TOP_GAP_LOG - math.log(SIX_PI)

    return pd.DataFrame([
        {
            "quantity": "exact_gap_minus_6pi",
            "value": residual,
            "ruling": "OPEN_DIAGNOSTIC_ONLY",
            "comment": "Do not fit residual before theorem premises are globally derived."
        },
        {
            "quantity": "percent_gap_above_6pi",
            "value": 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0),
            "ruling": "OPEN_DIAGNOSTIC_ONLY",
            "comment": "Current top/e context is 0.6324% above 6π candidate."
        },
        {
            "quantity": "log_gap_minus_log_6pi",
            "value": log_residual,
            "ruling": "OPEN_DIAGNOSTIC_ONLY",
            "comment": "Log residual remains open."
        },
        {
            "quantity": "residual_over_amplitude_tax",
            "value": residual / AMPLITUDE_TAX_FREEZE,
            "ruling": "NO_CLAIM",
            "comment": "No stable native relation promoted."
        },
        {
            "quantity": "residual_over_ln2",
            "value": residual / LN2,
            "ruling": "NO_CLAIM",
            "comment": "No stable binary relation promoted."
        },
        {
            "quantity": "residual_over_2pi",
            "value": residual / TWO_PI,
            "ruling": "NO_CLAIM",
            "comment": "No stable phase relation promoted."
        },
    ])


def proof_status_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "claim": "A symbolic conditional theorem for one extra 6π can be written.",
            "status": "PASS",
            "evidence": "A1-A5 imply K_top = 6π under stated rules.",
            "boundary": "Conditional theorem."
        },
        {
            "claim": "The theorem is independent of top/e.",
            "status": "PASS",
            "evidence": "K_top derives from 4π+2π, not exact top/e gap.",
            "boundary": "Top/e remains diagnostic only."
        },
        {
            "claim": "Exactly one layer is selected.",
            "status": "PASS_CONDITIONAL",
            "evidence": "Minimal nonzero no-overwrite completion selects one layer.",
            "boundary": "Depends on A2/A3."
        },
        {
            "claim": "The layer is untaxed.",
            "status": "PARTIAL_PASS",
            "evidence": "A5 distinguishes terminal completion from branch participation.",
            "boundary": "Needs action-level proof."
        },
        {
            "claim": "Top/e is fully closed.",
            "status": "NO",
            "evidence": "A1/A3/A5 and residual remain open.",
            "boundary": "No V12.13."
        },
    ])


def open_claims_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "open_claim": "derive_A1_saturation_from_action",
            "status": "OPEN",
            "current_best_candidate": "D-scale trace lane saturation inherited from R218.",
            "why_open": "Saturation condition is assumed at endpoint, not globally proven.",
            "required_next": "Write action-level saturation condition.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "derive_A3_both_sector_terminal_closure",
            "status": "OPEN",
            "current_best_candidate": "Top terminal completion must close spatial/spinor and frame/gauge sectors.",
            "why_open": "This is mechanically natural but still a conditional premise.",
            "required_next": "Show top-sector terminal state requires both sectors.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "derive_A5_untaxed_completion",
            "status": "OPEN",
            "current_best_candidate": "Terminal completion is not branch participation.",
            "why_open": "Untaxed rule is conditionally supported, not action-proven.",
            "required_next": "Separate terminal closure term from D-scale amplitude-tax term in action.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "residual_gap",
            "status": "OPEN",
            "current_best_candidate": "Residual is 0.6324% above 6π candidate.",
            "why_open": "Could be correction, target context, or approximation.",
            "required_next": "Do not fit residual until premises are action-derived.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "species_map",
            "status": "OPEN",
            "current_best_candidate": "Deferred.",
            "why_open": "No species labels used.",
            "required_next": "Later species map constraint skeleton.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "prediction_null_suite",
            "status": "OPEN",
            "current_best_candidate": "Not addressed.",
            "why_open": "No blind prediction/null suite.",
            "required_next": "Build no-retuning test suite.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "V12_13_promotion",
            "status": "NO",
            "current_best_candidate": "Not eligible.",
            "why_open": "Top/e not fully closed and species/predictions remain open.",
            "required_next": "No promotion.",
            "promotion_blocker": True,
        },
    ])


def claim_boundary_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Allowed claim",
            "claim": "R222M writes a symbolic conditional theorem candidate for one extra 6π.",
            "status": "YES",
            "safe_wording": "Conditional theorem candidate."
        },
        {
            "category": "Allowed claim",
            "claim": "A1-A5 imply K_top = 4π + 2π = 6π.",
            "status": "YES",
            "safe_wording": "Within the stated premise set."
        },
        {
            "category": "Allowed claim",
            "claim": "The theorem does not use the exact top/e gap to define the multiplier.",
            "status": "YES",
            "safe_wording": "Top/e remains diagnostic only."
        },
        {
            "category": "Blocked claim",
            "claim": "Top/e is solved.",
            "status": "NO",
            "safe_wording": "A1/A3/A5 and residual remain open."
        },
        {
            "category": "Blocked claim",
            "claim": "The theorem is fully derived from the global master action.",
            "status": "NO",
            "safe_wording": "Still conditional."
        },
        {
            "category": "Blocked claim",
            "claim": "Species map is derived.",
            "status": "NO",
            "safe_wording": "Species map remains open."
        },
        {
            "category": "Blocked claim",
            "claim": "V12.13 is promoted.",
            "status": "NO",
            "safe_wording": "No V12.13 promotion."
        },
    ])


def symbolic_theorem_note_text(created_utc: str) -> str:
    return f"""
# R222M Activation Criterion Symbolic Theorem Attempt

Generated: {created_utc}

## Theorem candidate

Given:

A1. D-scale trace lane is saturated.
A2. No-overwrite requires the next admissible write to be the least nonzero completion satisfying required closure.
A3. Top-sector terminal completion must close both real support sectors.
A4. Full support closure is 4pi spinor/spatial curvature closure plus 2pi frame/gauge phase closure.
A5. Terminal completion is not branch participation, so it is untaxed.

Then:

    K_top = 4pi + 2pi = 6pi

and the unique minimal nonzero terminal completion is exactly one untaxed 6pi layer.

## Diagnostic

D-scale endpoint:

    {D_SCALE_ENDPOINT}

6pi candidate top/e scale:

    {D_SCALE_ENDPOINT * SIX_PI}

Candidate / top/e context:

    {(D_SCALE_ENDPOINT * SIX_PI) / TOP_E_TARGET}

Exact top/e gap:

    {TOP_GAP_EXACT}

Residual gap minus 6pi:

    {TOP_GAP_EXACT - SIX_PI}

## Boundary

This is a symbolic conditional theorem candidate.
It is not a full global action theorem yet.
A1, A3, and A5 remain open action-level premises.
Top/e is not solved.
No species map.
No V12.13 promotion.
"""


def build_report(
    created_utc: str,
    verdict: str,
    axioms: pd.DataFrame,
    steps: pd.DataFrame,
    theorem: dict,
    alternatives: pd.DataFrame,
    gates: pd.DataFrame,
    residuals: pd.DataFrame,
    proof_status: pd.DataFrame,
    open_claims: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R222M — Activation Criterion Symbolic Theorem Attempt

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R222M attempts to write the R221 activation criterion as a symbolic conditional theorem.

Theorem candidate:
{json.dumps(json_safe(theorem), indent=2)}

Axiom matrix:
{axioms.to_string(index=False)}

Theorem steps:
{steps.to_string(index=False)}

Alternative matrix:
{alternatives.to_string(index=False)}

Theorem gate matrix:
{gates.to_string(index=False)}

Residual analysis:
{residuals.to_string(index=False)}

Proof status ledger:
{proof_status.to_string(index=False)}

Open claims ledger:
{open_claims.to_string(index=False)}

Claim boundary matrix:
{claims.to_string(index=False)}

Interpretation:
R222M successfully writes the top-sector activation rule as a symbolic conditional theorem:

A1-A5 imply that the unique minimal nonzero terminal completion is one untaxed K_top = 4π + 2π = 6π layer.

This is stronger than the R221 scorecard because the premises, proof steps, and rejected alternatives are now explicit. However, it is still conditional: A1 saturation, A3 both-sector terminal closure, and A5 untaxed terminal completion remain to be derived from the full master action.

Ruling:
Symbolic conditional theorem candidate preserved.
Top/e not fully solved.
No species map.
No prediction suite.
No V12.13 promotion.

Next recommended run:
R223M — Action-Level Premise Closure Audit

Question:
Which of A1, A3, and A5 can be promoted from conditional premises to action-derived statements?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    axioms = axiom_matrix()
    steps = theorem_steps()
    theorem = theorem_candidate_record()
    alternatives = alternative_matrix()
    gates = theorem_gate_matrix()
    residuals = residual_analysis()
    proof_status = proof_status_ledger()
    open_claims = open_claims_ledger()
    claims = claim_boundary_matrix()

    verdict = (
        "PARTIAL_PASS_SYMBOLIC_CONDITIONAL_THEOREM_FOR_ONE_EXTRA_6PI_WRITTEN_"
        "A1_TO_A5_IMPLY_UNIQUE_MINIMAL_NONZERO_UNTAXED_TERMINAL_COMPLETION_KTOP_EQUALS_4PI_PLUS_2PI_"
        "THEOREM_INDEPENDENT_OF_TOP_E_GAP_BUT_A1_A3_A5_REMAIN_ACTION_LEVEL_OPEN_"
        "RESIDUAL_SPECIES_PREDICTION_SUITE_AND_V12_13_OPEN"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "symbolic_theorem_candidate": theorem,
        "axioms": axioms.to_dict(orient="records"),
        "theorem_steps": steps.to_dict(orient="records"),
        "top_e_context": {
            "top_e_target_context": TOP_E_TARGET,
            "exact_multiplier_gap": TOP_GAP_EXACT,
            "gap_minus_6pi": TOP_GAP_EXACT - SIX_PI,
            "gap_percent_above_6pi": 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0),
            "sixpi_predicted_top_e": D_SCALE_ENDPOINT * SIX_PI,
            "sixpi_predicted_top_e_vs_target": (D_SCALE_ENDPOINT * SIX_PI) / TOP_E_TARGET,
        },
        "alternatives": alternatives.to_dict(orient="records"),
        "proof_status": proof_status.to_dict(orient="records"),
        "open_claims": open_claims.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "Symbolic conditional theorem candidate preserved; top/e not fully solved; no V12.13.",
        "next_recommended": "R223M - Action-Level Premise Closure Audit",
        "paste_back_to_chat": [
            "summary.json",
            "symbolic_theorem_note.md",
            "tables/R222M_axiom_matrix.csv",
            "tables/R222M_theorem_steps.csv",
            "tables/R222M_alternative_matrix.csv",
            "Any traceback if the run failed."
        ],
    }

    axioms.to_csv(tables / "R222M_axiom_matrix.csv", index=False)
    steps.to_csv(tables / "R222M_theorem_steps.csv", index=False)
    alternatives.to_csv(tables / "R222M_alternative_matrix.csv", index=False)
    gates.to_csv(tables / "R222M_theorem_gate_matrix.csv", index=False)
    residuals.to_csv(tables / "R222M_residual_analysis.csv", index=False)
    proof_status.to_csv(tables / "R222M_proof_status_ledger.csv", index=False)
    open_claims.to_csv(tables / "R222M_open_claims_ledger.csv", index=False)
    claims.to_csv(tables / "R222M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        axioms=axioms,
        steps=steps,
        theorem=theorem,
        alternatives=alternatives,
        gates=gates,
        residuals=residuals,
        proof_status=proof_status,
        open_claims=open_claims,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "symbolic_theorem_note.md").write_text(symbolic_theorem_note_text(created_utc), encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
