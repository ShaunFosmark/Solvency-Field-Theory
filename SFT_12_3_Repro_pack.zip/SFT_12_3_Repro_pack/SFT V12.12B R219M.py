#!/usr/bin/env python3
"""
SFT V12.12B R219M_ALT — Top/e Closure Mechanism Triage

Purpose:
    R218M froze the D-scale trace-variational law candidate:

        M_i = G_i exp(L_eff u_i)

        L_eff = 3π - 1/2 ln(25/13)

    with endpoint:

        endpoint_rho2 = 17871.48862357384
        endpoint_vs_D = 0.9996800358435753

    But the current top/e diagnostic scale remains open:

        top/e ≈ 339000

    R219M_ALT does NOT try to assign species.

    It asks a cleaner structural question:

        Does the top/e scale require one additional high-sector closure layer
        beyond the frozen D-scale law?

    Candidate multipliers tested:
        - exact top/e gap diagnostic only
        - 6π high-sector closure load
        - legacy K_req load
        - 2 * L_eff frozen half-action layer
        - 6π +/- amplitude tax variants
        - sqrt2 half-action diagnostic K
        - second D-scale layer hard-fail control

Rules:
    - no species labels
    - no empirical particle mass fitting
    - top/e is diagnostic context only
    - exact top/e gap cannot define the law
    - no V12.13 promotion

Outputs:
    SFT_V12_12B_R219M_ALT_Top_e_Closure_Mechanism_Triage/
        report.md
        top_e_triage_note.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R219M_ALT.py

    SFT_V12_12B_R219M_ALT_Top_e_Closure_Mechanism_Triage_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R219M_ALT_Top_e_Closure_Mechanism_Triage"

# Frozen R218M D-scale law context.
D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF_FREEZE = 25.0 / 13.0
AMPLITUDE_TAX_FREEZE = 0.5 * math.log(N_EFF_FREEZE)
L_EFF_FREEZE = THREE_PI - AMPLITUDE_TAX_FREEZE
G_ENDPOINT_RHO2 = 2.0
D_SCALE_ENDPOINT = G_ENDPOINT_RHO2 * math.exp(L_EFF_FREEZE)

TOP_GAP_EXACT = TOP_E_TARGET / D_SCALE_ENDPOINT
TOP_GAP_LOG = math.log(TOP_GAP_EXACT)

# R191/R190-style diagnostic. It uses D and remains diagnostic-only.
SQRT2_HALF_ACTION_K_DIAGNOSTIC = 2.0 * (math.log(D_TARGET) - 0.5 * LN2)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def multiplier_record(
    model_id: str,
    multiplier: float,
    status: str,
    native_prior: float,
    uses_top_to_define: bool,
    uses_D_to_define: bool,
    interpretation: str,
) -> dict:
    predicted_top_e = D_SCALE_ENDPOINT * multiplier
    factor = predicted_top_e / TOP_E_TARGET
    log_error = abs(math.log(factor))

    score = native_prior

    if log_error < 0.001:
        score += 7.0
    elif log_error < 0.005:
        score += 6.0
    elif log_error < 0.01:
        score += 5.0
    elif log_error < 0.03:
        score += 4.0
    elif log_error < 0.10:
        score += 2.0
    elif log_error < 0.50:
        score += 1.0

    if uses_top_to_define:
        score -= 16.0
    if uses_D_to_define:
        score -= 6.0
    if "control" in status.lower():
        score -= 2.0
    if "hard_fail" in status.lower():
        score -= 8.0

    return {
        "model_id": model_id,
        "status": status,
        "interpretation": interpretation,
        "multiplier": multiplier,
        "log_multiplier": math.log(multiplier) if multiplier > 0 else None,
        "predicted_top_e_scale": predicted_top_e,
        "predicted_top_e_vs_target_factor": factor,
        "top_e_log_error_abs": log_error,
        "top_e_percent_error": 100.0 * (factor - 1.0),
        "uses_top_to_define": uses_top_to_define,
        "uses_D_to_define": uses_D_to_define,
        "native_prior": native_prior,
        "combined_score": score,
    }


def top_e_multiplier_scorecard() -> pd.DataFrame:
    records = []

    records.append(multiplier_record(
        model_id="exact_top_gap_diagnostic",
        multiplier=TOP_GAP_EXACT,
        status="DIAGNOSTIC_ONLY_USES_TOP",
        native_prior=-10.0,
        uses_top_to_define=True,
        uses_D_to_define=False,
        interpretation="Exact gap from frozen D-scale endpoint to top/e; cannot define the theory.",
    ))

    records.append(multiplier_record(
        model_id="six_pi_high_sector_closure",
        multiplier=SIX_PI,
        status="LEAD_STRUCTURAL_CANDIDATE",
        native_prior=11.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        interpretation="One additional 6π high-sector closure/load layer on top of the frozen D-scale endpoint.",
    ))

    records.append(multiplier_record(
        model_id="legacy_K_req_load",
        multiplier=K_REQ,
        status="SUPPORTIVE_LEGACY_LOAD_CANDIDATE",
        native_prior=8.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        interpretation="Legacy K_req load from earlier K/beta lane; close to 6π but not newly derived here.",
    ))

    records.append(multiplier_record(
        model_id="sqrt2_half_action_K_diagnostic",
        multiplier=SQRT2_HALF_ACTION_K_DIAGNOSTIC,
        status="DIAGNOSTIC_USES_D",
        native_prior=4.0,
        uses_top_to_define=False,
        uses_D_to_define=True,
        interpretation="R191-style K from D and sqrt2 half-action relation; diagnostic only because it uses D.",
    ))

    records.append(multiplier_record(
        model_id="two_times_frozen_L_eff",
        multiplier=2.0 * L_EFF_FREEZE,
        status="STRUCTURAL_CONTROL",
        native_prior=5.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        interpretation="Second half-action layer using 2*L_eff_freeze rather than 6π.",
    ))

    records.append(multiplier_record(
        model_id="six_pi_plus_amplitude_tax",
        multiplier=SIX_PI + AMPLITUDE_TAX_FREEZE,
        status="CORRECTION_CONTROL",
        native_prior=4.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        interpretation="6π with amplitude tax added back as a possible correction; tested as control.",
    ))

    records.append(multiplier_record(
        model_id="six_pi_minus_amplitude_tax",
        multiplier=SIX_PI - AMPLITUDE_TAX_FREEZE,
        status="CORRECTION_CONTROL",
        native_prior=4.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        interpretation="6π with amplitude tax subtracted as a possible correction; tested as control.",
    ))

    records.append(multiplier_record(
        model_id="four_pi_plus_two_pi_direct",
        multiplier=FOUR_PI + TWO_PI,
        status="SAME_AS_6PI_ALIAS",
        native_prior=10.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        interpretation="Alias for 6π = 4π + 2π, recorded to preserve the closure interpretation.",
    ))

    records.append(multiplier_record(
        model_id="pure_K_eq_6pi_with_small_residual_open",
        multiplier=SIX_PI,
        status="RESIDUAL_OPEN_ALIAS",
        native_prior=10.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        interpretation="Same 6π candidate; residual to exact gap recorded as open correction.",
    ))

    records.append(multiplier_record(
        model_id="second_D_scale_layer_control",
        multiplier=D_TARGET,
        status="HARD_FAIL_CONTROL",
        native_prior=1.0,
        uses_top_to_define=False,
        uses_D_to_define=True,
        interpretation="A full second D-scale multiplication; expected to overshoot badly.",
    ))

    df = pd.DataFrame(records)
    return df.sort_values("combined_score", ascending=False).reset_index(drop=True)


def gap_diagnostics() -> pd.DataFrame:
    rows = []

    candidates = {
        "exact_top_gap": TOP_GAP_EXACT,
        "6pi": SIX_PI,
        "K_req": K_REQ,
        "sqrt2_half_action_K_diagnostic": SQRT2_HALF_ACTION_K_DIAGNOSTIC,
        "2_L_eff_freeze": 2.0 * L_EFF_FREEZE,
        "6pi_plus_amplitude_tax": SIX_PI + AMPLITUDE_TAX_FREEZE,
        "6pi_minus_amplitude_tax": SIX_PI - AMPLITUDE_TAX_FREEZE,
    }

    for name, val in candidates.items():
        rows.append({
            "quantity": name,
            "value": val,
            "difference_from_exact_gap": val - TOP_GAP_EXACT,
            "ratio_to_exact_gap": val / TOP_GAP_EXACT,
            "percent_error_vs_exact_gap": 100.0 * (val / TOP_GAP_EXACT - 1.0),
            "difference_from_6pi": val - SIX_PI,
            "ratio_to_6pi": val / SIX_PI,
        })

    return pd.DataFrame(rows)


def mechanism_triage_matrix(scorecard: pd.DataFrame) -> pd.DataFrame:
    lead = scorecard[scorecard["model_id"] == "six_pi_high_sector_closure"].iloc[0]
    kreq = scorecard[scorecard["model_id"] == "legacy_K_req_load"].iloc[0]
    exact = scorecard[scorecard["model_id"] == "exact_top_gap_diagnostic"].iloc[0]
    second_d = scorecard[scorecard["model_id"] == "second_D_scale_layer_control"].iloc[0]

    return pd.DataFrame([
        {
            "mechanism": "single additional 6π closure layer",
            "status": "LIVE_LEAD_CANDIDATE",
            "evidence": f"endpoint factor {lead['predicted_top_e_vs_target_factor']}, log error {lead['top_e_log_error_abs']}",
            "ruling": "Keep as top/e structural candidate, not closure.",
            "open_requirement": "Derive why top sector receives one full 6π closure/load layer after D-scale freeze."
        },
        {
            "mechanism": "legacy K_req layer",
            "status": "LIVE_SUPPORTIVE",
            "evidence": f"endpoint factor {kreq['predicted_top_e_vs_target_factor']}, log error {kreq['top_e_log_error_abs']}",
            "ruling": "Supportive bridge because K_req is near 6π, but not newly derived here.",
            "open_requirement": "Recover K_req mechanically without tuning."
        },
        {
            "mechanism": "exact top/e gap multiplier",
            "status": "REJECT_AS_DERIVATION",
            "evidence": f"exact multiplier {exact['multiplier']}",
            "ruling": "Diagnostic only.",
            "open_requirement": "Cannot be used to define the theory."
        },
        {
            "mechanism": "full second D-scale layer",
            "status": "HARD_FAIL",
            "evidence": f"endpoint factor {second_d['predicted_top_e_vs_target_factor']}",
            "ruling": "Reject as overshoot.",
            "open_requirement": "None; this control fails."
        },
        {
            "mechanism": "species-map explanation",
            "status": "DEFER",
            "evidence": "No species assignment rule exists yet.",
            "ruling": "Do not use species labels to solve top/e.",
            "open_requirement": "Species mapping must be derived later and separately."
        },
    ])


def open_claims_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "open_claim": "top_e_closure",
            "status": "OPEN_BUT_NARROWED",
            "current_best_candidate": "D-scale freeze endpoint multiplied by one additional 6π high-sector closure/load layer.",
            "why_open": "The 6π multiplier is close but not derived as a top-sector requirement.",
            "next_test": "Derive or reject the one-extra-6π-layer rule from support closure/action bookkeeping.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "K_req_origin",
            "status": "OPEN",
            "current_best_candidate": "K_req as 6π plus small residual/correction.",
            "why_open": "K_req is close to 6π but remains an old diagnostic load, not a derived top rule.",
            "next_test": "Check whether residual exact_gap - 6π has a native correction source.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "species_map",
            "status": "OPEN",
            "current_best_candidate": "Deferred.",
            "why_open": "Using species labels now risks accidental fitting.",
            "next_test": "Only attempt after top/e structural triage is bounded.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "prediction_null_suite",
            "status": "OPEN",
            "current_best_candidate": "Not addressed in R219M_ALT.",
            "why_open": "No blind prediction/null test produced yet.",
            "next_test": "Build no-retuning test suite once top/e rule is bounded.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "V12_13_promotion",
            "status": "NO",
            "current_best_candidate": "Not eligible.",
            "why_open": "Top/e is narrowed but not closed; species/predictions open.",
            "next_test": "No promotion until blockers are solved or scoped out.",
            "promotion_blocker": True,
        },
    ])


def promotion_gate_matrix(scorecard: pd.DataFrame) -> pd.DataFrame:
    lead = scorecard[scorecard["model_id"] == "six_pi_high_sector_closure"].iloc[0]
    exact = scorecard[scorecard["model_id"] == "exact_top_gap_diagnostic"].iloc[0]

    return pd.DataFrame([
        {
            "gate": "top_e_gap_identified",
            "status": "PASS",
            "evidence": f"Exact top/e gap from D-scale endpoint is {TOP_GAP_EXACT}.",
            "effect": "Provides target for structural triage."
        },
        {
            "gate": "six_pi_candidate",
            "status": "PASS_LIVE_CANDIDATE",
            "evidence": f"6π candidate factor={lead['predicted_top_e_vs_target_factor']}, percent_error={lead['top_e_percent_error']}.",
            "effect": "Narrowed top/e to a likely one-layer closure question."
        },
        {
            "gate": "exact_gap_not_used",
            "status": "PASS_BOUNDARY",
            "evidence": f"Exact gap model exists but is diagnostic-only, score={exact['combined_score']}.",
            "effect": "Prevents fitting."
        },
        {
            "gate": "top_e_derived",
            "status": "FAIL_OPEN",
            "evidence": "No derivation yet forces one extra 6π layer.",
            "effect": "Blocks V12.13."
        },
        {
            "gate": "species_assignment",
            "status": "FAIL_OPEN",
            "evidence": "No species map attempted or promoted.",
            "effect": "Blocks V12.13."
        },
        {
            "gate": "prediction_null_suite",
            "status": "FAIL_OPEN",
            "evidence": "No blind prediction/null test.",
            "effect": "Blocks V12.13."
        },
        {
            "gate": "V12_13",
            "status": "NO_PROMOTION",
            "evidence": "R219M_ALT is triage only.",
            "effect": "Preserve R218 freeze boundary."
        },
    ])


def claim_boundary_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Allowed claim",
            "claim": "R219M_ALT identifies 6π as the lead structural top/e multiplier candidate.",
            "status": "YES",
            "safe_wording": "Lead candidate, not derived closure."
        },
        {
            "category": "Allowed claim",
            "claim": "The top/e gap from the frozen D-scale endpoint is near 6π/K_req.",
            "status": "YES",
            "safe_wording": "Diagnostic proximity."
        },
        {
            "category": "Allowed claim",
            "claim": "A full second D-scale layer overshoots and is rejected.",
            "status": "YES",
            "safe_wording": "Control failure."
        },
        {
            "category": "Blocked claim",
            "claim": "Top/e is solved.",
            "status": "NO",
            "safe_wording": "Top/e closure remains open."
        },
        {
            "category": "Blocked claim",
            "claim": "The exact top/e gap defines the multiplier.",
            "status": "NO",
            "safe_wording": "Exact gap is diagnostic-only and uses top/e."
        },
        {
            "category": "Blocked claim",
            "claim": "Species map is derived.",
            "status": "NO",
            "safe_wording": "Species map deferred."
        },
        {
            "category": "Blocked claim",
            "claim": "V12.13 is promoted.",
            "status": "NO",
            "safe_wording": "No V12.13 promotion."
        },
    ])


def top_e_triage_note_text(created_utc: str) -> str:
    return f"""
# R219M_ALT Top/e Closure Mechanism Triage Note

Generated: {created_utc}

This run preserves the R218 D-scale law freeze boundary.

## Frozen D-scale law input

    M_i = G_i exp[(3pi - 1/2 ln(25/13)) u_i]

with endpoint:

    D_scale_endpoint = {D_SCALE_ENDPOINT}

## Top/e diagnostic gap

    top/e target = {TOP_E_TARGET}
    exact gap = top/e / D_scale_endpoint = {TOP_GAP_EXACT}

Compare:

    6pi = {SIX_PI}
    K_req = {K_REQ}
    sqrt2 half-action diagnostic K = {SQRT2_HALF_ACTION_K_DIAGNOSTIC}

## Ruling

The lead structural candidate is:

    top/e ≈ D_scale_endpoint * 6pi

This is not a derivation. It is a narrowed mechanism candidate.

The exact gap is diagnostic-only because it uses top/e.

A full second D-scale layer is rejected as a hard-fail overshoot.

## Open

The next proof target is:

    Why would the top sector receive one additional 6pi high-sector closure/load layer?

No species map.
No top/e closure.
No V12.13 promotion.
"""


def build_report(
    created_utc: str,
    verdict: str,
    scorecard: pd.DataFrame,
    diagnostics: pd.DataFrame,
    mechanisms: pd.DataFrame,
    open_claims: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R219M_ALT — Top/e Closure Mechanism Triage

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R219M_ALT tests whether top/e requires one additional high-sector closure layer beyond the frozen R218 D-scale law.

Frozen D-scale endpoint:
{D_SCALE_ENDPOINT}

Exact top/e gap:
{TOP_GAP_EXACT}

Multiplier scorecard:
{scorecard.to_string(index=False)}

Gap diagnostics:
{diagnostics.to_string(index=False)}

Mechanism triage matrix:
{mechanisms.to_string(index=False)}

Open claims ledger:
{open_claims.to_string(index=False)}

Promotion gate matrix:
{gates.to_string(index=False)}

Claim boundary matrix:
{claims.to_string(index=False)}

Interpretation:
R219M_ALT narrows the top/e problem. The frozen D-scale endpoint is short of the top/e diagnostic scale by a factor near 6π and legacy K_req.

The lead structural candidate is one additional 6π high-sector closure/load layer. However, this is not a derivation. The exact gap is diagnostic-only because it uses top/e. A full second D-scale layer fails by overshooting badly.

Ruling:
Top/e closure is narrowed but remains open.
No species map.
No V12.13 promotion.

Next recommended run:
R220M — One-Extra-6π Top-Sector Closure Derivation Gate

Question:
Can the one-extra-6π multiplier be derived from the R216/R217 canonical 3+2 action as a high-sector closure/load condition, without using top/e to define it?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    scorecard = top_e_multiplier_scorecard()
    diagnostics = gap_diagnostics()
    mechanisms = mechanism_triage_matrix(scorecard)
    open_claims = open_claims_ledger()
    gates = promotion_gate_matrix(scorecard)
    claims = claim_boundary_matrix()

    lead = scorecard[scorecard["model_id"] == "six_pi_high_sector_closure"].iloc[0].to_dict()
    legacy_k = scorecard[scorecard["model_id"] == "legacy_K_req_load"].iloc[0].to_dict()
    exact = scorecard[scorecard["model_id"] == "exact_top_gap_diagnostic"].iloc[0].to_dict()
    second_d = scorecard[scorecard["model_id"] == "second_D_scale_layer_control"].iloc[0].to_dict()

    verdict = (
        "PARTIAL_PASS_TOP_E_GAP_TRIAGE_IDENTIFIES_ONE_EXTRA_6PI_HIGH_SECTOR_LAYER_AS_LEAD_STRUCTURAL_CANDIDATE_"
        "LEGACY_KREQ_SUPPORTIVE_EXACT_GAP_DIAGNOSTIC_ONLY_SECOND_D_LAYER_REJECTED_"
        "TOP_E_CLOSURE_SPECIES_MAP_AND_PREDICTION_SUITE_OPEN_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "R218_frozen_D_scale_law": {
            "compact_formula": "M_i = G_i exp[(3*pi - 0.5*ln(25/13)) u_i]",
            "L_eff_numeric": L_EFF_FREEZE,
            "N_eff": N_EFF_FREEZE,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "endpoint_vs_D_factor": D_SCALE_ENDPOINT / D_TARGET,
        },
        "top_e_gap": {
            "top_e_target_context": TOP_E_TARGET,
            "exact_multiplier_gap": TOP_GAP_EXACT,
            "exact_gap_log": TOP_GAP_LOG,
            "gap_minus_6pi": TOP_GAP_EXACT - SIX_PI,
            "gap_over_6pi": TOP_GAP_EXACT / SIX_PI,
            "gap_percent_above_6pi": 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0),
            "gap_minus_K_req": TOP_GAP_EXACT - K_REQ,
            "gap_over_K_req": TOP_GAP_EXACT / K_REQ,
        },
        "lead_6pi_candidate": lead,
        "legacy_K_req_candidate": legacy_k,
        "exact_gap_diagnostic_only": exact,
        "second_D_layer_control": second_d,
        "scorecard": scorecard.to_dict(orient="records"),
        "open_claims": open_claims.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "Top/e narrowed, not solved. No V12.13 promotion.",
        "next_recommended": "R220M - One-Extra-6pi Top-Sector Closure Derivation Gate",
        "paste_back_to_chat": [
            "summary.json",
            "top_e_triage_note.md",
            "tables/R219M_top_e_multiplier_scorecard.csv",
            "tables/R219M_gap_diagnostics.csv",
            "tables/R219M_mechanism_triage_matrix.csv",
            "Any traceback if the run failed."
        ],
    }

    scorecard.to_csv(tables / "R219M_top_e_multiplier_scorecard.csv", index=False)
    diagnostics.to_csv(tables / "R219M_gap_diagnostics.csv", index=False)
    mechanisms.to_csv(tables / "R219M_mechanism_triage_matrix.csv", index=False)
    open_claims.to_csv(tables / "R219M_open_claims_ledger.csv", index=False)
    gates.to_csv(tables / "R219M_promotion_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R219M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        scorecard=scorecard,
        diagnostics=diagnostics,
        mechanisms=mechanisms,
        open_claims=open_claims,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "top_e_triage_note.md").write_text(top_e_triage_note_text(created_utc), encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
