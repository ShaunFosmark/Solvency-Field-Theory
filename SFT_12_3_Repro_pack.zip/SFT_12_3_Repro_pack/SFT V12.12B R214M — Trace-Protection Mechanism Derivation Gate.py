#!/usr/bin/env python3
"""
SFT V12.12B R214M — Trace-Protection Mechanism Derivation Gate

Purpose:
    R213M showed that the trace-weighted 3:2 sector coefficient survives
    normalization drift in a tolerance band and survives cross terms only if
    the action protects sector traces.

    R214M asks:
        Can trace protection be derived from symmetry / incommensurability?

Two ideas tested side by side:

    Opus idea:
        Spatial coordinates and phase closures cannot mix because they are
        different kinds of object:
            space transforms under spatial rotations and carries length-like
            settlement support meaning;
            phase transforms under gauge/closure rotations and carries
            cycle/phase meaning.

        Therefore the 5-component audit space is block-protected:
            3 spatial support components
            2 phase closure components

    My trace-protection idea:
        If the action contains protected projectors P_space and P_phase, then
        the coefficient depends on sector traces:

            W_space = Tr(P_space H P_space)
            W_phase = Tr(P_phase H P_phase)

        and is invariant under rotations/redefinitions inside each sector.

Core target:
    Derive why the coefficient should use sector traces rather than mixed
    eigenchannels.

Lead lane:
    M_i = G_i * exp(L_eff * u_i)

Lead coefficient:
    L_eff = 3π - 1/2 ln(25/13)

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - no V12.13 promotion inside this run

Outputs:
    SFT_V12_12B_R214M_Trace_Protection_Mechanism_Derivation_Gate/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R214M.py

    SFT_V12_12B_R214M_Trace_Protection_Mechanism_Derivation_Gate_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R214M_Trace_Protection_Mechanism_Derivation_Gate"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

# R201-R213 endpoint-compatible Green geometry endpoint.
# The previous ring/Green solver lane used G(rho=2)/G(rho=1/2) ~= 2.
G_ENDPOINT_RHO2 = 2.0


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def amplitude_tax_from_shares(shares: list[float]) -> dict:
    arr = np.array(shares, dtype=float)
    arr = arr[arr > 0]

    if arr.size == 0:
        return {
            "shares_normalized": "()",
            "N_eff": 1.0,
            "amplitude_tax": 0.0,
            "c_ln2": 0.0,
            "p_high": None,
            "p_low": None,
            "participation_sum_squares": 1.0,
        }

    arr = arr / np.sum(arr)
    sumsq = float(np.sum(arr * arr))
    N_eff = 1.0 / sumsq
    amplitude_tax = 0.5 * math.log(N_eff)

    sorted_arr = sorted(arr.tolist(), reverse=True)

    return {
        "shares_normalized": "(" + ",".join(f"{x:.12g}" for x in arr.tolist()) + ")",
        "N_eff": N_eff,
        "amplitude_tax": amplitude_tax,
        "c_ln2": amplitude_tax / LN2,
        "p_high": sorted_arr[0],
        "p_low": sorted_arr[1] if len(sorted_arr) > 1 else 0.0,
        "participation_sum_squares": sumsq,
    }


def endpoint_from_L(L_eff: float, G_endpoint: float = G_ENDPOINT_RHO2) -> float:
    return G_endpoint * math.exp(L_eff)


def endpoint_summary_from_shares(shares: list[float], label: str) -> dict:
    tax = amplitude_tax_from_shares(shares)
    L_eff = THREE_PI - tax["amplitude_tax"]
    endpoint = endpoint_from_L(L_eff)

    out = {
        "label": label,
        "shares": shares,
        "L_eff": L_eff,
        "endpoint_rho2": endpoint,
        "endpoint_vs_D_factor": endpoint / D_TARGET,
        "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
    }
    out.update(tax)
    return out


def required_D_split() -> dict:
    L_required = math.log(D_TARGET / G_ENDPOINT_RHO2)
    tax_required = THREE_PI - L_required
    N_eff_required = math.exp(2.0 * tax_required)
    c_required = tax_required / LN2

    if 1.0 <= N_eff_required <= 2.0:
        sumsq = 1.0 / N_eff_required
        y2 = max(0.0, (sumsq - 0.5) / 2.0)
        y = math.sqrt(y2)
        p_high = 0.5 + y
        p_low = 0.5 - y
    else:
        p_high = None
        p_low = None

    return {
        "L_required_endpoint": L_required,
        "tax_required": tax_required,
        "c_required_ln2_units": c_required,
        "N_eff_required": N_eff_required,
        "p_high_required": p_high,
        "p_low_required": p_low,
    }


def random_so3(rng: np.random.Generator) -> np.ndarray:
    A = rng.normal(size=(3, 3))
    Q, R = np.linalg.qr(A)

    # Force determinant +1.
    if np.linalg.det(Q) < 0:
        Q[:, 0] *= -1.0

    return Q


def random_so2(rng: np.random.Generator) -> np.ndarray:
    theta = float(rng.uniform(0.0, 2.0 * math.pi))
    c = math.cos(theta)
    s = math.sin(theta)
    return np.array([[c, -s], [s, c]], dtype=float)


def block_diag_3_2(A3: np.ndarray, B2: np.ndarray) -> np.ndarray:
    out = np.zeros((5, 5), dtype=float)
    out[:3, :3] = A3
    out[3:, 3:] = B2
    return out


def representation_matrix(rng: np.random.Generator) -> np.ndarray:
    return block_diag_3_2(random_so3(rng), random_so2(rng))


def project_to_symmetry_commutant(
    H: np.ndarray,
    n_samples: int = 500,
    seed: int = 214,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    acc = np.zeros_like(H, dtype=float)

    for _ in range(n_samples):
        U = representation_matrix(rng)
        acc += U.T @ H @ U

    return acc / float(n_samples)


def projector_matrices() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    P_space = np.diag([1.0, 1.0, 1.0, 0.0, 0.0])
    P_phase = np.diag([0.0, 0.0, 0.0, 1.0, 1.0])
    I5 = np.eye(5)
    return P_space, P_phase, I5


def sector_trace_weights(H: np.ndarray) -> dict:
    P_space, P_phase, _ = projector_matrices()

    W_space = float(np.trace(P_space @ H @ P_space))
    W_phase = float(np.trace(P_phase @ H @ P_phase))

    tax = amplitude_tax_from_shares([abs(W_space), abs(W_phase)])
    L_eff = THREE_PI - tax["amplitude_tax"]
    endpoint = endpoint_from_L(L_eff)

    return {
        "W_space": W_space,
        "W_phase": W_phase,
        "shares_normalized": tax["shares_normalized"],
        "N_eff": tax["N_eff"],
        "amplitude_tax": tax["amplitude_tax"],
        "c_ln2": tax["c_ln2"],
        "L_eff": L_eff,
        "endpoint_rho2": endpoint,
        "endpoint_vs_D_factor": endpoint / D_TARGET,
        "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
    }


def eigenchannel_weights(H: np.ndarray) -> dict:
    vals = np.linalg.eigvalsh(H)
    weights = [abs(float(v)) for v in vals if abs(float(v)) > 1e-12]

    tax = amplitude_tax_from_shares(weights)
    L_eff = THREE_PI - tax["amplitude_tax"]
    endpoint = endpoint_from_L(L_eff)

    return {
        "eigenvalues": "(" + ",".join(f"{float(v):.12g}" for v in vals.tolist()) + ")",
        "shares_normalized": tax["shares_normalized"],
        "N_eff": tax["N_eff"],
        "amplitude_tax": tax["amplitude_tax"],
        "c_ln2": tax["c_ln2"],
        "L_eff": L_eff,
        "endpoint_rho2": endpoint,
        "endpoint_vs_D_factor": endpoint / D_TARGET,
        "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
    }


def block_metrics(H: np.ndarray) -> dict:
    P_space, P_phase, _ = projector_matrices()

    H_ss = P_space @ H @ P_space
    H_pp = P_phase @ H @ P_phase
    H_sp = P_space @ H @ P_phase
    H_ps = P_phase @ H @ P_space

    space_block = H[:3, :3]
    phase_block = H[3:, 3:]

    space_iso = np.trace(space_block) / 3.0 * np.eye(3)
    phase_iso = np.trace(phase_block) / 2.0 * np.eye(2)

    return {
        "space_trace": float(np.trace(space_block)),
        "phase_trace": float(np.trace(phase_block)),
        "cross_norm": float(np.linalg.norm(H_sp) + np.linalg.norm(H_ps)),
        "diag_norm": float(np.linalg.norm(H_ss) + np.linalg.norm(H_pp)),
        "cross_leakage_ratio": float((np.linalg.norm(H_sp) + np.linalg.norm(H_ps)) / (np.linalg.norm(H_ss) + np.linalg.norm(H_pp))),
        "space_anisotropy_norm": float(np.linalg.norm(space_block - space_iso)),
        "phase_anisotropy_norm": float(np.linalg.norm(phase_block - phase_iso)),
    }


def invariance_error(H: np.ndarray, n_tests: int = 100, seed: int = 1214) -> float:
    rng = np.random.default_rng(seed)
    errors = []

    for _ in range(n_tests):
        U = representation_matrix(rng)
        errors.append(float(np.linalg.norm(U.T @ H @ U - H)))

    return float(np.mean(errors))


def symmetry_projection_audit() -> pd.DataFrame:
    rng = np.random.default_rng(214)
    rows = []

    base_cases = []

    # Case A: identity metric plus strong random cross terms.
    H_identity_cross = np.eye(5)
    random_cross = rng.normal(size=(3, 2))
    random_cross = random_cross / np.linalg.norm(random_cross)
    H_identity_cross[:3, 3:] = 0.75 * random_cross
    H_identity_cross[3:, :3] = 0.75 * random_cross.T
    base_cases.append(("identity_plus_cross_noise", H_identity_cross))

    # Case B: unequal sector normalization plus cross terms.
    H_unequal = np.diag([1.08, 1.08, 1.08, 1.0, 1.0])
    random_cross2 = rng.normal(size=(3, 2))
    random_cross2 = random_cross2 / np.linalg.norm(random_cross2)
    H_unequal[:3, 3:] = 0.55 * random_cross2
    H_unequal[3:, :3] = 0.55 * random_cross2.T
    base_cases.append(("unequal_norm_plus_cross_noise", H_unequal))

    # Case C: arbitrary symmetric 5x5 matrix.
    A = rng.normal(size=(5, 5))
    H_random = 0.5 * (A + A.T)
    H_random += 2.5 * np.eye(5)
    base_cases.append(("generic_symmetric_positive_shifted", H_random))

    for name, H in base_cases:
        H_proj = project_to_symmetry_commutant(H, n_samples=700, seed=214)

        for stage, M in [("raw", H), ("symmetry_projected", H_proj)]:
            bm = block_metrics(M)
            trace = sector_trace_weights(M)
            eig = eigenchannel_weights(M)

            rows.append({
                "case": name,
                "stage": stage,
                "invariance_error_mean": invariance_error(M),
                "space_trace": bm["space_trace"],
                "phase_trace": bm["phase_trace"],
                "cross_norm": bm["cross_norm"],
                "cross_leakage_ratio": bm["cross_leakage_ratio"],
                "space_anisotropy_norm": bm["space_anisotropy_norm"],
                "phase_anisotropy_norm": bm["phase_anisotropy_norm"],
                "trace_L_eff": trace["L_eff"],
                "trace_endpoint_vs_D": trace["endpoint_vs_D_factor"],
                "trace_endpoint_log_error": trace["endpoint_log_error_vs_D_abs"],
                "eigen_L_eff": eig["L_eff"],
                "eigen_endpoint_vs_D": eig["endpoint_vs_D_factor"],
                "eigen_endpoint_log_error": eig["endpoint_log_error_vs_D_abs"],
                "eigenvalues": eig["eigenvalues"],
            })

    return pd.DataFrame(rows)


def incommensurability_matrix() -> pd.DataFrame:
    rows = []

    rows.append({
        "object_a": "spatial_support_coordinate",
        "object_b": "spatial_support_coordinate",
        "same_kind": True,
        "allowed_mixing": True,
        "protecting_symmetry": "SO(3) rotational covariance",
        "mechanical_reason": "spatial coordinates may rotate into each other inside the Green-kernel domain",
    })

    rows.append({
        "object_a": "phase_closure_completion",
        "object_b": "phase_closure_completion",
        "same_kind": True,
        "allowed_mixing": True,
        "protecting_symmetry": "phase/gauge redefinition covariance",
        "mechanical_reason": "spinor and frame phases may be reparameterized inside phase-refresh sector",
    })

    rows.append({
        "object_a": "spatial_support_coordinate",
        "object_b": "phase_closure_completion",
        "same_kind": False,
        "allowed_mixing": False,
        "protecting_symmetry": "independent spatial covariance and gauge covariance",
        "mechanical_reason": "space answers WHERE the settlement lives; phase answers HOW the refresh cycles close; mixed coordinate has no direct physical dimension",
    })

    rows.append({
        "object_a": "no_overwrite_spatial_write",
        "object_b": "phase_maintenance_count",
        "same_kind": False,
        "allowed_mixing": False,
        "protecting_symmetry": "write-location bookkeeping vs cycle-count bookkeeping",
        "mechanical_reason": "a written spatial location is not a phase count; converting one to the other would require a new coupling not present in the claim boundary",
    })

    return pd.DataFrame(rows)


def candidate_mechanism_scorecard() -> pd.DataFrame:
    baseline = [
        endpoint_summary_from_shares([3.0, 2.0], "trace_protected_3_to_2"),
        endpoint_summary_from_shares([1.0, 1.0], "equal_two_channel_sqrt2"),
        endpoint_summary_from_shares([1.0, 1.0, 1.0, 1.0, 1.0], "five_eigenchannel_null"),
        endpoint_summary_from_shares([math.sqrt(FOUR_PI), math.sqrt(TWO_PI)], "sqrt_4pi_sqrt_2pi_bridge"),
        endpoint_summary_from_shares([FOUR_PI, TWO_PI], "direct_4pi_2pi_bridge"),
    ]

    rows = []

    priors = {
        "trace_protected_3_to_2": 10,
        "equal_two_channel_sqrt2": 6,
        "five_eigenchannel_null": 2,
        "sqrt_4pi_sqrt_2pi_bridge": 8,
        "direct_4pi_2pi_bridge": 7,
    }

    statuses = {
        "trace_protected_3_to_2": "lead_if_symmetry_trace_protection_holds",
        "equal_two_channel_sqrt2": "lower_order_binary_approximation",
        "five_eigenchannel_null": "null_control_fails_grouping",
        "sqrt_4pi_sqrt_2pi_bridge": "supportive_spinor_frame_bridge",
        "direct_4pi_2pi_bridge": "supportive_but_less_exact_bridge",
    }

    for rec in baseline:
        endpoint_err = rec["endpoint_log_error_vs_D_abs"]
        score = priors[rec["label"]]

        if endpoint_err < 0.001:
            score += 6
        elif endpoint_err < 0.01:
            score += 5
        elif endpoint_err < 0.03:
            score += 4
        elif endpoint_err < 0.1:
            score += 3
        elif endpoint_err < 0.5:
            score += 1

        if "null" in rec["label"]:
            score -= 4

        rows.append({
            "mechanism": rec["label"],
            "status": statuses[rec["label"]],
            "native_prior": priors[rec["label"]],
            "combined_score": score,
            "shares_normalized": rec["shares_normalized"],
            "N_eff": rec["N_eff"],
            "amplitude_tax": rec["amplitude_tax"],
            "c_ln2": rec["c_ln2"],
            "L_eff": rec["L_eff"],
            "endpoint_rho2": rec["endpoint_rho2"],
            "endpoint_vs_D_factor": rec["endpoint_vs_D_factor"],
            "endpoint_log_error_vs_D_abs": rec["endpoint_log_error_vs_D_abs"],
        })

    return pd.DataFrame(rows).sort_values("combined_score", ascending=False)


def trace_protection_gate_matrix(audit: pd.DataFrame) -> pd.DataFrame:
    projected = audit[audit["stage"] == "symmetry_projected"]

    max_projected_cross = float(projected["cross_norm"].max())
    max_projected_invariance_error = float(projected["invariance_error_mean"].max())
    max_projected_space_anisotropy = float(projected["space_anisotropy_norm"].max())
    max_projected_phase_anisotropy = float(projected["phase_anisotropy_norm"].max())

    return pd.DataFrame([
        {
            "gate": "incommensurable_sector_split",
            "test": "Spatial and phase objects transform under independent symmetry groups.",
            "status": "PASS_FORMAL",
            "boundary": "Formal representation argument, not yet full master-action proof."
        },
        {
            "gate": "symmetry_projection_erases_cross_terms",
            "test": "Group-averaging over SO(3)xSO(2) suppresses spatial-phase cross block.",
            "status": "PASS" if max_projected_cross < 0.10 else "WEAK",
            "boundary": f"max projected cross norm = {max_projected_cross}"
        },
        {
            "gate": "sector_isotropy",
            "test": "Symmetry projection makes spatial and phase blocks isotropic within sectors.",
            "status": "PASS" if max_projected_space_anisotropy < 0.10 and max_projected_phase_anisotropy < 0.10 else "WEAK",
            "boundary": f"space anisotropy {max_projected_space_anisotropy}, phase anisotropy {max_projected_phase_anisotropy}"
        },
        {
            "gate": "trace_invariance",
            "test": "Trace is invariant under allowed within-sector basis rotations.",
            "status": "PASS_FORMAL",
            "boundary": "This protects the coefficient if sector-trace rule is the action rule."
        },
        {
            "gate": "equal_sector_normalization",
            "test": "Does symmetry force k_space = k_phase?",
            "status": "OPEN",
            "boundary": "Symmetry protects blocks and traces, but does not by itself force equal sector normalization."
        },
        {
            "gate": "mixed_eigenchannel_null",
            "test": "Treat mixed eigenchannels as independent channels.",
            "status": "FAILS_AS_PRIMARY",
            "boundary": "This is the null model rejected by R213/R214 if symmetry sectors are physical."
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need action-level normalization derivation and prediction/null tests."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "The compact D-scale lane is M_i = G_i exp(L_eff u_i).",
            "status": "PRESERVED",
            "boundary": "D-scale lane only."
        },
        {
            "category": "Preserved",
            "claim": "Symmetry/incommensurability gives a formal route to block protection between spatial and phase sectors.",
            "status": "FORMAL_PASS",
            "boundary": "Still not a full master-action derivation."
        },
        {
            "category": "Preserved",
            "claim": "Allowed within-sector rotations preserve sector traces.",
            "status": "PASS",
            "boundary": "Trace rule still needs action-level justification."
        },
        {
            "category": "Observed",
            "claim": "Symmetry projection suppresses spatial-phase cross terms and sector anisotropy in the audit model.",
            "status": "DIAGNOSTIC_PASS",
            "boundary": "Numerical group averaging supports the representation argument."
        },
        {
            "category": "Open",
            "claim": "Symmetry alone forces equal per-component normalization between spatial and phase sectors.",
            "status": "OPEN",
            "boundary": "This remains the main missing proof."
        },
        {
            "category": "Rejected",
            "claim": "R214M proves the full mass hierarchy.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no final action normalization proof."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def build_report(
    created_utc: str,
    verdict: str,
    req: dict,
    scorecard: pd.DataFrame,
    audit_summary: dict,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R214M — Trace-Protection Mechanism Derivation Gate

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R214M compares Opus's incommensurable-sector symmetry argument with the projector-trace protection mechanism.

Lead compact lane:
M_i = G_i * exp(L_eff * u_i)

Lead candidate:
L_eff = 3pi - 1/2 ln(25/13)

D-required split:
{json.dumps(json_safe(req), indent=2)}

Mechanism scorecard:
{scorecard.to_string(index=False)}

Symmetry audit summary:
{json.dumps(json_safe(audit_summary), indent=2)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
R214M supports the trace-protection route.

Opus's idea supplies the physical reason cross-sector mixing is forbidden:
spatial support and phase closure are incommensurable objects with different
transformation laws. They live in different representation sectors.

The projector-trace mechanism supplies the invariant coefficient rule:
inside each sector, basis changes do not affect the sector trace. Therefore
the trace-weighted 3:2 split is protected if the action uses sector traces.

The mixed-eigenchannel model is rejected as the wrong bookkeeping if these
symmetry sectors are physical.

Remaining open proof:
symmetry protects block structure and traces, but it does not automatically
force equal per-component normalization between space and phase sectors. That
normalization must still come from the master action, no-overwrite accounting,
or a canonical kinetic normalization.

Ruling:
No V12.13 promotion.

Next recommended run:
R215M — Canonical Sector Normalization Derivation Gate

Question:
Can the action normalize spatial support and phase refresh sectors with the same per-component weight, turning the formal trace protection into the final D-scale coefficient law?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    req = required_D_split()
    scorecard = candidate_mechanism_scorecard()
    incommens = incommensurability_matrix()
    audit = symmetry_projection_audit()
    gates = trace_protection_gate_matrix(audit)
    claims = claim_boundary()

    projected = audit[audit["stage"] == "symmetry_projected"]
    raw = audit[audit["stage"] == "raw"]

    audit_summary = {
        "raw_cross_norm_mean": float(raw["cross_norm"].mean()),
        "projected_cross_norm_mean": float(projected["cross_norm"].mean()),
        "raw_invariance_error_mean": float(raw["invariance_error_mean"].mean()),
        "projected_invariance_error_mean": float(projected["invariance_error_mean"].mean()),
        "projected_space_anisotropy_mean": float(projected["space_anisotropy_norm"].mean()),
        "projected_phase_anisotropy_mean": float(projected["phase_anisotropy_norm"].mean()),
        "lead_trace_model": scorecard[scorecard["mechanism"] == "trace_protected_3_to_2"].iloc[0].to_dict(),
        "mixed_eigenchannel_null": scorecard[scorecard["mechanism"] == "five_eigenchannel_null"].iloc[0].to_dict(),
    }

    verdict = (
        "PARTIAL_PASS_SYMMETRY_INCOMMENSURABILITY_SUPPORTS_BLOCK_TRACE_PROTECTION_"
        "SO3_SO2_PROJECTION_SUPPRESSES_CROSS_TERMS_AND_PRESERVES_SECTOR_TRACES_"
        "MIXED_EIGENCHANNEL_NULL_REJECTED_AS_WRONG_BOOKKEEPING_IF_SECTORS_PHYSICAL_"
        "EQUAL_SECTOR_NORMALIZATION_OPEN_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "compact_formula": "M_i = G_i * exp(L_eff * u_i)",
        "candidate_law": "L_eff = 3*pi - 0.5*ln(25/13)",
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "three_pi": THREE_PI,
            "half_ln_25_over_13": 0.5 * math.log(25.0 / 13.0),
            "three_pi_minus_half_ln_25_over_13": THREE_PI - 0.5 * math.log(25.0 / 13.0),
            "N_eff_3_to_2": 25.0 / 13.0,
            "G_endpoint_rho2": G_ENDPOINT_RHO2,
        },
        "D_required_split": req,
        "audit_summary": audit_summary,
        "scorecard": scorecard.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R215M - Canonical Sector Normalization Derivation Gate",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R214M_mechanism_scorecard.csv",
            "tables/R214M_symmetry_projection_audit.csv",
            "tables/R214M_trace_protection_gate_matrix.csv",
            "Any traceback if the run failed."
        ],
    }

    scorecard.to_csv(tables / "R214M_mechanism_scorecard.csv", index=False)
    incommens.to_csv(tables / "R214M_incommensurability_matrix.csv", index=False)
    audit.to_csv(tables / "R214M_symmetry_projection_audit.csv", index=False)
    gates.to_csv(tables / "R214M_trace_protection_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R214M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        req=req,
        scorecard=scorecard,
        audit_summary=audit_summary,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
