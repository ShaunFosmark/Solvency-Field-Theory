#!/usr/bin/env python3
"""
SFT V12.12B R218M — D-Scale Law Freeze Candidate and Remaining-Open-Claims Ledger

Purpose:
    R217M derived the 3:2 trace-weight rule from the quadratic second
    variation of the R216 canonical 3+2 patch.

    R218M does not hunt a new coefficient.

    R218M freezes the D-scale law candidate as a conditional paper-grade lane:

        M_i = G_i exp(L_eff u_i)

        L_eff = 3π - 1/2 ln(25/13)

    while explicitly preserving the remaining open claims:

        - species map open
        - top/e closure open
        - prediction/null suite open
        - V12.13 promotion not earned

Core chain:
    R213M — trace protection survives normalization/cross-term audit
    R214M — symmetry/incommensurability supports block trace protection
    R215M — canonical equal per-component normalization is lead native choice
    R216M — canonical 3+2 master-action patch written
    R217M — trace rule derived from second variation of canonical patch

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - this is a freeze candidate, not V12.13 promotion

Outputs:
    SFT_V12_12B_R218M_D_Scale_Law_Freeze_Candidate_Ledger/
        report.md
        freeze_note.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R218M.py

    SFT_V12_12B_R218M_D_Scale_Law_Freeze_Candidate_Ledger_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R218M_D_Scale_Law_Freeze_Candidate_Ledger"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

G_ENDPOINT_RHO2 = 2.0

L_EFF_FREEZE = THREE_PI - 0.5 * math.log(25.0 / 13.0)
N_EFF_FREEZE = 25.0 / 13.0
AMPLITUDE_TAX_FREEZE = 0.5 * math.log(25.0 / 13.0)
ENDPOINT_FREEZE = G_ENDPOINT_RHO2 * math.exp(L_EFF_FREEZE)
ENDPOINT_VS_D = ENDPOINT_FREEZE / D_TARGET
LOG_ERROR_D = abs(math.log(ENDPOINT_FREEZE / D_TARGET))

L_REQUIRED = math.log(D_TARGET / G_ENDPOINT_RHO2)
TAX_REQUIRED = THREE_PI - L_REQUIRED
N_EFF_REQUIRED = math.exp(2.0 * TAX_REQUIRED)
C_REQUIRED = TAX_REQUIRED / LN2


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def required_D_split() -> dict:
    if 1.0 <= N_EFF_REQUIRED <= 2.0:
        sumsq = 1.0 / N_EFF_REQUIRED
        y2 = max(0.0, (sumsq - 0.5) / 2.0)
        y = math.sqrt(y2)
        p_high = 0.5 + y
        p_low = 0.5 - y
        k_required = (2.0 * p_high) / (3.0 * (1.0 - p_high))
    else:
        p_high = None
        p_low = None
        k_required = None

    return {
        "L_required_endpoint": L_REQUIRED,
        "tax_required": TAX_REQUIRED,
        "c_required_ln2_units": C_REQUIRED,
        "N_eff_required": N_EFF_REQUIRED,
        "p_high_required": p_high,
        "p_low_required": p_low,
        "k_space_over_k_phase_required": k_required,
        "k_required_minus_1": None if k_required is None else k_required - 1.0,
        "k_required_percent_offset_from_equal": None if k_required is None else 100.0 * (k_required - 1.0),
    }


def d_scale_law_card() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "item": "compact_formula",
            "value": "M_i = G_i exp(L_eff u_i)",
            "status": "FREEZE_CANDIDATE",
            "boundary": "D-scale lane only; no species assignment."
        },
        {
            "item": "effective_load",
            "value": "L_eff = 3*pi - 1/2 ln(25/13)",
            "status": "FREEZE_CANDIDATE",
            "boundary": "Conditional on canonical 3+2 variational patch."
        },
        {
            "item": "N_eff",
            "value": str(N_EFF_FREEZE),
            "status": "DERIVED_FROM_3_TO_2_TRACE",
            "boundary": "Sector trace weights 3 and 2."
        },
        {
            "item": "amplitude_tax",
            "value": str(AMPLITUDE_TAX_FREEZE),
            "status": "DERIVED_FROM_N_EFF",
            "boundary": "1/2 ln(N_eff)."
        },
        {
            "item": "endpoint_rho2",
            "value": str(ENDPOINT_FREEZE),
            "status": "DIAGNOSTIC",
            "boundary": "D used only after law is written."
        },
        {
            "item": "endpoint_vs_D",
            "value": str(ENDPOINT_VS_D),
            "status": "DIAGNOSTIC",
            "boundary": "Hits D-scale endpoint to about 0.032%."
        },
        {
            "item": "endpoint_log_error_vs_D",
            "value": str(LOG_ERROR_D),
            "status": "DIAGNOSTIC",
            "boundary": "Not an empirical mass fit."
        },
        {
            "item": "top_e_status",
            "value": str(ENDPOINT_FREEZE / TOP_E_TARGET),
            "status": "OPEN",
            "boundary": "Top/e hierarchy not closed by this law."
        },
    ])


def proof_chain_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "run": "R213M",
            "step": "Trace protection audit",
            "result": "Trace-weighted 3:2 survives normalization drift/cross-term audit; mixed eigenchannel bookkeeping fails.",
            "claim_status": "PRESERVED",
            "open_boundary": "Trace protection mechanism still needed."
        },
        {
            "run": "R214M",
            "step": "Symmetry/incommensurability mechanism",
            "result": "Spatial support and phase closure are incommensurable sectors protected by independent symmetries.",
            "claim_status": "FORMAL_PASS",
            "open_boundary": "Equal per-component normalization still needed."
        },
        {
            "run": "R215M",
            "step": "Canonical sector normalization",
            "result": "Equal per-component normalization k=1 is lead native choice; D-required k is only about +0.346% away.",
            "claim_status": "CONDITIONAL_PASS",
            "open_boundary": "Master-action metric statement still needed."
        },
        {
            "run": "R216M",
            "step": "Canonical 3+2 master-action patch",
            "result": "Q=(X1,X2,X3;Phi_spinor,Phi_frame) and dQ^2=sum dX_i^2+sum dPhi_a^2 written; raw-radian control rejected.",
            "claim_status": "PATCH_CANDIDATE",
            "open_boundary": "Variational trace derivation still needed."
        },
        {
            "run": "R217M",
            "step": "Variational trace-weight derivation",
            "result": "Second variation gives E[delta^2 S_s]=1/2 sigma^2 Tr(P_s H P_s); H=I5 yields weights 3 and 2.",
            "claim_status": "CONDITIONAL_PASS",
            "open_boundary": "Species map, top/e closure, prediction suite still open."
        },
        {
            "run": "R218M",
            "step": "Freeze candidate ledger",
            "result": "D-scale law candidate frozen with explicit open-claims ledger.",
            "claim_status": "FREEZE_CANDIDATE",
            "open_boundary": "No V12.13 promotion."
        },
    ])


def null_control_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "null_or_control": "five_independent_eigenchannel_null",
            "tested_in": "R213M/R214M/R216M/R217M",
            "result": "Fails as primary bookkeeping if protected sectors are physical.",
            "endpoint_vs_D": 0.6199752395999412,
            "ruling": "REJECT_AS_PRIMARY",
            "boundary": "Valid as a null/control only."
        },
        {
            "null_or_control": "raw_radian_phase_weighting",
            "tested_in": "R216M/R217M",
            "result": "Fails as native metric because it double-counts closure periods.",
            "endpoint_vs_D": 1.2110156362585691,
            "ruling": "REJECT_AS_NATIVE",
            "boundary": "Raw 4pi/2pi periods must normalize phases, not weight the metric."
        },
        {
            "null_or_control": "D_exact_k_diagnostic",
            "tested_in": "R215M/R216M/R217M",
            "result": "Exact D fit requires k_space/k_phase = 1.003460801..., only +0.346% from k=1.",
            "endpoint_vs_D": 1.0,
            "ruling": "DIAGNOSTIC_ONLY",
            "boundary": "Uses D and cannot define the law."
        },
        {
            "null_or_control": "nearby_k_1p005_control",
            "tested_in": "R215M/R216M",
            "result": "Close endpoint but lacks native derivation.",
            "endpoint_vs_D": 1.0001426913468703,
            "ruling": "CONTROL",
            "boundary": "Not promoted over canonical k=1."
        },
        {
            "null_or_control": "sqrt_4pi_sqrt_2pi_bridge",
            "tested_in": "R209M-R216M",
            "result": "Supportive spinor-frame bridge, close but not as clean as trace 3:2.",
            "endpoint_vs_D": 0.9945904602040532,
            "ruling": "SUPPORTIVE_BRIDGE",
            "boundary": "Not the freeze law."
        },
    ])


def open_claims_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "open_claim": "species_map",
            "status": "OPEN",
            "why_open": "No mapping from D-scale mode ladder to electron/muon/tau/quark/etc. has been derived.",
            "required_next": "Define admissible mode-to-species assignment rule without fitting species labels.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "top_e_closure",
            "status": "OPEN",
            "why_open": "The frozen D-scale law endpoint is about 5.27% of the current top/e diagnostic scale.",
            "required_next": "Derive additional layering, generation stacking, or top-sector compounding if real.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "prediction_suite",
            "status": "OPEN",
            "why_open": "No new falsifiable external prediction has been produced from the D-scale law alone.",
            "required_next": "Build prediction/null test matrix before stronger promotion.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "full_master_action_variation",
            "status": "PARTIAL_OPEN",
            "why_open": "R217 derives trace rule from the patch-level second variation, but global master-action derivation remains incomplete.",
            "required_next": "Embed patch in full action and show variational consistency with existing SFT terms.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "external_dataset_blind_test",
            "status": "OPEN",
            "why_open": "No blind holdout or independently specified data test has been run for particle-sector claims.",
            "required_next": "Specify a no-retuning prediction test before looking at target data.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "V12_13_promotion",
            "status": "NO",
            "why_open": "D-scale law candidate is mature, but species/top-e/predictions remain open.",
            "required_next": "Do not promote until blockers above are resolved or explicitly scoped out.",
            "promotion_blocker": True,
        },
    ])


def promotion_gate_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "gate": "D_scale_law_candidate",
            "status": "PASS_FREEZE_CANDIDATE",
            "evidence": "R213-R217 chain supports L_eff = 3pi - 1/2 ln(25/13).",
            "promotion_effect": "May freeze as conditional D-scale law candidate."
        },
        {
            "gate": "coefficient_not_fitted_to_D",
            "status": "PASS_BOUNDARY",
            "evidence": "Law uses canonical 3+2 trace; D-exact k is diagnostic-only.",
            "promotion_effect": "Supports paper-grade candidate status."
        },
        {
            "gate": "trace_rule_variational_support",
            "status": "PASS_CONDITIONAL",
            "evidence": "R217 second variation gives sector traces under canonical patch.",
            "promotion_effect": "Strengthens mechanism."
        },
        {
            "gate": "species_assignment",
            "status": "FAIL_OPEN",
            "evidence": "No derived species map.",
            "promotion_effect": "Blocks V12.13."
        },
        {
            "gate": "top_e_closure",
            "status": "FAIL_OPEN",
            "evidence": "Top/e scale not closed.",
            "promotion_effect": "Blocks V12.13."
        },
        {
            "gate": "prediction_null_suite",
            "status": "FAIL_OPEN",
            "evidence": "Prediction and destructive null suite not run.",
            "promotion_effect": "Blocks V12.13."
        },
        {
            "gate": "V12_13",
            "status": "NO_PROMOTION",
            "evidence": "Freeze candidate is not final theory promotion.",
            "promotion_effect": "Preserve as V12.12B D-scale freeze candidate only."
        },
    ])


def claim_boundary_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Allowed claim",
            "claim": "R218M freezes a conditional D-scale law candidate.",
            "status": "YES",
            "safe_wording": "D-scale law candidate, not full particle mass derivation."
        },
        {
            "category": "Allowed claim",
            "claim": "The frozen coefficient is L_eff = 3π - 1/2 ln(25/13).",
            "status": "YES",
            "safe_wording": "Conditional on canonical 3+2 variational patch."
        },
        {
            "category": "Allowed claim",
            "claim": "The law hits the D-scale endpoint to about 0.032%.",
            "status": "YES",
            "safe_wording": "Diagnostic endpoint agreement; not empirical species fit."
        },
        {
            "category": "Allowed claim",
            "claim": "R217 supports trace weighting from the second variation.",
            "status": "YES",
            "safe_wording": "Patch-level variational support."
        },
        {
            "category": "Blocked claim",
            "claim": "SFT has derived the full particle mass hierarchy.",
            "status": "NO",
            "safe_wording": "Species map and top/e closure remain open."
        },
        {
            "category": "Blocked claim",
            "claim": "V12.13 is promoted.",
            "status": "NO",
            "safe_wording": "No V12.13 promotion."
        },
        {
            "category": "Blocked claim",
            "claim": "The top/e scale is solved.",
            "status": "NO",
            "safe_wording": "Top/e remains open."
        },
        {
            "category": "Blocked claim",
            "claim": "The D-scale law has passed external prediction tests.",
            "status": "NO",
            "safe_wording": "Prediction/null suite remains open."
        },
    ])


def freeze_note_text(created_utc: str) -> str:
    return f"""
# SFT V12.12B R218M D-Scale Law Freeze Candidate

Generated: {created_utc}

This is a freeze candidate for the D-scale law lane only.
It is not V12.13 promotion.

## Frozen conditional law candidate

    M_i = G_i exp(L_eff u_i)

with:

    L_eff = 3pi - 1/2 ln(25/13)

and:

    N_eff = 25/13

## Mechanism chain

1. Spatial support and phase closure are protected sectors.
2. The canonical audit vector is:

       Q = (X1, X2, X3 ; Phi_spinor, Phi_frame)

3. Phase variables are cycle-normalized:

       Phi_spinor = phi_spinor / 4pi
       Phi_frame  = phi_frame  / 2pi

4. The canonical patch metric is:

       dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2

5. The second variation gives:

       delta^2 S = 1/2 delta Q^T H delta Q

   with canonical H = I_5.

6. For isotropic sector fluctuations:

       E[delta^2 S_s] = 1/2 sigma^2 Tr(P_s H P_s)

7. Therefore:

       W_space = 3
       W_phase = 2

8. Therefore:

       N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13

9. Therefore:

       L_eff = 3pi - 1/2 ln(25/13)

## Diagnostic endpoint

Using G_endpoint(rho=2)=2:

    endpoint = {ENDPOINT_FREEZE}
    endpoint_vs_D = {ENDPOINT_VS_D}
    log_error_vs_D = {LOG_ERROR_D}

## Still open

- species map
- top/e closure
- full global master-action embedding
- blind prediction/null suite
- V12.13 promotion

## Frozen wording

R218M freezes the D-scale law candidate:

    M_i = G_i exp[(3pi - 1/2 ln(25/13)) u_i]

as a conditional paper-grade lane supported by trace protection, canonical 3+2 normalization,
and second-variation sector trace weighting. It does not derive a species map, does not close
top/e, and does not promote V12.13.
"""


def build_report(
    created_utc: str,
    verdict: str,
    law: pd.DataFrame,
    chain: pd.DataFrame,
    nulls: pd.DataFrame,
    open_claims: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R218M — D-Scale Law Freeze Candidate and Remaining-Open-Claims Ledger

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R218M freezes the D-scale law candidate and records remaining open claims.

Frozen law candidate:
M_i = G_i exp[(3pi - 1/2 ln(25/13)) u_i]

D-scale law card:
{law.to_string(index=False)}

Proof chain ledger:
{chain.to_string(index=False)}

Null/control ledger:
{nulls.to_string(index=False)}

Remaining open claims:
{open_claims.to_string(index=False)}

Promotion gate matrix:
{gates.to_string(index=False)}

Claim boundary matrix:
{claims.to_string(index=False)}

Interpretation:
R218M is not another coefficient hunt. It freezes the coefficient lane as a conditional D-scale law candidate.

The coefficient L_eff = 3pi - 1/2 ln(25/13) is supported by the R213-R217 chain:
trace protection, symmetry/incommensurability, canonical equal normalization, explicit canonical patch, and second-variation trace weighting.

The result remains bounded:
it is a D-scale law candidate, not a full particle mass hierarchy. Species assignment, top/e closure, global master-action embedding, and prediction/null tests remain open.

Ruling:
Freeze candidate only.
No V12.13 promotion.

Next recommended run:
R219M — Species Map Constraint Skeleton OR Top/e Closure Mechanism Triage

Choice:
A. Try to derive an admissible species map without using empirical species labels.
B. Try to explain why top/e requires an additional layer beyond the frozen D-scale law.
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    law = d_scale_law_card()
    chain = proof_chain_ledger()
    nulls = null_control_ledger()
    open_claims = open_claims_ledger()
    gates = promotion_gate_matrix()
    claims = claim_boundary_matrix()
    req = required_D_split()

    verdict = (
        "FREEZE_CANDIDATE_D_SCALE_TRACE_VARIATIONAL_LAW_PRESERVED_"
        "L_EFF_EQUALS_3PI_MINUS_HALF_LN_25_OVER_13_"
        "R213_TO_R217_CHAIN_LOCKED_AS_CONDITIONAL_PAPER_GRADE_LANE_"
        "SPECIES_MAP_TOP_E_GLOBAL_ACTION_AND_PREDICTION_SUITE_OPEN_"
        "NO_V12_13_PROMOTION"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "freeze_status": "D_SCALE_LAW_CANDIDATE_FREEZE_NOT_PROMOTION",
        "frozen_law_candidate": {
            "compact_formula": "M_i = G_i exp(L_eff u_i)",
            "L_eff": "3*pi - 0.5*ln(25/13)",
            "L_eff_numeric": L_EFF_FREEZE,
            "N_eff": N_EFF_FREEZE,
            "amplitude_tax": AMPLITUDE_TAX_FREEZE,
            "G_endpoint_rho2": G_ENDPOINT_RHO2,
            "endpoint_rho2": ENDPOINT_FREEZE,
            "endpoint_vs_D_factor": ENDPOINT_VS_D,
            "endpoint_log_error_vs_D_abs": LOG_ERROR_D,
            "endpoint_vs_top_e_factor": ENDPOINT_FREEZE / TOP_E_TARGET,
        },
        "D_required_diagnostic": req,
        "proof_chain": chain.to_dict(orient="records"),
        "null_control_ledger": nulls.to_dict(orient="records"),
        "open_claims": open_claims.to_dict(orient="records"),
        "promotion_gate_matrix": gates.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "Freeze candidate only. No V12.13 promotion.",
        "next_recommended": [
            "R219M - Species Map Constraint Skeleton",
            "R219M_ALT - Top/e Closure Mechanism Triage",
        ],
        "paste_back_to_chat": [
            "summary.json",
            "freeze_note.md",
            "tables/R218M_d_scale_law_card.csv",
            "tables/R218M_open_claims_ledger.csv",
            "tables/R218M_promotion_gate_matrix.csv",
            "Any traceback if the run failed."
        ],
    }

    law.to_csv(tables / "R218M_d_scale_law_card.csv", index=False)
    chain.to_csv(tables / "R218M_proof_chain_ledger.csv", index=False)
    nulls.to_csv(tables / "R218M_null_control_ledger.csv", index=False)
    open_claims.to_csv(tables / "R218M_open_claims_ledger.csv", index=False)
    gates.to_csv(tables / "R218M_promotion_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R218M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        law=law,
        chain=chain,
        nulls=nulls,
        open_claims=open_claims,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "freeze_note.md").write_text(freeze_note_text(created_utc), encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
