
# R216M Master-Action Canonical Normalization Patch Candidate

Generated: 2026-06-18T04:38:26Z

This is a patch candidate, not a final promoted action.

## Canonical coordinates

Let the local settlement-support coordinate be written in dimensionless form:

    X_i = x_i / r_*

where r_* is the local support / closure-radius unit.

Let the phase closure coordinates be written as completed-cycle coordinates:

    Phi_spinor = phi_spinor / 4pi
    Phi_frame  = phi_frame  / 2pi

The point of this normalization is that phase variables enter as closure counts, not raw radians.

## Canonical 3+2 metric

Define the local audit vector:

    Q = (X_1, X_2, X_3 ; Phi_spinor, Phi_frame)

with canonical metric:

    dQ^2 = dX_1^2 + dX_2^2 + dX_3^2 + dPhi_spinor^2 + dPhi_frame^2

Equivalently:

    dQ^T dQ = sum_i dX_i^2 + sum_a dPhi_a^2

## Protected projectors

Let P_space project onto the first three entries of Q.
Let P_phase project onto the last two entries of Q.

Then:

    Tr(P_space) = 3
    Tr(P_phase) = 2

The two projectors are protected by the incommensurability of spatial support and phase closure.

## Amplitude tax

Using sector trace weights:

    W_space = 3
    W_phase = 2
    W = 5

    N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13

The half-action feedback coefficient becomes:

    L_eff = 3pi - 1/2 ln(25/13)

The D-scale lane is:

    M_i = G_i exp(L_eff u_i)

## Claim boundary

This patch writes the missing canonical normalization statement.
It does not yet prove the patch from a deeper variation of the full master action.
It does not supply species assignments.
It does not close the top/e hierarchy.
It does not promote V12.13.
