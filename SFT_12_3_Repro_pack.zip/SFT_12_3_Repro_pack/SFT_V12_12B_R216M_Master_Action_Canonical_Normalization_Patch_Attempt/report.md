
# SFT V12.12B R216M — Master-Action Canonical Normalization Patch Attempt

Generated: 2026-06-18T04:38:26Z

Verdict:
PARTIAL_PASS_MASTER_ACTION_CANONICAL_3PLUS2_METRIC_PATCH_WRITTEN_CYCLE_NORMALIZED_PHASE_COORDINATES_PROTECT_EQUAL_UNIT_WEIGHTING_RAW_RADIAN_PHASE_PERIOD_CONTROL_REJECTED_AS_DOUBLE_COUNTING_VARIATIONAL_DERIVATION_STILL_OPEN_NO_V12_13

Purpose:
R216M writes the missing canonical 3+2 metric patch.

Lead compact lane:
M_i = G_i exp(L_eff u_i)

Patch coefficient:
L_eff = 3pi - 1/2 ln(25/13)

D-required normalization diagnostic:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required_ln2_units": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446,
  "k_space_over_k_phase_required": 1.0034608010243735,
  "k_required_minus_1": 0.0034608010243735166,
  "k_required_percent_offset_from_equal": 0.34608010243735166
}

Candidate scorecard:
                                      model_id                                         status  native_prior  uses_D_to_define                  shares_input    L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_log_error_vs_D_abs  endpoint_vs_top_e_factor               shares_normalized    N_eff  amplitude_tax    c_ln2   p_high    p_low  participation_sum_squares  combined_score  k_space_over_k_phase  k_space_over_k_phase_equivalent
              canonical_cycle_normalized_patch                           LEAD_PATCH_CANDIDATE          11.0             False                         (3,2) 9.097815   17871.488624              0.999680                     0.000320                  0.052718                       (0.6,0.4) 1.923077       0.326963 0.471708 0.600000 0.400000                   0.520000            17.0                   NaN                              NaN
              spinor_frame_sqrt_4pi_2pi_bridge                              SUPPORTIVE_BRIDGE           8.0             False (3.54490770181,2.50662827463) 9.092711   17780.501218              0.994590                     0.005424                  0.052450 (0.585786437627,0.414213562373) 1.942809       0.332067 0.479072 0.585786 0.414214                   0.514719            13.0                   NaN                         0.942809
                       equal_two_channel_sqrt2               LOWER_ORDER_BINARY_APPROXIMATION           6.0             False                         (1,1) 9.078204   17524.436390              0.980267                     0.019930                  0.051695                       (0.5,0.5) 2.000000       0.346574 0.500000 0.500000 0.500000                   0.500000            10.0                   NaN                              NaN
            spinor_frame_direct_4pi_2pi_bridge               SUPPORTIVE_BUT_LESS_EXACT_BRIDGE           6.5             False (12.5663706144,6.28318530718) 9.130885   18472.377901              1.033292                     0.032750                  0.054491 (0.666666666667,0.333333333333) 1.800000       0.293893 0.423998 0.666667 0.333333                   0.555556             9.5                   NaN                         1.333333
                        nearby_k_1p005_control                   CONTROL_CLOSE_BUT_NOT_NATIVE           2.0             False                     (3.015,2) 9.098277   17879.759613              1.000143                     0.000143                  0.052743 (0.601196410768,0.398803589232) 1.921298       0.326501 0.471041 0.601196 0.398804                   0.520481             6.0              1.005000                              NaN
raw_radian_phase_period_metric_control_grouped CONTROL_RAW_PHASE_PERIOD_DOUBLE_COUNTS_CLOSURE           1.0             False             (3,18.8495559215) 9.289594   21649.579256              1.211016                     0.191459                  0.063863 (0.137302561698,0.862697438302) 1.310446       0.135184 0.195029 0.862697 0.137303                   0.763099             0.0                   NaN                              NaN
            five_independent_eigenchannel_null                         NULL_WRONG_BOOKKEEPING           1.0             False                   (1,1,1,1,1) 8.620059   11083.426741              0.619975                     0.478076                  0.032694           (0.2,0.2,0.2,0.2,0.2) 5.000000       0.804719 1.160964 0.200000 0.200000                   0.200000            -2.0                   NaN                              NaN
                          D_exact_k_diagnostic                         DIAGNOSTIC_ONLY_USES_D          -8.0              True             (3.01038240307,2) 9.098135   17877.208690              1.000000                     0.000000                  0.052735 (0.600828871111,0.399171128889) 1.921846       0.326643 0.471247 0.600829 0.399171                   0.520333           -14.0              1.003461                              NaN

Metric audit:
                               metric_id                                                                                interpretation        metric_status  space_trace  phase_trace  cross_norm  commutes_with_P_space  commutes_with_P_phase  trace_grouped_endpoint_vs_D  trace_grouped_log_error  trace_grouped_N_eff  trace_grouped_L_eff  eigenchannel_endpoint_vs_D  eigenchannel_log_error  eigenchannel_N_eff  eigenchannel_L_eff                                     eigenvalues
canonical_cycle_normalized_3plus2_metric                                           lead patch metric: dQ^2 = sum dX_i^2 + sum dPhi_a^2      PATCH_CANDIDATE     3.000000     2.000000         0.0                   True                   True                     0.999680                 0.000320             1.923077             9.097815                    0.619975                0.478076            5.000000            8.620059                                     (1,1,1,1,1)
               D_exact_diagnostic_metric                                                     diagnostic-only metric using D-required k REJECT_AS_DERIVATION     3.010382     2.000000         0.0                   True                   True                     1.000000                 0.000000             1.921846             9.098135                    0.619976                0.478074            4.999986            8.620060 (1,1,1.00346080102,1.00346080102,1.00346080102)
  raw_radian_phase_period_metric_control control: treats raw 4pi and 2pi phase periods as metric weights, likely double-counts closure              CONTROL     3.000000    18.849556         0.0                   True                   True                     1.211016                 0.191459             1.310446             9.289594                    0.898167                0.107399            2.382345            8.990735             (1,1,1,6.28318530718,12.5663706144)
nearby_half_percent_spatial_lift_control                                       control: close to exact D but not native unless derived              CONTROL     3.015000     2.000000         0.0                   True                   True                     1.000143                 0.000143             1.921298             9.098277                    0.619977                0.478073            4.999970            8.620062                         (1,1,1.005,1.005,1.005)

Patch premise matrix:
                                  premise                                                   patch_statement               status                                                                    boundary
dimensionless_spatial_support_coordinates                                                   X_i = x_i / r_*     CONDITIONAL_PASS Requires defining r_* as local support/closure radius in the master action.
       cycle_normalized_phase_coordinates     Phi_spinor = phi_spinor / 4pi and Phi_frame = phi_frame / 2pi           PASS_PATCH                 Treats phase closures as completed cycles, not raw radians.
                  canonical_3plus2_metric                              dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2 PASS_PATCH_CANDIDATE          Patch statement, not yet independently derived from deeper action.
                     protected_projectors P_space and P_phase are symmetry-protected projectors on Q-space.    SUPPORTED_BY_R214                       Depends on incommensurable spatial/phase bookkeeping.
                        sector_trace_rule                      W_space = Tr(P_space), W_phase = Tr(P_phase) PASS_PATCH_CANDIDATE                                   Still needs final variational derivation.
                            amplitude_tax                       N_eff = 1 / [(W_space/W)^2 + (W_phase/W)^2]            PRESERVED                                                          D-scale lane only.
                         half_action_load                                       L_eff = 3pi - 1/2 ln(N_eff)            PRESERVED                                   Half-action load route remains candidate.
                                   V12_13                                     Promote final theory version.                   NO                 No species map, no top/e closure, no prediction/null suite.

Gate matrix:
                  gate                                                                       test                status                                                            boundary
         patch_written                                Canonical 3+2 metric is explicitly written.    PASS_PATCH_WRITTEN                              Patch candidate, not final derivation.
cycle_normalized_phase Phase variables are normalized by closure periods rather than raw radians.       PASS_PATCH_RULE Prevents double-counting 4pi/2pi closure periods as metric weights.
    canonical_endpoint                                                  Canonical patch endpoint.       PASS_DIAGNOSTIC                                    endpoint_vs_D=0.9996800358435753
          D_required_k                                       D-exact k offset from canonical k=1. VERY_CLOSE_DIAGNOSTIC   k_required=1.0034608010243735, percent_offset=0.34608010243735166
    raw_radian_control                               Raw phase periods treated as metric weights. FAILS_AS_NATIVE_PATCH    endpoint_vs_D=1.2110156362585691; double-counts closure periods.
five_eigenchannel_null                                            Five independent eigenchannels.                 FAILS                                    endpoint_vs_D=0.6199752395999412
  tolerance_band_0p001                                            k band with log error <= 0.001.      PASS_BAND_EXISTS          {'count': 43, 'min_k': 0.9929999999999999, 'max_k': 1.014}
   tolerance_band_0p01                                             k band with log error <= 0.01.      PASS_BAND_EXISTS                      {'count': 441, 'min_k': 0.887, 'max_k': 1.107}
                V12_13                                                                 Promotion.                    NO   Patch written, but species map/top-e/prediction suite still open.

Claim boundary:
 category                                                                     claim          status                                                          boundary
Preserved                The compact D-scale lane remains M_i = G_i exp(L_eff u_i).       PRESERVED                                                D-scale lane only.
Preserved                     The canonical 3+2 metric patch is explicitly written. PATCH_CANDIDATE                           Not yet final master-action derivation.
Preserved      Cycle-normalized phase variables prevent raw-radian double counting. PATCH_CANDIDATE Requires accepting closure cycles as canonical phase coordinates.
 Observed The canonical patch gives the 3:2 trace coefficient and hits D to 0.032%. DIAGNOSTIC_PASS                           D used only after writing native patch.
     Open            The patch is derived by variation from the full master action.            OPEN                        Still needs formal variational derivation.
 Rejected                                 R216M proves the full particle hierarchy.              NO       No species map, no top/e closure, no prediction/null suite.
Promotion                                                         V12.13 promotion.              NO                                                   Not yet earned.

Interpretation:
R216M upgrades the canonical-normalization lane from a supported premise to an explicit patch candidate.

The essential move is to normalize phase variables by closure periods:
Phi_spinor = phi_spinor / 4pi and Phi_frame = phi_frame / 2pi.
This makes phase entries completed-cycle coordinates rather than raw radians.

Then the canonical audit metric is:
dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2.

That gives a protected 3+2 identity metric, sector traces 3 and 2, N_eff = 25/13, and L_eff = 3pi - 1/2 ln(25/13).

The raw-radian control is rejected as a native patch because it double-counts closure periods as metric weights.

Ruling:
No V12.13 promotion.

Next recommended run:
R217M — Variational Trace-Weight Derivation Attempt

Question:
Can the canonical patch be obtained from a quadratic variation of the master action, so that the sector trace rule appears as a variational Hessian/second-variation result rather than a postulated metric?
