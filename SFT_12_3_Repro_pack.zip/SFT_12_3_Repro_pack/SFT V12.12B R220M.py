#!/usr/bin/env python3
"""
SFT V12.12B R220M — One-Extra-6π Top-Sector Closure Derivation Gate

Purpose:
    R219M_ALT narrowed the top/e closure problem.

    Frozen R218 D-scale endpoint:
        D_scale_endpoint = 17871.48862357384

    Top/e diagnostic target:
        top/e ≈ 339000

    Exact diagnostic gap:
        top/e / D_scale_endpoint = 18.968761200610533

    R219M_ALT identified:
        6π = 18.84955592153876

    as the lead structural candidate:
        D_scale_endpoint * 6π = 336869.6242111989
        factor_vs_top/e = 0.9937157056377548

    R220M asks:

        Can the one-extra-6π multiplier be derived from the canonical
        3+2 action / closure bookkeeping without using top/e?

Core hypothesis:
    The R218 D-scale law freezes the trace-variational compact lane:

        M_i = G_i exp[(3π - 1/2 ln(25/13)) u_i]

    The top sector may require one additional untaxed full closure layer:

        K_top = 4π + 2π = 6π

    where:
        4π = spinor/spatial curvature closure
        2π = frame/gauge phase closure

    Unlike the D-scale half-action compounding lane, this high-sector layer
    is treated as a full closure/load completion, not a two-sector amplitude
    participation tax.

Rules:
    - no species labels
    - no empirical particle mass fitting
    - top/e is diagnostic context only
    - exact top/e gap cannot define the law
    - no V12.13 promotion

Outputs:
    SFT_V12_12B_R220M_One_Extra_6pi_Top_Sector_Closure_Derivation_Gate/
        report.md
        one_extra_6pi_note.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R220M.py

    SFT_V12_12B_R220M_One_Extra_6pi_Top_Sector_Closure_Derivation_Gate_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R220M_One_Extra_6pi_Top_Sector_Closure_Derivation_Gate"

# Diagnostic contexts from R218/R219.
D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF_FREEZE = 25.0 / 13.0
AMPLITUDE_TAX_FREEZE = 0.5 * math.log(N_EFF_FREEZE)
L_EFF_FREEZE = THREE_PI - AMPLITUDE_TAX_FREEZE
G_ENDPOINT_RHO2 = 2.0
D_SCALE_ENDPOINT = G_ENDPOINT_RHO2 * math.exp(L_EFF_FREEZE)

TOP_GAP_EXACT = TOP_E_TARGET / D_SCALE_ENDPOINT
TOP_GAP_LOG = math.log(TOP_GAP_EXACT)

SQRT2_HALF_ACTION_K_DIAGNOSTIC = 2.0 * (math.log(D_TARGET) - 0.5 * LN2)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def candidate_record(
    model_id: str,
    multiplier: float,
    derivation_route: str,
    status: str,
    native_prior: float,
    uses_top_to_define: bool,
    uses_D_to_define: bool,
    is_control: bool,
    interpretation: str,
) -> dict:
    predicted = D_SCALE_ENDPOINT * multiplier
    factor = predicted / TOP_E_TARGET
    log_error = abs(math.log(factor))

    score = native_prior

    if log_error < 0.001:
        score += 8.0
    elif log_error < 0.005:
        score += 7.0
    elif log_error < 0.01:
        score += 6.0
    elif log_error < 0.03:
        score += 4.0
    elif log_error < 0.10:
        score += 2.0
    elif log_error < 0.50:
        score += 1.0

    if uses_top_to_define:
        score -= 18.0
    if uses_D_to_define:
        score -= 6.0
    if is_control:
        score -= 2.0
    if "hard_fail" in status.lower():
        score -= 8.0

    return {
        "model_id": model_id,
        "status": status,
        "derivation_route": derivation_route,
        "interpretation": interpretation,
        "multiplier": multiplier,
        "log_multiplier": math.log(multiplier) if multiplier > 0 else None,
        "predicted_top_e_scale": predicted,
        "predicted_top_e_vs_target_factor": factor,
        "top_e_log_error_abs": log_error,
        "top_e_percent_error": 100.0 * (factor - 1.0),
        "residual_multiplier_to_exact_gap": TOP_GAP_EXACT - multiplier,
        "residual_percent_of_exact_gap": 100.0 * ((TOP_GAP_EXACT - multiplier) / TOP_GAP_EXACT),
        "uses_top_to_define": uses_top_to_define,
        "uses_D_to_define": uses_D_to_define,
        "is_control": is_control,
        "native_prior": native_prior,
        "combined_score": score,
    }


def closure_candidate_scorecard() -> pd.DataFrame:
    records = []

    # Lead: top sector receives one extra full 4π+2π closure layer.
    records.append(candidate_record(
        model_id="one_extra_full_closure_4pi_plus_2pi",
        multiplier=FOUR_PI + TWO_PI,
        derivation_route="K_top = 4π spatial/spinor curvature closure + 2π frame/gauge phase closure",
        status="LEAD_DERIVED_CANDIDATE",
        native_prior=13.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        is_control=False,
        interpretation="Top sector gets one additional untaxed full closure/load layer after frozen D-scale lane.",
    ))

    # Same numeric candidate, different language: double half-action.
    records.append(candidate_record(
        model_id="double_half_action_2x3pi",
        multiplier=2.0 * THREE_PI,
        derivation_route="K_top = 2 * 3π",
        status="SUPPORTIVE_ALIAS",
        native_prior=10.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        is_control=False,
        interpretation="Equivalent to 6π; supportive but less mechanically explicit than 4π+2π.",
    ))

    # Legacy K_req.
    records.append(candidate_record(
        model_id="legacy_K_req_load",
        multiplier=K_REQ,
        derivation_route="legacy K_req load from old K/beta lane",
        status="SUPPORTIVE_LEGACY_BRIDGE",
        native_prior=8.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        is_control=False,
        interpretation="K_req is close to both exact gap and 6π, but not newly derived here.",
    ))

    # R191 diagnostic.
    records.append(candidate_record(
        model_id="sqrt2_half_action_K_diagnostic",
        multiplier=SQRT2_HALF_ACTION_K_DIAGNOSTIC,
        derivation_route="K = 2(ln D - 1/2 ln2)",
        status="DIAGNOSTIC_USES_D",
        native_prior=4.0,
        uses_top_to_define=False,
        uses_D_to_define=True,
        is_control=True,
        interpretation="Diagnostic relation from D and sqrt2 half-action; cannot define top/e rule.",
    ))

    # Exact gap forbidden.
    records.append(candidate_record(
        model_id="exact_top_gap_diagnostic",
        multiplier=TOP_GAP_EXACT,
        derivation_route="top/e divided by D-scale endpoint",
        status="DIAGNOSTIC_ONLY_USES_TOP",
        native_prior=-12.0,
        uses_top_to_define=True,
        uses_D_to_define=False,
        is_control=True,
        interpretation="Exact target gap; cannot define theory.",
    ))

    # Taxed corrections.
    records.append(candidate_record(
        model_id="closure_6pi_plus_amplitude_tax_control",
        multiplier=SIX_PI + AMPLITUDE_TAX_FREEZE,
        derivation_route="K_top = 6π + amplitude_tax",
        status="TAXED_CLOSURE_CONTROL",
        native_prior=4.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        is_control=True,
        interpretation="Tests whether the D-scale amplitude tax should be added back onto the top closure layer.",
    ))

    records.append(candidate_record(
        model_id="closure_6pi_minus_amplitude_tax_control",
        multiplier=SIX_PI - AMPLITUDE_TAX_FREEZE,
        derivation_route="K_top = 6π - amplitude_tax",
        status="TAXED_CLOSURE_CONTROL",
        native_prior=4.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        is_control=True,
        interpretation="Tests whether the D-scale amplitude tax should be subtracted from the top closure layer.",
    ))

    # Reusing D-scale frozen L instead of full closure.
    records.append(candidate_record(
        model_id="two_times_frozen_L_eff_control",
        multiplier=2.0 * L_EFF_FREEZE,
        derivation_route="K_top = 2 * L_eff_freeze",
        status="STRUCTURAL_CONTROL",
        native_prior=5.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        is_control=True,
        interpretation="Tests whether the top sector should reuse the taxed D-scale half-action load.",
    ))

    # One extra half-action only.
    records.append(candidate_record(
        model_id="one_extra_3pi_half_closure_control",
        multiplier=THREE_PI,
        derivation_route="K_top = 3π",
        status="UNDERLOAD_CONTROL",
        native_prior=4.0,
        uses_top_to_define=False,
        uses_D_to_define=False,
        is_control=True,
        interpretation="Tests whether only one half-action layer is enough.",
    ))

    # Full second D-scale layer.
    records.append(candidate_record(
        model_id="second_D_scale_layer_control",
        multiplier=D_TARGET,
        derivation_route="K_top = D",
        status="HARD_FAIL_CONTROL",
        native_prior=1.0,
        uses_top_to_define=False,
        uses_D_to_define=True,
        is_control=True,
        interpretation="Tests full second D-scale compounding; expected to overshoot.",
    ))

    return pd.DataFrame(records).sort_values("combined_score", ascending=False).reset_index(drop=True)


def derivation_gate_matrix(scorecard: pd.DataFrame) -> pd.DataFrame:
    lead = scorecard[scorecard["model_id"] == "one_extra_full_closure_4pi_plus_2pi"].iloc[0]
    legacy = scorecard[scorecard["model_id"] == "legacy_K_req_load"].iloc[0]
    exact = scorecard[scorecard["model_id"] == "exact_top_gap_diagnostic"].iloc[0]
    two_l = scorecard[scorecard["model_id"] == "two_times_frozen_L_eff_control"].iloc[0]
    half = scorecard[scorecard["model_id"] == "one_extra_3pi_half_closure_control"].iloc[0]
    second_d = scorecard[scorecard["model_id"] == "second_D_scale_layer_control"].iloc[0]

    return pd.DataFrame([
        {
            "gate": "derive_6pi_without_top",
            "test": "Can 6π be written from closure bookkeeping without top/e?",
            "status": "PASS_FORMAL",
            "evidence": "6π = 4π + 2π = full spatial/spinor curvature closure plus frame/gauge phase closure.",
            "boundary": "Formal derivation of candidate multiplier, not proof that top sector must receive it."
        },
        {
            "gate": "top_match_quality",
            "test": "Does derived 6π land near top/e diagnostic?",
            "status": "PASS_DIAGNOSTIC",
            "evidence": f"factor={lead['predicted_top_e_vs_target_factor']}, percent_error={lead['top_e_percent_error']}",
            "boundary": "Diagnostic only."
        },
        {
            "gate": "exact_gap_not_used",
            "test": "Is exact gap rejected as derivation?",
            "status": "PASS_BOUNDARY",
            "evidence": f"exact gap candidate score={exact['combined_score']}",
            "boundary": "Exact top/e gap cannot define the multiplier."
        },
        {
            "gate": "why_one_extra_layer",
            "test": "Does R220 derive why exactly one additional 6π layer appears?",
            "status": "PARTIAL_OPEN",
            "evidence": "The full-closure layer is formal, but the top-sector trigger is not yet derived.",
            "boundary": "Need top-sector activation criterion."
        },
        {
            "gate": "taxed_vs_untaxed",
            "test": "Should the high-sector layer be taxed by the D-scale amplitude tax?",
            "status": "PASS_CONDITIONAL_UNTAXED",
            "evidence": "Untaxed 6π is lead; taxed variants are controls and do not improve mechanism priority.",
            "boundary": "Need formal reason top closure is completion load, not branch participation."
        },
        {
            "gate": "legacy_K_req_bridge",
            "test": "Does K_req remain supportive?",
            "status": "SUPPORTIVE",
            "evidence": f"K_req factor={legacy['predicted_top_e_vs_target_factor']}, percent_error={legacy['top_e_percent_error']}",
            "boundary": "K_req not newly derived here."
        },
        {
            "gate": "reuse_taxed_D_load",
            "test": "Does K_top = 2*L_eff_freeze work?",
            "status": "CONTROL_WEAKER",
            "evidence": f"factor={two_l['predicted_top_e_vs_target_factor']}, percent_error={two_l['top_e_percent_error']}",
            "boundary": "D-scale taxed load is not preferred for top closure."
        },
        {
            "gate": "one_half_layer",
            "test": "Does K_top = 3π work?",
            "status": "FAIL_UNDERLOAD",
            "evidence": f"factor={half['predicted_top_e_vs_target_factor']}, percent_error={half['top_e_percent_error']}",
            "boundary": "One half-action closure is insufficient."
        },
        {
            "gate": "second_D_layer",
            "test": "Does full second D-scale multiplication work?",
            "status": "HARD_FAIL",
            "evidence": f"factor={second_d['predicted_top_e_vs_target_factor']}, percent_error={second_d['top_e_percent_error']}",
            "boundary": "Rejected as overshoot."
        },
        {
            "gate": "top_e_closed",
            "test": "Is top/e solved?",
            "status": "NO",
            "evidence": "6π layer is derived as a candidate multiplier, but top-sector trigger/residual remain open.",
            "boundary": "No V12.13."
        },
    ])


def residual_analysis() -> pd.DataFrame:
    residual = TOP_GAP_EXACT - SIX_PI

    candidates = [
        ("residual_exact_gap_minus_6pi", residual, "diagnostic residual"),
        ("residual_as_fraction_of_6pi", residual / SIX_PI, "dimensionless fraction"),
        ("residual_over_amplitude_tax", residual / AMPLITUDE_TAX_FREEZE, "tests relation to D-scale tax"),
        ("residual_over_ln2", residual / LN2, "tests relation to binary unit"),
        ("residual_over_2pi", residual / TWO_PI, "tests relation to phase cycle"),
        ("residual_over_L_eff", residual / L_EFF_FREEZE, "tests relation to frozen effective load"),
        ("log_gap_minus_log_6pi", TOP_GAP_LOG - math.log(SIX_PI), "log residual"),
    ]

    rows = []
    for name, val, interp in candidates:
        rows.append({
            "quantity": name,
            "value": val,
            "interpretation": interp,
            "ruling": "DIAGNOSTIC_ONLY",
        })

    return pd.DataFrame(rows)


def open_claims_ledger() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "open_claim": "top_sector_trigger",
            "status": "OPEN",
            "current_best_candidate": "Top sector receives one additional full 6π closure/load layer.",
            "why_open": "R220 derives the 6π candidate formally but does not yet prove why the top sector activates exactly one extra layer.",
            "required_next": "Find a top-sector activation criterion independent of top/e.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "residual_gap",
            "status": "OPEN",
            "current_best_candidate": "Exact top/e gap is 0.632% above 6π.",
            "why_open": "Residual may be correction, target rounding/context, or sign this is only approximate.",
            "required_next": "Do not fit residual until trigger is derived.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "K_req_origin",
            "status": "OPEN",
            "current_best_candidate": "K_req remains supportive bridge close to 6π.",
            "why_open": "K_req is numerically supportive but not newly derived.",
            "required_next": "Derive K_req or demote it to historical diagnostic.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "species_map",
            "status": "OPEN",
            "current_best_candidate": "Deferred.",
            "why_open": "Species assignment still risks fitting.",
            "required_next": "Attempt only after top-sector trigger is bounded.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "prediction_null_suite",
            "status": "OPEN",
            "current_best_candidate": "Not addressed in R220M.",
            "why_open": "No external no-retuning test yet.",
            "required_next": "Build prediction/null suite after top-sector mechanism decision.",
            "promotion_blocker": True,
        },
        {
            "open_claim": "V12_13_promotion",
            "status": "NO",
            "current_best_candidate": "Not eligible.",
            "why_open": "Top/e trigger, species map, residual, and predictions remain open.",
            "required_next": "No promotion.",
            "promotion_blocker": True,
        },
    ])


def claim_boundary_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Allowed claim",
            "claim": "R220M derives 6π as a formal full-closure candidate from 4π+2π.",
            "status": "YES",
            "safe_wording": "Formal candidate multiplier derived without top/e."
        },
        {
            "category": "Allowed claim",
            "claim": "One extra 6π layer remains the lead top/e structural candidate.",
            "status": "YES",
            "safe_wording": "Lead candidate, not solved top/e."
        },
        {
            "category": "Allowed claim",
            "claim": "Taxed variants and full second D-scale layer are controls.",
            "status": "YES",
            "safe_wording": "Controls only."
        },
        {
            "category": "Blocked claim",
            "claim": "Top/e closure is solved.",
            "status": "NO",
            "safe_wording": "Top-sector trigger and residual remain open."
        },
        {
            "category": "Blocked claim",
            "claim": "Exact top/e gap defines the multiplier.",
            "status": "NO",
            "safe_wording": "Exact gap is diagnostic-only."
        },
        {
            "category": "Blocked claim",
            "claim": "Species map is derived.",
            "status": "NO",
            "safe_wording": "Species map remains open."
        },
        {
            "category": "Blocked claim",
            "claim": "V12.13 is promoted.",
            "status": "NO",
            "safe_wording": "No V12.13 promotion."
        },
    ])


def one_extra_6pi_note_text(created_utc: str) -> str:
    return f"""
# R220M One-Extra-6π Top-Sector Closure Derivation Gate Note

Generated: {created_utc}

This run preserves the R218 D-scale freeze and R219 top/e triage boundary.

## Input

Frozen D-scale law:

    M_i = G_i exp[(3pi - 1/2 ln(25/13)) u_i]

Frozen D-scale endpoint:

    {D_SCALE_ENDPOINT}

Top/e diagnostic target:

    {TOP_E_TARGET}

Exact diagnostic gap:

    {TOP_GAP_EXACT}

## Formal candidate derivation

A full high-sector closure layer is:

    K_top = 4pi + 2pi = 6pi

where:

    4pi = spatial/spinor curvature closure
    2pi = frame/gauge phase closure

Therefore:

    top/e candidate = D_scale_endpoint * 6pi

Numerically:

    6pi = {SIX_PI}
    predicted_top_e = {D_SCALE_ENDPOINT * SIX_PI}
    predicted_vs_target = {(D_SCALE_ENDPOINT * SIX_PI) / TOP_E_TARGET}

## Ruling

R220M derives the 6π multiplier as a formal full-closure candidate without using top/e.
It does not derive why the top sector must receive exactly one such layer.
It does not close the residual.
It does not produce species assignments.
It does not promote V12.13.

## Next proof target

Derive a top-sector activation criterion:

    Why exactly one extra 6π closure/load layer?
"""


def build_report(
    created_utc: str,
    verdict: str,
    scorecard: pd.DataFrame,
    gates: pd.DataFrame,
    residuals: pd.DataFrame,
    open_claims: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R220M — One-Extra-6π Top-Sector Closure Derivation Gate

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R220M tests whether the one-extra-6π top/e multiplier can be derived without using top/e.

Frozen D-scale endpoint:
{D_SCALE_ENDPOINT}

Top/e exact diagnostic gap:
{TOP_GAP_EXACT}

Candidate scorecard:
{scorecard.to_string(index=False)}

Derivation gate matrix:
{gates.to_string(index=False)}

Residual analysis:
{residuals.to_string(index=False)}

Open claims ledger:
{open_claims.to_string(index=False)}

Claim boundary matrix:
{claims.to_string(index=False)}

Interpretation:
R220M derives 6π as a formal full-closure candidate:

K_top = 4π + 2π = 6π.

This gives a structural multiplier independent of the exact top/e gap. It remains the lead top/e candidate, and it beats the taxed/reused-load controls in mechanism priority. The exact top/e gap remains diagnostic-only, and a full second D-scale layer remains rejected.

The result is still not top/e closure. The missing proof is the top-sector trigger: why exactly one extra full closure layer is activated.

Ruling:
Top/e candidate strengthened but not solved.
No species map.
No prediction suite.
No V12.13 promotion.

Next recommended run:
R221M — Top-Sector Activation Criterion Hunt

Question:
Can the theory derive why the high sector receives exactly one extra full 6π closure/load layer and not zero, two, or a taxed variant?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    scorecard = closure_candidate_scorecard()
    gates = derivation_gate_matrix(scorecard)
    residuals = residual_analysis()
    open_claims = open_claims_ledger()
    claims = claim_boundary_matrix()

    lead = scorecard[scorecard["model_id"] == "one_extra_full_closure_4pi_plus_2pi"].iloc[0].to_dict()
    legacy = scorecard[scorecard["model_id"] == "legacy_K_req_load"].iloc[0].to_dict()
    exact = scorecard[scorecard["model_id"] == "exact_top_gap_diagnostic"].iloc[0].to_dict()
    second_d = scorecard[scorecard["model_id"] == "second_D_scale_layer_control"].iloc[0].to_dict()

    verdict = (
        "PARTIAL_PASS_ONE_EXTRA_6PI_MULTIPLIER_DERIVED_AS_FORMAL_FULL_CLOSURE_CANDIDATE_"
        "K_TOP_EQUALS_4PI_PLUS_2PI_WITHOUT_TOP_INPUT_"
        "TOP_E_MATCH_DIAGNOSTIC_SUPPORTIVE_RESIDUAL_AND_TOP_SECTOR_TRIGGER_OPEN_"
        "TAXED_VARIANTS_AND_SECOND_D_LAYER_REJECTED_AS_PRIMARY_"
        "NO_SPECIES_MAP_NO_PREDICTION_SUITE_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "R218_frozen_D_scale_law": {
            "compact_formula": "M_i = G_i exp[(3*pi - 0.5*ln(25/13)) u_i]",
            "L_eff_numeric": L_EFF_FREEZE,
            "N_eff": N_EFF_FREEZE,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "endpoint_vs_D_factor": D_SCALE_ENDPOINT / D_TARGET,
        },
        "top_e_context": {
            "top_e_target_context": TOP_E_TARGET,
            "exact_multiplier_gap": TOP_GAP_EXACT,
            "exact_gap_log": TOP_GAP_LOG,
            "gap_minus_6pi": TOP_GAP_EXACT - SIX_PI,
            "gap_percent_above_6pi": 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0),
        },
        "formal_6pi_derivation": {
            "K_top": "4*pi + 2*pi",
            "four_pi_source": "spatial/spinor curvature closure",
            "two_pi_source": "frame/gauge phase closure",
            "K_top_numeric": SIX_PI,
            "uses_top_to_define": False,
            "uses_D_to_define": False,
        },
        "lead_6pi_candidate": lead,
        "legacy_K_req_bridge": legacy,
        "exact_gap_diagnostic_only": exact,
        "second_D_layer_control": second_d,
        "scorecard": scorecard.to_dict(orient="records"),
        "open_claims": open_claims.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "6pi candidate strengthened, top/e not solved, no V12.13.",
        "next_recommended": "R221M - Top-Sector Activation Criterion Hunt",
        "paste_back_to_chat": [
            "summary.json",
            "one_extra_6pi_note.md",
            "tables/R220M_closure_candidate_scorecard.csv",
            "tables/R220M_derivation_gate_matrix.csv",
            "tables/R220M_residual_analysis.csv",
            "Any traceback if the run failed."
        ],
    }

    scorecard.to_csv(tables / "R220M_closure_candidate_scorecard.csv", index=False)
    gates.to_csv(tables / "R220M_derivation_gate_matrix.csv", index=False)
    residuals.to_csv(tables / "R220M_residual_analysis.csv", index=False)
    open_claims.to_csv(tables / "R220M_open_claims_ledger.csv", index=False)
    claims.to_csv(tables / "R220M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        scorecard=scorecard,
        gates=gates,
        residuals=residuals,
        open_claims=open_claims,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "one_extra_6pi_note.md").write_text(one_extra_6pi_note_text(created_utc), encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
