
# SFT V12.12B R209M — Two-Channel Support Origin and Imbalance Gate

Generated: 2026-06-18T02:28:35Z

Verdict:
PARTIAL_PASS_COMPACT_FORM_PRESERVED_L_EFF_AS_HALF_ACTION_MINUS_AMPLITUDE_TAX_SUPPORTED_THREE_TO_TWO_SPLIT_LEADS_ENDPOINT_EQUAL_TWO_CHANNEL_REMAINS_CLEAN_BINARY_BASE_NATIVE_3_TO_2_ORIGIN_NOT_DERIVED_NO_V12_13

Purpose:
R209M audits Opus's compact form:

M_i = G_i * exp(L_eff * u_i)

and asks which native support bookkeeping could determine L_eff.

Definitions:
G_i = ring Green geometry signal.
u_i = log(rho_i/rho0)/log(4).
L_eff = 3pi - amplitude_tax.

Amplitude tax from support shares:
N_eff = 1 / sum(p_a^2)
amplitude_tax = 1/2 ln(N_eff)

Key constants:
D target context      = 17877.208689571427
top/e target context  = 339000.0
3pi                   = 9.42477796076938
ln2                   = 0.6931471805599453
sqrt2                 = 1.4142135623730951

D-required endpoint split:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "two_channel_possible": true,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446,
  "imbalance_required": 0.20165774222211108
}

Best mechanism summary:
                      mechanism_id       mechanism_family                                  native_status                                                      mechanical_reading  native_score_prior               shares_normalized   p_high    p_low  imbalance    N_eff  amplitude_tax    c_ln2    L_eff  endpoint_rho2  endpoint_vs_D_factor  endpoint_vs_top_e_factor  endpoint_log_error_vs_D_abs  span_max_over_min  rmse_log_vs_D_target  rmse_log_vs_top_e_target  distance_to_required_p_high  distance_to_equal_split  distance_to_3_to_2  combined_score
           equal_two_channel_sqrt2         binary_support      conditional_if_two_channel_origin_derived                                   two equal orthogonal support channels                 8.0                       (0.5,0.5) 0.500000 0.500000   0.000000 2.000000       0.346574 0.500000 9.078204   17524.436390              0.980267                  0.051695                     0.019930       17524.436390              0.710228                  1.487449                     0.100829                 0.000000            0.100000            13.0
   spinor_frame_sqrt_4pi_2pi_split           spinor_frame                            amplitude_candidate  amplitude split proportional to square roots of 4π and 2π load sectors                 6.0 (0.585786437627,0.414213562373) 0.585786 0.414214   0.171573 1.942809       0.332067 0.479072 9.092711   17780.501218              0.994590                  0.052450                     0.005424       17780.501218              0.716679                  1.478726                     0.015042                 0.085786            0.014214            12.0
        three_to_two_channel_split rational_support_count conditional_if_3_to_2_support_count_is_derived                            3:2 support participation, exact 60/40 split                 6.0                       (0.6,0.4) 0.600000 0.400000   0.200000 1.923077       0.326963 0.471708 9.097815   17871.488624              0.999680                  0.052718                     0.000320       17871.488624              0.718964                  1.475658                     0.000829                 0.100000            0.000000            12.0
   spinor_frame_4pi_2pi_load_split           spinor_frame                       candidate_from_R193_R194 support split proportional to 4π curvature load and 2π frame phase load                 7.0 (0.666666666667,0.333333333333) 0.666667 0.333333   0.333333 1.800000       0.293893 0.423998 9.130885   18472.377901              1.033292                  0.054491                     0.032750       18472.377901              0.733949                  1.455805                     0.065838                 0.166667            0.066667            11.0
         three_plus_one_sqrt_split         3plus1_support                amplitude_candidate_from_3plus1  amplitude split from sqrt(3) support envelope versus 1 tangent channel                 5.5 (0.633974596216,0.366025403784) 0.633975 0.366025   0.267949 1.866025       0.311905 0.449984 9.112873   18142.631570              1.014847                  0.053518                     0.014738       18142.631570              0.725749                  1.466614                     0.033146                 0.133975            0.033975            10.5
        three_plus_one_count_split         3plus1_support           candidate_from_3plus1_slot_structure            3 normal/support directions versus 1 tangent/write direction                 5.0                     (0.75,0.25) 0.750000 0.250000   0.500000 1.600000       0.235002 0.339036 9.189776   19592.915518              1.095972                  0.057796                     0.091641       19592.915518              0.761366                  1.420545                     0.149171                 0.250000            0.150000             9.0
          four_equal_channel_split         binary_support                          curve_shape_candidate                    two independent binary splits or four equal channels                 5.0           (0.25,0.25,0.25,0.25) 0.250000 0.250000   0.000000 4.000000       0.693147 1.000000 8.731631   12391.647808              0.693153                  0.036554                     0.366504       12391.647808              0.579575                  1.697676                     0.350829                 0.250000            0.350000             9.0
          two_plus_one_count_split  support_count_control                                        control                                                       2:1 split control                 4.0 (0.666666666667,0.333333333333) 0.666667 0.333333   0.333333 1.800000       0.293893 0.423998 9.130885   18472.377901              1.033292                  0.054491                     0.032750       18472.377901              0.733949                  1.455805                     0.065838                 0.166667            0.066667             6.0
                golden_ratio_split                control                             control_not_native                                              golden ratio split control                 1.0   (0.61803398875,0.38196601125) 0.618034 0.381966   0.236068 1.894427       0.319458 0.460881 9.105320   18006.118249              1.007211                  0.053115                     0.007185       18006.118249              0.722338                  1.471149                     0.017205                 0.118034            0.018034             5.0
spinor_frame_squared_4pi_2pi_split           spinor_frame                  control_likely_too_imbalanced          intensity-like split proportional to squared 4π and 2π sectors                 3.0                       (0.8,0.2) 0.800000 0.200000   0.600000 1.470588       0.192831 0.278197 9.231947   20436.829115              1.143178                  0.060286                     0.133812       20436.829115              0.781529                  1.395376                     0.199171                 0.300000            0.200000             4.0
              no_split_half_action                control                                        control                       pure half-action feedback with no amplitude split                 1.0                             (1) 1.000000 0.000000   1.000000 1.000000       0.000000 0.000000 9.424778   24783.295616              1.386307                  0.073107                     0.326643       24783.295616              0.878440                  1.281258                     0.399171                 0.500000            0.400000             0.0
       D_inferred_split_diagnostic        diagnostic_only                         diagnostic_only_uses_D                              split inferred from D endpoint; not native                -5.0 (0.600828871111,0.399171128889) 0.600829 0.399171   0.201658 1.921846       0.326643 0.471247 9.098135   17877.208690              1.000000                  0.052735                     0.000000       17877.208690              0.719108                  1.475466                     0.000000                 0.100829            0.000829            -7.0

Pairwise comparison:
                    mechanism_a                     mechanism_b  delta_endpoint_log_error_abs_a_minus_b  delta_rmse_D_a_minus_b  delta_native_prior_a_minus_b  delta_combined_score_a_minus_b
        equal_two_channel_sqrt2      three_to_two_channel_split                                0.019610               -0.008737                           2.0                             1.0
        equal_two_channel_sqrt2 spinor_frame_4pi_2pi_load_split                               -0.012820               -0.023722                           1.0                             2.0
        equal_two_channel_sqrt2 spinor_frame_sqrt_4pi_2pi_split                                0.014506               -0.006452                           2.0                             1.0
        equal_two_channel_sqrt2       three_plus_one_sqrt_split                                0.005193               -0.015521                           2.5                             2.5
        equal_two_channel_sqrt2        four_equal_channel_split                               -0.346574                0.130653                           3.0                             4.0
spinor_frame_4pi_2pi_load_split      three_to_two_channel_split                                0.032430                0.014985                           1.0                            -1.0
spinor_frame_4pi_2pi_load_split spinor_frame_sqrt_4pi_2pi_split                                0.027326                0.017270                           1.0                            -1.0
spinor_frame_4pi_2pi_load_split       three_plus_one_sqrt_split                                0.018012                0.008200                           1.5                             0.5
spinor_frame_sqrt_4pi_2pi_split      three_to_two_channel_split                                0.005104               -0.002285                           0.0                             0.0
spinor_frame_sqrt_4pi_2pi_split       three_plus_one_sqrt_split                               -0.009314               -0.009070                           0.5                             1.5
      three_plus_one_sqrt_split      three_to_two_channel_split                                0.014418                0.006785                          -0.5                            -1.5
       four_equal_channel_split      three_to_two_channel_split                                0.366184               -0.139390                          -1.0                            -3.0
       four_equal_channel_split spinor_frame_4pi_2pi_load_split                                0.333754               -0.154375                          -2.0                            -2.0
       four_equal_channel_split spinor_frame_sqrt_4pi_2pi_split                                0.361080               -0.137105                          -1.0                            -3.0
       four_equal_channel_split       three_plus_one_sqrt_split                                0.351766               -0.146175                          -0.5                            -1.5

Gate matrix:
             gate                                                 test                  status                                                    boundary
  compact_formula                             M_i = G_i exp(L_eff u_i)               PRESERVED Formula family is preserved; coefficient still under audit.
equal_two_channel           Two equal support channels give sqrt2 tax.                    LIVE    Cleanest action-like candidate but not exact D endpoint.
     three_to_two Exact 3:2 support split gives near-exact D endpoint. LEAD_ENDPOINT_CANDIDATE              Requires deriving 3:2 support count without D.
     fourpi_twopi                            4π:2π spinor/frame split.                  TESTED                 Native-looking but must beat numeric gates.
 diagnostic_split                              D-inferred 60/40 split.         DIAGNOSTIC_ONLY               Cannot count as derivation because it uses D.
            top_e                                  Full top/e context.                    OPEN                                   No top/e closure claimed.
           V12_13                                           Promotion.                      NO  Need native support-count derivation and prediction nulls.

Claim boundary:
 category                                                                    claim          status                                                      boundary
Preserved                The compact mass-lane family is M_i = G_i exp(L_eff u_i).       PRESERVED                   Still a D-scale lane, not full species map.
Preserved L_eff is controlled by half-action minus an amplitude participation tax.  LIVE_CANDIDATE                            Tax origin must be action-derived.
 Observed                      A 3:2 split is the near-exact D endpoint candidate. DIAGNOSTIC_PASS                            3:2 support count not yet derived.
 Observed     Equal two-channel sqrt2 remains the cleanest minimal binary premise.  LIVE_CANDIDATE                                 Less exact endpoint than 3:2.
 Rejected                               R209M derives the particle mass hierarchy.              NO No species map, no top/e closure, no final coefficient proof.
Promotion                                                        V12.13 promotion.              NO                                               Not yet earned.

Interpretation:
R209M preserves the compact formula M_i = G_i exp(L_eff u_i).

The coefficient L_eff appears to be half-action minus an amplitude participation tax.

The exact D endpoint prefers a two-channel split close to 60/40, and the exact rational 3:2 split nearly matches it without using D if the 3:2 support count can be derived.

Equal two-channel sqrt2 remains the cleanest minimal binary premise, but it undershoots D by about 1.97%.

The next gate is not more fitting. The next gate is to derive or reject the 3:2 support count from SFT structure.

Ruling:
No V12.13 promotion.

Next recommended run:
R210M — 3:2 Support Count Derivation Gate

Question:
Can the 3:2 split be derived from 3+1 slots, 4pi:2pi spinor-frame structure, or boundary write/support bookkeeping without using D?
