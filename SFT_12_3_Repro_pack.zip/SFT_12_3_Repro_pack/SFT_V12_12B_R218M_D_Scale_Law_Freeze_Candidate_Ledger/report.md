
# SFT V12.12B R218M — D-Scale Law Freeze Candidate and Remaining-Open-Claims Ledger

Generated: 2026-06-18T04:58:37Z

Verdict:
FREEZE_CANDIDATE_D_SCALE_TRACE_VARIATIONAL_LAW_PRESERVED_L_EFF_EQUALS_3PI_MINUS_HALF_LN_25_OVER_13_R213_TO_R217_CHAIN_LOCKED_AS_CONDITIONAL_PAPER_GRADE_LANE_SPECIES_MAP_TOP_E_GLOBAL_ACTION_AND_PREDICTION_SUITE_OPEN_NO_V12_13_PROMOTION

Purpose:
R218M freezes the D-scale law candidate and records remaining open claims.

Frozen law candidate:
M_i = G_i exp[(3pi - 1/2 ln(25/13)) u_i]

D-scale law card:
                   item                        value                    status                                        boundary
        compact_formula     M_i = G_i exp(L_eff u_i)          FREEZE_CANDIDATE       D-scale lane only; no species assignment.
         effective_load L_eff = 3*pi - 1/2 ln(25/13)          FREEZE_CANDIDATE Conditional on canonical 3+2 variational patch.
                  N_eff           1.9230769230769231 DERIVED_FROM_3_TO_2_TRACE                   Sector trace weights 3 and 2.
          amplitude_tax            0.326963233703332        DERIVED_FROM_N_EFF                                  1/2 ln(N_eff).
          endpoint_rho2            17871.48862357384                DIAGNOSTIC               D used only after law is written.
          endpoint_vs_D           0.9996800358435753                DIAGNOSTIC          Hits D-scale endpoint to about 0.032%.
endpoint_log_error_vs_D       0.00032001535587697285                DIAGNOSTIC                      Not an empirical mass fit.
           top_e_status          0.05271825552676649                      OPEN         Top/e hierarchy not closed by this law.

Proof chain ledger:
  run                                  step                                                                                                   result     claim_status                                            open_boundary
R213M                Trace protection audit  Trace-weighted 3:2 survives normalization drift/cross-term audit; mixed eigenchannel bookkeeping fails.        PRESERVED                 Trace protection mechanism still needed.
R214M Symmetry/incommensurability mechanism       Spatial support and phase closure are incommensurable sectors protected by independent symmetries.      FORMAL_PASS          Equal per-component normalization still needed.
R215M        Canonical sector normalization    Equal per-component normalization k=1 is lead native choice; D-required k is only about +0.346% away. CONDITIONAL_PASS             Master-action metric statement still needed.
R216M     Canonical 3+2 master-action patch Q=(X1,X2,X3;Phi_spinor,Phi_frame) and dQ^2=sum dX_i^2+sum dPhi_a^2 written; raw-radian control rejected.  PATCH_CANDIDATE               Variational trace derivation still needed.
R217M   Variational trace-weight derivation            Second variation gives E[delta^2 S_s]=1/2 sigma^2 Tr(P_s H P_s); H=I5 yields weights 3 and 2. CONDITIONAL_PASS Species map, top/e closure, prediction suite still open.
R218M               Freeze candidate ledger                                           D-scale law candidate frozen with explicit open-claims ledger. FREEZE_CANDIDATE                                     No V12.13 promotion.

Null/control ledger:
                   null_or_control               tested_in                                                                        result  endpoint_vs_D            ruling                                                          boundary
five_independent_eigenchannel_null R213M/R214M/R216M/R217M               Fails as primary bookkeeping if protected sectors are physical.       0.619975 REJECT_AS_PRIMARY                                     Valid as a null/control only.
        raw_radian_phase_weighting             R216M/R217M              Fails as native metric because it double-counts closure periods.       1.211016  REJECT_AS_NATIVE Raw 4pi/2pi periods must normalize phases, not weight the metric.
              D_exact_k_diagnostic       R215M/R216M/R217M Exact D fit requires k_space/k_phase = 1.003460801..., only +0.346% from k=1.       1.000000   DIAGNOSTIC_ONLY                                 Uses D and cannot define the law.
            nearby_k_1p005_control             R215M/R216M                                   Close endpoint but lacks native derivation.       1.000143           CONTROL                                  Not promoted over canonical k=1.
          sqrt_4pi_sqrt_2pi_bridge             R209M-R216M          Supportive spinor-frame bridge, close but not as clean as trace 3:2.       0.994590 SUPPORTIVE_BRIDGE                                               Not the freeze law.

Remaining open claims:
                  open_claim       status                                                                                                               why_open                                                                        required_next  promotion_blocker
                 species_map         OPEN                                  No mapping from D-scale mode ladder to electron/muon/tau/quark/etc. has been derived.    Define admissible mode-to-species assignment rule without fitting species labels.               True
               top_e_closure         OPEN                                  The frozen D-scale law endpoint is about 5.27% of the current top/e diagnostic scale.  Derive additional layering, generation stacking, or top-sector compounding if real.               True
            prediction_suite         OPEN                                   No new falsifiable external prediction has been produced from the D-scale law alone.                         Build prediction/null test matrix before stronger promotion.               True
full_master_action_variation PARTIAL_OPEN R217 derives trace rule from the patch-level second variation, but global master-action derivation remains incomplete. Embed patch in full action and show variational consistency with existing SFT terms.               True
 external_dataset_blind_test         OPEN                         No blind holdout or independently specified data test has been run for particle-sector claims.                 Specify a no-retuning prediction test before looking at target data.               True
            V12_13_promotion           NO                                            D-scale law candidate is mature, but species/top-e/predictions remain open.           Do not promote until blockers above are resolved or explicitly scoped out.               True

Promotion gate matrix:
                          gate                status                                                         evidence                                   promotion_effect
         D_scale_law_candidate PASS_FREEZE_CANDIDATE            R213-R217 chain supports L_eff = 3pi - 1/2 ln(25/13).   May freeze as conditional D-scale law candidate.
   coefficient_not_fitted_to_D         PASS_BOUNDARY      Law uses canonical 3+2 trace; D-exact k is diagnostic-only.             Supports paper-grade candidate status.
trace_rule_variational_support      PASS_CONDITIONAL R217 second variation gives sector traces under canonical patch.                             Strengthens mechanism.
            species_assignment             FAIL_OPEN                                          No derived species map.                                     Blocks V12.13.
                 top_e_closure             FAIL_OPEN                                          Top/e scale not closed.                                     Blocks V12.13.
         prediction_null_suite             FAIL_OPEN                   Prediction and destructive null suite not run.                                     Blocks V12.13.
                        V12_13          NO_PROMOTION                  Freeze candidate is not final theory promotion. Preserve as V12.12B D-scale freeze candidate only.

Claim boundary matrix:
     category                                                    claim status                                              safe_wording
Allowed claim       R218M freezes a conditional D-scale law candidate.    YES D-scale law candidate, not full particle mass derivation.
Allowed claim    The frozen coefficient is L_eff = 3π - 1/2 ln(25/13).    YES           Conditional on canonical 3+2 variational patch.
Allowed claim       The law hits the D-scale endpoint to about 0.032%.    YES Diagnostic endpoint agreement; not empirical species fit.
Allowed claim R217 supports trace weighting from the second variation.    YES                          Patch-level variational support.
Blocked claim        SFT has derived the full particle mass hierarchy.     NO                Species map and top/e closure remain open.
Blocked claim                                      V12.13 is promoted.     NO                                      No V12.13 promotion.
Blocked claim                               The top/e scale is solved.     NO                                       Top/e remains open.
Blocked claim    The D-scale law has passed external prediction tests.     NO                       Prediction/null suite remains open.

Interpretation:
R218M is not another coefficient hunt. It freezes the coefficient lane as a conditional D-scale law candidate.

The coefficient L_eff = 3pi - 1/2 ln(25/13) is supported by the R213-R217 chain:
trace protection, symmetry/incommensurability, canonical equal normalization, explicit canonical patch, and second-variation trace weighting.

The result remains bounded:
it is a D-scale law candidate, not a full particle mass hierarchy. Species assignment, top/e closure, global master-action embedding, and prediction/null tests remain open.

Ruling:
Freeze candidate only.
No V12.13 promotion.

Next recommended run:
R219M — Species Map Constraint Skeleton OR Top/e Closure Mechanism Triage

Choice:
A. Try to derive an admissible species map without using empirical species labels.
B. Try to explain why top/e requires an additional layer beyond the frozen D-scale law.
