#!/usr/bin/env python3
"""
SFT V12.12B R210M — 3:2 Support Count and Spinor-Frame Origin Gate

Purpose:
    Test my R210M gate and Opus's proposed native 3:2 decomposition together.

Opus hypothesis:
    Three spatial / normal support coordinates form the high channel.
    Two phase closure completions form the low channel:
        3 spatial support coordinates : 2 phase closure completions = 3:2

Compact formula under audit:
    M_i = G_i * exp(L_eff * u_i)

    G_i     = Green-geometry signal
    u_i     = log(rho_i/rho0)/log(4)
    L_eff   = 3π - amplitude_tax

For grouped support shares a:b:
    p_a = a/(a+b)
    p_b = b/(a+b)
    N_eff = 1 / (p_a^2 + p_b^2)
    amplitude_tax = 1/2 ln(N_eff)

For 3:2:
    N_eff = 25/13
    amplitude_tax = 1/2 ln(25/13)
    L_eff = 3π - 1/2 ln(25/13)

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - no V12.13 promotion

Outputs:
    SFT_V12_12B_R210M_3to2_Support_Count_and_Spinor_Frame_Origin_Gate/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R210M.py

    SFT_V12_12B_R210M_3to2_Support_Count_and_Spinor_Frame_Origin_Gate_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
from fractions import Fraction
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R210M_3to2_Support_Count_and_Spinor_Frame_Origin_Gate"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
SQRT2 = math.sqrt(2.0)
PHI = (1.0 + math.sqrt(5.0)) / 2.0

TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi
HALF_K_REQ = K_REQ / 2.0

RHO0 = 0.5
RHO_SPAN = 4.0

SEED_MODES = [
    Fraction(1, 2),
    Fraction(2, 3),
    Fraction(3, 4),
    Fraction(1, 1),
    Fraction(5, 4),
    Fraction(4, 3),
    Fraction(3, 2),
    Fraction(5, 3),
    Fraction(2, 1),
]

D_PERP = 3


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def frac_str(f: Fraction) -> str:
    if f.denominator == 1:
        return str(f.numerator)
    return f"{f.numerator}/{f.denominator}"


def balanced_occupancy(m: int, n: int) -> list[int]:
    active = min(max(n, 1), D_PERP)
    q, r = divmod(m, active)

    occ = [q + 1 if i < r else q for i in range(active)]
    occ += [0] * (D_PERP - len(occ))
    occ.sort(reverse=True)

    return occ


def shape_stats(occ: list[int]) -> dict:
    total = sum(occ)
    probs = [x / total for x in occ] if total else [0.0, 0.0, 0.0]

    l2 = math.sqrt(sum(p * p for p in probs))
    iso = 1.0 / D_PERP

    eccentricity = 0.0
    if total:
        eccentricity = math.sqrt(sum((p - iso) ** 2 for p in probs)) / math.sqrt(2.0 / 3.0)

    entropy = -sum(p * math.log(p) for p in probs if p > 0)
    entropy_norm = entropy / math.log(D_PERP)
    entropy_deficit = 1.0 - entropy_norm

    active_slots = sum(1 for x in occ if x > 0)
    max_occ = max(occ) if occ else 0
    slot_fill_fraction = active_slots / D_PERP

    return {
        "shape_l2_norm": l2,
        "eccentricity_norm": eccentricity,
        "entropy_norm": entropy_norm,
        "entropy_deficit": entropy_deficit,
        "active_slots": active_slots,
        "max_occ": max_occ,
        "slot_fill_fraction": slot_fill_fraction,
    }


def build_modes() -> pd.DataFrame:
    rows = []

    for rho in SEED_MODES:
        m = rho.numerator
        n = rho.denominator
        occ = balanced_occupancy(m, n)
        stats = shape_stats(occ)

        rows.append({
            "rho": frac_str(rho),
            "rho_float": float(rho),
            "m": m,
            "N": n,
            "occupancy_vector": "(" + ",".join(str(x) for x in occ) + ")",
            "occ0": occ[0],
            "occ1": occ[1],
            "occ2": occ[2],
            "active_slots": stats["active_slots"],
            "max_occ": stats["max_occ"],
            "slot_fill_fraction": stats["slot_fill_fraction"],
            "shape_l2_norm": stats["shape_l2_norm"],
            "eccentricity_norm": stats["eccentricity_norm"],
            "entropy_norm": stats["entropy_norm"],
            "entropy_deficit": stats["entropy_deficit"],
            "u_logrho": math.log(float(rho) / RHO0) / math.log(RHO_SPAN),
        })

    return pd.DataFrame(rows).sort_values("rho_float").reset_index(drop=True)


def fibonacci_sphere(n: int = 300) -> np.ndarray:
    pts = []
    phi = math.pi * (3.0 - math.sqrt(5.0))

    for i in range(n):
        y = 1.0 - (i / float(n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - y * y))
        theta = phi * i
        x = math.cos(theta) * radius
        z = math.sin(theta) * radius
        pts.append([x, y, z])

    return np.array(pts, dtype=float)


SPHERE_POINTS = fibonacci_sphere(300)
RHAT = SPHERE_POINTS.copy()


def ring_basis(axis_index: int) -> tuple[np.ndarray, np.ndarray]:
    if axis_index == 0:
        return np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])
    if axis_index == 1:
        return np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])
    return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])


def source_points_ring(
    occ: list[int],
    ring_radius: float = 0.55,
    n_per_ring: int = 36,
) -> tuple[np.ndarray, np.ndarray]:
    positions = []
    weights = []

    for axis_index, weight in enumerate(occ):
        if weight <= 0:
            continue

        e1, e2 = ring_basis(axis_index)

        for j in range(n_per_ring):
            t = 2.0 * math.pi * j / n_per_ring
            point = ring_radius * (math.cos(t) * e1 + math.sin(t) * e2)
            positions.append(point)
            weights.append(weight / n_per_ring)

    return np.array(positions, dtype=float), np.array(weights, dtype=float)


def eval_ring_geometry(
    occ: list[int],
    softening: float = 0.12,
    ring_radius: float = 0.55,
) -> dict:
    pos, weights = source_points_ring(occ, ring_radius=ring_radius)

    potentials = []
    grad_mags = []
    abs_radial_curvatures = []

    for x, rh in zip(SPHERE_POINTS, RHAT):
        d = x[None, :] - pos
        d2 = np.sum(d * d, axis=1) + softening ** 2
        R = np.sqrt(d2)

        potential = np.sum(weights / R)

        grad = np.sum((-weights[:, None] * d) / (R[:, None] ** 3), axis=0)
        grad_mag = np.linalg.norm(grad)

        rd = d @ rh
        hess_radial = np.sum(weights * (-1.0 / (R ** 3) + 3.0 * (rd ** 2) / (R ** 5)))

        potentials.append(float(potential))
        grad_mags.append(float(grad_mag))
        abs_radial_curvatures.append(abs(float(hess_radial)))

    return {
        "mean_potential": float(np.mean(potentials)),
        "mean_gradient_magnitude": float(np.mean(grad_mags)),
        "mean_abs_radial_curvature": float(np.mean(abs_radial_curvatures)),
        "p95_abs_radial_curvature": float(np.quantile(abs_radial_curvatures, 0.95)),
    }


def add_geometry_signal(modes: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in modes.iterrows():
        occ = [int(row["occ0"]), int(row["occ1"]), int(row["occ2"])]
        obs = eval_ring_geometry(occ)

        rec = row.to_dict()
        rec.update(obs)
        rows.append(rec)

    df = pd.DataFrame(rows)

    for col in [
        "mean_potential",
        "mean_gradient_magnitude",
        "mean_abs_radial_curvature",
        "p95_abs_radial_curvature",
    ]:
        base = df.loc[df["rho"] == "1/2", col].iloc[0]
        df[col + "_ratio_to_rho_half"] = df[col] / base

    df["G_i_geometry_ratio"] = df["mean_abs_radial_curvature_ratio_to_rho_half"]
    return df


def target_power_exponent(target_span: float) -> float:
    return math.log(target_span) / math.log(RHO_SPAN)


P_D = target_power_exponent(D_TARGET)
P_TOP = target_power_exponent(TOP_E_TARGET)
P_HALF_6PI = (SIX_PI / 2.0) / math.log(RHO_SPAN)
P_HALF_KREQ = (K_REQ / 2.0) / math.log(RHO_SPAN)


def add_targets(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    out["target_D_rhopower"] = (out["rho_float"] / RHO0) ** P_D
    out["target_top_e_rhopower"] = (out["rho_float"] / RHO0) ** P_TOP
    out["target_half_6pi_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_6PI
    out["target_half_Kreq_rhopower"] = (out["rho_float"] / RHO0) ** P_HALF_KREQ

    return out


def amplitude_tax_from_shares(shares: list[float]) -> dict:
    arr = np.array(shares, dtype=float)
    arr = arr[arr > 0]

    if arr.size == 0:
        return {
            "N_eff": 1.0,
            "amplitude_tax": 0.0,
            "c_ln2": 0.0,
            "share_string": "()",
            "p_high": np.nan,
            "p_low": np.nan,
            "imbalance": np.nan,
            "participation_sum_squares": 1.0,
        }

    arr = arr / np.sum(arr)
    sumsq = float(np.sum(arr * arr))
    N_eff = 1.0 / sumsq
    amplitude_tax = 0.5 * math.log(N_eff)
    c_ln2 = amplitude_tax / LN2

    sorted_arr = sorted(arr.tolist(), reverse=True)
    if len(sorted_arr) >= 2:
        p_high = sorted_arr[0]
        p_low = sorted_arr[1]
        imbalance = p_high - p_low
    else:
        p_high = sorted_arr[0]
        p_low = 0.0
        imbalance = p_high

    return {
        "N_eff": N_eff,
        "amplitude_tax": amplitude_tax,
        "c_ln2": c_ln2,
        "share_string": "(" + ",".join(f"{x:.12g}" for x in arr.tolist()) + ")",
        "p_high": p_high,
        "p_low": p_low,
        "imbalance": imbalance,
        "participation_sum_squares": sumsq,
    }


def required_D_split_from_geometry(geometry_endpoint: float) -> dict:
    L_required = math.log(D_TARGET / geometry_endpoint)
    tax_required = THREE_PI - L_required
    c_required = tax_required / LN2
    N_eff = math.exp(2.0 * tax_required)

    if 1.0 <= N_eff <= 2.0:
        sumsq = 1.0 / N_eff
        y2 = max(0.0, (sumsq - 0.5) / 2.0)
        y = math.sqrt(y2)
        p_high = 0.5 + y
        p_low = 0.5 - y
        possible = True
    else:
        p_high = np.nan
        p_low = np.nan
        possible = False

    return {
        "L_required_endpoint": L_required,
        "tax_required": tax_required,
        "c_required": c_required,
        "N_eff_required": N_eff,
        "two_channel_possible": possible,
        "p_high_required": p_high,
        "p_low_required": p_low,
        "imbalance_required": p_high - p_low if possible else np.nan,
    }


def support_origin_candidates(geometry_endpoint: float) -> pd.DataFrame:
    req = required_D_split_from_geometry(geometry_endpoint)
    p_req = req["p_high_required"]

    rows = [
        {
            "mechanism_id": "opus_3_spatial_2_phase_grouped",
            "mechanism_family": "opus_3plus2",
            "shares": [3.0, 2.0],
            "native_score_prior": 9.0,
            "uses_D_to_define": False,
            "mechanical_reading": "three spatial support coordinates grouped against two phase closure completions",
            "native_status": "conditional_pass_if_grouping_is_action_derived"
        },
        {
            "mechanism_id": "opus_5_components_ungrouped",
            "mechanism_family": "opus_3plus2_null",
            "shares": [1.0, 1.0, 1.0, 1.0, 1.0],
            "native_score_prior": 5.0,
            "uses_D_to_define": False,
            "mechanical_reading": "three spatial plus two phase components treated as five independent equal channels",
            "native_status": "null_control_against_grouping"
        },
        {
            "mechanism_id": "opus_sqrt_count_3_2",
            "mechanism_family": "opus_3plus2",
            "shares": [math.sqrt(3.0), math.sqrt(2.0)],
            "native_score_prior": 7.0,
            "uses_D_to_define": False,
            "mechanical_reading": "three spatial and two phase sectors combine internally in quadrature before channel participation",
            "native_status": "amplitude_count_candidate"
        },
        {
            "mechanism_id": "opus_intensity_count_3_2",
            "mechanism_family": "opus_3plus2_null",
            "shares": [9.0, 4.0],
            "native_score_prior": 3.0,
            "uses_D_to_define": False,
            "mechanical_reading": "intensity-like square of 3:2 count",
            "native_status": "control_likely_too_imbalanced"
        },
        {
            "mechanism_id": "equal_two_channel_sqrt2",
            "mechanism_family": "binary_support",
            "shares": [1.0, 1.0],
            "native_score_prior": 8.0,
            "uses_D_to_define": False,
            "mechanical_reading": "two equal orthogonal support channels",
            "native_status": "clean_minimal_binary_candidate"
        },
        {
            "mechanism_id": "spinor_frame_4pi_2pi_load_split",
            "mechanism_family": "spinor_frame",
            "shares": [FOUR_PI, TWO_PI],
            "native_score_prior": 7.0,
            "uses_D_to_define": False,
            "mechanical_reading": "support split proportional to 4π spinor curvature load and 2π frame phase load",
            "native_status": "candidate_from_R193_R194"
        },
        {
            "mechanism_id": "spinor_frame_sqrt_4pi_2pi_split",
            "mechanism_family": "spinor_frame",
            "shares": [math.sqrt(FOUR_PI), math.sqrt(TWO_PI)],
            "native_score_prior": 7.5,
            "uses_D_to_define": False,
            "mechanical_reading": "amplitude split proportional to square roots of 4π and 2π load sectors",
            "native_status": "amplitude_candidate_from_spinor_frame"
        },
        {
            "mechanism_id": "three_plus_one_count_split",
            "mechanism_family": "3plus1_support",
            "shares": [3.0, 1.0],
            "native_score_prior": 5.0,
            "uses_D_to_define": False,
            "mechanical_reading": "3 normal/support directions versus 1 tangent/write direction",
            "native_status": "candidate_from_3plus1_slot_structure"
        },
        {
            "mechanism_id": "three_plus_one_sqrt_split",
            "mechanism_family": "3plus1_support",
            "shares": [math.sqrt(3.0), 1.0],
            "native_score_prior": 5.5,
            "uses_D_to_define": False,
            "mechanical_reading": "sqrt(3) support envelope versus 1 tangent channel",
            "native_status": "amplitude_candidate_from_3plus1"
        },
        {
            "mechanism_id": "four_equal_channel_full_ln2",
            "mechanism_family": "binary_support",
            "shares": [1.0, 1.0, 1.0, 1.0],
            "native_score_prior": 5.0,
            "uses_D_to_define": False,
            "mechanical_reading": "two independent equal binary splits or four equal channels",
            "native_status": "curve_shape_candidate"
        },
        {
            "mechanism_id": "golden_ratio_control",
            "mechanism_family": "control",
            "shares": [PHI, 1.0],
            "native_score_prior": 1.0,
            "uses_D_to_define": False,
            "mechanical_reading": "golden ratio split control",
            "native_status": "control_not_native"
        },
        {
            "mechanism_id": "D_inferred_split_diagnostic",
            "mechanism_family": "diagnostic_only",
            "shares": [p_req, 1.0 - p_req],
            "native_score_prior": -8.0,
            "uses_D_to_define": True,
            "mechanical_reading": "split inferred from D endpoint",
            "native_status": "diagnostic_only_uses_D"
        },
    ]

    out = []
    for row in rows:
        tax = amplitude_tax_from_shares(row["shares"])
        rec = dict(row)
        rec.update({
            "shares_normalized": tax["share_string"],
            "N_eff": tax["N_eff"],
            "amplitude_tax": tax["amplitude_tax"],
            "c_ln2": tax["c_ln2"],
            "L_eff": THREE_PI - tax["amplitude_tax"],
            "p_high": tax["p_high"],
            "p_low": tax["p_low"],
            "imbalance": tax["imbalance"],
            "distance_to_required_p_high": abs(tax["p_high"] - p_req) if not np.isnan(p_req) else np.nan,
            "distance_to_equal_split": abs(tax["p_high"] - 0.5) if not np.isnan(tax["p_high"]) else np.nan,
            "distance_to_3_to_2": abs(tax["p_high"] - 0.6) if not np.isnan(tax["p_high"]) else np.nan,
            "closed_form_tax_hint": closed_form_tax_hint(row["mechanism_id"], tax),
        })
        out.append(rec)

    return pd.DataFrame(out)


def closed_form_tax_hint(mechanism_id: str, tax: dict) -> str:
    if mechanism_id == "opus_3_spatial_2_phase_grouped":
        return "tax = 1/2 ln(25/13), L_eff = 3pi - 1/2 ln(25/13)"
    if mechanism_id == "equal_two_channel_sqrt2":
        return "tax = 1/2 ln2, L_eff = 3pi - 1/2 ln2"
    if mechanism_id == "opus_5_components_ungrouped":
        return "tax = 1/2 ln5"
    if mechanism_id == "spinor_frame_4pi_2pi_load_split":
        return "tax = 1/2 ln(9/5)"
    return "tax = 1/2 ln(N_eff)"


def evaluate_origin_models(df: pd.DataFrame, origins: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for _, row in df.iterrows():
        G = float(row["G_i_geometry_ratio"])
        u = float(row["u_logrho"])

        for _, origin in origins.iterrows():
            L_eff = float(origin["L_eff"])
            ratio = G * math.exp(L_eff * u)

            rows.append({
                "rho": row["rho"],
                "rho_float": row["rho_float"],
                "m": int(row["m"]),
                "N": int(row["N"]),
                "occupancy_vector": row["occupancy_vector"],
                "G_i_geometry_ratio": G,
                "u_logrho": u,
                "mechanism_id": origin["mechanism_id"],
                "mechanism_family": origin["mechanism_family"],
                "native_status": origin["native_status"],
                "uses_D_to_define": bool(origin["uses_D_to_define"]),
                "native_score_prior": float(origin["native_score_prior"]),
                "mechanical_reading": origin["mechanical_reading"],
                "closed_form_tax_hint": origin["closed_form_tax_hint"],
                "shares_normalized": origin["shares_normalized"],
                "N_eff": float(origin["N_eff"]),
                "amplitude_tax": float(origin["amplitude_tax"]),
                "c_ln2": float(origin["c_ln2"]),
                "L_eff": L_eff,
                "p_high": float(origin["p_high"]),
                "p_low": float(origin["p_low"]),
                "imbalance": float(origin["imbalance"]),
                "model_ratio_to_rho_half": ratio,
                "target_D_rhopower": row["target_D_rhopower"],
                "target_top_e_rhopower": row["target_top_e_rhopower"],
                "residual_log_vs_D": math.log(ratio / row["target_D_rhopower"]) if ratio > 0 else np.nan,
                "residual_log_vs_top_e": math.log(ratio / row["target_top_e_rhopower"]) if ratio > 0 else np.nan,
            })

    return pd.DataFrame(rows)


def summarize_models(outputs: pd.DataFrame, origins: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for mechanism_id, grp in outputs.groupby("mechanism_id"):
        ordered = grp.sort_values("rho_float")
        endpoint = float(ordered["model_ratio_to_rho_half"].iloc[-1])
        span = float(ordered["model_ratio_to_rho_half"].max() / ordered["model_ratio_to_rho_half"].min())
        rmse_D = float(np.sqrt(np.nanmean(ordered["residual_log_vs_D"] ** 2)))
        rmse_top = float(np.sqrt(np.nanmean(ordered["residual_log_vs_top_e"] ** 2)))

        origin = origins[origins["mechanism_id"] == mechanism_id].iloc[0]

        endpoint_log_error_abs = abs(math.log(endpoint / D_TARGET)) if endpoint > 0 else np.inf

        native_score_prior = float(origin["native_score_prior"])
        score = native_score_prior

        if endpoint_log_error_abs < 0.001:
            score += 6.0
        elif endpoint_log_error_abs < 0.01:
            score += 5.0
        elif endpoint_log_error_abs < 0.03:
            score += 4.0
        elif endpoint_log_error_abs < 0.1:
            score += 3.0
        elif endpoint_log_error_abs < 0.25:
            score += 2.0
        elif endpoint_log_error_abs < 0.5:
            score += 1.0

        if rmse_D < 0.60:
            score += 3.0
        elif rmse_D < 0.70:
            score += 2.0
        elif rmse_D < 0.85:
            score += 1.0

        if bool(origin["uses_D_to_define"]):
            score -= 12.0
        if "control" in str(origin["native_status"]):
            score -= 2.0
        if "null" in str(origin["mechanism_family"]):
            score -= 1.0

        rows.append({
            "mechanism_id": mechanism_id,
            "mechanism_family": origin["mechanism_family"],
            "native_status": origin["native_status"],
            "uses_D_to_define": bool(origin["uses_D_to_define"]),
            "mechanical_reading": origin["mechanical_reading"],
            "closed_form_tax_hint": origin["closed_form_tax_hint"],
            "native_score_prior": native_score_prior,
            "shares_normalized": origin["shares_normalized"],
            "p_high": float(origin["p_high"]),
            "p_low": float(origin["p_low"]),
            "imbalance": float(origin["imbalance"]),
            "N_eff": float(origin["N_eff"]),
            "amplitude_tax": float(origin["amplitude_tax"]),
            "c_ln2": float(origin["c_ln2"]),
            "L_eff": float(origin["L_eff"]),
            "endpoint_rho2": endpoint,
            "endpoint_vs_D_factor": endpoint / D_TARGET,
            "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
            "endpoint_log_error_vs_D_abs": endpoint_log_error_abs,
            "span_max_over_min": span,
            "rmse_log_vs_D_target": rmse_D,
            "rmse_log_vs_top_e_target": rmse_top,
            "distance_to_required_p_high": float(origin["distance_to_required_p_high"]),
            "distance_to_equal_split": float(origin["distance_to_equal_split"]),
            "distance_to_3_to_2": float(origin["distance_to_3_to_2"]),
            "combined_score": score,
        })

    return pd.DataFrame(rows).sort_values("combined_score", ascending=False)


def derivation_gate_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "gate": "compact_formula",
            "test": "M_i = G_i exp(L_eff u_i)",
            "status": "PRESERVED",
            "boundary": "D-scale lane only, not full mass spectrum."
        },
        {
            "gate": "opus_3_support_2_phase_count",
            "test": "3 spatial support coordinates and 2 phase closure completions define 3:2 without D.",
            "status": "CONDITIONAL_PASS",
            "boundary": "Requires proving these five components group into two amplitude channels."
        },
        {
            "gate": "grouping_null",
            "test": "Treat 3+2 components as five equal independent channels instead of grouped 3:2.",
            "status": "CONTROL",
            "boundary": "If five-channel control wins, Opus grouping weakens."
        },
        {
            "gate": "spinor_frame_bridge",
            "test": "Compare 4π:2π and sqrt(4π):sqrt(2π) spinor-frame splits.",
            "status": "TESTED",
            "boundary": "Can support or compete with Opus 3:2."
        },
        {
            "gate": "D_independence",
            "test": "Candidate shares must be defined before D comparison.",
            "status": "PASS_FOR_OPUS_3TO2",
            "boundary": "D still used for diagnostic scoring."
        },
        {
            "gate": "top_e",
            "test": "Top/e closure.",
            "status": "OPEN",
            "boundary": "No top/e closure claimed."
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need action-level derivation and prediction nulls."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "The compact D-scale lane is M_i = G_i exp(L_eff u_i).",
            "status": "PRESERVED",
            "boundary": "D-scale lane only."
        },
        {
            "category": "Preserved",
            "claim": "Opus 3 spatial : 2 phase grouping gives the near-exact 3:2 split without using D.",
            "status": "CONDITIONAL_PASS",
            "boundary": "Only if grouping into two amplitude channels is action-derived."
        },
        {
            "category": "Observed",
            "claim": "For 3:2, amplitude tax is 1/2 ln(25/13), not exactly 1/2 ln2.",
            "status": "LOCKED_NUMERIC_IDENTITY",
            "boundary": "This sharpens the coefficient."
        },
        {
            "category": "Observed",
            "claim": "Equal sqrt2 remains clean but less endpoint-precise than 3:2.",
            "status": "LIVE_CANDIDATE",
            "boundary": "May be lower-order approximation."
        },
        {
            "category": "Rejected",
            "claim": "R210M proves the mass hierarchy.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no action-level proof."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def pairwise_focus(summary: pd.DataFrame) -> pd.DataFrame:
    focus = [
        "opus_3_spatial_2_phase_grouped",
        "opus_5_components_ungrouped",
        "opus_sqrt_count_3_2",
        "equal_two_channel_sqrt2",
        "spinor_frame_sqrt_4pi_2pi_split",
        "spinor_frame_4pi_2pi_load_split",
    ]

    rows = []

    for a in focus:
        for b in focus:
            if a >= b:
                continue

            ra = summary[summary["mechanism_id"] == a]
            rb = summary[summary["mechanism_id"] == b]

            if len(ra) == 0 or len(rb) == 0:
                continue

            xa = ra.iloc[0]
            xb = rb.iloc[0]

            rows.append({
                "mechanism_a": a,
                "mechanism_b": b,
                "delta_endpoint_log_error_abs_a_minus_b": float(xa["endpoint_log_error_vs_D_abs"] - xb["endpoint_log_error_vs_D_abs"]),
                "delta_rmse_D_a_minus_b": float(xa["rmse_log_vs_D_target"] - xb["rmse_log_vs_D_target"]),
                "delta_combined_score_a_minus_b": float(xa["combined_score"] - xb["combined_score"]),
            })

    return pd.DataFrame(rows)


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def build_report(
    created_utc: str,
    verdict: str,
    required_split: dict,
    opus_row: pd.Series,
    equal_row: pd.Series,
    sqrt_frame_row: pd.Series,
    best_summary: pd.DataFrame,
    pairwise: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R210M — 3:2 Support Count and Spinor-Frame Origin Gate

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R210M tests Opus's 3 spatial support : 2 phase closure decomposition together with the spinor-frame alternatives.

Compact formula:
M_i = G_i * exp(L_eff * u_i)

Coefficient:
L_eff = 3pi - amplitude_tax

Amplitude tax:
N_eff = 1 / sum(p_a^2)
amplitude_tax = 1/2 ln(N_eff)

Opus grouped 3:2:
shares = 3:2
p = 3/5 and 2/5
N_eff = 25/13
amplitude_tax = 1/2 ln(25/13)
L_eff = 3pi - 1/2 ln(25/13)

D-required endpoint split:
{json.dumps(json_safe(required_split), indent=2)}

Opus 3:2 result:
{opus_row.to_string()}

Equal two-channel sqrt2 result:
{equal_row.to_string()}

Spinor-frame sqrt(4pi):sqrt(2pi) result:
{sqrt_frame_row.to_string()}

Best mechanism summary:
{best_summary.to_string(index=False)}

Pairwise focus:
{pairwise.to_string(index=False)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
Opus's 3 spatial : 2 phase channel-count hypothesis survives the numerical gate.

The coefficient is not exactly 3pi - 1/2 ln2.
It is sharper:

L_eff = 3pi - 1/2 ln(25/13)

This is equivalent to a grouped 3:2 amplitude participation tax.

The five-component ungrouped null is important:
if the three spatial and two phase components are treated as five equal independent channels, the tax becomes 1/2 ln5, which is too large for the D-scale endpoint. Therefore the key open premise is grouping, not counting.

Ruling:
No V12.13 promotion.

Next recommended run:
R211M — Action-Level 3:2 Grouping Proof Attempt

Question:
Can the action force three spatial support coordinates into one settlement-support channel and two phase closures into one refresh channel?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    modes = build_modes()
    geometry = add_geometry_signal(modes)
    target_geometry = add_targets(geometry)

    geometry_endpoint = float(target_geometry.sort_values("rho_float").iloc[-1]["G_i_geometry_ratio"])
    required_split = required_D_split_from_geometry(geometry_endpoint)

    origins = support_origin_candidates(geometry_endpoint)
    outputs = evaluate_origin_models(target_geometry, origins)
    model_summary = summarize_models(outputs, origins)
    pairwise = pairwise_focus(model_summary)

    gates = derivation_gate_matrix()
    claims = claim_boundary()

    opus_row = model_summary[model_summary["mechanism_id"] == "opus_3_spatial_2_phase_grouped"].iloc[0]
    equal_row = model_summary[model_summary["mechanism_id"] == "equal_two_channel_sqrt2"].iloc[0]
    sqrt_frame_row = model_summary[model_summary["mechanism_id"] == "spinor_frame_sqrt_4pi_2pi_split"].iloc[0]
    ungrouped_row = model_summary[model_summary["mechanism_id"] == "opus_5_components_ungrouped"].iloc[0]

    best_summary = model_summary.head(12).copy()

    verdict = (
        "PARTIAL_PASS_OPUS_3_SPATIAL_2_PHASE_GROUPING_SURVIVES_NUMERIC_GATE_"
        "L_EFF_SHARPENED_TO_3PI_MINUS_HALF_LN_25_OVER_13_"
        "GROUPING_PREMISE_NOT_ACTION_PROVEN_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "compact_formula": "M_i = G_i * exp(L_eff * u_i)",
        "candidate_law": "L_eff = 3*pi - 0.5*ln(25/13)",
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "three_pi": THREE_PI,
            "ln2": LN2,
            "sqrt2": SQRT2,
            "three_pi_minus_half_ln2": THREE_PI - 0.5 * LN2,
            "three_pi_minus_half_ln_25_over_13": THREE_PI - 0.5 * math.log(25.0 / 13.0),
            "half_ln_25_over_13": 0.5 * math.log(25.0 / 13.0),
            "N_eff_3_to_2": 25.0 / 13.0,
            "K_req_half": HALF_K_REQ,
            "p_D": P_D,
            "p_top": P_TOP,
        },
        "D_required_endpoint_split": required_split,
        "opus_3_spatial_2_phase_grouped_result": opus_row.to_dict(),
        "opus_5_component_ungrouped_null_result": ungrouped_row.to_dict(),
        "equal_two_channel_sqrt2_result": equal_row.to_dict(),
        "spinor_frame_sqrt_4pi_2pi_result": sqrt_frame_row.to_dict(),
        "best_mechanisms": best_summary.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R211M - Action-Level 3:2 Grouping Proof Attempt",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R210M_mechanism_summary.csv",
            "tables/R210M_pairwise_focus.csv",
            "Any traceback if the run failed."
        ],
    }

    modes.to_csv(tables / "R210M_mode_geometry_inputs.csv", index=False)
    geometry.to_csv(tables / "R210M_geometry_signal.csv", index=False)
    target_geometry.to_csv(tables / "R210M_target_geometry.csv", index=False)
    origins.to_csv(tables / "R210M_support_origin_candidates.csv", index=False)
    outputs.to_csv(tables / "R210M_origin_model_outputs.csv", index=False)
    model_summary.to_csv(tables / "R210M_mechanism_summary.csv", index=False)
    pairwise.to_csv(tables / "R210M_pairwise_focus.csv", index=False)
    gates.to_csv(tables / "R210M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R210M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        required_split=required_split,
        opus_row=opus_row,
        equal_row=equal_row,
        sqrt_frame_row=sqrt_frame_row,
        best_summary=best_summary,
        pairwise=pairwise,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
