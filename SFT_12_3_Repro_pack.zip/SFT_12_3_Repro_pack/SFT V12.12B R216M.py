#!/usr/bin/env python3
"""
SFT V12.12B R216M — Master-Action Canonical Normalization Patch Attempt

Purpose:
    R215M showed that canonical equal per-component normalization is the
    lead native choice:

        k_space / k_phase = 1

    and that the D-required value is only about +0.346% away.

    R216M stops scanning and writes the actual master-action patch candidate:

        dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2

    where:
        X_i      = spatial support coordinates in local support-radius units
        Phi_a    = phase closure coordinates in closure-cycle units

    This makes the 3+2 metric canonical:
        three spatial support components
        two phase refresh components

    Then the sector traces are:
        Tr(P_space) = 3
        Tr(P_phase) = 2

    and the amplitude tax is:
        N_eff = 25/13
        L_eff = 3π - 1/2 ln(25/13)

Critical distinction:
    Raw radians are not the canonical phase variables.
    Phase closure coordinates must be cycle-normalized:
        Phi_spinor = phi_spinor / 4π
        Phi_frame  = phi_frame  / 2π

    Otherwise the 4π and 2π closure periods are double-counted as metric
    weights instead of being treated as closure-cycle coordinates.

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - no V12.13 promotion inside this run

Outputs:
    SFT_V12_12B_R216M_Master_Action_Canonical_Normalization_Patch_Attempt/
        report.md
        patch_candidate.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R216M.py

    SFT_V12_12B_R216M_Master_Action_Canonical_Normalization_Patch_Attempt_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R216M_Master_Action_Canonical_Normalization_Patch_Attempt"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

# Compact lane endpoint geometry factor from the current D-scale route.
G_ENDPOINT_RHO2 = 2.0


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def amplitude_tax_from_shares(shares: list[float]) -> dict:
    arr = np.array(shares, dtype=float)
    arr = arr[arr > 0]

    if arr.size == 0:
        return {
            "shares_normalized": "()",
            "N_eff": 1.0,
            "amplitude_tax": 0.0,
            "c_ln2": 0.0,
            "p_high": None,
            "p_low": None,
            "participation_sum_squares": 1.0,
        }

    arr = arr / np.sum(arr)
    sumsq = float(np.sum(arr * arr))
    N_eff = 1.0 / sumsq
    amplitude_tax = 0.5 * math.log(N_eff)

    sorted_arr = sorted(arr.tolist(), reverse=True)

    return {
        "shares_normalized": "(" + ",".join(f"{x:.12g}" for x in arr.tolist()) + ")",
        "N_eff": N_eff,
        "amplitude_tax": amplitude_tax,
        "c_ln2": amplitude_tax / LN2,
        "p_high": sorted_arr[0],
        "p_low": sorted_arr[1] if len(sorted_arr) > 1 else 0.0,
        "participation_sum_squares": sumsq,
    }


def endpoint_from_L(L_eff: float, G_endpoint: float = G_ENDPOINT_RHO2) -> float:
    return G_endpoint * math.exp(L_eff)


def endpoint_record(label: str, shares: list[float], status: str, native_prior: float, uses_D_to_define: bool) -> dict:
    tax = amplitude_tax_from_shares(shares)
    L_eff = THREE_PI - tax["amplitude_tax"]
    endpoint = endpoint_from_L(L_eff)

    rec = {
        "model_id": label,
        "status": status,
        "native_prior": native_prior,
        "uses_D_to_define": uses_D_to_define,
        "shares_input": "(" + ",".join(f"{x:.12g}" for x in shares) + ")",
        "L_eff": L_eff,
        "endpoint_rho2": endpoint,
        "endpoint_vs_D_factor": endpoint / D_TARGET,
        "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
        "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
    }
    rec.update(tax)

    score = native_prior
    err = rec["endpoint_log_error_vs_D_abs"]

    if err < 0.001:
        score += 6.0
    elif err < 0.01:
        score += 5.0
    elif err < 0.03:
        score += 4.0
    elif err < 0.1:
        score += 3.0
    elif err < 0.5:
        score += 1.0

    if uses_D_to_define:
        score -= 12.0
    if "null" in status.lower():
        score -= 4.0
    if "control" in status.lower():
        score -= 2.0

    rec["combined_score"] = score
    return rec


def required_D_k() -> dict:
    L_required = math.log(D_TARGET / G_ENDPOINT_RHO2)
    tax_required = THREE_PI - L_required
    N_eff_required = math.exp(2.0 * tax_required)
    c_required = tax_required / LN2

    if 1.0 <= N_eff_required <= 2.0:
        sumsq = 1.0 / N_eff_required
        y2 = max(0.0, (sumsq - 0.5) / 2.0)
        y = math.sqrt(y2)
        p_high = 0.5 + y
        p_low = 0.5 - y
        k_required = (2.0 * p_high) / (3.0 * (1.0 - p_high))
    else:
        p_high = None
        p_low = None
        k_required = None

    return {
        "L_required_endpoint": L_required,
        "tax_required": tax_required,
        "c_required_ln2_units": c_required,
        "N_eff_required": N_eff_required,
        "p_high_required": p_high,
        "p_low_required": p_low,
        "k_space_over_k_phase_required": k_required,
        "k_required_minus_1": None if k_required is None else k_required - 1.0,
        "k_required_percent_offset_from_equal": None if k_required is None else 100.0 * (k_required - 1.0),
    }


def projector_matrices() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    P_space = np.diag([1.0, 1.0, 1.0, 0.0, 0.0])
    P_phase = np.diag([0.0, 0.0, 0.0, 1.0, 1.0])
    I5 = np.eye(5)
    return P_space, P_phase, I5


def metric_audit() -> pd.DataFrame:
    P_space, P_phase, I5 = projector_matrices()

    metrics = []

    # Canonical patch metric.
    M_canon = np.eye(5)
    metrics.append((
        "canonical_cycle_normalized_3plus2_metric",
        M_canon,
        "lead patch metric: dQ^2 = sum dX_i^2 + sum dPhi_a^2",
        "PATCH_CANDIDATE"
    ))

    # D-exact diagnostic metric.
    req = required_D_k()
    k_req = req["k_space_over_k_phase_required"]
    M_d = np.diag([k_req, k_req, k_req, 1.0, 1.0])
    metrics.append((
        "D_exact_diagnostic_metric",
        M_d,
        "diagnostic-only metric using D-required k",
        "REJECT_AS_DERIVATION"
    ))

    # Raw-radian style metric/control: phase closures weighted by raw periods.
    M_raw_phase = np.diag([1.0, 1.0, 1.0, FOUR_PI, TWO_PI])
    metrics.append((
        "raw_radian_phase_period_metric_control",
        M_raw_phase,
        "control: treats raw 4pi and 2pi phase periods as metric weights, likely double-counts closure",
        "CONTROL"
    ))

    # Unequal but close spatial lift.
    M_close = np.diag([1.005, 1.005, 1.005, 1.0, 1.0])
    metrics.append((
        "nearby_half_percent_spatial_lift_control",
        M_close,
        "control: close to exact D but not native unless derived",
        "CONTROL"
    ))

    rows = []

    for name, M, reading, status in metrics:
        space_trace = float(np.trace(P_space @ M @ P_space))
        phase_trace = float(np.trace(P_phase @ M @ P_phase))
        cross_norm = float(np.linalg.norm(P_space @ M @ P_phase) + np.linalg.norm(P_phase @ M @ P_space))

        grouped = endpoint_record(
            label=name + "_grouped_trace",
            shares=[abs(space_trace), abs(phase_trace)],
            status=status,
            native_prior=10.0 if name == "canonical_cycle_normalized_3plus2_metric" else 2.0,
            uses_D_to_define=name == "D_exact_diagnostic_metric",
        )

        eigvals = np.linalg.eigvalsh(M)
        eigen = endpoint_record(
            label=name + "_eigenchannel",
            shares=[abs(float(v)) for v in eigvals if abs(float(v)) > 1e-12],
            status="EIGENCHANNEL_CONTROL",
            native_prior=1.0,
            uses_D_to_define=name == "D_exact_diagnostic_metric",
        )

        rows.append({
            "metric_id": name,
            "interpretation": reading,
            "metric_status": status,
            "space_trace": space_trace,
            "phase_trace": phase_trace,
            "cross_norm": cross_norm,
            "commutes_with_P_space": bool(np.linalg.norm(M @ P_space - P_space @ M) < 1e-12),
            "commutes_with_P_phase": bool(np.linalg.norm(M @ P_phase - P_phase @ M) < 1e-12),
            "trace_grouped_endpoint_vs_D": grouped["endpoint_vs_D_factor"],
            "trace_grouped_log_error": grouped["endpoint_log_error_vs_D_abs"],
            "trace_grouped_N_eff": grouped["N_eff"],
            "trace_grouped_L_eff": grouped["L_eff"],
            "eigenchannel_endpoint_vs_D": eigen["endpoint_vs_D_factor"],
            "eigenchannel_log_error": eigen["endpoint_log_error_vs_D_abs"],
            "eigenchannel_N_eff": eigen["N_eff"],
            "eigenchannel_L_eff": eigen["L_eff"],
            "eigenvalues": "(" + ",".join(f"{float(v):.12g}" for v in eigvals.tolist()) + ")",
        })

    return pd.DataFrame(rows)


def candidate_scorecard() -> pd.DataFrame:
    req = required_D_k()
    k_req = req["k_space_over_k_phase_required"]

    p_sqrt = math.sqrt(FOUR_PI) / (math.sqrt(FOUR_PI) + math.sqrt(TWO_PI))
    k_sqrt = (2.0 * p_sqrt) / (3.0 * (1.0 - p_sqrt))

    p_direct = FOUR_PI / (FOUR_PI + TWO_PI)
    k_direct = (2.0 * p_direct) / (3.0 * (1.0 - p_direct))

    candidates = [
        endpoint_record(
            "canonical_cycle_normalized_patch",
            [3.0, 2.0],
            "LEAD_PATCH_CANDIDATE",
            11.0,
            False,
        ),
        endpoint_record(
            "D_exact_k_diagnostic",
            [3.0 * k_req, 2.0],
            "DIAGNOSTIC_ONLY_USES_D",
            -8.0,
            True,
        ),
        endpoint_record(
            "nearby_k_1p005_control",
            [3.0 * 1.005, 2.0],
            "CONTROL_CLOSE_BUT_NOT_NATIVE",
            2.0,
            False,
        ),
        endpoint_record(
            "spinor_frame_sqrt_4pi_2pi_bridge",
            [math.sqrt(FOUR_PI), math.sqrt(TWO_PI)],
            "SUPPORTIVE_BRIDGE",
            8.0,
            False,
        ),
        endpoint_record(
            "spinor_frame_direct_4pi_2pi_bridge",
            [FOUR_PI, TWO_PI],
            "SUPPORTIVE_BUT_LESS_EXACT_BRIDGE",
            6.5,
            False,
        ),
        endpoint_record(
            "raw_radian_phase_period_metric_control_grouped",
            [3.0, FOUR_PI + TWO_PI],
            "CONTROL_RAW_PHASE_PERIOD_DOUBLE_COUNTS_CLOSURE",
            1.0,
            False,
        ),
        endpoint_record(
            "five_independent_eigenchannel_null",
            [1.0, 1.0, 1.0, 1.0, 1.0],
            "NULL_WRONG_BOOKKEEPING",
            1.0,
            False,
        ),
        endpoint_record(
            "equal_two_channel_sqrt2",
            [1.0, 1.0],
            "LOWER_ORDER_BINARY_APPROXIMATION",
            6.0,
            False,
        ),
    ]

    for rec in candidates:
        if rec["model_id"] == "D_exact_k_diagnostic":
            rec["k_space_over_k_phase"] = k_req
        elif rec["model_id"] == "nearby_k_1p005_control":
            rec["k_space_over_k_phase"] = 1.005
        elif rec["model_id"] == "spinor_frame_sqrt_4pi_2pi_bridge":
            rec["k_space_over_k_phase_equivalent"] = k_sqrt
        elif rec["model_id"] == "spinor_frame_direct_4pi_2pi_bridge":
            rec["k_space_over_k_phase_equivalent"] = k_direct
        else:
            rec["k_space_over_k_phase"] = None

    return pd.DataFrame(candidates).sort_values("combined_score", ascending=False)


def patch_premise_matrix() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "premise": "dimensionless_spatial_support_coordinates",
            "patch_statement": "X_i = x_i / r_*",
            "status": "CONDITIONAL_PASS",
            "boundary": "Requires defining r_* as local support/closure radius in the master action."
        },
        {
            "premise": "cycle_normalized_phase_coordinates",
            "patch_statement": "Phi_spinor = phi_spinor / 4pi and Phi_frame = phi_frame / 2pi",
            "status": "PASS_PATCH",
            "boundary": "Treats phase closures as completed cycles, not raw radians."
        },
        {
            "premise": "canonical_3plus2_metric",
            "patch_statement": "dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2",
            "status": "PASS_PATCH_CANDIDATE",
            "boundary": "Patch statement, not yet independently derived from deeper action."
        },
        {
            "premise": "protected_projectors",
            "patch_statement": "P_space and P_phase are symmetry-protected projectors on Q-space.",
            "status": "SUPPORTED_BY_R214",
            "boundary": "Depends on incommensurable spatial/phase bookkeeping."
        },
        {
            "premise": "sector_trace_rule",
            "patch_statement": "W_space = Tr(P_space), W_phase = Tr(P_phase)",
            "status": "PASS_PATCH_CANDIDATE",
            "boundary": "Still needs final variational derivation."
        },
        {
            "premise": "amplitude_tax",
            "patch_statement": "N_eff = 1 / [(W_space/W)^2 + (W_phase/W)^2]",
            "status": "PRESERVED",
            "boundary": "D-scale lane only."
        },
        {
            "premise": "half_action_load",
            "patch_statement": "L_eff = 3pi - 1/2 ln(N_eff)",
            "status": "PRESERVED",
            "boundary": "Half-action load route remains candidate."
        },
        {
            "premise": "V12_13",
            "patch_statement": "Promote final theory version.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no prediction/null suite."
        },
    ])


def normalization_scan() -> pd.DataFrame:
    rows = []

    for k in np.linspace(0.85, 1.15, 601):
        shares = [3.0 * float(k), 2.0]
        rec = endpoint_record(
            "scan_k",
            shares,
            "SCAN",
            0.0,
            False,
        )
        rec["k_space_over_k_phase"] = float(k)
        rows.append(rec)

    return pd.DataFrame(rows).sort_values("endpoint_log_error_vs_D_abs")


def gate_matrix(req: dict, metric_df: pd.DataFrame, scorecard: pd.DataFrame, scan: pd.DataFrame) -> pd.DataFrame:
    canonical = scorecard[scorecard["model_id"] == "canonical_cycle_normalized_patch"].iloc[0]
    raw_phase = scorecard[scorecard["model_id"] == "raw_radian_phase_period_metric_control_grouped"].iloc[0]
    null = scorecard[scorecard["model_id"] == "five_independent_eigenchannel_null"].iloc[0]

    tol_001 = scan[scan["endpoint_log_error_vs_D_abs"] <= 0.001]
    tol_01 = scan[scan["endpoint_log_error_vs_D_abs"] <= 0.01]

    band_001 = {
        "count": int(len(tol_001)),
        "min_k": None if len(tol_001) == 0 else float(tol_001["k_space_over_k_phase"].min()),
        "max_k": None if len(tol_001) == 0 else float(tol_001["k_space_over_k_phase"].max()),
    }

    band_01 = {
        "count": int(len(tol_01)),
        "min_k": None if len(tol_01) == 0 else float(tol_01["k_space_over_k_phase"].min()),
        "max_k": None if len(tol_01) == 0 else float(tol_01["k_space_over_k_phase"].max()),
    }

    return pd.DataFrame([
        {
            "gate": "patch_written",
            "test": "Canonical 3+2 metric is explicitly written.",
            "status": "PASS_PATCH_WRITTEN",
            "boundary": "Patch candidate, not final derivation."
        },
        {
            "gate": "cycle_normalized_phase",
            "test": "Phase variables are normalized by closure periods rather than raw radians.",
            "status": "PASS_PATCH_RULE",
            "boundary": "Prevents double-counting 4pi/2pi closure periods as metric weights."
        },
        {
            "gate": "canonical_endpoint",
            "test": "Canonical patch endpoint.",
            "status": "PASS_DIAGNOSTIC",
            "boundary": f"endpoint_vs_D={canonical['endpoint_vs_D_factor']}"
        },
        {
            "gate": "D_required_k",
            "test": "D-exact k offset from canonical k=1.",
            "status": "VERY_CLOSE_DIAGNOSTIC",
            "boundary": f"k_required={req['k_space_over_k_phase_required']}, percent_offset={req['k_required_percent_offset_from_equal']}"
        },
        {
            "gate": "raw_radian_control",
            "test": "Raw phase periods treated as metric weights.",
            "status": "FAILS_AS_NATIVE_PATCH",
            "boundary": f"endpoint_vs_D={raw_phase['endpoint_vs_D_factor']}; double-counts closure periods."
        },
        {
            "gate": "five_eigenchannel_null",
            "test": "Five independent eigenchannels.",
            "status": "FAILS",
            "boundary": f"endpoint_vs_D={null['endpoint_vs_D_factor']}"
        },
        {
            "gate": "tolerance_band_0p001",
            "test": "k band with log error <= 0.001.",
            "status": "PASS_BAND_EXISTS" if band_001["count"] > 0 else "NO_BAND",
            "boundary": str(band_001)
        },
        {
            "gate": "tolerance_band_0p01",
            "test": "k band with log error <= 0.01.",
            "status": "PASS_BAND_EXISTS" if band_01["count"] > 0 else "NO_BAND",
            "boundary": str(band_01)
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Patch written, but species map/top-e/prediction suite still open."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "The compact D-scale lane remains M_i = G_i exp(L_eff u_i).",
            "status": "PRESERVED",
            "boundary": "D-scale lane only."
        },
        {
            "category": "Preserved",
            "claim": "The canonical 3+2 metric patch is explicitly written.",
            "status": "PATCH_CANDIDATE",
            "boundary": "Not yet final master-action derivation."
        },
        {
            "category": "Preserved",
            "claim": "Cycle-normalized phase variables prevent raw-radian double counting.",
            "status": "PATCH_CANDIDATE",
            "boundary": "Requires accepting closure cycles as canonical phase coordinates."
        },
        {
            "category": "Observed",
            "claim": "The canonical patch gives the 3:2 trace coefficient and hits D to 0.032%.",
            "status": "DIAGNOSTIC_PASS",
            "boundary": "D used only after writing native patch."
        },
        {
            "category": "Open",
            "claim": "The patch is derived by variation from the full master action.",
            "status": "OPEN",
            "boundary": "Still needs formal variational derivation."
        },
        {
            "category": "Rejected",
            "claim": "R216M proves the full particle hierarchy.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no prediction/null suite."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def patch_candidate_text(created_utc: str) -> str:
    return f"""
# R216M Master-Action Canonical Normalization Patch Candidate

Generated: {created_utc}

This is a patch candidate, not a final promoted action.

## Canonical coordinates

Let the local settlement-support coordinate be written in dimensionless form:

    X_i = x_i / r_*

where r_* is the local support / closure-radius unit.

Let the phase closure coordinates be written as completed-cycle coordinates:

    Phi_spinor = phi_spinor / 4pi
    Phi_frame  = phi_frame  / 2pi

The point of this normalization is that phase variables enter as closure counts, not raw radians.

## Canonical 3+2 metric

Define the local audit vector:

    Q = (X_1, X_2, X_3 ; Phi_spinor, Phi_frame)

with canonical metric:

    dQ^2 = dX_1^2 + dX_2^2 + dX_3^2 + dPhi_spinor^2 + dPhi_frame^2

Equivalently:

    dQ^T dQ = sum_i dX_i^2 + sum_a dPhi_a^2

## Protected projectors

Let P_space project onto the first three entries of Q.
Let P_phase project onto the last two entries of Q.

Then:

    Tr(P_space) = 3
    Tr(P_phase) = 2

The two projectors are protected by the incommensurability of spatial support and phase closure.

## Amplitude tax

Using sector trace weights:

    W_space = 3
    W_phase = 2
    W = 5

    N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13

The half-action feedback coefficient becomes:

    L_eff = 3pi - 1/2 ln(25/13)

The D-scale lane is:

    M_i = G_i exp(L_eff u_i)

## Claim boundary

This patch writes the missing canonical normalization statement.
It does not yet prove the patch from a deeper variation of the full master action.
It does not supply species assignments.
It does not close the top/e hierarchy.
It does not promote V12.13.
"""


def build_report(
    created_utc: str,
    verdict: str,
    req: dict,
    scorecard: pd.DataFrame,
    metric_df: pd.DataFrame,
    premises: pd.DataFrame,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R216M — Master-Action Canonical Normalization Patch Attempt

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R216M writes the missing canonical 3+2 metric patch.

Lead compact lane:
M_i = G_i exp(L_eff u_i)

Patch coefficient:
L_eff = 3pi - 1/2 ln(25/13)

D-required normalization diagnostic:
{json.dumps(json_safe(req), indent=2)}

Candidate scorecard:
{scorecard.to_string(index=False)}

Metric audit:
{metric_df.to_string(index=False)}

Patch premise matrix:
{premises.to_string(index=False)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
R216M upgrades the canonical-normalization lane from a supported premise to an explicit patch candidate.

The essential move is to normalize phase variables by closure periods:
Phi_spinor = phi_spinor / 4pi and Phi_frame = phi_frame / 2pi.
This makes phase entries completed-cycle coordinates rather than raw radians.

Then the canonical audit metric is:
dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2.

That gives a protected 3+2 identity metric, sector traces 3 and 2, N_eff = 25/13, and L_eff = 3pi - 1/2 ln(25/13).

The raw-radian control is rejected as a native patch because it double-counts closure periods as metric weights.

Ruling:
No V12.13 promotion.

Next recommended run:
R217M — Variational Trace-Weight Derivation Attempt

Question:
Can the canonical patch be obtained from a quadratic variation of the master action, so that the sector trace rule appears as a variational Hessian/second-variation result rather than a postulated metric?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    req = required_D_k()
    scorecard = candidate_scorecard()
    metric_df = metric_audit()
    premises = patch_premise_matrix()
    scan = normalization_scan()
    gates = gate_matrix(req, metric_df, scorecard, scan)
    claims = claim_boundary()

    verdict = (
        "PARTIAL_PASS_MASTER_ACTION_CANONICAL_3PLUS2_METRIC_PATCH_WRITTEN_"
        "CYCLE_NORMALIZED_PHASE_COORDINATES_PROTECT_EQUAL_UNIT_WEIGHTING_"
        "RAW_RADIAN_PHASE_PERIOD_CONTROL_REJECTED_AS_DOUBLE_COUNTING_"
        "VARIATIONAL_DERIVATION_STILL_OPEN_NO_V12_13"
    )

    canonical = scorecard[scorecard["model_id"] == "canonical_cycle_normalized_patch"].iloc[0].to_dict()
    raw_control = scorecard[scorecard["model_id"] == "raw_radian_phase_period_metric_control_grouped"].iloc[0].to_dict()
    null = scorecard[scorecard["model_id"] == "five_independent_eigenchannel_null"].iloc[0].to_dict()
    best_scan = scan.iloc[0].to_dict()

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "compact_formula": "M_i = G_i exp(L_eff u_i)",
        "candidate_law": "L_eff = 3*pi - 0.5*ln(25/13)",
        "canonical_patch": {
            "Q": "(X1, X2, X3 ; Phi_spinor, Phi_frame)",
            "X_i": "x_i / r_*",
            "Phi_spinor": "phi_spinor / 4*pi",
            "Phi_frame": "phi_frame / 2*pi",
            "metric": "dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2",
            "W_space": 3.0,
            "W_phase": 2.0,
            "N_eff": 25.0 / 13.0,
        },
        "D_required_normalization": req,
        "canonical_patch_result": canonical,
        "raw_radian_control_result": raw_control,
        "five_eigenchannel_null_result": null,
        "best_scan_result": best_scan,
        "scorecard": scorecard.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R217M - Variational Trace-Weight Derivation Attempt",
        "paste_back_to_chat": [
            "summary.json",
            "patch_candidate.md",
            "tables/R216M_candidate_scorecard.csv",
            "tables/R216M_metric_audit.csv",
            "tables/R216M_patch_premise_matrix.csv",
            "Any traceback if the run failed."
        ],
    }

    scorecard.to_csv(tables / "R216M_candidate_scorecard.csv", index=False)
    metric_df.to_csv(tables / "R216M_metric_audit.csv", index=False)
    premises.to_csv(tables / "R216M_patch_premise_matrix.csv", index=False)
    scan.to_csv(tables / "R216M_normalization_scan.csv", index=False)
    gates.to_csv(tables / "R216M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R216M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        req=req,
        scorecard=scorecard,
        metric_df=metric_df,
        premises=premises,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "patch_candidate.md").write_text(patch_candidate_text(created_utc), encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
