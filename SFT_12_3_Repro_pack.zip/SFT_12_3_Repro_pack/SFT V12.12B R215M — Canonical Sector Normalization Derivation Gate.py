#!/usr/bin/env python3
"""
SFT V12.12B R215M — Canonical Sector Normalization Derivation Gate

Purpose:
    R214M supported trace protection:
        spatial support and phase closure are incommensurable sectors,
        protected by independent symmetry/covariance bookkeeping.

    The remaining structural question is:

        Why should each spatial-support component and each phase-refresh
        component carry the same canonical per-component weight?

    R215M tests whether the native equal-unit normalization

        k_space / k_phase = 1

    is:
        1. structurally motivated,
        2. close to the D-required value,
        3. stable against small normalization drift,
        4. better than load-weighted / eigenchannel alternatives.

Lead compact lane:
    M_i = G_i * exp(L_eff * u_i)

Lead candidate:
    L_eff = 3π - 1/2 ln(25/13)

where:
    W_space = 3 * k_space
    W_phase = 2 * k_phase

For canonical equal per-component normalization:
    k_space = k_phase
    W_space : W_phase = 3 : 2
    N_eff = 25/13

Rules:
    - no species labels
    - no empirical mass table
    - D and top/e are diagnostic context only
    - no V12.13 promotion inside this run

Outputs:
    SFT_V12_12B_R215M_Canonical_Sector_Normalization_Derivation_Gate/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R215M.py

    SFT_V12_12B_R215M_Canonical_Sector_Normalization_Derivation_Gate_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_12B_R215M_Canonical_Sector_Normalization_Derivation_Gate"

D_TARGET = 17877.208689571427
TOP_E_TARGET = 339000.0
K_REQ = 18.890588898086865

LN2 = math.log(2.0)
TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

# From the R201-R214 compact lane: the rho=2 endpoint geometry factor is 2.
G_ENDPOINT_RHO2 = 2.0


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_manifest(root: Path, run_id: str, created_utc: str) -> dict:
    files = []

    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })

    manifest = {
        "run_id": run_id,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def amplitude_tax_from_shares(shares: list[float]) -> dict:
    arr = np.array(shares, dtype=float)
    arr = arr[arr > 0]

    if arr.size == 0:
        return {
            "shares_normalized": "()",
            "N_eff": 1.0,
            "amplitude_tax": 0.0,
            "c_ln2": 0.0,
            "p_high": None,
            "p_low": None,
            "participation_sum_squares": 1.0,
        }

    arr = arr / np.sum(arr)
    sumsq = float(np.sum(arr * arr))
    N_eff = 1.0 / sumsq
    amplitude_tax = 0.5 * math.log(N_eff)

    sorted_arr = sorted(arr.tolist(), reverse=True)

    return {
        "shares_normalized": "(" + ",".join(f"{x:.12g}" for x in arr.tolist()) + ")",
        "N_eff": N_eff,
        "amplitude_tax": amplitude_tax,
        "c_ln2": amplitude_tax / LN2,
        "p_high": sorted_arr[0],
        "p_low": sorted_arr[1] if len(sorted_arr) > 1 else 0.0,
        "participation_sum_squares": sumsq,
    }


def endpoint_from_L(L_eff: float, G_endpoint: float = G_ENDPOINT_RHO2) -> float:
    return G_endpoint * math.exp(L_eff)


def model_from_k_ratio(k_space_over_k_phase: float, label: str, native_prior: float, status: str, uses_D_to_define: bool) -> dict:
    k = float(k_space_over_k_phase)

    W_space = 3.0 * k
    W_phase = 2.0

    tax = amplitude_tax_from_shares([W_space, W_phase])
    L_eff = THREE_PI - tax["amplitude_tax"]
    endpoint = endpoint_from_L(L_eff)

    rec = {
        "model_id": label,
        "status": status,
        "uses_D_to_define": uses_D_to_define,
        "native_prior": native_prior,
        "k_space_over_k_phase": k,
        "W_space": W_space,
        "W_phase": W_phase,
        "L_eff": L_eff,
        "endpoint_rho2": endpoint,
        "endpoint_vs_D_factor": endpoint / D_TARGET,
        "endpoint_log_error_vs_D_abs": abs(math.log(endpoint / D_TARGET)),
        "endpoint_vs_top_e_factor": endpoint / TOP_E_TARGET,
    }
    rec.update(tax)
    return rec


def required_D_split_and_k() -> dict:
    L_required = math.log(D_TARGET / G_ENDPOINT_RHO2)
    tax_required = THREE_PI - L_required
    N_eff_required = math.exp(2.0 * tax_required)
    c_required = tax_required / LN2

    if 1.0 <= N_eff_required <= 2.0:
        sumsq = 1.0 / N_eff_required
        y2 = max(0.0, (sumsq - 0.5) / 2.0)
        y = math.sqrt(y2)
        p_high = 0.5 + y
        p_low = 0.5 - y
    else:
        p_high = None
        p_low = None

    if p_high is not None:
        # p_high = 3k / (3k + 2), solve for k.
        k_required = (2.0 * p_high) / (3.0 * (1.0 - p_high))
    else:
        k_required = None

    return {
        "L_required_endpoint": L_required,
        "tax_required": tax_required,
        "c_required_ln2_units": c_required,
        "N_eff_required": N_eff_required,
        "p_high_required": p_high,
        "p_low_required": p_low,
        "k_space_over_k_phase_required": k_required,
        "k_required_minus_1": None if k_required is None else k_required - 1.0,
        "k_required_percent_offset_from_equal": None if k_required is None else 100.0 * (k_required - 1.0),
    }


def candidate_normalizations(req: dict) -> pd.DataFrame:
    k_req = req["k_space_over_k_phase_required"]

    # Convert bridge p_high values into equivalent k ratio under p = 3k/(3k+2).
    p_sqrt_4pi_2pi = math.sqrt(FOUR_PI) / (math.sqrt(FOUR_PI) + math.sqrt(TWO_PI))
    k_sqrt_4pi_2pi = (2.0 * p_sqrt_4pi_2pi) / (3.0 * (1.0 - p_sqrt_4pi_2pi))

    p_direct_4pi_2pi = FOUR_PI / (FOUR_PI + TWO_PI)
    k_direct_4pi_2pi = (2.0 * p_direct_4pi_2pi) / (3.0 * (1.0 - p_direct_4pi_2pi))

    candidates = [
        model_from_k_ratio(
            1.0,
            "canonical_equal_per_component",
            10.0,
            "lead_native_candidate",
            False,
        ),
        model_from_k_ratio(
            k_req,
            "D_inferred_exact_k_diagnostic",
            -8.0,
            "diagnostic_only_uses_D",
            True,
        ),
        model_from_k_ratio(
            1.005,
            "nearby_half_percent_spatial_lift_control",
            2.0,
            "diagnostic_control",
            False,
        ),
        model_from_k_ratio(
            k_sqrt_4pi_2pi,
            "spinor_frame_sqrt_4pi_2pi_equivalent_k",
            8.0,
            "supportive_bridge",
            False,
        ),
        model_from_k_ratio(
            k_direct_4pi_2pi,
            "spinor_frame_direct_4pi_2pi_equivalent_k",
            6.5,
            "supportive_but_less_exact_bridge",
            False,
        ),
        model_from_k_ratio(
            2.0,
            "three_plus_one_support_tangent_k2",
            4.0,
            "3plus1_control",
            False,
        ),
        model_from_k_ratio(
            0.5,
            "phase_dominant_inverse_control",
            2.0,
            "control",
            False,
        ),
    ]

    rows = []
    for rec in candidates:
        score = float(rec["native_prior"])
        err = float(rec["endpoint_log_error_vs_D_abs"])

        if err < 0.001:
            score += 6.0
        elif err < 0.01:
            score += 5.0
        elif err < 0.03:
            score += 4.0
        elif err < 0.1:
            score += 3.0
        elif err < 0.5:
            score += 1.0

        if rec["uses_D_to_define"]:
            score -= 12.0
        if "control" in rec["status"]:
            score -= 2.0

        rec["combined_score"] = score
        rows.append(rec)

    return pd.DataFrame(rows).sort_values("combined_score", ascending=False)


def normalization_scan() -> pd.DataFrame:
    rows = []

    for k in np.linspace(0.75, 1.25, 501):
        rec = model_from_k_ratio(
            float(k),
            "scan_k",
            0.0,
            "scan",
            False,
        )
        rows.append(rec)

    return pd.DataFrame(rows).sort_values("endpoint_log_error_vs_D_abs")


def canonical_variable_dictionary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "sector": "spatial_support",
            "raw_variable": "x_i",
            "canonical_variable": "X_i = x_i / r_*",
            "dimension_after_normalization": "dimensionless",
            "count": 3,
            "normalization_claim": "spatial coordinates are measured in the local support radius / closure radius unit",
            "status": "conditional_native_candidate",
        },
        {
            "sector": "phase_refresh",
            "raw_variable": "phi_a",
            "canonical_variable": "Phi_a = phi_a",
            "dimension_after_normalization": "dimensionless radians / cycle count",
            "count": 2,
            "normalization_claim": "phase closures are already dimensionless cycle variables",
            "status": "native",
        },
        {
            "sector": "action_unit",
            "raw_variable": "delta A",
            "canonical_variable": "delta A / hbar",
            "dimension_after_normalization": "dimensionless action",
            "count": 1,
            "normalization_claim": "both support displacement and phase refresh must enter the solvency/action ledger in dimensionless action units",
            "status": "conditional_bridge",
        },
        {
            "sector": "where_how",
            "raw_variable": "spatial support plus phase refresh",
            "canonical_variable": "(X_1,X_2,X_3 ; Phi_spinor,Phi_frame)",
            "dimension_after_normalization": "dimensionless 3+2 audit vector",
            "count": 5,
            "normalization_claim": "once expressed in canonical ledger units, equal per-component weight is the minimal invariant metric",
            "status": "lead_normalization_route",
        },
    ])


def normalization_premise_matrix(req: dict) -> pd.DataFrame:
    return pd.DataFrame([
        {
            "premise": "dimensionless_canonicalization",
            "test": "Spatial variables can be normalized by local support radius while phase variables are dimensionless cycles.",
            "status": "PASS_FORMAL",
            "boundary": "Requires identifying the native SFT support radius r_*."
        },
        {
            "premise": "single_action_unit",
            "test": "Both sectors enter the solvency ledger in the same dimensionless action unit.",
            "status": "CONDITIONAL_PASS",
            "boundary": "Needs master-action statement, likely delta A / hbar or one-cycle write budget."
        },
        {
            "premise": "minimal_invariant_metric",
            "test": "After canonicalization, the natural metric on the 3+2 audit space is identity within each component.",
            "status": "CONDITIONAL_PASS",
            "boundary": "Symmetry allows equal weights but does not alone force them."
        },
        {
            "premise": "equal_normalization_matches_D_without_fit",
            "test": "k_space/k_phase=1 is native and lands close to D.",
            "status": "PASS_DIAGNOSTIC",
            "boundary": "D used only after the native k=1 law is written."
        },
        {
            "premise": "D_required_k_near_equal",
            "test": "D-required k is close to 1.",
            "status": "PASS_DIAGNOSTIC",
            "boundary": f"k_required = {req['k_space_over_k_phase_required']}, offset percent = {req['k_required_percent_offset_from_equal']}"
        },
        {
            "premise": "load_weighted_alternatives",
            "test": "4π/2π or sqrt(4π)/sqrt(2π) alternatives compete with equal canonical normalization.",
            "status": "TESTED_AS_BRIDGES",
            "boundary": "Bridge models support neighborhood but are not as clean as canonical equal unit metric."
        },
        {
            "premise": "final_action_derivation",
            "test": "Full master action explicitly derives the equal per-component normalization.",
            "status": "OPEN",
            "boundary": "This is not fully proven in R215."
        },
    ])


def gate_matrix(req: dict, scan: pd.DataFrame, candidates: pd.DataFrame) -> pd.DataFrame:
    tolerance_001 = scan[scan["endpoint_log_error_vs_D_abs"] <= 0.001]
    tolerance_01 = scan[scan["endpoint_log_error_vs_D_abs"] <= 0.01]

    equal_row = candidates[candidates["model_id"] == "canonical_equal_per_component"].iloc[0]
    d_row = candidates[candidates["model_id"] == "D_inferred_exact_k_diagnostic"].iloc[0]

    if len(tolerance_001) > 0:
        band_001 = {
            "min_k": float(tolerance_001["k_space_over_k_phase"].min()),
            "max_k": float(tolerance_001["k_space_over_k_phase"].max()),
            "count": int(len(tolerance_001)),
        }
    else:
        band_001 = {"min_k": None, "max_k": None, "count": 0}

    if len(tolerance_01) > 0:
        band_01 = {
            "min_k": float(tolerance_01["k_space_over_k_phase"].min()),
            "max_k": float(tolerance_01["k_space_over_k_phase"].max()),
            "count": int(len(tolerance_01)),
        }
    else:
        band_01 = {"min_k": None, "max_k": None, "count": 0}

    return pd.DataFrame([
        {
            "gate": "canonical_equal_metric",
            "test": "Does k_space/k_phase=1 give the lead 3:2 coefficient?",
            "status": "PASS",
            "boundary": f"endpoint_vs_D={equal_row['endpoint_vs_D_factor']}"
        },
        {
            "gate": "D_required_k",
            "test": "How far is D-required k from equal normalization?",
            "status": "VERY_CLOSE_DIAGNOSTIC",
            "boundary": f"k_required={req['k_space_over_k_phase_required']}, percent offset={req['k_required_percent_offset_from_equal']}"
        },
        {
            "gate": "normalization_tolerance_0p001",
            "test": "k band with endpoint log error <= 0.001.",
            "status": "PASS_BAND_EXISTS" if band_001["count"] > 0 else "NO_BAND",
            "boundary": str(band_001)
        },
        {
            "gate": "normalization_tolerance_0p01",
            "test": "k band with endpoint log error <= 0.01.",
            "status": "PASS_BAND_EXISTS" if band_01["count"] > 0 else "NO_BAND",
            "boundary": str(band_01)
        },
        {
            "gate": "bridge_models",
            "test": "Do spinor-frame alternatives remain supportive?",
            "status": "SUPPORTIVE",
            "boundary": "sqrt(4pi):sqrt(2pi) remains close but not as clean as canonical trace 3:2."
        },
        {
            "gate": "D_inferred_model",
            "test": "Exact D k is kept diagnostic-only.",
            "status": "REJECT_AS_DERIVATION",
            "boundary": f"diagnostic endpoint factor={d_row['endpoint_vs_D_factor']}"
        },
        {
            "gate": "V12_13",
            "test": "Promotion.",
            "status": "NO",
            "boundary": "Need explicit master-action normalization term and prediction/null tests."
        },
    ])


def claim_boundary() -> pd.DataFrame:
    return pd.DataFrame([
        {
            "category": "Preserved",
            "claim": "The compact D-scale lane remains M_i = G_i exp(L_eff u_i).",
            "status": "PRESERVED",
            "boundary": "D-scale lane only."
        },
        {
            "category": "Preserved",
            "claim": "Canonical equal per-component normalization gives the trace-weighted 3:2 coefficient.",
            "status": "CONDITIONAL_PASS",
            "boundary": "Requires full master-action normalization statement."
        },
        {
            "category": "Observed",
            "claim": "D-required k_space/k_phase is very close to 1.",
            "status": "DIAGNOSTIC_PASS",
            "boundary": "D-required k cannot be used to define the law."
        },
        {
            "category": "Observed",
            "claim": "A finite k tolerance band surrounds the equal-normalization solution.",
            "status": "SUPPORTS_ROBUSTNESS",
            "boundary": "Robustness is not derivation."
        },
        {
            "category": "Open",
            "claim": "The master action explicitly fixes the canonical unit metric across spatial and phase sectors.",
            "status": "OPEN",
            "boundary": "This remains the paper-grade proof target."
        },
        {
            "category": "Rejected",
            "claim": "R215M proves the full particle mass hierarchy.",
            "status": "NO",
            "boundary": "No species map, no top/e closure, no prediction suite."
        },
        {
            "category": "Promotion",
            "claim": "V12.13 promotion.",
            "status": "NO",
            "boundary": "Not yet earned."
        },
    ])


def build_report(
    created_utc: str,
    verdict: str,
    req: dict,
    candidates: pd.DataFrame,
    scan_best: dict,
    gates: pd.DataFrame,
    claims: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.12B R215M — Canonical Sector Normalization Derivation Gate

Generated: {created_utc}

Verdict:
{verdict}

Purpose:
R215M tests whether equal per-component normalization between spatial support and phase refresh sectors is a native canonical choice.

Lead compact lane:
M_i = G_i * exp(L_eff * u_i)

Lead coefficient:
L_eff = 3pi - 1/2 ln(25/13)

Canonical equal normalization:
k_space/k_phase = 1

D-required normalization:
{json.dumps(json_safe(req), indent=2)}

Candidate normalization scorecard:
{candidates.to_string(index=False)}

Best scan row:
{json.dumps(json_safe(scan_best), indent=2)}

Gate matrix:
{gates.to_string(index=False)}

Claim boundary:
{claims.to_string(index=False)}

Interpretation:
R215M supports canonical equal per-component normalization as the lead native choice.

The D-required k_space/k_phase is extremely close to unity, so the native k=1 law is not an arbitrary tuning. However, the exact D-optimal k remains diagnostic-only and cannot define the law.

The main remaining proof is to write the master action in canonical dimensionless variables and show that spatial support components and phase-refresh components carry the same unit coefficient in the action ledger.

Ruling:
No V12.13 promotion.

Next recommended run:
R216M — Master-Action Canonical Normalization Patch Attempt

Question:
Can the master action be patched or rewritten with an explicit canonical 3+2 metric:
delta q^T delta q = sum_i dX_i^2 + sum_a dPhi_a^2,
so the equal per-component normalization is not assumed but stated as the canonical action measure?
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    req = required_D_split_and_k()
    candidates = candidate_normalizations(req)
    scan = normalization_scan()
    variables = canonical_variable_dictionary()
    premises = normalization_premise_matrix(req)
    gates = gate_matrix(req, scan, candidates)
    claims = claim_boundary()

    equal_row = candidates[candidates["model_id"] == "canonical_equal_per_component"].iloc[0]
    d_row = candidates[candidates["model_id"] == "D_inferred_exact_k_diagnostic"].iloc[0]
    best_scan = scan.iloc[0].to_dict()

    verdict = (
        "PARTIAL_PASS_CANONICAL_EQUAL_SECTOR_NORMALIZATION_IS_LEAD_NATIVE_CHOICE_"
        "D_REQUIRED_K_IS_WITHIN_0P35_PERCENT_OF_EQUAL_UNIT_METRIC_"
        "FINITE_NORMALIZATION_TOLERANCE_BAND_CONFIRMED_"
        "MASTER_ACTION_CANONICAL_METRIC_STATEMENT_STILL_OPEN_NO_V12_13"
    )

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "compact_formula": "M_i = G_i * exp(L_eff * u_i)",
        "candidate_law": "L_eff = 3*pi - 0.5*ln(25/13)",
        "key_constants": {
            "D_target_context": D_TARGET,
            "top_e_target_context": TOP_E_TARGET,
            "three_pi": THREE_PI,
            "half_ln_25_over_13": 0.5 * math.log(25.0 / 13.0),
            "three_pi_minus_half_ln_25_over_13": THREE_PI - 0.5 * math.log(25.0 / 13.0),
            "N_eff_3_to_2": 25.0 / 13.0,
            "G_endpoint_rho2": G_ENDPOINT_RHO2,
        },
        "D_required_normalization": req,
        "canonical_equal_result": equal_row.to_dict(),
        "D_inferred_exact_result_diagnostic_only": d_row.to_dict(),
        "best_scan_result": best_scan,
        "candidate_scorecard": candidates.to_dict(orient="records"),
        "claim_boundary": claims.to_dict(orient="records"),
        "ruling": "No V12.13 promotion.",
        "next_recommended": "R216M - Master-Action Canonical Normalization Patch Attempt",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R215M_candidate_normalizations.csv",
            "tables/R215M_normalization_scan.csv",
            "tables/R215M_normalization_premise_matrix.csv",
            "Any traceback if the run failed."
        ],
    }

    candidates.to_csv(tables / "R215M_candidate_normalizations.csv", index=False)
    scan.to_csv(tables / "R215M_normalization_scan.csv", index=False)
    variables.to_csv(tables / "R215M_canonical_variable_dictionary.csv", index=False)
    premises.to_csv(tables / "R215M_normalization_premise_matrix.csv", index=False)
    gates.to_csv(tables / "R215M_gate_matrix.csv", index=False)
    claims.to_csv(tables / "R215M_claim_boundary_matrix.csv", index=False)

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        req=req,
        candidates=candidates,
        scan_best=best_scan,
        gates=gates,
        claims=claims,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    this_file = Path(__file__).resolve()
    shutil.copy2(this_file, scripts / this_file.name)

    sha_manifest(root, RUN_ID, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
