
# SFT V12.12B R217M — Variational Trace-Weight Derivation Attempt

Generated: 2026-06-18T04:43:43Z

Verdict:
PARTIAL_PASS_VARIATIONAL_TRACE_RULE_DERIVED_FROM_CANONICAL_PATCH_SECOND_VARIATION_SECTOR_WEIGHTS_3_AND_2_FOLLOW_FROM_HESSIAN_TRACES_CROSS_TERMS_AVERAGE_OUT_FOR_INDEPENDENT_ZERO_MEAN_SECTOR_FLUCTUATIONS_RAW_RADIAN_AND_FIVE_EIGENCHANNEL_NULLS_REJECTED_SPECIES_TOP_E_AND_PREDICTION_SUITE_OPEN_NO_V12_13

Purpose:
R217M tests whether the sector trace rule can be obtained from the quadratic variation of the R216 canonical patch.

D-required normalization diagnostic:
{
  "L_required_endpoint": 9.098134742421925,
  "tax_required": 0.3266432183474546,
  "c_required_ln2_units": 0.4712465512498836,
  "N_eff_required": 1.9218464885850215,
  "p_high_required": 0.6008288711110555,
  "p_low_required": 0.39917112888894446,
  "k_space_over_k_phase_required": 1.0034608010243735,
  "k_required_minus_1": 0.0034608010243735166,
  "k_required_percent_offset_from_equal": 0.34608010243735166
}

Analytic variational audit:
                      case_id                                   status                                                                                   interpretation  uses_D_to_define  W_space_trace  W_phase_trace  expected_space_action_sigma1  expected_phase_action_sigma1  expected_action_ratio_space_to_phase  trace_N_eff  trace_L_eff  trace_endpoint_vs_D  trace_log_error_vs_D  eigen_N_eff  eigen_L_eff  eigen_endpoint_vs_D  eigen_log_error_vs_D                                     eigenvalues  cross_norm  cross_ratio
    canonical_R216_patch_H_I5                   LEAD_VARIATIONAL_PATCH                      R216 canonical cycle-normalized 3+2 metric; second variation Hessian is I_5             False       3.000000       2.000000                      1.500000                      1.000000                              1.500000     1.923077     9.097815             0.999680              0.000320     5.000000     8.620059             0.619975              0.478076                                     (1,1,1,1,1)         0.0     0.000000
         D_exact_diagnostic_H                   DIAGNOSTIC_ONLY_USES_D                                         D-exact diagnostic metric; not allowed to define the law              True       3.010382       2.000000                      1.505191                      1.000000                              1.505191     1.921846     9.098135             1.000000              0.000000     4.999986     8.620060             0.619976              0.478074 (1,1,1.00346080102,1.00346080102,1.00346080102)         0.0     0.000000
         raw_radian_control_H CONTROL_RAW_RADIAN_DOUBLE_COUNTS_CLOSURE       control: raw phase periods are treated as metric weights; expected to fail as native patch             False       3.000000      18.849556                      1.500000                      9.424778                              0.159155     1.310446     9.289594             1.211016              0.191459     2.382345     8.990735             0.898167              0.107399             (1,1,1,6.28318530718,12.5663706144)         0.0     0.000000
canonical_plus_cross_eps_0p10                          CROSS_TERM_TEST                                             canonical metric plus mild cross-sector Hessian term             False       3.000000       2.000000                      1.500000                      1.000000                              1.500000     1.923077     9.097815             0.999680              0.000320     4.980080     8.622055             0.621214              0.476080                                 (0.9,1,1,1,1.1)         0.2     0.063567
canonical_plus_cross_eps_0p25                          CROSS_TERM_TEST                                         canonical metric plus stronger cross-sector Hessian term             False       3.000000       2.000000                      1.500000                      1.000000                              1.500000     1.923077     9.097815             0.999680              0.000320     4.878049     8.632405             0.627677              0.465729                               (0.75,1,1,1,1.25)         0.5     0.158919
 five_equal_eigenchannel_null                   NULL_WRONG_BOOKKEEPING same canonical Hessian but interpreted as five independent channels instead of two sector traces             False       3.000000       2.000000                      1.500000                      1.000000                              1.500000     1.923077     9.097815             0.999680              0.000320     5.000000     8.620059             0.619975              0.478076                                     (1,1,1,1,1)         0.0     0.000000

Monte Carlo variational audit:
                      case_id  mean_S_space_MC  mean_S_phase_MC  mean_S_cross_MC  mean_S_full_MC  analytic_S_space  analytic_S_phase  space_MC_minus_analytic  phase_MC_minus_analytic  space_to_phase_ratio_MC  space_to_phase_ratio_analytic  abs_cross_mean_over_full_mean
    canonical_R216_patch_H_I5         1.497074         0.997281    -3.788562e-19        2.494355          1.500000          1.000000                -0.002926                -0.002719                 1.501155                       1.500000                   1.518854e-19
         D_exact_diagnostic_H         1.505586         0.997832     2.323484e-19        2.503418          1.505191          1.000000                 0.000395                -0.002168                 1.508857                       1.505191                   9.281247e-20
         raw_radian_control_H         1.499184         9.427558     2.124658e-18       10.926743          1.500000          9.424778                -0.000816                 0.002781                 0.159021                       0.159155                   1.944457e-19
canonical_plus_cross_eps_0p10         1.500082         0.995586    -3.319603e-05        2.495635          1.500000          1.000000                 0.000082                -0.004414                 1.506732                       1.500000                   1.330164e-05
canonical_plus_cross_eps_0p25         1.502516         1.003144    -7.260739e-04        2.504933          1.500000          1.000000                 0.002516                 0.003144                 1.497807                       1.500000                   2.898576e-04
 five_equal_eigenchannel_null         1.497232         1.000043    -6.009706e-19        2.497275          1.500000          1.000000                -0.002768                 0.000043                 1.497168                       1.500000                   2.406506e-19

Scorecard:
                      case_id                                   status  combined_score  uses_D_to_define  trace_N_eff  trace_L_eff  trace_endpoint_vs_D  trace_log_error_vs_D  eigen_N_eff  eigen_endpoint_vs_D  cross_ratio  space_to_phase_ratio_analytic  space_to_phase_ratio_MC  mean_cross_action_MC  abs_cross_mean_over_full_mean  variational_MC_confirms_trace
    canonical_R216_patch_H_I5                   LEAD_VARIATIONAL_PATCH            20.0             False     1.923077     9.097815             0.999680              0.000320     5.000000             0.619975     0.000000                       1.500000                 1.501155         -3.788562e-19                   1.518854e-19                           True
canonical_plus_cross_eps_0p10                          CROSS_TERM_TEST            15.0             False     1.923077     9.097815             0.999680              0.000320     4.980080             0.621214     0.063567                       1.500000                 1.506732         -3.319603e-05                   1.330164e-05                           True
canonical_plus_cross_eps_0p25                          CROSS_TERM_TEST            15.0             False     1.923077     9.097815             0.999680              0.000320     4.878049             0.627677     0.158919                       1.500000                 1.497807         -7.260739e-04                   2.898576e-04                           True
 five_equal_eigenchannel_null                   NULL_WRONG_BOOKKEEPING             5.0             False     1.923077     9.097815             0.999680              0.000320     5.000000             0.619975     0.000000                       1.500000                 1.497168         -6.009706e-19                   2.406506e-19                           True
         raw_radian_control_H CONTROL_RAW_RADIAN_DOUBLE_COUNTS_CLOSURE             2.0             False     1.310446     9.289594             1.211016              0.191459     2.382345             0.898167     0.000000                       0.159155                 0.159021          2.124658e-18                   1.944457e-19                           True
         D_exact_diagnostic_H                   DIAGNOSTIC_ONLY_USES_D           -12.0              True     1.921846     9.098135             1.000000              0.000000     4.999986             0.619976     0.000000                       1.505191                 1.508857          2.323484e-19                   9.281247e-20                           True

Premise matrix:
                       premise                                                                           statement             status                                                              boundary
    quadratic_second_variation                                          The local patch admits δ²S = 1/2 δQᵀ H δQ.         PATCH_PASS              This is the quadratic local variation of the R216 patch.
             canonical_Hessian                                             For the R216 canonical metric, H = I_5.         PATCH_PASS                      Requires accepting cycle-normalized coordinates.
 isotropic_sector_fluctuations            Allowed fluctuations are isotropic inside the spatial and phase sectors. SYMMETRY_SUPPORTED                       Uses R214 rotational/gauge covariance argument.
    trace_expectation_identity                                                 E[δQ_sᵀ H δQ_s] = σ² Tr(P_s H P_s).        PASS_FORMAL                            This is the mathematical trace derivation.
cross_expectation_cancellation Independent zero-mean spatial and phase fluctuations make mean cross action vanish. PASS_MC_AND_FORMAL   Cross terms can still matter if sectors are dynamically correlated.
          sector_weight_result                                                 For H=I_5, W_space=3 and W_phase=2.               PASS                                                    D-scale lane only.
      variational_trace_weight           The trace rule arises from second variation, not from an added postulate.   CONDITIONAL_PASS Conditional on the R216 patch being the correct local action measure.
                        V12_13                                                              Promote final version.                 NO           No species map, no top/e closure, no prediction/null suite.

Gate matrix:
                         gate                                                                 test           status                                                                                        boundary
     second_variation_written                            δ²S = 1/2 δQᵀ H δQ with R216 canonical Q.       PASS_PATCH                                           Patch-level second variation, not full global action.
               trace_identity                   Sector expected quadratic action equals 1/2 trace.             PASS                                                               Formal and Monte Carlo confirmed.
         lead_canonical_trace                       Canonical H=I_5 gives W_space=3 and W_phase=2.             PASS                                                                endpoint_vs_D=0.9996800358435753
       cross_term_expectation Cross terms have near-zero mean for independent sector fluctuations.  PASS_DIAGNOSTIC eps0.10 cross mean ratio=1.3301635719038997e-05, eps0.25 cross mean ratio=0.0002898575718227442
           raw_radian_control                        Raw phase periods treated as Hessian weights.  FAILS_AS_NATIVE                                endpoint_vs_D=1.2110156362585691; double-counts closure periods.
       five_eigenchannel_null            Five independent eigenchannels rather than sector traces. FAILS_AS_PRIMARY                                                                endpoint_vs_D=0.9996800358435753
variational_derivation_status     Trace rule appears from second variation of the canonical patch. CONDITIONAL_PASS               Still conditional on R216 canonical patch being accepted as local action measure.
                       V12_13                                                           Promotion.               NO                                     Need species map, top/e closure, and prediction/null suite.

Claim boundary:
 category                                                                                             claim           status                                                            boundary
Preserved                                        The compact D-scale lane remains M_i = G_i exp(L_eff u_i).        PRESERVED                                                  D-scale lane only.
Preserved                                The R216 canonical 3+2 patch has a quadratic variation with H=I_5.       PATCH_PASS                                                 Patch-level result.
Preserved The trace-weight rule follows from expected second variation under isotropic sector fluctuations. CONDITIONAL_PASS Conditional on canonical patch and independent sector fluctuations.
 Observed                           Monte Carlo sector fluctuations confirm the trace expectation identity.  DIAGNOSTIC_PASS                      Numerical confirmation of the formal identity.
 Rejected                                       Raw-radian phase weights are the canonical Hessian weights.               NO                         Rejected as closure-period double counting.
 Rejected                             Five independent eigenchannels are the correct amplitude bookkeeping.               NO                         Rejected if protected sectors are physical.
     Open                                                     This proves the full particle mass hierarchy.               NO         No species map, no top/e closure, no prediction/null suite.
Promotion                                                                                 V12.13 promotion.               NO                                                     Not yet earned.

Interpretation:
The trace rule is no longer merely a bookkeeping instruction. At the patch level, it follows from the expected quadratic variation of isotropic sector fluctuations:

E[delta^2 S_s] = 1/2 sigma^2 Tr(P_s H P_s).

For the R216 canonical patch H=I_5, this gives W_space=3 and W_phase=2. The resulting N_eff is 25/13 and the D-scale coefficient remains L_eff = 3pi - 1/2 ln(25/13).

Cross terms have near-zero mean under independent zero-mean sector fluctuations, supporting the protected trace rule.

The raw-radian control remains rejected as double-counting closure periods. The five-eigenchannel null remains rejected if protected sectors are physical.

Ruling:
No V12.13 promotion.

Next recommended run:
R218M — D-Scale Law Freeze Candidate and Remaining-Open-Claims Ledger

Question:
Is the D-scale hierarchy law now mature enough to freeze as a conditional paper-grade law candidate, while explicitly reserving species map, top/e closure, and prediction/null suite as open?
