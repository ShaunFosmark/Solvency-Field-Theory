
# R217M Variational Trace-Weight Patch Note

Generated: 2026-06-18T04:43:43Z

This note records the patch-level variational derivation attempted in R217M.

## Starting point

Use the R216 canonical audit vector:

    Q = (X1, X2, X3 ; Phi_spinor, Phi_frame)

with:

    X_i = x_i / r_*
    Phi_spinor = phi_spinor / 4pi
    Phi_frame  = phi_frame  / 2pi

and canonical metric:

    dQ^2 = sum_i dX_i^2 + sum_a dPhi_a^2

## Quadratic variation

The local quadratic action variation is:

    delta^2 S = 1/2 delta Q^T H delta Q

For the canonical patch:

    H = I_5

## Projectors

Let:

    P_space = diag(1,1,1,0,0)
    P_phase = diag(0,0,0,1,1)

## Trace identity

For isotropic fluctuations in a sector with covariance sigma^2 P_s:

    E[delta Q_s^T H delta Q_s] = sigma^2 Tr(P_s H P_s)

Therefore:

    E[delta^2 S_s] = 1/2 sigma^2 Tr(P_s H P_s)

For H = I_5:

    W_space = Tr(P_space H P_space) = 3
    W_phase = Tr(P_phase H P_phase) = 2

## Amplitude tax

Using the sector variation weights:

    N_eff = 1 / [(3/5)^2 + (2/5)^2] = 25/13

and:

    L_eff = 3pi - 1/2 ln(25/13)

## Claim boundary

This derives the trace rule from the second variation of the canonical patch.
It remains conditional on the R216 patch being the correct local master-action measure.
It does not assign species.
It does not close top/e.
It does not promote V12.13.
