
# SFT V12.12B R220M — One-Extra-6π Top-Sector Closure Derivation Gate

Generated: 2026-06-18T05:31:41Z

Verdict:
PARTIAL_PASS_ONE_EXTRA_6PI_MULTIPLIER_DERIVED_AS_FORMAL_FULL_CLOSURE_CANDIDATE_K_TOP_EQUALS_4PI_PLUS_2PI_WITHOUT_TOP_INPUT_TOP_E_MATCH_DIAGNOSTIC_SUPPORTIVE_RESIDUAL_AND_TOP_SECTOR_TRIGGER_OPEN_TAXED_VARIANTS_AND_SECOND_D_LAYER_REJECTED_AS_PRIMARY_NO_SPECIES_MAP_NO_PREDICTION_SUITE_NO_V12_13

Purpose:
R220M tests whether the one-extra-6π top/e multiplier can be derived without using top/e.

Frozen D-scale endpoint:
17871.48862357384

Top/e exact diagnostic gap:
18.968761200610533

Candidate scorecard:
                               model_id                   status                                                           derivation_route                                                                            interpretation   multiplier  log_multiplier  predicted_top_e_scale  predicted_top_e_vs_target_factor  top_e_log_error_abs  top_e_percent_error  residual_multiplier_to_exact_gap  residual_percent_of_exact_gap  uses_top_to_define  uses_D_to_define  is_control  native_prior  combined_score
    one_extra_full_closure_4pi_plus_2pi   LEAD_DERIVED_CANDIDATE K_top = 4π spatial/spinor curvature closure + 2π frame/gauge phase closure Top sector gets one additional untaxed full closure/load layer after frozen D-scale lane.    18.849556        2.936489           3.368696e+05                          0.993716             0.006304            -0.628429                          0.119205                       0.628429               False             False       False          13.0            19.0
               double_half_action_2x3pi         SUPPORTIVE_ALIAS                                                             K_top = 2 * 3π                   Equivalent to 6π; supportive but less mechanically explicit than 4π+2π.    18.849556        2.936489           3.368696e+05                          0.993716             0.006304            -0.628429                          0.119205                       0.628429               False             False       False          10.0            16.0
                      legacy_K_req_load SUPPORTIVE_LEGACY_BRIDGE                                     legacy K_req load from old K/beta lane                      K_req is close to both exact gap and 6π, but not newly derived here.    18.890589        2.938664           3.376029e+05                          0.995879             0.004130            -0.412111                          0.078172                       0.412111               False             False       False           8.0            15.0
 closure_6pi_plus_amplitude_tax_control    TAXED_CLOSURE_CONTROL                                                 K_top = 6π + amplitude_tax  Tests whether the D-scale amplitude tax should be added back onto the top closure layer.    19.176519        2.953687           3.427129e+05                          1.010953             0.010893             1.095264                         -0.207758                      -1.095264               False             False        True           4.0             6.0
closure_6pi_minus_amplitude_tax_control    TAXED_CLOSURE_CONTROL                                                 K_top = 6π - amplitude_tax  Tests whether the D-scale amplitude tax should be subtracted from the top closure layer.    18.522593        2.918991           3.310263e+05                          0.976479             0.023802            -2.352123                          0.446169                       2.352123               False             False        True           4.0             6.0
         two_times_frozen_L_eff_control       STRUCTURAL_CONTROL                                                   K_top = 2 * L_eff_freeze             Tests whether the top sector should reuse the taxed D-scale half-action load.    18.195629        2.901181           3.251830e+05                          0.959242             0.041612            -4.075816                          0.773132                       4.075816               False             False        True           5.0             5.0
         sqrt2_half_action_K_diagnostic        DIAGNOSTIC_USES_D                                                      K = 2(ln D - 1/2 ln2)               Diagnostic relation from D and sqrt2 half-action; cannot define top/e rule.    18.889417        2.938602           3.375820e+05                          0.995817             0.004192            -0.418291                          0.079345                       0.418291               False              True        True           4.0             3.0
     one_extra_3pi_half_closure_control        UNDERLOAD_CONTROL                                                                 K_top = 3π                                       Tests whether only one half-action layer is enough.     9.424778        2.243342           1.684348e+05                          0.496858             0.699451           -50.314215                          9.543983                      50.314215               False             False        True           4.0             2.0
           second_D_scale_layer_control        HARD_FAIL_CONTROL                                                                  K_top = D                             Tests full second D-scale compounding; expected to overshoot. 17877.208690        9.791282           3.194923e+08                        942.455256             6.848488         94145.525580                     -17858.239928                  -94145.525580               False              True        True           1.0           -15.0
               exact_top_gap_diagnostic DIAGNOSTIC_ONLY_USES_TOP                                          top/e divided by D-scale endpoint                                                   Exact target gap; cannot define theory.    18.968761        2.942793           3.390000e+05                          1.000000             0.000000             0.000000                          0.000000                       0.000000                True             False        True         -12.0           -24.0

Derivation gate matrix:
                  gate                                                                test                   status                                                                                    evidence                                                                              boundary
derive_6pi_without_top           Can 6π be written from closure bookkeeping without top/e?              PASS_FORMAL        6π = 4π + 2π = full spatial/spinor curvature closure plus frame/gauge phase closure. Formal derivation of candidate multiplier, not proof that top sector must receive it.
     top_match_quality                         Does derived 6π land near top/e diagnostic?          PASS_DIAGNOSTIC                                factor=0.9937157056377548, percent_error=-0.6284294362245202                                                                      Diagnostic only.
    exact_gap_not_used                                Is exact gap rejected as derivation?            PASS_BOUNDARY                                                             exact gap candidate score=-24.0                                         Exact top/e gap cannot define the multiplier.
   why_one_extra_layer       Does R220 derive why exactly one additional 6π layer appears?             PARTIAL_OPEN            The full-closure layer is formal, but the top-sector trigger is not yet derived.                                                 Need top-sector activation criterion.
      taxed_vs_untaxed Should the high-sector layer be taxed by the D-scale amplitude tax? PASS_CONDITIONAL_UNTAXED      Untaxed 6π is lead; taxed variants are controls and do not improve mechanism priority.          Need formal reason top closure is completion load, not branch participation.
   legacy_K_req_bridge                                       Does K_req remain supportive?               SUPPORTIVE                          K_req factor=0.9958788925804416, percent_error=-0.4121107419558401                                                         K_req not newly derived here.
    reuse_taxed_D_load                                   Does K_top = 2*L_eff_freeze work?           CONTROL_WEAKER                                 factor=0.9592418430332945, percent_error=-4.075815696670548                                  D-scale taxed load is not preferred for top closure.
        one_half_layer                                               Does K_top = 3π work?           FAIL_UNDERLOAD                                 factor=0.4968578528188774, percent_error=-50.31421471811226                                              One half-action closure is insufficient.
        second_D_layer                       Does full second D-scale multiplication work?                HARD_FAIL                                   factor=942.4552558021568, percent_error=94145.52558021568                                                                Rejected as overshoot.
          top_e_closed                                                    Is top/e solved?                       NO 6π layer is derived as a candidate multiplier, but top-sector trigger/residual remain open.                                                                            No V12.13.

Residual analysis:
                    quantity    value                          interpretation          ruling
residual_exact_gap_minus_6pi 0.119205                     diagnostic residual DIAGNOSTIC_ONLY
 residual_as_fraction_of_6pi 0.006324                  dimensionless fraction DIAGNOSTIC_ONLY
 residual_over_amplitude_tax 0.364583           tests relation to D-scale tax DIAGNOSTIC_ONLY
           residual_over_ln2 0.171977           tests relation to binary unit DIAGNOSTIC_ONLY
           residual_over_2pi 0.018972           tests relation to phase cycle DIAGNOSTIC_ONLY
         residual_over_L_eff 0.013103 tests relation to frozen effective load DIAGNOSTIC_ONLY
       log_gap_minus_log_6pi 0.006304                            log residual DIAGNOSTIC_ONLY

Open claims ledger:
           open_claim status                                         current_best_candidate                                                                                                            why_open                                                    required_next  promotion_blocker
   top_sector_trigger   OPEN Top sector receives one additional full 6π closure/load layer. R220 derives the 6π candidate formally but does not yet prove why the top sector activates exactly one extra layer.     Find a top-sector activation criterion independent of top/e.               True
         residual_gap   OPEN                            Exact top/e gap is 0.632% above 6π.                              Residual may be correction, target rounding/context, or sign this is only approximate.                    Do not fit residual until trigger is derived.               True
         K_req_origin   OPEN                   K_req remains supportive bridge close to 6π.                                                              K_req is numerically supportive but not newly derived.              Derive K_req or demote it to historical diagnostic.               True
          species_map   OPEN                                                      Deferred.                                                                             Species assignment still risks fitting.                Attempt only after top-sector trigger is bounded.               True
prediction_null_suite   OPEN                                        Not addressed in R220M.                                                                                   No external no-retuning test yet. Build prediction/null suite after top-sector mechanism decision.               True
     V12_13_promotion     NO                                                  Not eligible.                                                  Top/e trigger, species map, residual, and predictions remain open.                                                    No promotion.               True

Claim boundary matrix:
     category                                                           claim status                                       safe_wording
Allowed claim R220M derives 6π as a formal full-closure candidate from 4π+2π.    YES Formal candidate multiplier derived without top/e.
Allowed claim One extra 6π layer remains the lead top/e structural candidate.    YES                  Lead candidate, not solved top/e.
Allowed claim      Taxed variants and full second D-scale layer are controls.    YES                                     Controls only.
Blocked claim                                        Top/e closure is solved.     NO       Top-sector trigger and residual remain open.
Blocked claim                         Exact top/e gap defines the multiplier.     NO                      Exact gap is diagnostic-only.
Blocked claim                                         Species map is derived.     NO                          Species map remains open.
Blocked claim                                             V12.13 is promoted.     NO                               No V12.13 promotion.

Interpretation:
R220M derives 6π as a formal full-closure candidate:

K_top = 4π + 2π = 6π.

This gives a structural multiplier independent of the exact top/e gap. It remains the lead top/e candidate, and it beats the taxed/reused-load controls in mechanism priority. The exact top/e gap remains diagnostic-only, and a full second D-scale layer remains rejected.

The result is still not top/e closure. The missing proof is the top-sector trigger: why exactly one extra full closure layer is activated.

Ruling:
Top/e candidate strengthened but not solved.
No species map.
No prediction suite.
No V12.13 promotion.

Next recommended run:
R221M — Top-Sector Activation Criterion Hunt

Question:
Can the theory derive why the high sector receives exactly one extra full 6π closure/load layer and not zero, two, or a taxed variant?
