#!/usr/bin/env python3
"""
SFT V12.13 R224F — Manuscript / Freeze Pack Writer

Title:
    Solvency Field Theory V12.13:
    Trace-Variational D-Scale Law and Conditional Top-Sector 6π Closure

Purpose:
    Write the scoped V12.13 document after the V12.12A photon closure addendum
    and R218-R223 D-scale/top-sector closure chain.

Boundary:
    This is a scoped candidate/freeze document.
    It does not claim:
        - complete particle mass hierarchy
        - derived species map
        - final top/e closure
        - residual-gap explanation
        - blind prediction/null suite
        - complete global action theorem

Outputs:
    SFT_V12_13_Trace_Variational_D_Scale_Conditional_Top_Sector_6pi_Closure/
        SFT_V12_13_Trace_Variational_D_Scale_Conditional_Top_Sector_6pi_Closure.md
        SFT_V12_13_Executive_Summary.md
        README.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R224F_write_V12_13.py

    SFT_V12_13_Trace_Variational_D_Scale_Conditional_Top_Sector_6pi_Closure_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import csv
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile


RUN_ID = "SFT_V12_13_Trace_Variational_D_Scale_Conditional_Top_Sector_6pi_Closure"
TITLE = "Solvency Field Theory V12.13: Trace-Variational D-Scale Law and Conditional Top-Sector 6π Closure"

# Core constants from R218-R223.
D_TARGET = 17877.208689571427
TOP_E_CONTEXT = 339000.0

TWO_PI = 2.0 * math.pi
THREE_PI = 3.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = THREE_PI - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)
TOP_6PI = D_SCALE_ENDPOINT * SIX_PI
TOP_GAP_EXACT = TOP_E_CONTEXT / D_SCALE_ENDPOINT

D_ENDPOINT_FACTOR = D_SCALE_ENDPOINT / D_TARGET
D_ENDPOINT_ERROR_PERCENT = 100.0 * (D_ENDPOINT_FACTOR - 1.0)
TOP_6PI_FACTOR = TOP_6PI / TOP_E_CONTEXT
TOP_6PI_ERROR_PERCENT = 100.0 * (TOP_6PI_FACTOR - 1.0)
GAP_MINUS_6PI = TOP_GAP_EXACT - SIX_PI
GAP_PERCENT_ABOVE_6PI = 100.0 * (TOP_GAP_EXACT / SIX_PI - 1.0)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "title": TITLE,
        "created_utc": created_utc,
        "file_count": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def equation_index() -> list[dict]:
    return [
        {
            "id": "EQ1",
            "name": "Photon closure-fit identity",
            "equation": "λ_gamma(E=mc²) = 4π r_spin",
            "source": "V12.12A Photon Closure Fit Addendum",
            "status": "foundation",
            "meaning": "The photon open-path wavelength at energy mc² equals the massive closed 4π spinor path.",
        },
        {
            "id": "EQ2",
            "name": "Spin radius",
            "equation": "r_spin = ħ/(2mc)",
            "source": "V12.12A / R192M",
            "status": "foundation",
            "meaning": "Spinor radius used in the 4π closure identity.",
        },
        {
            "id": "EQ3",
            "name": "Curvature crossing rate",
            "equation": "Ω_r / ν_C = 4π",
            "source": "R192M",
            "status": "derived",
            "meaning": "Local curvature crossing per Compton maintenance cycle.",
        },
        {
            "id": "EQ4",
            "name": "Full closure load",
            "equation": "Δ_close = 4π + 2π = 6π",
            "source": "R192M, R193M, R194M, R220M",
            "status": "formal conditional",
            "meaning": "Full support/frame closure: 4π spatial/spinor plus 2π frame/gauge phase.",
        },
        {
            "id": "EQ5",
            "name": "Effective feedback load",
            "equation": "L_eff = 3π − 1/2 ln(25/13)",
            "source": "R208M-R217M",
            "status": "conditional derived",
            "meaning": "D-scale trace-variational load from protected 3+2 sector trace weighting.",
        },
        {
            "id": "EQ6",
            "name": "D-scale law",
            "equation": "M_i = G_i × exp(L_eff × u_i)",
            "source": "R211M-R218M",
            "status": "freeze candidate",
            "meaning": "Frozen conditional D-scale trace law.",
        },
        {
            "id": "EQ7",
            "name": "Top-sector theorem candidate",
            "equation": "K_top = 4π + 2π = 6π",
            "source": "R221M-R223M",
            "status": "symbolic conditional theorem",
            "meaning": "At D-scale saturation, minimal nonzero terminal completion selects one untaxed 6π layer.",
        },
        {
            "id": "EQ8",
            "name": "Combined candidate law",
            "equation": "M_i = G_i × exp(L_eff × u_i) × K_top^(top sector)",
            "source": "V12.13 synthesis",
            "status": "conditional framework",
            "meaning": "D-scale trace law with conditional top-sector terminal completion.",
        },
    ]


def run_catalog() -> list[dict]:
    return [
        {
            "run": "V12.12 / R184R-R185F",
            "role": "Reality lock foundation",
            "include": "main",
            "contribution": "Locally real particle foundation: particles are real energy at c in real support motion, not abstract graph vertices.",
        },
        {
            "run": "V12.12A",
            "role": "Photon closure addendum",
            "include": "main",
            "contribution": "λ_gamma(E=mc²)=4πr_spin, linking photon path and massive spinor closure.",
        },
        {
            "run": "R187T / V12.12B",
            "role": "Compression ladder scaffold",
            "include": "brief setup",
            "contribution": "Toy population and compression scaffold; no species map promoted.",
        },
        {
            "run": "R189M",
            "role": "D-span clarification",
            "include": "brief setup",
            "contribution": "D is base dynamic range, not full top/e span.",
        },
        {
            "run": "R190M-R191M",
            "role": "K/beta and half-action clues",
            "include": "brief clue section",
            "contribution": "K_req, beta, sqrt2, and half-action patterns identified as clues, not final law.",
        },
        {
            "run": "R192M",
            "role": "Local settlement reinforcement skeleton",
            "include": "main",
            "contribution": "Particle maintenance as local reinforcement vs relaxation; Ω_r/ν_C=4π.",
        },
        {
            "run": "R193M",
            "role": "2π frame/gauge holonomy",
            "include": "main",
            "contribution": "2π phase/gauge closure component.",
        },
        {
            "run": "R194M",
            "role": "Support-fiber closure bridge",
            "include": "main",
            "contribution": "4π+2π=6π support/frame closure candidate.",
        },
        {
            "run": "R195M",
            "role": "Directional settlement bridge",
            "include": "main paragraph",
            "contribution": "Frame/gauge orientation contributes real directional settlement structure, allowing 2π to enter as physical settlement load.",
        },
        {
            "run": "R208M-R210M",
            "role": "Two-channel / 3:2 support origin",
            "include": "main derivation bridge",
            "contribution": "3 spatial : 2 phase grouping leads to N_eff=25/13.",
        },
        {
            "run": "R211M-R217M",
            "role": "D-scale proof chain",
            "include": "core main text",
            "contribution": "Action grouping, projector trace, normalization, trace protection, canonical patch, second variation.",
        },
        {
            "run": "R218M",
            "role": "D-scale freeze candidate",
            "include": "main freeze point",
            "contribution": "M_i=G_i exp[(3π−1/2ln(25/13))u_i] frozen as conditional D-scale law candidate.",
        },
        {
            "run": "R219M-R223M",
            "role": "Top-sector 6π conditional extension",
            "include": "main conditional extension",
            "contribution": "Gap triage, formal 6π, activation criterion, symbolic theorem, premise closure audit.",
        },
        {
            "run": "R188M/R198M/R200M-R204M",
            "role": "Demoted exploratory routes",
            "include": "not main",
            "contribution": "Simple exponent, Green-solver, inverse/feedback explorations helped redirect the route but are not required in main story.",
        },
        {
            "run": "R196M-R197M",
            "role": "Future force/charge lanes",
            "include": "appendix or future work only",
            "contribution": "Coulomb/null and relaxation kernel lanes remain useful for future force program, not core V12.13 mass-scale story.",
        },
    ]


def claim_boundary() -> list[dict]:
    return [
        {
            "claim": "V12.13 gives a scoped trace-variational D-scale law and conditional top-sector 6π closure framework.",
            "status": "allowed",
            "wording": "Framework / conditional closure.",
        },
        {
            "claim": "The D-scale coefficient L_eff is derived independently of D.",
            "status": "allowed",
            "wording": "L_eff comes from 3+2 sector trace weighting, not from D fitting.",
        },
        {
            "claim": "The top-sector 6π layer is a symbolic conditional theorem candidate.",
            "status": "allowed",
            "wording": "Conditional theorem candidate, not final top/e solution.",
        },
        {
            "claim": "The exact top/e gap defines the law.",
            "status": "blocked",
            "wording": "Diagnostic only; never definitional.",
        },
        {
            "claim": "The particle mass hierarchy is fully derived.",
            "status": "blocked",
            "wording": "No complete hierarchy claim.",
        },
        {
            "claim": "Species map is derived.",
            "status": "blocked",
            "wording": "Species map remains open.",
        },
        {
            "claim": "Top/e is fully closed.",
            "status": "blocked",
            "wording": "Top/e diagnostic is narrowed but residual and action premises remain open.",
        },
        {
            "claim": "Residual 0.6324% above 6π is explained.",
            "status": "blocked",
            "wording": "Residual remains open.",
        },
        {
            "claim": "Blind prediction/null suite is complete.",
            "status": "blocked",
            "wording": "Prediction suite remains open.",
        },
        {
            "claim": "Global master-action theorem is complete.",
            "status": "blocked",
            "wording": "A1/A3/A5 still need final global action derivation.",
        },
    ]


def diagnostic_comparisons() -> list[dict]:
    return [
        {
            "quantity": "D_target",
            "value": D_TARGET,
            "role": "diagnostic comparison",
            "part_of_law": "no",
        },
        {
            "quantity": "D_scale_endpoint",
            "value": D_SCALE_ENDPOINT,
            "role": "output of frozen D-scale law at endpoint",
            "part_of_law": "yes, as model output",
        },
        {
            "quantity": "D_scale_endpoint / D_target",
            "value": D_ENDPOINT_FACTOR,
            "role": "diagnostic agreement",
            "part_of_law": "no",
        },
        {
            "quantity": "D endpoint percent error",
            "value": D_ENDPOINT_ERROR_PERCENT,
            "role": "diagnostic agreement",
            "part_of_law": "no",
        },
        {
            "quantity": "D_scale_endpoint × 6π",
            "value": TOP_6PI,
            "role": "conditional top-sector candidate output",
            "part_of_law": "yes, conditional top sector",
        },
        {
            "quantity": "top/e context",
            "value": TOP_E_CONTEXT,
            "role": "diagnostic comparison",
            "part_of_law": "no",
        },
        {
            "quantity": "(D_scale_endpoint × 6π) / top/e context",
            "value": TOP_6PI_FACTOR,
            "role": "diagnostic agreement",
            "part_of_law": "no",
        },
        {
            "quantity": "top 6π percent error",
            "value": TOP_6PI_ERROR_PERCENT,
            "role": "diagnostic agreement",
            "part_of_law": "no",
        },
        {
            "quantity": "exact top/e gap − 6π",
            "value": GAP_MINUS_6PI,
            "role": "open residual",
            "part_of_law": "no",
        },
        {
            "quantity": "exact gap percent above 6π",
            "value": GAP_PERCENT_ABOVE_6PI,
            "role": "open residual",
            "part_of_law": "no",
        },
    ]


def open_claims() -> list[dict]:
    return [
        {
            "open_item": "A1 global saturation theorem",
            "status": "open",
            "description": "D-scale saturation as u=1 endpoint has an action-boundary route, but global variational derivation remains open.",
        },
        {
            "open_item": "A3 terminal necessity",
            "status": "open",
            "description": "Both-sector terminal closure promoted to formal action route; final theorem still open.",
        },
        {
            "open_item": "A5 tax split",
            "status": "open",
            "description": "Terminal completion N_eff=1 and tax=0 promoted as action-category route; explicit action split remains open.",
        },
        {
            "open_item": "Residual gap",
            "status": "open",
            "description": "Exact gap is 0.6324% above 6π; not explained or fitted.",
        },
        {
            "open_item": "Species map",
            "status": "open",
            "description": "No particle species assignments derived.",
        },
        {
            "open_item": "Prediction/null suite",
            "status": "open",
            "description": "No blind no-retuning suite yet.",
        },
        {
            "open_item": "Full hierarchy closure",
            "status": "open",
            "description": "No complete particle mass hierarchy claim.",
        },
    ]


def independence_box() -> str:
    return f"""
## Independence and non-fitting boundary

The central V12.13 coefficient is not defined by D, top/e, the R172 selected family, or any measured particle mass.

The coefficient

    L_eff = 3π − 1/2 ln(25/13)

is constructed from internal structure only:

    3π comes from the half-action/closure-load lane.
    25/13 comes from protected 3+2 sector trace weighting.
    The 3 sector is spatial settlement geometry.
    The 2 sector is phase/frame closure.

The D-scale comparison is therefore diagnostic:

    D_target = {D_TARGET}
    D_scale_endpoint = {D_SCALE_ENDPOINT}
    D_scale_endpoint / D_target = {D_ENDPOINT_FACTOR}
    percent error = {D_ENDPOINT_ERROR_PERCENT}%

Likewise, the top/e comparison is diagnostic:

    D_scale_endpoint × 6π = {TOP_6PI}
    top/e context = {TOP_E_CONTEXT}
    factor = {TOP_6PI_FACTOR}
    percent error = {TOP_6PI_ERROR_PERCENT}%

The exact top/e gap is not used to define the law. The residual above 6π remains open.
"""


def manuscript(created_utc: str) -> str:
    return f"""# {TITLE}

Generated: {created_utc}

## Abstract

Solvency Field Theory V12.13 consolidates the V12.12 particle-program results into a scoped trace-variational framework. The document begins from the V12.12 locally real particle foundation and the V12.12A photon closure identity, where the photon wavelength at energy mc² equals the massive closed 4π spinor path. It then develops a local settlement-reinforcement picture in which particle persistence is not a race against cosmic expansion but a local balance between Compton-scale refresh and settlement relaxation. The D-scale law is frozen as a conditional trace-variational candidate,

    M_i = G_i × exp[(3π − 1/2 ln(25/13))u_i],

where the coefficient is derived from protected 3+2 sector trace weighting rather than fitted to D. A conditional top-sector extension is then stated: at D-scale saturation, the least nonzero no-overwrite terminal completion that closes both real support sectors is one untaxed K_top = 4π + 2π = 6π layer. This predicts a top/e-scale diagnostic within about 0.63% of the current context value. The result is a scoped framework, not a complete particle mass hierarchy: species assignment, residual closure, full global action proof, and prediction/null testing remain open.

---

## 1. Status and claim boundary

V12.13 is a scoped version document. It freezes a conditional D-scale trace law and a conditional top-sector 6π closure theorem candidate. It does not claim a complete particle mass hierarchy, species map, final top/e closure, residual-gap explanation, or blind prediction/null suite.

This version builds on the V12.12 locally real particle foundation: the particle is treated as real energy at c in real support motion, not as an abstract graph vertex with decorative fiber labels. The 4π term is real curvature crossing. The 2π term is real frame/gauge phase completion. The three spatial dimensions are real settlement geometry. Without that reality lock, the V12.13 quantities would be formal labels rather than physical support structure.

---

## 2. Photon closure foundation from V12.12A

The closure-fit identity is

    λ_gamma(E = mc²) = 4π r_spin

with

    r_spin = ħ/(2mc).

Thus

    4π r_spin = h/(mc) = λ_C.

This connects a photon open-path wavelength at energy mc² to the massive closed 4π spinor path. V12.13 uses this as the physical anchor for treating 4π as a real closure measure.

---

## 3. Local settlement reinforcement

R192M replaced the earlier Hubble-race intuition with a local maintenance equation: a particle persists by refreshing its local settlement/gravity support faster than local relaxation erases it. The important rate identity is

    Ω_r / ν_C = 4π.

Interpretation: one Compton maintenance cycle samples a 4π curvature crossing. This makes 4π a local curvature-crossing rate, not a symbolic decoration.

---

## 4. Closure geometry: 4π, 2π, and 6π

The V12.13 closure spine uses two physically distinct closure components:

    4π = spatial/spinor curvature closure
    2π = frame/gauge phase closure

Together,

    Δ_close = 4π + 2π = 6π.

The 4π term enters from local curvature crossing and photon/massive closure. The 2π term enters from frame/gauge phase holonomy. The full 6π combination is the natural support-frame terminal closure measure.

---

## 5. Directional settlement bridge

The 2π phase sector is included as a settlement load because frame/gauge orientation is not merely bookkeeping. Directional settlement compatibility gives it mechanical content: same circulation orientation produces a repulsive compatibility pattern, while opposite orientation meshes as an attractive compatibility pattern. In V12.13 language, charge/frame orientation creates real directional settlement structure that participates alongside scalar depth settlement. This is why the phase/frame sector contributes a real trace weight rather than remaining an abstract fiber label.

This bridge is not a full Coulomb derivation or a complete force law. Its role here is narrower: it justifies treating the 2π frame/gauge completion as physical support structure in the trace-variational D-scale law.

---

## 6. The 3+2 canonical sector split

The D-scale law depends on a protected 3+2 split:

    3 spatial settlement directions
    2 phase/frame closure directions

The effective participation number is

    N_eff = 25/13.

The amplitude tax is

    1/2 ln(25/13) = {AMP_TAX}.

The effective load is

    L_eff = 3π − 1/2 ln(25/13)
          = {L_EFF}.

The important feature is that these numbers come from internal sector counting and trace weighting. They are not fitted to D.

---

## 7. D-scale trace-variational law

The frozen D-scale candidate is

    M_i = G_i × exp(L_eff × u_i),

with

    L_eff = 3π − 1/2 ln(25/13).

At the endpoint used in the D diagnostic,

    D_scale_endpoint = {D_SCALE_ENDPOINT}.

The comparison is

    D_target = {D_TARGET}
    D_scale_endpoint / D_target = {D_ENDPOINT_FACTOR}
    percent error = {D_ENDPOINT_ERROR_PERCENT}%.

This is a diagnostic agreement, not a definition.

{independence_box()}

---

## 8. R211M-R217M proof chain

The D-scale law is supported by the following chain:

1. R211M: action-level 3:2 grouping proof attempt.
2. R212M: separable projector trace route.
3. R213M: normalization and cross-term audit.
4. R214M: trace-protection mechanism via symmetry/incommensurability.
5. R215M: canonical sector normalization.
6. R216M: master-action canonical 3+2 patch.
7. R217M: second-variation trace-weight derivation.

Together, these runs support the conditional D-scale coefficient

    L_eff = 3π − 1/2 ln(25/13).

R218M freezes this as a D-scale law candidate, not a final mass hierarchy.

---

## 9. Conditional top-sector 6π closure

R219M-R223M extend the D-scale framework to a conditional top-sector completion.

The top-sector theorem candidate is:

Given:
    A1. D-scale trace lane is saturated.
    A2. No-overwrite minimality applies.
    A3. Terminal completion must close both real support sectors.
    A4. Full closure measure is 4π + 2π.
    A5. Terminal completion is untaxed.

Then the unique minimal nonzero terminal completion is

    K_top = 4π + 2π = 6π.

This theorem is conditional. R223M tightens the premises:

    A1 receives an action-boundary route: u is normalized with 0 ≤ u ≤ 1 and saturation at u=1.
    A3 is promoted to a formal action-route candidate: terminal closure cannot leave either real support sector open.
    A5 is promoted to an action-category separation candidate: branch participation tax and terminal completion are different categories.

The candidate top-sector output is

    D_scale_endpoint × 6π = {TOP_6PI}.

Compared to the top/e context,

    top/e context = {TOP_E_CONTEXT}
    factor = {TOP_6PI_FACTOR}
    percent error = {TOP_6PI_ERROR_PERCENT}%.

The residual is

    exact gap − 6π = {GAP_MINUS_6PI}
    exact gap percent above 6π = {GAP_PERCENT_ABOVE_6PI}%.

The residual remains open and is not fitted.

---

## 10. Combined candidate law

The scoped V12.13 candidate can be summarized as

    M_i = G_i × exp(L_eff × u_i) × K_top^(top sector),

where

    L_eff = 3π − 1/2 ln(25/13)

and, conditionally,

    K_top = 4π + 2π = 6π.

The exponent "top sector" is an activation flag, not a fitted continuous exponent. It means the top-sector terminal completion is applied only when the D-scale trace lane is saturated and the top-sector closure condition is active.

---

## 11. What is not claimed

V12.13 does not claim:

    complete particle mass hierarchy
    derived species map
    final top/e closure
    residual-gap explanation
    blind prediction/null suite
    complete global action theorem
    measured-mass fit

The D-scale and top/e comparisons are diagnostic only.

---

## 12. Open problems

The main open problems are:

1. Derive A1 saturation from the global action.
2. Derive A3 terminal necessity from the global action.
3. Derive A5 action-category separation explicitly.
4. Explain or demote the 0.6324% residual above 6π.
5. Build the species-map constraint skeleton.
6. Build the blind prediction/null suite.
7. Decide whether V12.13 remains a scoped candidate framework or becomes the foundation for a later species program.

---

## 13. Preservation statement

SFT V12.13 freezes a scoped trace-variational D-scale law and conditional top-sector 6π closure framework. The D-scale coefficient L_eff = 3π − 1/2 ln(25/13) is derived from protected 3+2 sector trace weighting, not from D or measured masses. The top-sector extension states that, at D-scale saturation, the least nonzero no-overwrite terminal completion closing both real support sectors is one untaxed K_top = 4π + 2π = 6π layer. The resulting D-scale endpoint agrees with the D diagnostic to about 0.032%, and the conditional top-sector 6π output agrees with the top/e context to about 0.63%. These agreements are diagnostic, not definitional. Species assignment, residual closure, prediction/null testing, and full global action proof remain open.
"""


def executive_summary(created_utc: str) -> str:
    return f"""# SFT V12.13 Executive Summary

Generated: {created_utc}

Title:
{TITLE}

V12.13 consolidates the particle-program breakthrough chain from V12.12A through R223M.

Core result:

    L_eff = 3π − 1/2 ln(25/13)

    M_i = G_i × exp(L_eff × u_i)

Conditional top-sector result:

    K_top = 4π + 2π = 6π

Combined scoped candidate:

    M_i = G_i × exp(L_eff × u_i) × K_top^(top sector)

Diagnostic comparisons:

    D_target = {D_TARGET}
    D_scale_endpoint = {D_SCALE_ENDPOINT}
    D agreement factor = {D_ENDPOINT_FACTOR}
    D percent error = {D_ENDPOINT_ERROR_PERCENT}%

    D_scale_endpoint × 6π = {TOP_6PI}
    top/e context = {TOP_E_CONTEXT}
    top/e agreement factor = {TOP_6PI_FACTOR}
    top/e percent error = {TOP_6PI_ERROR_PERCENT}%

Claim boundary:

    This is a scoped candidate/freeze document.
    It does not claim a complete mass hierarchy, species map, final top/e closure,
    residual explanation, prediction suite, or full global action theorem.
"""


def readme(created_utc: str) -> str:
    return f"""# {RUN_ID}

Generated: {created_utc}

This pack contains the V12.13 scoped manuscript:

    {TITLE}

Main files:
    - SFT_V12_13_Trace_Variational_D_Scale_Conditional_Top_Sector_6pi_Closure.md
    - SFT_V12_13_Executive_Summary.md
    - summary.json
    - tables/equation_index.csv
    - tables/run_catalog.csv
    - tables/claim_boundary_matrix.csv
    - tables/diagnostic_comparisons.csv
    - tables/open_claims_ledger.csv

Boundary:
    V12.13 is a scoped trace-variational D-scale and conditional top-sector 6π closure framework.
    It is not a complete particle mass hierarchy or species map.
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    manuscript_path = root / "SFT_V12_13_Trace_Variational_D_Scale_Conditional_Top_Sector_6pi_Closure.md"
    exec_path = root / "SFT_V12_13_Executive_Summary.md"
    readme_path = root / "README.md"

    manuscript_path.write_text(manuscript(created_utc), encoding="utf-8")
    exec_path.write_text(executive_summary(created_utc), encoding="utf-8")
    readme_path.write_text(readme(created_utc), encoding="utf-8")

    write_csv(tables / "equation_index.csv", equation_index())
    write_csv(tables / "run_catalog.csv", run_catalog())
    write_csv(tables / "claim_boundary_matrix.csv", claim_boundary())
    write_csv(tables / "diagnostic_comparisons.csv", diagnostic_comparisons())
    write_csv(tables / "open_claims_ledger.csv", open_claims())

    summary = {
        "run_id": RUN_ID,
        "title": TITLE,
        "created_utc": created_utc,
        "version_status": "SCOPED_FREEZE_DOCUMENT",
        "main_claim": "Trace-variational D-scale law and conditional top-sector 6π closure framework.",
        "core_equations": {
            "photon_closure_identity": "λ_gamma(E=mc²) = 4π r_spin",
            "curvature_crossing_rate": "Ω_r / ν_C = 4π",
            "full_closure_load": "Δ_close = 4π + 2π = 6π",
            "effective_feedback_load": "L_eff = 3π − 1/2 ln(25/13)",
            "D_scale_law": "M_i = G_i × exp(L_eff × u_i)",
            "top_sector_theorem": "K_top = 4π + 2π = 6π",
            "combined_candidate": "M_i = G_i × exp(L_eff × u_i) × K_top^(top sector)",
        },
        "numeric_diagnostics": {
            "N_eff": N_EFF,
            "amplitude_tax": AMP_TAX,
            "L_eff": L_EFF,
            "D_target": D_TARGET,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "D_endpoint_factor": D_ENDPOINT_FACTOR,
            "D_endpoint_error_percent": D_ENDPOINT_ERROR_PERCENT,
            "sixpi": SIX_PI,
            "top_6pi": TOP_6PI,
            "top_e_context": TOP_E_CONTEXT,
            "top_6pi_factor": TOP_6PI_FACTOR,
            "top_6pi_error_percent": TOP_6PI_ERROR_PERCENT,
            "gap_minus_6pi": GAP_MINUS_6PI,
            "gap_percent_above_6pi": GAP_PERCENT_ABOVE_6PI,
        },
        "boundary": {
            "not_complete_mass_hierarchy": True,
            "species_map_open": True,
            "top_e_residual_open": True,
            "prediction_suite_open": True,
            "global_action_theorem_open": True,
        },
        "recommended_next": "Review/edit manuscript text, then optionally generate PDF/LaTeX in a separate packaging run.",
        "paste_back_to_chat": [
            "summary.json",
            "SFT_V12_13_Executive_Summary.md",
            "SFT_V12_13_Trace_Variational_D_Scale_Conditional_Top_Sector_6pi_Closure.md",
            "tables/claim_boundary_matrix.csv",
            "Any traceback if failed.",
        ],
    }

    (root / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    manifest = make_manifest(root, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "title": TITLE,
        "zip_path": str(zip_path.resolve()),
        "summary_path": str((root / "summary.json").resolve()),
        "manuscript_path": str(manuscript_path.resolve()),
        "executive_summary_path": str(exec_path.resolve()),
        "manifest_file_count": manifest["file_count"],
        "summary": summary,
    }

    print(json.dumps(final_payload, indent=2))


if __name__ == "__main__":
    main()
