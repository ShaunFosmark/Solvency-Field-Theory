#!/usr/bin/env python3
"""Minimal reproduction screen for R262F operator status.
This is not a symbolic field-theory proof. It records the finite decision logic of the gate.
"""

candidates = [
    {"term":"A_mu A^mu", "gauge_invariant":False, "curvature_only":False, "order":2},
    {"term":"(partial_mu A^mu)^2", "gauge_invariant":False, "curvature_only":False, "order":2},
    {"term":"F_munu F^munu", "gauge_invariant":True, "curvature_only":True, "order":2},
    {"term":"F_munu tildeF^munu", "gauge_invariant":True, "curvature_only":True, "order":2, "topological_or_odd":True},
    {"term":"(F_munu F^munu)^2", "gauge_invariant":True, "curvature_only":True, "order":4},
]

def classify(c):
    if not c["gauge_invariant"]:
        return "FAIL"
    if not c["curvature_only"]:
        return "FAIL"
    if c.get("topological_or_odd"):
        return "GUARDED"
    if c["order"] == 2:
        return "PASS_LEADING"
    return "DEFER_HIGHER_ORDER"

for c in candidates:
    print(f"{c['term']}: {classify(c)}")
