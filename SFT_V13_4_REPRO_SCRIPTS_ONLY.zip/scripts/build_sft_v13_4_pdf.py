from pathlib import Path
import re, textwrap, json, datetime

base=Path('/mnt/data')
out=base/'SFT_V13_4_Forces_Full_Derivation.md'

# Helpers

def wrap_long_token_line(line, width=88):
    if len(line) <= width:
        return line
    # Prefer break at underscores for verdict strings / labels
    parts=line.split('_')
    if len(parts)>1:
        lines=[]; cur=''
        for p in parts:
            add = p if not cur else '_' + p
            if len(cur)+len(add) > width and cur:
                lines.append(cur)
                cur=p
            else:
                cur += add
        if cur: lines.append(cur)
        return '\n'.join(lines)
    return '\n'.join(textwrap.wrap(line, width=width, break_long_words=True, break_on_hyphens=False))

def preprocess_md(text):
    # normalize weird long em/en dashes to ASCII for renderer reliability, but keep math symbols as they are
    text=text.replace('—','-').replace('–','-').replace('“','"').replace('”','"').replace('’',"'").replace('‘',"'")
    # Wrap long lines inside fenced code blocks to avoid PDF clipping
    out=[]; in_code=False
    for line in text.splitlines():
        if line.strip().startswith('```'):
            in_code = not in_code
            out.append(line)
        elif in_code:
            out.append(wrap_long_token_line(line))
        else:
            # also wrap very long markdown table cells? leave them for pandoc tables
            out.append(line)
    return '\n'.join(out).strip()+"\n"

def shift_headings(text, shift=1):
    lines=[]
    for line in text.splitlines():
        if re.match(r'^#{1,5} ', line):
            hashes, rest = line.split(' ',1)
            hashes = '#'*(min(len(hashes)+shift,6))
            lines.append(hashes+' '+rest)
        else:
            lines.append(line)
    return '\n'.join(lines)

def include_file(path, title=None, shift=1):
    path=Path(path)
    if not path.exists():
        return f"\n<!-- missing {path} -->\n"
    text=path.read_text(encoding='utf-8', errors='replace')
    text=preprocess_md(text)
    text=shift_headings(text, shift)
    if title:
        return f"\n## {title}\n\n"+text+"\n"
    return "\n"+text+"\n"

# Paths
r260='/mnt/data/_r260_extract/SFT_V13_4_R260F_Forces_Inventory_V12_to_V13_Translation_Gate/report.md'
r260b='/mnt/data/_r260_extract/SFT_V13_4_R260B_Force_Interaction_Mediator_Ontology_Gate/report.md'
r261='/mnt/data/_r260_extract/SFT_V13_4_R261F_Pitch_Twist_Independence_Confirmation/report.md'

files = {
'r262f_audit':'/mnt/data/SFT_V13_4_R262F_A_B_Dual_Gate_Test_Pack/R262F_AB_Comparison_Audit.md',
'r262f_b':'/mnt/data/SFT_V13_4_R262F_A_B_Dual_Gate_Test_Pack/R262F_B_Opus_Native_Maxwell_Foundation_PASS.md',
'r262b':'/mnt/data/SFT_V13_4_R262B_Move_Maxwell_Gate_Pack/R262B_Main_Gate.md',
'r262b_eq':'/mnt/data/SFT_V13_4_R262B_Move_Maxwell_Gate_Pack/R262B_Equation_Spine.md',
'r262c':'/mnt/data/SFT_V13_4_R262C_Conservation_Current_Noether_Gate_Pack/R262C_Main_Gate.md',
'r262c_theorem':'/mnt/data/SFT_V13_4_R262C_Conservation_Current_Noether_Gate_Pack/R262C_Native_Conservation_Theorems.md',
'r262c_eq':'/mnt/data/SFT_V13_4_R262C_Conservation_Current_Noether_Gate_Pack/R262C_Equation_Spine.md',
'r262d':'/mnt/data/SFT_V13_4_R262D_Coupling_Alpha_Running_Gate_Pack/R262D_Main_Gate.md',
'r262d_alpha':'/mnt/data/SFT_V13_4_R262D_Coupling_Alpha_Running_Gate_Pack/R262D_Alpha_Model.md',
'r262d_eq':'/mnt/data/SFT_V13_4_R262D_Coupling_Alpha_Running_Gate_Pack/R262D_Equation_Spine.md',
'r263f':'/mnt/data/SFT_V13_4_R263F_Charge_Topology_Nine_Mode_Gate_Pack/R263F_Main_Gate.md',
'r263f_audit':'/mnt/data/SFT_V13_4_R263F_Charge_Topology_Nine_Mode_Gate_Pack/R263F_AB_Overlap_Audit.md',
'r263f_eq':'/mnt/data/SFT_V13_4_R263F_Charge_Topology_Nine_Mode_Gate_Pack/R263F_Equation_Spine.md',
'r263b':'/mnt/data/SFT_V13_4_R263B_Generation_Structure_Dperp3_Gate_Pack/R263B_Main_Gate.md',
'r263b_model':'/mnt/data/SFT_V13_4_R263B_Generation_Structure_Dperp3_Gate_Pack/R263B_Generation_Model.md',
'r263b_eq':'/mnt/data/SFT_V13_4_R263B_Generation_Structure_Dperp3_Gate_Pack/R263B_Equation_Spine.md',
'r264f':'/mnt/data/SFT_V13_4_R264F_Strong_Color_Confinement_AB_Gate_Pack/R264F_Main_Gate.md',
'r264f_audit':'/mnt/data/SFT_V13_4_R264F_Strong_Color_Confinement_AB_Gate_Pack/R264F_AB_Overlap_Audit.md',
'r264f_eq':'/mnt/data/SFT_V13_4_R264F_Strong_Color_Confinement_AB_Gate_Pack/R264F_Equation_Spine.md',
'r265f':'/mnt/data/SFT_V13_4_R265F_Weak_Branch_Mode_Transition_Gate_Pack/R265F_Main_Gate.md',
'r265f_doublet':'/mnt/data/SFT_V13_4_R265F_Weak_Branch_Mode_Transition_Gate_Pack/R265F_Weak_Doublet_Model.md',
'r265f_hand':'/mnt/data/SFT_V13_4_R265F_Weak_Branch_Mode_Transition_Gate_Pack/R265F_Handedness_Selector.md',
'r265f_eq':'/mnt/data/SFT_V13_4_R265F_Weak_Branch_Mode_Transition_Gate_Pack/R265F_Equation_Spine.md',
'r266term':'/mnt/data/SFT_V13_4_R266F_Native_Frame_Rigidity_Terminology_Patch/R266F_Native_Terminology_Patch.md',
'r266f':'/mnt/data/SFT_V13_4_R266F_Higgs_PhiRelax_Historical_Rigidity_AB_Gate_Pack/R266F_Main_Gate.md',
'r266f_target':'/mnt/data/SFT_V13_4_R266F_Higgs_PhiRelax_Historical_Rigidity_AB_Gate_Pack/R266F_Microscopic_Operator_Target.md',
'r266f_eq':'/mnt/data/SFT_V13_4_R266F_Higgs_PhiRelax_Historical_Rigidity_AB_Gate_Pack/R266F_Equation_Spine.md',
'r267f':'/mnt/data/SFT_V13_4_R267F_Quantum_Bridge_Retranslation_Gate_Pack/R267F_Main_Gate.md',
'r267f_wave':'/mnt/data/SFT_V13_4_R267F_Quantum_Bridge_Retranslation_Gate_Pack/R267F_Wavefunction_As_Settlement_Field.md',
'r267f_born':'/mnt/data/SFT_V13_4_R267F_Quantum_Bridge_Retranslation_Gate_Pack/R267F_Born_Rule_Measurement.md',
'r267f_int':'/mnt/data/SFT_V13_4_R267F_Quantum_Bridge_Retranslation_Gate_Pack/R267F_Interference_Decoherence_Entanglement.md',
'r267f_bell':'/mnt/data/SFT_V13_4_R267F_Quantum_Bridge_Retranslation_Gate_Pack/R267F_Bell_Obligation.md',
'r267f_eq':'/mnt/data/SFT_V13_4_R267F_Quantum_Bridge_Retranslation_Gate_Pack/R267F_Equation_Spine.md',
'r268f':'/mnt/data/SFT_V13_4_R268F_Native_Action_Stack_Gate_Pack/R268F_Main_Gate.md',
'r268_stack':'/mnt/data/SFT_V13_4_R268F_Native_Action_Stack_Gate_Pack/R268F_Native_Action_Stack.md',
'r268_vertex':'/mnt/data/SFT_V13_4_R268F_Native_Action_Stack_Gate_Pack/R268F_Explicit_Vertex_Rules.md',
'r268_dirac':'/mnt/data/SFT_V13_4_R268F_Native_Action_Stack_Gate_Pack/R268F_No_Imported_Dirac_Guardrail.md',
'r268_sm':'/mnt/data/SFT_V13_4_R268F_Native_Action_Stack_Gate_Pack/R268F_SM_Correspondence.md',
'r268_eq':'/mnt/data/SFT_V13_4_R268F_Native_Action_Stack_Gate_Pack/R268F_Equation_Spine.md',
'r269':'/mnt/data/SFT_V13_4_R269F_Mechanism_Rollup_Pack/R269F_Main_Rollup.md',
'r269_exec':'/mnt/data/SFT_V13_4_R269F_Mechanism_Rollup_Pack/R269F_Executive_Summary.md',
'r269_mech':'/mnt/data/SFT_V13_4_R269F_Mechanism_Rollup_Pack/R269F_Mechanism_Synthesis.md',
'r269_claim':'/mnt/data/SFT_V13_4_R269F_Mechanism_Rollup_Pack/R269F_Claim_Boundary.md',
'r269_open':'/mnt/data/SFT_V13_4_R269F_Mechanism_Rollup_Pack/R269F_Open_Obligations.md',
'r269_insert':'/mnt/data/SFT_V13_4_R269F_Mechanism_Rollup_Pack/R269F_Manuscript_Insert.md',
}

front = r'''
---
title: "Solvency Field Theory V13.4: Forces as Settlement-Interaction Operators"
subtitle: "Full Derivation Document - Native Force Sector, Action Stack, and Claim Boundary"
author: "Shaun Fosmark, with AI collaboration"
date: "2026-06-30 / V13.4 R260F-R269F"
lang: en-US
---

# Preservation Notice

This document is the full V13.4 force-sector derivation manuscript assembled from the R260F-R269F gate sequence. It is intended to let a reader understand the SFT force architecture from this document alone.

The document uses **native SFT language first** and Standard Model correspondence second. Standard Model terms are translation notes, not the primary ontology.

## Central Claim

Forces are settlement-interaction operators: pressure on the next write, carried by scalar compactness, directional holonomy, boundary-port topology, branch transition, frame-rigidity loading, and explicit vertex admissibility.

## Rollup Verdict

```text
ROLLUP_READY_R269F_V13_4_FORCE_SECTOR_MECHANISM_ARCHITECTURE_INTEGRATED_NATIVE_SETTLEMENT_LANGUAGE_ALL_STRUCTURAL_FORCE_KERNELS_SUMMARIZED_WITH_BOUNDARIES_EM_CLASSICAL_NATIVE_STRONG_WEAK_TOPOLOGY_STRUCTURAL_KERNELS_FRAME_RIGIDITY_AND_QUANTUM_BRIDGE_TARGETS_IDENTIFIED_ACTION_STACK_READY_BELL_ALPHA_QCD_ELECTROWEAK_NUMERICS_AND_FULL_QFT_OPEN
```

## Best One-Sentence Summary

Forces are not substances; they are different ways written settlement resists, redirects, completes, or updates the next write.

## What This Document Claims

- Classical electromagnetism is native at the structural level.
- Charge topology reproduces the one-generation Standard Model charge kernel.
- Three generations have a native route through \(D_\perp=3\).
- Strong and weak sectors have native topology/transition kernels.
- Frame-rigidity loading and \(\Phi_{\rm relax}\) are routed to one common settlement-response target.
- The quantum bridge survives V13 retranslation structurally.
- A native action-stack scaffold is coherent and includes explicit vertex admissibility rules.

## What This Document Does Not Claim

- It does not derive \(\alpha\).
- It does not solve Bell correlations.
- It does not derive full QCD or hadron spectra.
- It does not derive W/Z masses, Weinberg angle, or weak rates.
- It does not derive the full QFT operator algebra.
- It does not derive the full particle mass hierarchy or mixing matrices.
- It does not replace precision Standard Model calculations.

\newpage

# Quick Notation

| Symbol | Native SFT meaning |
|---|---|
| \(\phi_C\) | Compton closure phase / mass cadence |
| \(\theta_g\) | charge/framing holonomy / directional settlement address |
| \(A_\mu\) | directional settlement connection |
| \(F_{\mu\nu}\) | directional settlement curvature / holonomy failure |
| \(J^\mu\) | conserved directional settlement current |
| \(B_3\) | weak branch orientation |
| \(n_Y\) | integer winding corresponding to hypercharge route |
| \(D_\perp=3\) | three normal deformation lanes / three-port source |
| \(\mathcal H_{\rm settle}\) | microscopic settlement-response operator target |
| \(\Phi_{\rm relax}\) | relaxation / frame-maintenance cost term |
| \(\psi\) | settlement support-readiness amplitude |
| \(|\psi|^2\) | settlement intensity |
| \(S_{\rm vertices}\) | explicit common-write admissibility rules |

\newpage

# Roadmap

1. Foundations and force ontology.
2. Independent phases: \(\phi_C\) and \(\theta_g\).
3. Electromagnetism: gauge connection, Maxwell curvature, moving fields, conservation, and coupling location.
4. Charge topology, species count, and generations.
5. Strong sector: color as port address and confinement as incomplete-address rejection.
6. Weak sector: branch-changing settlement and handedness selection.
7. Frame-rigidity loading, \(\Phi_{\rm relax}\), and rigidity resonance.
8. Quantum bridge retranslation.
9. Native action stack and explicit vertex rules.
10. Rollup, claim boundary, and open obligations.

\newpage
'''

custom_pair = r'''
# R261.5F Pair-Production Charge Orientation and Gear Compatibility

## Purpose

R261.5F connects charge orientation to pair-production topology. It is not a full cross-section derivation. Its role is to identify how opposite charge signs arise from symmetric closure at a vertex.

## Core Claim

Two photons with sufficient invariant mass can form a charged pair only by assigning opposite \(\theta_g\) holonomies to the two outgoing massive closures. Angular momentum and net charge conservation force opposite circulation directions.

Native reading:

> Pair production writes two opposite directional settlement addresses from one neutral closure event.

## Pair Production Skeleton

\[
\gamma + \gamma \rightarrow e^- + e^+.
\]

Net charge before:

\[
Q_{\rm in}=0.
\]

Net charge after:

\[
Q_{\rm out}=(-1)+(+1)=0.
\]

In \(\theta_g\) language:

\[
\Delta \theta_g^{(e^-)} = - \Delta \theta_g^{(e^+)}.
\]

## Gear Rule

Opposite windings mesh:

\[
(+\theta_g) + (-\theta_g) \rightarrow \text{compatible closure / attraction route}.
\]

Same windings conflict:

\[
(+\theta_g) + (+\theta_g) \rightarrow \text{incompatible pressure / repulsion route}.
\]

## Claim Boundary

R261.5F does not derive:

- pair-production cross sections,
- charge magnitude,
- \(\alpha\),
- full QED,
- spin-statistics,
- detailed scattering amplitudes.

It supplies the native vertex language used later by \(S_{\rm vertices}\): charge/winding conservation and gear compatibility.

'''

foundation = r'''
# V13.4 Foundations Before the Force Gates

## Locally Real Support

A V13 locally real object is not first a point particle in a pre-existing arena. It is a written support history. Real energy moves at the one-speed budget. Massive objects are closed supports; null radiation is open support.

Native sentence:

> A particle is a locally real write process whose past is locked and whose next write is constrained by settlement compatibility.

## No-Overwrite

No-overwrite is the statement that written history cannot be erased. A vertex may determine the next write, but it cannot rewrite the past.

This becomes the conservation backbone of V13.4:

> Conservation is no-overwrite applied to symmetry.

## Force as Pressure on the Next Write

A force is not a mysterious substance. It is pressure on the next write caused by settlement incompatibility, curvature, port incompleteness, branch transition, or frame-rigidity cost.

## Native House Style

State the SFT mechanism first. Place the Standard Model correspondence underneath as a translation note.

Example:

Native SFT:

> Frame-rigidity loading is the settlement cost of maintaining or changing written frame commitments.

SM correspondence:

> This plays the role assigned to the Higgs mechanism in the Standard Model.

'''

parts=[]
parts.append(preprocess_md(front))
parts.append(preprocess_md(foundation))
parts.append(include_file(r260, 'R260F - V12 to V13 Force Inventory Translation', shift=1))
parts.append(include_file(r260b, 'R260B - Force, Interaction, Mediator Ontology', shift=1))
parts.append(include_file(r261, 'R261F - Pitch/Twist Independence', shift=1))
parts.append(preprocess_md(custom_pair))
parts.append(include_file(files['r262f_audit'], 'R262F - Maxwell Foundation A/B Audit', shift=1))
parts.append(include_file(files['r262f_b'], 'R262F - Native Maxwell Foundation', shift=1))
parts.append(include_file(files['r262b'], 'R262B - Moving Maxwell: Magnetism, Lorentz Force, Radiation', shift=1))
parts.append(include_file(files['r262b_eq'], 'R262B Equation Spine', shift=1))
parts.append(include_file(files['r262c'], 'R262C - Conservation, Current, Noether Translation', shift=1))
parts.append(include_file(files['r262c_theorem'], 'R262C Native Conservation Theorems', shift=1))
parts.append(include_file(files['r262c_eq'], 'R262C Equation Spine', shift=1))
parts.append(include_file(files['r262d'], 'R262D - Coupling as Cadence-Memory Overlap / Alpha Hook', shift=1))
parts.append(include_file(files['r262d_alpha'], 'R262D Alpha Model', shift=1))
parts.append(include_file(files['r262d_eq'], 'R262D Equation Spine', shift=1))
parts.append(include_file(files['r263f'], 'R263F - Charge Topology from Nine-Mode / Anchor Structure', shift=1))
parts.append(include_file(files['r263f_audit'], 'R263F A/B Overlap Audit', shift=1))
parts.append(include_file(files['r263f_eq'], 'R263F Equation Spine', shift=1))
parts.append(include_file(files['r263b'], 'R263B - Generation Structure from D_perp = 3', shift=1))
parts.append(include_file(files['r263b_model'], 'R263B Generation Model', shift=1))
parts.append(include_file(files['r263b_eq'], 'R263B Equation Spine', shift=1))
parts.append(include_file(files['r264f'], 'R264F - Strong Color and Confinement Topology', shift=1))
parts.append(include_file(files['r264f_audit'], 'R264F A/B Overlap Audit', shift=1))
parts.append(include_file(files['r264f_eq'], 'R264F Equation Spine', shift=1))
parts.append(include_file(files['r265f'], 'R265F - Weak Branch as Mode Transition', shift=1))
parts.append(include_file(files['r265f_doublet'], 'R265F Weak Doublet Model', shift=1))
parts.append(include_file(files['r265f_hand'], 'R265F Handedness Selector', shift=1))
parts.append(include_file(files['r265f_eq'], 'R265F Equation Spine', shift=1))
parts.append(include_file(files['r266term'], 'R266F Native Terminology Patch', shift=1))
parts.append(include_file(files['r266f'], 'R266F - Frame-Rigidity Loading, Phi_relax, and Rigidity Resonance', shift=1))
parts.append(include_file(files['r266f_target'], 'R266F Microscopic Operator Target', shift=1))
parts.append(include_file(files['r266f_eq'], 'R266F Equation Spine', shift=1))
parts.append(include_file(files['r267f'], 'R267F - Quantum Bridge Retranslation', shift=1))
parts.append(include_file(files['r267f_wave'], 'R267F Wavefunction as Settlement Field', shift=1))
parts.append(include_file(files['r267f_born'], 'R267F Born Rule and Measurement', shift=1))
parts.append(include_file(files['r267f_int'], 'R267F Interference, Decoherence, Entanglement', shift=1))
parts.append(include_file(files['r267f_bell'], 'R267F Bell Obligation', shift=1))
parts.append(include_file(files['r267f_eq'], 'R267F Equation Spine', shift=1))
parts.append(include_file(files['r268f'], 'R268F - Native Action Stack', shift=1))
parts.append(include_file(files['r268_stack'], 'R268F Compact Native Stack', shift=1))
parts.append(include_file(files['r268_vertex'], 'R268F Explicit Vertex Rules', shift=1))
parts.append(include_file(files['r268_dirac'], 'R268F No Imported Dirac Guardrail', shift=1))
parts.append(include_file(files['r268_sm'], 'R268F Standard Model Correspondence', shift=1))
parts.append(include_file(files['r268_eq'], 'R268F Equation Spine', shift=1))
parts.append(include_file(files['r269_exec'], 'R269F Executive Summary', shift=1))
parts.append(include_file(files['r269'], 'R269F Main Rollup', shift=1))
parts.append(include_file(files['r269_mech'], 'R269F Mechanism Synthesis', shift=1))
parts.append(include_file(files['r269_claim'], 'R269F Claim Boundary', shift=1))
parts.append(include_file(files['r269_open'], 'R269F Open Obligations', shift=1))
parts.append(include_file(files['r269_insert'], 'R269F Manuscript Insert Draft', shift=1))

# Appendix: gate ledger and tables as markdown from CSVs
parts.append("\n# Appendix A - Gate Ledger\n\n")
ledger=Path('/mnt/data/SFT_V13_4_R269F_Mechanism_Rollup_Pack/R269F_Gate_Ledger.csv')
if ledger.exists():
    import csv
    with ledger.open(newline='', encoding='utf-8') as f:
        rows=list(csv.reader(f))
    # simple markdown table with wrapped cells by replacing very long verdicts
    rows=[[wrap_long_token_line(c,60).replace('\n','<br>') for c in r] for r in rows]
    header=rows[0]; data=rows[1:]
    parts.append('| '+' | '.join(header)+' |\n')
    parts.append('| '+' | '.join(['---']*len(header))+' |\n')
    for r in data:
        parts.append('| '+' | '.join(r)+' |\n')

parts.append("\n# Appendix B - Final Open Obligation List\n\n")
parts.append(r'''
The V13.4 force-sector result is an architecture, not a finished precision theory. The open obligations are deliberately preserved:

1. Bell correlations and no-signaling.
2. The microscopic form of \(\mathcal H_{\rm settle}\).
3. \(\Phi_{\rm relax}\), absolute mass scale, and frame-rigidity numerics.
4. \(\alpha\), \(p(E)\), and coupling running.
5. Full strong dynamics, \(\alpha_s\), confinement scale, and hadron spectra.
6. W/Z masses, Weinberg angle, weak rates, and precision electroweak tests.
7. Full quantum field bridge, spin-statistics, loops, and scattering amplitudes.
8. Fermion mass hierarchy, CKM/PMNS, neutrino structure, and CP phases.

''')

out.write_text('\n'.join(parts), encoding='utf-8')
print(out)
