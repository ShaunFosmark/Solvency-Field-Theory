#!/usr/bin/env python3
"""
SFT V13.4 scripts-only repro runner.

Purpose
-------
This runner intentionally ships scripts only, not result files. It expects the
V13.4 gate-pack directories or gate-pack zip files to be placed beside this
script bundle before rerun.

Typical layout after unzipping:
  SFT_V13_4_REPRO_SCRIPTS_ONLY/
    scripts/
      run_all_v13_4_repro.py
      build_sft_v13_4_pdf.py
      r262f_operator_screen.py

Recommended rerun layout:
  workdir/
    scripts/...
    SFT_V13_4_R262F_A_B_Dual_Gate_Test_Pack/
    SFT_V13_4_R262B_Move_Maxwell_Gate_Pack/
    ...
    SFT_V13_4_R269F_Mechanism_Rollup_Pack/

Or place the corresponding *.zip gate packs in workdir; this script can extract them.
"""

from __future__ import annotations

import argparse
import csv
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from datetime import datetime

REQUIRED_DIRS = [
    "SFT_V13_4_R262F_A_B_Dual_Gate_Test_Pack",
    "SFT_V13_4_R262B_Move_Maxwell_Gate_Pack",
    "SFT_V13_4_R262C_Conservation_Current_Noether_Gate_Pack",
    "SFT_V13_4_R262D_Coupling_Alpha_Running_Gate_Pack",
    "SFT_V13_4_R263F_Charge_Topology_Nine_Mode_Gate_Pack",
    "SFT_V13_4_R263B_Generation_Structure_Dperp3_Gate_Pack",
    "SFT_V13_4_R264F_Strong_Color_Confinement_AB_Gate_Pack",
    "SFT_V13_4_R265F_Weak_Branch_Mode_Transition_Gate_Pack",
    "SFT_V13_4_R266F_Native_Frame_Rigidity_Terminology_Patch",
    "SFT_V13_4_R266F_Higgs_PhiRelax_Historical_Rigidity_AB_Gate_Pack",
    "SFT_V13_4_R267F_Quantum_Bridge_Retranslation_Gate_Pack",
    "SFT_V13_4_R268F_Native_Action_Stack_Gate_Pack",
    "SFT_V13_4_R269F_Mechanism_Rollup_Pack",
]

OPTIONAL_EARLY_INPUTS = [
    "_r260_extract/SFT_V13_4_R260F_Forces_Inventory_V12_to_V13_Translation_Gate/report.md",
    "_r260_extract/SFT_V13_4_R260B_Force_Interaction_Mediator_Ontology_Gate/report.md",
    "_r260_extract/SFT_V13_4_R261F_Pitch_Twist_Independence_Confirmation/report.md",
]

def log(msg: str) -> None:
    print(f"[SFT V13.4 repro] {msg}")

def extract_gate_zips(root: Path) -> None:
    """Extract gate-pack zips in root if their directories are absent."""
    for zpath in sorted(root.glob("SFT_V13_4_*Gate_Pack.zip")) + sorted(root.glob("SFT_V13_4_*Rollup_Pack.zip")) + sorted(root.glob("SFT_V13_4_*Terminology_Patch.zip")):
        target_guess = root / zpath.stem
        if target_guess.exists():
            continue
        log(f"Extracting {zpath.name}")
        with zipfile.ZipFile(zpath, "r") as z:
            target_guess.mkdir(exist_ok=True)
            z.extractall(target_guess)

def check_inputs(root: Path) -> list[tuple[str, str]]:
    rows = []
    for d in REQUIRED_DIRS:
        status = "OK" if (root / d).exists() else "MISSING"
        rows.append((d, status))
    for rel in OPTIONAL_EARLY_INPUTS:
        status = "OK" if (root / rel).exists() else "OPTIONAL_MISSING"
        rows.append((rel, status))
    return rows

def write_manifest(outdir: Path, rows: list[tuple[str, str]]) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    with (outdir / "input_check_manifest.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["path", "status"])
        w.writerows(rows)

def run_py(script: Path, cwd: Path) -> int:
    log(f"Running {script.name}")
    return subprocess.call([sys.executable, str(script)], cwd=str(cwd))

def maybe_build_pdf(root: Path, md_path: Path, outdir: Path) -> None:
    """Use pandoc if available. PDF requires a TeX engine; DOCX usually works if pandoc exists."""
    pandoc = shutil.which("pandoc")
    if not pandoc:
        log("pandoc not found; skipping PDF/DOCX build. Markdown repro is the primary script output.")
        return

    docx = outdir / "SFT_V13_4_Forces_Full_Derivation.docx"
    pdf = outdir / "SFT_V13_4_Forces_Full_Derivation.pdf"

    log("Building DOCX via pandoc")
    subprocess.call([pandoc, str(md_path), "-o", str(docx)], cwd=str(root))

    # Try PDF. This may fail if LaTeX is unavailable; that is acceptable in scripts-only mode.
    log("Attempting PDF via pandoc")
    rc = subprocess.call([pandoc, str(md_path), "-o", str(pdf), "--pdf-engine=xelatex"], cwd=str(root))
    if rc != 0:
        log("PDF build did not complete. Install pandoc + xelatex or use the DOCX/MD output.")

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="working directory containing gate-pack dirs/zips")
    ap.add_argument("--extract-zips", action="store_true", help="extract matching gate-pack zips before checking")
    ap.add_argument("--skip-pdf", action="store_true", help="do not attempt pandoc PDF/DOCX build")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    scripts = Path(__file__).resolve().parent
    outdir = root / "repro_outputs"
    outdir.mkdir(exist_ok=True)

    log(f"root={root}")
    if args.extract_zips:
        extract_gate_zips(root)

    rows = check_inputs(root)
    write_manifest(outdir, rows)

    missing = [p for p, status in rows if status == "MISSING"]
    if missing:
        log("Required gate-pack directories are missing. See repro_outputs/input_check_manifest.csv")
        for p in missing:
            log(f"MISSING: {p}")
        log("Place the gate-pack dirs/zips beside this script bundle, or rerun with --extract-zips.")
        # Continue only if user wants to inspect scripts; do not hard fail silently.
        return 2

    # Run R262F operator screen if desired.
    r262_script = scripts / "r262f_operator_screen.py"
    if r262_script.exists():
        rc = run_py(r262_script, root)
        log(f"r262f_operator_screen exit={rc}")

    # Build master markdown using the assembler script.
    build_script = scripts / "build_sft_v13_4_pdf.py"
    if build_script.exists():
        # The original assembler writes to /mnt/data by default in ChatGPT runtime.
        # For portable use, users may edit base=Path('/mnt/data') to base=root.
        # To keep exact provenance, we do not auto-edit it here.
        log("Running PDF/MD assembler. If outside ChatGPT runtime, edit base path inside build_sft_v13_4_pdf.py first.")
        rc = run_py(build_script, root)
        log(f"build_sft_v13_4_pdf exit={rc}")

    md_path = root / "SFT_V13_4_Forces_Full_Derivation.md"
    if not md_path.exists():
        # Original ChatGPT path fallback
        alt = Path("/mnt/data/SFT_V13_4_Forces_Full_Derivation.md")
        if alt.exists():
            shutil.copy2(alt, outdir / alt.name)
            md_path = outdir / alt.name

    if md_path.exists() and not args.skip_pdf:
        maybe_build_pdf(root, md_path, outdir)

    log("Done.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
