#!/usr/bin/env python3
"""
Patch build_sft_v13_4_pdf.py for a local working directory.

The original ChatGPT-built assembler uses base=Path('/mnt/data') and absolute
paths. This helper copies it to build_sft_v13_4_pdf_LOCAL.py with a local root.

Usage:
  python scripts/patch_build_script_paths.py --root /path/to/workdir
"""

from __future__ import annotations

import argparse
from pathlib import Path

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="local workdir containing gate-pack directories")
    args = ap.parse_args()

    scripts = Path(__file__).resolve().parent
    src = scripts / "build_sft_v13_4_pdf.py"
    if not src.exists():
        raise SystemExit("missing scripts/build_sft_v13_4_pdf.py")

    root = Path(args.root).resolve()
    text = src.read_text(encoding="utf-8")
    text = text.replace("base=Path('/mnt/data')", f"base=Path({str(root)!r})")
    text = text.replace("'/mnt/data/", f"{str(root)!r} + '/")
    # The replacement above is conservative and may need manual review for edge cases.
    dst = scripts / "build_sft_v13_4_pdf_LOCAL.py"
    dst.write_text(text, encoding="utf-8")
    print(dst)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
