#!/usr/bin/env python3
"""Check for expected SFT V13.4 gate-pack directories/zips in a workdir."""
from __future__ import annotations
import argparse, csv, zipfile
from pathlib import Path

REQUIRED = [
"SFT_V13_4_R262F_A_B_Dual_Gate_Test_Pack",
"SFT_V13_4_R262B_Move_Maxwell_Gate_Pack",
"SFT_V13_4_R262C_Conservation_Current_Noether_Gate_Pack",
"SFT_V13_4_R262D_Coupling_Alpha_Running_Gate_Pack",
"SFT_V13_4_R263F_Charge_Topology_Nine_Mode_Gate_Pack",
"SFT_V13_4_R263B_Generation_Structure_Dperp3_Gate_Pack",
"SFT_V13_4_R264F_Strong_Color_Confinement_AB_Gate_Pack",
"SFT_V13_4_R265F_Weak_Branch_Mode_Transition_Gate_Pack",
"SFT_V13_4_R266F_Native_Frame_Rigidity_Terminology_Patch",
"SFT_V13_4_R266F_Higgs_PhiRelax_Historical_Rigidity_AB_Gate_Pack",
"SFT_V13_4_R267F_Quantum_Bridge_Retranslation_Gate_Pack",
"SFT_V13_4_R268F_Native_Action_Stack_Gate_Pack",
"SFT_V13_4_R269F_Mechanism_Rollup_Pack",
]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    args=ap.parse_args()
    root=Path(args.root).resolve()
    rows=[]
    for d in REQUIRED:
        exists=(root/d).exists()
        zip_exists=(root/(d+".zip")).exists()
        rows.append([d, "DIR_OK" if exists else ("ZIP_PRESENT" if zip_exists else "MISSING")])
    out=root/"v13_4_input_check.csv"
    with out.open("w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["item","status"]); w.writerows(rows)
    for r in rows:
        print(f"{r[1]:12s} {r[0]}")
    print("wrote", out)
if __name__=="__main__":
    main()
