# SFT V13.4 Repro Pack — Scripts Only

Generated: 2026-06-30 22:47:09

This pack intentionally contains **scripts only**, not result files, PDFs, DOCX,
gate reports, or CSV result tables.

The idea is exactly what Shaun requested:

> anyone rerunning the scripts will regenerate the results.

## Contents

- `scripts/build_sft_v13_4_pdf.py`  
  Assembles the V13.4 full derivation markdown from the gate-pack source files.

- `scripts/r262f_operator_screen.py`  
  R262F operator-screen script from the Maxwell/gauge foundation gate.

- `scripts/run_all_v13_4_repro.py`  
  Master runner/checker for reruns.

- `scripts/check_v13_4_inputs.py`  
  Checks whether the expected V13.4 gate-pack inputs are present.

- `scripts/patch_build_script_paths.py`  
  Helper to adapt the ChatGPT `/mnt/data` assembler path to a local workdir.

## Expected Inputs for Full Rerun

Place the V13.4 gate-pack directories or matching `.zip` files beside the
scripts before rerunning. The master runner can extract matching zips with:

```bash
python scripts/run_all_v13_4_repro.py --root . --extract-zips
```

For a quick check:

```bash
python scripts/check_v13_4_inputs.py --root .
```

## Notes

- This is a scripts-only reproducibility bundle; it does **not** duplicate the
  generated reports/results.
- The existing `build_sft_v13_4_pdf.py` was created in the ChatGPT runtime and
  uses `/mnt/data` paths. Use `patch_build_script_paths.py` or edit the `base`
  path before local reruns.
- PDF generation requires `pandoc` and a LaTeX engine such as `xelatex`. The
  markdown generation is the primary reproducible text output.
