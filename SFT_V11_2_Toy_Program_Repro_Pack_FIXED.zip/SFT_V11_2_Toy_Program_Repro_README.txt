SFT V11.2 Toy Program Repro Pack

Contents:
- CSV summaries from the retarded dent / dented bowl toy sequence
- PNG plots generated during the toy runs
- Organized by toy output folder

Status:
These are exploratory toy-model outputs. They are not theorem proofs and do not derive quantum mechanics.
They document the numerical experiments summarized in the SFT V11.2 Toy Program Addendum.

Main toy sequence:
1. Retarded dents as unresolved forcing
2. Dented internal lag bowl / ball-of-doom model
3. Dented bowl parameter scan
4. Photon-like transient crossings
5. Two-slit correlated dent toy
6. Which-way detector toy
7. Phase-vs-kick detector split
8. Quantum eraser analogue
