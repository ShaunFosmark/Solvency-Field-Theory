# SFT Track2R-03: Sealed Lambda Prediction Table

## Verdict

**TRACK2R03_SEALED_LAMBDA_PREDICTION_TABLE_READY_FOR_TRACK2R04**

Prediction table hash:

`f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b`

Selector hash:

`2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021`

## Claim boundary

Track2R-03 generates and seals the prediction table only. It does not join Track1 \(\lambda_{\rm best}\), does not validate the predictions, and does not read observed-velocity residuals.

## Hash checks

| Check | Pass | Observed | Required |
|---|---|---|---|
| parent_manifest_hash_matches_track2r01_file | True | 917160406652d7aeee603833eefdbd653ebb11d41eef0f7cdd5113a3cc806ca3 | 917160406652d7aeee603833eefdbd653ebb11d41eef0f7cdd5113a3cc806ca3 |
| selector_parent_hash_matches_track2r01 | True | 917160406652d7aeee603833eefdbd653ebb11d41eef0f7cdd5113a3cc806ca3 | 917160406652d7aeee603833eefdbd653ebb11d41eef0f7cdd5113a3cc806ca3 |
| selector_feature_hash_matches_current_feature_table | True | 8b5b0e5c4262d2f910c89da6be499f1543808c6043709a4ce50071060e47747c | 8b5b0e5c4262d2f910c89da6be499f1543808c6043709a4ce50071060e47747c |
| selector_hash_file_matches_manifest | True | 2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021 | 2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021 |
| selector_hash_recomputed_matches_file | True | 2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021 | 2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021 |
| selector_version_expected | True | SFT_TRACK2R_02_LAMBDA_READOUT_SELECTOR_v1 | SFT_TRACK2R_02_LAMBDA_READOUT_SELECTOR_v1 |
| prediction_table_sha256_written | True | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b | C:\Users\TaicHI\SPARC\SFT_TRACK2R_03_SEALED_LAMBDA_PREDICTIONS\track2r03_lambda_pred_table.csv |


## No-target audit

| Item | Detected | Used | Status |
|---|---|---|---|
| Track2R-01 allowed feature table | True | True | ALLOWED_PARENT_INPUT |
| Track2R-02 selector manifest | True | True | ALLOWED_SELECTOR_INPUT |
| Track2R-02 selector hash | True | True | ALLOWED_SELECTOR_INPUT |
| Track1 lambda_best | True | False | QUARANTINED |
| Track1B robustness | True | False | QUARANTINED |
| RAR_All_Data | True | False | QUARANTINED |
| Old Track2 Gate14C | True | False | QUARANTINED |
| Old Track2 Gate14D | True | False | QUARANTINED |
| Track1 lambda_best join | False | False | NOT_THIS_GATE |
| validation metrics | False | False | NOT_THIS_GATE |


## Prediction summary

| Field | N | Min | p16 | Median | p84 | Max | Mean | Std | Note |
|---|---|---|---|---|---|---|---|---|---|
| S_type | 175 | 0.0 | 0.09090909090909094 | 0.36363636363636365 | 0.6509090909090905 | 1.0 | 0.3833766233766233 | 0.2651103330994297 |  |
| S_source | 175 | 0.14644684312065823 | 0.14794091491025624 | 0.16152381085825748 | 0.42208969408126423 | 0.8502333731934014 | 0.24718470720979802 | 0.18916340777753457 |  |
| S_blend | 175 | 0.07322919004469708 | 0.12376071729475394 | 0.2571502775755746 | 0.5568363815358962 | 0.8531993233815731 | 0.3152806652932107 | 0.21077733760639591 |  |
| lambda_pred_primary_type_endpoint_linear | 175 | 1.1780972450961724 | 1.192209616754096 | 1.2345467317278673 | 1.279141826166906 | 1.3333333333333333 | 1.2376111324307306 | 0.04115469106160619 |  |
| lambda_pred_secondary_source_root_sphericity | 175 | 1.2008310801569047 | 1.2010630140170673 | 1.2031715696509673 | 1.2436207980905678 | 1.310084148039402 | 1.2164692321154695 | 0.029364987460995397 |  |
| lambda_pred_tertiary_equal_type_source_blend | 175 | 1.189465058103487 | 1.1973093747264352 | 1.2180162482761048 | 1.2645383467539402 | 1.3105445705445202 | 1.2270401822731 | 0.03272024937906031 |  |
| lambda_control_disk_endpoint | 175 | 1.1780972450961724 | 1.1780972450961724 | 1.1780972450961724 | 1.1780972450961724 | 1.1780972450961724 | 1.178097245096172 | 4.453635000155353e-16 |  |
| lambda_control_sphere_endpoint | 175 | 1.3333333333333333 | 1.3333333333333333 | 1.3333333333333333 | 1.3333333333333333 | 1.3333333333333333 | 1.3333333333333333 | 0.0 |  |
| lambda_control_endpoint_midpoint | 175 | 1.255715289214753 | 1.255715289214753 | 1.255715289214753 | 1.255715289214753 | 1.255715289214753 | 1.2557152892147525 | 4.453635000155353e-16 |  |
| NO_TARGET_SANITY_SPEARMAN_Type_vs_primary_lambda | 175 |  |  | -0.9999999999999999 |  |  |  |  | Algebraic sanity check only, not validation against lambda_best. |


## Gate blueprint

| Gate | Task | Success criterion | Output |
|---|---|---|---|
| Track2R-03 | Generate sealed per-galaxy lambda_pred table using Track2R-02 selector hash. | Prediction table SHA-256 written before any target join. | track2r03_lambda_pred_table.csv + sha256 |
| Track2R-04 | Validate sealed lambda_pred against Track1 lambda_best. | Report primary, secondary, and controls without changing predictions. | lambda prediction validation report |
| Track2R-05 | Use sealed lambda_pred to predict rotation curves. | Compare with controls and Track1 best-lambda ceiling. | rotation-curve validation report |


## Next step

Track2R-04 may now join this sealed prediction table to Track1 \(\lambda_{\rm best}\) for validation. Any selector change after this point is a new fork.
