#!/usr/bin/env python3
"""
SFT Track2R-06:
Closure Diagnostic for the SPARC Morphology-Readout Track

Purpose
-------
Close Track2R cleanly after the frozen validation sequence.

Track2R-04 showed that the sealed no-target morphology lambda selector
predicts the direction of Track1 lambda_best structure.

Track2R-05 showed that this directional lambda success does not improve
full-sample rotation curves over the best fixed-lambda control.

Track2R-06 is a no-retuning closure diagnostic. It does not introduce a
new model, does not repair the selector, and does not fit a correction.
It only classifies what survived and what remains open.

Expected conclusion if the current Track2R outputs are unchanged:
    TRACK2R06_MORPHOLOGY_DIRECTION_VALIDATED_AMPLITUDE_CLOSURE_OPEN

Inputs
------
    SFT_TRACK2R_04_LAMBDA_PREDICTION_VALIDATION/
        track2r04_verdict.csv
        track2r04_selector_metrics.csv
        track2r04_selector_rankings.csv
        track2r04_hash_checks.csv
        track2r04_no_retuning_audit.csv

    SFT_TRACK2R_05_ROTATION_CURVE_VALIDATION/
        track2r05_verdict.csv
        track2r05_selector_metrics.csv
        track2r05_selector_rankings.csv
        track2r05_per_galaxy_metrics.csv
        track2r05_hash_checks.csv
        track2r05_no_retuning_audit.csv

Outputs
-------
    track2r06_closure_verdict.csv
    track2r06_lambda_space_vs_curve_space_summary.csv
    track2r06_failure_mode_by_group.csv
    track2r06_help_hurt_by_galaxy.csv
    track2r06_public_claim_table.csv
    track2r06_no_retuning_audit.csv
    track2r06_manifest.json
    TRACK2R_06_closure_diagnostic_report.md

Run
---
    python SFT_TRACK2R_06_closure_diagnostic.py --sparc-dir "C:\\Users\\TaicHI\\SPARC"

Claim boundary
--------------
This is a closure/interpretation gate only. Any new selector, correction,
amplitude law, or rotation-curve repair after this point is a new
predeclared fork.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np

PROTOCOL_VERSION = "SFT_TRACK2R_06_CLOSURE_DIAGNOSTIC_v1"
OUT_DIR_NAME = "SFT_TRACK2R_06_CLOSURE_DIAGNOSTIC"

EXPECTED_TRACK2R04_VERDICT = "TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS"
EXPECTED_TRACK2R05_VERDICT = "TRACK2R05_DIRECTIONAL_LAMBDA_VALIDATION_DOES_NOT_IMPROVE_ROTATION_CURVES"


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def safe_int(x: Any, default: int = -999) -> int:
    try:
        if x is None or x == "":
            return default
        return int(float(x))
    except Exception:
        return default


def boolish(x: Any) -> bool:
    s = str(x).strip().lower()
    if s in ("true", "t", "1", "yes", "y"):
        return True
    if s in ("false", "f", "0", "no", "n", "", "nan", "none"):
        return False
    try:
        return bool(float(s))
    except Exception:
        return bool(s)


def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    if not path.exists():
        return ""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def find_paths(sparc_dir: Path, t2r04_dir_arg: str | None, t2r05_dir_arg: str | None) -> dict:
    t2r04 = Path(t2r04_dir_arg).expanduser() if t2r04_dir_arg else sparc_dir / "SFT_TRACK2R_04_LAMBDA_PREDICTION_VALIDATION"
    t2r05 = Path(t2r05_dir_arg).expanduser() if t2r05_dir_arg else sparc_dir / "SFT_TRACK2R_05_ROTATION_CURVE_VALIDATION"
    if not t2r04.is_absolute():
        t2r04 = sparc_dir / t2r04
    if not t2r05.is_absolute():
        t2r05 = sparc_dir / t2r05

    return {
        "track2r04_dir": t2r04,
        "track2r04_verdict": t2r04 / "track2r04_verdict.csv",
        "track2r04_selector_metrics": t2r04 / "track2r04_selector_metrics.csv",
        "track2r04_selector_rankings": t2r04 / "track2r04_selector_rankings.csv",
        "track2r04_hash_checks": t2r04 / "track2r04_hash_checks.csv",
        "track2r04_no_retuning_audit": t2r04 / "track2r04_no_retuning_audit.csv",

        "track2r05_dir": t2r05,
        "track2r05_verdict": t2r05 / "track2r05_verdict.csv",
        "track2r05_selector_metrics": t2r05 / "track2r05_selector_metrics.csv",
        "track2r05_selector_rankings": t2r05 / "track2r05_selector_rankings.csv",
        "track2r05_per_galaxy_metrics": t2r05 / "track2r05_per_galaxy_metrics.csv",
        "track2r05_hash_checks": t2r05 / "track2r05_hash_checks.csv",
        "track2r05_no_retuning_audit": t2r05 / "track2r05_no_retuning_audit.csv",
    }


def first(rows: list[dict]) -> dict:
    return rows[0] if rows else {}


def get_metric(rows: list[dict], group: str, selector_short: str | None = None, selector_name: str | None = None) -> dict:
    for r in rows:
        if str(r.get("group")) != group:
            continue
        if selector_short is not None and str(r.get("selector_short")) == selector_short:
            return r
        if selector_name is not None and str(r.get("selector")) == selector_name:
            return r
    return {}


def all_hash_checks_pass(rows: list[dict]) -> bool:
    if not rows:
        return False
    return all(str(r.get("pass", "")).strip().lower() == "true" for r in rows)


def build_no_retuning_audit(paths: dict, t2r04_hash: bool, t2r05_hash: bool) -> list[dict]:
    return [
        {"item": "Track2R-04 verdict", "detected": paths["track2r04_verdict"].exists(), "used": True, "status": "CLOSURE_INPUT"},
        {"item": "Track2R-04 selector metrics", "detected": paths["track2r04_selector_metrics"].exists(), "used": True, "status": "CLOSURE_INPUT"},
        {"item": "Track2R-04 hash checks all pass", "detected": bool(t2r04_hash), "used": True, "status": "LOCKBOX_CONFIRMATION"},
        {"item": "Track2R-05 verdict", "detected": paths["track2r05_verdict"].exists(), "used": True, "status": "CLOSURE_INPUT"},
        {"item": "Track2R-05 selector metrics", "detected": paths["track2r05_selector_metrics"].exists(), "used": True, "status": "CLOSURE_INPUT"},
        {"item": "Track2R-05 per-galaxy metrics", "detected": paths["track2r05_per_galaxy_metrics"].exists(), "used": True, "status": "CLOSURE_INPUT"},
        {"item": "Track2R-05 hash checks all pass", "detected": bool(t2r05_hash), "used": True, "status": "LOCKBOX_CONFIRMATION"},
        {"item": "new selector introduced", "detected": False, "used": False, "status": "NO"},
        {"item": "lambda_pred modified", "detected": False, "used": False, "status": "NO"},
        {"item": "rotation residuals used for repair", "detected": False, "used": False, "status": "NO"},
        {"item": "new coefficient or amplitude law fitted", "detected": False, "used": False, "status": "NO"},
        {"item": "new public success claim introduced", "detected": False, "used": False, "status": "NO"},
    ]


def lambda_curve_summary(t2r04_metrics: list[dict], t2r05_metrics: list[dict], t2r04_verdict: dict, t2r05_verdict: dict) -> list[dict]:
    l_primary = get_metric(t2r04_metrics, "FULL", selector_short="primary")
    l_source = get_metric(t2r04_metrics, "FULL", selector_short="secondary_source")
    l_blend = get_metric(t2r04_metrics, "FULL", selector_short="tertiary_blend")
    l_disk = get_metric(t2r04_metrics, "FULL", selector_short="control_disk")
    l_sphere = get_metric(t2r04_metrics, "FULL", selector_short="control_sphere")
    l_mid = get_metric(t2r04_metrics, "FULL", selector_short="control_midpoint")

    c_primary = get_metric(t2r05_metrics, "FULL", selector_short="primary")
    c_source = get_metric(t2r05_metrics, "FULL", selector_short="secondary_source")
    c_blend = get_metric(t2r05_metrics, "FULL", selector_short="tertiary_blend")
    c_disk = get_metric(t2r05_metrics, "FULL", selector_short="control_disk")
    c_sphere = get_metric(t2r05_metrics, "FULL", selector_short="control_sphere")
    c_mid = get_metric(t2r05_metrics, "FULL", selector_short="control_midpoint")
    c_ceiling = get_metric(t2r05_metrics, "FULL", selector_short="ceiling_best")

    best_lambda_control_rmse = min(
        [safe_float(x.get("rmse"), float("inf")) for x in [l_disk, l_sphere, l_mid] if x],
        default=float("inf")
    )
    best_curve_control_rms = min(
        [safe_float(x.get("rms_V_km_s"), float("inf")) for x in [c_disk, c_sphere, c_mid] if x],
        default=float("inf")
    )

    rows = [
        {
            "domain": "lambda_space",
            "test": "Track2R-04 primary directional validation",
            "selector": "PRIMARY_TYPE_ENDPOINT_LINEAR",
            "metric_primary": "Spearman rho",
            "value_primary": safe_float(l_primary.get("spearman_rho")),
            "p_value": safe_float(l_primary.get("spearman_p")),
            "error_metric": "RMSE(lambda)",
            "error_value": safe_float(l_primary.get("rmse")),
            "best_control_error": best_lambda_control_rmse,
            "delta_vs_best_control": safe_float(l_primary.get("rmse")) - best_lambda_control_rmse,
            "status": "PASS" if str(t2r04_verdict.get("verdict")) == EXPECTED_TRACK2R04_VERDICT else "REVIEW",
            "interpretation": "Morphology Type selector recovers fitted lambda direction and beats fixed lambda controls in lambda-space.",
        },
        {
            "domain": "lambda_space",
            "test": "Track2R-04 blend directional validation",
            "selector": "TERTIARY_EQUAL_TYPE_SOURCE_BLEND",
            "metric_primary": "Spearman rho",
            "value_primary": safe_float(l_blend.get("spearman_rho")),
            "p_value": safe_float(l_blend.get("spearman_p")),
            "error_metric": "RMSE(lambda)",
            "error_value": safe_float(l_blend.get("rmse")),
            "best_control_error": best_lambda_control_rmse,
            "delta_vs_best_control": safe_float(l_blend.get("rmse")) - best_lambda_control_rmse,
            "status": "SUPPORTING_SIGNAL",
            "interpretation": "Blend has slightly higher rank correlation than primary but worse amplitude RMSE than primary.",
        },
        {
            "domain": "curve_space",
            "test": "Track2R-05 primary rotation validation",
            "selector": "PRIMARY_TYPE_ENDPOINT_LINEAR",
            "metric_primary": "RMS velocity residual km/s",
            "value_primary": safe_float(c_primary.get("rms_V_km_s")),
            "p_value": "",
            "error_metric": "RMS V km/s",
            "error_value": safe_float(c_primary.get("rms_V_km_s")),
            "best_control_error": best_curve_control_rms,
            "delta_vs_best_control": safe_float(c_primary.get("delta_rms_V_vs_best_constant_control")),
            "status": "FAIL_FULL_SAMPLE" if str(t2r05_verdict.get("verdict")) == EXPECTED_TRACK2R05_VERDICT else "REVIEW",
            "interpretation": "Directional lambda predictor does not improve full-sample rotation curves over best fixed lambda control.",
        },
        {
            "domain": "curve_space",
            "test": "Track2R-05 fit ceiling gap",
            "selector": "TRACK1_LAMBDA_BEST_FIT_CEILING",
            "metric_primary": "RMS velocity residual km/s",
            "value_primary": safe_float(c_ceiling.get("rms_V_km_s")),
            "p_value": "",
            "error_metric": "primary minus ceiling RMS V",
            "error_value": safe_float(c_primary.get("delta_rms_V_vs_ceiling_best")),
            "best_control_error": "",
            "delta_vs_best_control": "",
            "status": "AMPLITUDE_GAP",
            "interpretation": "Fitted per-galaxy lambda ceiling remains much better than sealed morphology predictor; amplitude/readout closure is open.",
        },
    ]

    # Add compact selector comparison rows.
    selector_rows = [
        ("primary", l_primary, c_primary),
        ("source", l_source, c_source),
        ("blend", l_blend, c_blend),
        ("disk_control", l_disk, c_disk),
        ("sphere_control", l_sphere, c_sphere),
        ("midpoint_control", l_mid, c_mid),
    ]
    for label, lm, cm in selector_rows:
        rows.append({
            "domain": "selector_comparison",
            "test": label,
            "selector": lm.get("selector", cm.get("selector", label)),
            "metric_primary": "lambda rho / curve RMS",
            "value_primary": safe_float(lm.get("spearman_rho")),
            "p_value": safe_float(lm.get("spearman_p")),
            "error_metric": "curve RMS V km/s",
            "error_value": safe_float(cm.get("rms_V_km_s")),
            "best_control_error": best_curve_control_rms,
            "delta_vs_best_control": safe_float(cm.get("delta_rms_V_vs_best_constant_control")),
            "status": "DIAGNOSTIC",
            "interpretation": "Side-by-side selector diagnostic.",
        })

    return rows


def failure_mode_by_group(t2r05_metrics: list[dict]) -> list[dict]:
    rows = []
    groups = sorted(set(r.get("group", "") for r in t2r05_metrics if r.get("selector_short") == "primary" and r.get("status") == "OK"))

    for g in groups:
        p = get_metric(t2r05_metrics, g, selector_short="primary")
        disk = get_metric(t2r05_metrics, g, selector_short="control_disk")
        sphere = get_metric(t2r05_metrics, g, selector_short="control_sphere")
        mid = get_metric(t2r05_metrics, g, selector_short="control_midpoint")
        ceiling = get_metric(t2r05_metrics, g, selector_short="ceiling_best")

        controls = [x for x in [disk, sphere, mid] if x]
        if not p or not controls:
            continue
        best_control = min(controls, key=lambda x: safe_float(x.get("rms_V_km_s"), float("inf")))
        delta_control = safe_float(p.get("rms_V_km_s")) - safe_float(best_control.get("rms_V_km_s"))
        delta_ceiling = safe_float(p.get("rms_V_km_s")) - safe_float(ceiling.get("rms_V_km_s")) if ceiling else float("nan")

        if delta_control < 0:
            mode = "LOCAL_HELP"
            interp = "Primary sealed morphology predictor beats the best constant control in this group."
        elif abs(delta_control) <= 0.1:
            mode = "NEAR_TIE"
            interp = "Primary is effectively tied with the best constant control at this group scale."
        else:
            mode = "HURT"
            interp = "Primary underperforms the best constant control in this group."

        rows.append({
            "group": g,
            "row_N": safe_int(p.get("row_N")),
            "galaxy_N": safe_int(p.get("galaxy_N")),
            "primary_rms_V_km_s": safe_float(p.get("rms_V_km_s")),
            "primary_mae_V_km_s": safe_float(p.get("mae_V_km_s")),
            "primary_rms_log10V": safe_float(p.get("rms_log10V")),
            "best_constant_control": best_control.get("selector", ""),
            "best_constant_control_rms_V_km_s": safe_float(best_control.get("rms_V_km_s")),
            "delta_primary_minus_best_constant_rms_V": delta_control,
            "ceiling_best_rms_V_km_s": safe_float(ceiling.get("rms_V_km_s")) if ceiling else "",
            "delta_primary_minus_ceiling_rms_V": delta_ceiling,
            "failure_mode": mode,
            "interpretation": interp,
        })

    # Put important groups first, then by delta.
    priority = {
        "FULL": 0,
        "INTERIOR_NON_EDGE": 1,
        "Q1_ONLY": 2,
        "Q1_Q2": 3,
        "TYPE_2_TO_10": 4,
        "TYPE_2_TO_10_INTERIOR": 5,
        "LOW_ACCEL_LOGGBAR_LT_MINUS11": 6,
        "MID_ACCEL_1E11_TO_1E10": 7,
        "HIGH_ACCEL_GE_1E10": 8,
        "NPOINTS_GE_MEDIAN": 9,
        "NPOINTS_GE_MEDIAN_INTERIOR": 10,
    }
    rows.sort(key=lambda r: (priority.get(r["group"], 99), safe_float(r["delta_primary_minus_best_constant_rms_V"])))
    return rows


def help_hurt_by_galaxy(per_gal: list[dict]) -> list[dict]:
    rows = []
    for r in per_gal:
        primary = safe_float(r.get("primary_rms_V_km_s"))
        controls = {
            "control_disk": safe_float(r.get("control_disk_rms_V_km_s")),
            "control_sphere": safe_float(r.get("control_sphere_rms_V_km_s")),
            "control_midpoint": safe_float(r.get("control_midpoint_rms_V_km_s")),
        }
        finite_controls = {k: v for k, v in controls.items() if math.isfinite(v)}
        if not math.isfinite(primary) or not finite_controls:
            continue
        best_control_name, best_control_val = min(finite_controls.items(), key=lambda kv: kv[1])
        delta = primary - best_control_val
        ceiling = safe_float(r.get("ceiling_best_rms_V_km_s"))
        rows.append({
            "Galaxy": r.get("Galaxy", ""),
            "Galaxy_key": r.get("Galaxy_key", ""),
            "Type": safe_float(r.get("Type")),
            "Q": safe_int(r.get("Q")),
            "edge_any": r.get("edge_any", ""),
            "row_N": safe_int(r.get("row_N")),
            "primary_rms_V_km_s": primary,
            "best_constant_control": best_control_name,
            "best_constant_control_rms_V_km_s": best_control_val,
            "delta_primary_minus_best_constant_rms_V": delta,
            "ceiling_best_rms_V_km_s": ceiling,
            "delta_primary_minus_ceiling_rms_V": primary - ceiling if math.isfinite(ceiling) else "",
            "help_hurt": "HELP" if delta < 0 else ("TIE_NEAR_ZERO" if abs(delta) <= 0.1 else "HURT"),
            "best_prediction_selector_by_rms": r.get("best_prediction_selector_by_rms", ""),
            "best_constant_control_by_rms": r.get("best_constant_control_by_rms", ""),
        })
    rows.sort(key=lambda r: safe_float(r["delta_primary_minus_best_constant_rms_V"]))
    return rows


def summarize_help_hurt(help_rows: list[dict]) -> dict:
    n = len(help_rows)
    if not n:
        return {
            "galaxy_N": 0,
            "help_N": 0,
            "hurt_N": 0,
            "tie_N": 0,
            "help_fraction": float("nan"),
            "median_delta_rms": float("nan"),
            "mean_delta_rms": float("nan"),
        }
    deltas = np.array([safe_float(r["delta_primary_minus_best_constant_rms_V"]) for r in help_rows], dtype=float)
    finite = deltas[np.isfinite(deltas)]
    help_n = sum(r["help_hurt"] == "HELP" for r in help_rows)
    hurt_n = sum(r["help_hurt"] == "HURT" for r in help_rows)
    tie_n = sum(r["help_hurt"] == "TIE_NEAR_ZERO" for r in help_rows)
    return {
        "galaxy_N": n,
        "help_N": help_n,
        "hurt_N": hurt_n,
        "tie_N": tie_n,
        "help_fraction": help_n / n if n else float("nan"),
        "median_delta_rms": float(np.median(finite)) if finite.size else float("nan"),
        "mean_delta_rms": float(np.mean(finite)) if finite.size else float("nan"),
        "p16_delta_rms": float(np.percentile(finite, 16)) if finite.size else float("nan"),
        "p84_delta_rms": float(np.percentile(finite, 84)) if finite.size else float("nan"),
    }


def public_claim_table(t2r04_verdict: dict, t2r05_verdict: dict, group_rows: list[dict], help_summary: dict) -> list[dict]:
    full = next((r for r in group_rows if r.get("group") == "FULL"), {})
    interior = next((r for r in group_rows if r.get("group") == "INTERIOR_NON_EDGE"), {})
    low_acc = next((r for r in group_rows if r.get("group") == "LOW_ACCEL_LOGGBAR_LT_MINUS11"), {})
    type_int = next((r for r in group_rows if r.get("group") == "TYPE_2_TO_10_INTERIOR"), {})

    return [
        {
            "claim": "SPARC morphology-lambda structure exists",
            "status": "SUPPORTED_BY_TRACK1_AND_TRACK2R04",
            "allowed_wording": "The fitted per-galaxy lambda structure is morphology-linked, and a frozen no-target morphology selector recovers the direction of that structure.",
            "forbidden_wording": "SFT fully predicts each galaxy's lambda or rotation curve from morphology alone.",
            "basis": "Track1/Track1B morphology-lambda correlation plus Track2R-04 directional validation.",
        },
        {
            "claim": "No-target morphology readout validates lambda direction",
            "status": "SUPPORTED",
            "allowed_wording": f"Track2R-04 primary selector verdict: {t2r04_verdict.get('verdict','')}.",
            "forbidden_wording": "The selector is a precision lambda predictor.",
            "basis": "Primary selector positive rank correlation and beats constant controls in lambda-space.",
        },
        {
            "claim": "No-target morphology readout improves full-sample rotation curves",
            "status": "NOT_SUPPORTED",
            "allowed_wording": f"Track2R-05 verdict: {t2r05_verdict.get('verdict','')}. Full-sample primary delta RMS vs best constant = {full.get('delta_primary_minus_best_constant_rms_V','')}.",
            "forbidden_wording": "Track2R-05 proves SFT beats fixed-lambda controls on SPARC rotation curves.",
            "basis": "Primary sealed predictor is worse than best constant control in full-sample curve residuals.",
        },
        {
            "claim": "There are domain-local hints where morphology readout helps",
            "status": "WEAK_LOCAL_SUPPORT",
            "allowed_wording": f"Small local improvements appear in selected groups, e.g. low-acceleration delta RMS {low_acc.get('delta_primary_minus_best_constant_rms_V','')} and Type 2-10 interior delta RMS {type_int.get('delta_primary_minus_best_constant_rms_V','')}.",
            "forbidden_wording": "These pockets establish a final amplitude law.",
            "basis": "Track2R-05 subgroup diagnostics.",
        },
        {
            "claim": "Amplitude/readout closure remains open",
            "status": "OPEN_PROBLEM",
            "allowed_wording": "The first sealed Type-endpoint morphology predictor captures direction but is amplitude-limited; any amplitude correction requires a new predeclared fork.",
            "forbidden_wording": "We can repair the selector after seeing residuals and keep the same validation status.",
            "basis": "Track2R-05 full-sample failure plus fit-ceiling gap.",
        },
        {
            "claim": "Track2R final status",
            "status": "CLOSED_WITH_CAUTION",
            "allowed_wording": "Track2R closes as a directional morphology-readout validation with amplitude closure open.",
            "forbidden_wording": "Track2R is a completed rotation-curve solution.",
            "basis": f"Help fraction by galaxy = {help_summary.get('help_fraction','')}; median per-galaxy delta RMS = {help_summary.get('median_delta_rms','')}.",
        },
    ]


def closure_verdict(t2r04_verdict: dict, t2r05_verdict: dict, t2r04_hash_ok: bool, t2r05_hash_ok: bool,
                    summary_rows: list[dict], group_rows: list[dict], help_summary: dict) -> dict:
    v04 = str(t2r04_verdict.get("verdict", ""))
    v05 = str(t2r05_verdict.get("verdict", ""))

    full = next((r for r in group_rows if r.get("group") == "FULL"), {})
    primary_full_delta = safe_float(full.get("delta_primary_minus_best_constant_rms_V"))

    if not (t2r04_hash_ok and t2r05_hash_ok):
        verdict = "TRACK2R06_CLOSURE_REQUIRES_REVIEW_LOCKBOX_FAILURE"
        interpretation = "One or more prior hash checks did not pass."
    elif v04 == EXPECTED_TRACK2R04_VERDICT and v05 == EXPECTED_TRACK2R05_VERDICT:
        verdict = "TRACK2R06_MORPHOLOGY_DIRECTION_VALIDATED_AMPLITUDE_CLOSURE_OPEN"
        interpretation = (
            "Track2R-04 validates the no-target morphology direction in lambda-space, "
            "while Track2R-05 shows that the same sealed predictor does not improve full-sample rotation curves. "
            "Amplitude/readout closure remains open."
        )
    elif v04 == EXPECTED_TRACK2R04_VERDICT and math.isfinite(primary_full_delta) and primary_full_delta < 0:
        verdict = "TRACK2R06_MORPHOLOGY_DIRECTION_AND_ROTATION_SCAFFOLD_SUPPORTED"
        interpretation = "Both lambda-space direction and rotation-curve scaffold improved over constants."
    else:
        verdict = "TRACK2R06_TRACK2R_CLOSURE_INCONCLUSIVE_OR_REQUIRES_REVIEW"
        interpretation = "The prior Track2R verdict pattern does not match the expected closure case."

    return {
        "verdict": verdict,
        "track2r06_version": PROTOCOL_VERSION,
        "claim_boundary": "Closure diagnostic only; no selector repair, no refit, no retuning, no new amplitude law",
        "track2r04_verdict": v04,
        "track2r05_verdict": v05,
        "track2r04_hash_checks_pass": t2r04_hash_ok,
        "track2r05_hash_checks_pass": t2r05_hash_ok,
        "full_sample_primary_delta_rms_vs_best_constant": primary_full_delta,
        "help_fraction_by_galaxy": help_summary.get("help_fraction"),
        "help_N": help_summary.get("help_N"),
        "hurt_N": help_summary.get("hurt_N"),
        "tie_N": help_summary.get("tie_N"),
        "median_per_galaxy_delta_rms": help_summary.get("median_delta_rms"),
        "interpretation": interpretation,
        "main_result": (
            "Track2R should be reported as directional morphology-readout support, "
            "not as a completed rotation-curve prediction law."
        ),
        "next_step": (
            "Package Track2R as a cautionary support lane for the SPARC morphology paper, "
            "or start a new predeclared Track3 amplitude/readout fork."
        ),
    }


def write_report(path: Path, verdict: dict, summary_rows: list[dict], group_rows: list[dict],
                 help_summary: dict, claim_rows: list[dict], audit_rows: list[dict]) -> None:
    def table(rows, cols, limit=None):
        rows2 = rows[:limit] if limit else rows
        lines = ["| " + " | ".join(label for _, label in cols) + " |\n",
                 "|" + "|".join("---" for _ in cols) + "|\n"]
        for r in rows2:
            lines.append("| " + " | ".join(str(r.get(k, "")) for k, _ in cols) + " |\n")
        if limit and len(rows) > limit:
            lines.append("| ... | ... | ... | ... | ... |\n")
        return "".join(lines)

    helpful = [r for r in group_rows if str(r.get("failure_mode")) == "LOCAL_HELP"]
    hurt = [r for r in group_rows if str(r.get("failure_mode")) == "HURT"]

    text = f"""# SFT Track2R-06 Closure Diagnostic

## Verdict

**{verdict['verdict']}**

{verdict['interpretation']}

## Claim boundary

{verdict['claim_boundary']}

## Executive conclusion

Track2R closes as follows:

1. The morphology-readout direction survived in lambda-space.
2. The first sealed Type-endpoint predictor did not improve full-sample rotation curves over the best constant-lambda control.
3. Small domain-local improvements exist, but they are not a completed amplitude law.
4. Any repair, correction, or expanded readout must be treated as a new predeclared fork.

## Lambda-space versus curve-space summary

{table(summary_rows, [('domain','Domain'),('test','Test'),('selector','Selector'),('metric_primary','Metric'),('value_primary','Value'),('p_value','p'),('error_metric','Error metric'),('error_value','Error'),('best_control_error','Best control'),('delta_vs_best_control','Delta vs control'),('status','Status')])}

## Failure mode by group

{table(group_rows, [('group','Group'),('row_N','Rows'),('galaxy_N','Galaxies'),('primary_rms_V_km_s','Primary RMS V'),('best_constant_control','Best constant'),('delta_primary_minus_best_constant_rms_V','Delta RMS'),('failure_mode','Mode'),('interpretation','Interpretation')])}

## Local-help groups

{table(helpful, [('group','Group'),('row_N','Rows'),('galaxy_N','Galaxies'),('delta_primary_minus_best_constant_rms_V','Delta RMS'),('interpretation','Interpretation')])}

## Hurt groups

{table(hurt, [('group','Group'),('row_N','Rows'),('galaxy_N','Galaxies'),('delta_primary_minus_best_constant_rms_V','Delta RMS'),('interpretation','Interpretation')])}

## Per-galaxy help/hurt summary

| Metric | Value |
|---|---|
| galaxy_N | {help_summary.get('galaxy_N')} |
| help_N | {help_summary.get('help_N')} |
| hurt_N | {help_summary.get('hurt_N')} |
| tie_N | {help_summary.get('tie_N')} |
| help_fraction | {help_summary.get('help_fraction')} |
| median_delta_rms | {help_summary.get('median_delta_rms')} |
| mean_delta_rms | {help_summary.get('mean_delta_rms')} |

## Public claim table

{table(claim_rows, [('claim','Claim'),('status','Status'),('allowed_wording','Allowed wording'),('forbidden_wording','Forbidden wording'),('basis','Basis')])}

## No-retuning audit

{table(audit_rows, [('item','Item'),('detected','Detected'),('used','Used'),('status','Status')])}

## Recommended use

Use Track2R as a support lane for the SPARC morphology paper:

> A frozen no-target morphology selector recovers the direction of the fitted lambda structure, but the first Type-endpoint readout does not close the amplitude into full-sample rotation-curve improvement.

Do not use Track2R-05 as a rotation-curve success claim.
"""
    path.write_text(text, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sparc-dir", default=r"C:\Users\TaicHI\SPARC")
    ap.add_argument("--track2r04-dir", default=None)
    ap.add_argument("--track2r05-dir", default=None)
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    sparc_dir = Path(args.sparc_dir).expanduser().resolve()
    out = Path(args.out_dir).expanduser().resolve() if args.out_dir else sparc_dir / OUT_DIR_NAME
    out.mkdir(parents=True, exist_ok=True)

    paths = find_paths(sparc_dir, args.track2r04_dir, args.track2r05_dir)

    required = [
        paths["track2r04_verdict"],
        paths["track2r04_selector_metrics"],
        paths["track2r04_hash_checks"],
        paths["track2r05_verdict"],
        paths["track2r05_selector_metrics"],
        paths["track2r05_per_galaxy_metrics"],
        paths["track2r05_hash_checks"],
    ]
    missing = [p for p in required if not p.exists()]
    if missing:
        print("ERROR: missing Track2R closure input files:", file=sys.stderr)
        for p in missing:
            print(f"  {p}", file=sys.stderr)
        sys.exit(2)

    t2r04_verdict = first(read_csv(paths["track2r04_verdict"]))
    t2r04_metrics = read_csv(paths["track2r04_selector_metrics"])
    t2r04_hash_checks = read_csv(paths["track2r04_hash_checks"])

    t2r05_verdict = first(read_csv(paths["track2r05_verdict"]))
    t2r05_metrics = read_csv(paths["track2r05_selector_metrics"])
    t2r05_hash_checks = read_csv(paths["track2r05_hash_checks"])
    t2r05_per_gal = read_csv(paths["track2r05_per_galaxy_metrics"])

    t2r04_hash_ok = all_hash_checks_pass(t2r04_hash_checks)
    t2r05_hash_ok = all_hash_checks_pass(t2r05_hash_checks)

    audit_rows = build_no_retuning_audit(paths, t2r04_hash_ok, t2r05_hash_ok)
    summary_rows = lambda_curve_summary(t2r04_metrics, t2r05_metrics, t2r04_verdict, t2r05_verdict)
    group_rows = failure_mode_by_group(t2r05_metrics)
    help_rows = help_hurt_by_galaxy(t2r05_per_gal)
    help_summary = summarize_help_hurt(help_rows)
    claim_rows = public_claim_table(t2r04_verdict, t2r05_verdict, group_rows, help_summary)
    verdict = closure_verdict(t2r04_verdict, t2r05_verdict, t2r04_hash_ok, t2r05_hash_ok, summary_rows, group_rows, help_summary)

    write_csv(out / "track2r06_closure_verdict.csv", [verdict])
    write_csv(out / "track2r06_lambda_space_vs_curve_space_summary.csv", summary_rows)
    write_csv(out / "track2r06_failure_mode_by_group.csv", group_rows)
    write_csv(out / "track2r06_help_hurt_by_galaxy.csv", help_rows)
    write_csv(out / "track2r06_help_hurt_summary.csv", [help_summary])
    write_csv(out / "track2r06_public_claim_table.csv", claim_rows)
    write_csv(out / "track2r06_no_retuning_audit.csv", audit_rows)

    manifest = {
        "track2r06_version": PROTOCOL_VERSION,
        "verdict": verdict,
        "input_files": {k: str(v) for k, v in paths.items() if isinstance(v, Path)},
        "input_sha256": {
            "track2r04_verdict": sha256_file(paths["track2r04_verdict"]),
            "track2r04_selector_metrics": sha256_file(paths["track2r04_selector_metrics"]),
            "track2r04_hash_checks": sha256_file(paths["track2r04_hash_checks"]),
            "track2r05_verdict": sha256_file(paths["track2r05_verdict"]),
            "track2r05_selector_metrics": sha256_file(paths["track2r05_selector_metrics"]),
            "track2r05_per_galaxy_metrics": sha256_file(paths["track2r05_per_galaxy_metrics"]),
            "track2r05_hash_checks": sha256_file(paths["track2r05_hash_checks"]),
        },
        "output_files": [
            "track2r06_closure_verdict.csv",
            "track2r06_lambda_space_vs_curve_space_summary.csv",
            "track2r06_failure_mode_by_group.csv",
            "track2r06_help_hurt_by_galaxy.csv",
            "track2r06_help_hurt_summary.csv",
            "track2r06_public_claim_table.csv",
            "track2r06_no_retuning_audit.csv",
            "TRACK2R_06_closure_diagnostic_report.md",
        ],
        "claim_boundary": verdict["claim_boundary"],
    }
    (out / "track2r06_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    write_report(out / "TRACK2R_06_closure_diagnostic_report.md", verdict, summary_rows, group_rows, help_summary, claim_rows, audit_rows)

    print("\nSFT TRACK2R-06 CLOSURE DIAGNOSTIC")
    print("=================================")
    print("\nPurpose:")
    print("  Close Track2R without retuning: lambda-space direction vs curve-space amplitude.")

    print("\nInput verdicts:")
    print(f"  Track2R-04: {t2r04_verdict.get('verdict','')}")
    print(f"  Track2R-05: {t2r05_verdict.get('verdict','')}")

    print("\nLockbox:")
    print(f"  Track2R-04 hash checks pass: {t2r04_hash_ok}")
    print(f"  Track2R-05 hash checks pass: {t2r05_hash_ok}")

    print("\nLambda-space vs curve-space:")
    for r in summary_rows[:4]:
        print(
            f"  {r['domain']:14s} {r['test']:42s} "
            f"value={r.get('value_primary')} error={r.get('error_value')} "
            f"delta_vs_control={r.get('delta_vs_best_control')} status={r.get('status')}"
        )

    print("\nFailure mode by key group:")
    key_groups = [
        "FULL", "INTERIOR_NON_EDGE", "Q1_ONLY", "Q1_Q2", "TYPE_2_TO_10",
        "TYPE_2_TO_10_INTERIOR", "LOW_ACCEL_LOGGBAR_LT_MINUS11",
        "NPOINTS_GE_MEDIAN", "NPOINTS_GE_MEDIAN_INTERIOR"
    ]
    for r in group_rows:
        if r["group"] in key_groups:
            print(
                f"  {r['group']:30s} rows={r['row_N']} galaxies={r['galaxy_N']} "
                f"deltaRMS={r['delta_primary_minus_best_constant_rms_V']} mode={r['failure_mode']}"
            )

    print("\nPer-galaxy help/hurt summary:")
    for k, v in help_summary.items():
        print(f"  {k}: {v}")

    print("\nPublic claim table:")
    for r in claim_rows:
        print(f"  {r['claim']}: {r['status']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {out}")
    print(f"  closure verdict: {out/'track2r06_closure_verdict.csv'}")
    print(f"  lambda/curve summary: {out/'track2r06_lambda_space_vs_curve_space_summary.csv'}")
    print(f"  failure modes: {out/'track2r06_failure_mode_by_group.csv'}")
    print(f"  help/hurt by galaxy: {out/'track2r06_help_hurt_by_galaxy.csv'}")
    print(f"  public claim table: {out/'track2r06_public_claim_table.csv'}")
    print(f"  report: {out/'TRACK2R_06_closure_diagnostic_report.md'}")


if __name__ == "__main__":
    main()
