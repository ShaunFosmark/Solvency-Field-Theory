# SFT Track2R-06 Closure Diagnostic

## Verdict

**TRACK2R06_MORPHOLOGY_DIRECTION_VALIDATED_AMPLITUDE_CLOSURE_OPEN**

Track2R-04 validates the no-target morphology direction in lambda-space, while Track2R-05 shows that the same sealed predictor does not improve full-sample rotation curves. Amplitude/readout closure remains open.

## Claim boundary

Closure diagnostic only; no selector repair, no refit, no retuning, no new amplitude law

## Executive conclusion

Track2R closes as follows:

1. The morphology-readout direction survived in lambda-space.
2. The first sealed Type-endpoint predictor did not improve full-sample rotation curves over the best constant-lambda control.
3. Small domain-local improvements exist, but they are not a completed amplitude law.
4. Any repair, correction, or expanded readout must be treated as a new predeclared fork.

## Lambda-space versus curve-space summary

| Domain | Test | Selector | Metric | Value | p | Error metric | Error | Best control | Delta vs control | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| lambda_space | Track2R-04 primary directional validation | PRIMARY_TYPE_ENDPOINT_LINEAR | Spearman rho | 0.27161389600924596 | 0.0002769472823964572 | RMSE(lambda) | 0.7274371744497276 | 0.7342798588488669 | -0.006842684399139376 | PASS |
| lambda_space | Track2R-04 blend directional validation | TERTIARY_EQUAL_TYPE_SOURCE_BLEND | Spearman rho | 0.28717161027990473 | 0.0001165944428951299 | RMSE(lambda) | 0.7306265274275271 | 0.7342798588488669 | -0.003653331421339834 | SUPPORTING_SIGNAL |
| curve_space | Track2R-05 primary rotation validation | PRIMARY_TYPE_ENDPOINT_LINEAR | RMS velocity residual km/s | 23.76099334263328 |  | RMS V km/s | 23.76099334263328 | 23.67157594058304 | 0.08941740205024118 | FAIL_FULL_SAMPLE |
| curve_space | Track2R-05 fit ceiling gap | TRACK1_LAMBDA_BEST_FIT_CEILING | RMS velocity residual km/s | 16.354487377947162 |  | primary minus ceiling RMS V | 7.406505964686119 |  |  | AMPLITUDE_GAP |
| selector_comparison | primary | PRIMARY_TYPE_ENDPOINT_LINEAR | lambda rho / curve RMS | 0.27161389600924596 | 0.0002769472823964572 | curve RMS V km/s | 23.76099334263328 | 23.67157594058304 | 0.08941740205024118 | DIAGNOSTIC |
| selector_comparison | source | SECONDARY_SOURCE_ROOT_SPHERICITY | lambda rho / curve RMS | 0.19375979897915474 | 0.010192554655342257 | curve RMS V km/s | 23.94239728900231 | 23.67157594058304 | 0.27082134841927186 | DIAGNOSTIC |
| selector_comparison | blend | TERTIARY_EQUAL_TYPE_SOURCE_BLEND | lambda rho / curve RMS | 0.28717161027990473 | 0.0001165944428951299 | curve RMS V km/s | 23.84748200304066 | 23.67157594058304 | 0.17590606245762075 | DIAGNOSTIC |
| selector_comparison | disk_control | CONTROL_CONSTANT_DISK_ENDPOINT | lambda rho / curve RMS | nan | nan | curve RMS V km/s | 24.46099247844102 | 23.67157594058304 | 0.7894165378579814 | DIAGNOSTIC |
| selector_comparison | sphere_control | CONTROL_CONSTANT_SPHERE_ENDPOINT | lambda rho / curve RMS | nan | nan | curve RMS V km/s | 23.67157594058304 | 23.67157594058304 | 0.0 | DIAGNOSTIC |
| selector_comparison | midpoint_control | CONTROL_CONSTANT_ENDPOINT_MIDPOINT | lambda rho / curve RMS | nan | nan | curve RMS V km/s | 24.009284556933526 | 23.67157594058304 | 0.3377086163504863 | DIAGNOSTIC |


## Failure mode by group

| Group | Rows | Galaxies | Primary RMS V | Best constant | Delta RMS | Mode | Interpretation |
|---|---|---|---|---|---|---|---|
| FULL | 3389 | 175 | 23.76099334263328 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.08941740205024118 | NEAR_TIE | Primary is effectively tied with the best constant control at this group scale. |
| INTERIOR_NON_EDGE | 2581 | 134 | 16.94448244818822 | CONTROL_CONSTANT_DISK_ENDPOINT | 0.030376542119451955 | NEAR_TIE | Primary is effectively tied with the best constant control at this group scale. |
| Q1_ONLY | 2132 | 99 | 24.877736343988243 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.16286839800198294 | HURT | Primary underperforms the best constant control in this group. |
| Q1_Q2 | 3269 | 163 | 23.689587315918967 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.12717520652892134 | HURT | Primary underperforms the best constant control in this group. |
| TYPE_2_TO_10 | 3169 | 164 | 23.07223387327209 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.08637785543000476 | NEAR_TIE | Primary is effectively tied with the best constant control at this group scale. |
| TYPE_2_TO_10_INTERIOR | 2477 | 129 | 16.576286670064892 | CONTROL_CONSTANT_ENDPOINT_MIDPOINT | -0.012106201531608463 | LOCAL_HELP | Primary sealed morphology predictor beats the best constant control in this group. |
| LOW_ACCEL_LOGGBAR_LT_MINUS11 | 1261 | 130 | 15.236486732870976 | CONTROL_CONSTANT_ENDPOINT_MIDPOINT | -0.16575972904178116 | LOCAL_HELP | Primary sealed morphology predictor beats the best constant control in this group. |
| MID_ACCEL_1E11_TO_1E10 | 1344 | 126 | 24.68578445293483 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.27024219281690876 | HURT | Primary underperforms the best constant control in this group. |
| HIGH_ACCEL_GE_1E10 | 784 | 60 | 31.976128629606002 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.11765025745142665 | HURT | Primary underperforms the best constant control in this group. |
| NPOINTS_GE_MEDIAN | 1724 | 41 | 27.461923600726255 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.2871717084696037 | HURT | Primary underperforms the best constant control in this group. |
| NPOINTS_GE_MEDIAN_INTERIOR | 1256 | 32 | 17.901015581209432 | CONTROL_CONSTANT_ENDPOINT_MIDPOINT | -0.008771951140033707 | LOCAL_HELP | Primary sealed morphology predictor beats the best constant control in this group. |
| INNER_RADII_LE_MEDIAN | 1695 | 173 | 21.169949509694394 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.03507020156181895 | NEAR_TIE | Primary is effectively tied with the best constant control at this group scale. |
| OUTER_RADII_GT_MEDIAN | 1694 | 139 | 26.09734796430764 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.1344708604376521 | HURT | Primary underperforms the best constant control in this group. |
| EDGE_ONLY | 808 | 41 | 38.0907728193773 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.44955792002112815 | HURT | Primary underperforms the best constant control in this group. |


## Local-help groups

| Group | Rows | Galaxies | Delta RMS | Interpretation |
|---|---|---|---|---|
| TYPE_2_TO_10_INTERIOR | 2477 | 129 | -0.012106201531608463 | Primary sealed morphology predictor beats the best constant control in this group. |
| LOW_ACCEL_LOGGBAR_LT_MINUS11 | 1261 | 130 | -0.16575972904178116 | Primary sealed morphology predictor beats the best constant control in this group. |
| NPOINTS_GE_MEDIAN_INTERIOR | 1256 | 32 | -0.008771951140033707 | Primary sealed morphology predictor beats the best constant control in this group. |


## Hurt groups

| Group | Rows | Galaxies | Delta RMS | Interpretation |
|---|---|---|---|---|
| Q1_ONLY | 2132 | 99 | 0.16286839800198294 | Primary underperforms the best constant control in this group. |
| Q1_Q2 | 3269 | 163 | 0.12717520652892134 | Primary underperforms the best constant control in this group. |
| MID_ACCEL_1E11_TO_1E10 | 1344 | 126 | 0.27024219281690876 | Primary underperforms the best constant control in this group. |
| HIGH_ACCEL_GE_1E10 | 784 | 60 | 0.11765025745142665 | Primary underperforms the best constant control in this group. |
| NPOINTS_GE_MEDIAN | 1724 | 41 | 0.2871717084696037 | Primary underperforms the best constant control in this group. |
| OUTER_RADII_GT_MEDIAN | 1694 | 139 | 0.1344708604376521 | Primary underperforms the best constant control in this group. |
| EDGE_ONLY | 808 | 41 | 0.44955792002112815 | Primary underperforms the best constant control in this group. |


## Per-galaxy help/hurt summary

| Metric | Value |
|---|---|
| galaxy_N | 175 |
| help_N | 3 |
| hurt_N | 146 |
| tie_N | 26 |
| help_fraction | 0.017142857142857144 |
| median_delta_rms | 0.5113292095376964 |
| mean_delta_rms | 0.7071045772904717 |

## Public claim table

| Claim | Status | Allowed wording | Forbidden wording | Basis |
|---|---|---|---|---|
| SPARC morphology-lambda structure exists | SUPPORTED_BY_TRACK1_AND_TRACK2R04 | The fitted per-galaxy lambda structure is morphology-linked, and a frozen no-target morphology selector recovers the direction of that structure. | SFT fully predicts each galaxy's lambda or rotation curve from morphology alone. | Track1/Track1B morphology-lambda correlation plus Track2R-04 directional validation. |
| No-target morphology readout validates lambda direction | SUPPORTED | Track2R-04 primary selector verdict: TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS. | The selector is a precision lambda predictor. | Primary selector positive rank correlation and beats constant controls in lambda-space. |
| No-target morphology readout improves full-sample rotation curves | NOT_SUPPORTED | Track2R-05 verdict: TRACK2R05_DIRECTIONAL_LAMBDA_VALIDATION_DOES_NOT_IMPROVE_ROTATION_CURVES. Full-sample primary delta RMS vs best constant = 0.08941740205024118. | Track2R-05 proves SFT beats fixed-lambda controls on SPARC rotation curves. | Primary sealed predictor is worse than best constant control in full-sample curve residuals. |
| There are domain-local hints where morphology readout helps | WEAK_LOCAL_SUPPORT | Small local improvements appear in selected groups, e.g. low-acceleration delta RMS -0.16575972904178116 and Type 2-10 interior delta RMS -0.012106201531608463. | These pockets establish a final amplitude law. | Track2R-05 subgroup diagnostics. |
| Amplitude/readout closure remains open | OPEN_PROBLEM | The first sealed Type-endpoint morphology predictor captures direction but is amplitude-limited; any amplitude correction requires a new predeclared fork. | We can repair the selector after seeing residuals and keep the same validation status. | Track2R-05 full-sample failure plus fit-ceiling gap. |
| Track2R final status | CLOSED_WITH_CAUTION | Track2R closes as a directional morphology-readout validation with amplitude closure open. | Track2R is a completed rotation-curve solution. | Help fraction by galaxy = 0.017142857142857144; median per-galaxy delta RMS = 0.5113292095376964. |


## No-retuning audit

| Item | Detected | Used | Status |
|---|---|---|---|
| Track2R-04 verdict | True | True | CLOSURE_INPUT |
| Track2R-04 selector metrics | True | True | CLOSURE_INPUT |
| Track2R-04 hash checks all pass | True | True | LOCKBOX_CONFIRMATION |
| Track2R-05 verdict | True | True | CLOSURE_INPUT |
| Track2R-05 selector metrics | True | True | CLOSURE_INPUT |
| Track2R-05 per-galaxy metrics | True | True | CLOSURE_INPUT |
| Track2R-05 hash checks all pass | True | True | LOCKBOX_CONFIRMATION |
| new selector introduced | False | False | NO |
| lambda_pred modified | False | False | NO |
| rotation residuals used for repair | False | False | NO |
| new coefficient or amplitude law fitted | False | False | NO |
| new public success claim introduced | False | False | NO |


## Recommended use

Use Track2R as a support lane for the SPARC morphology paper:

> A frozen no-target morphology selector recovers the direction of the fitted lambda structure, but the first Type-endpoint readout does not close the amplitude into full-sample rotation-curve improvement.

Do not use Track2R-05 as a rotation-curve success claim.
