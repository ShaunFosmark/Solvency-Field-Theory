# Results Insert

Lane 1 found a statistically significant morphology-lambda trend. The full-sample Track1 rank correlation was rho = -0.2716 with p = 2.7695e-04. The interior/non-edge result was rho = -0.2478 with p = 0.003898. The wide-rail edge fraction was 0.2343, so edge caution is retained. The permutation control gave p = 7.9992e-04.

Track1B confirmed that the signal was not simply an old rail artifact or an inclination artifact, but also showed that the trend is weakened in selected quality and high-point-count cuts. The Q1-only cut gave p = 0.1458, while the Q1+Q2 cut gave p = 9.9330e-04. The Type 2--10 interior cut gave p = 0.003475. The high-point-count cut gave p = 0.1529. A multivariable partial-rank control including inclination, quality, point count, bulge fraction, and gas fraction gave p = 0.8206, marking the sample-structure caution.

Track2R-04 validated the no-target morphology readout direction. The primary selector gave rho = 0.2716, p = 2.7695e-04, RMSE(lambda) = 0.7274, and MAE(lambda) = 0.6168. The blend selector had a slightly larger rank correlation, rho = 0.2872, but did not improve the amplitude error over the primary selector.

Track2R-05 did not validate the same sealed predictor as a full-sample rotation-curve improvement. The primary selector produced RMS V = 23.76 km/s, while the best constant control, the sphere endpoint, gave RMS V = 23.67 km/s. The primary delta relative to the best constant was therefore 0.08942 km/s. The Track1 lambda_best fit ceiling remained substantially better, RMS V = 16.35 km/s, leaving a primary-ceiling gap of 7.407 km/s.

Track2R-06 closed the track as directional morphology-readout support with amplitude closure open. Per-galaxy help/hurt was help_N = 3, hurt_N = 146, tie_N = 26, with help fraction 0.01714.
