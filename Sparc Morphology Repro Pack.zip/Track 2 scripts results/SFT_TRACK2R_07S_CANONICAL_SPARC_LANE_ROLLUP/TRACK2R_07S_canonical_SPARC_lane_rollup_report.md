# SFT Track2R-07S Canonical SPARC Lane Rollup

## Verdict

**TRACK2R07S_CANONICAL_NUMERIC_ROLLUP_READY_FOR_PAPER_INSERT**

Track2R-07/07R rollup preserved; canonical Track1/Track1B numbers forced into the paper insert to avoid schema mis-parsing.

## Paper thesis

**SPARC lambda structure is morphology-linked; a frozen no-target morphology readout recovers direction but not full rotation-curve amplitude.**

## Claim boundary

Canonical numeric paper-rollup patch only; no new fit, no new selector, no retuning, no upgraded success claim

## Evidence ladder

| Lane | Step | Result | Key numbers | Interpretation | Claim boundary |
|---|---|---|---|---|---|
| Lane 1 | Track1 wide-rail morphology-lambda rerun | SUPPORTED_WITH_CAUTIONS | full rho=-0.27161389600924596, p=0.0002769472823964572; interior rho=-0.24775767351229477, p=0.0038983220391168865; wide_edge_fraction=0.2342857142857143 | Per-galaxy fitted lambda has a morphology-linked structure after widening the lambda scan rails. | Correlation/readout structure only; no dark-halo claim, no completed rotation-curve law. |
| Lane 1 | Track1B robustness audit | SURVIVES_WITH_SAMPLE_STRUCTURE_CAUTIONS | Q1 p=0.1458228105305058; Q1_Q2 p=0.000993303089194354; Type2-10 interior p=0.0034748572832141826; high-N p=0.15293474105197186; all-controls partial p=0.8205972197732623 | Signal is not simply an old rail or inclination artifact, but is entangled with quality/composition/sample structure. | Robust morphology correlation with cautions, not a closed interpolation law. |
| Lane 2 | Track2R-04 no-target lambda-direction validation | SUPPORTED | primary rho=0.27161389600924596, p=0.0002769472823964572, RMSE(lambda)=0.7274371744497276; blend rho=0.28717161027990473 | A frozen no-target morphology selector recovers the direction of fitted lambda structure. | Directional lambda-space validation only; not a precision predictor. |
| Lane 2 | Track2R-05 rotation-curve propagation | NOT_SUPPORTED_FULL_SAMPLE | primary RMSV=23.76099334263328 km/s; sphere control RMSV=23.67157594058304 km/s; delta vs best constant=0.08941740205024118; Track1 ceiling RMSV=16.354487377947162 km/s | The first sealed morphology readout does not improve full-sample rotation curves over the best constant-lambda control. | Amplitude/readout closure remains open. |
| Lane 2 | Track2R-06 closure diagnostic | CLOSED_WITH_CAUTION | help_N=3.0, hurt_N=146.0, tie_N=26.0, help_fraction=0.017142857142857144 | Track2R supports morphology as a readout coordinate, but not a completed rotation-curve amplitude law. | Directional support lane only. |


## Claim boundary table

| Claim | Status | Allowed wording | Forbidden wording | Basis |
|---|---|---|---|---|
| SPARC fitted lambda is morphology structured | SUPPORTED | The SPARC fitted per-galaxy lambda values show a statistically significant morphology-linked trend, robust to several but not all cuts. | SFT fully derives each galaxy rotation curve from morphology alone. | Track1 full rho=-0.27161389600924596, p=0.0002769472823964572; interior rho=-0.24775767351229477, p=0.0038983220391168865. |
| Signal is not a narrow-rail artifact | SUPPORTED_WITH_EDGE_CAUTION | The wide-rail rerun preserves the morphology-lambda trend after expanding the lambda scan range. | All edge effects are eliminated. | Wide-edge fraction=0.2342857142857143; edge cautions remain. |
| Signal is independent of all sample/composition structure | NOT_SUPPORTED | The signal is not explained by inclination alone, but multivariable/sample-structure controls absorb much of it. | The morphology signal is fully isolated from sample quality and composition. | Q1-only p=0.1458228105305058; high-N p=0.15293474105197186; all-controls partial p=0.8205972197732623. |
| Frozen no-target morphology readout predicts lambda direction | SUPPORTED | A predeclared Type-endpoint morphology selector recovers the direction of fitted lambda structure without target leakage. | The frozen selector is a precision lambda predictor. | Track2R-04 rho=0.27161389600924596, p=0.0002769472823964572. |
| Frozen no-target morphology readout improves full-sample rotation curves | NOT_SUPPORTED | The same frozen selector does not improve full-sample rotation-curve residuals over the best constant-lambda control. | Track2R proves a successful SPARC rotation-curve prediction law. | Track2R-05 delta RMS vs best constant=0.08941740205024118. |
| Amplitude/readout closure | OPEN | The amplitude/readout law remains open and requires a new predeclared fork if pursued. | A post-hoc correction can be added to the same locked validation chain. | Track2R-06 verdict=TRACK2R06_MORPHOLOGY_DIRECTION_VALIDATED_AMPLITUDE_CLOSURE_OPEN. |
| Public SPARC result | SUPPORTED_WITH_CAUTION | SPARC supports morphology-dependent SFT weak-field readout structure, while the first no-target amplitude closure remains incomplete. | SPARC validates the full SFT gravity program. | SPARC is an empirical galaxy-readout branch, not the entire V12.3 gravity program. |


## Numeric highlights

| Section | Metric | Value | Source |
|---|---|---|---|
| Canonical Track1/Track1B | track1_full_rho | -0.27161389600924596 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1_full_p | 0.0002769472823964572 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1_interior_rho | -0.24775767351229477 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1_interior_p | 0.0038983220391168865 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1_edge_fraction | 0.2342857142857143 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1_permutation_p | 0.0007999200079992001 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1_inclination_full_p | 0.29586778546667586 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1_bulge_fraction_full_p | 0.028072263173873593 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_full_rho | -0.27161389600924596 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_full_p | 0.0002769472823964572 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_interior_rho | -0.24775767351229477 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_interior_p | 0.0038983220391168865 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_q1_rho | -0.14724927665522128 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_q1_p | 0.1458228105305058 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_q1q2_rho | -0.2555529508719165 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_q1q2_p | 0.000993303089194354 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_type210_rho | -0.30990678800024285 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_type210_p | 5.384809110525655e-05 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_type210_interior_rho | -0.25549421484602025 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_type210_interior_p | 0.0034748572832141826 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_exclude_t0_t11_p | 0.00013230077012864815 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_npoints_rho | -0.15276809845208664 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_npoints_p | 0.15293474105197186 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_all_controls_partial_p | 0.8205972197732623 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_full_bootstrap_ci_low | -0.420787 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_full_bootstrap_ci_high | -0.114175 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_interior_bootstrap_ci_low | -0.40682 | canonical_locked_prior_gate_value |
| Canonical Track1/Track1B | track1b_interior_bootstrap_ci_high | -0.0782502 | canonical_locked_prior_gate_value |
| Parsed Track2R | track2r04_primary_rho | 0.27161389600924596 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r04_primary_p | 0.0002769472823964572 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r04_primary_rmse_lambda | 0.7274371744497276 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r04_primary_mae_lambda | 0.616752751448737 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r04_blend_rho | 0.28717161027990473 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r04_blend_p | 0.0001165944428951299 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r04_blend_rmse_lambda | 0.7306265274275271 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_primary_rmsV | 23.76099334263328 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_primary_maeV | 16.632232905215442 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_primary_rmsLogV | 0.09812140233989979 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_primary_delta_vs_best_constant | 0.08941740205024118 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_sphere_control_rmsV | 23.67157594058304 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_ceiling_rmsV | 16.354487377947162 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_primary_delta_vs_ceiling | 7.406505964686119 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_lowacc_delta | -0.16575972904178116 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_type210_interior_delta | -0.012106201531608463 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r05_npoints_interior_delta | -0.008771951140033707 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r06_help_N | 3.0 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r06_hurt_N | 146.0 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r06_tie_N | 26.0 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r06_help_fraction | 0.017142857142857144 | parsed_current_track2r_outputs |
| Parsed Track2R | track2r06_median_delta_rms | 0.5113292095376964 | parsed_current_track2r_outputs |


## Recommended use

Use this 07S rollup as the canonical SPARC morphology paper insert. Do not present Track2R as a completed rotation-curve prediction success. The final Track2R status remains directional morphology support with amplitude closure open.
