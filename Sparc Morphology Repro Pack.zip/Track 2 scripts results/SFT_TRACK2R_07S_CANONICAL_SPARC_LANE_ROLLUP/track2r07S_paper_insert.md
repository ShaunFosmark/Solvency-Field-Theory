# SPARC Morphology-Readout Paper Insert

## Thesis

**SPARC lambda structure is morphology-linked; a frozen no-target morphology readout recovers direction but not full rotation-curve amplitude.**

## Abstract candidate

# Abstract Candidate

We report a SPARC weak-field readout audit of Solvency Field Theory focused on whether the per-galaxy solvency coefficient, lambda, behaves as a universal constant or as a morphology-dependent readout coordinate. A wide-rail rerun of the SPARC lambda profile scan preserves a significant morphology-lambda trend, with full-sample Spearman rho = -0.2716 and p = 2.7695e-04; the non-edge interior sample gives rho = -0.2478 and p = 0.003898. Robustness checks show that the signal survives several edge and morphology cuts, while quality and sample-structure controls remain important cautions. A separately frozen no-target morphology selector recovers the direction of the fitted lambda structure, with Track2R-04 primary rho = 0.2716 and p = 2.7695e-04. However, propagating the sealed predictor into rotation curves does not improve the full-sample velocity residuals over the best constant-lambda control, with delta RMS = 0.08942 km/s. We therefore conclude that SPARC supports morphology-dependent lambda readout structure, but the first Type-endpoint no-target amplitude law is not a completed rotation-curve predictor.


## Methods insert

# Methods Insert

The SPARC analysis was divided into two lanes. Lane 1 measured the fitted per-galaxy lambda structure using a fixed weak-field law and a widened lambda scan range. The scan used fixed constants and fixed stellar mass-to-light assumptions, then tested whether the resulting lambda_best values correlate with galaxy morphology. Lane 1B repeated the morphology audit across robustness cuts, edge checks, quality cuts, bootstrap intervals, and partial-rank controls.

Lane 2, Track2R, was frozen before target validation. Track2R-01 created the allowed no-target morphology/source feature table. Track2R-02 froze the lambda readout selector. Track2R-03 generated the sealed per-galaxy lambda_pred table. Track2R-04 was the first allowed join to Track1 lambda_best. Track2R-05 propagated the sealed lambda_pred values into rotation-curve predictions against ROTMOD Vobs/eVobs as validation targets only. Track2R-06 closed the result with no selector repair, no refit, no retuning, and no new amplitude law. Track2R-07 and Track2R-07R/07S are rollup and paper-text packaging steps only.

The key locked primary readout was the Type-endpoint selector, mapping Hubble Type to a bounded interpolation between the disk endpoint 3pi/8 and the spherical endpoint 4/3. Track1 lambda_best was used as a validation target in Track2R-04 and as a fit-ceiling reference in Track2R-05; it was not used to modify the sealed predictions.


## Results insert

# Results Insert

Lane 1 found a statistically significant morphology-lambda trend. The full-sample Track1 rank correlation was rho = -0.2716 with p = 2.7695e-04. The interior/non-edge result was rho = -0.2478 with p = 0.003898. The wide-rail edge fraction was 0.2343, so edge caution is retained. The permutation control gave p = 7.9992e-04.

Track1B confirmed that the signal was not simply an old rail artifact or an inclination artifact, but also showed that the trend is weakened in selected quality and high-point-count cuts. The Q1-only cut gave p = 0.1458, while the Q1+Q2 cut gave p = 9.9330e-04. The Type 2--10 interior cut gave p = 0.003475. The high-point-count cut gave p = 0.1529. A multivariable partial-rank control including inclination, quality, point count, bulge fraction, and gas fraction gave p = 0.8206, marking the sample-structure caution.

Track2R-04 validated the no-target morphology readout direction. The primary selector gave rho = 0.2716, p = 2.7695e-04, RMSE(lambda) = 0.7274, and MAE(lambda) = 0.6168. The blend selector had a slightly larger rank correlation, rho = 0.2872, but did not improve the amplitude error over the primary selector.

Track2R-05 did not validate the same sealed predictor as a full-sample rotation-curve improvement. The primary selector produced RMS V = 23.76 km/s, while the best constant control, the sphere endpoint, gave RMS V = 23.67 km/s. The primary delta relative to the best constant was therefore 0.08942 km/s. The Track1 lambda_best fit ceiling remained substantially better, RMS V = 16.35 km/s, leaving a primary-ceiling gap of 7.407 km/s.

Track2R-06 closed the track as directional morphology-readout support with amplitude closure open. Per-galaxy help/hurt was help_N = 3, hurt_N = 146, tie_N = 26, with help fraction 0.01714.


## Discussion insert

# Discussion Insert

The SPARC result should be interpreted as evidence that the SFT weak-field readout is morphology-structured rather than universal. The central empirical statement is not that a final rotation-curve law has been derived, but that the fitted lambda coordinate carries a reproducible morphology dependence. The frozen no-target Track2R selector strengthens this interpretation by recovering the direction of the fitted lambda structure without target leakage.

The same Track2R sequence also prevents overclaiming. Directional lambda-space validation did not close into full-sample rotation-curve improvement. The first Type-endpoint law is therefore too crude as an amplitude predictor. This suggests that morphology is a real readout coordinate, but that the amplitude/readout map requires additional predeclared physical structure before it can function as a precision rotation-curve model.

The appropriate conclusion is that SPARC supports a morphology-dependent SFT readout lane with explicit sample-structure and amplitude-closure cautions. Any future amplitude repair or expanded readout law should be treated as a new predeclared fork rather than a continuation of the sealed Track2R validation.


## Compact claim boundary

Allowed:

> SPARC supports morphology-dependent SFT weak-field readout structure. A frozen no-target morphology selector recovers the direction of fitted lambda, but the first Type-endpoint amplitude law does not improve full-sample rotation curves over the best constant-lambda control.

Forbidden:

> SPARC validates the full SFT gravity program or proves a completed no-target rotation-curve predictor.
