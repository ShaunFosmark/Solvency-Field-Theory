# Discussion Insert

The SPARC result should be interpreted as evidence that the SFT weak-field readout is morphology-structured rather than universal. The central empirical statement is not that a final rotation-curve law has been derived, but that the fitted lambda coordinate carries a reproducible morphology dependence. The frozen no-target Track2R selector strengthens this interpretation by recovering the direction of the fitted lambda structure without target leakage.

The same Track2R sequence also prevents overclaiming. Directional lambda-space validation did not close into full-sample rotation-curve improvement. The first Type-endpoint law is therefore too crude as an amplitude predictor. This suggests that morphology is a real readout coordinate, but that the amplitude/readout map requires additional predeclared physical structure before it can function as a precision rotation-curve model.

The appropriate conclusion is that SPARC supports a morphology-dependent SFT readout lane with explicit sample-structure and amplitude-closure cautions. Any future amplitude repair or expanded readout law should be treated as a new predeclared fork rather than a continuation of the sealed Track2R validation.
