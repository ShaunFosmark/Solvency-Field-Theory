#!/usr/bin/env python3
"""
SFT Track2R-01:
Clean Restart Protocol for Morphology-Readout Lambda Prediction

Purpose
-------
Old Track 2 tested a SPARC-internal D/B/E environment channel and failed.
That branch is archived as an internal diagnostic only.

Track2R restarts from the structure supported by Track 1:

    g_eff^2 = g_bar^2 + lambda_morph * a_SFT * g_bar

Track2R-01 does NOT predict lambda yet.
Track2R-01 freezes the clean protocol boundary and builds the allowed
metadata/source-only morphology feature table.

Core rule
---------
Feature construction may use:
    - SPARC metadata: Hubble Type, distance, inclination, L36, MHI, Reff,
      disk scale, surface brightness, Vflat, Q
    - SPARC source mass-model columns: radius, Vgas, Vdisk, Vbul
    - fixed stellar mass-to-light constants already used in Track 1:
        Upsilon_disk = 0.5
        Upsilon_bulge = 0.7
    - theoretical endpoints:
        lambda_disk = 3*pi/8
        lambda_sphere = 4/3

Feature construction may NOT use:
    - Track1 lambda_best
    - chi2(lambda)
    - rotation-curve residuals
    - observed acceleration residuals
    - RAR_All_Data
    - dark halo fits
    - old Track2 D/B/E outputs
    - any post-hoc repair from Gate14C/14D

Outputs
-------
    track2r01_protocol_hash.txt
    track2r01_protocol_manifest.json
    track2r01_allowed_feature_table.csv
    track2r01_feature_summary.csv
    track2r01_allowed_inputs.csv
    track2r01_forbidden_inputs.csv
    track2r01_no_target_audit.csv
    track2r01_gate_blueprint.csv
    track2r01_verdict.csv
    TRACK2R_01_morphology_readout_protocol_report.md

Run
---
    python SFT_TRACK2R_01_morphology_readout_protocol.py --sparc-dir "C:\\Users\\TaicHI\\SPARC"

Next gates
----------
Track2R-02:
    choose/freeze lambda_pred readout law from allowed variables only.

Track2R-03:
    generate sealed lambda_pred table and hash BEFORE joining Track1 lambda_best.

Track2R-04:
    join sealed lambda_pred to Track1 lambda_best for validation.

Track2R-05:
    use sealed lambda_pred to predict rotation curves.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
from pathlib import Path
from typing import Iterable

import numpy as np

C = 299_792_458.0
MPC = 3.0856775814913673e22
KPC = 3.0856775814913673e19
H0_KM_S_MPC = 67.74
H0_SI = H0_KM_S_MPC * 1000.0 / MPC
A_SFT = C * H0_SI / (2.0 * math.pi)

ML_DISK = 0.5
ML_BULGE = 0.7

LAMBDA_DISK = 3.0 * math.pi / 8.0
LAMBDA_SPHERE = 4.0 / 3.0
DELTA_LAMBDA = LAMBDA_SPHERE - LAMBDA_DISK

PROTOCOL_VERSION = "SFT_TRACK2R_01_MORPHOLOGY_READOUT_PROTOCOL_v1"
OUT_DIR_NAME = "SFT_TRACK2R_01_MORPHOLOGY_READOUT_PROTOCOL"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def read_lines(path: Path) -> list[str]:
    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            return path.read_text(encoding=enc, errors="replace").splitlines()
        except Exception:
            pass
    return path.read_text(errors="replace").splitlines()


def iter_files(base: Path) -> Iterable[Path]:
    for root, dirs, files in os.walk(base):
        # Avoid recursively reading output trees.
        dirs[:] = [d for d in dirs if not d.upper().startswith("SFT_")]
        for fn in files:
            yield Path(root) / fn


def find_inputs(sparc_dir: Path, table1_path: str | None = None) -> dict:
    files = list(iter_files(sparc_dir))

    table1 = None
    if table1_path:
        p = Path(table1_path).expanduser()
        if not p.is_absolute():
            p = sparc_dir / p
        if p.exists():
            table1 = p.resolve()

    if table1 is None:
        exact = [p for p in files if p.name.lower() == "table1.txt"]
        if exact:
            table1 = sorted(exact, key=lambda x: len(str(x)))[0]
    if table1 is None:
        table_like = [p for p in files if "table1" in p.name.lower() and p.suffix.lower() in (".txt", ".mrt")]
        if table_like:
            table1 = sorted(table_like, key=lambda x: len(str(x)))[0]

    rotmod = None
    for p in sparc_dir.rglob("*"):
        if p.is_dir() and p.name.lower() == "rotmod_ltg":
            rotmod = p
            break

    rar = None
    for p in files:
        if "rar_all_data" in str(p).lower():
            rar = p
            break

    track1 = sparc_dir / "SFT_SPARC_TRACK1_LAMBDA_WIDE_OUTPUT" / "sparc_lambda_wide_per_galaxy.csv"
    track1b = sparc_dir / "SFT_SPARC_TRACK1B_ROBUSTNESS_OUTPUT" / "track1b_verdict.csv"
    old_track2 = sparc_dir / "SFT_GRAV_TRAJ_14C_OUTPUT" / "gate14c_validation_joined_rows.csv"
    old_track2d = sparc_dir / "SFT_GRAV_TRAJ_14D_OUTPUT" / "gate14d_verdict.csv"

    return {
        "table1": table1,
        "rotmod_ltg_dir": rotmod,
        "rar_all_data_quarantined": rar,
        "track1_lambda_best_forbidden": track1 if track1.exists() else None,
        "track1b_robustness_forbidden": track1b if track1b.exists() else None,
        "old_track2_14c_forbidden": old_track2 if old_track2.exists() else None,
        "old_track2_14d_forbidden": old_track2d if old_track2d.exists() else None,
    }


def parse_table1(path: Path) -> tuple[dict[str, dict], list[dict]]:
    rows = []
    for raw in read_lines(path):
        s = raw.rstrip("\n")
        if not re.match(r"^\s*[A-Za-z0-9][A-Za-z0-9+\-_.]*\s+\d{1,2}\s+[-+]?\d", s):
            continue

        parsed = None

        try:
            if len(s) >= 99:
                parsed = {
                    "Galaxy": s[0:11].strip(),
                    "Type": int(s[11:13].strip()),
                    "Distance_Mpc": float(s[13:19].strip()),
                    "e_Distance_Mpc": float(s[19:24].strip()),
                    "f_D": int(s[24:26].strip()),
                    "Inclination_deg": float(s[26:30].strip()),
                    "e_Inclination_deg": float(s[30:34].strip()),
                    "L36_1e9Lsun": float(s[34:41].strip()),
                    "e_L36": float(s[41:48].strip()),
                    "Reff_kpc": float(s[48:53].strip()),
                    "SBeff_Lsun_pc2": float(s[53:61].strip()),
                    "Rdisk_kpc": float(s[61:66].strip()),
                    "SBdisk_Lsun_pc2": float(s[66:74].strip()),
                    "MHI_1e9Msun": float(s[74:81].strip()),
                    "RHI_kpc": float(s[81:86].strip()),
                    "Vflat_km_s": float(s[86:91].strip()),
                    "e_Vflat_km_s": float(s[91:96].strip()),
                    "Q": int(s[96:99].strip()),
                    "Ref": s[99:].strip(),
                }
        except Exception:
            parsed = None

        if parsed is None:
            try:
                parts = s.split()
                if len(parts) >= 18:
                    parsed = {
                        "Galaxy": parts[0],
                        "Type": int(parts[1]),
                        "Distance_Mpc": float(parts[2]),
                        "e_Distance_Mpc": float(parts[3]),
                        "f_D": int(parts[4]),
                        "Inclination_deg": float(parts[5]),
                        "e_Inclination_deg": float(parts[6]),
                        "L36_1e9Lsun": float(parts[7]),
                        "e_L36": float(parts[8]),
                        "Reff_kpc": float(parts[9]),
                        "SBeff_Lsun_pc2": float(parts[10]),
                        "Rdisk_kpc": float(parts[11]),
                        "SBdisk_Lsun_pc2": float(parts[12]),
                        "MHI_1e9Msun": float(parts[13]),
                        "RHI_kpc": float(parts[14]),
                        "Vflat_km_s": float(parts[15]),
                        "e_Vflat_km_s": float(parts[16]),
                        "Q": int(parts[17]),
                        "Ref": " ".join(parts[18:]),
                    }
            except Exception:
                parsed = None

        if parsed:
            rows.append(parsed)

    return {r["Galaxy"]: r for r in rows}, rows


def rotmod_files(rot_dir: Path) -> list[Path]:
    files = []
    for p in sorted(iter_files(rot_dir)):
        if p.is_file():
            low = p.name.lower()
            if "rar" in low or "table" in low:
                continue
            files.append(p)
    return files


def galaxy_from_rotmod_name(path: Path) -> str:
    stem = path.stem
    stem = re.sub(r"(?i)[_\-]?rotmod.*$", "", stem)
    stem = re.sub(r"(?i)\.dat$", "", stem)
    return stem.strip("_- ")


def numeric_rows(path: Path) -> list[list[float]]:
    rows = []
    for line in read_lines(path):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";") or s.startswith("|"):
            continue
        s = s.split("#", 1)[0].strip()
        vals = []
        ok = True
        for part in s.split():
            try:
                vals.append(float(part.replace("D", "E")))
            except Exception:
                ok = False
                break
        if ok and len(vals) >= 6:
            while len(vals) < 8:
                vals.append(float("nan"))
            rows.append(vals[:8])
    return rows


def sign_preserving_square(v: np.ndarray) -> np.ndarray:
    return v * np.abs(v)


def source_features(nums: list[list[float]]) -> dict:
    arr = np.array(nums, dtype=float)
    if arr.ndim != 2 or arr.shape[1] < 6:
        return {"source_feature_pass": False, "source_reason": "bad_numeric_shape"}

    # NOTE: columns 1 and 2 are Vobs/eVobs in ROTMOD. They are deliberately not read.
    R = arr[:, 0]
    Vgas = arr[:, 3]
    Vdisk = arr[:, 4]
    Vbul = arr[:, 5]

    mask = (
        np.isfinite(R) & (R > 0) &
        np.isfinite(Vgas) & np.isfinite(Vdisk) & np.isfinite(Vbul)
    )
    if np.sum(mask) < 3:
        return {"source_feature_pass": False, "source_reason": "too_few_source_rows"}

    R = R[mask]
    Vgas = Vgas[mask]
    Vdisk = Vdisk[mask]
    Vbul = Vbul[mask]

    gas_power_signed = sign_preserving_square(Vgas)
    gas_power_abs = np.abs(Vgas) ** 2
    disk_power = ML_DISK * Vdisk ** 2
    bulge_power = ML_BULGE * Vbul ** 2
    total_source_power = gas_power_abs + disk_power + bulge_power

    positive_total = total_source_power > 0
    if np.sum(positive_total) < 3:
        return {"source_feature_pass": False, "source_reason": "too_few_positive_source_power_rows"}

    R = R[positive_total]
    gas_power_signed = gas_power_signed[positive_total]
    gas_power_abs = gas_power_abs[positive_total]
    disk_power = disk_power[positive_total]
    bulge_power = bulge_power[positive_total]
    total_source_power = total_source_power[positive_total]

    total_sum = float(np.sum(total_source_power))
    bulge_sum = float(np.sum(bulge_power))
    disk_sum = float(np.sum(disk_power))
    gas_sum = float(np.sum(gas_power_abs))

    bulge_frac = bulge_sum / total_sum if total_sum > 0 else float("nan")
    disk_frac = disk_sum / total_sum if total_sum > 0 else float("nan")
    gas_frac = gas_sum / total_sum if total_sum > 0 else float("nan")

    # Concentration-ish source proxies, from source components only.
    # Half-source-power radius.
    order = np.argsort(R)
    R_sorted = R[order]
    power_sorted = total_source_power[order]
    csum = np.cumsum(power_sorted)
    half = 0.5 * csum[-1]
    half_idx = int(np.searchsorted(csum, half))
    source_half_radius_kpc = float(R_sorted[min(max(half_idx, 0), len(R_sorted)-1)])

    # Weighted source radius and spread.
    w = total_source_power / np.sum(total_source_power)
    mean_R = float(np.sum(w * R))
    rms_R = float(np.sqrt(np.sum(w * (R - mean_R) ** 2)))

    # Bulge centrality: bulge fraction weighted more toward inner source rows.
    invR = 1.0 / np.maximum(R, 1e-9)
    bulge_inner_weight = float(np.sum(bulge_power * invR) / np.sum(total_source_power * invR)) if np.sum(total_source_power * invR) > 0 else float("nan")

    # Gas outerness: source-weighted gas radius relative to all-source radius.
    gas_wsum = float(np.sum(gas_power_abs))
    gas_mean_R = float(np.sum(gas_power_abs * R) / gas_wsum) if gas_wsum > 0 else float("nan")
    gas_outerness = gas_mean_R / mean_R if mean_R > 0 and math.isfinite(gas_mean_R) else float("nan")

    return {
        "source_feature_pass": True,
        "source_reason": "",
        "source_rows": int(len(R)),
        "source_R_min_kpc": float(np.min(R)),
        "source_R_max_kpc": float(np.max(R)),
        "source_R_mean_weighted_kpc": mean_R,
        "source_R_rms_weighted_kpc": rms_R,
        "source_half_power_radius_kpc": source_half_radius_kpc,
        "source_bulge_fraction_proxy": bulge_frac,
        "source_disk_fraction_proxy": disk_frac,
        "source_gas_fraction_proxy": gas_frac,
        "source_bulge_inner_weight_proxy": bulge_inner_weight,
        "source_gas_outerness_proxy": gas_outerness,
        "source_total_power_proxy": total_sum,
        "source_bulge_power_proxy": bulge_sum,
        "source_disk_power_proxy": disk_sum,
        "source_gas_power_proxy": gas_sum,
    }


def build_feature_table(meta_by_gal: dict[str, dict], rot_files: list[Path]) -> tuple[list[dict], list[dict]]:
    rows = []
    parse_rows = []
    for p in rot_files:
        gal = galaxy_from_rotmod_name(p)
        meta = meta_by_gal.get(gal, {})
        nums = numeric_rows(p)
        sf = source_features(nums)

        # Metadata-only ratios and morphology coordinates.
        L36 = meta.get("L36_1e9Lsun", float("nan"))
        MHI = meta.get("MHI_1e9Msun", float("nan"))
        Reff = meta.get("Reff_kpc", float("nan"))
        Rdisk = meta.get("Rdisk_kpc", float("nan"))
        RHI = meta.get("RHI_kpc", float("nan"))
        SBeff = meta.get("SBeff_Lsun_pc2", float("nan"))
        SBdisk = meta.get("SBdisk_Lsun_pc2", float("nan"))
        Vflat = meta.get("Vflat_km_s", float("nan"))
        Type = meta.get("Type", float("nan"))

        # Normalize Type monotonically from early to late.
        # This is a coordinate only, not a prediction law.
        type_late_coordinate_0_to_1 = float(np.clip((Type - 0.0) / 11.0, 0.0, 1.0)) if math.isfinite(float(Type)) else float("nan")
        type_early_coordinate_0_to_1 = 1.0 - type_late_coordinate_0_to_1 if math.isfinite(type_late_coordinate_0_to_1) else float("nan")

        # Gas-to-light metadata proxy.
        gas_to_light_proxy = MHI / L36 if math.isfinite(MHI) and math.isfinite(L36) and L36 > 0 else float("nan")
        size_ratio_RHI_Reff = RHI / Reff if math.isfinite(RHI) and math.isfinite(Reff) and Reff > 0 else float("nan")
        disk_scale_ratio_Rdisk_Reff = Rdisk / Reff if math.isfinite(Rdisk) and math.isfinite(Reff) and Reff > 0 else float("nan")

        row = {
            "Galaxy": gal,
            "metadata_present": bool(meta),
            "rotmod_file": str(p),
            "allowed_feature_table_version": PROTOCOL_VERSION,

            # SPARC metadata.
            "Type": Type if meta else "",
            "type_late_coordinate_0_to_1": type_late_coordinate_0_to_1,
            "type_early_coordinate_0_to_1": type_early_coordinate_0_to_1,
            "Distance_Mpc": meta.get("Distance_Mpc", ""),
            "Inclination_deg": meta.get("Inclination_deg", ""),
            "L36_1e9Lsun": L36 if meta else "",
            "MHI_1e9Msun": MHI if meta else "",
            "Reff_kpc": Reff if meta else "",
            "Rdisk_kpc": Rdisk if meta else "",
            "RHI_kpc": RHI if meta else "",
            "SBeff_Lsun_pc2": SBeff if meta else "",
            "SBdisk_Lsun_pc2": SBdisk if meta else "",
            "Vflat_km_s": Vflat if meta else "",
            "Q": meta.get("Q", ""),

            # Metadata morphology/source coordinates.
            "gas_to_light_proxy_MHI_over_L36": gas_to_light_proxy,
            "size_ratio_RHI_over_Reff": size_ratio_RHI_Reff,
            "disk_scale_ratio_Rdisk_over_Reff": disk_scale_ratio_Rdisk_Reff,

            # Source-only ROTMOD feature proxies. No Vobs/eVobs.
            **sf,

            # Theoretical endpoints are allowed constants, not data-derived.
            "lambda_disk_endpoint_3pi8": LAMBDA_DISK,
            "lambda_sphere_endpoint_4over3": LAMBDA_SPHERE,
            "delta_lambda_endpoint_width": DELTA_LAMBDA,

            # Explicit non-use flags.
            "uses_Vobs": False,
            "uses_eVobs": False,
            "uses_lambda_best": False,
            "uses_rotation_residuals": False,
            "uses_RAR_All_Data": False,
            "uses_DBE_old_track2": False,
            "lambda_prediction_made": False,
        }
        rows.append(row)
        parse_rows.append({
            "Galaxy": gal,
            "rotmod_file": str(p),
            "metadata_present": bool(meta),
            "numeric_rows_found": len(nums),
            "source_feature_pass": sf.get("source_feature_pass", False),
            "source_reason": sf.get("source_reason", ""),
        })

    return rows, parse_rows


def summary_stats(feature_rows: list[dict]) -> list[dict]:
    fields = [
        "Type",
        "type_late_coordinate_0_to_1",
        "type_early_coordinate_0_to_1",
        "Inclination_deg",
        "L36_1e9Lsun",
        "MHI_1e9Msun",
        "gas_to_light_proxy_MHI_over_L36",
        "source_bulge_fraction_proxy",
        "source_disk_fraction_proxy",
        "source_gas_fraction_proxy",
        "source_bulge_inner_weight_proxy",
        "source_gas_outerness_proxy",
        "source_half_power_radius_kpc",
    ]
    out = []
    for f in fields:
        vals = []
        for r in feature_rows:
            try:
                x = float(r.get(f, float("nan")))
            except Exception:
                x = float("nan")
            if math.isfinite(x):
                vals.append(x)
        if vals:
            arr = np.array(vals, dtype=float)
            out.append({
                "feature": f,
                "n_finite": int(len(arr)),
                "mean": float(np.mean(arr)),
                "median": float(np.median(arr)),
                "std": float(np.std(arr, ddof=1)) if len(arr) > 1 else 0.0,
                "p16": float(np.percentile(arr, 16)),
                "p84": float(np.percentile(arr, 84)),
                "min": float(np.min(arr)),
                "max": float(np.max(arr)),
            })
        else:
            out.append({"feature": f, "n_finite": 0})
    return out


def allowed_inputs_rows() -> list[dict]:
    return [
        {"input": "Table1 Galaxy metadata", "allowed": True, "purpose": "morphology/source descriptors", "notes": "Type, distance, inclination, luminosity, size, MHI, Q"},
        {"input": "ROTMOD radius column", "allowed": True, "purpose": "source geometry coordinates", "notes": "Radius only; not target residual"},
        {"input": "ROTMOD Vgas column", "allowed": True, "purpose": "gas source proxy", "notes": "source component only"},
        {"input": "ROTMOD Vdisk column", "allowed": True, "purpose": "disk source proxy", "notes": "source component only"},
        {"input": "ROTMOD Vbul column", "allowed": True, "purpose": "bulge/source sphericity proxy", "notes": "source component only"},
        {"input": "fixed Upsilon_disk=0.5", "allowed": True, "purpose": "source proxy construction", "notes": "inherited from Track1 fixed inputs"},
        {"input": "fixed Upsilon_bulge=0.7", "allowed": True, "purpose": "source proxy construction", "notes": "inherited from Track1 fixed inputs"},
        {"input": "lambda_disk=3pi/8", "allowed": True, "purpose": "theoretical endpoint", "notes": "not fit"},
        {"input": "lambda_sphere=4/3", "allowed": True, "purpose": "theoretical endpoint", "notes": "not fit"},
        {"input": "inclination", "allowed": True, "purpose": "control variable", "notes": "may be used for null/control, not primary morphology target unless predeclared"},
        {"input": "quality Q", "allowed": True, "purpose": "sample/control variable", "notes": "not for tuning coefficients"},
    ]


def forbidden_inputs_rows() -> list[dict]:
    return [
        {"input": "Track1 lambda_best", "forbidden_for": "feature construction and law selection", "notes": "may only be joined in Track2R-04 validation after lambda_pred table is sealed"},
        {"input": "Track1 chi2(lambda)", "forbidden_for": "law selection", "notes": "would leak target"},
        {"input": "Vobs/eVobs", "forbidden_for": "Track2R-01 feature construction", "notes": "needed only later for final rotation-curve validation"},
        {"input": "rotation-curve residuals", "forbidden_for": "all predictor design", "notes": "no residual tuning"},
        {"input": "RAR_All_Data", "forbidden_for": "Track2R morphology readout", "notes": "not morphology-lambda target"},
        {"input": "dark halo parameters", "forbidden_for": "all gates", "notes": "not used"},
        {"input": "old Track2 E, D, or B", "forbidden_for": "new Track2R predictor", "notes": "old branch archived internal only"},
        {"input": "Gate14C/14D damage diagnostics", "forbidden_for": "parameter repair", "notes": "used only as motivation to restart, not as predictor input"},
        {"input": "per-galaxy tuned exponent/offset", "forbidden_for": "all gates", "notes": "would defeat prediction"},
    ]


def gate_blueprint_rows() -> list[dict]:
    return [
        {
            "gate": "Track2R-01",
            "status_after_this_script": "COMPLETE_IF_HASHED",
            "task": "Freeze clean morphology-readout protocol boundary and allowed feature table.",
            "success_criterion": "Feature table built without lambda_best, residuals, RAR, dark halos, or old D/B/E.",
            "output": "protocol hash + allowed feature table",
        },
        {
            "gate": "Track2R-02",
            "status_after_this_script": "NEXT",
            "task": "Choose/freeze lambda_pred readout law from allowed morphology/source variables only.",
            "success_criterion": "A law is selected before joining Track1 lambda_best and with no residual tuning.",
            "output": "readout law manifest and hash",
        },
        {
            "gate": "Track2R-03",
            "status_after_this_script": "PENDING",
            "task": "Generate sealed lambda_pred table for every galaxy.",
            "success_criterion": "Prediction table hash written before target join.",
            "output": "lambda_pred table + SHA-256",
        },
        {
            "gate": "Track2R-04",
            "status_after_this_script": "PENDING",
            "task": "Validate sealed lambda_pred against Track1 lambda_best.",
            "success_criterion": "Report rank, RMS, endpoint behavior, and no-retuning audit.",
            "output": "validation report",
        },
        {
            "gate": "Track2R-05",
            "status_after_this_script": "PENDING",
            "task": "Use sealed lambda_pred in rotation-curve prediction.",
            "success_criterion": "Compare to fixed lambda=1, fixed disk endpoint, fixed sphere endpoint, and Track1 best-lambda ceiling.",
            "output": "rotation-curve validation",
        },
    ]


def no_target_audit_rows(inputs: dict) -> list[dict]:
    return [
        {"item": "Track1 lambda_best file detected", "detected": inputs["track1_lambda_best_forbidden"] is not None, "used": False, "path": str(inputs["track1_lambda_best_forbidden"] or ""), "status": "QUARANTINED"},
        {"item": "Track1B robustness file detected", "detected": inputs["track1b_robustness_forbidden"] is not None, "used": False, "path": str(inputs["track1b_robustness_forbidden"] or ""), "status": "QUARANTINED"},
        {"item": "RAR_All_Data detected", "detected": inputs["rar_all_data_quarantined"] is not None, "used": False, "path": str(inputs["rar_all_data_quarantined"] or ""), "status": "QUARANTINED"},
        {"item": "Old Track2 Gate14C joined rows detected", "detected": inputs["old_track2_14c_forbidden"] is not None, "used": False, "path": str(inputs["old_track2_14c_forbidden"] or ""), "status": "QUARANTINED"},
        {"item": "Old Track2 Gate14D verdict detected", "detected": inputs["old_track2_14d_forbidden"] is not None, "used": False, "path": str(inputs["old_track2_14d_forbidden"] or ""), "status": "QUARANTINED"},
        {"item": "Vobs/eVobs columns in ROTMOD", "detected": True, "used": False, "path": "ROTMOD columns 2-3 ignored by parser", "status": "NOT_READ_FOR_FEATURES"},
        {"item": "lambda prediction generated", "detected": False, "used": False, "path": "", "status": "NOT_THIS_GATE"},
    ]


def protocol_manifest(feature_table_sha: str, inputs: dict, n_features: int) -> dict:
    # Important: keep this independent of machine-specific paths where possible.
    return {
        "protocol_version": PROTOCOL_VERSION,
        "purpose": "Clean restart of Track2 as morphology-readout lambda prediction protocol.",
        "status": "protocol_boundary_and_feature_table_freeze",
        "theory_law_target": "g_eff^2 = g_bar^2 + lambda_morph * a_SFT * g_bar",
        "track1_status": "main SPARC result, target for later validation only",
        "old_track2_status": "internal note only; old SPARC-internal D/B/E branch not used",
        "fixed_constants": {
            "H0_km_s_Mpc": H0_KM_S_MPC,
            "a_SFT_m_s2": A_SFT,
            "ML_disk": ML_DISK,
            "ML_bulge": ML_BULGE,
            "lambda_disk_3pi8": LAMBDA_DISK,
            "lambda_sphere_4over3": LAMBDA_SPHERE,
            "delta_lambda": DELTA_LAMBDA,
        },
        "allowed_feature_inputs": [r["input"] for r in allowed_inputs_rows()],
        "forbidden_inputs": [r["input"] for r in forbidden_inputs_rows()],
        "feature_table_rows": n_features,
        "feature_table_sha256": feature_table_sha,
        "next_gates": gate_blueprint_rows(),
        "epistemic_boundary": (
            "This is not fully prospective with respect to the discovery that morphology correlates with lambda; "
            "it is a clean no-target restart for predicting lambda from metadata/source features without using lambda_best."
        ),
    }


def write_report(path: Path, manifest: dict, protocol_hash: str, verdict: dict,
                 allowed: list[dict], forbidden: list[dict], audit: list[dict],
                 blueprint: list[dict], summary: list[dict]) -> None:
    def table(rows, cols):
        lines = ["| " + " | ".join(label for _, label in cols) + " |\n",
                 "|" + "|".join("---" for _ in cols) + "|\n"]
        for r in rows:
            lines.append("| " + " | ".join(str(r.get(k, "")) for k, _ in cols) + " |\n")
        return "".join(lines)

    text = f"""# SFT Track2R-01: Morphology-Readout Protocol Restart

## Verdict

**{verdict['verdict']}**

Protocol hash:

`{protocol_hash}`

## What changed

The old Track 2 SPARC-internal `D/B/E` environment implementation is archived as an internal note only. Track2R restarts from the structure supported by Track 1:

\\[
g_{{\\rm eff}}^2 = g_{{\\rm bar}}^2 + \\lambda_{{\\rm morph}} a_{{\\rm SFT}} g_{{\\rm bar}}.
\\]

Track2R-01 does not predict \\(\\lambda\\). It freezes the allowed metadata/source feature table and the no-target firewall for later prediction.

## Allowed inputs

{table(allowed, [('input','Input'),('purpose','Purpose'),('notes','Notes')])}

## Forbidden inputs

{table(forbidden, [('input','Input'),('forbidden_for','Forbidden for'),('notes','Notes')])}

## No-target audit

{table(audit, [('item','Item'),('detected','Detected'),('used','Used'),('status','Status')])}

## Gate blueprint

{table(blueprint, [('gate','Gate'),('task','Task'),('success_criterion','Success criterion'),('output','Output')])}

## Feature summary

{table(summary, [('feature','Feature'),('n_finite','N finite'),('median','Median'),('p16','p16'),('p84','p84'),('min','Min'),('max','Max')])}

## Claim boundary

This protocol supports a later test of whether \\(\\lambda_{{\\rm morph}}\\) can be predicted from morphology/source-readout variables. It does not support a claim that the predictor has already succeeded, and it does not revive the old SPARC-internal environment channel.

## Next step

Track2R-02 should choose a no-target \\(\\lambda_{{\\rm pred}}\\) readout law from these allowed features only, then hash that law before any join to Track 1 \\(\\lambda_{{\\rm best}}\\).
"""
    path.write_text(text, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sparc-dir", default=r"C:\Users\TaicHI\SPARC")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--table1-path", default=None)
    args = ap.parse_args()

    sparc_dir = Path(args.sparc_dir).expanduser().resolve()
    out = Path(args.out_dir).expanduser().resolve() if args.out_dir else sparc_dir / OUT_DIR_NAME
    out.mkdir(parents=True, exist_ok=True)

    if not sparc_dir.exists():
        print(f"ERROR: SPARC directory not found: {sparc_dir}", file=sys.stderr)
        sys.exit(2)

    inputs = find_inputs(sparc_dir, args.table1_path)
    if inputs["table1"] is None or inputs["rotmod_ltg_dir"] is None:
        print("ERROR: missing Table1.txt or Rotmod_LTG directory.", file=sys.stderr)
        print(inputs, file=sys.stderr)
        sys.exit(2)

    meta_by_gal, meta_rows = parse_table1(inputs["table1"])
    if not meta_rows:
        print(f"ERROR: Table1 parsed 0 rows: {inputs['table1']}", file=sys.stderr)
        sys.exit(3)

    rot_files = rotmod_files(inputs["rotmod_ltg_dir"])
    feature_rows, parse_rows = build_feature_table(meta_by_gal, rot_files)
    feature_rows = sorted(feature_rows, key=lambda r: r["Galaxy"])

    # Write provisional feature table first so its hash becomes part of protocol manifest.
    feature_path = out / "track2r01_allowed_feature_table.csv"
    write_csv(feature_path, feature_rows)
    feature_sha = sha256_file(feature_path)

    allowed = allowed_inputs_rows()
    forbidden = forbidden_inputs_rows()
    audit = no_target_audit_rows(inputs)
    blueprint = gate_blueprint_rows()
    summary = summary_stats(feature_rows)

    manifest = protocol_manifest(feature_sha, inputs, len(feature_rows))
    protocol_hash = sha256_text(canonical_json(manifest))
    manifest["protocol_hash_sha256"] = protocol_hash

    # Output all artifacts.
    (out / "track2r01_protocol_hash.txt").write_text(protocol_hash + "\n", encoding="utf-8")
    (out / "track2r01_protocol_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    write_csv(out / "track2r01_parse_audit.csv", parse_rows)
    write_csv(out / "track2r01_feature_summary.csv", summary)
    write_csv(out / "track2r01_allowed_inputs.csv", allowed)
    write_csv(out / "track2r01_forbidden_inputs.csv", forbidden)
    write_csv(out / "track2r01_no_target_audit.csv", audit)
    write_csv(out / "track2r01_gate_blueprint.csv", blueprint)

    n_feature_pass = sum(1 for r in feature_rows if r.get("source_feature_pass") is True)
    n_metadata = sum(1 for r in feature_rows if r.get("metadata_present") is True)
    forbidden_used = any(str(r["used"]).lower() == "true" for r in audit)

    checks = {
        "table1_parsed_rows": len(meta_rows),
        "rotmod_files": len(rot_files),
        "feature_rows": len(feature_rows),
        "metadata_present_rows": n_metadata,
        "source_feature_pass_rows": n_feature_pass,
        "forbidden_targets_used": forbidden_used,
        "feature_table_sha256": feature_sha,
        "protocol_hash_sha256": protocol_hash,
    }

    if len(feature_rows) == len(rot_files) and n_metadata == len(rot_files) and n_feature_pass == len(rot_files) and not forbidden_used:
        v = "TRACK2R01_MORPHOLOGY_READOUT_PROTOCOL_FROZEN_READY_FOR_TRACK2R02"
    else:
        v = "TRACK2R01_PROTOCOL_REQUIRES_INPUT_REVIEW"

    verdict = {
        "verdict": v,
        "claim_boundary": "Track2R-01 protocol/feature freeze only; no lambda prediction, no validation, no refit, no retuning",
        "protocol_version": PROTOCOL_VERSION,
        "protocol_hash_sha256": protocol_hash,
        "feature_table_sha256": feature_sha,
        "table1_rows": len(meta_rows),
        "rotmod_files": len(rot_files),
        "feature_rows": len(feature_rows),
        "metadata_present_rows": n_metadata,
        "source_feature_pass_rows": n_feature_pass,
        "uses_lambda_best": False,
        "uses_Vobs_or_eVobs": False,
        "uses_rotation_residuals": False,
        "uses_RAR_All_Data": False,
        "uses_old_DBE_track2": False,
        "forbidden_targets_used": forbidden_used,
        "main_result": (
            "Clean Track2R restart protocol boundary and allowed morphology/source feature table are frozen. "
            "Next gate may choose lambda_pred readout law from allowed variables only."
        ),
        "next_gate": "Track2R-02: freeze no-target lambda_pred readout selector before joining Track1 lambda_best.",
    }
    write_csv(out / "track2r01_verdict.csv", [verdict])

    write_report(
        out / "TRACK2R_01_morphology_readout_protocol_report.md",
        manifest, protocol_hash, verdict, allowed, forbidden, audit, blueprint, summary
    )

    # Also write a compact console-friendly summary.
    print("\nSFT TRACK2R-01 MORPHOLOGY-READOUT PROTOCOL RESTART")
    print("===================================================")
    print("\nPurpose:")
    print("  Restart Track2 from morphology-dependent lambda, not old SPARC-internal D/B/E.")
    print("  Build allowed feature table only. No lambda prediction or validation in this gate.")

    print("\nInputs:")
    print(f"  Table1: {inputs['table1']}")
    print(f"  Rotmod_LTG: {inputs['rotmod_ltg_dir']}")
    print(f"  RAR_All_Data: {inputs['rar_all_data_quarantined']}  [QUARANTINED]")
    print(f"  Track1 lambda_best: {inputs['track1_lambda_best_forbidden']}  [QUARANTINED]")
    print(f"  Old Track2 14C: {inputs['old_track2_14c_forbidden']}  [QUARANTINED]")
    print(f"  Old Track2 14D: {inputs['old_track2_14d_forbidden']}  [QUARANTINED]")

    print("\nConstants:")
    print(f"  a_SFT_m_s2: {A_SFT:.12e}")
    print(f"  lambda_disk_3pi8: {LAMBDA_DISK:.12f}")
    print(f"  lambda_sphere_4over3: {LAMBDA_SPHERE:.12f}")
    print(f"  ML_disk: {ML_DISK}")
    print(f"  ML_bulge: {ML_BULGE}")

    print("\nCounts/checks:")
    for k, val in checks.items():
        print(f"  {k}: {val}")

    print("\nNo-target audit:")
    for r in audit:
        print(f"  {r['item']:40s} detected={r['detected']} used={r['used']} status={r['status']}")

    print("\nFeature summary:")
    for r in summary:
        med = r.get("median", "")
        p16 = r.get("p16", "")
        p84 = r.get("p84", "")
        print(f"  {r['feature']:40s} N={r.get('n_finite','')} median={med} p16={p16} p84={p84}")

    print("\nGate blueprint:")
    for r in blueprint:
        print(f"  {r['gate']:12s} {r['status_after_this_script']:22s} {r['task']}")

    print("\nVerdict:")
    for k, val in verdict.items():
        print(f"  {k}: {val}")

    print("\nFiles:")
    print(f"  output directory: {out}")
    print(f"  protocol hash: {out/'track2r01_protocol_hash.txt'}")
    print(f"  manifest: {out/'track2r01_protocol_manifest.json'}")
    print(f"  feature table: {out/'track2r01_allowed_feature_table.csv'}")
    print(f"  feature summary: {out/'track2r01_feature_summary.csv'}")
    print(f"  no-target audit: {out/'track2r01_no_target_audit.csv'}")
    print(f"  gate blueprint: {out/'track2r01_gate_blueprint.csv'}")
    print(f"  verdict: {out/'track2r01_verdict.csv'}")
    print(f"  report: {out/'TRACK2R_01_morphology_readout_protocol_report.md'}")


if __name__ == "__main__":
    main()
