# SFT Track2R-04: Lambda Prediction Validation

## Verdict

**TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS**

Interpretation:

primary selector has positive target correlation and beats constant endpoint/midpoint controls

## Claim boundary

This gate validates the sealed Track2R-03 predictions against Track1 lambda_best. It does not change the selector, does not change the prediction table, and does not fit a new coefficient.

## Hash checks

| Check | Pass | Observed | Required |
|---|---|---|---|
| prediction_table_hash_matches_track2r03_hash_file | True | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b |
| prediction_table_hash_matches_expected | True | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b |
| all_rows_selector_hash_expected | True | 2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021 | 2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021 |
| all_rows_track2r03_version_expected | True | SFT_TRACK2R_03_SEALED_LAMBDA_PREDICTION_TABLE_v1 | SFT_TRACK2R_03_SEALED_LAMBDA_PREDICTION_TABLE_v1 |
| track1_target_table_present | True | C:\Users\TaicHI\SPARC\SFT_SPARC_TRACK1_LAMBDA_WIDE_OUTPUT\sparc_lambda_wide_per_galaxy.csv | sparc_lambda_wide_per_galaxy.csv |


## No-retuning audit

| Item | Detected | Used | Status |
|---|---|---|---|
| Track2R-03 sealed prediction table | True | True | SEALED_INPUT |
| Track1 lambda_best target table | True | True | VALIDATION_TARGET_ONLY |
| Track2R-02 selector manifest | True | False | NOT_MODIFIED |
| RAR_All_Data | True | False | QUARANTINED |
| Old Track2 Gate14C | True | False | QUARANTINED |
| Old Track2 Gate14D | True | False | QUARANTINED |
| selector or predictions changed after validation | False | False | NO |
| rotation residuals used for fitting | False | False | NO |
| new coefficient fit | False | False | NO |


## Groups

| Group | Description | N |
|---|---|---|
| FULL | all joined rows | 175 |
| INTERIOR_NON_EDGE | rows not edge-railed in Track1 lambda fit | 134 |
| EDGE_ONLY | rows edge-railed in Track1 lambda fit | 41 |
| LOW_EDGE_ONLY | low-edge rows in Track1 lambda fit | 16 |
| HIGH_EDGE_ONLY | high-edge rows in Track1 lambda fit | 25 |
| Q1_ONLY | quality flag Q=1 | 99 |
| Q1_Q2 | quality flag Q=1 or Q=2 | 163 |
| TYPE_2_TO_10 | 2 <= Hubble Type <= 10 | 164 |
| TYPE_2_TO_10_INTERIOR | 2 <= Hubble Type <= 10 and non-edge | 129 |
| EXCLUDE_T0_T11 | exclude Type 0 and Type 11 endpoints | 167 |
| EXCLUDE_T0_T11_INTERIOR | exclude Type 0/11 and edge rows | 132 |
| NPOINTS_GE_MEDIAN | n_points >= median (14.0) | 89 |
| NPOINTS_GE_MEDIAN_INTERIOR | n_points >= median (14.0) and non-edge | 71 |


## Full-sample selector metrics

| Selector | N | Spearman rho | p | RMSE | MAE | Median abs | Mean bias |
|---|---|---|---|---|---|---|---|
| PRIMARY_TYPE_ENDPOINT_LINEAR | 175 | 0.27161389600924596 | 0.0002769472823964572 | 0.7274371744497276 | 0.616752751448737 | 0.5751161532983631 | -0.06480601042641303 |
| SECONDARY_SOURCE_ROOT_SPHERICITY | 175 | 0.19375979897915474 | 0.010192554655342257 | 0.7342351829148143 | 0.6185271313264886 | 0.5766487415636579 | -0.08594791074167434 |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | 175 | 0.28717161027990473 | 0.0001165944428951299 | 0.7306265274275271 | 0.6174975967650194 | 0.5753824474310105 | -0.07537696058404367 |
| CONTROL_CONSTANT_DISK_ENDPOINT | 175 | nan | nan | 0.7440877214796991 | 0.6203296040895617 | 0.5719027549038289 | -0.1243198977609713 |
| CONTROL_CONSTANT_SPHERE_ENDPOINT | 175 | nan | nan | 0.7342798588488669 | 0.6373923809523813 | 0.5963333333333329 | 0.03091619047618954 |
| CONTROL_CONSTANT_ENDPOINT_MIDPOINT | 175 | nan | nan | 0.7351137078106945 | 0.6268515489914851 | 0.5957152892147526 | -0.04670185364239079 |


## Full-sample rankings

| Metric | Rank | Selector | Value | p |
|---|---|---|---|---|
| rmse | 1 | PRIMARY_TYPE_ENDPOINT_LINEAR | 0.7274371744497276 |  |
| rmse | 2 | TERTIARY_EQUAL_TYPE_SOURCE_BLEND | 0.7306265274275271 |  |
| rmse | 3 | SECONDARY_SOURCE_ROOT_SPHERICITY | 0.7342351829148143 |  |
| rmse | 4 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.7342798588488669 |  |
| rmse | 5 | CONTROL_CONSTANT_ENDPOINT_MIDPOINT | 0.7351137078106945 |  |
| rmse | 6 | CONTROL_CONSTANT_DISK_ENDPOINT | 0.7440877214796991 |  |
| mae | 1 | PRIMARY_TYPE_ENDPOINT_LINEAR | 0.616752751448737 |  |
| mae | 2 | TERTIARY_EQUAL_TYPE_SOURCE_BLEND | 0.6174975967650194 |  |
| mae | 3 | SECONDARY_SOURCE_ROOT_SPHERICITY | 0.6185271313264886 |  |
| mae | 4 | CONTROL_CONSTANT_DISK_ENDPOINT | 0.6203296040895617 |  |
| mae | 5 | CONTROL_CONSTANT_ENDPOINT_MIDPOINT | 0.6268515489914851 |  |
| mae | 6 | CONTROL_CONSTANT_SPHERE_ENDPOINT | 0.6373923809523813 |  |
| spearman_rho | 1 | TERTIARY_EQUAL_TYPE_SOURCE_BLEND | 0.28717161027990473 | 0.0001165944428951299 |
| spearman_rho | 2 | PRIMARY_TYPE_ENDPOINT_LINEAR | 0.27161389600924596 | 0.0002769472823964572 |
| spearman_rho | 3 | SECONDARY_SOURCE_ROOT_SPHERICITY | 0.19375979897915474 | 0.010192554655342257 |
| spearman_rho | 4 | CONTROL_CONSTANT_DISK_ENDPOINT | nan | nan |
| spearman_rho | 5 | CONTROL_CONSTANT_SPHERE_ENDPOINT | nan | nan |
| spearman_rho | 6 | CONTROL_CONSTANT_ENDPOINT_MIDPOINT | nan | nan |


## Join issues

| Galaxy | Key | Reason | Note |
|---|---|---|---|


## Next step

If the primary selector shows useful directional validation, Track2R-05 may use the sealed predictions for rotation-curve validation. If it fails, this gate becomes an internal note and any revised selector requires a new predeclared fork.
