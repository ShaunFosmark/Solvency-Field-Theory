#!/usr/bin/env python3
"""
SFT Track2R-04:
Validate Sealed Lambda Predictions Against Track 1 Lambda_Best

Prerequisites
-------------
Track2R-03 generated and sealed the lambda_pred prediction table.
Track1 generated sparc_lambda_wide_per_galaxy.csv with lambda_best.

This is the first Track2R gate allowed to join lambda_pred to Track1
lambda_best. It must not alter predictions, selector laws, hashes, or
Track1 targets.

This gate validates:
    - PRIMARY_TYPE_ENDPOINT_LINEAR
    - SECONDARY_SOURCE_ROOT_SPHERICITY
    - TERTIARY_EQUAL_TYPE_SOURCE_BLEND
    - CONTROL_CONSTANT_DISK_ENDPOINT
    - CONTROL_CONSTANT_SPHERE_ENDPOINT
    - CONTROL_CONSTANT_ENDPOINT_MIDPOINT

Outputs
-------
    track2r04_joined_validation_rows.csv
    track2r04_selector_metrics.csv
    track2r04_selector_rankings.csv
    track2r04_hash_checks.csv
    track2r04_no_retuning_audit.csv
    track2r04_group_definitions.csv
    track2r04_verdict.csv
    TRACK2R_04_lambda_prediction_validation_report.md
    plots/*.png when matplotlib is available

Run
---
    python SFT_TRACK2R_04_validate_sealed_lambda_predictions.py --sparc-dir "C:\\Users\\TaicHI\\SPARC"

Claim boundary
--------------
This is validation only. Any modification of the selector or prediction
table after seeing these results is a new fork.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
from pathlib import Path
from typing import Any

import numpy as np

try:
    from scipy.stats import spearmanr, pearsonr, kendalltau
    SCIPY_OK = True
except Exception:
    SCIPY_OK = False
    spearmanr = pearsonr = kendalltau = None

try:
    import matplotlib.pyplot as plt
    MPL_OK = True
except Exception:
    MPL_OK = False
    plt = None

PROTOCOL_VERSION = "SFT_TRACK2R_04_LAMBDA_PREDICTION_VALIDATION_v1"
EXPECTED_TRACK2R03_VERSION = "SFT_TRACK2R_03_SEALED_LAMBDA_PREDICTION_TABLE_v1"

OUT_DIR_NAME = "SFT_TRACK2R_04_LAMBDA_PREDICTION_VALIDATION"

EXPECTED_SELECTOR_HASH = "2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021"
EXPECTED_PREDICTION_TABLE_HASH = "f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b"

SELECTORS = [
    ("primary", "lambda_pred_primary_type_endpoint_linear", "PRIMARY_TYPE_ENDPOINT_LINEAR"),
    ("secondary_source", "lambda_pred_secondary_source_root_sphericity", "SECONDARY_SOURCE_ROOT_SPHERICITY"),
    ("tertiary_blend", "lambda_pred_tertiary_equal_type_source_blend", "TERTIARY_EQUAL_TYPE_SOURCE_BLEND"),
    ("control_disk", "lambda_control_disk_endpoint", "CONTROL_CONSTANT_DISK_ENDPOINT"),
    ("control_sphere", "lambda_control_sphere_endpoint", "CONTROL_CONSTANT_SPHERE_ENDPOINT"),
    ("control_midpoint", "lambda_control_endpoint_midpoint", "CONTROL_CONSTANT_ENDPOINT_MIDPOINT"),
]


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def safe_int(x: Any, default: int = -999) -> int:
    try:
        if x is None or x == "":
            return default
        return int(float(x))
    except Exception:
        return default


def boolish(x: Any) -> bool:
    s = str(x).strip().lower()
    if s in ("true", "t", "1", "yes", "y"):
        return True
    if s in ("false", "f", "0", "no", "n", "", "nan", "none"):
        return False
    try:
        return bool(float(s))
    except Exception:
        return bool(s)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def normalize_galaxy_name(x: Any) -> str:
    return str(x).strip().lower().replace(" ", "")


def find_paths(sparc_dir: Path, pred_table_arg: str | None, track1_arg: str | None) -> dict:
    track2r03 = sparc_dir / "SFT_TRACK2R_03_SEALED_LAMBDA_PREDICTIONS"
    track1 = sparc_dir / "SFT_SPARC_TRACK1_LAMBDA_WIDE_OUTPUT"

    pred_table = Path(pred_table_arg).expanduser() if pred_table_arg else track2r03 / "track2r03_lambda_pred_table.csv"
    if not pred_table.is_absolute():
        pred_table = sparc_dir / pred_table

    track1_table = Path(track1_arg).expanduser() if track1_arg else track1 / "sparc_lambda_wide_per_galaxy.csv"
    if not track1_table.is_absolute():
        track1_table = sparc_dir / track1_table

    return {
        "track2r03_dir": track2r03,
        "track2r03_pred_table": pred_table,
        "track2r03_pred_hash_file": track2r03 / "track2r03_lambda_pred_table_sha256.txt",
        "track2r03_verdict": track2r03 / "track2r03_verdict.csv",
        "track2r03_manifest": track2r03 / "track2r03_manifest.json",
        "track1_per_galaxy": track1_table,
        "track1_verdict": track1 / "sparc_lambda_wide_verdict.csv",
        "track1b_verdict": sparc_dir / "SFT_SPARC_TRACK1B_ROBUSTNESS_OUTPUT" / "track1b_verdict.csv",
        "rar_forbidden": sparc_dir / "RAR_All_Data.txt",
        "old_track2_14c_forbidden": sparc_dir / "SFT_GRAV_TRAJ_14C_OUTPUT" / "gate14c_validation_joined_rows.csv",
        "old_track2_14d_forbidden": sparc_dir / "SFT_GRAV_TRAJ_14D_OUTPUT" / "gate14d_verdict.csv",
    }


def infer_col(columns: list[str], candidates: list[str], required: bool = True, label: str = "") -> str | None:
    lower = {c.lower(): c for c in columns}
    compact = {c.lower().replace("_", "").replace("-", "").replace(" ", ""): c for c in columns}

    for cand in candidates:
        if cand.lower() in lower:
            return lower[cand.lower()]
    for cand in candidates:
        key = cand.lower().replace("_", "").replace("-", "").replace(" ", "")
        if key in compact:
            return compact[key]

    # Partial fallback: candidate contained in column compact name.
    for cand in candidates:
        key = cand.lower().replace("_", "").replace("-", "").replace(" ", "")
        for ck, orig in compact.items():
            if key and key in ck:
                return orig

    if required:
        raise RuntimeError(f"Required column not found for {label or candidates}: candidates={candidates}; columns={columns}")
    return None


def load_inputs(paths: dict) -> tuple[list[dict], list[dict], dict]:
    missing = [p for p in [paths["track2r03_pred_table"], paths["track1_per_galaxy"]] if not p.exists()]
    if missing:
        print("ERROR: missing required validation files:", file=sys.stderr)
        for p in missing:
            print(f"  {p}", file=sys.stderr)
        print("\nUse --pred-table or --track1-table to provide explicit paths.", file=sys.stderr)
        sys.exit(2)

    pred_rows = read_csv(paths["track2r03_pred_table"])
    target_rows = read_csv(paths["track1_per_galaxy"])

    if not pred_rows or not target_rows:
        raise RuntimeError("Prediction or Track1 target table is empty.")

    pred_cols = list(pred_rows[0].keys())
    targ_cols = list(target_rows[0].keys())

    schema = {
        "pred_gal": infer_col(pred_cols, ["Galaxy", "galaxy", "Name"], True, "prediction Galaxy"),
        "target_gal": infer_col(targ_cols, ["Galaxy", "galaxy", "Name", "ID"], True, "target Galaxy"),
        "lambda_best": infer_col(
            targ_cols,
            ["lambda_best", "lambdaBest", "best_lambda", "lambda_min", "lambda_hat", "lambda", "lam_best"],
            True,
            "Track1 lambda_best",
        ),
        "edge_any": infer_col(targ_cols, ["edge_any", "edge_flag", "at_edge", "is_edge", "lambda_edge", "new_edge_any"], False),
        "edge_low": infer_col(targ_cols, ["edge_low", "low_edge", "at_low_edge", "lambda_edge_low", "new_edge_low"], False),
        "edge_high": infer_col(targ_cols, ["edge_high", "high_edge", "at_high_edge", "lambda_edge_high", "new_edge_high"], False),
        "q": infer_col(targ_cols, ["Q", "quality", "quality_flag"], False),
        "type": infer_col(targ_cols, ["Type", "T", "HubbleType", "hubble_type"], False),
        "n_points": infer_col(targ_cols, ["n_points", "npts", "N", "n_valid", "n_rows"], False),
        "inclination": infer_col(targ_cols, ["Inclination_deg", "Inc", "inclination", "i"], False),
        "chi2_min": infer_col(targ_cols, ["chi2_min", "chi2", "chi2_best", "min_chi2"], False),
        "red_chi2": infer_col(targ_cols, ["red_chi2", "reduced_chi2", "chi2_red"], False),
        "lambda_lo_68": infer_col(targ_cols, ["lambda_lo_68", "lambda_low_68", "lambda_16", "lo_68", "lambda_1sigma_low"], False),
        "lambda_hi_68": infer_col(targ_cols, ["lambda_hi_68", "lambda_high_68", "lambda_84", "hi_68", "lambda_1sigma_high"], False),
    }

    return pred_rows, target_rows, schema


def join_rows(pred_rows: list[dict], target_rows: list[dict], schema: dict) -> tuple[list[dict], list[dict]]:
    target_by_key = {}
    duplicate_targets = []
    for r in target_rows:
        k = normalize_galaxy_name(r.get(schema["target_gal"], ""))
        if not k:
            continue
        if k in target_by_key:
            duplicate_targets.append({"Galaxy_key": k, "note": "duplicate target key"})
        target_by_key[k] = r

    joined = []
    misses = []

    for pr in pred_rows:
        gal = pr.get(schema["pred_gal"], "")
        k = normalize_galaxy_name(gal)
        tr = target_by_key.get(k)
        if tr is None:
            misses.append({"Galaxy": gal, "Galaxy_key": k, "reason": "prediction row not found in Track1 target table"})
            continue

        lb = safe_float(tr.get(schema["lambda_best"]))
        if not math.isfinite(lb):
            misses.append({"Galaxy": gal, "Galaxy_key": k, "reason": "lambda_best not finite"})
            continue

        T = safe_float(tr.get(schema["type"])) if schema.get("type") else safe_float(pr.get("Type"))
        Q = safe_int(tr.get(schema["q"])) if schema.get("q") else safe_int(pr.get("Q"))
        inc = safe_float(tr.get(schema["inclination"])) if schema.get("inclination") else safe_float(pr.get("Inclination_deg"))
        npts = safe_int(tr.get(schema["n_points"])) if schema.get("n_points") else -999

        edge_low = boolish(tr.get(schema["edge_low"])) if schema.get("edge_low") else False
        edge_high = boolish(tr.get(schema["edge_high"])) if schema.get("edge_high") else False
        if schema.get("edge_any"):
            edge_any = boolish(tr.get(schema["edge_any"]))
        else:
            edge_any = edge_low or edge_high

        lo68 = safe_float(tr.get(schema["lambda_lo_68"])) if schema.get("lambda_lo_68") else float("nan")
        hi68 = safe_float(tr.get(schema["lambda_hi_68"])) if schema.get("lambda_hi_68") else float("nan")

        row = {
            "Galaxy": gal,
            "Galaxy_key": k,
            "lambda_best": lb,
            "Type": T,
            "Q": Q,
            "Inclination_deg": inc,
            "n_points": npts,
            "edge_any": edge_any,
            "edge_low": edge_low,
            "edge_high": edge_high,
            "chi2_min": safe_float(tr.get(schema["chi2_min"])) if schema.get("chi2_min") else float("nan"),
            "red_chi2": safe_float(tr.get(schema["red_chi2"])) if schema.get("red_chi2") else float("nan"),
            "lambda_lo_68": lo68,
            "lambda_hi_68": hi68,
            "selector_hash_sha256": pr.get("selector_hash_sha256", ""),
            "prediction_table_source_version": pr.get("track2r03_version", ""),
        }

        for short, col, label in SELECTORS:
            pred = safe_float(pr.get(col))
            row[f"{short}_lambda_pred"] = pred
            row[f"{short}_resid_pred_minus_best"] = pred - lb if math.isfinite(pred) else float("nan")
            row[f"{short}_abs_resid"] = abs(pred - lb) if math.isfinite(pred) else float("nan")
            row[f"{short}_sq_resid"] = (pred - lb) ** 2 if math.isfinite(pred) else float("nan")
            if math.isfinite(pred) and math.isfinite(lo68) and math.isfinite(hi68):
                row[f"{short}_inside_track1_68"] = lo68 <= pred <= hi68
            else:
                row[f"{short}_inside_track1_68"] = ""

        joined.append(row)

    return joined, misses + duplicate_targets


def rankdata(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x)
    order = np.argsort(x, kind="mergesort")
    ranks = np.empty(len(x), dtype=float)
    i = 0
    while i < len(x):
        j = i + 1
        while j < len(x) and x[order[j]] == x[order[i]]:
            j += 1
        avg = 0.5 * (i + j - 1) + 1.0
        ranks[order[i:j]] = avg
        i = j
    return ranks


def corr_metrics(x: np.ndarray, y: np.ndarray) -> dict:
    m = np.isfinite(x) & np.isfinite(y)
    x = x[m]
    y = y[m]
    if len(x) < 3:
        return {
            "n_corr": int(len(x)),
            "spearman_rho": float("nan"),
            "spearman_p": float("nan"),
            "pearson_r": float("nan"),
            "pearson_p": float("nan"),
            "kendall_tau": float("nan"),
            "kendall_p": float("nan"),
        }

    if np.nanstd(x) == 0 or np.nanstd(y) == 0:
        pear = float("nan")
    else:
        pear = float(np.corrcoef(x, y)[0, 1])
    rx = rankdata(x)
    ry = rankdata(y)
    spear = float(np.corrcoef(rx, ry)[0, 1]) if np.nanstd(rx) > 0 and np.nanstd(ry) > 0 else float("nan")

    if SCIPY_OK:
        try:
            sp = spearmanr(x, y)
            pr = pearsonr(x, y) if np.nanstd(x) > 0 and np.nanstd(y) > 0 else (float("nan"), float("nan"))
            kt = kendalltau(x, y)
            return {
                "n_corr": int(len(x)),
                "spearman_rho": float(sp.statistic),
                "spearman_p": float(sp.pvalue),
                "pearson_r": float(pr.statistic if hasattr(pr, "statistic") else pr[0]),
                "pearson_p": float(pr.pvalue if hasattr(pr, "pvalue") else pr[1]),
                "kendall_tau": float(kt.statistic),
                "kendall_p": float(kt.pvalue),
            }
        except Exception:
            pass

    return {
        "n_corr": int(len(x)),
        "spearman_rho": spear,
        "spearman_p": float("nan"),
        "pearson_r": pear,
        "pearson_p": float("nan"),
        "kendall_tau": float("nan"),
        "kendall_p": float("nan"),
    }


def group_masks(rows: list[dict]) -> list[tuple[str, str, np.ndarray]]:
    n = len(rows)
    T = np.array([safe_float(r.get("Type")) for r in rows])
    Q = np.array([safe_int(r.get("Q")) for r in rows])
    edge = np.array([boolish(r.get("edge_any")) for r in rows], dtype=bool)
    edge_low = np.array([boolish(r.get("edge_low")) for r in rows], dtype=bool)
    edge_high = np.array([boolish(r.get("edge_high")) for r in rows], dtype=bool)
    npts = np.array([safe_int(r.get("n_points")) for r in rows], dtype=float)

    finite_npts = npts[np.isfinite(npts) & (npts > 0)]
    npts_median = float(np.median(finite_npts)) if finite_npts.size else float("nan")

    groups = [
        ("FULL", "all joined rows", np.ones(n, dtype=bool)),
        ("INTERIOR_NON_EDGE", "rows not edge-railed in Track1 lambda fit", ~edge),
        ("EDGE_ONLY", "rows edge-railed in Track1 lambda fit", edge),
        ("LOW_EDGE_ONLY", "low-edge rows in Track1 lambda fit", edge_low),
        ("HIGH_EDGE_ONLY", "high-edge rows in Track1 lambda fit", edge_high),
        ("Q1_ONLY", "quality flag Q=1", Q == 1),
        ("Q1_Q2", "quality flag Q=1 or Q=2", (Q == 1) | (Q == 2)),
        ("TYPE_2_TO_10", "2 <= Hubble Type <= 10", (T >= 2) & (T <= 10)),
        ("TYPE_2_TO_10_INTERIOR", "2 <= Hubble Type <= 10 and non-edge", (T >= 2) & (T <= 10) & (~edge)),
        ("EXCLUDE_T0_T11", "exclude Type 0 and Type 11 endpoints", (T != 0) & (T != 11)),
        ("EXCLUDE_T0_T11_INTERIOR", "exclude Type 0/11 and edge rows", (T != 0) & (T != 11) & (~edge)),
    ]
    if math.isfinite(npts_median):
        groups.append(("NPOINTS_GE_MEDIAN", f"n_points >= median ({npts_median})", npts >= npts_median))
        groups.append(("NPOINTS_GE_MEDIAN_INTERIOR", f"n_points >= median ({npts_median}) and non-edge", (npts >= npts_median) & (~edge)))

    return groups


def compute_metrics(joined: list[dict]) -> tuple[list[dict], list[dict]]:
    metrics = []
    group_defs = []

    lb_all = np.array([safe_float(r.get("lambda_best")) for r in joined], dtype=float)

    for group_name, group_desc, mask in group_masks(joined):
        idx = np.where(mask)[0]
        group_defs.append({"group": group_name, "description": group_desc, "N": int(len(idx))})
        if len(idx) < 3:
            continue

        target = lb_all[idx]

        for short, pred_col_base, label in SELECTORS:
            p = np.array([safe_float(joined[i].get(f"{short}_lambda_pred")) for i in idx], dtype=float)
            resid = p - target
            finite = np.isfinite(p) & np.isfinite(target)
            if np.sum(finite) < 3:
                metrics.append({"group": group_name, "selector": label, "selector_short": short, "N": int(np.sum(finite)), "status": "TOO_FEW_ROWS"})
                continue

            pf = p[finite]
            tf = target[finite]
            rf = resid[finite]
            absr = np.abs(rf)

            cm = corr_metrics(pf, tf)

            inside_cols = []
            for i in idx[finite]:
                val = joined[i].get(f"{short}_inside_track1_68")
                if val != "":
                    inside_cols.append(boolish(val))
            within68 = float(np.mean(inside_cols)) if inside_cols else float("nan")

            metrics.append({
                "group": group_name,
                "selector": label,
                "selector_short": short,
                "N": int(len(pf)),
                "rmse": float(np.sqrt(np.mean(rf ** 2))),
                "mae": float(np.mean(absr)),
                "median_abs_error": float(np.median(absr)),
                "bias_mean_pred_minus_best": float(np.mean(rf)),
                "bias_median_pred_minus_best": float(np.median(rf)),
                "resid_p16": float(np.percentile(rf, 16)),
                "resid_p84": float(np.percentile(rf, 84)),
                "target_lambda_median": float(np.median(tf)),
                "pred_lambda_median": float(np.median(pf)),
                "target_lambda_p16": float(np.percentile(tf, 16)),
                "target_lambda_p84": float(np.percentile(tf, 84)),
                "pred_lambda_p16": float(np.percentile(pf, 16)),
                "pred_lambda_p84": float(np.percentile(pf, 84)),
                "within_track1_68_fraction": within68,
                **cm,
                "status": "OK",
            })

    return metrics, group_defs


def selector_rankings(metrics: list[dict]) -> list[dict]:
    rankings = []
    groups = sorted(set(r["group"] for r in metrics if r.get("status") == "OK"))
    for g in groups:
        gm = [r for r in metrics if r["group"] == g and r.get("status") == "OK"]
        by_rmse = sorted(gm, key=lambda r: safe_float(r.get("rmse"), float("inf")))
        by_mae = sorted(gm, key=lambda r: safe_float(r.get("mae"), float("inf")))
        # For Spearman, higher is better; NaN goes last.
        by_spear = sorted(gm, key=lambda r: (-safe_float(r.get("spearman_rho"), -999), safe_float(r.get("spearman_p"), 999)))
        for rank, r in enumerate(by_rmse, start=1):
            rankings.append({"group": g, "metric": "rmse", "rank": rank, "selector": r["selector"], "value": r["rmse"]})
        for rank, r in enumerate(by_mae, start=1):
            rankings.append({"group": g, "metric": "mae", "rank": rank, "selector": r["selector"], "value": r["mae"]})
        for rank, r in enumerate(by_spear, start=1):
            rankings.append({"group": g, "metric": "spearman_rho", "rank": rank, "selector": r["selector"], "value": r["spearman_rho"], "p": r.get("spearman_p")})
    return rankings


def hash_checks(paths: dict, pred_hash: str, pred_rows: list[dict]) -> list[dict]:
    hash_file_val = ""
    if paths["track2r03_pred_hash_file"].exists():
        hash_file_val = paths["track2r03_pred_hash_file"].read_text(encoding="utf-8").strip()

    selector_values = sorted(set(str(r.get("selector_hash_sha256", "")) for r in pred_rows))
    table_versions = sorted(set(str(r.get("track2r03_version", "")) for r in pred_rows))

    return [
        {
            "check": "prediction_table_hash_matches_track2r03_hash_file",
            "pass": pred_hash == hash_file_val,
            "observed": pred_hash,
            "required": hash_file_val,
        },
        {
            "check": "prediction_table_hash_matches_expected",
            "pass": pred_hash == EXPECTED_PREDICTION_TABLE_HASH,
            "observed": pred_hash,
            "required": EXPECTED_PREDICTION_TABLE_HASH,
        },
        {
            "check": "all_rows_selector_hash_expected",
            "pass": len(selector_values) == 1 and selector_values[0] == EXPECTED_SELECTOR_HASH,
            "observed": ";".join(selector_values),
            "required": EXPECTED_SELECTOR_HASH,
        },
        {
            "check": "all_rows_track2r03_version_expected",
            "pass": len(table_versions) == 1 and table_versions[0] == EXPECTED_TRACK2R03_VERSION,
            "observed": ";".join(table_versions),
            "required": EXPECTED_TRACK2R03_VERSION,
        },
        {
            "check": "track1_target_table_present",
            "pass": paths["track1_per_galaxy"].exists(),
            "observed": str(paths["track1_per_galaxy"]),
            "required": "sparc_lambda_wide_per_galaxy.csv",
        },
    ]


def no_retuning_audit(paths: dict) -> list[dict]:
    return [
        {"item": "Track2R-03 sealed prediction table", "detected": paths["track2r03_pred_table"].exists(), "used": True, "status": "SEALED_INPUT", "path": str(paths["track2r03_pred_table"])},
        {"item": "Track1 lambda_best target table", "detected": paths["track1_per_galaxy"].exists(), "used": True, "status": "VALIDATION_TARGET_ONLY", "path": str(paths["track1_per_galaxy"])},
        {"item": "Track2R-02 selector manifest", "detected": (paths["track2r03_dir"].parent / "SFT_TRACK2R_02_LAMBDA_READOUT_SELECTOR" / "track2r02_selector_manifest.json").exists(), "used": False, "status": "NOT_MODIFIED", "path": str(paths["track2r03_dir"].parent / "SFT_TRACK2R_02_LAMBDA_READOUT_SELECTOR" / "track2r02_selector_manifest.json")},
        {"item": "RAR_All_Data", "detected": paths["rar_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["rar_forbidden"])},
        {"item": "Old Track2 Gate14C", "detected": paths["old_track2_14c_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["old_track2_14c_forbidden"])},
        {"item": "Old Track2 Gate14D", "detected": paths["old_track2_14d_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["old_track2_14d_forbidden"])},
        {"item": "selector or predictions changed after validation", "detected": False, "used": False, "status": "NO"},
        {"item": "rotation residuals used for fitting", "detected": False, "used": False, "status": "NO"},
        {"item": "new coefficient fit", "detected": False, "used": False, "status": "NO"},
    ]


def verdict_from_metrics(metrics: list[dict], hash_rows: list[dict], joined_count: int) -> dict:
    all_hash = all(str(r.get("pass")).lower() == "true" for r in hash_rows)

    def get_metric(group: str, short: str) -> dict | None:
        for r in metrics:
            if r.get("group") == group and r.get("selector_short") == short and r.get("status") == "OK":
                return r
        return None

    primary = get_metric("FULL", "primary")
    source = get_metric("FULL", "secondary_source")
    blend = get_metric("FULL", "tertiary_blend")
    c_disk = get_metric("FULL", "control_disk")
    c_sphere = get_metric("FULL", "control_sphere")
    c_mid = get_metric("FULL", "control_midpoint")

    if not all_hash or joined_count == 0 or primary is None:
        verdict = "TRACK2R04_VALIDATION_REQUIRES_REVIEW"
        status = "hash/join failure or missing primary metrics"
    else:
        primary_rho = safe_float(primary.get("spearman_rho"))
        primary_p = safe_float(primary.get("spearman_p"))
        primary_rmse = safe_float(primary.get("rmse"))
        primary_mae = safe_float(primary.get("mae"))
        controls = [r for r in [c_disk, c_sphere, c_mid] if r is not None]
        best_control_rmse = min([safe_float(r.get("rmse"), float("inf")) for r in controls]) if controls else float("inf")
        best_control_mae = min([safe_float(r.get("mae"), float("inf")) for r in controls]) if controls else float("inf")

        directional_sig = primary_rho > 0 and (not math.isfinite(primary_p) or primary_p < 0.05)
        beats_control_rmse = primary_rmse < best_control_rmse
        beats_control_mae = primary_mae < best_control_mae

        if directional_sig and beats_control_rmse and beats_control_mae:
            verdict = "TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS"
            status = "primary selector has positive target correlation and beats constant endpoint/midpoint controls"
        elif directional_sig:
            verdict = "TRACK2R04_PRIMARY_SELECTOR_DIRECTIONAL_SIGNAL_ONLY_AMPLITUDE_LIMITED"
            status = "primary selector has positive target correlation but does not beat all constant controls on amplitude metrics"
        else:
            verdict = "TRACK2R04_PRIMARY_SELECTOR_NOT_VALIDATED_OR_INCONCLUSIVE"
            status = "primary selector lacks a significant positive validation correlation"

    return {
        "verdict": verdict,
        "claim_boundary": "Track2R-04 validation only; sealed predictions unchanged; no refit, no retuning, no selector repair",
        "track2r04_version": PROTOCOL_VERSION,
        "validation_status_interpretation": status,
        "joined_rows": joined_count,
        "all_hash_checks_pass": all_hash,
        "primary_full_spearman_rho": primary.get("spearman_rho") if primary else "",
        "primary_full_spearman_p": primary.get("spearman_p") if primary else "",
        "primary_full_rmse": primary.get("rmse") if primary else "",
        "primary_full_mae": primary.get("mae") if primary else "",
        "source_full_spearman_rho": source.get("spearman_rho") if source else "",
        "source_full_rmse": source.get("rmse") if source else "",
        "blend_full_spearman_rho": blend.get("spearman_rho") if blend else "",
        "blend_full_rmse": blend.get("rmse") if blend else "",
        "control_disk_full_rmse": c_disk.get("rmse") if c_disk else "",
        "control_sphere_full_rmse": c_sphere.get("rmse") if c_sphere else "",
        "control_midpoint_full_rmse": c_mid.get("rmse") if c_mid else "",
        "selector_changed": False,
        "prediction_table_changed": False,
        "uses_rotation_residuals_for_tuning": False,
        "uses_RAR_All_Data": False,
        "uses_old_DBE_track2": False,
        "main_result": (
            "Sealed lambda predictions were joined to Track1 lambda_best and evaluated against primary, secondary, and control selectors. "
            "Interpretation depends on the metrics in track2r04_selector_metrics.csv."
        ),
        "next_gate": "Track2R-05 only if Track2R-04 supports a useful frozen selector; otherwise write internal note and fork only predeclared.",
    }


def make_plots(out: Path, joined: list[dict], metrics: list[dict]) -> None:
    if not MPL_OK or not joined:
        return
    plots = out / "plots"
    plots.mkdir(parents=True, exist_ok=True)

    target = np.array([safe_float(r.get("lambda_best")) for r in joined])
    T = np.array([safe_float(r.get("Type")) for r in joined])
    primary = np.array([safe_float(r.get("primary_lambda_pred")) for r in joined])
    source = np.array([safe_float(r.get("secondary_source_lambda_pred")) for r in joined])
    blend = np.array([safe_float(r.get("tertiary_blend_lambda_pred")) for r in joined])
    edge = np.array([boolish(r.get("edge_any")) for r in joined], dtype=bool)

    # Plot 1: primary vs target.
    m = np.isfinite(target) & np.isfinite(primary)
    if np.sum(m) > 0:
        fig = plt.figure(figsize=(7, 5))
        plt.scatter(target[m & ~edge], primary[m & ~edge], s=22, label="non-edge")
        if np.any(m & edge):
            plt.scatter(target[m & edge], primary[m & edge], s=28, marker="x", label="edge")
        lo = float(np.nanmin([np.nanmin(target[m]), np.nanmin(primary[m])]))
        hi = float(np.nanmax([np.nanmax(target[m]), np.nanmax(primary[m])]))
        plt.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1)
        plt.xlabel("Track1 lambda_best")
        plt.ylabel("Track2R primary lambda_pred")
        plt.title("Track2R-04 primary prediction vs Track1 lambda_best")
        plt.legend()
        plt.tight_layout()
        fig.savefig(plots / "track2r04_primary_vs_lambda_best.png", dpi=180)
        plt.close(fig)

    # Plot 2: lambda vs Type.
    m = np.isfinite(T) & np.isfinite(target) & np.isfinite(primary)
    if np.sum(m) > 0:
        fig = plt.figure(figsize=(7, 5))
        plt.scatter(T[m], target[m], s=22, label="Track1 lambda_best")
        plt.scatter(T[m], primary[m], s=22, label="primary lambda_pred")
        plt.xlabel("Hubble Type")
        plt.ylabel("lambda")
        plt.title("Track2R-04 target and prediction vs Type")
        plt.legend()
        plt.tight_layout()
        fig.savefig(plots / "track2r04_lambda_vs_type.png", dpi=180)
        plt.close(fig)

    # Plot 3: selector RMSE bars for FULL.
    full = [r for r in metrics if r.get("group") == "FULL" and r.get("status") == "OK"]
    if full:
        labels = [r["selector_short"] for r in full]
        vals = [safe_float(r.get("rmse")) for r in full]
        fig = plt.figure(figsize=(8, 5))
        plt.bar(labels, vals)
        plt.ylabel("RMSE in lambda")
        plt.title("Track2R-04 full-sample RMSE by selector")
        plt.xticks(rotation=30, ha="right")
        plt.tight_layout()
        fig.savefig(plots / "track2r04_full_rmse_by_selector.png", dpi=180)
        plt.close(fig)


def write_report(path: Path, verdict: dict, hash_rows: list[dict], audit: list[dict],
                 group_defs: list[dict], metrics: list[dict], rankings: list[dict], join_issues: list[dict]) -> None:
    def table(rows, cols, limit=None):
        rows2 = rows[:limit] if limit else rows
        lines = ["| " + " | ".join(label for _, label in cols) + " |\n",
                 "|" + "|".join("---" for _ in cols) + "|\n"]
        for r in rows2:
            lines.append("| " + " | ".join(str(r.get(k, "")) for k, _ in cols) + " |\n")
        if limit and len(rows) > limit:
            lines.append(f"| ... | {len(rows)-limit} more rows omitted |  |  |\n")
        return "".join(lines)

    full_metrics = [r for r in metrics if r.get("group") == "FULL" and r.get("status") == "OK"]
    rank_full = [r for r in rankings if r.get("group") == "FULL"]

    text = f"""# SFT Track2R-04: Lambda Prediction Validation

## Verdict

**{verdict['verdict']}**

Interpretation:

{verdict['validation_status_interpretation']}

## Claim boundary

This gate validates the sealed Track2R-03 predictions against Track1 lambda_best. It does not change the selector, does not change the prediction table, and does not fit a new coefficient.

## Hash checks

{table(hash_rows, [('check','Check'),('pass','Pass'),('observed','Observed'),('required','Required')])}

## No-retuning audit

{table(audit, [('item','Item'),('detected','Detected'),('used','Used'),('status','Status')])}

## Groups

{table(group_defs, [('group','Group'),('description','Description'),('N','N')])}

## Full-sample selector metrics

{table(full_metrics, [('selector','Selector'),('N','N'),('spearman_rho','Spearman rho'),('spearman_p','p'),('rmse','RMSE'),('mae','MAE'),('median_abs_error','Median abs'),('bias_mean_pred_minus_best','Mean bias')])}

## Full-sample rankings

{table(rank_full, [('metric','Metric'),('rank','Rank'),('selector','Selector'),('value','Value'),('p','p')])}

## Join issues

{table(join_issues, [('Galaxy','Galaxy'),('Galaxy_key','Key'),('reason','Reason'),('note','Note')], limit=25)}

## Next step

If the primary selector shows useful directional validation, Track2R-05 may use the sealed predictions for rotation-curve validation. If it fails, this gate becomes an internal note and any revised selector requires a new predeclared fork.
"""
    path.write_text(text, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sparc-dir", default=r"C:\Users\TaicHI\SPARC")
    ap.add_argument("--pred-table", default=None)
    ap.add_argument("--track1-table", default=None)
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    sparc_dir = Path(args.sparc_dir).expanduser().resolve()
    out = Path(args.out_dir).expanduser().resolve() if args.out_dir else sparc_dir / OUT_DIR_NAME
    out.mkdir(parents=True, exist_ok=True)

    paths = find_paths(sparc_dir, args.pred_table, args.track1_table)
    pred_rows, target_rows, schema = load_inputs(paths)
    pred_hash = sha256_file(paths["track2r03_pred_table"])

    joined, join_issues = join_rows(pred_rows, target_rows, schema)
    metrics, group_defs = compute_metrics(joined)
    rankings = selector_rankings(metrics)
    hash_rows = hash_checks(paths, pred_hash, pred_rows)
    audit = no_retuning_audit(paths)
    verdict = verdict_from_metrics(metrics, hash_rows, len(joined))

    write_csv(out / "track2r04_joined_validation_rows.csv", joined)
    write_csv(out / "track2r04_join_issues.csv", join_issues)
    write_csv(out / "track2r04_selector_metrics.csv", metrics)
    write_csv(out / "track2r04_selector_rankings.csv", rankings)
    write_csv(out / "track2r04_hash_checks.csv", hash_rows)
    write_csv(out / "track2r04_no_retuning_audit.csv", audit)
    write_csv(out / "track2r04_group_definitions.csv", group_defs)
    write_csv(out / "track2r04_schema_map.csv", [{"field": k, "column": v} for k, v in schema.items()])
    write_csv(out / "track2r04_verdict.csv", [verdict])

    manifest = {
        "track2r04_version": PROTOCOL_VERSION,
        "prediction_table_sha256": pred_hash,
        "expected_prediction_table_sha256": EXPECTED_PREDICTION_TABLE_HASH,
        "expected_selector_hash": EXPECTED_SELECTOR_HASH,
        "joined_rows": len(joined),
        "join_issues": len(join_issues),
        "schema_map": schema,
        "verdict": verdict,
        "claim_boundary": verdict["claim_boundary"],
    }
    (out / "track2r04_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    make_plots(out, joined, metrics)
    write_report(out / "TRACK2R_04_lambda_prediction_validation_report.md", verdict, hash_rows, audit, group_defs, metrics, rankings, join_issues)

    print("\nSFT TRACK2R-04 LAMBDA PREDICTION VALIDATION")
    print("===========================================")
    print("\nPurpose:")
    print("  Join sealed lambda_pred table to Track1 lambda_best and validate.")
    print("  No selector repair, no prediction edits, no new fit, no old D/B/E.")

    print("\nInput tables:")
    print(f"  sealed prediction table: {paths['track2r03_pred_table']}")
    print(f"  Track1 lambda_best table: {paths['track1_per_galaxy']}")

    print("\nSchema map:")
    for k, v in schema.items():
        print(f"  {k}: {v}")

    print("\nHash checks:")
    for r in hash_rows:
        print(f"  {r['check']:52s} PASS={r['pass']}")

    print("\nNo-retuning audit:")
    for r in audit:
        print(f"  {r['item']:44s} detected={r['detected']} used={r['used']} status={r['status']}")

    print("\nJoin summary:")
    print(f"  prediction rows: {len(pred_rows)}")
    print(f"  Track1 target rows: {len(target_rows)}")
    print(f"  joined rows: {len(joined)}")
    print(f"  join issues: {len(join_issues)}")

    print("\nFull-sample selector metrics:")
    for r in metrics:
        if r.get("group") == "FULL" and r.get("status") == "OK":
            print(
                f"  {r['selector']:42s} "
                f"N={r['N']} rho={r.get('spearman_rho')} p={r.get('spearman_p')} "
                f"rmse={r.get('rmse')} mae={r.get('mae')} bias={r.get('bias_mean_pred_minus_best')}"
            )

    print("\nKey robustness groups for primary selector:")
    for r in metrics:
        if r.get("selector_short") == "primary" and r.get("group") in [
            "FULL", "INTERIOR_NON_EDGE", "Q1_ONLY", "Q1_Q2", "TYPE_2_TO_10", "TYPE_2_TO_10_INTERIOR", "NPOINTS_GE_MEDIAN"
        ] and r.get("status") == "OK":
            print(
                f"  {r['group']:26s} N={r['N']} rho={r.get('spearman_rho')} p={r.get('spearman_p')} "
                f"rmse={r.get('rmse')} mae={r.get('mae')}"
            )

    print("\nFull-sample rankings:")
    for r in rankings:
        if r.get("group") == "FULL" and r.get("rank") == 1:
            print(f"  best by {r['metric']}: {r['selector']} value={r['value']} p={r.get('p','')}")

    print("\nVerdict:")
    for k, val in verdict.items():
        print(f"  {k}: {val}")

    print("\nFiles:")
    print(f"  output directory: {out}")
    print(f"  joined rows: {out/'track2r04_joined_validation_rows.csv'}")
    print(f"  selector metrics: {out/'track2r04_selector_metrics.csv'}")
    print(f"  selector rankings: {out/'track2r04_selector_rankings.csv'}")
    print(f"  hash checks: {out/'track2r04_hash_checks.csv'}")
    print(f"  no-retuning audit: {out/'track2r04_no_retuning_audit.csv'}")
    print(f"  verdict: {out/'track2r04_verdict.csv'}")
    print(f"  report: {out/'TRACK2R_04_lambda_prediction_validation_report.md'}")
    if MPL_OK:
        print(f"  plots: {out/'plots'}")


if __name__ == "__main__":
    main()
