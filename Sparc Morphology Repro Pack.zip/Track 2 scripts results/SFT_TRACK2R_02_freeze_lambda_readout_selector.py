#!/usr/bin/env python3
"""
SFT Track2R-02:
Freeze No-Target Morphology-Readout Lambda Selector

Parent gate
-----------
Track2R-01 froze the clean morphology-readout feature table.

This gate chooses and hashes the lambda_pred readout selector BEFORE
Track1 lambda_best is joined.

This gate does NOT validate against lambda_best.
This gate does NOT use Vobs/eVobs, residuals, RAR_All_Data, old D/B/E,
dark halos, or Track1 fit outputs.

Primary selector
----------------
The primary predeclared selector is intentionally minimal:

    S_type = clamp(1 - T/11, 0, 1)

    lambda_pred = lambda_disk + (lambda_sphere - lambda_disk) * S_type

where:
    lambda_disk   = 3*pi/8
    lambda_sphere = 4/3

Rationale:
    late-type disk systems -> lower lambda near thin-disk endpoint
    early/bulge systems    -> higher lambda near spherical endpoint

Secondary selectors, locked now for later comparison, are not allowed to
replace the primary after target validation:
    - source-root sphericity selector
    - equal type/source blend selector
    - endpoint constants / midpoint controls

Outputs
-------
    track2r02_selector_hash.txt
    track2r02_selector_manifest.json
    track2r02_formula_cards.csv
    track2r02_required_features.csv
    track2r02_no_target_audit.csv
    track2r02_selector_preview_summary.csv
    track2r02_gate_blueprint.csv
    track2r02_verdict.csv
    SFT_TRACK2R_02_selector_reference.py
    TRACK2R_02_lambda_readout_selector_report.md

Run
---
    python SFT_TRACK2R_02_freeze_lambda_readout_selector.py --sparc-dir "C:\\Users\\TaicHI\\SPARC"

Next gate
---------
Track2R-03 uses the hashed selector to generate and seal a per-galaxy
lambda_pred table, still without lambda_best.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np

PROTOCOL_VERSION = "SFT_TRACK2R_02_LAMBDA_READOUT_SELECTOR_v1"
PARENT_PROTOCOL_VERSION = "SFT_TRACK2R_01_MORPHOLOGY_READOUT_PROTOCOL_v1"
OUT_DIR_NAME = "SFT_TRACK2R_02_LAMBDA_READOUT_SELECTOR"

LAMBDA_DISK = 3.0 * math.pi / 8.0
LAMBDA_SPHERE = 4.0 / 3.0
DELTA_LAMBDA = LAMBDA_SPHERE - LAMBDA_DISK


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        x = float(x)
    except Exception:
        return float("nan")
    if not math.isfinite(x):
        return float("nan")
    return min(max(x, lo), hi)


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def find_paths(sparc_dir: Path) -> dict:
    track2r01 = sparc_dir / "SFT_TRACK2R_01_MORPHOLOGY_READOUT_PROTOCOL"
    return {
        "track2r01_dir": track2r01,
        "track2r01_feature_table": track2r01 / "track2r01_allowed_feature_table.csv",
        "track2r01_protocol_hash": track2r01 / "track2r01_protocol_hash.txt",
        "track2r01_manifest": track2r01 / "track2r01_protocol_manifest.json",
        "track1_lambda_best_forbidden": sparc_dir / "SFT_SPARC_TRACK1_LAMBDA_WIDE_OUTPUT" / "sparc_lambda_wide_per_galaxy.csv",
        "track1b_forbidden": sparc_dir / "SFT_SPARC_TRACK1B_ROBUSTNESS_OUTPUT" / "track1b_verdict.csv",
        "rar_forbidden": sparc_dir / "RAR_All_Data.txt",
        "old_track2_14c_forbidden": sparc_dir / "SFT_GRAV_TRAJ_14C_OUTPUT" / "gate14c_validation_joined_rows.csv",
        "old_track2_14d_forbidden": sparc_dir / "SFT_GRAV_TRAJ_14D_OUTPUT" / "gate14d_verdict.csv",
    }


def load_parent(paths: dict) -> tuple[str, str, dict]:
    feature_path = paths["track2r01_feature_table"]
    hash_path = paths["track2r01_protocol_hash"]
    manifest_path = paths["track2r01_manifest"]

    missing = [p for p in [feature_path, hash_path, manifest_path] if not p.exists()]
    if missing:
        print("ERROR: missing Track2R-01 prerequisite files:", file=sys.stderr)
        for p in missing:
            print(f"  {p}", file=sys.stderr)
        sys.exit(2)

    parent_hash = hash_path.read_text(encoding="utf-8").strip()
    feature_hash = sha256_file(feature_path)
    parent_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    return parent_hash, feature_hash, parent_manifest


def selector_manifest(parent_hash: str, feature_hash: str) -> dict:
    return {
        "selector_version": PROTOCOL_VERSION,
        "parent_protocol_version": PARENT_PROTOCOL_VERSION,
        "parent_protocol_hash_sha256": parent_hash,
        "parent_feature_table_sha256": feature_hash,
        "theory_target": "lambda_morph readout for g_eff^2 = g_bar^2 + lambda_morph * a_SFT * g_bar",
        "fixed_endpoints": {
            "lambda_disk_3pi8": LAMBDA_DISK,
            "lambda_sphere_4over3": LAMBDA_SPHERE,
            "delta_lambda": DELTA_LAMBDA,
        },
        "primary_selector": {
            "name": "PRIMARY_TYPE_ENDPOINT_LINEAR",
            "role": "primary_prediction",
            "formula": [
                "S_type = clamp(1 - Type/11, 0, 1)",
                "lambda_pred = lambda_disk_3pi8 + delta_lambda * S_type",
            ],
            "required_features": ["Type"],
            "rationale": (
                "Minimal no-target morphology readout: late Hubble types are disk-dominated and should approach "
                "the thin-disk endpoint 3*pi/8; early/bulge systems should move toward the spherical endpoint 4/3."
            ),
            "post_validation_replacement_allowed": False,
        },
        "secondary_selectors_locked_for_comparison": [
            {
                "name": "SECONDARY_SOURCE_ROOT_SPHERICITY",
                "role": "locked_secondary_comparison",
                "formula": [
                    "Bf = clamp(source_bulge_fraction_proxy, 0, 1)",
                    "Bi = clamp(source_bulge_inner_weight_proxy, 0, 1)",
                    "Df = clamp(source_disk_fraction_proxy, 0, 1)",
                    "Gf = clamp(source_gas_fraction_proxy, 0, 1)",
                    "S_source = clamp(mean([sqrt(Bf), sqrt(Bi), 1 - sqrt(Df), 1 - sqrt(Gf)]), 0, 1)",
                    "lambda_pred = lambda_disk_3pi8 + delta_lambda * S_source",
                ],
                "required_features": [
                    "source_bulge_fraction_proxy",
                    "source_bulge_inner_weight_proxy",
                    "source_disk_fraction_proxy",
                    "source_gas_fraction_proxy",
                ],
                "rationale": (
                    "Source-only root readout of how far the mass model is from a thin disk. "
                    "Uses root components to match SFT root/readout language, not target-fitted weights."
                ),
                "post_validation_replacement_allowed": False,
            },
            {
                "name": "TERTIARY_EQUAL_TYPE_SOURCE_BLEND",
                "role": "locked_secondary_comparison",
                "formula": [
                    "S_blend = clamp(0.5 * S_type + 0.5 * S_source, 0, 1)",
                    "lambda_pred = lambda_disk_3pi8 + delta_lambda * S_blend",
                ],
                "required_features": [
                    "Type",
                    "source_bulge_fraction_proxy",
                    "source_bulge_inner_weight_proxy",
                    "source_disk_fraction_proxy",
                    "source_gas_fraction_proxy",
                ],
                "rationale": "Equal no-target blend of metadata morphology and source-decomposition sphericity.",
                "post_validation_replacement_allowed": False,
            },
        ],
        "control_selectors_locked_for_comparison": [
            {
                "name": "CONTROL_CONSTANT_DISK_ENDPOINT",
                "role": "control",
                "formula": ["lambda_pred = lambda_disk_3pi8"],
                "required_features": [],
            },
            {
                "name": "CONTROL_CONSTANT_SPHERE_ENDPOINT",
                "role": "control",
                "formula": ["lambda_pred = lambda_sphere_4over3"],
                "required_features": [],
            },
            {
                "name": "CONTROL_CONSTANT_ENDPOINT_MIDPOINT",
                "role": "control",
                "formula": ["lambda_pred = 0.5 * (lambda_disk_3pi8 + lambda_sphere_4over3)"],
                "required_features": [],
            },
        ],
        "forbidden_inputs": [
            "Track1 lambda_best",
            "Track1 chi2(lambda)",
            "Vobs/eVobs for selector construction",
            "rotation-curve residuals",
            "RAR_All_Data",
            "dark halo parameters",
            "old Track2 D/B/E fields or diagnostics",
            "post-validation coefficient changes",
            "per-galaxy tuned offsets",
        ],
        "non_negotiable_validation_order": [
            "Track2R-02 freezes this selector hash.",
            "Track2R-03 uses this hash to generate sealed lambda_pred table without targets.",
            "Track2R-04 joins sealed lambda_pred to Track1 lambda_best.",
            "Track2R-05 uses sealed lambda_pred for rotation-curve validation.",
        ],
        "claim_boundary": (
            "This selector is a predeclared morphology-readout hypothesis. "
            "It is not selected from lambda_best and is not validated in Track2R-02."
        ),
    }


def formula_cards(manifest: dict) -> list[dict]:
    rows = []
    prim = manifest["primary_selector"]
    rows.append({
        "selector": prim["name"],
        "role": prim["role"],
        "required_features": "; ".join(prim["required_features"]),
        "formula": " ; ".join(prim["formula"]),
        "rationale": prim["rationale"],
        "post_validation_replacement_allowed": prim["post_validation_replacement_allowed"],
    })
    for s in manifest["secondary_selectors_locked_for_comparison"]:
        rows.append({
            "selector": s["name"],
            "role": s["role"],
            "required_features": "; ".join(s["required_features"]),
            "formula": " ; ".join(s["formula"]),
            "rationale": s["rationale"],
            "post_validation_replacement_allowed": s["post_validation_replacement_allowed"],
        })
    for s in manifest["control_selectors_locked_for_comparison"]:
        rows.append({
            "selector": s["name"],
            "role": s["role"],
            "required_features": "; ".join(s["required_features"]),
            "formula": " ; ".join(s["formula"]),
            "rationale": "control baseline",
            "post_validation_replacement_allowed": False,
        })
    return rows


def required_features_rows(manifest: dict, feature_rows: list[dict]) -> list[dict]:
    available = set(feature_rows[0].keys()) if feature_rows else set()
    selectors = [manifest["primary_selector"]] + manifest["secondary_selectors_locked_for_comparison"] + manifest["control_selectors_locked_for_comparison"]

    rows = []
    for sel in selectors:
        req = sel["required_features"]
        if not req:
            rows.append({
                "selector": sel["name"],
                "feature": "(none)",
                "available": True,
                "n_finite_or_present": len(feature_rows),
                "coverage_fraction": 1.0,
            })
            continue
        for f in req:
            nfin = 0
            for r in feature_rows:
                x = safe_float(r.get(f))
                if math.isfinite(x):
                    nfin += 1
            rows.append({
                "selector": sel["name"],
                "feature": f,
                "available": f in available,
                "n_finite_or_present": nfin,
                "coverage_fraction": nfin / len(feature_rows) if feature_rows else 0,
            })
    return rows


def no_target_audit(paths: dict) -> list[dict]:
    return [
        {"item": "Track2R-01 feature table", "detected": paths["track2r01_feature_table"].exists(), "used": True, "status": "ALLOWED_PARENT_INPUT", "path": str(paths["track2r01_feature_table"])},
        {"item": "Track2R-01 protocol hash", "detected": paths["track2r01_protocol_hash"].exists(), "used": True, "status": "ALLOWED_PARENT_INPUT", "path": str(paths["track2r01_protocol_hash"])},
        {"item": "Track1 lambda_best", "detected": paths["track1_lambda_best_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["track1_lambda_best_forbidden"])},
        {"item": "Track1B robustness", "detected": paths["track1b_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["track1b_forbidden"])},
        {"item": "RAR_All_Data", "detected": paths["rar_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["rar_forbidden"])},
        {"item": "Old Track2 Gate14C", "detected": paths["old_track2_14c_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["old_track2_14c_forbidden"])},
        {"item": "Old Track2 Gate14D", "detected": paths["old_track2_14d_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["old_track2_14d_forbidden"])},
        {"item": "lambda prediction generated", "detected": False, "used": False, "status": "NOT_THIS_GATE", "path": ""},
        {"item": "validation against lambda_best", "detected": False, "used": False, "status": "NOT_THIS_GATE", "path": ""},
    ]


def s_type(row: dict) -> float:
    T = safe_float(row.get("Type"))
    return clamp(1.0 - T / 11.0)


def s_source(row: dict) -> float:
    Bf = clamp(safe_float(row.get("source_bulge_fraction_proxy")))
    Bi = clamp(safe_float(row.get("source_bulge_inner_weight_proxy")))
    Df = clamp(safe_float(row.get("source_disk_fraction_proxy")))
    Gf = clamp(safe_float(row.get("source_gas_fraction_proxy")))
    vals = [math.sqrt(Bf), math.sqrt(Bi), 1.0 - math.sqrt(Df), 1.0 - math.sqrt(Gf)]
    vals = [v for v in vals if math.isfinite(v)]
    if not vals:
        return float("nan")
    return clamp(float(np.mean(vals)))


def lambda_from_s(S: float) -> float:
    S = clamp(S)
    return LAMBDA_DISK + DELTA_LAMBDA * S


def selector_values(row: dict) -> dict:
    st = s_type(row)
    ss = s_source(row)
    sb = clamp(0.5 * st + 0.5 * ss) if math.isfinite(st) and math.isfinite(ss) else float("nan")
    return {
        "PRIMARY_TYPE_ENDPOINT_LINEAR": lambda_from_s(st),
        "SECONDARY_SOURCE_ROOT_SPHERICITY": lambda_from_s(ss),
        "TERTIARY_EQUAL_TYPE_SOURCE_BLEND": lambda_from_s(sb),
        "CONTROL_CONSTANT_DISK_ENDPOINT": LAMBDA_DISK,
        "CONTROL_CONSTANT_SPHERE_ENDPOINT": LAMBDA_SPHERE,
        "CONTROL_CONSTANT_ENDPOINT_MIDPOINT": 0.5 * (LAMBDA_DISK + LAMBDA_SPHERE),
    }


def preview_summary(feature_rows: list[dict]) -> list[dict]:
    names = [
        "PRIMARY_TYPE_ENDPOINT_LINEAR",
        "SECONDARY_SOURCE_ROOT_SPHERICITY",
        "TERTIARY_EQUAL_TYPE_SOURCE_BLEND",
        "CONTROL_CONSTANT_DISK_ENDPOINT",
        "CONTROL_CONSTANT_SPHERE_ENDPOINT",
        "CONTROL_CONSTANT_ENDPOINT_MIDPOINT",
    ]
    vals_by = {name: [] for name in names}
    st_vals, ss_vals = [], []
    for r in feature_rows:
        st = s_type(r)
        ss = s_source(r)
        if math.isfinite(st):
            st_vals.append(st)
        if math.isfinite(ss):
            ss_vals.append(ss)
        vals = selector_values(r)
        for name in names:
            x = vals[name]
            if math.isfinite(x):
                vals_by[name].append(x)

    rows = []
    for name in names:
        arr = np.array(vals_by[name], dtype=float)
        if arr.size:
            rows.append({
                "selector": name,
                "n_preview": int(arr.size),
                "lambda_min_preview": float(np.min(arr)),
                "lambda_p16_preview": float(np.percentile(arr, 16)),
                "lambda_median_preview": float(np.median(arr)),
                "lambda_p84_preview": float(np.percentile(arr, 84)),
                "lambda_max_preview": float(np.max(arr)),
                "note": "preview only; no lambda_best joined",
            })
        else:
            rows.append({"selector": name, "n_preview": 0, "note": "preview failed"})
    for name, vals in [("S_type", st_vals), ("S_source", ss_vals)]:
        arr = np.array(vals, dtype=float)
        rows.append({
            "selector": name,
            "n_preview": int(arr.size),
            "lambda_min_preview": "",
            "lambda_p16_preview": float(np.percentile(arr, 16)) if arr.size else "",
            "lambda_median_preview": float(np.median(arr)) if arr.size else "",
            "lambda_p84_preview": float(np.percentile(arr, 84)) if arr.size else "",
            "lambda_max_preview": "",
            "note": "sphericity coordinate preview; not target validation",
        })
    return rows


def gate_blueprint_rows() -> list[dict]:
    return [
        {
            "gate": "Track2R-02",
            "status_after_this_script": "COMPLETE_IF_HASHED",
            "task": "Freeze no-target lambda_pred readout selector.",
            "success_criterion": "Selector hash written before Track1 lambda_best is joined.",
            "output": "selector manifest + hash + formula cards",
        },
        {
            "gate": "Track2R-03",
            "status_after_this_script": "NEXT",
            "task": "Generate sealed per-galaxy lambda_pred table using selector hash.",
            "success_criterion": "Prediction table hash written without lambda_best or Vobs/eVobs.",
            "output": "sealed lambda_pred table + SHA-256",
        },
        {
            "gate": "Track2R-04",
            "status_after_this_script": "PENDING",
            "task": "Validate sealed lambda_pred against Track1 lambda_best.",
            "success_criterion": "Report primary/secondary/control metrics without changing selector.",
            "output": "lambda validation report",
        },
        {
            "gate": "Track2R-05",
            "status_after_this_script": "PENDING",
            "task": "Use sealed lambda_pred for rotation-curve validation.",
            "success_criterion": "Compare against constants and Track1 best-lambda ceiling.",
            "output": "rotation-curve validation report",
        },
    ]


def reference_impl_text(selector_hash: str) -> str:
    return f"""#!/usr/bin/env python3
\"\"\"
Reference implementation for {PROTOCOL_VERSION}

Selector hash:
{selector_hash}

This module is generated by Track2R-02 and should be used by Track2R-03.
Do not edit formulas after validation.
\"\"\"

import math
import numpy as np

LAMBDA_DISK = 3.0 * math.pi / 8.0
LAMBDA_SPHERE = 4.0 / 3.0
DELTA_LAMBDA = LAMBDA_SPHERE - LAMBDA_DISK
SELECTOR_HASH_SHA256 = "{selector_hash}"


def clamp(x, lo=0.0, hi=1.0):
    try:
        x = float(x)
    except Exception:
        return float("nan")
    if not math.isfinite(x):
        return float("nan")
    return min(max(x, lo), hi)


def safe_float(x, default=float("nan")):
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def s_type(row):
    T = safe_float(row.get("Type"))
    return clamp(1.0 - T / 11.0)


def s_source(row):
    Bf = clamp(safe_float(row.get("source_bulge_fraction_proxy")))
    Bi = clamp(safe_float(row.get("source_bulge_inner_weight_proxy")))
    Df = clamp(safe_float(row.get("source_disk_fraction_proxy")))
    Gf = clamp(safe_float(row.get("source_gas_fraction_proxy")))
    vals = [math.sqrt(Bf), math.sqrt(Bi), 1.0 - math.sqrt(Df), 1.0 - math.sqrt(Gf)]
    vals = [v for v in vals if math.isfinite(v)]
    if not vals:
        return float("nan")
    return clamp(float(np.mean(vals)))


def lambda_from_s(S):
    S = clamp(S)
    return LAMBDA_DISK + DELTA_LAMBDA * S


def predict_all(row):
    st = s_type(row)
    ss = s_source(row)
    sb = clamp(0.5 * st + 0.5 * ss) if math.isfinite(st) and math.isfinite(ss) else float("nan")
    return {{
        "PRIMARY_TYPE_ENDPOINT_LINEAR": lambda_from_s(st),
        "SECONDARY_SOURCE_ROOT_SPHERICITY": lambda_from_s(ss),
        "TERTIARY_EQUAL_TYPE_SOURCE_BLEND": lambda_from_s(sb),
        "CONTROL_CONSTANT_DISK_ENDPOINT": LAMBDA_DISK,
        "CONTROL_CONSTANT_SPHERE_ENDPOINT": LAMBDA_SPHERE,
        "CONTROL_CONSTANT_ENDPOINT_MIDPOINT": 0.5 * (LAMBDA_DISK + LAMBDA_SPHERE),
        "S_type": st,
        "S_source": ss,
        "S_blend": sb,
    }}
"""


def write_report(path: Path, manifest: dict, selector_hash: str, verdict: dict,
                 cards: list[dict], required: list[dict], audit: list[dict],
                 preview: list[dict], blueprint: list[dict]) -> None:
    def table(rows, cols):
        lines = ["| " + " | ".join(label for _, label in cols) + " |\n",
                 "|" + "|".join("---" for _ in cols) + "|\n"]
        for r in rows:
            lines.append("| " + " | ".join(str(r.get(k, "")) for k, _ in cols) + " |\n")
        return "".join(lines)

    text = f"""# SFT Track2R-02: Lambda Readout Selector Freeze

## Verdict

**{verdict['verdict']}**

Selector hash:

`{selector_hash}`

Parent Track2R-01 protocol hash:

`{manifest['parent_protocol_hash_sha256']}`

Parent feature table hash:

`{manifest['parent_feature_table_sha256']}`

## Primary selector

The primary selector is the minimal no-target Type-to-endpoint law:

\\[
S_T = \\mathrm{{clip}}\\left(1-\\frac{{T}}{{11}},0,1\\right)
\\]

\\[
\\lambda_{{\\rm pred}} = \\lambda_{{\\rm disk}} + (\\lambda_{{\\rm sphere}}-\\lambda_{{\\rm disk}})S_T
\\]

with

\\[
\\lambda_{{\\rm disk}}=3\\pi/8={LAMBDA_DISK:.12f}
\\]

and

\\[
\\lambda_{{\\rm sphere}}=4/3={LAMBDA_SPHERE:.12f}.
\\]

This selector is deliberately simple: it encodes only the SFT-predicted direction that later disk-dominated systems move lower and earlier/bulge-dominated systems move higher.

## Frozen formula cards

{table(cards, [('selector','Selector'),('role','Role'),('required_features','Required features'),('formula','Formula')])}

## Required feature coverage

{table(required, [('selector','Selector'),('feature','Feature'),('available','Available'),('n_finite_or_present','N finite'),('coverage_fraction','Coverage')])}

## No-target audit

{table(audit, [('item','Item'),('detected','Detected'),('used','Used'),('status','Status')])}

## Preview summary

This is not validation. It checks only that the frozen selector produces finite no-target values from the allowed feature table.

{table(preview, [('selector','Selector'),('n_preview','N'),('lambda_min_preview','Min/coord'),('lambda_p16_preview','p16'),('lambda_median_preview','Median'),('lambda_p84_preview','p84'),('lambda_max_preview','Max'),('note','Note')])}

## Gate blueprint

{table(blueprint, [('gate','Gate'),('task','Task'),('success_criterion','Success criterion'),('output','Output')])}

## Claim boundary

Track2R-02 freezes the law only. It does not claim the law works. Track2R-03 must seal the per-galaxy prediction table using this hash before Track2R-04 is allowed to join Track1 \\(\\lambda_{{\\rm best}}\\).
"""
    path.write_text(text, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sparc-dir", default=r"C:\Users\TaicHI\SPARC")
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    sparc_dir = Path(args.sparc_dir).expanduser().resolve()
    out = Path(args.out_dir).expanduser().resolve() if args.out_dir else sparc_dir / OUT_DIR_NAME
    out.mkdir(parents=True, exist_ok=True)

    paths = find_paths(sparc_dir)
    parent_hash, feature_hash, parent_manifest = load_parent(paths)
    feature_rows = read_csv(paths["track2r01_feature_table"])

    manifest = selector_manifest(parent_hash, feature_hash)
    selector_hash = sha256_text(canonical_json(manifest))
    manifest["selector_hash_sha256"] = selector_hash

    cards = formula_cards(manifest)
    required = required_features_rows(manifest, feature_rows)
    audit = no_target_audit(paths)
    preview = preview_summary(feature_rows)
    blueprint = gate_blueprint_rows()

    forbidden_used = any(str(r["used"]).lower() == "true" and "FORBIDDEN" in str(r.get("status","")).upper() for r in audit)
    primary_features_ok = all(
        r["available"] and float(r["coverage_fraction"]) == 1.0
        for r in required
        if r["selector"] == "PRIMARY_TYPE_ENDPOINT_LINEAR" and r["feature"] != "(none)"
    )
    all_feature_coverage_ok = all(bool(r["available"]) and float(r["coverage_fraction"]) > 0.99 for r in required if r["feature"] != "(none)")
    parent_ok = parent_manifest.get("protocol_hash_sha256") == parent_hash

    if parent_ok and primary_features_ok and all_feature_coverage_ok and not forbidden_used and len(feature_rows) > 0:
        v = "TRACK2R02_LAMBDA_READOUT_SELECTOR_FROZEN_READY_FOR_TRACK2R03"
    else:
        v = "TRACK2R02_SELECTOR_FREEZE_REQUIRES_REVIEW"

    verdict = {
        "verdict": v,
        "claim_boundary": "Track2R-02 selector freeze only; no lambda_best join, no validation, no refit, no retuning",
        "selector_version": PROTOCOL_VERSION,
        "parent_protocol_hash_sha256": parent_hash,
        "parent_feature_table_sha256": feature_hash,
        "selector_hash_sha256": selector_hash,
        "feature_rows_seen": len(feature_rows),
        "primary_selector": manifest["primary_selector"]["name"],
        "secondary_selectors_locked": ";".join(s["name"] for s in manifest["secondary_selectors_locked_for_comparison"]),
        "control_selectors_locked": ";".join(s["name"] for s in manifest["control_selectors_locked_for_comparison"]),
        "primary_required_features_ok": primary_features_ok,
        "all_required_feature_coverage_ok": all_feature_coverage_ok,
        "parent_manifest_hash_ok": parent_ok,
        "uses_lambda_best": False,
        "uses_Vobs_or_eVobs": False,
        "uses_rotation_residuals": False,
        "uses_RAR_All_Data": False,
        "uses_old_DBE_track2": False,
        "prediction_table_generated": False,
        "validation_performed": False,
        "main_result": (
            "The no-target morphology-readout selector is frozen and hashed. "
            "Track2R-03 may generate the sealed lambda_pred prediction table using this selector hash."
        ),
        "next_gate": "Track2R-03: generate sealed per-galaxy lambda_pred table without target join.",
    }

    (out / "track2r02_selector_hash.txt").write_text(selector_hash + "\n", encoding="utf-8")
    (out / "track2r02_selector_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    write_csv(out / "track2r02_formula_cards.csv", cards)
    write_csv(out / "track2r02_required_features.csv", required)
    write_csv(out / "track2r02_no_target_audit.csv", audit)
    write_csv(out / "track2r02_selector_preview_summary.csv", preview)
    write_csv(out / "track2r02_gate_blueprint.csv", blueprint)
    write_csv(out / "track2r02_verdict.csv", [verdict])
    (out / "SFT_TRACK2R_02_selector_reference.py").write_text(reference_impl_text(selector_hash), encoding="utf-8")
    write_report(out / "TRACK2R_02_lambda_readout_selector_report.md", manifest, selector_hash, verdict, cards, required, audit, preview, blueprint)

    print("\nSFT TRACK2R-02 LAMBDA READOUT SELECTOR FREEZE")
    print("=============================================")
    print("\nPurpose:")
    print("  Freeze lambda_pred readout law before any target join.")
    print("  No lambda_best, no Vobs/eVobs, no residuals, no RAR, no old D/B/E.")

    print("\nParent lockbox:")
    print(f"  parent protocol hash: {parent_hash}")
    print(f"  parent feature table hash: {feature_hash}")
    print(f"  parent manifest hash ok: {parent_ok}")

    print("\nFrozen selectors:")
    for r in cards:
        print(f"  {r['selector']:42s} role={r['role']}")

    print("\nRequired feature coverage:")
    for r in required:
        print(
            f"  {r['selector']:42s} {r['feature']:38s} "
            f"available={r['available']} coverage={r['coverage_fraction']}"
        )

    print("\nNo-target audit:")
    for r in audit:
        print(f"  {r['item']:32s} detected={r['detected']} used={r['used']} status={r['status']}")

    print("\nSelector preview summary (not validation):")
    for r in preview:
        print(
            f"  {r['selector']:42s} N={r['n_preview']} "
            f"median={r.get('lambda_median_preview','')} "
            f"p16={r.get('lambda_p16_preview','')} p84={r.get('lambda_p84_preview','')}"
        )

    print("\nGate blueprint:")
    for r in blueprint:
        print(f"  {r['gate']:10s} {r['status_after_this_script']:22s} {r['task']}")

    print("\nVerdict:")
    for k, val in verdict.items():
        print(f"  {k}: {val}")

    print("\nFiles:")
    print(f"  output directory: {out}")
    print(f"  selector hash: {out/'track2r02_selector_hash.txt'}")
    print(f"  selector manifest: {out/'track2r02_selector_manifest.json'}")
    print(f"  formula cards: {out/'track2r02_formula_cards.csv'}")
    print(f"  required features: {out/'track2r02_required_features.csv'}")
    print(f"  no-target audit: {out/'track2r02_no_target_audit.csv'}")
    print(f"  preview summary: {out/'track2r02_selector_preview_summary.csv'}")
    print(f"  reference implementation: {out/'SFT_TRACK2R_02_selector_reference.py'}")
    print(f"  verdict: {out/'track2r02_verdict.csv'}")
    print(f"  report: {out/'TRACK2R_02_lambda_readout_selector_report.md'}")


if __name__ == "__main__":
    main()
