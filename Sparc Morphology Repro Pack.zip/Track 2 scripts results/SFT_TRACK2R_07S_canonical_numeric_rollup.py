#!/usr/bin/env python3
"""
SFT Track2R-07S:
Canonical Numeric Sanity Patch for SPARC Lane Rollup

Purpose
-------
Track2R-07R fixed the NaN problem, but two fields can still be mis-parsed
from old CSV schemas:
    - wide edge fraction
    - all-controls partial-rank p-value

This script creates the final canonical paper rollup by using the sealed
Track1/Track1B canonical values directly for the Lane 1/Track1B section,
while still reading the Track2R-04/05/06 numeric values from their output
files.

This is NOT a new science gate. It does not refit, retune, repair,
or change any selector. It only protects the paper-facing rollup from
old CSV schema mis-parsing.

Expected verdict:
    TRACK2R07S_CANONICAL_NUMERIC_ROLLUP_READY_FOR_PAPER_INSERT

Run:
    python SFT_TRACK2R_07S_canonical_numeric_rollup.py --sparc-dir "C:\\Users\\TaicHI\\SPARC"
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

PROTOCOL_VERSION = "SFT_TRACK2R_07S_CANONICAL_NUMERIC_ROLLUP_v1"
OUT_DIR_NAME = "SFT_TRACK2R_07S_CANONICAL_SPARC_LANE_ROLLUP"

EXPECTED_TRACK2R04 = "TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS"
EXPECTED_TRACK2R05 = "TRACK2R05_DIRECTIONAL_LAMBDA_VALIDATION_DOES_NOT_IMPROVE_ROTATION_CURVES"
EXPECTED_TRACK2R06 = "TRACK2R06_MORPHOLOGY_DIRECTION_VALIDATED_AMPLITUDE_CLOSURE_OPEN"
EXPECTED_TRACK2R07 = "TRACK2R07_SPARC_LANES_ROLLED_UP_DIRECTIONAL_MORPHOLOGY_RESULT_WITH_AMPLITUDE_CAUTION"
EXPECTED_TRACK2R07R = "TRACK2R07R_NUMERIC_INGEST_PATCHED_ROLLUP_READY_FOR_PAPER_INSERT"

CANONICAL = {
    "track1_verdict": "MORPHOLOGY_LAMBDA_WIDE_RERUN_CONFIRMS_CORRELATION_WITH_CAUTIONS",
    "track1b_verdict": "TRACK1B_ROBUSTNESS_AUDIT_SIGNAL_SURVIVES_WITH_EDGE_CAUTIONS",

    # Track1 / wide-rail rerun canonical values
    "track1_full_rho": -0.27161389600924596,
    "track1_full_p": 0.0002769472823964572,
    "track1_interior_rho": -0.24775767351229477,
    "track1_interior_p": 0.0038983220391168865,
    "track1_edge_fraction": 0.2342857142857143,
    "track1_permutation_p": 0.0007999200079992001,
    "track1_inclination_full_p": 0.29586778546667586,
    "track1_bulge_fraction_full_p": 0.028072263173873593,

    # Track1B robustness canonical values
    "track1b_full_rho": -0.27161389600924596,
    "track1b_full_p": 0.0002769472823964572,
    "track1b_interior_rho": -0.24775767351229477,
    "track1b_interior_p": 0.0038983220391168865,
    "track1b_q1_rho": -0.14724927665522128,
    "track1b_q1_p": 0.1458228105305058,
    "track1b_q1q2_rho": -0.2555529508719165,
    "track1b_q1q2_p": 0.000993303089194354,
    "track1b_type210_rho": -0.30990678800024285,
    "track1b_type210_p": 5.384809110525655e-05,
    "track1b_type210_interior_rho": -0.25549421484602025,
    "track1b_type210_interior_p": 0.0034748572832141826,
    "track1b_exclude_t0_t11_p": 0.00013230077012864815,
    "track1b_npoints_rho": -0.15276809845208664,
    "track1b_npoints_p": 0.15293474105197186,
    "track1b_all_controls_partial_p": 0.8205972197732623,
    "track1b_full_bootstrap_ci_low": -0.420787,
    "track1b_full_bootstrap_ci_high": -0.114175,
    "track1b_interior_bootstrap_ci_low": -0.40682,
    "track1b_interior_bootstrap_ci_high": -0.0782502,
}


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def finite(x: Any) -> bool:
    return math.isfinite(safe_float(x))


def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def sha256_file(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def first(rows: list[dict]) -> dict:
    return rows[0] if rows else {}


def get_metric(rows: list[dict], group: str, selector_short: str) -> dict:
    for r in rows:
        if str(r.get("group", "")) == group and str(r.get("selector_short", "")) == selector_short:
            return r
    return {}


def find_paths(sparc_dir: Path) -> dict:
    t2r04 = sparc_dir / "SFT_TRACK2R_04_LAMBDA_PREDICTION_VALIDATION"
    t2r05 = sparc_dir / "SFT_TRACK2R_05_ROTATION_CURVE_VALIDATION"
    t2r06 = sparc_dir / "SFT_TRACK2R_06_CLOSURE_DIAGNOSTIC"
    t2r07 = sparc_dir / "SFT_TRACK2R_07_SPARC_LANE_ROLLUP"
    t2r07r = sparc_dir / "SFT_TRACK2R_07R_PATCHED_SPARC_LANE_ROLLUP"

    return {
        "track2r04_verdict": t2r04 / "track2r04_verdict.csv",
        "track2r04_metrics": t2r04 / "track2r04_selector_metrics.csv",
        "track2r05_verdict": t2r05 / "track2r05_verdict.csv",
        "track2r05_metrics": t2r05 / "track2r05_selector_metrics.csv",
        "track2r06_verdict": t2r06 / "track2r06_closure_verdict.csv",
        "track2r06_help_hurt_summary": t2r06 / "track2r06_help_hurt_summary.csv",
        "track2r06_failure_modes": t2r06 / "track2r06_failure_mode_by_group.csv",
        "track2r07_verdict": t2r07 / "track2r07_rollup_verdict.csv",
        "track2r07r_verdict": t2r07r / "track2r07R_rollup_verdict.csv",
    }


def parse_track2r(paths: dict) -> dict:
    v04 = first(read_csv(paths["track2r04_verdict"]))
    m04 = read_csv(paths["track2r04_metrics"])
    v05 = first(read_csv(paths["track2r05_verdict"]))
    m05 = read_csv(paths["track2r05_metrics"])
    v06 = first(read_csv(paths["track2r06_verdict"]))
    hh = first(read_csv(paths["track2r06_help_hurt_summary"]))
    v07 = first(read_csv(paths["track2r07_verdict"]))
    v07r = first(read_csv(paths["track2r07r_verdict"]))

    p04 = get_metric(m04, "FULL", "primary")
    b04 = get_metric(m04, "FULL", "tertiary_blend")
    p05 = get_metric(m05, "FULL", "primary")
    sphere05 = get_metric(m05, "FULL", "control_sphere")
    ceiling05 = get_metric(m05, "FULL", "ceiling_best")
    lowacc = get_metric(m05, "LOW_ACCEL_LOGGBAR_LT_MINUS11", "primary")
    type210i = get_metric(m05, "TYPE_2_TO_10_INTERIOR", "primary")
    npointsi = get_metric(m05, "NPOINTS_GE_MEDIAN_INTERIOR", "primary")

    return {
        "track2r07_verdict": v07.get("verdict", ""),
        "track2r07r_verdict": v07r.get("verdict", ""),
        "track2r04_verdict": v04.get("verdict", ""),
        "track2r05_verdict": v05.get("verdict", ""),
        "track2r06_verdict": v06.get("verdict", ""),

        "track2r04_primary_rho": safe_float(p04.get("spearman_rho")),
        "track2r04_primary_p": safe_float(p04.get("spearman_p")),
        "track2r04_primary_rmse_lambda": safe_float(p04.get("rmse")),
        "track2r04_primary_mae_lambda": safe_float(p04.get("mae")),
        "track2r04_blend_rho": safe_float(b04.get("spearman_rho")),
        "track2r04_blend_p": safe_float(b04.get("spearman_p")),
        "track2r04_blend_rmse_lambda": safe_float(b04.get("rmse")),

        "track2r05_primary_rmsV": safe_float(p05.get("rms_V_km_s")),
        "track2r05_primary_maeV": safe_float(p05.get("mae_V_km_s")),
        "track2r05_primary_rmsLogV": safe_float(p05.get("rms_log10V")),
        "track2r05_primary_delta_vs_best_constant": safe_float(p05.get("delta_rms_V_vs_best_constant_control")),
        "track2r05_sphere_control_rmsV": safe_float(sphere05.get("rms_V_km_s")),
        "track2r05_ceiling_rmsV": safe_float(ceiling05.get("rms_V_km_s")),
        "track2r05_primary_delta_vs_ceiling": safe_float(p05.get("delta_rms_V_vs_ceiling_best")),
        "track2r05_lowacc_delta": safe_float(lowacc.get("delta_rms_V_vs_best_constant_control")),
        "track2r05_type210_interior_delta": safe_float(type210i.get("delta_rms_V_vs_best_constant_control")),
        "track2r05_npoints_interior_delta": safe_float(npointsi.get("delta_rms_V_vs_best_constant_control")),

        "track2r06_help_N": safe_float(hh.get("help_N")),
        "track2r06_hurt_N": safe_float(hh.get("hurt_N")),
        "track2r06_tie_N": safe_float(hh.get("tie_N")),
        "track2r06_help_fraction": safe_float(hh.get("help_fraction")),
        "track2r06_median_delta_rms": safe_float(hh.get("median_delta_rms")),
    }


def fmt(x: Any, digits: int = 4) -> str:
    f = safe_float(x)
    if math.isfinite(f):
        if abs(f) != 0 and (abs(f) < 1e-3 or abs(f) >= 1e4):
            return f"{f:.{digits}e}"
        return f"{f:.{digits}g}"
    return str(x)


def build_evidence(t2r: dict) -> list[dict]:
    c = CANONICAL
    return [
        {
            "lane": "Lane 1",
            "step": "Track1 wide-rail morphology-lambda rerun",
            "result": "SUPPORTED_WITH_CAUTIONS",
            "key_numbers": (
                f"full rho={c['track1_full_rho']}, p={c['track1_full_p']}; "
                f"interior rho={c['track1_interior_rho']}, p={c['track1_interior_p']}; "
                f"wide_edge_fraction={c['track1_edge_fraction']}"
            ),
            "interpretation": "Per-galaxy fitted lambda has a morphology-linked structure after widening the lambda scan rails.",
            "claim_boundary": "Correlation/readout structure only; no dark-halo claim, no completed rotation-curve law.",
        },
        {
            "lane": "Lane 1",
            "step": "Track1B robustness audit",
            "result": "SURVIVES_WITH_SAMPLE_STRUCTURE_CAUTIONS",
            "key_numbers": (
                f"Q1 p={c['track1b_q1_p']}; Q1_Q2 p={c['track1b_q1q2_p']}; "
                f"Type2-10 interior p={c['track1b_type210_interior_p']}; "
                f"high-N p={c['track1b_npoints_p']}; "
                f"all-controls partial p={c['track1b_all_controls_partial_p']}"
            ),
            "interpretation": "Signal is not simply an old rail or inclination artifact, but is entangled with quality/composition/sample structure.",
            "claim_boundary": "Robust morphology correlation with cautions, not a closed interpolation law.",
        },
        {
            "lane": "Lane 2",
            "step": "Track2R-04 no-target lambda-direction validation",
            "result": "SUPPORTED",
            "key_numbers": (
                f"primary rho={t2r['track2r04_primary_rho']}, p={t2r['track2r04_primary_p']}, "
                f"RMSE(lambda)={t2r['track2r04_primary_rmse_lambda']}; blend rho={t2r['track2r04_blend_rho']}"
            ),
            "interpretation": "A frozen no-target morphology selector recovers the direction of fitted lambda structure.",
            "claim_boundary": "Directional lambda-space validation only; not a precision predictor.",
        },
        {
            "lane": "Lane 2",
            "step": "Track2R-05 rotation-curve propagation",
            "result": "NOT_SUPPORTED_FULL_SAMPLE",
            "key_numbers": (
                f"primary RMSV={t2r['track2r05_primary_rmsV']} km/s; "
                f"sphere control RMSV={t2r['track2r05_sphere_control_rmsV']} km/s; "
                f"delta vs best constant={t2r['track2r05_primary_delta_vs_best_constant']}; "
                f"Track1 ceiling RMSV={t2r['track2r05_ceiling_rmsV']} km/s"
            ),
            "interpretation": "The first sealed morphology readout does not improve full-sample rotation curves over the best constant-lambda control.",
            "claim_boundary": "Amplitude/readout closure remains open.",
        },
        {
            "lane": "Lane 2",
            "step": "Track2R-06 closure diagnostic",
            "result": "CLOSED_WITH_CAUTION",
            "key_numbers": (
                f"help_N={t2r['track2r06_help_N']}, hurt_N={t2r['track2r06_hurt_N']}, "
                f"tie_N={t2r['track2r06_tie_N']}, help_fraction={t2r['track2r06_help_fraction']}"
            ),
            "interpretation": "Track2R supports morphology as a readout coordinate, but not a completed rotation-curve amplitude law.",
            "claim_boundary": "Directional support lane only.",
        },
    ]


def build_claims(t2r: dict) -> list[dict]:
    c = CANONICAL
    return [
        {
            "claim": "SPARC fitted lambda is morphology structured",
            "status": "SUPPORTED",
            "allowed_wording": "The SPARC fitted per-galaxy lambda values show a statistically significant morphology-linked trend, robust to several but not all cuts.",
            "forbidden_wording": "SFT fully derives each galaxy rotation curve from morphology alone.",
            "basis": f"Track1 full rho={c['track1_full_rho']}, p={c['track1_full_p']}; interior rho={c['track1_interior_rho']}, p={c['track1_interior_p']}.",
        },
        {
            "claim": "Signal is not a narrow-rail artifact",
            "status": "SUPPORTED_WITH_EDGE_CAUTION",
            "allowed_wording": "The wide-rail rerun preserves the morphology-lambda trend after expanding the lambda scan range.",
            "forbidden_wording": "All edge effects are eliminated.",
            "basis": f"Wide-edge fraction={c['track1_edge_fraction']}; edge cautions remain.",
        },
        {
            "claim": "Signal is independent of all sample/composition structure",
            "status": "NOT_SUPPORTED",
            "allowed_wording": "The signal is not explained by inclination alone, but multivariable/sample-structure controls absorb much of it.",
            "forbidden_wording": "The morphology signal is fully isolated from sample quality and composition.",
            "basis": f"Q1-only p={c['track1b_q1_p']}; high-N p={c['track1b_npoints_p']}; all-controls partial p={c['track1b_all_controls_partial_p']}.",
        },
        {
            "claim": "Frozen no-target morphology readout predicts lambda direction",
            "status": "SUPPORTED",
            "allowed_wording": "A predeclared Type-endpoint morphology selector recovers the direction of fitted lambda structure without target leakage.",
            "forbidden_wording": "The frozen selector is a precision lambda predictor.",
            "basis": f"Track2R-04 rho={t2r['track2r04_primary_rho']}, p={t2r['track2r04_primary_p']}.",
        },
        {
            "claim": "Frozen no-target morphology readout improves full-sample rotation curves",
            "status": "NOT_SUPPORTED",
            "allowed_wording": "The same frozen selector does not improve full-sample rotation-curve residuals over the best constant-lambda control.",
            "forbidden_wording": "Track2R proves a successful SPARC rotation-curve prediction law.",
            "basis": f"Track2R-05 delta RMS vs best constant={t2r['track2r05_primary_delta_vs_best_constant']}.",
        },
        {
            "claim": "Amplitude/readout closure",
            "status": "OPEN",
            "allowed_wording": "The amplitude/readout law remains open and requires a new predeclared fork if pursued.",
            "forbidden_wording": "A post-hoc correction can be added to the same locked validation chain.",
            "basis": f"Track2R-06 verdict={t2r['track2r06_verdict']}.",
        },
        {
            "claim": "Public SPARC result",
            "status": "SUPPORTED_WITH_CAUTION",
            "allowed_wording": "SPARC supports morphology-dependent SFT weak-field readout structure, while the first no-target amplitude closure remains incomplete.",
            "forbidden_wording": "SPARC validates the full SFT gravity program.",
            "basis": "SPARC is an empirical galaxy-readout branch, not the entire V12.3 gravity program.",
        },
    ]


def build_numeric(t2r: dict) -> list[dict]:
    rows = []
    for k, v in CANONICAL.items():
        if k.endswith("verdict"):
            continue
        rows.append({"section": "Canonical Track1/Track1B", "metric": k, "value": v, "source": "canonical_locked_prior_gate_value"})
    for k, v in t2r.items():
        if k.endswith("verdict"):
            continue
        rows.append({"section": "Parsed Track2R", "metric": k, "value": v, "source": "parsed_current_track2r_outputs"})
    return rows


def build_verdict(t2r: dict) -> dict:
    ok = (
        t2r.get("track2r04_verdict") == EXPECTED_TRACK2R04
        and t2r.get("track2r05_verdict") == EXPECTED_TRACK2R05
        and t2r.get("track2r06_verdict") == EXPECTED_TRACK2R06
        and finite(t2r.get("track2r04_primary_rho"))
        and finite(t2r.get("track2r05_primary_delta_vs_best_constant"))
    )
    if ok:
        verdict = "TRACK2R07S_CANONICAL_NUMERIC_ROLLUP_READY_FOR_PAPER_INSERT"
        main = "Track2R-07/07R rollup preserved; canonical Track1/Track1B numbers forced into the paper insert to avoid schema mis-parsing."
    else:
        verdict = "TRACK2R07S_CANONICAL_ROLLUP_REQUIRES_REVIEW"
        main = "One or more expected Track2R inputs is missing or malformed."

    return {
        "verdict": verdict,
        "track2r07s_version": PROTOCOL_VERSION,
        "claim_boundary": "Canonical numeric paper-rollup patch only; no new fit, no new selector, no retuning, no upgraded success claim",
        "track2r07_original_verdict": t2r.get("track2r07_verdict", ""),
        "track2r07r_original_verdict": t2r.get("track2r07r_verdict", ""),
        "track1_verdict": CANONICAL["track1_verdict"],
        "track1b_verdict": CANONICAL["track1b_verdict"],
        "track2r04_verdict": t2r.get("track2r04_verdict", ""),
        "track2r05_verdict": t2r.get("track2r05_verdict", ""),
        "track2r06_verdict": t2r.get("track2r06_verdict", ""),
        "track1_full_rho": CANONICAL["track1_full_rho"],
        "track1_full_p": CANONICAL["track1_full_p"],
        "track1_interior_rho": CANONICAL["track1_interior_rho"],
        "track1_interior_p": CANONICAL["track1_interior_p"],
        "track1_edge_fraction": CANONICAL["track1_edge_fraction"],
        "track1b_all_controls_partial_p": CANONICAL["track1b_all_controls_partial_p"],
        "track2r04_primary_rho": t2r.get("track2r04_primary_rho"),
        "track2r05_delta_vs_best_constant": t2r.get("track2r05_primary_delta_vs_best_constant"),
        "track2r06_help_fraction": t2r.get("track2r06_help_fraction"),
        "main_result": main,
        "paper_thesis": "SPARC lambda structure is morphology-linked; a frozen no-target morphology readout recovers direction but not full rotation-curve amplitude.",
        "recommended_next_step": "Use the 07S paper insert as the canonical SPARC morphology paper insert; any amplitude law remains Track3/new fork.",
    }


def build_paper_texts(t2r: dict, verdict: dict) -> dict[str, str]:
    c = CANONICAL
    abstract = f"""# Abstract Candidate

We report a SPARC weak-field readout audit of Solvency Field Theory focused on whether the per-galaxy solvency coefficient, lambda, behaves as a universal constant or as a morphology-dependent readout coordinate. A wide-rail rerun of the SPARC lambda profile scan preserves a significant morphology-lambda trend, with full-sample Spearman rho = {fmt(c['track1_full_rho'])} and p = {fmt(c['track1_full_p'])}; the non-edge interior sample gives rho = {fmt(c['track1_interior_rho'])} and p = {fmt(c['track1_interior_p'])}. Robustness checks show that the signal survives several edge and morphology cuts, while quality and sample-structure controls remain important cautions. A separately frozen no-target morphology selector recovers the direction of the fitted lambda structure, with Track2R-04 primary rho = {fmt(t2r['track2r04_primary_rho'])} and p = {fmt(t2r['track2r04_primary_p'])}. However, propagating the sealed predictor into rotation curves does not improve the full-sample velocity residuals over the best constant-lambda control, with delta RMS = {fmt(t2r['track2r05_primary_delta_vs_best_constant'])} km/s. We therefore conclude that SPARC supports morphology-dependent lambda readout structure, but the first Type-endpoint no-target amplitude law is not a completed rotation-curve predictor.
"""

    methods = f"""# Methods Insert

The SPARC analysis was divided into two lanes. Lane 1 measured the fitted per-galaxy lambda structure using a fixed weak-field law and a widened lambda scan range. The scan used fixed constants and fixed stellar mass-to-light assumptions, then tested whether the resulting lambda_best values correlate with galaxy morphology. Lane 1B repeated the morphology audit across robustness cuts, edge checks, quality cuts, bootstrap intervals, and partial-rank controls.

Lane 2, Track2R, was frozen before target validation. Track2R-01 created the allowed no-target morphology/source feature table. Track2R-02 froze the lambda readout selector. Track2R-03 generated the sealed per-galaxy lambda_pred table. Track2R-04 was the first allowed join to Track1 lambda_best. Track2R-05 propagated the sealed lambda_pred values into rotation-curve predictions against ROTMOD Vobs/eVobs as validation targets only. Track2R-06 closed the result with no selector repair, no refit, no retuning, and no new amplitude law. Track2R-07 and Track2R-07R/07S are rollup and paper-text packaging steps only.

The key locked primary readout was the Type-endpoint selector, mapping Hubble Type to a bounded interpolation between the disk endpoint 3pi/8 and the spherical endpoint 4/3. Track1 lambda_best was used as a validation target in Track2R-04 and as a fit-ceiling reference in Track2R-05; it was not used to modify the sealed predictions.
"""

    results = f"""# Results Insert

Lane 1 found a statistically significant morphology-lambda trend. The full-sample Track1 rank correlation was rho = {fmt(c['track1_full_rho'])} with p = {fmt(c['track1_full_p'])}. The interior/non-edge result was rho = {fmt(c['track1_interior_rho'])} with p = {fmt(c['track1_interior_p'])}. The wide-rail edge fraction was {fmt(c['track1_edge_fraction'])}, so edge caution is retained. The permutation control gave p = {fmt(c['track1_permutation_p'])}.

Track1B confirmed that the signal was not simply an old rail artifact or an inclination artifact, but also showed that the trend is weakened in selected quality and high-point-count cuts. The Q1-only cut gave p = {fmt(c['track1b_q1_p'])}, while the Q1+Q2 cut gave p = {fmt(c['track1b_q1q2_p'])}. The Type 2--10 interior cut gave p = {fmt(c['track1b_type210_interior_p'])}. The high-point-count cut gave p = {fmt(c['track1b_npoints_p'])}. A multivariable partial-rank control including inclination, quality, point count, bulge fraction, and gas fraction gave p = {fmt(c['track1b_all_controls_partial_p'])}, marking the sample-structure caution.

Track2R-04 validated the no-target morphology readout direction. The primary selector gave rho = {fmt(t2r['track2r04_primary_rho'])}, p = {fmt(t2r['track2r04_primary_p'])}, RMSE(lambda) = {fmt(t2r['track2r04_primary_rmse_lambda'])}, and MAE(lambda) = {fmt(t2r['track2r04_primary_mae_lambda'])}. The blend selector had a slightly larger rank correlation, rho = {fmt(t2r['track2r04_blend_rho'])}, but did not improve the amplitude error over the primary selector.

Track2R-05 did not validate the same sealed predictor as a full-sample rotation-curve improvement. The primary selector produced RMS V = {fmt(t2r['track2r05_primary_rmsV'])} km/s, while the best constant control, the sphere endpoint, gave RMS V = {fmt(t2r['track2r05_sphere_control_rmsV'])} km/s. The primary delta relative to the best constant was therefore {fmt(t2r['track2r05_primary_delta_vs_best_constant'])} km/s. The Track1 lambda_best fit ceiling remained substantially better, RMS V = {fmt(t2r['track2r05_ceiling_rmsV'])} km/s, leaving a primary-ceiling gap of {fmt(t2r['track2r05_primary_delta_vs_ceiling'])} km/s.

Track2R-06 closed the track as directional morphology-readout support with amplitude closure open. Per-galaxy help/hurt was help_N = {fmt(t2r['track2r06_help_N'])}, hurt_N = {fmt(t2r['track2r06_hurt_N'])}, tie_N = {fmt(t2r['track2r06_tie_N'])}, with help fraction {fmt(t2r['track2r06_help_fraction'])}.
"""

    discussion = f"""# Discussion Insert

The SPARC result should be interpreted as evidence that the SFT weak-field readout is morphology-structured rather than universal. The central empirical statement is not that a final rotation-curve law has been derived, but that the fitted lambda coordinate carries a reproducible morphology dependence. The frozen no-target Track2R selector strengthens this interpretation by recovering the direction of the fitted lambda structure without target leakage.

The same Track2R sequence also prevents overclaiming. Directional lambda-space validation did not close into full-sample rotation-curve improvement. The first Type-endpoint law is therefore too crude as an amplitude predictor. This suggests that morphology is a real readout coordinate, but that the amplitude/readout map requires additional predeclared physical structure before it can function as a precision rotation-curve model.

The appropriate conclusion is that SPARC supports a morphology-dependent SFT readout lane with explicit sample-structure and amplitude-closure cautions. Any future amplitude repair or expanded readout law should be treated as a new predeclared fork rather than a continuation of the sealed Track2R validation.
"""

    full = f"""# SPARC Morphology-Readout Paper Insert

## Thesis

**{verdict['paper_thesis']}**

## Abstract candidate

{abstract}

## Methods insert

{methods}

## Results insert

{results}

## Discussion insert

{discussion}

## Compact claim boundary

Allowed:

> SPARC supports morphology-dependent SFT weak-field readout structure. A frozen no-target morphology selector recovers the direction of fitted lambda, but the first Type-endpoint amplitude law does not improve full-sample rotation curves over the best constant-lambda control.

Forbidden:

> SPARC validates the full SFT gravity program or proves a completed no-target rotation-curve predictor.
"""
    return {
        "track2r07S_abstract_candidate.md": abstract,
        "track2r07S_methods_insert.md": methods,
        "track2r07S_results_insert.md": results,
        "track2r07S_discussion_insert.md": discussion,
        "track2r07S_paper_insert.md": full,
    }


def write_report(path: Path, verdict: dict, evidence: list[dict], claims: list[dict], numeric: list[dict]) -> None:
    def table(rows, cols):
        lines = ["| " + " | ".join(label for _, label in cols) + " |\n",
                 "|" + "|".join("---" for _ in cols) + "|\n"]
        for r in rows:
            lines.append("| " + " | ".join(str(r.get(k, "")) for k, _ in cols) + " |\n")
        return "".join(lines)

    text = f"""# SFT Track2R-07S Canonical SPARC Lane Rollup

## Verdict

**{verdict['verdict']}**

{verdict['main_result']}

## Paper thesis

**{verdict['paper_thesis']}**

## Claim boundary

{verdict['claim_boundary']}

## Evidence ladder

{table(evidence, [('lane','Lane'),('step','Step'),('result','Result'),('key_numbers','Key numbers'),('interpretation','Interpretation'),('claim_boundary','Claim boundary')])}

## Claim boundary table

{table(claims, [('claim','Claim'),('status','Status'),('allowed_wording','Allowed wording'),('forbidden_wording','Forbidden wording'),('basis','Basis')])}

## Numeric highlights

{table(numeric, [('section','Section'),('metric','Metric'),('value','Value'),('source','Source')])}

## Recommended use

Use this 07S rollup as the canonical SPARC morphology paper insert. Do not present Track2R as a completed rotation-curve prediction success. The final Track2R status remains directional morphology support with amplitude closure open.
"""
    path.write_text(text, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sparc-dir", default=r"C:\Users\TaicHI\SPARC")
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    sparc_dir = Path(args.sparc_dir).expanduser().resolve()
    out = Path(args.out_dir).expanduser().resolve() if args.out_dir else sparc_dir / OUT_DIR_NAME
    out.mkdir(parents=True, exist_ok=True)

    paths = find_paths(sparc_dir)
    required = [
        paths["track2r04_verdict"],
        paths["track2r04_metrics"],
        paths["track2r05_verdict"],
        paths["track2r05_metrics"],
        paths["track2r06_verdict"],
        paths["track2r06_help_hurt_summary"],
    ]
    missing = [p for p in required if not p.exists()]
    if missing:
        print("ERROR: missing required Track2R inputs:", file=sys.stderr)
        for p in missing:
            print(f"  {p}", file=sys.stderr)
        sys.exit(2)

    t2r = parse_track2r(paths)
    evidence = build_evidence(t2r)
    claims = build_claims(t2r)
    numeric = build_numeric(t2r)
    verdict = build_verdict(t2r)
    papers = build_paper_texts(t2r, verdict)

    write_csv(out / "track2r07S_rollup_verdict.csv", [verdict])
    write_csv(out / "track2r07S_evidence_ladder.csv", evidence)
    write_csv(out / "track2r07S_claim_boundary_table.csv", claims)
    write_csv(out / "track2r07S_numeric_highlights.csv", numeric)

    for fn, text in papers.items():
        (out / fn).write_text(text, encoding="utf-8")

    manifest = {
        "track2r07s_version": PROTOCOL_VERSION,
        "verdict": verdict,
        "input_paths": {k: str(v) for k, v in paths.items()},
        "input_sha256": {k: sha256_file(v) for k, v in paths.items() if v.exists() and v.is_file()},
        "canonical_values": CANONICAL,
        "output_files": [
            "track2r07S_rollup_verdict.csv",
            "track2r07S_evidence_ladder.csv",
            "track2r07S_claim_boundary_table.csv",
            "track2r07S_numeric_highlights.csv",
            "track2r07S_paper_insert.md",
            "track2r07S_abstract_candidate.md",
            "track2r07S_methods_insert.md",
            "track2r07S_results_insert.md",
            "track2r07S_discussion_insert.md",
            "TRACK2R_07S_canonical_SPARC_lane_rollup_report.md",
        ],
        "claim_boundary": verdict["claim_boundary"],
    }
    (out / "track2r07S_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    write_report(out / "TRACK2R_07S_canonical_SPARC_lane_rollup_report.md", verdict, evidence, claims, numeric)

    print("\nSFT TRACK2R-07S CANONICAL SPARC LANE ROLLUP")
    print("===========================================")
    print("\nPurpose:")
    print("  Final canonical paper rollup. No new analysis; fixes 07R schema mis-parses.")

    print("\nInput verdicts:")
    print(f"  Track1 canonical:  {CANONICAL['track1_verdict']}")
    print(f"  Track1B canonical: {CANONICAL['track1b_verdict']}")
    print(f"  Track2R-07 original: {t2r.get('track2r07_verdict')}")
    print(f"  Track2R-07R original: {t2r.get('track2r07r_verdict')}")
    print(f"  Track2R-04: {t2r.get('track2r04_verdict')}")
    print(f"  Track2R-05: {t2r.get('track2r05_verdict')}")
    print(f"  Track2R-06: {t2r.get('track2r06_verdict')}")

    print("\nCanonical numeric highlights:")
    for k in [
        "track1_full_rho", "track1_full_p", "track1_interior_rho", "track1_interior_p",
        "track1_edge_fraction", "track1_permutation_p", "track1b_q1_p", "track1b_q1q2_p",
        "track1b_type210_interior_p", "track1b_npoints_p", "track1b_all_controls_partial_p"
    ]:
        print(f"  {k}: {CANONICAL[k]}")
    for k in [
        "track2r04_primary_rho", "track2r04_primary_p",
        "track2r05_primary_delta_vs_best_constant",
        "track2r06_help_fraction"
    ]:
        print(f"  {k}: {t2r[k]}")

    print("\nEvidence ladder:")
    for r in evidence:
        print(f"  {r['lane']:7s} {r['step']:52s} {r['result']}")

    print("\nClaim boundary table:")
    for r in claims:
        print(f"  {r['claim']}: {r['status']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {out}")
    print(f"  canonical verdict: {out/'track2r07S_rollup_verdict.csv'}")
    print(f"  evidence ladder: {out/'track2r07S_evidence_ladder.csv'}")
    print(f"  claim table: {out/'track2r07S_claim_boundary_table.csv'}")
    print(f"  numeric highlights: {out/'track2r07S_numeric_highlights.csv'}")
    print(f"  paper insert: {out/'track2r07S_paper_insert.md'}")
    print(f"  report: {out/'TRACK2R_07S_canonical_SPARC_lane_rollup_report.md'}")


if __name__ == "__main__":
    main()
