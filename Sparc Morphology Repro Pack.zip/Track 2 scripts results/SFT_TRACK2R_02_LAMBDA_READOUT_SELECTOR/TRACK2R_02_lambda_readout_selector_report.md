# SFT Track2R-02: Lambda Readout Selector Freeze

## Verdict

**TRACK2R02_LAMBDA_READOUT_SELECTOR_FROZEN_READY_FOR_TRACK2R03**

Selector hash:

`2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021`

Parent Track2R-01 protocol hash:

`917160406652d7aeee603833eefdbd653ebb11d41eef0f7cdd5113a3cc806ca3`

Parent feature table hash:

`8b5b0e5c4262d2f910c89da6be499f1543808c6043709a4ce50071060e47747c`

## Primary selector

The primary selector is the minimal no-target Type-to-endpoint law:

\[
S_T = \mathrm{clip}\left(1-\frac{T}{11},0,1\right)
\]

\[
\lambda_{\rm pred} = \lambda_{\rm disk} + (\lambda_{\rm sphere}-\lambda_{\rm disk})S_T
\]

with

\[
\lambda_{\rm disk}=3\pi/8=1.178097245096
\]

and

\[
\lambda_{\rm sphere}=4/3=1.333333333333.
\]

This selector is deliberately simple: it encodes only the SFT-predicted direction that later disk-dominated systems move lower and earlier/bulge-dominated systems move higher.

## Frozen formula cards

| Selector | Role | Required features | Formula |
|---|---|---|---|
| PRIMARY_TYPE_ENDPOINT_LINEAR | primary_prediction | Type | S_type = clamp(1 - Type/11, 0, 1) ; lambda_pred = lambda_disk_3pi8 + delta_lambda * S_type |
| SECONDARY_SOURCE_ROOT_SPHERICITY | locked_secondary_comparison | source_bulge_fraction_proxy; source_bulge_inner_weight_proxy; source_disk_fraction_proxy; source_gas_fraction_proxy | Bf = clamp(source_bulge_fraction_proxy, 0, 1) ; Bi = clamp(source_bulge_inner_weight_proxy, 0, 1) ; Df = clamp(source_disk_fraction_proxy, 0, 1) ; Gf = clamp(source_gas_fraction_proxy, 0, 1) ; S_source = clamp(mean([sqrt(Bf), sqrt(Bi), 1 - sqrt(Df), 1 - sqrt(Gf)]), 0, 1) ; lambda_pred = lambda_disk_3pi8 + delta_lambda * S_source |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | locked_secondary_comparison | Type; source_bulge_fraction_proxy; source_bulge_inner_weight_proxy; source_disk_fraction_proxy; source_gas_fraction_proxy | S_blend = clamp(0.5 * S_type + 0.5 * S_source, 0, 1) ; lambda_pred = lambda_disk_3pi8 + delta_lambda * S_blend |
| CONTROL_CONSTANT_DISK_ENDPOINT | control |  | lambda_pred = lambda_disk_3pi8 |
| CONTROL_CONSTANT_SPHERE_ENDPOINT | control |  | lambda_pred = lambda_sphere_4over3 |
| CONTROL_CONSTANT_ENDPOINT_MIDPOINT | control |  | lambda_pred = 0.5 * (lambda_disk_3pi8 + lambda_sphere_4over3) |


## Required feature coverage

| Selector | Feature | Available | N finite | Coverage |
|---|---|---|---|---|
| PRIMARY_TYPE_ENDPOINT_LINEAR | Type | True | 175 | 1.0 |
| SECONDARY_SOURCE_ROOT_SPHERICITY | source_bulge_fraction_proxy | True | 175 | 1.0 |
| SECONDARY_SOURCE_ROOT_SPHERICITY | source_bulge_inner_weight_proxy | True | 175 | 1.0 |
| SECONDARY_SOURCE_ROOT_SPHERICITY | source_disk_fraction_proxy | True | 175 | 1.0 |
| SECONDARY_SOURCE_ROOT_SPHERICITY | source_gas_fraction_proxy | True | 175 | 1.0 |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | Type | True | 175 | 1.0 |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | source_bulge_fraction_proxy | True | 175 | 1.0 |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | source_bulge_inner_weight_proxy | True | 175 | 1.0 |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | source_disk_fraction_proxy | True | 175 | 1.0 |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | source_gas_fraction_proxy | True | 175 | 1.0 |
| CONTROL_CONSTANT_DISK_ENDPOINT | (none) | True | 175 | 1.0 |
| CONTROL_CONSTANT_SPHERE_ENDPOINT | (none) | True | 175 | 1.0 |
| CONTROL_CONSTANT_ENDPOINT_MIDPOINT | (none) | True | 175 | 1.0 |


## No-target audit

| Item | Detected | Used | Status |
|---|---|---|---|
| Track2R-01 feature table | True | True | ALLOWED_PARENT_INPUT |
| Track2R-01 protocol hash | True | True | ALLOWED_PARENT_INPUT |
| Track1 lambda_best | True | False | QUARANTINED |
| Track1B robustness | True | False | QUARANTINED |
| RAR_All_Data | True | False | QUARANTINED |
| Old Track2 Gate14C | True | False | QUARANTINED |
| Old Track2 Gate14D | True | False | QUARANTINED |
| lambda prediction generated | False | False | NOT_THIS_GATE |
| validation against lambda_best | False | False | NOT_THIS_GATE |


## Preview summary

This is not validation. It checks only that the frozen selector produces finite no-target values from the allowed feature table.

| Selector | N | Min/coord | p16 | Median | p84 | Max | Note |
|---|---|---|---|---|---|---|---|
| PRIMARY_TYPE_ENDPOINT_LINEAR | 175 | 1.1780972450961724 | 1.192209616754096 | 1.2345467317278673 | 1.279141826166906 | 1.3333333333333333 | preview only; no lambda_best joined |
| SECONDARY_SOURCE_ROOT_SPHERICITY | 175 | 1.2008310801569047 | 1.2010630140170673 | 1.2031715696509673 | 1.2436207980905678 | 1.310084148039402 | preview only; no lambda_best joined |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | 175 | 1.189465058103487 | 1.1973093747264352 | 1.2180162482761048 | 1.2645383467539402 | 1.3105445705445202 | preview only; no lambda_best joined |
| CONTROL_CONSTANT_DISK_ENDPOINT | 175 | 1.1780972450961724 | 1.1780972450961724 | 1.1780972450961724 | 1.1780972450961724 | 1.1780972450961724 | preview only; no lambda_best joined |
| CONTROL_CONSTANT_SPHERE_ENDPOINT | 175 | 1.3333333333333333 | 1.3333333333333333 | 1.3333333333333333 | 1.3333333333333333 | 1.3333333333333333 | preview only; no lambda_best joined |
| CONTROL_CONSTANT_ENDPOINT_MIDPOINT | 175 | 1.255715289214753 | 1.255715289214753 | 1.255715289214753 | 1.255715289214753 | 1.255715289214753 | preview only; no lambda_best joined |
| S_type | 175 |  | 0.09090909090909094 | 0.36363636363636365 | 0.6509090909090905 |  | sphericity coordinate preview; not target validation |
| S_source | 175 |  | 0.14794091491025624 | 0.16152381085825748 | 0.42208969408126423 |  | sphericity coordinate preview; not target validation |


## Gate blueprint

| Gate | Task | Success criterion | Output |
|---|---|---|---|
| Track2R-02 | Freeze no-target lambda_pred readout selector. | Selector hash written before Track1 lambda_best is joined. | selector manifest + hash + formula cards |
| Track2R-03 | Generate sealed per-galaxy lambda_pred table using selector hash. | Prediction table hash written without lambda_best or Vobs/eVobs. | sealed lambda_pred table + SHA-256 |
| Track2R-04 | Validate sealed lambda_pred against Track1 lambda_best. | Report primary/secondary/control metrics without changing selector. | lambda validation report |
| Track2R-05 | Use sealed lambda_pred for rotation-curve validation. | Compare against constants and Track1 best-lambda ceiling. | rotation-curve validation report |


## Claim boundary

Track2R-02 freezes the law only. It does not claim the law works. Track2R-03 must seal the per-galaxy prediction table using this hash before Track2R-04 is allowed to join Track1 \(\lambda_{\rm best}\).
