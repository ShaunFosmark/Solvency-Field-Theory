# SFT Track2R-05: Rotation-Curve Validation

## Verdict

**TRACK2R05_DIRECTIONAL_LAMBDA_VALIDATION_DOES_NOT_IMPROVE_ROTATION_CURVES**

Interpretation:

Track2R-04 direction did not translate into better rotation-curve prediction versus constants

## Claim boundary

This gate propagates sealed Track2R lambda predictions into rotation-curve predictions. It does not alter selectors, does not refit lambda, does not change stellar mass-to-light constants, and uses Vobs/eVobs only as validation targets.

## Hash checks

| Check | Pass | Observed | Required |
|---|---|---|---|
| prediction_table_hash_matches_track2r03_hash_file | True | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b |
| prediction_table_hash_matches_expected | True | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b | f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b |
| all_rows_selector_hash_expected | True | 2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021 | 2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021 |
| track2r04_verdict_present | True | TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS | TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS |
| track2r04_verdict_expected | True | TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS | TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS |
| rotmod_ltg_dir_present | True | C:\Users\TaicHI\SPARC\Rotmod_LTG | Rotmod_LTG directory |


## No-retuning audit

| Item | Detected | Used | Status |
|---|---|---|---|
| Track2R-03 sealed prediction table | True | True | SEALED_INPUT_NOT_MODIFIED |
| Track1 lambda_best | True | True | FIT_CEILING_REFERENCE_ONLY |
| ROTMOD Vobs/eVobs | True | True | VALIDATION_TARGET_ONLY |
| RAR_All_Data | True | False | QUARANTINED |
| Old Track2 Gate14C | True | False | QUARANTINED |
| Old Track2 Gate14D | True | False | QUARANTINED |
| selector changed after Track2R-04 | False | False | NO |
| prediction table changed after Track2R-03 | False | False | NO |
| new lambda coefficient fitted | False | False | NO |
| M/L values changed | False | False | NO |


## Full-sample selector metrics

| Selector | Role | Rows | Galaxies | RMS V | MAE V | RMS log10V | mean chi2/row | Delta RMS vs best constant | Delta RMS vs ceiling |
|---|---|---|---|---|---|---|---|---|---|
| PRIMARY_TYPE_ENDPOINT_LINEAR | prediction | 3389 | 175 | 23.76099334263328 | 16.632232905215442 | 0.09812140233989979 | 56.243907883609424 | 0.08941740205024118 | 7.406505964686119 |
| SECONDARY_SOURCE_ROOT_SPHERICITY | prediction | 3389 | 175 | 23.94239728900231 | 16.72509484557882 | 0.09841688032289703 | 57.22955503225847 | 0.27082134841927186 | 7.587909911055149 |
| TERTIARY_EQUAL_TYPE_SOURCE_BLEND | prediction | 3389 | 175 | 23.84748200304066 | 16.6752961251452 | 0.09826093850074734 | 56.705632880651905 | 0.17590606245762075 | 7.492994625093498 |
| CONTROL_CONSTANT_DISK_ENDPOINT | control | 3389 | 175 | 24.46099247844102 | 16.999987666490945 | 0.09865979420165531 | 61.370279321218675 | 0.7894165378579814 | 8.106505100493859 |
| CONTROL_CONSTANT_SPHERE_ENDPOINT | control | 3389 | 175 | 23.67157594058304 | 16.633114308247727 | 0.09938997946491404 | 56.250519175499136 | 0.0 | 7.3170885626358775 |
| CONTROL_CONSTANT_ENDPOINT_MIDPOINT | control | 3389 | 175 | 24.009284556933526 | 16.764399398568646 | 0.09889536822423428 | 58.30762692812693 | 0.3377086163504863 | 7.654797178986364 |
| TRACK1_LAMBDA_BEST_FIT_CEILING | fit_ceiling_reference | 3389 | 175 | 16.354487377947162 | 10.22706850148256 | 0.07007523722688663 | 13.954708823858196 | -7.3170885626358775 | 0.0 |


## Best selectors by full-sample metric

| Metric | Best selector | Role | Value |
|---|---|---|---|
| rms_V_km_s | TRACK1_LAMBDA_BEST_FIT_CEILING | fit_ceiling_reference | 16.354487377947162 |
| mae_V_km_s | TRACK1_LAMBDA_BEST_FIT_CEILING | fit_ceiling_reference | 10.22706850148256 |
| chi2_mean_per_row | TRACK1_LAMBDA_BEST_FIT_CEILING | fit_ceiling_reference | 13.954708823858196 |
| rms_log10V | TRACK1_LAMBDA_BEST_FIT_CEILING | fit_ceiling_reference | 0.07007523722688663 |
| pearson_Vmodel_vs_Vobs | TRACK1_LAMBDA_BEST_FIT_CEILING | fit_ceiling_reference | 0.9829485272161532 |


## Primary selector robustness groups

| Group | Rows | Galaxies | RMS V | MAE V | RMS log10V | Delta RMS vs best constant |
|---|---|---|---|---|---|---|
| FULL | 3389 | 175 | 23.76099334263328 | 16.632232905215442 | 0.09812140233989979 | 0.08941740205024118 |
| INTERIOR_NON_EDGE | 2581 | 134 | 16.94448244818822 | 11.901842096857388 | 0.07453741168985166 | 0.030376542119451955 |
| EDGE_ONLY | 808 | 41 | 38.0907728193773 | 31.742553049240374 | 0.15044924675505864 | 0.44955792002112815 |
| Q1_ONLY | 2132 | 99 | 24.877736343988243 | 17.082374276426076 | 0.08087228843277207 | 0.16286839800198294 |
| Q1_Q2 | 3269 | 163 | 23.689587315918967 | 16.485196862016178 | 0.09071033269370911 | 0.12717520652892134 |
| TYPE_2_TO_10 | 3169 | 164 | 23.07223387327209 | 16.009441905816242 | 0.09675039206769244 | 0.08637785543000476 |
| TYPE_2_TO_10_INTERIOR | 2477 | 129 | 16.576286670064892 | 11.631879301155664 | 0.07410769752995547 | -0.012106201531608463 |
| LOW_ACCEL_LOGGBAR_LT_MINUS11 | 1261 | 130 | 15.236486732870976 | 11.25456861339819 | 0.11512996052485583 | -0.16575972904178116 |
| MID_ACCEL_1E11_TO_1E10 | 1344 | 126 | 24.68578445293483 | 17.438402983505252 | 0.08526273180883134 | 0.27024219281690876 |
| HIGH_ACCEL_GE_1E10 | 784 | 60 | 31.976128629606002 | 23.89976107710328 | 0.08852307319450049 | 0.11765025745142665 |
| NPOINTS_GE_MEDIAN | 1724 | 41 | 27.461923600726255 | 19.330341465682512 | 0.07882324559434413 | 0.2871717084696037 |
| NPOINTS_GE_MEDIAN_INTERIOR | 1256 | 32 | 17.901015581209432 | 12.458742176765018 | 0.0700119615316512 | -0.008771951140033707 |
| INNER_RADII_LE_MEDIAN | 1695 | 173 | 21.169949509694394 | 14.37082500484173 | 0.12347604596392389 | 0.03507020156181895 |
| OUTER_RADII_GT_MEDIAN | 1694 | 139 | 26.09734796430764 | 18.894975757124207 | 0.06329272112200886 | 0.1344708604376521 |


## Groups

| Group | Description | Rows | Galaxies |
|---|---|---|---|
| FULL | all valid rotation-curve rows | 3389 | 175 |
| INTERIOR_NON_EDGE | rows belonging to galaxies not edge-railed in Track1 lambda fit | 2581 | 134 |
| EDGE_ONLY | rows belonging to edge-railed Track1 lambda fits | 808 | 41 |
| Q1_ONLY | quality flag Q=1 galaxies | 2132 | 99 |
| Q1_Q2 | quality flag Q=1 or Q=2 galaxies | 3269 | 163 |
| TYPE_2_TO_10 | 2 <= Hubble Type <= 10 | 3169 | 164 |
| TYPE_2_TO_10_INTERIOR | 2 <= Hubble Type <= 10 and non-edge | 2477 | 129 |
| LOW_ACCEL_LOGGBAR_LT_MINUS11 | gbar < 1e-11 m/s^2 | 1261 | 130 |
| MID_ACCEL_1E11_TO_1E10 | 1e-11 <= gbar < 1e-10 m/s^2 | 1344 | 126 |
| HIGH_ACCEL_GE_1E10 | gbar >= 1e-10 m/s^2 | 784 | 60 |
| NPOINTS_GE_MEDIAN | n_points >= median (26.0) | 1724 | 41 |
| NPOINTS_GE_MEDIAN_INTERIOR | n_points >= median (26.0) and non-edge | 1256 | 32 |
| INNER_RADII_LE_MEDIAN | R <= median row radius (5.77 kpc) | 1695 | 173 |
| OUTER_RADII_GT_MEDIAN | R > median row radius (5.77 kpc) | 1694 | 139 |


## Parse/join issues

| Galaxy | Key | Reason | ROTMOD |
|---|---|---|---|


## Next step

If Track2R-05 improves over constants, the result can become the rotation-curve scaffold result for the morphology-readout branch. If it does not, Track2R-04 remains a directional lambda-structure result and Track2R-05 is archived as an amplitude-limited scaffold test.
