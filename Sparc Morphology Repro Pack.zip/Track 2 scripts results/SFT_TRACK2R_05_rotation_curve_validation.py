#!/usr/bin/env python3
"""
SFT Track2R-05:
Rotation-Curve Validation Using Sealed Lambda Predictions

Prerequisites
-------------
Track2R-03 sealed a per-galaxy lambda_pred table.
Track2R-04 validated sealed lambda_pred against Track1 lambda_best.

Track2R-05 asks the operational question:

    Do the sealed lambda_pred values improve rotation-curve prediction
    versus fixed lambda controls?

This gate is allowed to use Vobs/eVobs only as validation targets.
It is not allowed to alter lambda_pred, selector formulas, M/L values,
or any coefficient after seeing residuals.

Compared selectors
------------------
    primary        = PRIMARY_TYPE_ENDPOINT_LINEAR
    secondary      = SECONDARY_SOURCE_ROOT_SPHERICITY
    blend          = TERTIARY_EQUAL_TYPE_SOURCE_BLEND
    control_disk   = constant 3*pi/8
    control_sphere = constant 4/3
    control_mid    = endpoint midpoint
    ceiling_best   = Track1 lambda_best, fit ceiling/reference only

Weak-field law
--------------
    g_eff^2 = g_bar^2 + lambda * a_SFT * g_bar

where:
    a_SFT = c H0 / (2*pi)
    H0 = 67.74 km/s/Mpc
    ML_disk = 0.5
    ML_bulge = 0.7

ROTMOD columns assumed:
    R_kpc, Vobs_km_s, eVobs_km_s, Vgas_km_s, Vdisk_km_s, Vbul_km_s, ...

Outputs
-------
    track2r05_rotation_validation_rows.csv
    track2r05_per_galaxy_metrics.csv
    track2r05_selector_metrics.csv
    track2r05_selector_rankings.csv
    track2r05_hash_checks.csv
    track2r05_no_retuning_audit.csv
    track2r05_group_definitions.csv
    track2r05_schema_map.csv
    track2r05_verdict.csv
    TRACK2R_05_rotation_curve_validation_report.md
    plots/*.png if matplotlib is available

Run
---
    python SFT_TRACK2R_05_rotation_curve_validation.py --sparc-dir "C:\\Users\\TaicHI\\SPARC"

Claim boundary
--------------
This is validation only. Any selector revision after seeing this output is
a new predeclared fork.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
from pathlib import Path
from typing import Any

import numpy as np

try:
    import matplotlib.pyplot as plt
    MPL_OK = True
except Exception:
    MPL_OK = False
    plt = None

PROTOCOL_VERSION = "SFT_TRACK2R_05_ROTATION_CURVE_VALIDATION_v1"
OUT_DIR_NAME = "SFT_TRACK2R_05_ROTATION_CURVE_VALIDATION"

EXPECTED_SELECTOR_HASH = "2db85f1e2286e69a78290a060d7162b27c6238ae04318d4a0edfeeefa9c2c021"
EXPECTED_PREDICTION_TABLE_HASH = "f0f7b3568463bc88521341de4a7eca05953caa4edb8f56da7f484210b6cdb99b"
EXPECTED_TRACK2R04_VERDICT = "TRACK2R04_PRIMARY_SELECTOR_VALIDATED_DIRECTION_AND_BEATS_CONSTANT_CONTROLS"

C = 299_792_458.0
MPC = 3.0856775814913673e22
KPC = 3.0856775814913673e19
H0_KM_S_MPC = 67.74
H0_SI = H0_KM_S_MPC * 1000.0 / MPC
A_SFT = C * H0_SI / (2.0 * math.pi)

ML_DISK = 0.5
ML_BULGE = 0.7

LAMBDA_DISK = 3.0 * math.pi / 8.0
LAMBDA_SPHERE = 4.0 / 3.0
LAMBDA_MID = 0.5 * (LAMBDA_DISK + LAMBDA_SPHERE)

SELECTORS = [
    ("primary", "lambda_pred_primary_type_endpoint_linear", "PRIMARY_TYPE_ENDPOINT_LINEAR", "prediction"),
    ("secondary_source", "lambda_pred_secondary_source_root_sphericity", "SECONDARY_SOURCE_ROOT_SPHERICITY", "prediction"),
    ("tertiary_blend", "lambda_pred_tertiary_equal_type_source_blend", "TERTIARY_EQUAL_TYPE_SOURCE_BLEND", "prediction"),
    ("control_disk", "lambda_control_disk_endpoint", "CONTROL_CONSTANT_DISK_ENDPOINT", "control"),
    ("control_sphere", "lambda_control_sphere_endpoint", "CONTROL_CONSTANT_SPHERE_ENDPOINT", "control"),
    ("control_midpoint", "lambda_control_endpoint_midpoint", "CONTROL_CONSTANT_ENDPOINT_MIDPOINT", "control"),
    ("ceiling_best", "lambda_best", "TRACK1_LAMBDA_BEST_FIT_CEILING", "fit_ceiling_reference"),
]


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def safe_int(x: Any, default: int = -999) -> int:
    try:
        if x is None or x == "":
            return default
        return int(float(x))
    except Exception:
        return default


def boolish(x: Any) -> bool:
    s = str(x).strip().lower()
    if s in ("true", "t", "1", "yes", "y"):
        return True
    if s in ("false", "f", "0", "no", "n", "", "nan", "none"):
        return False
    try:
        return bool(float(s))
    except Exception:
        return bool(s)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def normalize_galaxy_name(x: Any) -> str:
    return str(x).strip().lower().replace(" ", "")


def iter_files(base: Path):
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if not d.upper().startswith("SFT_")]
        for fn in files:
            yield Path(root) / fn


def find_paths(sparc_dir: Path, pred_table_arg: str | None, track1_arg: str | None,
               rotmod_arg: str | None, track2r04_arg: str | None) -> dict:
    track2r03 = sparc_dir / "SFT_TRACK2R_03_SEALED_LAMBDA_PREDICTIONS"
    track2r04 = sparc_dir / "SFT_TRACK2R_04_LAMBDA_PREDICTION_VALIDATION"
    track1 = sparc_dir / "SFT_SPARC_TRACK1_LAMBDA_WIDE_OUTPUT"

    pred_table = Path(pred_table_arg).expanduser() if pred_table_arg else track2r03 / "track2r03_lambda_pred_table.csv"
    if not pred_table.is_absolute():
        pred_table = sparc_dir / pred_table

    track1_table = Path(track1_arg).expanduser() if track1_arg else track1 / "sparc_lambda_wide_per_galaxy.csv"
    if not track1_table.is_absolute():
        track1_table = sparc_dir / track1_table

    rotmod_dir = Path(rotmod_arg).expanduser() if rotmod_arg else sparc_dir / "Rotmod_LTG"
    if not rotmod_dir.is_absolute():
        rotmod_dir = sparc_dir / rotmod_dir

    track2r04_verdict = Path(track2r04_arg).expanduser() if track2r04_arg else track2r04 / "track2r04_verdict.csv"
    if not track2r04_verdict.is_absolute():
        track2r04_verdict = sparc_dir / track2r04_verdict

    return {
        "track2r03_dir": track2r03,
        "track2r03_pred_table": pred_table,
        "track2r03_pred_hash_file": track2r03 / "track2r03_lambda_pred_table_sha256.txt",
        "track2r04_dir": track2r04,
        "track2r04_verdict": track2r04_verdict,
        "track2r04_selector_metrics": track2r04 / "track2r04_selector_metrics.csv",
        "track1_per_galaxy": track1_table,
        "track1_verdict": track1 / "sparc_lambda_wide_verdict.csv",
        "rotmod_ltg_dir": rotmod_dir,
        "rar_forbidden": sparc_dir / "RAR_All_Data.txt",
        "old_track2_14c_forbidden": sparc_dir / "SFT_GRAV_TRAJ_14C_OUTPUT" / "gate14c_validation_joined_rows.csv",
        "old_track2_14d_forbidden": sparc_dir / "SFT_GRAV_TRAJ_14D_OUTPUT" / "gate14d_verdict.csv",
    }


def infer_col(columns: list[str], candidates: list[str], required: bool = True, label: str = "") -> str | None:
    lower = {c.lower(): c for c in columns}
    compact = {c.lower().replace("_", "").replace("-", "").replace(" ", ""): c for c in columns}

    for cand in candidates:
        if cand.lower() in lower:
            return lower[cand.lower()]
    for cand in candidates:
        key = cand.lower().replace("_", "").replace("-", "").replace(" ", "")
        if key in compact:
            return compact[key]
    for cand in candidates:
        key = cand.lower().replace("_", "").replace("-", "").replace(" ", "")
        for ck, orig in compact.items():
            if key and key in ck:
                return orig

    if required:
        raise RuntimeError(f"Required column not found for {label or candidates}; columns={columns}")
    return None


def galaxy_from_rotmod_name(path: Path) -> str:
    stem = path.stem
    stem = re.sub(r"(?i)[_\-]?rotmod.*$", "", stem)
    stem = re.sub(r"(?i)\.dat$", "", stem)
    return stem.strip("_- ")


def find_rotmod_files(rot_dir: Path) -> dict[str, Path]:
    out = {}
    for p in sorted(iter_files(rot_dir)):
        if not p.is_file():
            continue
        low = p.name.lower()
        if "rar" in low or "table" in low:
            continue
        gal = galaxy_from_rotmod_name(p)
        if gal:
            out[normalize_galaxy_name(gal)] = p
    return out


def read_lines(path: Path) -> list[str]:
    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            return path.read_text(encoding=enc, errors="replace").splitlines()
        except Exception:
            pass
    return path.read_text(errors="replace").splitlines()


def numeric_rows(path: Path) -> list[list[float]]:
    rows = []
    for line in read_lines(path):
        s = line.strip()
        if not s or s.startswith("#") or s.startswith(";") or s.startswith("|"):
            continue
        s = s.split("#", 1)[0].strip()
        vals = []
        ok = True
        for part in s.split():
            try:
                vals.append(float(part.replace("D", "E")))
            except Exception:
                ok = False
                break
        if ok and len(vals) >= 6:
            while len(vals) < 8:
                vals.append(float("nan"))
            rows.append(vals[:8])
    return rows


def sign_preserving_square(v: float) -> float:
    return v * abs(v)


def model_velocity_kms(radius_kpc: float, vgas: float, vdisk: float, vbul: float, lam: float) -> tuple[float, float, float]:
    """
    Return (V_model_km_s, gbar_SI, geff_SI).
    """
    if not all(math.isfinite(x) for x in [radius_kpc, vgas, vdisk, vbul, lam]):
        return float("nan"), float("nan"), float("nan")
    if radius_kpc <= 0:
        return float("nan"), float("nan"), float("nan")

    vbar2_kms2 = sign_preserving_square(vgas) + ML_DISK * vdisk * vdisk + ML_BULGE * vbul * vbul
    if not math.isfinite(vbar2_kms2) or vbar2_kms2 <= 0:
        return float("nan"), float("nan"), float("nan")

    r_m = radius_kpc * KPC
    gbar = vbar2_kms2 * 1.0e6 / r_m
    if not math.isfinite(gbar) or gbar <= 0:
        return float("nan"), float("nan"), float("nan")

    geff2 = gbar * gbar + lam * A_SFT * gbar
    if not math.isfinite(geff2) or geff2 < 0:
        return float("nan"), gbar, float("nan")
    geff = math.sqrt(geff2)
    vmodel = math.sqrt(geff * r_m) / 1000.0
    return vmodel, gbar, geff


def load_tables(paths: dict) -> tuple[list[dict], list[dict], dict]:
    missing = [p for p in [paths["track2r03_pred_table"], paths["track1_per_galaxy"], paths["rotmod_ltg_dir"]] if not p.exists()]
    if missing:
        print("ERROR: missing required files/directories:", file=sys.stderr)
        for p in missing:
            print(f"  {p}", file=sys.stderr)
        sys.exit(2)

    pred_rows = read_csv(paths["track2r03_pred_table"])
    target_rows = read_csv(paths["track1_per_galaxy"])

    pred_cols = list(pred_rows[0].keys())
    targ_cols = list(target_rows[0].keys())

    schema = {
        "pred_gal": infer_col(pred_cols, ["Galaxy", "galaxy", "Name"], True, "prediction Galaxy"),
        "target_gal": infer_col(targ_cols, ["Galaxy", "galaxy", "Name", "ID"], True, "Track1 Galaxy"),
        "lambda_best": infer_col(targ_cols, ["lambda_best", "lambdaBest", "best_lambda", "lambda_min", "lambda_hat", "lambda", "lam_best"], True, "Track1 lambda_best"),
        "edge_any": infer_col(targ_cols, ["edge_any", "edge_flag", "at_edge", "is_edge", "lambda_edge", "new_edge_any"], False),
        "edge_low": infer_col(targ_cols, ["edge_low", "low_edge", "at_low_edge", "lambda_edge_low", "new_edge_low"], False),
        "edge_high": infer_col(targ_cols, ["edge_high", "high_edge", "at_high_edge", "lambda_edge_high", "new_edge_high"], False),
        "q": infer_col(targ_cols, ["Q", "quality", "quality_flag"], False),
        "type": infer_col(targ_cols, ["Type", "T", "HubbleType", "hubble_type"], False),
        "n_points": infer_col(targ_cols, ["n_points", "npts", "N", "n_valid", "n_rows"], False),
        "inclination": infer_col(targ_cols, ["Inclination_deg", "Inc", "inclination", "i"], False),
    }
    return pred_rows, target_rows, schema


def join_prediction_and_target(pred_rows: list[dict], target_rows: list[dict], schema: dict) -> tuple[dict[str, dict], list[dict]]:
    targets = {}
    for tr in target_rows:
        k = normalize_galaxy_name(tr.get(schema["target_gal"], ""))
        if k:
            targets[k] = tr

    joined = {}
    issues = []
    for pr in pred_rows:
        gal = pr.get(schema["pred_gal"], "")
        k = normalize_galaxy_name(gal)
        tr = targets.get(k)
        if tr is None:
            issues.append({"Galaxy": gal, "Galaxy_key": k, "reason": "prediction row not found in Track1 target table"})
            continue

        lb = safe_float(tr.get(schema["lambda_best"]))
        if not math.isfinite(lb):
            issues.append({"Galaxy": gal, "Galaxy_key": k, "reason": "Track1 lambda_best not finite"})
            continue

        edge_low = boolish(tr.get(schema["edge_low"])) if schema.get("edge_low") else False
        edge_high = boolish(tr.get(schema["edge_high"])) if schema.get("edge_high") else False
        edge_any = boolish(tr.get(schema["edge_any"])) if schema.get("edge_any") else (edge_low or edge_high)

        T = safe_float(tr.get(schema["type"])) if schema.get("type") else safe_float(pr.get("Type"))
        Q = safe_int(tr.get(schema["q"])) if schema.get("q") else safe_int(pr.get("Q"))
        inc = safe_float(tr.get(schema["inclination"])) if schema.get("inclination") else safe_float(pr.get("Inclination_deg"))
        npts = safe_int(tr.get(schema["n_points"])) if schema.get("n_points") else -999

        row = {
            "Galaxy": gal,
            "Galaxy_key": k,
            "lambda_best": lb,
            "Type": T,
            "Q": Q,
            "Inclination_deg": inc,
            "n_points": npts,
            "edge_any": edge_any,
            "edge_low": edge_low,
            "edge_high": edge_high,
            "selector_hash_sha256": pr.get("selector_hash_sha256", ""),
            "track2r03_version": pr.get("track2r03_version", ""),
        }
        for short, col, label, role in SELECTORS:
            if short == "ceiling_best":
                row[f"{short}_lambda"] = lb
            else:
                row[f"{short}_lambda"] = safe_float(pr.get(col))
        joined[k] = row

    return joined, issues


def build_validation_rows(joined_gal: dict[str, dict], rot_files: dict[str, Path]) -> tuple[list[dict], list[dict]]:
    rows = []
    issues = []
    for key, galinfo in joined_gal.items():
        p = rot_files.get(key)
        if p is None:
            issues.append({"Galaxy": galinfo["Galaxy"], "Galaxy_key": key, "reason": "ROTMOD file missing"})
            continue

        nums = numeric_rows(p)
        if not nums:
            issues.append({"Galaxy": galinfo["Galaxy"], "Galaxy_key": key, "reason": "ROTMOD numeric rows empty", "rotmod_file": str(p)})
            continue

        for i, vals in enumerate(nums):
            R_kpc, Vobs, eVobs, Vgas, Vdisk, Vbul = vals[:6]
            base = {
                "Galaxy": galinfo["Galaxy"],
                "Galaxy_key": key,
                "rotmod_file": str(p),
                "row_index": i,
                "R_kpc": R_kpc,
                "Vobs_km_s": Vobs,
                "eVobs_km_s": eVobs,
                "Vgas_km_s": Vgas,
                "Vdisk_km_s": Vdisk,
                "Vbul_km_s": Vbul,
                "Type": galinfo["Type"],
                "Q": galinfo["Q"],
                "Inclination_deg": galinfo["Inclination_deg"],
                "n_points": galinfo["n_points"],
                "edge_any": galinfo["edge_any"],
                "edge_low": galinfo["edge_low"],
                "edge_high": galinfo["edge_high"],
            }

            # Use primary to compute trace gbar once. It is independent of lambda.
            _, gbar, _ = model_velocity_kms(R_kpc, Vgas, Vdisk, Vbul, 1.0)
            base["gbar_m_s2"] = gbar

            valid_any = False
            for short, col, label, role in SELECTORS:
                lam = safe_float(galinfo.get(f"{short}_lambda"))
                Vmodel, _, geff = model_velocity_kms(R_kpc, Vgas, Vdisk, Vbul, lam)
                base[f"{short}_lambda"] = lam
                base[f"{short}_Vmodel_km_s"] = Vmodel
                base[f"{short}_geff_m_s2"] = geff
                if all(math.isfinite(x) for x in [Vobs, Vmodel]):
                    delta = Vmodel - Vobs
                    base[f"{short}_delta_V_km_s"] = delta
                    base[f"{short}_abs_delta_V_km_s"] = abs(delta)
                    base[f"{short}_sq_delta_V"] = delta * delta
                    if math.isfinite(eVobs) and eVobs > 0:
                        base[f"{short}_chi2_contrib"] = (delta / eVobs) ** 2
                    else:
                        base[f"{short}_chi2_contrib"] = float("nan")
                    if Vobs > 0 and Vmodel > 0:
                        base[f"{short}_delta_log10V"] = math.log10(Vmodel) - math.log10(Vobs)
                    else:
                        base[f"{short}_delta_log10V"] = float("nan")
                    valid_any = True
                else:
                    base[f"{short}_delta_V_km_s"] = float("nan")
                    base[f"{short}_abs_delta_V_km_s"] = float("nan")
                    base[f"{short}_sq_delta_V"] = float("nan")
                    base[f"{short}_chi2_contrib"] = float("nan")
                    base[f"{short}_delta_log10V"] = float("nan")

            base["row_valid_any_selector"] = valid_any
            if valid_any:
                rows.append(base)

    return rows, issues


def group_masks(rows: list[dict]) -> list[tuple[str, str, np.ndarray]]:
    n = len(rows)
    T = np.array([safe_float(r.get("Type")) for r in rows])
    Q = np.array([safe_int(r.get("Q")) for r in rows])
    edge = np.array([boolish(r.get("edge_any")) for r in rows], dtype=bool)
    npts = np.array([safe_int(r.get("n_points")) for r in rows], dtype=float)
    gbar = np.array([safe_float(r.get("gbar_m_s2")) for r in rows], dtype=float)
    R = np.array([safe_float(r.get("R_kpc")) for r in rows], dtype=float)

    finite_npts = npts[np.isfinite(npts) & (npts > 0)]
    npts_median = float(np.median(finite_npts)) if finite_npts.size else float("nan")

    groups = [
        ("FULL", "all valid rotation-curve rows", np.ones(n, dtype=bool)),
        ("INTERIOR_NON_EDGE", "rows belonging to galaxies not edge-railed in Track1 lambda fit", ~edge),
        ("EDGE_ONLY", "rows belonging to edge-railed Track1 lambda fits", edge),
        ("Q1_ONLY", "quality flag Q=1 galaxies", Q == 1),
        ("Q1_Q2", "quality flag Q=1 or Q=2 galaxies", (Q == 1) | (Q == 2)),
        ("TYPE_2_TO_10", "2 <= Hubble Type <= 10", (T >= 2) & (T <= 10)),
        ("TYPE_2_TO_10_INTERIOR", "2 <= Hubble Type <= 10 and non-edge", (T >= 2) & (T <= 10) & (~edge)),
        ("LOW_ACCEL_LOGGBAR_LT_MINUS11", "gbar < 1e-11 m/s^2", np.isfinite(gbar) & (gbar < 1e-11)),
        ("MID_ACCEL_1E11_TO_1E10", "1e-11 <= gbar < 1e-10 m/s^2", np.isfinite(gbar) & (gbar >= 1e-11) & (gbar < 1e-10)),
        ("HIGH_ACCEL_GE_1E10", "gbar >= 1e-10 m/s^2", np.isfinite(gbar) & (gbar >= 1e-10)),
    ]
    if math.isfinite(npts_median):
        groups.append(("NPOINTS_GE_MEDIAN", f"n_points >= median ({npts_median})", npts >= npts_median))
        groups.append(("NPOINTS_GE_MEDIAN_INTERIOR", f"n_points >= median ({npts_median}) and non-edge", (npts >= npts_median) & (~edge)))
    if np.any(np.isfinite(R)):
        r_med = float(np.nanmedian(R[np.isfinite(R)]))
        groups.append(("INNER_RADII_LE_MEDIAN", f"R <= median row radius ({r_med:.3g} kpc)", np.isfinite(R) & (R <= r_med)))
        groups.append(("OUTER_RADII_GT_MEDIAN", f"R > median row radius ({r_med:.3g} kpc)", np.isfinite(R) & (R > r_med)))

    return groups


def compute_metrics(rows: list[dict]) -> tuple[list[dict], list[dict]]:
    metrics = []
    group_defs = []

    for group, desc, mask in group_masks(rows):
        idx = np.where(mask)[0]
        group_defs.append({
            "group": group,
            "description": desc,
            "row_N": int(len(idx)),
            "galaxy_N": int(len(set(rows[i]["Galaxy_key"] for i in idx))) if len(idx) else 0,
        })
        if len(idx) < 3:
            continue

        for short, col, label, role in SELECTORS:
            dv = np.array([safe_float(rows[i].get(f"{short}_delta_V_km_s")) for i in idx], dtype=float)
            chi = np.array([safe_float(rows[i].get(f"{short}_chi2_contrib")) for i in idx], dtype=float)
            dlog = np.array([safe_float(rows[i].get(f"{short}_delta_log10V")) for i in idx], dtype=float)
            Vobs = np.array([safe_float(rows[i].get("Vobs_km_s")) for i in idx], dtype=float)
            Vmodel = np.array([safe_float(rows[i].get(f"{short}_Vmodel_km_s")) for i in idx], dtype=float)

            m = np.isfinite(dv)
            if np.sum(m) < 3:
                metrics.append({"group": group, "selector": label, "selector_short": short, "role": role, "row_N": int(np.sum(m)), "status": "TOO_FEW_ROWS"})
                continue

            dvf = dv[m]
            vobsf = Vobs[m]
            vmodf = Vmodel[m]
            absd = np.abs(dvf)

            chim = np.isfinite(chi)
            logm = np.isfinite(dlog)

            # Correlation between predicted and observed velocities.
            if np.sum(np.isfinite(vobsf) & np.isfinite(vmodf)) >= 3 and np.std(vobsf) > 0 and np.std(vmodf) > 0:
                pear_v = float(np.corrcoef(vobsf, vmodf)[0, 1])
            else:
                pear_v = float("nan")

            metrics.append({
                "group": group,
                "selector": label,
                "selector_short": short,
                "role": role,
                "row_N": int(np.sum(m)),
                "galaxy_N": int(len(set(rows[i]["Galaxy_key"] for i in idx if math.isfinite(safe_float(rows[i].get(f"{short}_delta_V_km_s")))))),
                "rms_V_km_s": float(np.sqrt(np.mean(dvf ** 2))),
                "mae_V_km_s": float(np.mean(absd)),
                "median_abs_V_km_s": float(np.median(absd)),
                "bias_mean_V_km_s": float(np.mean(dvf)),
                "bias_median_V_km_s": float(np.median(dvf)),
                "deltaV_p16": float(np.percentile(dvf, 16)),
                "deltaV_p84": float(np.percentile(dvf, 84)),
                "chi2_mean_per_row": float(np.mean(chi[chim])) if np.any(chim) else float("nan"),
                "chi2_median_per_row": float(np.median(chi[chim])) if np.any(chim) else float("nan"),
                "rms_log10V": float(np.sqrt(np.mean(dlog[logm] ** 2))) if np.any(logm) else float("nan"),
                "median_abs_log10V": float(np.median(np.abs(dlog[logm]))) if np.any(logm) else float("nan"),
                "pearson_Vmodel_vs_Vobs": pear_v,
                "status": "OK",
            })

    # Add deltas vs ceiling_best and controls where available.
    by_key = {(r["group"], r["selector_short"]): r for r in metrics if r.get("status") == "OK"}
    for r in metrics:
        if r.get("status") != "OK":
            continue
        g = r["group"]
        ceiling = by_key.get((g, "ceiling_best"))
        best_control = min(
            [by_key.get((g, "control_disk")), by_key.get((g, "control_sphere")), by_key.get((g, "control_midpoint"))],
            key=lambda x: safe_float(x.get("rms_V_km_s"), float("inf")) if x else float("inf")
        )
        if ceiling:
            r["delta_rms_V_vs_ceiling_best"] = safe_float(r.get("rms_V_km_s")) - safe_float(ceiling.get("rms_V_km_s"))
            r["delta_rms_log10V_vs_ceiling_best"] = safe_float(r.get("rms_log10V")) - safe_float(ceiling.get("rms_log10V"))
        if best_control:
            r["best_constant_control_by_rms"] = best_control["selector"]
            r["delta_rms_V_vs_best_constant_control"] = safe_float(r.get("rms_V_km_s")) - safe_float(best_control.get("rms_V_km_s"))
            r["delta_rms_log10V_vs_best_constant_control"] = safe_float(r.get("rms_log10V")) - safe_float(best_control.get("rms_log10V"))

    return metrics, group_defs


def compute_per_galaxy(rows: list[dict]) -> list[dict]:
    groups = {}
    for r in rows:
        groups.setdefault(r["Galaxy_key"], []).append(r)

    out = []
    for key, gr in groups.items():
        base = {
            "Galaxy": gr[0]["Galaxy"],
            "Galaxy_key": key,
            "Type": gr[0]["Type"],
            "Q": gr[0]["Q"],
            "edge_any": gr[0]["edge_any"],
            "row_N": len(gr),
        }
        for short, col, label, role in SELECTORS:
            dv = np.array([safe_float(r.get(f"{short}_delta_V_km_s")) for r in gr], dtype=float)
            chi = np.array([safe_float(r.get(f"{short}_chi2_contrib")) for r in gr], dtype=float)
            dlog = np.array([safe_float(r.get(f"{short}_delta_log10V")) for r in gr], dtype=float)
            m = np.isfinite(dv)
            if np.sum(m) >= 1:
                base[f"{short}_rms_V_km_s"] = float(np.sqrt(np.mean(dv[m] ** 2)))
                base[f"{short}_mae_V_km_s"] = float(np.mean(np.abs(dv[m])))
                base[f"{short}_bias_mean_V_km_s"] = float(np.mean(dv[m]))
                base[f"{short}_valid_N"] = int(np.sum(m))
            else:
                base[f"{short}_rms_V_km_s"] = float("nan")
                base[f"{short}_mae_V_km_s"] = float("nan")
                base[f"{short}_bias_mean_V_km_s"] = float("nan")
                base[f"{short}_valid_N"] = 0
            cm = np.isfinite(chi)
            base[f"{short}_chi2_mean_per_row"] = float(np.mean(chi[cm])) if np.any(cm) else float("nan")
            lm = np.isfinite(dlog)
            base[f"{short}_rms_log10V"] = float(np.sqrt(np.mean(dlog[lm] ** 2))) if np.any(lm) else float("nan")

        # Helpful flags.
        best_pred = min(
            ["primary", "secondary_source", "tertiary_blend"],
            key=lambda s: safe_float(base.get(f"{s}_rms_V_km_s"), float("inf"))
        )
        best_control = min(
            ["control_disk", "control_sphere", "control_midpoint"],
            key=lambda s: safe_float(base.get(f"{s}_rms_V_km_s"), float("inf"))
        )
        base["best_prediction_selector_by_rms"] = best_pred
        base["best_constant_control_by_rms"] = best_control
        base["primary_beats_best_constant_control"] = safe_float(base.get("primary_rms_V_km_s"), float("inf")) < safe_float(base.get(f"{best_control}_rms_V_km_s"), float("inf"))
        out.append(base)

    return sorted(out, key=lambda r: str(r["Galaxy"]))


def selector_rankings(metrics: list[dict]) -> list[dict]:
    rankings = []
    groups = sorted(set(r["group"] for r in metrics if r.get("status") == "OK"))
    fields = [
        ("rms_V_km_s", "lower"),
        ("mae_V_km_s", "lower"),
        ("chi2_mean_per_row", "lower"),
        ("rms_log10V", "lower"),
        ("pearson_Vmodel_vs_Vobs", "higher"),
    ]
    for g in groups:
        gm = [r for r in metrics if r.get("group") == g and r.get("status") == "OK"]
        for field, direction in fields:
            if direction == "lower":
                ranked = sorted(gm, key=lambda r: safe_float(r.get(field), float("inf")))
            else:
                ranked = sorted(gm, key=lambda r: -safe_float(r.get(field), -float("inf")))
            for rank, r in enumerate(ranked, start=1):
                rankings.append({
                    "group": g,
                    "metric": field,
                    "rank": rank,
                    "selector": r["selector"],
                    "selector_short": r["selector_short"],
                    "role": r["role"],
                    "value": r.get(field),
                })
    return rankings


def hash_checks(paths: dict, pred_rows: list[dict], pred_hash: str) -> list[dict]:
    hash_file_val = ""
    if paths["track2r03_pred_hash_file"].exists():
        hash_file_val = paths["track2r03_pred_hash_file"].read_text(encoding="utf-8").strip()

    selector_values = sorted(set(str(r.get("selector_hash_sha256", "")) for r in pred_rows))
    track2r04_verdict = ""
    if paths["track2r04_verdict"].exists():
        try:
            rows = read_csv(paths["track2r04_verdict"])
            if rows:
                track2r04_verdict = rows[0].get("verdict", "")
        except Exception:
            track2r04_verdict = ""

    return [
        {
            "check": "prediction_table_hash_matches_track2r03_hash_file",
            "pass": pred_hash == hash_file_val,
            "observed": pred_hash,
            "required": hash_file_val,
        },
        {
            "check": "prediction_table_hash_matches_expected",
            "pass": pred_hash == EXPECTED_PREDICTION_TABLE_HASH,
            "observed": pred_hash,
            "required": EXPECTED_PREDICTION_TABLE_HASH,
        },
        {
            "check": "all_rows_selector_hash_expected",
            "pass": len(selector_values) == 1 and selector_values[0] == EXPECTED_SELECTOR_HASH,
            "observed": ";".join(selector_values),
            "required": EXPECTED_SELECTOR_HASH,
        },
        {
            "check": "track2r04_verdict_present",
            "pass": bool(track2r04_verdict),
            "observed": track2r04_verdict,
            "required": EXPECTED_TRACK2R04_VERDICT,
        },
        {
            "check": "track2r04_verdict_expected",
            "pass": track2r04_verdict == EXPECTED_TRACK2R04_VERDICT,
            "observed": track2r04_verdict,
            "required": EXPECTED_TRACK2R04_VERDICT,
        },
        {
            "check": "rotmod_ltg_dir_present",
            "pass": paths["rotmod_ltg_dir"].exists(),
            "observed": str(paths["rotmod_ltg_dir"]),
            "required": "Rotmod_LTG directory",
        },
    ]


def no_retuning_audit(paths: dict) -> list[dict]:
    return [
        {"item": "Track2R-03 sealed prediction table", "detected": paths["track2r03_pred_table"].exists(), "used": True, "status": "SEALED_INPUT_NOT_MODIFIED", "path": str(paths["track2r03_pred_table"])},
        {"item": "Track1 lambda_best", "detected": paths["track1_per_galaxy"].exists(), "used": True, "status": "FIT_CEILING_REFERENCE_ONLY", "path": str(paths["track1_per_galaxy"])},
        {"item": "ROTMOD Vobs/eVobs", "detected": paths["rotmod_ltg_dir"].exists(), "used": True, "status": "VALIDATION_TARGET_ONLY", "path": str(paths["rotmod_ltg_dir"])},
        {"item": "RAR_All_Data", "detected": paths["rar_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["rar_forbidden"])},
        {"item": "Old Track2 Gate14C", "detected": paths["old_track2_14c_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["old_track2_14c_forbidden"])},
        {"item": "Old Track2 Gate14D", "detected": paths["old_track2_14d_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["old_track2_14d_forbidden"])},
        {"item": "selector changed after Track2R-04", "detected": False, "used": False, "status": "NO"},
        {"item": "prediction table changed after Track2R-03", "detected": False, "used": False, "status": "NO"},
        {"item": "new lambda coefficient fitted", "detected": False, "used": False, "status": "NO"},
        {"item": "M/L values changed", "detected": False, "used": False, "status": "NO"},
    ]


def verdict_from_metrics(metrics: list[dict], hash_rows: list[dict], row_count: int, gal_count: int) -> dict:
    all_hash = all(str(r.get("pass")).lower() == "true" for r in hash_rows)

    def gm(group: str, short: str) -> dict | None:
        for r in metrics:
            if r.get("group") == group and r.get("selector_short") == short and r.get("status") == "OK":
                return r
        return None

    primary = gm("FULL", "primary")
    blend = gm("FULL", "tertiary_blend")
    source = gm("FULL", "secondary_source")
    c_disk = gm("FULL", "control_disk")
    c_sphere = gm("FULL", "control_sphere")
    c_mid = gm("FULL", "control_midpoint")
    ceiling = gm("FULL", "ceiling_best")

    controls = [r for r in [c_disk, c_sphere, c_mid] if r is not None]
    predictions = [r for r in [primary, source, blend] if r is not None]

    if not all_hash or primary is None or row_count == 0:
        verdict = "TRACK2R05_ROTATION_VALIDATION_REQUIRES_REVIEW"
        status = "hash failure, missing primary metrics, or no validation rows"
    else:
        best_control_rms = min(safe_float(r.get("rms_V_km_s"), float("inf")) for r in controls) if controls else float("inf")
        best_control_log = min(safe_float(r.get("rms_log10V"), float("inf")) for r in controls) if controls else float("inf")
        best_pred_rms = min(safe_float(r.get("rms_V_km_s"), float("inf")) for r in predictions) if predictions else float("inf")

        p_rms = safe_float(primary.get("rms_V_km_s"))
        p_log = safe_float(primary.get("rms_log10V"))
        p_chi = safe_float(primary.get("chi2_mean_per_row"))

        primary_beats_control_rms = p_rms < best_control_rms
        primary_beats_control_log = p_log < best_control_log
        any_pred_beats_control = best_pred_rms < best_control_rms

        if primary_beats_control_rms and primary_beats_control_log:
            verdict = "TRACK2R05_PRIMARY_ROTATION_SCAFFOLD_BEATS_CONSTANT_CONTROLS"
            status = "primary sealed morphology lambda improves rotation-curve residuals over fixed lambda controls"
        elif any_pred_beats_control:
            verdict = "TRACK2R05_SECONDARY_OR_BLEND_ROTATION_SCAFFOLD_BEATS_CONSTANT_CONTROLS"
            status = "a sealed morphology selector improves rotation-curve residuals over constants, but primary is not best"
        else:
            verdict = "TRACK2R05_DIRECTIONAL_LAMBDA_VALIDATION_DOES_NOT_IMPROVE_ROTATION_CURVES"
            status = "Track2R-04 direction did not translate into better rotation-curve prediction versus constants"

    return {
        "verdict": verdict,
        "claim_boundary": "Track2R-05 rotation validation only; sealed predictions unchanged; no refit, no retuning, no selector repair",
        "track2r05_version": PROTOCOL_VERSION,
        "validation_status_interpretation": status,
        "row_count": row_count,
        "galaxy_count": gal_count,
        "all_hash_checks_pass": all_hash,
        "primary_full_rms_V_km_s": primary.get("rms_V_km_s") if primary else "",
        "primary_full_mae_V_km_s": primary.get("mae_V_km_s") if primary else "",
        "primary_full_rms_log10V": primary.get("rms_log10V") if primary else "",
        "primary_full_chi2_mean_per_row": primary.get("chi2_mean_per_row") if primary else "",
        "secondary_full_rms_V_km_s": source.get("rms_V_km_s") if source else "",
        "blend_full_rms_V_km_s": blend.get("rms_V_km_s") if blend else "",
        "control_disk_full_rms_V_km_s": c_disk.get("rms_V_km_s") if c_disk else "",
        "control_sphere_full_rms_V_km_s": c_sphere.get("rms_V_km_s") if c_sphere else "",
        "control_midpoint_full_rms_V_km_s": c_mid.get("rms_V_km_s") if c_mid else "",
        "ceiling_best_full_rms_V_km_s": ceiling.get("rms_V_km_s") if ceiling else "",
        "primary_delta_rms_V_vs_best_constant_control": primary.get("delta_rms_V_vs_best_constant_control") if primary else "",
        "primary_delta_rms_V_vs_ceiling_best": primary.get("delta_rms_V_vs_ceiling_best") if primary else "",
        "selector_changed": False,
        "prediction_table_changed": False,
        "uses_Vobs_eVobs_for_validation_only": True,
        "uses_rotation_residuals_for_tuning": False,
        "uses_RAR_All_Data": False,
        "uses_old_DBE_track2": False,
        "main_result": (
            "Sealed morphology-lambda predictions were propagated into rotation-curve predictions and compared to fixed lambda controls and the Track1 best-lambda ceiling."
        ),
        "next_gate": "If useful, write Track2R summary/paper insert; if not, archive as internal scaffold test and fork only predeclared.",
    }


def make_plots(out: Path, rows: list[dict], per_gal: list[dict], metrics: list[dict]) -> None:
    if not MPL_OK or not rows:
        return
    plots = out / "plots"
    plots.mkdir(parents=True, exist_ok=True)

    # Plot 1: Vmodel vs Vobs for primary and ceiling.
    Vobs = np.array([safe_float(r.get("Vobs_km_s")) for r in rows])
    primary = np.array([safe_float(r.get("primary_Vmodel_km_s")) for r in rows])
    ceiling = np.array([safe_float(r.get("ceiling_best_Vmodel_km_s")) for r in rows])
    m = np.isfinite(Vobs) & np.isfinite(primary)
    if np.sum(m) > 0:
        fig = plt.figure(figsize=(6.5, 5.5))
        plt.scatter(Vobs[m], primary[m], s=8, alpha=0.5, label="primary")
        mc = np.isfinite(Vobs) & np.isfinite(ceiling)
        if np.sum(mc) > 0:
            plt.scatter(Vobs[mc], ceiling[mc], s=8, alpha=0.25, label="Track1 best ceiling")
        lo = float(np.nanmin(Vobs[m]))
        hi = float(np.nanmax([np.nanmax(Vobs[m]), np.nanmax(primary[m])]))
        plt.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1)
        plt.xlabel("Vobs [km/s]")
        plt.ylabel("Vmodel [km/s]")
        plt.title("Track2R-05 rotation validation")
        plt.legend()
        plt.tight_layout()
        fig.savefig(plots / "track2r05_vmodel_vs_vobs.png", dpi=180)
        plt.close(fig)

    # Plot 2: Full-sample RMS by selector.
    full = [r for r in metrics if r.get("group") == "FULL" and r.get("status") == "OK"]
    if full:
        labels = [r["selector_short"] for r in full]
        vals = [safe_float(r.get("rms_V_km_s")) for r in full]
        fig = plt.figure(figsize=(8, 5))
        plt.bar(labels, vals)
        plt.ylabel("RMS velocity residual [km/s]")
        plt.title("Track2R-05 full-sample RMS by selector")
        plt.xticks(rotation=30, ha="right")
        plt.tight_layout()
        fig.savefig(plots / "track2r05_full_rms_by_selector.png", dpi=180)
        plt.close(fig)

    # Plot 3: Per-galaxy primary vs controls.
    vals = []
    for g in per_gal:
        vals.append((
            str(g["Galaxy"]),
            safe_float(g.get("primary_rms_V_km_s")),
            min(safe_float(g.get("control_disk_rms_V_km_s"), float("inf")),
                safe_float(g.get("control_sphere_rms_V_km_s"), float("inf")),
                safe_float(g.get("control_midpoint_rms_V_km_s"), float("inf"))),
        ))
    vals = [(name, p, c) for name, p, c in vals if math.isfinite(p) and math.isfinite(c)]
    if vals:
        # Plot only sorted deltas to keep it readable.
        deltas = np.array([p - c for _, p, c in vals])
        order = np.argsort(deltas)
        fig = plt.figure(figsize=(8, 5))
        plt.plot(np.arange(len(deltas)), deltas[order], marker=".", linestyle="")
        plt.axhline(0.0, linestyle="--", linewidth=1)
        plt.xlabel("Galaxies sorted by primary minus best constant RMS")
        plt.ylabel("Delta RMS [km/s]")
        plt.title("Track2R-05 per-galaxy primary improvement vs best constant")
        plt.tight_layout()
        fig.savefig(plots / "track2r05_per_galaxy_primary_delta_vs_control.png", dpi=180)
        plt.close(fig)


def write_report(path: Path, verdict: dict, hash_rows: list[dict], audit: list[dict],
                 group_defs: list[dict], metrics: list[dict], rankings: list[dict],
                 parse_issues: list[dict]) -> None:
    def table(rows, cols, limit=None):
        rows2 = rows[:limit] if limit else rows
        lines = ["| " + " | ".join(label for _, label in cols) + " |\n",
                 "|" + "|".join("---" for _ in cols) + "|\n"]
        for r in rows2:
            lines.append("| " + " | ".join(str(r.get(k, "")) for k, _ in cols) + " |\n")
        if limit and len(rows) > limit:
            lines.append("| ... | ... | ... | ... |\n")
        return "".join(lines)

    full_metrics = [r for r in metrics if r.get("group") == "FULL" and r.get("status") == "OK"]
    rank_full = [r for r in rankings if r.get("group") == "FULL" and r.get("rank") == 1]
    primary_groups = [r for r in metrics if r.get("selector_short") == "primary" and r.get("status") == "OK"]

    text = f"""# SFT Track2R-05: Rotation-Curve Validation

## Verdict

**{verdict['verdict']}**

Interpretation:

{verdict['validation_status_interpretation']}

## Claim boundary

This gate propagates sealed Track2R lambda predictions into rotation-curve predictions. It does not alter selectors, does not refit lambda, does not change stellar mass-to-light constants, and uses Vobs/eVobs only as validation targets.

## Hash checks

{table(hash_rows, [('check','Check'),('pass','Pass'),('observed','Observed'),('required','Required')])}

## No-retuning audit

{table(audit, [('item','Item'),('detected','Detected'),('used','Used'),('status','Status')])}

## Full-sample selector metrics

{table(full_metrics, [('selector','Selector'),('role','Role'),('row_N','Rows'),('galaxy_N','Galaxies'),('rms_V_km_s','RMS V'),('mae_V_km_s','MAE V'),('rms_log10V','RMS log10V'),('chi2_mean_per_row','mean chi2/row'),('delta_rms_V_vs_best_constant_control','Delta RMS vs best constant'),('delta_rms_V_vs_ceiling_best','Delta RMS vs ceiling')])}

## Best selectors by full-sample metric

{table(rank_full, [('metric','Metric'),('selector','Best selector'),('role','Role'),('value','Value')])}

## Primary selector robustness groups

{table(primary_groups, [('group','Group'),('row_N','Rows'),('galaxy_N','Galaxies'),('rms_V_km_s','RMS V'),('mae_V_km_s','MAE V'),('rms_log10V','RMS log10V'),('delta_rms_V_vs_best_constant_control','Delta RMS vs best constant')])}

## Groups

{table(group_defs, [('group','Group'),('description','Description'),('row_N','Rows'),('galaxy_N','Galaxies')])}

## Parse/join issues

{table(parse_issues, [('Galaxy','Galaxy'),('Galaxy_key','Key'),('reason','Reason'),('rotmod_file','ROTMOD')], limit=25)}

## Next step

If Track2R-05 improves over constants, the result can become the rotation-curve scaffold result for the morphology-readout branch. If it does not, Track2R-04 remains a directional lambda-structure result and Track2R-05 is archived as an amplitude-limited scaffold test.
"""
    path.write_text(text, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sparc-dir", default=r"C:\Users\TaicHI\SPARC")
    ap.add_argument("--pred-table", default=None)
    ap.add_argument("--track1-table", default=None)
    ap.add_argument("--rotmod-dir", default=None)
    ap.add_argument("--track2r04-verdict", default=None)
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    sparc_dir = Path(args.sparc_dir).expanduser().resolve()
    out = Path(args.out_dir).expanduser().resolve() if args.out_dir else sparc_dir / OUT_DIR_NAME
    out.mkdir(parents=True, exist_ok=True)

    paths = find_paths(sparc_dir, args.pred_table, args.track1_table, args.rotmod_dir, args.track2r04_verdict)

    pred_rows, target_rows, schema = load_tables(paths)
    pred_hash = sha256_file(paths["track2r03_pred_table"])
    hash_rows = hash_checks(paths, pred_rows, pred_hash)
    audit = no_retuning_audit(paths)

    joined_gal, join_issues = join_prediction_and_target(pred_rows, target_rows, schema)
    rot_files = find_rotmod_files(paths["rotmod_ltg_dir"])
    validation_rows, parse_issues = build_validation_rows(joined_gal, rot_files)
    all_issues = join_issues + parse_issues

    metrics, group_defs = compute_metrics(validation_rows)
    per_gal = compute_per_galaxy(validation_rows)
    rankings = selector_rankings(metrics)
    verdict = verdict_from_metrics(metrics, hash_rows, len(validation_rows), len(per_gal))

    write_csv(out / "track2r05_rotation_validation_rows.csv", validation_rows)
    write_csv(out / "track2r05_per_galaxy_metrics.csv", per_gal)
    write_csv(out / "track2r05_selector_metrics.csv", metrics)
    write_csv(out / "track2r05_selector_rankings.csv", rankings)
    write_csv(out / "track2r05_hash_checks.csv", hash_rows)
    write_csv(out / "track2r05_no_retuning_audit.csv", audit)
    write_csv(out / "track2r05_group_definitions.csv", group_defs)
    write_csv(out / "track2r05_parse_join_issues.csv", all_issues)
    write_csv(out / "track2r05_schema_map.csv", [{"field": k, "column": v} for k, v in schema.items()])
    write_csv(out / "track2r05_verdict.csv", [verdict])

    manifest = {
        "track2r05_version": PROTOCOL_VERSION,
        "prediction_table_sha256": pred_hash,
        "expected_prediction_table_sha256": EXPECTED_PREDICTION_TABLE_HASH,
        "expected_selector_hash": EXPECTED_SELECTOR_HASH,
        "row_count": len(validation_rows),
        "galaxy_count": len(per_gal),
        "parse_join_issues": len(all_issues),
        "constants": {
            "H0_km_s_Mpc": H0_KM_S_MPC,
            "a_SFT_m_s2": A_SFT,
            "ML_disk": ML_DISK,
            "ML_bulge": ML_BULGE,
            "lambda_disk": LAMBDA_DISK,
            "lambda_sphere": LAMBDA_SPHERE,
            "lambda_midpoint": LAMBDA_MID,
        },
        "verdict": verdict,
        "claim_boundary": verdict["claim_boundary"],
    }
    (out / "track2r05_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    make_plots(out, validation_rows, per_gal, metrics)
    write_report(out / "TRACK2R_05_rotation_curve_validation_report.md", verdict, hash_rows, audit, group_defs, metrics, rankings, all_issues)

    print("\nSFT TRACK2R-05 ROTATION-CURVE VALIDATION")
    print("========================================")
    print("\nPurpose:")
    print("  Propagate sealed lambda_pred values into rotation-curve predictions.")
    print("  Vobs/eVobs are validation targets only. No refit, no retuning, no selector repair.")

    print("\nInputs:")
    print(f"  sealed prediction table: {paths['track2r03_pred_table']}")
    print(f"  Track1 lambda_best table: {paths['track1_per_galaxy']}")
    print(f"  Rotmod_LTG: {paths['rotmod_ltg_dir']}")

    print("\nConstants:")
    print(f"  H0_km_s_Mpc: {H0_KM_S_MPC}")
    print(f"  a_SFT_m_s2: {A_SFT:.12e}")
    print(f"  ML_disk: {ML_DISK}")
    print(f"  ML_bulge: {ML_BULGE}")
    print(f"  lambda_disk: {LAMBDA_DISK:.12f}")
    print(f"  lambda_sphere: {LAMBDA_SPHERE:.12f}")
    print(f"  lambda_midpoint: {LAMBDA_MID:.12f}")

    print("\nSchema map:")
    for k, v in schema.items():
        print(f"  {k}: {v}")

    print("\nHash checks:")
    for r in hash_rows:
        print(f"  {r['check']:52s} PASS={r['pass']}")

    print("\nNo-retuning audit:")
    for r in audit:
        print(f"  {r['item']:44s} detected={r['detected']} used={r['used']} status={r['status']}")

    print("\nJoin/parse summary:")
    print(f"  prediction galaxies: {len(pred_rows)}")
    print(f"  Track1 target galaxies: {len(target_rows)}")
    print(f"  joined galaxies: {len(joined_gal)}")
    print(f"  ROTMOD files found: {len(rot_files)}")
    print(f"  validation rows: {len(validation_rows)}")
    print(f"  per-galaxy metric rows: {len(per_gal)}")
    print(f"  parse/join issues: {len(all_issues)}")

    print("\nFull-sample rotation metrics:")
    for r in metrics:
        if r.get("group") == "FULL" and r.get("status") == "OK":
            print(
                f"  {r['selector']:42s} role={r['role']:22s} "
                f"rows={r['row_N']} rmsV={r.get('rms_V_km_s')} maeV={r.get('mae_V_km_s')} "
                f"rmsLogV={r.get('rms_log10V')} chi2row={r.get('chi2_mean_per_row')} "
                f"dRMS_vs_control={r.get('delta_rms_V_vs_best_constant_control','')} "
                f"dRMS_vs_ceiling={r.get('delta_rms_V_vs_ceiling_best','')}"
            )

    print("\nKey robustness groups for primary selector:")
    for r in metrics:
        if r.get("selector_short") == "primary" and r.get("group") in [
            "FULL", "INTERIOR_NON_EDGE", "Q1_ONLY", "Q1_Q2", "TYPE_2_TO_10", "TYPE_2_TO_10_INTERIOR", "NPOINTS_GE_MEDIAN"
        ] and r.get("status") == "OK":
            print(
                f"  {r['group']:26s} rows={r['row_N']} galaxies={r['galaxy_N']} "
                f"rmsV={r.get('rms_V_km_s')} maeV={r.get('mae_V_km_s')} "
                f"dRMS_vs_control={r.get('delta_rms_V_vs_best_constant_control','')}"
            )

    print("\nFull-sample rankings:")
    for r in rankings:
        if r.get("group") == "FULL" and r.get("rank") == 1:
            print(f"  best by {r['metric']}: {r['selector']} role={r['role']} value={r['value']}")

    print("\nVerdict:")
    for k, val in verdict.items():
        print(f"  {k}: {val}")

    print("\nFiles:")
    print(f"  output directory: {out}")
    print(f"  validation rows: {out/'track2r05_rotation_validation_rows.csv'}")
    print(f"  per-galaxy metrics: {out/'track2r05_per_galaxy_metrics.csv'}")
    print(f"  selector metrics: {out/'track2r05_selector_metrics.csv'}")
    print(f"  selector rankings: {out/'track2r05_selector_rankings.csv'}")
    print(f"  hash checks: {out/'track2r05_hash_checks.csv'}")
    print(f"  no-retuning audit: {out/'track2r05_no_retuning_audit.csv'}")
    print(f"  verdict: {out/'track2r05_verdict.csv'}")
    print(f"  report: {out/'TRACK2R_05_rotation_curve_validation_report.md'}")
    if MPL_OK:
        print(f"  plots: {out/'plots'}")


if __name__ == "__main__":
    main()
