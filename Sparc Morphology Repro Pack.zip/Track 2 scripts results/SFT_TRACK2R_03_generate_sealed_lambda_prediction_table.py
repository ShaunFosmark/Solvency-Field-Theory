#!/usr/bin/env python3
"""
SFT Track2R-03:
Generate and Seal No-Target Lambda Prediction Table

Prerequisites
-------------
Track2R-01 froze the allowed morphology/source feature table.
Track2R-02 froze the no-target lambda_pred selector.

This gate generates the sealed per-galaxy lambda_pred prediction table
using the Track2R-02 selector hash.

This gate does NOT join Track1 lambda_best.
This gate does NOT validate.
This gate does NOT read Vobs/eVobs, residuals, RAR_All_Data, old D/B/E,
dark halos, or Track1 fit outputs.

Outputs
-------
    track2r03_lambda_pred_table.csv
    track2r03_lambda_pred_table_sha256.txt
    track2r03_prediction_summary.csv
    track2r03_hash_checks.csv
    track2r03_no_target_audit.csv
    track2r03_gate_blueprint.csv
    track2r03_verdict.csv
    TRACK2R_03_sealed_lambda_prediction_report.md

Run
---
    python SFT_TRACK2R_03_generate_sealed_lambda_prediction_table.py --sparc-dir "C:\\Users\\TaicHI\\SPARC"

Next gate
---------
Track2R-04 may join the sealed prediction table to Track1 lambda_best for
validation, but may not alter any selector or prediction value.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np

PROTOCOL_VERSION = "SFT_TRACK2R_03_SEALED_LAMBDA_PREDICTION_TABLE_v1"
EXPECTED_SELECTOR_VERSION = "SFT_TRACK2R_02_LAMBDA_READOUT_SELECTOR_v1"
EXPECTED_PARENT_VERSION = "SFT_TRACK2R_01_MORPHOLOGY_READOUT_PROTOCOL_v1"

LAMBDA_DISK = 3.0 * math.pi / 8.0
LAMBDA_SPHERE = 4.0 / 3.0
DELTA_LAMBDA = LAMBDA_SPHERE - LAMBDA_DISK

OUT_DIR_NAME = "SFT_TRACK2R_03_SEALED_LAMBDA_PREDICTIONS"


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        x = float(x)
    except Exception:
        return float("nan")
    if not math.isfinite(x):
        return float("nan")
    return min(max(x, lo), hi)


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def safe_int(x: Any, default: int = -999) -> int:
    try:
        if x is None or x == "":
            return default
        return int(float(x))
    except Exception:
        return default


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def find_paths(sparc_dir: Path) -> dict:
    track2r01 = sparc_dir / "SFT_TRACK2R_01_MORPHOLOGY_READOUT_PROTOCOL"
    track2r02 = sparc_dir / "SFT_TRACK2R_02_LAMBDA_READOUT_SELECTOR"
    return {
        "track2r01_dir": track2r01,
        "track2r01_feature_table": track2r01 / "track2r01_allowed_feature_table.csv",
        "track2r01_protocol_hash": track2r01 / "track2r01_protocol_hash.txt",
        "track2r01_manifest": track2r01 / "track2r01_protocol_manifest.json",
        "track2r02_dir": track2r02,
        "track2r02_selector_hash": track2r02 / "track2r02_selector_hash.txt",
        "track2r02_selector_manifest": track2r02 / "track2r02_selector_manifest.json",
        "track2r02_verdict": track2r02 / "track2r02_verdict.csv",
        "track1_lambda_best_forbidden": sparc_dir / "SFT_SPARC_TRACK1_LAMBDA_WIDE_OUTPUT" / "sparc_lambda_wide_per_galaxy.csv",
        "track1b_forbidden": sparc_dir / "SFT_SPARC_TRACK1B_ROBUSTNESS_OUTPUT" / "track1b_verdict.csv",
        "rar_forbidden": sparc_dir / "RAR_All_Data.txt",
        "old_track2_14c_forbidden": sparc_dir / "SFT_GRAV_TRAJ_14C_OUTPUT" / "gate14c_validation_joined_rows.csv",
        "old_track2_14d_forbidden": sparc_dir / "SFT_GRAV_TRAJ_14D_OUTPUT" / "gate14d_verdict.csv",
    }


def load_prereqs(paths: dict) -> tuple[list[dict], dict, str, str, dict, str]:
    required = [
        paths["track2r01_feature_table"],
        paths["track2r01_protocol_hash"],
        paths["track2r01_manifest"],
        paths["track2r02_selector_hash"],
        paths["track2r02_selector_manifest"],
    ]
    missing = [p for p in required if not p.exists()]
    if missing:
        print("ERROR: missing prerequisite files:", file=sys.stderr)
        for p in missing:
            print(f"  {p}", file=sys.stderr)
        sys.exit(2)

    feature_rows = read_csv(paths["track2r01_feature_table"])
    parent_protocol_hash = paths["track2r01_protocol_hash"].read_text(encoding="utf-8").strip()
    parent_manifest = json.loads(paths["track2r01_manifest"].read_text(encoding="utf-8"))
    feature_table_hash = sha256_file(paths["track2r01_feature_table"])

    selector_hash = paths["track2r02_selector_hash"].read_text(encoding="utf-8").strip()
    selector_manifest = json.loads(paths["track2r02_selector_manifest"].read_text(encoding="utf-8"))

    return feature_rows, parent_manifest, parent_protocol_hash, feature_table_hash, selector_manifest, selector_hash


def recompute_selector_hash(selector_manifest: dict) -> str:
    # Track2R-02 computed hash before adding selector_hash_sha256 into the manifest.
    m = dict(selector_manifest)
    m.pop("selector_hash_sha256", None)
    return sha256_text(canonical_json(m))


def s_type(row: dict) -> float:
    T = safe_float(row.get("Type"))
    return clamp(1.0 - T / 11.0)


def s_source(row: dict) -> float:
    Bf = clamp(safe_float(row.get("source_bulge_fraction_proxy")))
    Bi = clamp(safe_float(row.get("source_bulge_inner_weight_proxy")))
    Df = clamp(safe_float(row.get("source_disk_fraction_proxy")))
    Gf = clamp(safe_float(row.get("source_gas_fraction_proxy")))
    vals = [math.sqrt(Bf), math.sqrt(Bi), 1.0 - math.sqrt(Df), 1.0 - math.sqrt(Gf)]
    vals = [v for v in vals if math.isfinite(v)]
    if not vals:
        return float("nan")
    return clamp(float(np.mean(vals)))


def lambda_from_s(S: float) -> float:
    S = clamp(S)
    return LAMBDA_DISK + DELTA_LAMBDA * S


def predict_row(row: dict, selector_hash: str, parent_feature_hash: str) -> dict:
    st = s_type(row)
    ss = s_source(row)
    sb = clamp(0.5 * st + 0.5 * ss) if math.isfinite(st) and math.isfinite(ss) else float("nan")

    lam_primary = lambda_from_s(st)
    lam_source = lambda_from_s(ss)
    lam_blend = lambda_from_s(sb)
    lam_disk = LAMBDA_DISK
    lam_sphere = LAMBDA_SPHERE
    lam_mid = 0.5 * (LAMBDA_DISK + LAMBDA_SPHERE)

    return {
        "Galaxy": row.get("Galaxy", ""),
        "Type": safe_int(row.get("Type")),
        "Q": safe_int(row.get("Q")),
        "Inclination_deg": safe_float(row.get("Inclination_deg")),
        "metadata_present": row.get("metadata_present", ""),
        "source_feature_pass": row.get("source_feature_pass", ""),

        "track2r03_version": PROTOCOL_VERSION,
        "selector_hash_sha256": selector_hash,
        "parent_feature_table_sha256": parent_feature_hash,

        # s-coordinates are no-target morphology/readout coordinates.
        "S_type": st,
        "S_source": ss,
        "S_blend": sb,

        # Sealed lambda predictions.
        "lambda_pred_primary_type_endpoint_linear": lam_primary,
        "lambda_pred_secondary_source_root_sphericity": lam_source,
        "lambda_pred_tertiary_equal_type_source_blend": lam_blend,

        # Locked controls.
        "lambda_control_disk_endpoint": lam_disk,
        "lambda_control_sphere_endpoint": lam_sphere,
        "lambda_control_endpoint_midpoint": lam_mid,

        # Feature trace values useful for future audit, still no targets.
        "source_bulge_fraction_proxy": safe_float(row.get("source_bulge_fraction_proxy")),
        "source_bulge_inner_weight_proxy": safe_float(row.get("source_bulge_inner_weight_proxy")),
        "source_disk_fraction_proxy": safe_float(row.get("source_disk_fraction_proxy")),
        "source_gas_fraction_proxy": safe_float(row.get("source_gas_fraction_proxy")),
        "type_late_coordinate_0_to_1": safe_float(row.get("type_late_coordinate_0_to_1")),
        "type_early_coordinate_0_to_1": safe_float(row.get("type_early_coordinate_0_to_1")),

        # Non-use flags.
        "uses_lambda_best": False,
        "uses_Vobs_or_eVobs": False,
        "uses_rotation_residuals": False,
        "uses_RAR_All_Data": False,
        "uses_old_DBE_track2": False,
        "validation_performed": False,
    }


def prediction_summary(pred_rows: list[dict]) -> list[dict]:
    cols = [
        "S_type",
        "S_source",
        "S_blend",
        "lambda_pred_primary_type_endpoint_linear",
        "lambda_pred_secondary_source_root_sphericity",
        "lambda_pred_tertiary_equal_type_source_blend",
        "lambda_control_disk_endpoint",
        "lambda_control_sphere_endpoint",
        "lambda_control_endpoint_midpoint",
    ]
    out = []
    for c in cols:
        vals = np.array([safe_float(r.get(c)) for r in pred_rows], dtype=float)
        vals = vals[np.isfinite(vals)]
        if vals.size:
            out.append({
                "field": c,
                "n_finite": int(vals.size),
                "min": float(np.min(vals)),
                "p16": float(np.percentile(vals, 16)),
                "median": float(np.median(vals)),
                "p84": float(np.percentile(vals, 84)),
                "max": float(np.max(vals)),
                "mean": float(np.mean(vals)),
                "std": float(np.std(vals, ddof=1)) if vals.size > 1 else 0.0,
            })
        else:
            out.append({"field": c, "n_finite": 0})

    # No-target monotonic sanity check: primary should be algebraically decreasing with Type.
    T = np.array([safe_float(r.get("Type")) for r in pred_rows], dtype=float)
    lam = np.array([safe_float(r.get("lambda_pred_primary_type_endpoint_linear")) for r in pred_rows], dtype=float)
    m = np.isfinite(T) & np.isfinite(lam)
    if np.sum(m) >= 3:
        # Spearman without scipy: correlation of average ranks.
        rt = rankdata(T[m])
        rl = rankdata(lam[m])
        rho = float(np.corrcoef(rt, rl)[0, 1])
        out.append({
            "field": "NO_TARGET_SANITY_SPEARMAN_Type_vs_primary_lambda",
            "n_finite": int(np.sum(m)),
            "min": "",
            "p16": "",
            "median": rho,
            "p84": "",
            "max": "",
            "mean": "",
            "std": "",
            "note": "Algebraic sanity check only, not validation against lambda_best.",
        })

    return out


def rankdata(x: np.ndarray) -> np.ndarray:
    # Average ranks, scipy-free.
    x = np.asarray(x)
    order = np.argsort(x, kind="mergesort")
    ranks = np.empty(len(x), dtype=float)
    i = 0
    while i < len(x):
        j = i + 1
        while j < len(x) and x[order[j]] == x[order[i]]:
            j += 1
        avg_rank = 0.5 * (i + j - 1) + 1.0
        ranks[order[i:j]] = avg_rank
        i = j
    return ranks


def hash_checks(parent_manifest: dict, parent_protocol_hash: str, feature_hash: str,
                selector_manifest: dict, selector_hash_file: str, prediction_hash: str,
                prediction_path: Path) -> list[dict]:
    selector_hash_from_manifest = selector_manifest.get("selector_hash_sha256", "")
    selector_hash_recomputed = recompute_selector_hash(selector_manifest)
    parent_hash_from_selector = selector_manifest.get("parent_protocol_hash_sha256", "")
    feature_hash_from_selector = selector_manifest.get("parent_feature_table_sha256", "")

    return [
        {
            "check": "parent_manifest_hash_matches_track2r01_file",
            "pass": parent_manifest.get("protocol_hash_sha256", "") == parent_protocol_hash,
            "observed": parent_manifest.get("protocol_hash_sha256", ""),
            "required": parent_protocol_hash,
        },
        {
            "check": "selector_parent_hash_matches_track2r01",
            "pass": parent_hash_from_selector == parent_protocol_hash,
            "observed": parent_hash_from_selector,
            "required": parent_protocol_hash,
        },
        {
            "check": "selector_feature_hash_matches_current_feature_table",
            "pass": feature_hash_from_selector == feature_hash,
            "observed": feature_hash_from_selector,
            "required": feature_hash,
        },
        {
            "check": "selector_hash_file_matches_manifest",
            "pass": selector_hash_file == selector_hash_from_manifest,
            "observed": selector_hash_file,
            "required": selector_hash_from_manifest,
        },
        {
            "check": "selector_hash_recomputed_matches_file",
            "pass": selector_hash_recomputed == selector_hash_file,
            "observed": selector_hash_recomputed,
            "required": selector_hash_file,
        },
        {
            "check": "selector_version_expected",
            "pass": selector_manifest.get("selector_version", "") == EXPECTED_SELECTOR_VERSION,
            "observed": selector_manifest.get("selector_version", ""),
            "required": EXPECTED_SELECTOR_VERSION,
        },
        {
            "check": "prediction_table_sha256_written",
            "pass": bool(prediction_hash) and prediction_path.exists(),
            "observed": prediction_hash,
            "required": str(prediction_path),
        },
    ]


def no_target_audit(paths: dict) -> list[dict]:
    return [
        {"item": "Track2R-01 allowed feature table", "detected": paths["track2r01_feature_table"].exists(), "used": True, "status": "ALLOWED_PARENT_INPUT", "path": str(paths["track2r01_feature_table"])},
        {"item": "Track2R-02 selector manifest", "detected": paths["track2r02_selector_manifest"].exists(), "used": True, "status": "ALLOWED_SELECTOR_INPUT", "path": str(paths["track2r02_selector_manifest"])},
        {"item": "Track2R-02 selector hash", "detected": paths["track2r02_selector_hash"].exists(), "used": True, "status": "ALLOWED_SELECTOR_INPUT", "path": str(paths["track2r02_selector_hash"])},
        {"item": "Track1 lambda_best", "detected": paths["track1_lambda_best_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["track1_lambda_best_forbidden"])},
        {"item": "Track1B robustness", "detected": paths["track1b_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["track1b_forbidden"])},
        {"item": "RAR_All_Data", "detected": paths["rar_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["rar_forbidden"])},
        {"item": "Old Track2 Gate14C", "detected": paths["old_track2_14c_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["old_track2_14c_forbidden"])},
        {"item": "Old Track2 Gate14D", "detected": paths["old_track2_14d_forbidden"].exists(), "used": False, "status": "QUARANTINED", "path": str(paths["old_track2_14d_forbidden"])},
        {"item": "Track1 lambda_best join", "detected": False, "used": False, "status": "NOT_THIS_GATE", "path": ""},
        {"item": "validation metrics", "detected": False, "used": False, "status": "NOT_THIS_GATE", "path": ""},
    ]


def gate_blueprint_rows() -> list[dict]:
    return [
        {
            "gate": "Track2R-03",
            "status_after_this_script": "COMPLETE_IF_HASHED",
            "task": "Generate sealed per-galaxy lambda_pred table using Track2R-02 selector hash.",
            "success_criterion": "Prediction table SHA-256 written before any target join.",
            "output": "track2r03_lambda_pred_table.csv + sha256",
        },
        {
            "gate": "Track2R-04",
            "status_after_this_script": "NEXT",
            "task": "Validate sealed lambda_pred against Track1 lambda_best.",
            "success_criterion": "Report primary, secondary, and controls without changing predictions.",
            "output": "lambda prediction validation report",
        },
        {
            "gate": "Track2R-05",
            "status_after_this_script": "PENDING",
            "task": "Use sealed lambda_pred to predict rotation curves.",
            "success_criterion": "Compare with controls and Track1 best-lambda ceiling.",
            "output": "rotation-curve validation report",
        },
    ]


def write_report(path: Path, verdict: dict, hash_rows: list[dict], audit: list[dict],
                 summary: list[dict], blueprint: list[dict]) -> None:
    def table(rows, cols):
        lines = ["| " + " | ".join(label for _, label in cols) + " |\n",
                 "|" + "|".join("---" for _ in cols) + "|\n"]
        for r in rows:
            lines.append("| " + " | ".join(str(r.get(k, "")) for k, _ in cols) + " |\n")
        return "".join(lines)

    text = f"""# SFT Track2R-03: Sealed Lambda Prediction Table

## Verdict

**{verdict['verdict']}**

Prediction table hash:

`{verdict['prediction_table_sha256']}`

Selector hash:

`{verdict['selector_hash_sha256']}`

## Claim boundary

Track2R-03 generates and seals the prediction table only. It does not join Track1 \\(\\lambda_{{\\rm best}}\\), does not validate the predictions, and does not read observed-velocity residuals.

## Hash checks

{table(hash_rows, [('check','Check'),('pass','Pass'),('observed','Observed'),('required','Required')])}

## No-target audit

{table(audit, [('item','Item'),('detected','Detected'),('used','Used'),('status','Status')])}

## Prediction summary

{table(summary, [('field','Field'),('n_finite','N'),('min','Min'),('p16','p16'),('median','Median'),('p84','p84'),('max','Max'),('mean','Mean'),('std','Std'),('note','Note')])}

## Gate blueprint

{table(blueprint, [('gate','Gate'),('task','Task'),('success_criterion','Success criterion'),('output','Output')])}

## Next step

Track2R-04 may now join this sealed prediction table to Track1 \\(\\lambda_{{\\rm best}}\\) for validation. Any selector change after this point is a new fork.
"""
    path.write_text(text, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sparc-dir", default=r"C:\Users\TaicHI\SPARC")
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    sparc_dir = Path(args.sparc_dir).expanduser().resolve()
    out = Path(args.out_dir).expanduser().resolve() if args.out_dir else sparc_dir / OUT_DIR_NAME
    out.mkdir(parents=True, exist_ok=True)

    paths = find_paths(sparc_dir)
    feature_rows, parent_manifest, parent_protocol_hash, feature_hash, selector_manifest, selector_hash_file = load_prereqs(paths)

    pred_rows = [predict_row(r, selector_hash_file, feature_hash) for r in feature_rows]
    pred_rows = sorted(pred_rows, key=lambda r: str(r["Galaxy"]))

    pred_path = out / "track2r03_lambda_pred_table.csv"
    write_csv(pred_path, pred_rows)
    pred_hash = sha256_file(pred_path)
    (out / "track2r03_lambda_pred_table_sha256.txt").write_text(pred_hash + "\n", encoding="utf-8")

    summary = prediction_summary(pred_rows)
    hash_rows = hash_checks(parent_manifest, parent_protocol_hash, feature_hash, selector_manifest, selector_hash_file, pred_hash, pred_path)
    audit = no_target_audit(paths)
    blueprint = gate_blueprint_rows()

    all_hash_pass = all(str(r.get("pass")).lower() == "true" for r in hash_rows)
    forbidden_used = any(str(r["used"]).lower() == "true" and "QUARANTINED" in str(r["status"]).upper() for r in audit)
    n_primary_finite = sum(math.isfinite(safe_float(r.get("lambda_pred_primary_type_endpoint_linear"))) for r in pred_rows)
    endpoint_ok = all(
        LAMBDA_DISK - 1e-12 <= safe_float(r.get("lambda_pred_primary_type_endpoint_linear")) <= LAMBDA_SPHERE + 1e-12
        for r in pred_rows
    )

    if all_hash_pass and not forbidden_used and n_primary_finite == len(pred_rows) and endpoint_ok:
        v = "TRACK2R03_SEALED_LAMBDA_PREDICTION_TABLE_READY_FOR_TRACK2R04"
    else:
        v = "TRACK2R03_SEALED_TABLE_REQUIRES_REVIEW"

    verdict = {
        "verdict": v,
        "claim_boundary": "Track2R-03 sealed prediction table only; no lambda_best join, no validation, no refit, no retuning",
        "track2r03_version": PROTOCOL_VERSION,
        "selector_hash_sha256": selector_hash_file,
        "parent_protocol_hash_sha256": parent_protocol_hash,
        "parent_feature_table_sha256": feature_hash,
        "prediction_table_sha256": pred_hash,
        "prediction_rows": len(pred_rows),
        "primary_finite_rows": n_primary_finite,
        "endpoint_bounds_ok": endpoint_ok,
        "all_hash_checks_pass": all_hash_pass,
        "uses_lambda_best": False,
        "uses_Vobs_or_eVobs": False,
        "uses_rotation_residuals": False,
        "uses_RAR_All_Data": False,
        "uses_old_DBE_track2": False,
        "validation_performed": False,
        "main_result": (
            "A per-galaxy lambda_pred table has been generated and sealed from the Track2R-02 selector. "
            "Track2R-04 may validate it against Track1 lambda_best without altering predictions."
        ),
        "next_gate": "Track2R-04: join sealed lambda_pred table to Track1 lambda_best and validate.",
    }

    write_csv(out / "track2r03_prediction_summary.csv", summary)
    write_csv(out / "track2r03_hash_checks.csv", hash_rows)
    write_csv(out / "track2r03_no_target_audit.csv", audit)
    write_csv(out / "track2r03_gate_blueprint.csv", blueprint)
    write_csv(out / "track2r03_verdict.csv", [verdict])
    write_report(out / "TRACK2R_03_sealed_lambda_prediction_report.md", verdict, hash_rows, audit, summary, blueprint)

    manifest = {
        "track2r03_version": PROTOCOL_VERSION,
        "selector_hash_sha256": selector_hash_file,
        "parent_protocol_hash_sha256": parent_protocol_hash,
        "parent_feature_table_sha256": feature_hash,
        "prediction_table_sha256": pred_hash,
        "prediction_rows": len(pred_rows),
        "output_files": [
            "track2r03_lambda_pred_table.csv",
            "track2r03_lambda_pred_table_sha256.txt",
            "track2r03_prediction_summary.csv",
            "track2r03_hash_checks.csv",
            "track2r03_no_target_audit.csv",
            "track2r03_gate_blueprint.csv",
            "track2r03_verdict.csv",
            "TRACK2R_03_sealed_lambda_prediction_report.md",
        ],
        "claim_boundary": verdict["claim_boundary"],
    }
    (out / "track2r03_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("\nSFT TRACK2R-03 SEALED LAMBDA PREDICTION TABLE")
    print("=============================================")
    print("\nPurpose:")
    print("  Generate and seal per-galaxy lambda_pred table from Track2R-02 selector.")
    print("  No lambda_best join, no validation, no residuals, no RAR, no old D/B/E.")

    print("\nLockbox hashes:")
    print(f"  parent protocol hash: {parent_protocol_hash}")
    print(f"  parent feature table hash: {feature_hash}")
    print(f"  selector hash: {selector_hash_file}")
    print(f"  prediction table hash: {pred_hash}")

    print("\nHash checks:")
    for r in hash_rows:
        print(f"  {r['check']:52s} PASS={r['pass']}")

    print("\nNo-target audit:")
    for r in audit:
        print(f"  {r['item']:38s} detected={r['detected']} used={r['used']} status={r['status']}")

    print("\nPrediction summary:")
    for r in summary:
        print(
            f"  {r['field']:52s} N={r.get('n_finite','')} "
            f"median={r.get('median','')} p16={r.get('p16','')} p84={r.get('p84','')}"
        )

    print("\nGate blueprint:")
    for r in blueprint:
        print(f"  {r['gate']:10s} {r['status_after_this_script']:22s} {r['task']}")

    print("\nVerdict:")
    for k, val in verdict.items():
        print(f"  {k}: {val}")

    print("\nFiles:")
    print(f"  output directory: {out}")
    print(f"  sealed prediction table: {pred_path}")
    print(f"  prediction table sha256: {out/'track2r03_lambda_pred_table_sha256.txt'}")
    print(f"  prediction summary: {out/'track2r03_prediction_summary.csv'}")
    print(f"  hash checks: {out/'track2r03_hash_checks.csv'}")
    print(f"  no-target audit: {out/'track2r03_no_target_audit.csv'}")
    print(f"  verdict: {out/'track2r03_verdict.csv'}")
    print(f"  report: {out/'TRACK2R_03_sealed_lambda_prediction_report.md'}")


if __name__ == "__main__":
    main()
