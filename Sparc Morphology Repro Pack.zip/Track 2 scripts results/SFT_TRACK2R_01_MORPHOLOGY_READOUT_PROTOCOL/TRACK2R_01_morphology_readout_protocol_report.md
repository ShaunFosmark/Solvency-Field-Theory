# SFT Track2R-01: Morphology-Readout Protocol Restart

## Verdict

**TRACK2R01_MORPHOLOGY_READOUT_PROTOCOL_FROZEN_READY_FOR_TRACK2R02**

Protocol hash:

`917160406652d7aeee603833eefdbd653ebb11d41eef0f7cdd5113a3cc806ca3`

## What changed

The old Track 2 SPARC-internal `D/B/E` environment implementation is archived as an internal note only. Track2R restarts from the structure supported by Track 1:

\[
g_{\rm eff}^2 = g_{\rm bar}^2 + \lambda_{\rm morph} a_{\rm SFT} g_{\rm bar}.
\]

Track2R-01 does not predict \(\lambda\). It freezes the allowed metadata/source feature table and the no-target firewall for later prediction.

## Allowed inputs

| Input | Purpose | Notes |
|---|---|---|
| Table1 Galaxy metadata | morphology/source descriptors | Type, distance, inclination, luminosity, size, MHI, Q |
| ROTMOD radius column | source geometry coordinates | Radius only; not target residual |
| ROTMOD Vgas column | gas source proxy | source component only |
| ROTMOD Vdisk column | disk source proxy | source component only |
| ROTMOD Vbul column | bulge/source sphericity proxy | source component only |
| fixed Upsilon_disk=0.5 | source proxy construction | inherited from Track1 fixed inputs |
| fixed Upsilon_bulge=0.7 | source proxy construction | inherited from Track1 fixed inputs |
| lambda_disk=3pi/8 | theoretical endpoint | not fit |
| lambda_sphere=4/3 | theoretical endpoint | not fit |
| inclination | control variable | may be used for null/control, not primary morphology target unless predeclared |
| quality Q | sample/control variable | not for tuning coefficients |


## Forbidden inputs

| Input | Forbidden for | Notes |
|---|---|---|
| Track1 lambda_best | feature construction and law selection | may only be joined in Track2R-04 validation after lambda_pred table is sealed |
| Track1 chi2(lambda) | law selection | would leak target |
| Vobs/eVobs | Track2R-01 feature construction | needed only later for final rotation-curve validation |
| rotation-curve residuals | all predictor design | no residual tuning |
| RAR_All_Data | Track2R morphology readout | not morphology-lambda target |
| dark halo parameters | all gates | not used |
| old Track2 E, D, or B | new Track2R predictor | old branch archived internal only |
| Gate14C/14D damage diagnostics | parameter repair | used only as motivation to restart, not as predictor input |
| per-galaxy tuned exponent/offset | all gates | would defeat prediction |


## No-target audit

| Item | Detected | Used | Status |
|---|---|---|---|
| Track1 lambda_best file detected | True | False | QUARANTINED |
| Track1B robustness file detected | True | False | QUARANTINED |
| RAR_All_Data detected | True | False | QUARANTINED |
| Old Track2 Gate14C joined rows detected | True | False | QUARANTINED |
| Old Track2 Gate14D verdict detected | True | False | QUARANTINED |
| Vobs/eVobs columns in ROTMOD | True | False | NOT_READ_FOR_FEATURES |
| lambda prediction generated | False | False | NOT_THIS_GATE |


## Gate blueprint

| Gate | Task | Success criterion | Output |
|---|---|---|---|
| Track2R-01 | Freeze clean morphology-readout protocol boundary and allowed feature table. | Feature table built without lambda_best, residuals, RAR, dark halos, or old D/B/E. | protocol hash + allowed feature table |
| Track2R-02 | Choose/freeze lambda_pred readout law from allowed morphology/source variables only. | A law is selected before joining Track1 lambda_best and with no residual tuning. | readout law manifest and hash |
| Track2R-03 | Generate sealed lambda_pred table for every galaxy. | Prediction table hash written before target join. | lambda_pred table + SHA-256 |
| Track2R-04 | Validate sealed lambda_pred against Track1 lambda_best. | Report rank, RMS, endpoint behavior, and no-retuning audit. | validation report |
| Track2R-05 | Use sealed lambda_pred in rotation-curve prediction. | Compare to fixed lambda=1, fixed disk endpoint, fixed sphere endpoint, and Track1 best-lambda ceiling. | rotation-curve validation |


## Feature summary

| Feature | N finite | Median | p16 | p84 | Min | Max |
|---|---|---|---|---|---|---|
| Type | 175 | 7.0 | 3.84 | 10.0 | 0.0 | 11.0 |
| type_late_coordinate_0_to_1 | 175 | 0.6363636363636364 | 0.34909090909090906 | 0.9090909090909091 | 0.0 | 1.0 |
| type_early_coordinate_0_to_1 | 175 | 0.36363636363636365 | 0.09090909090909094 | 0.6509090909090905 | 0.0 | 1.0 |
| Inclination_deg | 175 | 60.0 | 39.84 | 79.16 | 15.0 | 90.0 |
| L36_1e9Lsun | 175 | 3.889 | 0.33424000000000004 | 111.01028 | 0.012 | 489.955 |
| MHI_1e9Msun | 175 | 1.701 | 0.31968 | 8.315119999999999 | 0.012 | 40.075 |
| gas_to_light_proxy_MHI_over_L36 | 175 | 0.32943645083932854 | 0.061873067298161964 | 1.2782134847016473 | 0.0059188951395739466 | 6.5 |
| source_bulge_fraction_proxy | 175 | 0.0 | 0.0 | 0.12654446106694467 | 0.0 | 0.8640277951567988 |
| source_disk_fraction_proxy | 175 | 0.6359113136284323 | 0.3300109101663771 | 0.8721541033704302 | 0.059527212960649736 | 0.9874713960558524 |
| source_gas_fraction_proxy | 175 | 0.2632720839552804 | 0.04343116750841623 | 0.5883337069129349 | 0.0029401664734335607 | 0.9404727870393501 |
| source_bulge_inner_weight_proxy | 175 | 0.0 | 0.0 | 0.1782543928651533 | 0.0 | 0.9550562738245482 |
| source_gas_outerness_proxy | 175 | 1.2445348516738768 | 1.088977120701711 | 1.7572874215144934 | 0.9581730904958669 | 4.893727472303819 |
| source_half_power_radius_kpc | 175 | 5.92 | 2.7567999999999997 | 11.382399999999999 | 0.51 | 31.22 |


## Claim boundary

This protocol supports a later test of whether \(\lambda_{\rm morph}\) can be predicted from morphology/source-readout variables. It does not support a claim that the predictor has already succeeded, and it does not revive the old SPARC-internal environment channel.

## Next step

Track2R-02 should choose a no-target \(\lambda_{\rm pred}\) readout law from these allowed features only, then hash that law before any join to Track 1 \(\lambda_{\rm best}\).
