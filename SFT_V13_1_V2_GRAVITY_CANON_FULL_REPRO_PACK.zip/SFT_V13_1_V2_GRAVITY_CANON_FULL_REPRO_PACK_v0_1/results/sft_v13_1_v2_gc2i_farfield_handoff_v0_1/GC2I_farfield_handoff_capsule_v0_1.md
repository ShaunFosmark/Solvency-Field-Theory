# SFT V13.1-V2 GC-2I — Far-Field Handoff, a_S, E, and λ(z) Tension v0.1

## Part VI title

**The Far-Field Handoff: cosmological write scale, participation, and the high-z tension**

## Status

```text
GC-2I_DRAFT_PARTIAL_ARCHITECTURE_PASS_TENSION_REGISTERED_E_PROTOCOL_OPEN
```

GC-2H finished the normalization boundary. GC-2I now moves to the galaxy/cosmology handoff.

The charter requires this section to carry:

```text
a_S = cH/2π
the V12.3 frozen E protocol
mandatory reconciliation with Fork08 participation
```

This gate does not validate the far-field law. It protects the local metric sector, sharpens the H(z) tension, and freezes the reconciliation problem.

---

# 1. ATTACK

The attack:

> If a_S = cH/2π, then at high redshift H(z) is larger. That seems to predict stronger weak-field boosts in high-z galaxies. But Track2 and the SPARC participation operator predict weaker boosts in dynamically young/unsettled high-z systems. The theory may be fighting itself.

A second attack:

> V12.3 had an environment factor E = D·B. Fork08/SPARC has a participation operator p_j/Pcoh/λ_eff. If those two far-field modifiers do not know each other, the program contains two disconnected correction systems.

Both attacks are valid.

---

# 2. STAKES

If GC-2I fails:

```text
- SPARC and DESI are standing on different gravity programs;
- a_S ∝ H(z) contradicts λ(z) suppression;
- V12.3 E becomes an unmerged historical artifact;
- far-field modifiers risk leaking into local γ=1 metric closure.
```

If GC-2I passes honestly:

```text
- local metric closure remains protected;
- a_S is identified as background scale, not boost participation;
- λ_eff/Pcoh is identified as banked local accessibility;
- the high-z tension becomes a quantitative condition;
- V12.3 E is either reconciled with Fork08 or declared a fork.
```

---

# 3. CAPSULE — scale vs participation split

## 3.1 Far-field scale

The background settlement scale is:

```text
a_S(t) = cH(t)/(2π)
```

At z=0 with H0=67.74 km/s/Mpc:

```text
a_S0 = 1.047455259180e-10 m/s²
```

This is a far-field handoff scale. It is not a local metric closure coefficient.

## 3.2 SPARC/Fork08 law

The weak-field far-field law is:

```text
g_SFT²(r) = g_bar²(r) + λ_eff(r) a_S g_bar(r)
```

with:

```text
λ_eff(r) = Σ_j w_j(r) p_j(r) λ_j
```

where participation p_j encodes banked/coherent settlement support.

## 3.3 Redshift tension diagnostic

If a_S changes with H(z), then the net anomalous support relative to local is not just λ(z).

It is:

```text
B_net(z) = [λ_eff(z)/λ_eff(0)] [H(z)/H0]
```

For high-z systems to show weaker net boost than local systems:

```text
B_net(z) < 1
```

so:

```text
λ_eff(z)/λ_eff(0) < H0/H(z)
```

This is the key condition.

At z bin centers in an illustrative flat matter+Λ reference:

| z | H/H0 | λ ratio needed for no net growth |
|---:|---:|---:|
| 0.35 | 1.208 | 0.828 |
| 0.95 | 1.738 | 0.575 |
| 1.50 | 2.368 | 0.422 |
| 2.20 | 3.318 | 0.301 |

This means Track2 high-z suppression must be strong enough to outrun the H(z) rise.

## 3.4 Interpretation

The SFT split becomes:

```text
a_S:
    background horizon/write-rate scale

λ_eff / Pcoh / participation:
    local banked settlement accessibility
```

So there is no contradiction if:

```text
H(z) rises
but
Pcoh/λ_eff falls faster in unsettled systems
```

There is tension if:

```text
high-z settled systems keep λ_eff near local values
```

because then a_S(z) makes the net support larger, not smaller.

---

# 4. V12.3 E vs Fork08 participation

Four reconciliation candidates are now frozen:

```text
R0_E_NEAR_1:
    E is approximately unity or already absorbed for SPARC-like disks.

R1_E_AS_BACKGROUND_ACCESSIBILITY:
    E modulates far-field background accessibility, while p_j/Pcoh modulates local source participation.

R2_E_EQUALS_PARTICIPATION_SCALAR:
    E is the older name for the same coherent-settlement accessibility later formalized as participation/Pcoh.

R3_PROTOCOL_FORK:
    E and Fork08 participation are incompatible; one must be retired or domain-limited.
```

Status:

```text
OPEN
```

No public promotion until resolved.

---

# 5. LOCAL METRIC PROTECTION RULE

This is mandatory:

```text
E, Pcoh, λ_eff, and a_S do not modify F/B closure.
```

They cannot change:

```text
γ = 1
β = 1
light/Shapiro factor = 2
```

They live in the far-field support term only.

If any far-field operator changes local metric closure, it is rejected.

---

# 6. DIAGNOSTIC TABLE — Track2 corridors with H(z)

Using the sealed Track2 corridor classes and illustrative H(z):

{bin_df.to_markdown(index=False, floatfmt=".3f")}

Clean read:

```text
hard-reset systems can remain suppressed despite H(z) growth;
ordinary systems cross/tension depending z and corridor end;
settled high-z systems tend toward net boost growth if λ remains high.
```

So the far-field prediction is sharpened:

```text
high-z low-Pcoh systems:
    suppressed boost can survive H(z)

high-z genuinely settled systems:
    should recover or exceed local support if a_S(z) applies directly

observational kill axis:
    settled high-z disks with low boost are tension for simple a_S(z);
    unsettled high-z disks with full boost are tension for Pcoh suppression.
```

---

# 7. STATUS LINE

```text
FARFIELD_HANDOFF_STATUS:
    PARTIAL_ARCHITECTURE_PASS
    HZ_TENSION_REGISTERED
    E_PROTOCOL_RECONCILIATION_OPEN

EARNED / CARRIED:
    a_S = cH/2π as far-field background scale
    SPARC law g² = g_bar² + λ_eff a_S g_bar
    participation coefficient as banked/coherent settlement accessibility
    local metric closure protected from far-field modifiers
    suppression condition λ(z)/λ0 < H0/H(z)

OPEN:
    V12.3 E protocol vs Fork08 participation reconciliation
    whether a_S uses instantaneous H(z), effective lookback-integrated H, or local accessibility-filtered H
    direct DESI/high-z observational adjudication
```

---

# 8. LIVE EDGE

## GC-2I-R1 — E protocol reconciliation

Run the frozen V12.3 E protocol against SPARC/Fork08 rows or algebraically map it to participation.

Pass outcomes:

```text
E≈1:
    V12.3 harmonizes as background protocol.

E maps to Pcoh:
    merge notation.

E conflicts:
    declare fork; retire or domain-limit one protocol.
```

## GC-2I-R2 — H(z) accessibility split

Determine whether a_S(t) is:

```text
instantaneous H(z)
lookback-integrated write scale
locally accessible horizon scale
```

This decides the high-z prediction.

---

# 9. Referee intuition check

Does this match the physical picture?

```text
The horizon sets the available background settlement scale.
Local systems only bank what they can coherently write.
High-z has a larger background rate but less accumulated local coherence.
The observable boost is the product of those two facts.
```

If yes, GC-2I passes as architecture with open reconciliation.

If no, pause public SPARC/DESI gravity claims until the far-field handoff is rebuilt.
