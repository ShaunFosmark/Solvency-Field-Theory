# GC2I Opus/Public Narrative Handoff Seed

## Public section title

**From local gravity to galaxy-scale support**

## Public claim

SFT separates the far-field scale from the local participation coefficient. The scale a_S = cH/2π comes from the cosmological write rate. The coefficient λ_eff measures how much of the local baryonic system has banked coherent settlement history. High-redshift systems therefore contain a real tension: H(z) is larger, which raises the background scale, but young or disturbed systems have lower participation, which suppresses the local boost. The observable is their product.

## Must include

- a_S is a far-field scale, not a local metric coefficient.
- E/Pcoh/participation cannot alter γ=1.
- High-z suppression requires λ_eff/Pcoh suppression to outrun H(z) growth.
- V12.3 E and Fork08 participation must be reconciled before public promotion.

## Must not say

- "Track2 is solved."
- "DESI/high-z data validate the far-field law."
- "E is already identical to Pcoh" unless GC-2I-R1 passes.
- "a_S(z)=cH(z)/2π straightforwardly predicts low high-z boosts" without the participation condition.
