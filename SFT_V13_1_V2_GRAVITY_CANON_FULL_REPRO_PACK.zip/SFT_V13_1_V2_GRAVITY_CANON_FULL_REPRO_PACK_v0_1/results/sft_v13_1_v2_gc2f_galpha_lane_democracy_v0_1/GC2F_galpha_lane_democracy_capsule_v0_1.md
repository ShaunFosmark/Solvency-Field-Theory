# SFT V13.1-V2 GC-2F / G-alpha — Lane-Democratic Deposition Capsule v0.1

## Part IV live-edge title

**From selected α = 1 to lane-democratic α = 1**

## Status

```text
GC-2F_GALPHA_CONDITIONAL_DERIVATION_DRAFT
```

GC-2D and GC-2E showed:

```text
α = 1 gives γ = 1
γ = 1 gives the full light/Shapiro factor
direct null and timelike trajectories pass weak-field tests
```

But that still left the central debt:

```text
Why α = 1?
```

GC-2F attempts the native SFT answer.

---

# 1. ATTACK

The attack:

> You picked α = 1 because GR needs it. That is coefficient selection, not derivation. Cassini enforces γ = 1 to high precision, but satisfying Cassini is not the same as deriving γ = 1 from the write operator.

This attack is valid unless the write/lane structure forces equal temporal and spatial metric response.

---

# 2. STAKES

If G-alpha fails:

```text
- SFT still survives the weak-field tests but carries α=1 as SELECTED.
- Cassini is satisfied, not predicted.
- one-speed closure remains a successful closure rule, not yet an operator theorem.
```

If G-alpha passes:

```text
- α=1 becomes a consequence of lane-democratic write deposition.
- γ=1 becomes predicted by write geometry.
- the factor-of-two gate becomes mechanism, not calibration.
```

---

# 3. CAPSULE — minimal derivation

## 3.1 Lane definitions

Use the V13.8-compatible partition:

```text
I4 = Π_settlement + Π_continuation
Tr(Π_settlement)=3
Tr(Π_continuation)=1
```

Interpretation:

```text
continuation lane:
    local frame advancement / clock availability

settlement lanes:
    three spatial settlement directions / path accommodation
```

## 3.2 One universal footprint per write

The GC-2A source rule says:

```text
one write = one universal footprint
energy = write rate
```

The G-alpha candidate adds the symmetry rule:

```text
before source anisotropy is applied,
the footprint magnitude per lane slot is equal.
```

That is **lane-democratic deposition**.

It does not say the total spatial trace equals the continuation lane. There are three spatial lanes.

It says:

```text
per available lane:
    equal magnitude response
```

## 3.3 Sign rule

A settled source affects the continuation and settlement lanes with opposite sign:

```text
continuation lane:
    debit / lag / reduced local clock advancement

settlement lanes:
    credit / spatial path accommodation / expanded closure length
```

Let:

```text
q_t = continuation-lane debit magnitude
q_s = per-spatial-lane credit magnitude
```

Lane democracy gives:

```text
q_s = q_t
```

## 3.4 Closure exponents

The time factor is:

```text
F = exp(-q_t φ)
```

The per-lane spatial factor is:

```text
B = exp(q_s φ)
```

If φ is normalized to the continuation lag, then:

```text
F = exp(-φ)
B = exp((q_s/q_t) φ)
```

Therefore:

```text
α = q_s/q_t
```

Lane democracy gives:

```text
q_s/q_t = 1
```

so:

```text
α = 1
B = exp(φ)
F B = 1
γ = 1
```

## 3.5 Why the 3:1 projector ratio does not make γ = 3

The spatial trace has three lanes:

```text
spatial trace response = 3 q_s
continuation response = q_t
```

Lane democracy therefore gives the total trace ratio:

```text
spatial trace / temporal magnitude = 3
```

But PPN γ is not the total spatial trace divided by the time slot. It is the **per-spatial-lane** coefficient compared with the time coefficient.

Thus:

```text
γ = q_s/q_t = 1
```

not:

```text
γ = 3
```

This is the guardrail.

---

# 4. NUMERIC / ALGEBRAIC RETEST

Lane-democratic row:

| quantity | expected | measured |
|---|---:|---:|
| q_s/q_t | 1 | 1.000000000000 |
| α | 1 | 1.000000000000 |
| γ | 1 | 1.000000000000 |
| light/Shapiro factor | 2 | 2.000000000000 |
| perihelion numerator | 3 | 3.000000000000 |
| spatial trace / temporal magnitude | 3 | 3.000000000000 |

Perturbation schematic:

```text
h ∝ 2φ diag(-1,+1,+1,+1)
```

Per-lane readout:

```text
γ = (+2φ)/(2φ) = 1
```

Total spatial trace readout:

```text
(+2φ + +2φ + +2φ)/(2φ) = 3
```

Both are correct, but they answer different questions.

---

# 5. STATUS LINE

```text
GALPHA_STATUS:
    CONDITIONAL_DERIVATION_PASS_IF_LANE_DEMOCRACY_ACCEPTED

UPGRADED:
    α = 1 no longer merely selected by weak-field target
    α = 1 follows from q_s = q_t per-lane deposition

EARNED:
    γ = 1 from per-lane equality
    factor-of-two from lane-democratic reciprocal closure
    3:1 projector trace ratio without confusing γ

STILL OPEN:
    prove lane democracy is unavoidable from no-overwrite / symmetry / one-footprint law
    handle anisotropic sources beyond isotropic weak-field response
    connect lane democracy to full covariant dynamics
    confirm no conflict with G-J, G-RAD, G-SEP
```

Recommended status upgrade:

```text
α = 1:
    from SELECTED_NOT_DERIVED
    to CONDITIONAL_EARNED_FROM_LANE_DEMOCRACY
```

Not yet:

```text
FULLY_DERIVED_FROM_FIRST_PRINCIPLES
```

---

# 6. LIVE EDGE

## G-alpha-2 — inevitability of lane democracy

The remaining attack:

> Why must a universal footprint be lane-democratic per slot? Why not q_s/q_t ≠ 1?

Candidate answers to test next:

```text
1. local isotropy of an unpolarized write
2. no preferred lane before source orientation
3. one-speed budget conservation
4. no-overwrite admissibility under local relabeling
5. failure of q_s/q_t≠1 to preserve universal null readout
```

This is now a sharper gate than the original α question.

---

# 7. Referee intuition check

Does this match the physical picture?

```text
A write is one event.
Before anisotropy, it does not know which spatial lane should get more footprint.
The continuation lane loses advancement capacity.
Each settlement lane receives equal path-accommodation magnitude.
The total spatial response is 3:1 because there are three lanes,
but each lane matches the time-lane magnitude.
That per-lane equality is γ = 1.
```

If yes, α=1 is no longer just selected by GR-like tests. It is conditionally earned by the SFT write/lane structure.

If no, α=1 remains selected only and G-alpha stays open.
