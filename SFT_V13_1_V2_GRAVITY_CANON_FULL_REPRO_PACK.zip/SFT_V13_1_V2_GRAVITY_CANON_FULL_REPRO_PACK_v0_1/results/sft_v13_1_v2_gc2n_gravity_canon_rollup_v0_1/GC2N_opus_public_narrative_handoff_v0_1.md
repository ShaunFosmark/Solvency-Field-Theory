# GC-2N Opus Public Narrative Handoff v0.1

## Use this as source status, not as license to upgrade claims

The derivation canon now supports a public narrative, but each statement must preserve its status.

## Public paper architecture

1. **Why gravity had to be rebuilt**
   - Not a patch to old V13.1.
   - Rebuilt from locally real particle, one-speed, no-overwrite, and projector/lane stack.

2. **Source**
   - Energy writes settlement by rate.
   - Universal footprint.
   - Active density target.
   - G value not yet derived.

3. **Weak-field metric**
   - Scalar projection gives Newtonian gravity.
   - One-speed reciprocal closure gives γ=1.
   - Factor-of-two light bending follows.
   - Direct trajectories pass.

4. **Normalization**
   - G_eff=a_phi c^3/hbar.
   - A0=2πa_phi.
   - Numeric a_phi open.

5. **Far field**
   - a_S=cH/2π.
   - λ_eff/Pcoh is local banked participation.
   - High-z suppression condition is λ_eff(z)/λ_eff(0)<H0/H(z).
   - E protocol open.

6. **Static spherical strong field**
   - Areal shell capacity.
   - Universal footprint/additivity kills q≠0.
   - A=1-2M/R.
   - Horizon as continuation capacity exhaustion.
   - Static spherical Schwarzschild restored.
   - No Kerr/ringdown/dynamic-collapse claim.

7. **Frontiers**
   - Radiation: TT skeleton only; scalar/dipole/pulsar open.
   - SEP: universal κ route; binding/self-energy open.
   - Frame dragging: topology only; coefficient/transport open.

## Approved strong sentences

```text
In the weak-field metric sector, γ=1 is not fitted; it follows from one-speed reciprocal closure.
```

```text
In the static spherical sector, SFT restores Schwarzschild when the areal-shell lapse is identified with literal remaining continuation capacity; universal one-footprint additivity forces A=1-2M/R.
```

```text
SFT compresses the gravitational coupling to one root-area invariant, but it does not yet derive the numerical value of that root.
```

```text
The horizon is interpreted as the areal surface where continuation capacity is exhausted.
```

## Required disclaimers

```text
The numerical value of G remains open.
```

```text
Radiation, binary pulsars, strong equivalence, frame-dragging coefficients, Kerr, and dynamic black-hole physics remain frontier gates.
```

## Forbidden upgrades

Do not write:

```text
SFT has derived all of GR.
SFT has solved black holes.
SFT has passed binary pulsars.
SFT has derived Kerr.
SFT derives the numerical value of G from first principles.
SFT proves SEP.
```
