# SFT V13.1-V2 Gravity Canon — GC-2N Main-Line Rollup v0.1

## Master verdict

```text
SFT_V13_1_V2_GC2N_GRAVITY_CANON_MAINLINE_ROLLUP_COMPLETE_WEAK_FIELD_METRIC_STRONG_PASS_STATIC_SPHERICAL_SCHWARZSCHILD_RESTORED_WITH_EXPLICIT_AREAL_CAPACITY_AXIOMS_NORMALIZATION_STRUCTURE_EARNED_G_VALUE_OPEN_FARFIELD_ARCHITECTURE_PARTIAL_RADIATION_SEP_FRAME_DRAGGING_FRONTIERS_ARMED_PUBLIC_BOUNDARIES_SET
```

## Clean read

The Gravity Canon now has a coherent status-labeled spine:

```text
source -> scalar projection -> tensor/lane bridge -> one-speed metric closure
-> direct weak-field tests -> G-alpha theorem -> normalization
-> far-field architecture -> bounded strong-field restoration
-> radiation/equivalence/frame-dragging frontiers
```

The major win is not that every sector is solved.

The major win is that the solved sectors, partial sectors, and open debts are now separated.

---

# 1. What is strongly earned

## 1.1 Weak-field gravity

The weak-field gravity chain is now strong:

```text
C_A source compactness
-> Newtonian scalar projection
-> one-speed reciprocal metric closure
-> γ=1
-> β=1
-> light/Shapiro factor 2
-> perihelion weak-field behavior
-> direct trajectory recovery
```

The old scalar-gravity graveyard is no longer just avoided by selection. GC-2G upgraded the factor-of-two closure:

```text
Lane democracy is the one-speed budget applied to the metric.
F B = 1 forces q_s=q_t, α=1, γ=1.
```

Public allowed:

```text
In the weak-field metric sector, γ=1 is a theorem of one-speed closure.
```

Boundary:

```text
This does not by itself solve radiation, frame dragging, Kerr, or binary pulsars.
```

## 1.2 Normalization structure

GC-2H earned:

```text
G_eff = a_phi c^3 / hbar
A0 = 2π a_phi
a_phi E/hbar = A0 E/h
```

So SFT earns the structure of the coupling and the 2π clock-gauge convention.

Boundary:

```text
The numerical value of a_phi / G remains open.
Planck area cannot be used as a derivation input because it already contains G.
```

## 1.3 Static spherical Schwarzschild

GC-2J initially exposed a strong-field fork. R1/R2/R3 fought for the claim and restored it in a bounded domain.

Final static-spherical restoration:

```text
native shell variable: areal radius R
capacity compactness: C=M/R
universal-footprint/additive capacity: K(C)=2C
remaining continuation capacity: A(C)=1-2C
radial one-speed reciprocity: g_RR=1/A
```

Therefore:

```text
ds² = -(1-2M/R)dt² + (1-2M/R)^-1dR² + R²dΩ²
```

This restores exact Schwarzschild in the static spherical areal-capacity sector.

Boundary:

```text
This does not solve Kerr, dynamic collapse, ringdown, horizon microphysics, thermodynamics, or radiation.
```

---

# 2. What is partially earned

## 2.1 Far-field handoff

GC-2I earned a protected architecture:

```text
a_S = cH/2π
g_SFT² = g_bar² + λ_eff a_S g_bar
```

and sharpened high-z suppression to:

```text
λ_eff(z)/λ_eff(0) < H0/H(z)
```

Boundary:

```text
V12.3 E protocol and Fork08 participation remain unreconciled.
```

## 2.2 Radiation

GC-2K earned the TT skeleton only:

```text
trace-free lane response -> far-zone TT readout -> plus/cross skeleton
quadrupole m=2 source structure
```

Open:

```text
scalar breathing suppression
dipole suppression
quadrupole power coefficient
radiation reaction
binary-pulsar pass
```

## 2.3 Equivalence

GC-2L identified the native route:

```text
gravity source = write-rate energy
κ_i = q_i/m_i universal
```

If κ is universal:

```text
free fall is universal
binary dipole D = Σq_i x_i vanishes in COM coordinates
```

Open:

```text
binding energy universality
strong self-energy
compact-object scalar sensitivity
full SEP
```

Macro-closure addendum:

```text
rock -> white dwarf -> neutron star -> black hole
perturbation -> contribution -> partnership -> identity
```

This is flagged as a future route to close binding/self-energy universality.

## 2.4 Frame dragging

GC-2M identified the mixed continuation-settlement channel:

```text
A_mix ∝ J × r / r³
curl A_mix ∝ [3n(J·n)-J]/r³
```

Topology passes.

Open:

```text
Lense-Thirring coefficient
gyroscope transport
Gravity Probe B / LAGEOS
Kerr
```

---

# 3. What is not claimed

SFT V13.1-V2 does not yet claim:

```text
numerical derivation of G
full covariant field equations
complete strong equivalence principle
binary-pulsar radiation pass
complete gravitational-wave theory
frame-dragging coefficient
Kerr black holes
dynamic collapse
ringdown
black-hole thermodynamics
horizon microphysics
```

---

# 4. Public narrative spine for Opus

## Suggested public abstract spine

SFT treats gravity as settlement written by locally real energy under the one-speed/no-overwrite constraint. In the weak field, the source compactness produces the Newtonian scalar projection, while one-speed reciprocity forces equal and opposite clock and spatial responses, giving γ=1 and the full light-bending factor. The coupling strength compresses to a root-area invariant, G_eff=a_phi c³/ℏ, while the numerical value of that root remains open. In static spherical strong fields, areal-shell continuation capacity and universal one-footprint additivity force A=1-2M/R, restoring the Schwarzschild exterior as a capacity-exhaustion theorem. Galaxy-scale support, radiation, equivalence, frame dragging, and rotating strong fields are carried as bounded frontiers with explicit tests and open debts.

## One-sentence headline

```text
SFT now has a status-labeled gravity canon: weak-field metric gravity is strongly earned, static spherical Schwarzschild is restored under explicit areal-capacity axioms, and the remaining frontiers are no longer hidden.
```

---

# 5. Main open theorem targets

```text
G-root-2:
    derive numerical a_phi

G-COV:
    full covariant settlement/lane field equation

G-RAD-2:
    scalar/dipole suppression and quadrupole power coefficient

G-SEP-2:
    macro-closure continuity theorem for binding/self-energy universality

G-J-2:
    Lense-Thirring coefficient and gyroscope transport

T1-spin:
    Kerr / rotating strong-field closure

GC-2I-R1:
    V12.3 E protocol vs Fork08 participation reconciliation
```

---

# 6. Rollup status line

```text
GRAVITY_CANON_STATUS:
    WEAK_FIELD_METRIC: STRONG_PASS
    G_ALPHA: THEOREM_WITH_METRIC_ONE_SPEED_AXIOM
    NORMALIZATION: STRUCTURE_PASS_VALUE_OPEN
    FAR_FIELD: PARTIAL_ARCHITECTURE_PASS
    STATIC_SPHERICAL_STRONG_FIELD: RESTORED_WITH_EXPLICIT_CAPACITY_AXIOMS
    RADIATION: TT_SKELETON_ONLY
    SEP: UNIVERSALITY_ROUTE_CONDITIONAL
    FRAME_DRAGGING: TOPOLOGY_ONLY
    KERR/DYNAMICS: OPEN
```
