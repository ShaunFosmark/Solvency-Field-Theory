# GC-2N Executive Summary v0.1

## Verdict

```text
SFT_V13_1_V2_GC2N_GRAVITY_CANON_MAINLINE_ROLLUP_COMPLETE
```

## What changed

The gravity program now has a clean claim ledger.

The old danger was that SFT had many gravity wins but unclear status boundaries. GC-2N fixes that.

## Main wins

```text
1. Weak-field metric gravity is strongly earned.
2. γ=1 is promoted to a one-speed theorem in the weak-field metric sector.
3. G normalization structure is earned while the numerical value remains open.
4. Far-field architecture is protected and high-z tension is now testable.
5. Static spherical Schwarzschild is restored with explicit areal-capacity axioms.
6. Radiation, SEP, and frame dragging are armed as frontiers instead of overclaimed.
```

## The most important upgrade

GC-2J-R3:

```text
q≠0 means variable marginal footprint or settlement-settlement cross term.
Universal-footprint additivity kills q.
Therefore A=1-2M/R.
Therefore static spherical Schwarzschild is restored.
```

## The most important remaining debt

The frontier triad:

```text
radiation:
    scalar/dipole suppression and quadrupole power

equivalence:
    binding/self-energy universality

rotation:
    frame-drag coefficient and Kerr
```

## Public status

Ready for Opus narrative drafting, with strict boundaries.
