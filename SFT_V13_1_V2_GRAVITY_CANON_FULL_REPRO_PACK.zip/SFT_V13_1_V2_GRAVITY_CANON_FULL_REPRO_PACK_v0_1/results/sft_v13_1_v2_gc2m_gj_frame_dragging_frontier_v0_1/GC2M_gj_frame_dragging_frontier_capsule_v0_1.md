# SFT V13.1-V2 GC-2M / G-J — Rotating-Source Mixed Channel and Frame-Dragging Frontier v0.1

## Status

```text
GC-2M_PARTIAL_FRONTIER_PASS_FRAME_DRAGGING_TOPOLOGY_ONLY_COEFFICIENT_AND_TRANSPORT_OPEN
```

GC-2K and GC-2L handled the radiation/equivalence frontier. GC-2M asks whether the rotating-source sector has a native place in the gravity canon.

The answer is:

```text
Yes: rotation lives in the mixed continuation-settlement channel.
```

But this is not yet a frame-dragging observational pass.

---

# 1. Attack

The attack:

> A scalar settlement field cannot produce frame dragging. Frame dragging is an off-diagonal/mixed metric effect sourced by angular momentum. If SFT only has C_A, it fails immediately.

GC-2C already blocked scalar-only gravity by identifying trace-free and mixed channels.

GC-2M now tests whether the mixed channel has the right rotating-source topology.

---

# 2. Stakes

If GC-2M fails:

```text
- rotating and static sources are indistinguishable
- h_0i / frame dragging has no native home
- Gravity Probe B / LAGEOS / Kerr spin cannot be addressed
```

If GC-2M overclaims:

```text
- a vector-potential toy is mistaken for Lense-Thirring
- coefficient and gyroscope transport are skipped
- strong-field Kerr leaks past GC-2J
```

So the status must remain exact:

```text
topology yes
coefficient no
strong-field spin no
```

---

# 3. Native channel

The mixed sector is:

```text
settlement lane <-> continuation lane
```

A static source loads the scalar/trace channel.

A rotating source carries oriented history flow, so it must enter the mixed continuation-settlement channel.

Candidate skeleton:

```text
A_mix ∝ J × r / r^3
```

Then:

```text
|A_mix| ∝ r^-2
curl A_mix ∝ [3 n(J·n)-J] / r^3
```

This is the correct topological home for a Lense-Thirring-like sector.

---

# 4. Retest diagnostics

| test | expected | measured | verdict |
|---|---:|---:|---|
| A_mix falloff | -2 | -2.000000000000 | PASS_TOPOLOGY |
| curl axis falloff | -3 | -3.000000000000 | PASS_TOPOLOGY |
| curl equator falloff | -3 | -3.000000000000 | PASS_TOPOLOGY |
| A sign reversal residual | 0 | 0.000e+00 | PASS |
| B sign reversal residual | 0 | 0.000e+00 | PASS |
| max n·A | 0 | 1.725e-17 | PASS |
| max J·A | 0 | 0.000e+00 | PASS |
| axis/equator magnitude ratio | 2 | 2.000000000000 | PASS_TOPOLOGY |

Verdict:

```text
PASS_TOPOLOGY
```

---

# 5. What is not earned

GC-2M does not derive:

```text
absolute Lense-Thirring coefficient
h_0i normalization
gyroscope transport law
Gravity Probe B value
LAGEOS nodal precession
Kerr metric
strong-field spin shadow / ISCO / ringdown
```

Those remain open.

---

# 6. Macro-closure addendum

A new G-SEP insight is flagged here for final rollup:

```text
rock -> white dwarf -> neutron star -> black hole
```

may be a closure spectrum:

```text
perturbation -> contribution -> partnership -> identity
```

A neutron star may be the transition zone where gravitational binding energy stops behaving like an external correction and starts behaving like self-maintaining settlement closure.

If compact-star binding energy is a macro-scale version of particle closure, then it may carry the same coupling ratio κ as rest mass.

This could become the future route to closing the G-SEP self-energy debt.

Status:

```text
FLAGGED_NOT_PROVEN
```

The target theorem is:

```text
Macro-closure continuity theorem:
    self-maintaining settlement energy couples with the same κ as microscopic particle closure energy.
```

---

# 7. Status line

```text
G_J_STATUS:
    MIXED_CHANNEL_LOCATION_EARNED
    FRAME_DRAGGING_TOPOLOGY_PASS
    LENSE_THIRRING_COEFFICIENT_NOT_DERIVED
    GYROSCOPE_TRANSPORT_NOT_DERIVED
    KERR_STRONG_FIELD_DEFERRED
    MACRO_CLOSURE_GSEP_ADDENDUM_FLAGGED

EARNED:
    rotating source has native mixed-channel home
    A_mix has correct r^-2 falloff and spin sign reversal
    curl/precession skeleton has r^-3 falloff and axial geometry

NOT EARNED:
    measured frame-dragging pass
    full h_0i sector
    strong-field Kerr
```

---

# 8. Public canon rule

The public paper may say:

```text
SFT identifies the mixed continuation-settlement channel as the native home of rotating-source effects, and its simplest skeleton has the expected frame-dragging topology.
```

It may not say:

```text
SFT has derived Lense-Thirring frame dragging.
```

or:

```text
SFT has derived Kerr.
```

---

# 9. Verdict string

```text
SFT_V13_1_V2_GC2M_GJ_FRAME_DRAGGING_FRONTIER_PARTIAL_MIXED_CONTINUATION_SETTLEMENT_CHANNEL_PASS_TOPOLOGY_AJXR_R3_FALLOFF_SIGN_ORIENTATION_PASS_LENSE_THIRRING_COEFFICIENT_GYROSCOPE_TRANSPORT_AND_KERR_NOT_DERIVED_MACRO_CLOSURE_GSEP_ADDENDUM_FLAGGED
```
