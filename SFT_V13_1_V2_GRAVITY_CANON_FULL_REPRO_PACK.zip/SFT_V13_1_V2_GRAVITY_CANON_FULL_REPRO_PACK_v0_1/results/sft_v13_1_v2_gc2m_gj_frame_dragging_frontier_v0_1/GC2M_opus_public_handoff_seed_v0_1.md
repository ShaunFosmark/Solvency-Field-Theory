# GC2M Opus/Public Narrative Handoff Seed

## Public section title

Rotation and the mixed channel

## Public claim

SFT's scalar settlement field is not the whole gravitational response. Rotating sources live in the mixed continuation-settlement channel, the native place for off-diagonal/frame-dragging behavior. The simplest mixed-channel skeleton has the expected circulation, spin sign reversal, r^-2 vector-potential falloff, and r^-3 curl/precession geometry. This is a topology pass only: SFT has not yet derived the Lense-Thirring coefficient, gyroscope transport law, or Kerr strong-field metric.

## Must include

- Rotating-source effects live in the mixed continuation-settlement channel.
- Frame-dragging topology passes.
- Coefficient and observational frame-dragging pass are not claimed.
- Kerr/strong spin is deferred to the strong-field fork.
- Neutron-star macro-closure insight is flagged for future G-SEP closure.

## Must not say

- SFT has derived frame dragging.
- SFT passes Gravity Probe B or LAGEOS.
- SFT has derived Kerr.
- Neutron-star closure proves SEP already.
