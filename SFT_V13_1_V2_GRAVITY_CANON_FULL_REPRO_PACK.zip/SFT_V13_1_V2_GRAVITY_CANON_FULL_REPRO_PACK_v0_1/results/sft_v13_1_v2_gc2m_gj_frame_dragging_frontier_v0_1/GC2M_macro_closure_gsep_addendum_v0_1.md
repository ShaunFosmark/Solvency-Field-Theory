# GC2M Addendum — Neutron Star as Macro-Closure Bridge

## Status

```text
FLAGGED_FOR_FINAL_ROLLUP_AND_FUTURE_GSEP_CLOSE
```

## Insight

The sequence

```text
rock -> white dwarf -> neutron star -> black hole
```

may be the macroscopic version of the same closure continuum that defines a particle.

The progression is:

```text
perturbation -> contribution -> partnership -> identity
```

For ordinary matter, settlement is a tiny perturbation on particle rest mass.

For a white dwarf, settlement is a significant structural contribution.

For a neutron star, settlement is no longer merely external gravity acting on matter. It is a structural partner: the star exists because settlement, degeneracy/nuclear response, and history-locking maintain a self-bound configuration.

For a black hole, settlement/horizon write surface may become the object.

For a particle, closure already is the object at the microscopic scale.

## G-SEP implication

If compact-object binding energy is not an external scalar charge but a larger-scale instance of the same closure mechanism that gives particles their rest energy, then the coupling ratio kappa is naturally universal:

```text
particle closure energy and compact-star binding closure energy are the same kind of write ledger
```

Then neutron-star binding energy should carry the same settlement charge per inertial energy as ordinary rest mass.

This is a candidate route to close the G-SEP self-energy debt later.

## Current boundary

This is not claimed as a proof.

It is a flagged theorem target:

```text
Macro-closure continuity theorem:
    self-maintaining settlement energy couples with the same kappa as microscopic particle closure energy.
```

If proven, it upgrades G-SEP from conditional universality to a native strong-equivalence mechanism.

If false, neutron stars remain the dangerous scalar-charge / Nordtvedt / dipole test.
