# GC2L Opus/Public Narrative Handoff Seed

## Public section title

Equivalence and the dipole danger

## Public claim

SFT's native route to the equivalence principle is that gravity couples to write-rate energy itself, not to material labels. If all forms of internal, binding, and field energy enter the same settlement ledger with the same weight, then gravitational charge per inertial mass is universal. In that case, binary dipole radiation is suppressed automatically because the gravitational dipole is proportional to the inertial center-of-mass dipole. But this is still conditional: binding energy, compact-object self-energy, and body-dependent scalar charge must be fully audited before SFT can claim a strong-equivalence or binary-pulsar pass.

## Must include

- Universality route identified.
- Binary dipole vanishes if q/m is universal.
- Nonuniversality immediately creates dipole risk.
- Binding/self-energy remains open.
- Full SEP and binary pulsar pass are not claimed.

## Must not say

- SFT has proven SEP.
- SFT passes binary pulsars.
- Scalar charge danger is closed.
- Compact-object self-energy is solved.
