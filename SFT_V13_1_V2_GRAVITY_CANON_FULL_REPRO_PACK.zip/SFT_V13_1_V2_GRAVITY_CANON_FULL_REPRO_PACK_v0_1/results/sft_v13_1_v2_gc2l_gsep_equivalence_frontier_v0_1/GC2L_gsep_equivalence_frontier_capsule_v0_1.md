# SFT V13.1-V2 GC-2L / G-SEP — Equivalence, Universality, and Dipole Suppression Frontier v0.1

## Status

```text
GC-2L_PARTIAL_FRONTIER_PASS_UNIVERSALITY_SKELETON_ONLY_BINDING_SELF_ENERGY_OPEN
```

GC-2K left the radiation sector in a dangerous but clear state:

```text
TT skeleton works.
Scalar breathing and dipole radiation remain open.
```

GC-2L asks whether the equivalence/universality structure gives a native suppression route.

This gate does not claim full SEP.

It earns a conditional skeleton:

```text
If gravitational charge is universal write-rate energy,
then composition free fall and binary dipole suppression follow.
```

But it leaves binding energy, strong self-energy, and body-dependent scalar charge as high-stakes open debts.

---

# 1. Attack

The attack:

> SFT has a scalar settlement source. If different bodies carry different scalar charge per inertial mass, then free fall is composition-dependent and binaries radiate dipole power. Binary pulsars and equivalence tests will kill it.

This attack is valid unless SFT proves universality.

---

# 2. Stakes

If G-SEP fails:

```text
- scalar-charge differences survive
- dipole radiation returns
- Nordtvedt/self-energy violations appear
- binary pulsar safety fails
- G-RAD cannot be promoted
```

If G-SEP passes later:

```text
- trace/scalar source becomes universal constraint charge
- dipole radiation is suppressed
- tensor quadrupole channel can remain the leading far-zone radiation
```

---

# 3. Native universality route

SFT's best route is:

```text
gravity source = write-rate energy
```

not:

```text
gravity source = material label
```

If every form of inertial energy also contributes the same settlement write charge, then:

```text
q_g / m_i = constant
```

Let:

```text
κ_i = q_i / m_i
```

Universal coupling means:

```text
κ_i = κ for all bodies
```

Then free fall is universal.

---

# 4. Binary dipole diagnostic

Define the radiative dipole charge:

```text
D = Σ_i q_i x_i
```

For a binary in center-of-mass coordinates:

```text
m1 x1 + m2 x2 = 0
```

If:

```text
q_i = κ m_i
```

then:

```text
D = κ(m1x1 + m2x2) = 0
```

So the dipole vanishes.

If universality fails:

```text
κ1 ≠ κ2
```

then for separation a:

```text
D = μ a (κ1 - κ2)
```

where μ is the reduced mass.

Numerical diagnostic used:

```text
m1=1.4
m2=1.3
a=1.0
μ=0.674074074074
```

Result:

```text
D = 0 exactly when κ1=κ2.
D grows linearly with Δκ.
```

This is the core dipole-suppression condition.

---

# 5. Nordtvedt/self-energy diagnostic

A schematic self-energy sensitivity can be written:

```text
κ = 1 + η_N ε_g
```

where:

```text
ε_g = |binding energy|/(mc²)
```

If η_N is nonzero, strongly self-gravitating bodies obtain different κ and can violate strong equivalence.

Status:

```text
OPEN_HIGH_STAKES
```

The hard cases are compact objects, not laboratory bodies.

---

# 6. Universal source ledger

All of these must couple with identical source weight:

```text
rest mass energy
internal kinetic energy
radiation energy and pressure
nuclear/strong binding
electromagnetic binding
gravitational/self binding
```

GC-2A already carried the active source target:

```text
ρ_active = ρ_rest + u_int/c² + ρ_rad + 3p/c² + ρ_bind
```

But GC-2L does not declare this fully proven across micro-to-macro binding sectors.

---

# 7. Gate scores

```text
universal write-charge principle:
    PASS_SKELETON

composition free fall:
    CONDITIONAL_PASS

binary dipole suppression:
    CONDITIONAL_PASS

Nordtvedt/self-energy:
    OPEN_HIGH_STAKES

scalar charge danger:
    OPEN_HIGH_STAKES

final:
    PARTIAL_FRONTIER_PASS_UNIVERSALITY_SKELETON_ONLY
```

---

# 8. Status line

```text
G_SEP_STATUS:
    UNIVERSALITY_ROUTE_IDENTIFIED
    FREE_FALL_PASS_CONDITIONAL_ON_ALL_ENERGY_COUPLING
    DIPOLE_SUPPRESSION_PASS_CONDITIONAL_ON_UNIVERSAL_KAPPA
    BINDING_ENERGY_UNIVERSALITY_OPEN
    STRONG_SELF_ENERGY_OPEN
    FULL_SEP_NOT_CLAIMED

EARNED:
    if q_i/m_i is universal, free fall is universal
    if q_i/m_i is universal, binary dipole radiation is suppressed
    nonuniversality immediately produces dipole risk

NOT EARNED:
    complete strong equivalence principle
    compact-body self-energy universality
    binary-pulsar-safe radiation sector
    full scalar-charge suppression proof
```

---

# 9. Public canon rule

The public paper may say:

```text
SFT's native route to equivalence is that the settlement source is write-rate energy itself, not material composition. If all internal and binding energies enter the same write ledger, composition dependence and dipole radiation are suppressed.
```

It may not say:

```text
SFT has proven the strong equivalence principle.
```

or:

```text
SFT passes binary pulsar constraints.
```

---

# 10. Verdict string

```text
SFT_V13_1_V2_GC2L_GSEP_EQUIVALENCE_FRONTIER_PARTIAL_UNIVERSAL_WRITE_CHARGE_SKELETON_PASS_FREEFALL_AND_DIPOLE_SUPPRESSION_CONDITIONAL_ON_UNIVERSAL_KAPPA_BINDING_SELF_ENERGY_AND_SCALAR_CHARGE_DANGER_OPEN_FULL_SEP_NOT_CLAIMED
```
