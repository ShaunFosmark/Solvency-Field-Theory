# GC2B Opus/Public Narrative Handoff Seed

## Public section title

**The first projection: settlement looks Newtonian before it looks relativistic**

## Public claim

Once energy is interpreted as write rate, the first gravitational readout is a scalar settlement compactness. For a localized source, that compactness spreads outward as 1/r in three spatial dimensions. Its gradient gives the ordinary inverse-square acceleration, and a uniform spherical source gives the expected linear interior acceleration.

## Must include

- This is the first projection only.
- C_A is not the full gravitational object.
- Scalar settlement explains Newtonian behavior and clock-lag profile.
- Full light bending requires the later spatial/metric closure.

## Must not say

- "The scalar field alone is gravity."
- "This section derives GR."
- "This section solves Cassini/frame-dragging/waves."
