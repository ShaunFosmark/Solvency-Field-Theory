# SFT V13.1-V2 GC-2B — Scalar Settlement Projection Capsule v0.1

## Part II title

**Settlement Field: the scalar projection of gravitational response**

## Status

```text
GC-2B_DRAFT_RETESTED_PROJECTION_ONLY
```

This capsule rebuilds the old scalar settlement gate. It earns the Newtonian/clock-lag projection, but it does **not** claim full gravity.

The metric/tensor/lane response is downstream.

---

# 1. ATTACK

The attack:

> SFT's settlement field is just a scalar potential. A scalar potential may reproduce Newtonian attraction, but it cannot by itself give full relativistic gravity, light bending, frame dragging, tensor waves, or the Cassini value γ = 1.

This attack is correct if SFT stops here.

So GC-2B must be explicit:

```text
Scalar settlement is the 00/Newtonian/readout projection.
It is not the complete gravitational object.
```

---

# 2. STAKES

If the scalar projection fails, gravity fails immediately:

```text
- no inverse-square force
- no exterior 1/r settlement
- no ordinary clock-lag profile
- no uniform-sphere interior behavior
- no bridge from local writes to bulk bodies
```

If the scalar projection is overclaimed, gravity also fails:

```text
- scalar-only gives the wrong relativistic theory
- factor-of-two light bending attack returns
- Cassini/frame-dragging/waves are unaddressed
```

So this section has one job:

```text
earn the scalar projection, then stop.
```

---

# 3. CAPSULE — minimal re-derivation path

## 3.1 Point source exterior

From GC-2A, for localized energy E:

```text
C_A(E,r) = A_write E / (ℏ c r)
```

With the readout normalization:

```text
A_write = Gℏ/c^3
E = M c^2
```

then:

```text
C_A(r) = GM/(c^2 r)
```

This immediately gives:

```text
C_A ∝ r^-1
```

and the scalar acceleration readout:

```text
a = -c^2 ∇C_A
```

gives:

```text
|a| = GM/r^2
```

so:

```text
|a| ∝ r^-2
```

## 3.2 Weak clock-lag scalar projection

In weak field, the local scalar lag readout is proportional to the compactness:

```text
δτ/τ ∼ C_A
```

Therefore:

```text
clock lag ∝ r^-1
```

This is only the scalar clock-lag projection. The reciprocal spatial closure that produces γ = 1 belongs to the later one-speed metric section.

## 3.3 Uniform sphere interior

For a uniform sphere of radius R and total mass M:

```text
M(<r) = M (r/R)^3
```

The interior acceleration is:

```text
a(r) = G M(<r) / r^2
     = G M r / R^3
```

so:

```text
a(r) ∝ r
```

At r > R, the field returns to:

```text
a(r) = GM/r^2
```

---

# 4. NUMERIC RETEST

Dimensionless retest used μ = GM/c² = 1 for exterior profiles.

| test | expected | measured |
|---|---:|---:|
| exterior C_A slope | -1 | -1.000000000000 |
| exterior acceleration slope | -2 | -2.000000000000 |
| weak clock-lag slope | -1 | -1.000000000000 |
| uniform-sphere interior acceleration slope | +1 | 1.000000000000 |
| uniform-sphere exterior acceleration slope | -2 | -2.000000000000 |

Verdict:

```text
PASS_SCALAR_PROJECTION
```

---

# 5. STATUS LINE

```text
SCALAR_SETTLEMENT_STATUS:
    EARNED_AS_NEWTONIAN_00_PROJECTION

EARNED:
    exterior C_A ∝ r^-1
    exterior |a| ∝ r^-2
    weak clock-lag projection ∝ r^-1
    uniform-sphere interior |a| ∝ r
    exterior field depends on total enclosed source

NOT EARNED HERE:
    γ = 1
    full light bending
    Shapiro factor 2
    perihelion numerator
    frame dragging
    gravitational waves
    strong-field horizons
```

---

# 6. LIVE EDGES

## GC-2C — tensor/lane promotion

Question:

```text
How does the scalar settlement readout promote to a metric-like/tensor-like response?
```

## GC-2D / G-alpha — one-speed closure

Question:

```text
Why does spatial closure match clock lag so that γ = 1?
```

## G-J / G-RAD

Question:

```text
Where do rotating-source and wave-sector records live?
```

---

# 7. Referee intuition check

Does this match the physical picture?

```text
The scalar settlement field tells us how much local write accommodation is demanded by the source.
Its exterior footprint spreads as 1/r in 3D.
Its gradient gives ordinary acceleration.
But scalar settlement alone is not yet spacetime geometry.
```

If yes, proceed to GC-2C.

If no, do not move to metric closure yet.
