# GC2J-R3 Opus/Public Handoff Seed

## Public section title

Why the static spherical horizon returns

## Public claim

In the static spherical sector, SFT can restore exact Schwarzschild if the areal-shell metric lapse is identified with literal remaining continuation capacity. Universal one-footprint write mechanics makes capacity consumption linear in compactness. Any quadratic correction qC² would make the marginal cost depend on already-existing settlement or introduce a source-source cross term. Thus q=0, A=1-2M/R, and the horizon is the surface where continuation capacity is exhausted.

## Must include

- Static spherical sector only.
- Requires explicit capacity axiom: A is continuation capacity itself.
- q≠0 means variable marginal footprint or settlement-settlement cross term.
- Horizon is continuation-capacity exhaustion at R=2M.
- Kerr, ringdown, radiation, thermodynamics, and horizon microphysics remain open.

## Must not say

- SFT has solved all black holes.
- Kerr is derived.
- Gravitational radiation is solved.
- The capacity axiom requires no explanation.
