# SFT V13.1-V2 GC-2J-R3 — Areal-Shell Capacity Law v0.1

## Status

```text
GC2J_R3_STATIC_SPHERICAL_SCHWARZSCHILD_DERIVED_WITH_EXPLICIT_AREAL_CAPACITY_AXIOMS
```

## Question

Can SFT kill the q≠0 alternatives in

```text
A_q(C)=1-2C+qC²
```

and restore exact Schwarzschild in the static spherical sector?

## Answer

Yes, if the following SFT strong-field capacity axiom is accepted explicitly:

```text
A(C) is the literal remaining continuation-capacity fraction of an areal shell.
```

Under that definition, q≠0 is not a harmless coordinate freedom. It is either:

```text
variable marginal write cost
```

or:

```text
a settlement-settlement cross term.
```

Both violate the current universal-footprint/no-self-cost rule.

Therefore q=0 follows.

This restores exact Schwarzschild in the static spherical exterior sector.

---

# 1. Opus route: universal-footprint linear capacity

Define:

```text
A_q(C)=1-2C+qC²
```

Then consumed continuation capacity is:

```text
K_q(C)=1-A_q(C)=2C-qC²
```

Universal-footprint write mechanics says:

```text
one write = one footprint
```

and the cost of the next footprint does not depend on the settlement already accumulated.

Therefore the marginal capacity debit must be constant:

```text
dK/dC = constant
```

But:

```text
dK_q/dC = 2 - 2qC
```

This is constant only if:

```text
q=0
```

So Opus route passes if A is literal capacity.

---

# 2. 5.6 route: additivity/no-cross-term audit

Independent exterior source packages should add their capacity debit without a cross-term.

For q-family capacity:

```text
K_q(C1+C2)-K_q(C1)-K_q(C2) = -2qC1C2
```

A nonzero q produces a source-source / settlement-settlement interaction term.

Therefore:

```text
q≠0 means existing settlement changes the capacity cost of additional settlement
```

That violates the universal footprint rule.

So the additivity route also kills q≠0.

---

# 3. Factor 2

The factor 2 is not a new fit.

It is inherited from one-speed reciprocal closure:

```text
one unit clock/continuation debit
+
one unit radial/spatial debit
=
two-sided capacity consumption
```

Therefore:

```text
K(C)=2C
```

and:

```text
A(C)=1-K(C)=1-2C
```

---

# 4. Exact static spherical metric

With areal radius R:

```text
C=M/R
```

and radial one-speed reciprocity:

```text
g_RR = 1/A(R)
```

we get:

```text
A(R)=1-2M/R
```

therefore:

```text
ds²=-(1-2M/R)dt²+(1-2M/R)^-1dR²+R²dΩ²
```

This is the Schwarzschild exterior.

---

# 5. What is restored

```text
static spherical exterior Schwarzschild:
    RESTORED_WITH_EXPLICIT_CAPACITY_AXIOMS

finite horizon:
    R=2M as continuation-capacity exhaustion surface

V10 exact Schwarzschild:
    restored in this limited sector
```

The SFT interpretation of the horizon:

```text
R=2M is the areal shell where continuation capacity A reaches zero.
```

---

# 6. What is not restored

This does not solve:

```text
Kerr / rotating black holes
dynamic collapse
ringdown
gravitational radiation
black-hole thermodynamics
horizon microphysics
interior continuation
```

Those remain frontier gates.

---

# 7. Hostile loophole

The main loophole is readout nonlinearity:

```text
linear hidden ledger L(C)=2C
but metric A=f[L(C)]
```

could reintroduce q-like terms without changing microscopic footprint cost.

GC-2J-R3 closes that loophole only if SFT defines:

```text
A = the continuation-capacity fraction itself
```

not merely a nonlinear display of capacity.

This is the explicit axiom dependency.

---

# 8. Gate scores

```text
Opus universal-footprint route:
    PASS_IF_A_IS_CAPACITY

5.6 additivity route:
    PASS_IF_CAPACITY_ADDITIVE

q=0 selection:
    PASS_WITH_EXPLICIT_AXIOM

Schwarzschild restoration:
    CONDITIONAL_RESTORATION

readout nonlinearity:
    OPEN_UNLESS_A_DEFINED_AS_CAPACITY

final:
    STATIC_SPHERICAL_SCHWARZSCHILD_DERIVED_WITH_CAPACITY_AXIOMS
```

---

# 9. Updated strong-field status

Before R1:

```text
exact Schwarzschild downgraded
```

After R1:

```text
Schwarzschild one-speed compatibility rescued
```

After R2:

```text
native areal-shell theorem path identified
```

After R3:

```text
static spherical Schwarzschild restored if continuation capacity A is the literal capacity readout
```

This is the strongest honest restoration available.

---

# 10. Public wording

Allowed:

```text
In the static spherical sector, SFT recovers exact Schwarzschild when the areal-shell continuation capacity is taken as the metric lapse capacity itself. Universal one-footprint write mechanics forces linear capacity consumption, A=1-2M/R, and the horizon is the surface where continuation capacity is exhausted.
```

Forbidden:

```text
SFT has solved all black-hole physics.
```

or:

```text
Kerr, ringdown, and horizon microphysics are complete.
```

---

# 11. Verdict string

```text
SFT_V13_1_V2_GC2J_R3_AREAL_CAPACITY_LAW_STATIC_SPHERICAL_SCHWARZSCHILD_RESTORED_WITH_EXPLICIT_CAPACITY_AXIOMS_UNIVERSAL_FOOTPRINT_AND_ADDITIVE_NO_CROSS_TERM_FORCE_Q0_A_EQUALS_1_MINUS_2M_OVER_R_HORIZON_AS_CONTINUATION_CAPACITY_EXHAUSTION_KERR_RADIATION_DYNAMICS_OPEN
```
