# GC2A Opus/Public Narrative Handoff Seed

## Public section title

**What SFT says gravity is sourced by**

## Clean public claim

SFT does not begin gravity with a separate gravitational substance. It begins with locally real systems that must keep writing themselves into history. Energy measures how rapidly that maintenance must be written. A freely propagating photon writes its energy outward at c; a massive particle is photon-like support caught in closure, so the same energy is maintained locally. Matter, radiation, pressure, internal energy, and binding all enter as active write demand.

## Must include

- Energy as write rate, not extra per-write deposit.
- Closed photon / locally real particle as localized maintenance.
- Radiation has double active source because outward momentum/pressure participates.
- Newtonian scalar acceleration is only the first projection.
- SFT does not claim the numerical value of G is derived in this section.

## Must not say

- "SFT derives the full Einstein equation here."
- "SFT derives G from first principles."
- "Settlement scalar alone is gravity."
- "Radiation factor is imported from GR without native explanation."

## Public boundary sentence

This section identifies the source of gravitational settlement in SFT. The later sections explain why that source produces a metric-like response rather than only a scalar potential.
