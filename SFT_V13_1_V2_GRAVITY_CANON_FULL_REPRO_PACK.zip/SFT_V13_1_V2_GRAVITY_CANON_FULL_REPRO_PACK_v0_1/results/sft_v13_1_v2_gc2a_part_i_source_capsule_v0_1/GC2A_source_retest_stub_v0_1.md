# GC2A Retest Stub — Source Side

## Immediate retests

### R-S1: Newtonian exterior scalar projection
Input:
```text
C_A(E,r)=A_write E/(hbar c r)
A_write=G hbar/c^3
E=Mc^2
a=-c^2 grad C_A
```

Expected:
```text
C_A=GM/(c^2 r)
|a|=GM/r^2
```

Status:
```text
trivial algebraic PASS, but A_write numerical value remains calibrated/open.
```

### R-S2: radiation active factor
Input:
```text
epsilon+3p
p=w epsilon
```

Expected:
```text
matter: w=0 -> 1
radiation: w=1/3 -> 2
```

Status:
```text
algebraic PASS; microscopic pressure/write derivation still needs covariant completion.
```

### R-S3: compatibility with projector partition
Input:
```text
one write = one footprint
I4 = Pi_set + Pi_cont
```

Expected:
```text
source is write rate; projector handles response, not extra energy split.
```

Status:
```text
conceptual PASS; lane response moved to GC2B/GC2C.
```
