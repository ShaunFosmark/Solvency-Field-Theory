# SFT V13.1-V2 GC-2A — Part I Source Capsule Draft v0.1

## Part I title

**The Source: locally real writes, active operation density, and why energy gravitates**

## Status

```text
GC-2A_DRAFT_NOT_FINAL
```

This is the first capsule draft for the derivation canon. It is not the public Zenodo narrative and not a final freeze.

## Claim boundary

This section does **not** claim the full metric theory. It only earns the source side:

```text
what writes gravity?
what does energy mean in write language?
why does radiation gravitate differently from cold matter?
how does this remain compatible with the locally real particle stack?
```

The scalar field, tensor/lane promotion, one-speed metric closure, and weak-field PPN recovery come later.

---

# 1. ATTACK

The attack is direct:

> SFT says gravity comes from settlement, but "settlement" risks becoming a renamed mass field. If mass-energy is simply imported from relativity, then SFT has not derived gravity from its locally real particle. Worse, if photons and pressure gravitate only because GR says they do, then the source side is not native. The entire gravity program is hanging on an imported stress-energy tensor.

If this attack lands, V13.1-V2 fails before light bending. SFT would have a gravity *readout*, not a gravity source.

---

# 2. STAKES

If Part I fails:

```text
- C_A(E,r) is just a fitted Newtonian potential.
- rho_active is imported rather than native.
- radiation's source role is unearned.
- closed photons / particles do not naturally source gravity.
- the particle-to-star ladder in V13.1 becomes narrative, not mechanism.
- SPARC/DESI/far-field claims stand on an unearned source.
```

So Part I must show:

```text
locally real particle
→ irreversible writes
→ write rate
→ energy as rate of writes
→ active operation density
→ settlement demand
→ gravity source
```

---

# 3. CAPSULE — minimal re-derivation path

## 3.1 One write is one footprint

The V13.8-compatible rule is:

```text
per write: one universal footprint is deposited
per unit time: energy controls how many writes occur
```

Therefore energy is not a second factor in the per-write deposit. Energy is the rate of deposition.

Reduced/radian write rate:

```text
dN_hbar/dt = E / hbar
```

Full-cycle write rate:

```text
dN_h/dt = E / h
```

with the convention relation:

```text
A_h dN_h = A_hbar dN_hbar
A_h = 2pi A_hbar
```

This prevents double-counting energy.

## 3.2 Exterior compactness readout

For a localized source of energy E, the minimal retarded exterior settlement readout is:

```text
C_A(E,r) = A_write E / (hbar c r)
```

For a continuous source:

```text
C_A(x,t) = A_write ∫ [rho_E(y, t - |x-y|/c)] / [hbar c |x-y|] d^3y
```

If the readout-normalized identification is supplied,

```text
A_write = G hbar / c^3
```

and if E = M c^2, then

```text
C_A = GM/(c^2 r)
```

and the scalar acceleration readout gives

```text
a = -c^2 ∇C_A
|a| = GM/r^2
```

This earns the Newtonian exterior projection, not the full relativistic theory.

## 3.3 Active operation density

A cold source spends most of its causal budget in local closure/maintenance. Radiation spends its causal budget outward. In source bookkeeping, pressure contributes because directed momentum flux imposes settlement demand.

The native source continuity target is:

```text
rho_ops ∝ epsilon + 3p
```

or in mass-density units,

```text
rho_active = rho_rest + u_int/c^2 + rho_rad + 3p/c^2 + rho_bind
```

For a perfect fluid with equation of state:

```text
p = w epsilon
```

the source factor is:

```text
epsilon + 3p = epsilon (1 + 3w)
```

Cold matter:

```text
w = 0
source factor = 1
```

Radiation:

```text
w = 1/3
source factor = 2
```

This is the source-side factor of two: radiation gravitates with double active weight relative to its energy density because its entire c-budget is outward momentum/pressure flux.

## 3.4 Closed photon / locally real particle reading

A locally real massive particle is not a new substance. It is energy caught in closure: photon-like/null support whose c-budget is folded into local maintenance rather than freely propagating outward.

So the source rule is:

```text
open photon:
    energy writes outward; radiation pressure contributes

closed photon / massive particle:
    same energy maintains local closure; source is localized

star / body:
    accumulated closure maintenance and internal/binding/radiation ledgers
```

The source is therefore not "mass because mass." It is write maintenance rate.

## 3.5 Compatibility with projector partition

The write operator is:

```text
W = irreversible write + (Pi_set, Pi_cont) + no-overwrite admissibility
```

with:

```text
I4 = Pi_set + Pi_cont
Tr(I4)=4
Tr(Pi_set)=3
Tr(Pi_cont)=1
P_dir = 3/4
eta_I = 1/4
```

Part I does not yet use the projector partition to derive the metric. It only requires that the source be a write stream compatible with the projector framework. Metric/lane response is Part III/IV.

---

# 4. STATUS LINE

```text
SOURCE_SIDE_STATUS:
    PARTIAL_EARNED_COMPATIBLE

EARNED:
    energy-as-write-rate rule
    Newtonian exterior scalar readout if A_write supplied
    rho+3p source continuity
    radiation double active source
    compatibility with closed/open photon picture

SELECTED / CALIBRATED:
    numerical value of A_write or G is not derived here

OPEN:
    exact microscopic deposition kernel K_set
    full covariant stress tensor
    self-gravitating-body equivalence / dipole radiation gate
    binding-energy sign and ledger convention for all composite systems
```

---

# 5. LIVE EDGES

## G-SEP — equivalence / dipole gate

Question:

```text
Does the five-component active source preserve equivalence for self-gravitating bodies and suppress forbidden scalar dipole radiation?
```

Kill condition:

```text
If SFT predicts composition-dependent free fall or scalar dipole loss at ruled-out levels, the source program fails.
```

## G-RAD link

The source rule must feed the later radiation/polarization gate without creating a scalar breathing mode at detectable levels.

## G-alpha link

Part I supplies the energy/write source. It does not derive gamma=1. That happens only after tensor/lane promotion and one-speed closure.

---

# 6. Referee intuition check

Does this match the physical picture?

```text
energy is not a substance sitting in space;
energy is how frequently the system must write.
a photon writes outward at c;
a closed photon writes locally in maintenance;
a body is accumulated local maintenance;
gravity is the settlement demand of that writing.
```

If yes, Part I can proceed to GC-2B.

If no, the source language must be corrected before any metric claim is rebuilt.
