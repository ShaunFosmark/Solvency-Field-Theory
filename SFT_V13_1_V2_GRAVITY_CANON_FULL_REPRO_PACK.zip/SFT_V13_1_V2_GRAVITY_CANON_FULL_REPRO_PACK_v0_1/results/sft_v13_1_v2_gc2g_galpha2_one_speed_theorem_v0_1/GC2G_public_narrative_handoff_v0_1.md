# GC2G Public Narrative Handoff — Carefully Worded

## Strong public sentence

In the weak-field metric sector, light bends by the full factor because the same one-speed budget that closes the locally real particle also closes the gravitational metric. Settlement debits the continuation lane as clock lag and credits each spatial settlement lane reciprocally; this forces F B = 1, alpha = 1, and gamma = 1.

## More poetic version

The particle and its field are not separate inventions. The one-speed budget that makes energy real also fixes how gravity deforms time and space. Clock lag and spatial closure are reciprocal faces of the same write constraint.

## The sentence Shaun wants, with boundary

Light bends by the full factor because the same constraint that defines mass — energy at c — also defines the weak-field gravitational metric. The particle and its field are one object at the level of the one-speed write budget. In that sector, gamma = 1 is not a parameter of SFT; it is a theorem of one-speed closure.

## Required boundary sentence

This result is a weak-field metric-sector theorem. It does not by itself complete strong-field horizons, gravitational radiation, frame dragging, binary-pulsar decay, or the numerical value of G.
