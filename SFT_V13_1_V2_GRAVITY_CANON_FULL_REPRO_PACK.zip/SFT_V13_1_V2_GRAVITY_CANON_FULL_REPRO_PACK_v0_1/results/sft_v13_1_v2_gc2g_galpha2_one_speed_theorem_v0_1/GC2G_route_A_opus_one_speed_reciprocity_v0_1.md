# GC2G / G-alpha-2A — Opus Route: One-Speed Budget as Metric Reciprocity

## Verdict

```text
PASS_DERIVED_FROM_FOUNDING_AXIOM_IF_METRIC_APPLICATION_ACCEPTED
```

## Attack

The remaining G-alpha attack after GC-2F was:

> Lane democracy may just be a new assumption. Why must q_s = q_t?

## Answer

Lane democracy is not the primitive. The primitive is the one-speed budget.

SFT's founding axiom says that real support exhausts one invariant causal budget c. Settlement may redistribute how the budget is read between continuation and spatial settlement, but it cannot change the budget itself.

GC-2B earned the continuation/clock-lag side:

```text
F = exp(-q_t phi)
```

If clocks slow by F, then applying the same one-speed budget to the metric requires the spatial readout to compensate reciprocally:

```text
B = 1/F
```

so:

```text
F B = 1
```

Now use the lane exponent form:

```text
B = exp(q_s phi)
F = exp(-q_t phi)
```

Then:

```text
F B = exp[(q_s - q_t) phi]
```

For this to equal 1 for arbitrary settlement strength phi:

```text
q_s = q_t
```

Therefore:

```text
alpha = q_s/q_t = 1
gamma = 1
```

## Meaning

The same constraint that closes the particle also closes the metric.

```text
energy at c
→ one-speed budget
→ reciprocal metric response
→ F B = 1
→ q_s = q_t
→ alpha = 1
→ gamma = 1
```

## Status

This upgrades G-alpha if the derivation canon ratifies:

```text
the one-speed budget applies to metric lane response, not only internal particle motion.
```

That is not a new physical principle; it is the metric statement of the existing one.
