# SFT V13.1-V2 GC-2G / G-alpha-2 — One-Speed Theorem Adjudication v0.1

## Status

```text
GC2G_GALPHA2_PASS_STATUS_UPGRADE_WITH_EXPLICIT_AXIOM_DEPENDENCY
```

## Central result

The strongest route is the Opus route:

```text
Lane democracy is the one-speed budget applied to the metric.
```

The 5.6 no-preferred-lane route is a supporting route:

```text
No-overwrite / local relabeling symmetry makes the compensation equal across the three spatial settlement lanes.
```

Together they produce the upgrade:

```text
alpha = 1
from: CONDITIONAL_EARNED_FROM_LANE_DEMOCRACY
to: DERIVED_FROM_FOUNDING_ONE_SPEED_AXIOM_IF_METRIC_APPLICATION_RATIFIED
```

## 1. The decisive derivation

Start with the one-speed budget:

```text
real support preserves one invariant causal budget c
```

Settlement slows the continuation/clock lane:

```text
F = exp(-q_t phi)
```

If the same support must still preserve the one-speed budget through settlement geometry, spatial closure must compensate reciprocally:

```text
B = 1/F
```

Therefore:

```text
F B = 1
```

But in lane-exponent form:

```text
B = exp(q_s phi)
F = exp(-q_t phi)
```

so:

```text
F B = exp[(q_s-q_t) phi]
```

For arbitrary phi:

```text
q_s = q_t
```

Therefore:

```text
alpha = q_s/q_t = 1
gamma = 1
```

## 2. Projector translation

The V13.8 partition says:

```text
I4 = Pi_settlement + Pi_continuation
Tr(Pi_settlement)=3
Tr(Pi_continuation)=1
```

The continuation lane is debited:

```text
-phi
```

Each settlement lane is credited:

```text
+phi
```

The weak metric perturbation schematic becomes:

```text
h ∝ 2 phi diag(-1,+1,+1,+1)
```

The total spatial trace is three times the time-lane magnitude:

```text
3:1
```

but the PPN gamma compares one spatial lane to the time lane:

```text
gamma = 1
```

## 3. Why q_s/q_t != 1 fails

If:

```text
q_s/q_t != 1
```

then:

```text
F B = exp[(q_s-q_t) phi] != 1
```

for nonzero phi.

That means settlement changes the local null budget instead of redistributing it.

In SFT language, this violates the same one-speed constraint that defines the particle.

## 4. What is now earned

```text
F B = 1
alpha = 1
gamma = 1
factor-of-two light bending
```

are no longer merely selected by matching weak-field GR.

They are derived from:

```text
one-speed budget
+ settlement clock lag
+ metric application of budget conservation
+ no-preferred-lane symmetry
```

## 5. Remaining honesty boundary

This does not complete:

```text
full covariant field equations
strong-field horizons
frame dragging
gravitational-wave polarizations
binary-pulsar radiation reaction
numerical value of G
```

## 6. Public sentence candidate

Approved with one boundary phrase:

> In the weak-field metric sector, light bends by the full factor because the same one-speed budget that closes the locally real particle also closes the gravitational metric: settlement debits the continuation lane and credits each spatial settlement lane reciprocally, forcing F B = 1, alpha = 1, and gamma = 1.

Do not yet say:

```text
SFT has completed all of relativistic gravity.
```

## 7. Verdict string

```text
SFT_V13_1_V2_GC2G_GALPHA2_ONE_SPEED_THEOREM_PASS_ALPHA1_GAMMA1_DERIVED_FROM_FOUNDING_ONE_SPEED_AXIOM_IF_METRIC_APPLICATION_RATIFIED_NO_PREFERRED_LANE_SUPPORTS_SPATIAL_DEMOCRACY_FULL_GRAVITY_FRONTIER_STILL_OPEN
```
