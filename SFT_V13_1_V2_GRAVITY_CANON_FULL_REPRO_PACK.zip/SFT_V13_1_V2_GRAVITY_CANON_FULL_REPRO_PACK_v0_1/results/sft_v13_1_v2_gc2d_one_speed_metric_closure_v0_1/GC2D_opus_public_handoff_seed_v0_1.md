# GC2D Opus/Public Narrative Handoff Seed

## Public section title

**Why SFT does not bend light by half**

## Public claim

The scalar settlement field by itself would only slow clocks. That would be insufficient. SFT's weak-field closure adds the reciprocal spatial response required by the one-speed budget: if local clock capacity is reduced by settlement, spatial path capacity expands reciprocally. In the weak field this gives γ=1, so light bending and Shapiro delay receive the full factor of two.

## Must include

- The scalar-only attack is valid and serious.
- SFT answers it with F=e^-φ and B=e^φ.
- γ=1 and β=1 are recovered in the weak-field closure.
- α=1 is currently selected/recovered by the weak-field gate, not yet derived from the deepest write operator.

## Must not say

- "SFT has derived α=1 from first principles" unless G-alpha later passes.
- "SFT has completed GR."
- "SFT has solved waves/frame dragging/strong fields."
