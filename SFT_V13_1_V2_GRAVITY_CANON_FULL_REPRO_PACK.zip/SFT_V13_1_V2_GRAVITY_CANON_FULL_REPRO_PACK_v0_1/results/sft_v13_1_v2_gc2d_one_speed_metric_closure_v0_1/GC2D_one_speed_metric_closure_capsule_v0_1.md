# SFT V13.1-V2 GC-2D — One-Speed Metric Closure Capsule v0.1

## Part IV title

**The Graveyard Gate: one-speed closure, γ = 1, and the full light-bending factor**

## Status

```text
GC-2D_DRAFT_RETESTED_WEAK_FIELD_CLOSURE_PASS_ALPHA1_SELECTED_NOT_DERIVED
```

This is the first full graveyard gate in V13.1-V2.

GC-2A earned the source side.  
GC-2B earned the scalar/Newtonian projection.  
GC-2C earned the tensor/lane promotion bridge.  

GC-2D now asks whether the weak-field closure gives the right metric skeleton:

```text
γ = 1
β = 1
light/Shapiro factor = 2
perihelion numerator = 3
```

It does, for the one-speed reciprocal closure:

```text
F = e^-φ
B = e^φ
F B = 1
```

But the status boundary is essential:

```text
α = 1 is selected/recovered by the weak-field closure gate here.
The deeper write-operator derivation of α = 1 remains G-alpha.
```

---

# 1. ATTACK

The graveyard attack:

> A scalar settlement field bends light by half. If SFT maps gravity only to clock lag, it predicts γ = 0, not γ = 1. Eddington kills it. Cassini buries it. A scalar theory can mimic Newtonian acceleration but not the full weak-field metric.

The scalar-only metric would have:

```text
spatial curvature γ = 0
light/Shapiro factor = 1 + γ = 1
ratio to GR = 1/2
```

That is death.

---

# 2. STAKES

If this gate fails:

```text
- SFT dies at the 1919 light-bending/factor-of-two test;
- V10/V11 Schwarzschild-like claims were accidental;
- Bullet/cluster lensing readings are unearned;
- SPARC/DESI gravity cannot be trusted as relativistic gravity;
- the current stack's scalar-only presentation is externally fatal.
```

If this gate passes but overclaims:

```text
- Cassini is treated as derived when α=1 was only selected;
- lane-democracy is skipped;
- the next reviewer catches the missing mechanism.
```

So this section must do both:

```text
recover the weak-field numbers
and refuse to call α=1 fully derived.
```

---

# 3. CAPSULE — minimal re-derivation path

## 3.1 Closure definitions

Let the scalar compactness/lag variable be:

```text
φ = GM/(c²r)
```

Define the lapse/clock factor:

```text
F = e^-φ
```

and the spatial closure factor:

```text
B = e^(αφ)
```

The metric skeleton is:

```text
ds² = -F² c²dt² + B² (dx²+dy²+dz²)
```

For α = 1:

```text
B = e^φ
F B = 1
```

Numeric identity retest:

```text
max |F B - 1| over φ∈[0,10] = 2.220e-16
```

## 3.2 Weak-field expansion

For the time part:

```text
F² = e^-2φ
   ≈ 1 - 2φ + 2φ² + O(φ³)
```

so:

```text
β = 1
```

For the spatial part:

```text
B² = e^(2αφ)
   ≈ 1 + 2αφ + O(φ²)
```

so:

```text
γ = α
```

Therefore:

```text
α = 1 -> γ = 1
```

## 3.3 Light/Shapiro factor

Weak-field light bending and Shapiro delay carry the factor:

```text
1 + γ
```

Scalar time-only gravity:

```text
γ = 0
1 + γ = 1
ratio to GR = 1/2
```

One-speed reciprocal closure:

```text
γ = 1
1 + γ = 2
ratio to GR = 1
```

This is the factor-of-two gate.

## 3.4 Perihelion skeleton

The PPN perihelion numerator is:

```text
2 + 2γ - β
```

For α = 1:

```text
γ = 1
β = 1
2 + 2γ - β = 3
```

GR target:

```text
3
```

Ratio:

```text
1
```

---

# 4. NUMERIC RETEST

| test | expected | measured | verdict |
|---|---:|---:|---|
| F B identity error | 0 | 2.220e-16 | PASS |
| γ | 1 | 1.000000000000 | PASS |
| β | 1 | 1.000000000000 | PASS |
| light/Shapiro factor | 2 | 2.000000000000 | PASS |
| light deflection ratio to GR | 1 | 1.000000000000 | PASS |
| perihelion numerator | 3 | 3.000000000000 | PASS |
| perihelion ratio to GR | 1 | 1.000000000000 | PASS |
| fitted series γ | 1 | 0.999999997816 | PASS |
| fitted series β | 1 | 0.999918424573 | PASS |

Verdict:

```text
PASS_WEAK_FIELD_ONE_SPEED_CLOSURE
```

---

# 5. ALPHA SWEEP

The closure family:

```text
B = e^(αφ)
```

gives:

```text
γ = α
```

Therefore:

| α | γ | light factor | deflection ratio | perihelion ratio | status |
|---:|---:|---:|---:|---:|---|
| 0.0 | 0.0 | 1.0 | 0.500 | 0.333 | FAIL_WEAK_FIELD_TARGET |
| 0.5 | 0.5 | 1.5 | 0.750 | 0.667 | FAIL_WEAK_FIELD_TARGET |
| 1.0 | 1.0 | 2.0 | 1.000 | 1.000 | PASS_WEAK_FIELD |
| 1.5 | 1.5 | 2.5 | 1.250 | 1.333 | FAIL_WEAK_FIELD_TARGET |
| 2.0 | 2.0 | 3.0 | 1.500 | 1.667 | FAIL_WEAK_FIELD_TARGET |

The weak-field data select α = 1.

But selection is not the same as internal derivation.

---

# 6. STATUS LINE

```text
ONE_SPEED_CLOSURE_STATUS:
    WEAK_FIELD_PASS
    ALPHA1_SELECTED_NOT_YET_DERIVED_FROM_WRITE_OPERATOR

EARNED:
    reciprocal closure F=e^-φ, B=e^φ gives F B=1
    γ = 1
    β = 1
    light/Shapiro factor = 2
    scalar half-deflection failure is avoided
    perihelion weak-field numerator = 3

SELECTED:
    α = 1 among closure exponents because it alone lands the weak-field metric target

OPEN:
    G-alpha derivation of α = 1 from lane-democratic deposition
    full covariant field equation
    direct trajectory rerun as GC-2E / Gate 05 recovery
    strong-field reconciliation with V10 Schwarzschild vs exponential closure
```

---

# 7. LIVE EDGE — G-alpha

The next physical derivation target is not another coefficient fit. It is:

```text
Can the write operator force α = 1?
```

Candidate mechanism:

```text
one universal footprint per write
equal lane-democratic deposition
continuation-lane debit
settlement-lane spatial credit
```

Target:

```text
h ∝ 2φ diag(-1,+1,+1,+1)
```

If this works:

```text
γ = 1 becomes predicted by write geometry.
```

If it fails:

```text
γ = 1 remains selected/calibrated by weak-field dynamics.
```

---

# 8. Referee intuition check

Does this match the physical picture?

```text
Scalar settlement slows clocks.
One-speed closure says the lost local clock capacity appears as reciprocal spatial path capacity.
Light reads both.
So the photon does not receive half the effect.
It follows the straightest available null path through a closure geometry where time lag and spatial closure are locked.
```

If yes, GC-2D survives the graveyard gate.

If no, do not proceed to public gravity claims.
