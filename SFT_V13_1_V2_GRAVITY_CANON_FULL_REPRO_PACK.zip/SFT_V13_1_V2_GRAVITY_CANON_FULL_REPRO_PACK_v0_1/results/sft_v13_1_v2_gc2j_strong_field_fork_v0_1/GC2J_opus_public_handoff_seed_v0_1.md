# GC2J Opus/Public Narrative Handoff Seed

## Public section title

Where SFT stops: strong fields and horizons

## Public claim

SFT's current gravity canon earns the weak-field metric behavior needed for light bending, time delay, and perihelion recovery. It does not yet earn an exact black-hole solution. The exponential one-speed closure and exact Schwarzschild geometry agree in the weak field but diverge near horizons: Schwarzschild has a finite event horizon, while the exponential closure has no finite lapse-zero surface. This is a registered strong-field fork, not a solved sector.

## Must include

- Weak-field recovery remains earned.
- Exact strong-field Schwarzschild is not currently carried as a live claim.
- Exponential closure has no finite lapse-zero horizon.
- Strong-field observables include shadows, ringdown, echoes, accretion signatures, and thermodynamics.

## Must not say

- SFT derives black holes.
- SFT has exact Schwarzschild.
- SFT predicts horizonless objects as a final claim.
- Strong-field behavior is solved.
