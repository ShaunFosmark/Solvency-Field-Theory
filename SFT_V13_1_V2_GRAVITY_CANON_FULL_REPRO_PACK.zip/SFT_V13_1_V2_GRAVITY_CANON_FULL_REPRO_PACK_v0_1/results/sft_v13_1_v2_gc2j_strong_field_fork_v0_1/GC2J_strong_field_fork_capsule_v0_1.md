# SFT V13.1-V2 GC-2J / T1 - Strong-Field Fork v0.1

## Status

```text
GC-2J_STRONG_FIELD_FORK_OPEN_WEAK_FIELD_PASS_EXACT_SCHWARZSCHILD_DOWNGRADED_PENDING_RECONCILIATION
```

GC-2D through GC-2G rebuilt the weak-field metric sector and survived the factor-of-two light-bending gate.

GC-2J asks a different question:

```text
Can the one-speed exponential closure and V10 exact Schwarzschild both be exact in the strong field?
```

Answer:

```text
No - not without an additional transition/reconciliation mechanism.
```

They agree in the weak field. They diverge near the horizon.

## 1. Attack

The attack:

> Exponential closure F=e^-phi never reaches zero at finite radius. Schwarzschild has a finite event horizon. V10 claimed exact Schwarzschild recovery. These cannot both be right in the strong field.

This attack lands.

But it does not kill the weak-field program. It creates a strong-field fork.

## 2. Capsule comparison

Use isotropic coordinate rho and u=M/rho.

Exponential one-speed closure:

```text
F_exp = e^-u
B_exp = e^u
ds^2 = -F_exp^2 dt^2 + B_exp^2(drho^2+rho^2 dOmega^2)
```

Schwarzschild in isotropic coordinates:

```text
F_Schw = (1-u/2)/(1+u/2)
B_Schw = (1+u/2)^2
```

## 3. Weak-field agreement

Time coefficient:

```text
A_exp = e^-2u ~= 1 - 2u + 2u^2 - 4u^3/3 + ...
A_Schw ~= 1 - 2u + 2u^2 - 3u^3/2 + ...
```

They agree through the beta=1 weak-field term.

Spatial coefficient:

```text
S_exp = e^2u ~= 1 + 2u + 2u^2 + ...
S_Schw = (1+u/2)^4 ~= 1 + 2u + 3u^2/2 + ...
```

They agree at first order, preserving gamma=1.

They diverge beyond the weak-field PPN skeleton.

## 4. Horizon diagnostic

| model | finite lapse-zero horizon | horizon location |
|---|---|---|
| Schwarzschild | yes | rho=M/2, R=2M |
| Exponential closure | no finite rho | F=e^-M/rho only reaches zero as rho approaches 0 |

Verdict:

```text
FAIL_AS_EXACT_STRONG_FIELD_EQUIVALENCE
```

## 5. Photon-sphere / shadow diagnostic

For isotropic null paths, the exponential closure has critical impact parameter:

```text
b_exp(rho) = rho e^(2M/rho)
```

Minimum occurs at:

```text
rho = 2M
```

so:

```text
b_exp = 2e M = 5.436563656918 M
```

Schwarzschild reference:

```text
b_Schw = 3 sqrt(3) M = 5.196152422707 M
```

Relative difference:

```text
4.627%
```

This is not a final prediction. It is a diagnostic of the fork.

## 6. Resolution options

```text
T1-A:
    exponential closure is physical strong field.
    Status: OPEN_HIGH_RISK.

T1-B:
    exponential closure is weak-field chart only;
    nonlinear settlement / horizon stock transitions to Schwarzschild-like strong field.
    Status: OPEN_RECONCILIATION_REQUIRED.

T1-C:
    domain split; V13.1-V2 claims weak field only.
    Status: RECOMMENDED_PUBLIC_BOUNDARY.

T1-D:
    retire/rewrite V10 exact Schwarzschild strong-field claim.
    Status: POSSIBLE_IF_NO_RECONCILIATION.
```

## 7. Status line

```text
STRONG_FIELD_STATUS:
    WEAK_FIELD_AGREEMENT_EARNED
    EXACT_SCHWARZSCHILD_STRONG_FIELD_NOT_CARRIED
    EXPONENTIAL_HORIZONLESS_ROUTE_OPEN_HIGH_RISK
    STRONG_FIELD_FORK_REGISTERED

EARNED:
    weak-field beta=1 and gamma=1 agreement
    direct weak-field trajectory recovery from prior gates

NOT EARNED:
    finite event horizon
    exact Schwarzschild exterior
    ringdown spectrum
    merger radiation reaction
    EHT shadow match
    black-hole thermodynamics
```

## 8. Public canon rule

The public paper may say:

```text
SFT recovers the weak-field Schwarzschild/PPN behavior needed for light bending, time delay, and perihelion tests.
```

It may not say:

```text
SFT has derived exact Schwarzschild black holes.
```

unless T1-B or a later strong-field derivation passes.

## 9. Verdict string

```text
SFT_V13_1_V2_GC2J_STRONG_FIELD_FORK_REGISTERED_WEAK_FIELD_EXPONENTIAL_AND_SCHWARZSCHILD_AGREE_TO_PPN_TARGETS_EXACT_STRONG_FIELD_EQUIVALENCE_FAILS_HORIZON_BEHAVIOR_DIVERGES_V10_EXACT_SCHWARZSCHILD_DOWNGRADED_PENDING_RECONCILIATION_PUBLIC_CANON_BOUNDARY_SET
```
