# GC2J-R2 Opus/Public Handoff Seed

## Public section title

A native path to Schwarzschild, but not yet a restoration

## Public claim

SFT has a natural reason to use areal radius in spherical strong fields: a write boundary is a physical two-sphere with area 4πR². In that native shell variable, Schwarzschild satisfies radial one-speed reciprocity exactly. If SFT can derive the exterior capacity law A(R)=1-2M/R from no-overwrite shell accounting, then exact Schwarzschild follows. But this final capacity law is not yet derived. One-speed reciprocity alone admits many strong-field metrics.

## Must include

- Areal radius is the plausible native shell variable.
- Schwarzschild has a native restoration path.
- The missing theorem is A(R)=1-2M/R from shell capacity.
- One-speed reciprocity alone is non-unique.
- Downgrade softened, not reversed.

## Must not say

- Exact Schwarzschild is restored.
- SFT derives black holes.
- The exponential metric is irrelevant.
- Coordinate choice alone proves the metric.
