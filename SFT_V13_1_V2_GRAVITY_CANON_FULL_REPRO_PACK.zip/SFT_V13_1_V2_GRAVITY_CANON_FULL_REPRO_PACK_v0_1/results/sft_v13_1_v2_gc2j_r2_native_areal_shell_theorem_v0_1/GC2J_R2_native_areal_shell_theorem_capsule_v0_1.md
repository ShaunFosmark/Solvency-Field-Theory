# SFT V13.1-V2 GC-2J-R2 — Native Areal-Shell Theorem Attempt v0.1

## Status

```text
GC2J_R2_CONDITIONAL_THEOREM_PATH_IDENTIFIED_DOWNGRADE_SOFTENED_NOT_REVERSED
```

## Question

Can SFT restore V10 exact Schwarzschild by showing that the native write-shell coordinate is the areal radius?

## Result

A native route exists, but the proof is not complete.

This gate identifies the missing theorem precisely:

```text
Areal-shell capacity law:
    exterior vacuum continuation capacity A(R) = 1 - 2M/R
```

If that law is derived from no-overwrite/write-surface accounting, exact Schwarzschild follows.

But one-speed reciprocity alone does not force it.

---

# 1. What R1 rescued

GC-2J-R1 showed:

```text
Schwarzschild is one-speed-compatible in areal coordinates.
```

In areal radius R:

```text
ds² = -A(R)dt² + A(R)^-1dR² + R²dΩ²
```

with:

```text
A(R)=1-2M/R
```

Then:

```text
F sqrt(g_RR)=1
```

So Schwarzschild is not hostile to one-speed closure.

---

# 2. Native shell argument

SFT has a strong reason to prefer areal radius:

```text
a spherical write boundary is measured by its area
Area = 4πR²
```

No-overwrite accumulation in a spherical exterior naturally counts shells by physical boundary area, not by isotropic coordinate spacing.

Therefore:

```text
R = native shell label
```

is plausible.

This is a real improvement over the raw GC-2J fork.

---

# 3. Conditional derivation

If the following are accepted:

```text
1. native shell variable is areal radius R
2. exterior compactness is C=M/R
3. radial one-speed reciprocity gives g_RR=1/A(R)
4. exterior vacuum capacity law gives A(R)=1-2M/R
```

then:

```text
ds² = -(1-2M/R)dt² + (1-2M/R)^-1dR² + R²dΩ²
```

which is exact Schwarzschild.

So V10 has a clear restoration path.

---

# 4. Hostile failure: non-uniqueness

The dangerous point:

```text
one-speed radial reciprocity does not uniquely select A(R)
```

A whole family:

```text
A_q(C)=1-2C+qC²
g_RR=1/A_q
```

has radial reciprocity and the same first-order compactness behavior, but different strong-field physics.

Therefore the decisive missing step is not reciprocity.

It is:

```text
why q=0?
why exact linear capacity A=1-2C?
```

That is the areal-shell capacity theorem.

---

# 5. Gate scores

```text
areal radius nativity:
    PASS_PLAUSIBLE

radial reciprocity:
    PASS_CONDITIONAL

Schwarzschild form:
    CONDITIONAL_PASS

uniqueness:
    FAIL

downgrade status:
    SOFTENED_NOT_REVERSED

final:
    CONDITIONAL_THEOREM_PATH_IDENTIFIED
```

---

# 6. Updated strong-field status

Old:

```text
exact Schwarzschild downgraded
```

After R1:

```text
Schwarzschild is one-speed-compatible, but not derived
```

After R2:

```text
Schwarzschild has a native SFT theorem path through areal shell accounting,
but the decisive capacity law A=1-2M/R remains open.
```

So the downgrade is softened again.

It is not reversed.

---

# 7. Next theorem target

```text
GC2J-R3:
Areal-shell capacity law
```

Required proof:

```text
No-overwrite spherical shell accounting
+ exterior source compactness C=M/R
+ finite continuation exhaustion at 2M
=> A(R)=1-2M/R
```

If R3 passes, V10 exact Schwarzschild can be restored.

If R3 fails, the public canon remains weak-field only.

---

# 8. Public wording

Allowed:

```text
Exact Schwarzschild is compatible with SFT's one-speed budget and has a native restoration path if areal shell accounting yields A=1-2M/R.
```

Forbidden:

```text
SFT has derived exact Schwarzschild black holes.
```

---

# 9. Verdict string

```text
SFT_V13_1_V2_GC2J_R2_NATIVE_AREAL_SHELL_THEOREM_ATTEMPT_CONDITIONAL_PATH_IDENTIFIED_AREAL_RADIUS_NATIVE_PLAUSIBLE_RADIAL_RECIPROCITY_PASS_SCHWARZSCHILD_FOLLOWS_IF_CAPACITY_LAW_A_EQUALS_1_MINUS_2M_OVER_R_DERIVED_UNIQUENESS_FAILS_DOWNGRADE_SOFTENED_NOT_REVERSED
```
