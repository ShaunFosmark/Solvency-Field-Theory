# SFT V13.1-V2 GC-2E — Direct Trajectory Recovery Capsule v0.1

## Part IV continuation

**Do not trust coefficients alone: direct null and timelike paths through the closure geometry**

## Status

```text
GC-2E_DRAFT_DIRECT_TRAJECTORY_RETEST_PASS_WEAK_FIELD
```

GC-2D recovered the weak-field metric coefficients:

```text
F=e^-φ
B=e^φ
γ=1
β=1
light/Shapiro factor=2
perihelion numerator=3
```

GC-2E asks whether the same closure geometry reproduces the behavior dynamically, by integrating paths through it.

This is still weak-field. It is not a strong-field/horizon claim.

---

# 1. ATTACK

The attack:

> Coefficient matching can fool you. You can write down γ=1 in a PPN table and still not have a self-consistent trajectory rule. If SFT only matches symbols but does not propagate null and timelike paths correctly, the factor-of-two win is bookkeeping, not physics.

So GC-2E integrates trajectories directly.

---

# 2. STAKES

If GC-2E fails:

```text
- GC-2D's coefficient recovery is suspect;
- light-bending remains a paper match rather than path dynamics;
- perihelion recovery is not re-earned;
- V13.1-V2 cannot claim the old trajectory gate was pulled forward.
```

If GC-2E passes:

```text
- the weak-field closure is not merely coefficient bookkeeping;
- null paths read the same factor-of-two geometry;
- timelike bound orbits recover the weak perihelion skeleton.
```

---

# 3. NULL CAPSULE

For a static isotropic metric,

```text
ds² = -F² dt² + B² dℓ²
```

null rays follow the optical index

```text
n = B/F
```

With the closure family,

```text
F=e^-φ
B=e^(αφ)
```

so:

```text
n = e^((1+α)φ)
```

For weak field and impact parameter b:

```text
δ ≈ 2(1+α) μ/b
```

where:

```text
μ = GM/c²
```

GR target:

```text
δ_GR = 4μ/b
```

Therefore:

```text
ratio to GR = (1+α)/2
```

Scalar/time-only control:

```text
α=0 -> ratio=0.5
```

One-speed reciprocal closure:

```text
α=1 -> ratio=1
```

## Direct null integration result

Using:

```text
μ = 1
b = 1000
L = 100000
```

Direct ray integration gives:

| α | direct ratio to GR | finite-integral agreement | status |
|---:|---:|---:|---|
| 0.0 | 0.500758 | 1.001565 | ALT_TRACKED |
| 0.5 | 0.751726 | 1.002351 | ALT_TRACKED |
| 1.0 | 1.003089 | 1.003139 | PASS_FACTOR_TWO |
| 2.0 | 1.507007 | 1.004722 | ALT_TRACKED |

The small excess above exactly 1 for α=1 is finite-field/finite-integration curvature, not a fitted parameter. The weak prediction is recovered at the expected level.

---

# 4. TIMELIKE CAPSULE

The same metric:

```text
ds² = -A dt² + S(dx²+dy²)
A=e^-2μ/r
S=e^2αμ/r
```

was integrated with proper-time geodesics for a weak bound orbit.

Seed parameters:

```text
α = 1
μ = 1
p = 500.0
e = 0.2
```

Weak GR target:

```text
Δϖ = 6πμ/p
```

Direct integration measured:

```text
Δϖ_measured = 0.037637791386
Δϖ_expected = 0.037699111843
ratio = 0.998373424361
```

Verdict:

```text
PASS_DIRECT_TIMELIKE_WEAK_FIELD
```

---

# 5. STATUS LINE

```text
DIRECT_TRAJECTORY_STATUS:
    WEAK_FIELD_PASS

EARNED:
    null direct integration reproduces factor-of-two closure behavior
    scalar/time-only half-deflection appears as control
    timelike direct integration recovers weak perihelion precession

NOT EARNED HERE:
    strong-field trajectories
    horizons
    exact Schwarzschild equivalence
    gravitational radiation reaction
    binary pulsar decay
```

---

# 6. LIVE EDGES

## T1 — strong-field closure fork

The direct weak-field trajectory pass does not solve the strong-field question:

```text
exponential closure vs V10 exact Schwarzschild / horizon behavior
```

## G-alpha

Direct trajectories still do not derive α=1 from the write operator. They confirm that α=1 dynamically works.

## G-RAD / G-SEP

Path dynamics do not yet supply radiation reaction, polarization count, or dipole suppression.

---

# 7. Referee intuition check

Does this match the physical picture?

```text
Light follows the straightest null path through the closure geometry.
It reads both the clock-lag and reciprocal spatial-closure parts.
Timelike bodies follow the same geometry and recover the weak orbit correction.
The closure is not just a coefficient table; it moves paths correctly in weak field.
```

If yes, the old Gate 05 is pulled forward.

If no, GC-2D should remain coefficient-only and public claims must be downgraded.
