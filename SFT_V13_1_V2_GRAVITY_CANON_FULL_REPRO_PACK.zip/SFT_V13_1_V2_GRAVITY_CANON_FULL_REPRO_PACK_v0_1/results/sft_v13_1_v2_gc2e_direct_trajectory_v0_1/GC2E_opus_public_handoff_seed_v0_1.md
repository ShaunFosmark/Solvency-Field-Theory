# GC2E Opus/Public Narrative Handoff Seed

## Public section title

**The closure geometry moves paths, not just coefficients**

## Public claim

SFT's weak-field closure was checked by directly integrating paths. Null rays follow the optical geometry n=B/F and recover the full light-bending factor for B=F^-1. Timelike bound orbits integrated through the same closure recover the weak perihelion precession. This supports the claim that the weak-field closure is dynamical, not only symbolic.

## Must include

- Direct null ray integration.
- Scalar/time-only half-deflection control.
- Direct timelike orbit precession.
- Weak-field domain only.

## Must not say

- "SFT has solved strong-field black holes."
- "SFT has derived radiation reaction."
- "SFT has completed binary pulsar tests."
