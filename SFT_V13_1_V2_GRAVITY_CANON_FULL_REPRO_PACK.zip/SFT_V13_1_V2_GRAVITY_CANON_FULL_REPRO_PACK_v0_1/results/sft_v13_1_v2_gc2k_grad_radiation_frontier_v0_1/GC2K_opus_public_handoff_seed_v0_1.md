# GC2K Opus/Public Narrative Handoff Seed

## Public section title

Gravitational waves: what is earned, what remains open

## Public claim

SFT's gravity canon identifies the trace-free settlement lane as the natural candidate for tensor gravitational radiation. A far-zone transverse trace-free diagnostic gives the expected two plus/cross readouts, and the rotating quadrupole has the expected m=2 skeleton. This is not yet a full gravitational-wave theory. The scalar breathing and dipole-radiation risks remain open until SFT derives their suppression and recovers the quadrupole power law.

## Must include

- TT skeleton only, not full field equation.
- Scalar breathing and dipole radiation are open high-stakes gates.
- Binary-pulsar energy loss is not claimed.
- Merger/ringdown depends on the strong-field fork.

## Must not say

- SFT has solved gravitational waves.
- SFT passes Hulse-Taylor.
- Extra polarizations are proven absent.
- Radiation reaction is derived.
