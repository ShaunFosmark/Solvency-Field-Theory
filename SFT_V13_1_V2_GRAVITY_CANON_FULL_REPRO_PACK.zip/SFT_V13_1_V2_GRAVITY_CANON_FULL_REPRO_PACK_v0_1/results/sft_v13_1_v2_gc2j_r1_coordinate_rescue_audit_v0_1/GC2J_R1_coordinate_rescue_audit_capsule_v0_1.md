# SFT V13.1-V2 GC-2J-R1 — Coordinate Rescue Hostile Audit v0.1

## Status

```text
GC2J_R1_COORDINATE_RESCUE_PARTIAL_SUCCESS_COMPATIBILITY_RESCUED_DERIVATION_NOT_RESCUED
```

## Question

Can the GC-2J strong-field downgrade be reversed by noting that Schwarzschild satisfies reciprocal closure in Schwarzschild/areal coordinates?

## Short answer

Partly.

The hostile test confirms:

```text
Schwarzschild is compatible with a one-speed radial reciprocal closure in areal coordinates.
```

But it does not confirm:

```text
SFT has derived exact Schwarzschild.
```

The downgrade is softened, not reversed.

The strong-field fork becomes sharper:

```text
F*B=1 is not a coordinate-invariant law.
It is a gauge-specific reciprocity condition.
Schwarzschild satisfies reciprocity in areal radial gauge.
Exponential closure satisfies reciprocity in isotropic gauge.
Those are not the same physical metric.
```

---

# 1. What passes

In Schwarzschild/areal coordinates:

```text
ds² = -A(R) dt² + A(R)^-1 dR² + R² dΩ²
A(R)=1-2M/R
```

Therefore:

```text
F = sqrt(A)
sqrt(g_RR)=1/sqrt(A)
F sqrt(g_RR)=1
```

So the one-speed radial reciprocity condition holds exactly.

This means exact Schwarzschild is not hostile to the one-speed idea.

It is one-speed-compatible.

---

# 2. What fails

Schwarzschild in isotropic coordinates has:

```text
F_S = (1-M/2ρ)/(1+M/2ρ)
B_S = (1+M/2ρ)^2
```

so:

```text
F_S B_S = 1 - M²/(4ρ²)
```

not exactly 1.

The exponential isotropic closure has:

```text
F_E=e^-M/ρ
B_E=e^M/ρ
F_E B_E=1
```

These are different coordinate/gauge implementations.

But they are not merely two coordinate forms of the same metric.

The lapse as a function of areal radius differs:

```text
Schwarzschild:
    A(R)=1-2M/R

Exponential isotropic:
    R=ρ e^(M/ρ)
    A=e^(-2M/ρ)
```

The audit finds these differ beyond weak field.

Therefore:

```text
exponential isotropic closure is not just Schwarzschild in another coordinate system.
```

---

# 3. Hostile verdicts

| claim | verdict |
|---|---|
| Schwarzschild satisfies radial one-speed reciprocity in areal gauge | PASS |
| Schwarzschild is compatible with the one-speed budget | PASS_BUT_WEAK |
| Exponential isotropic is just Schwarzschild in another coordinate | FAIL |
| V10 exact Schwarzschild downgrade can be fully reversed | FAIL |
| Strong-field fork can be refined as a coordinate/gauge/dynamics problem | PASS |
| Public paper can claim exact Schwarzschild black holes | FAIL_BOUNDARY |

---

# 4. What changes to GC-2J

Old GC-2J status:

```text
exact strong-field Schwarzschild downgraded
```

New refined status:

```text
exact strong-field Schwarzschild not derived, but no longer rejected as one-speed-incompatible.
```

Better wording:

```text
Schwarzschild is one-speed-compatible in areal radial gauge.
The exponential closure is the isotropic-gauge reciprocal ansatz.
SFT must still derive which radial gauge and strong-field dynamics are native.
```

So the strong-field fork remains open, but it is less fatal.

---

# 5. Why local c alone is not enough

A warning:

```text
local physical speed c
```

is true in any Lorentzian metric with local orthonormal frames. If SFT reduces the one-speed budget to only that statement, it becomes too weak to select a strong-field metric.

To recover exact Schwarzschild, SFT needs more than local c.

It needs a native strong-field theorem such as:

```text
one-speed budget
+ no-overwrite shell accounting
+ areal radius as write-surface area variable
+ exterior vacuum/source-free settlement
=> A(R)=1-2M/R and g_RR=A^-1
```

That theorem is not yet in hand.

---

# 6. Status line

```text
GC2J_R1_STATUS:
    SCHWARZSCHILD_ONE_SPEED_COMPATIBILITY_RESCUED
    EXPONENTIAL_AS_SCHWARZSCHILD_COORDINATE_TRANSFORM_REJECTED
    EXACT_SCHWARZSCHILD_DERIVATION_STILL_OPEN
    DOWNGRADE_SOFTENED_NOT_REVERSED

EARNED:
    Schwarzschild satisfies radial reciprocal closure in areal coordinates
    F*B=1 is gauge-specific, not coordinate-invariant
    GC-2J fork should be restated as native-gauge/dynamics problem

NOT EARNED:
    exact Schwarzschild from SFT first principles
    horizon formation theorem
    Kerr/strong-field spin
    shadow/ringdown pass
```

---

# 7. Next theorem target

```text
GC2J-R2:
Native areal-shell theorem
```

Target:

```text
Show that no-overwrite write surfaces use areal radius R as the physical shell variable.
Then derive radial reciprocity in that gauge:
    F sqrt(g_RR)=1
Then derive the exterior vacuum form:
    F² = 1 - 2M/R
```

If that passes, V10 exact Schwarzschild can be restored.

If not, the public boundary remains weak-field only.
