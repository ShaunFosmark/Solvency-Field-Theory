# GC2J-R1 Opus/Public Handoff Seed

## Public section title

Strong-field coordinates: a rescue that is not yet a derivation

## Public claim

The strong-field fork is subtler than exponential versus Schwarzschild as raw formulas. Exact Schwarzschild satisfies reciprocal radial closure in areal coordinates: g_tt g_RR = -1. Therefore Schwarzschild is compatible with the one-speed budget. However, the exponential isotropic closure is not merely Schwarzschild in a different coordinate system; its lapse as a function of areal radius differs. The result softens the downgrade but does not reverse it: SFT still must derive why its native strong-field shell variable is the areal radius and why the exterior vacuum solution is Schwarzschild.

## Must include

- Schwarzschild is one-speed-compatible in areal gauge.
- F*B=1 is gauge-specific, not coordinate-invariant.
- Exponential isotropic is not a coordinate transform of Schwarzschild.
- Exact Schwarzschild derivation remains open.
- Public black-hole claims remain bounded.

## Must not say

- The strong-field fork is solved.
- V10 exact Schwarzschild is restored.
- Exponential and Schwarzschild are the same metric.
- Local c alone derives Schwarzschild.
