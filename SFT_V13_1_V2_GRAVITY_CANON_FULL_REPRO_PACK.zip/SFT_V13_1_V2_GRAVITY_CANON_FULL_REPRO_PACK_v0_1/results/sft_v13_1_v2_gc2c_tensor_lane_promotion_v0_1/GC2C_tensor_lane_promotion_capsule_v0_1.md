# SFT V13.1-V2 GC-2C — Tensor/Lane Promotion Capsule v0.1

## Part III title

**From Scalar Settlement to Tensor/Lane Response**

## Status

```text
GC-2C_DRAFT_TOY_RETESTED_BRIDGE_ONLY
```

This capsule rebuilds the bridge that prevents the gravity program from being scalar-only.

It does **not** yet claim:
```text
full Einstein field equations
complete gravitational-wave theory
frame dragging derived at measured magnitude
binary-pulsar-safe radiation sector
```

It claims a narrower but crucial result:

```text
Scalar settlement can be decomposed into trace, trace-free, and mixed lane channels.
Those channels are compatible with the V13.8 3+1 projector stack.
The trace-free channel naturally carries quadrupole / m=2 structure.
The mixed continuation-settlement channel is the native place for rotation/frame-dragging work.
```

---

# 1. ATTACK

The attack:

> GC-2B only rebuilt a scalar settlement projection. A scalar field can give Newtonian attraction, but it cannot be the relativistic gravitational object. It has no spatial curvature, no frame dragging, no tensor gravitational waves, and generically gives scalar breathing/dipole radiation modes that precision tests punish.

This attack is valid if SFT has only \(C_A\).

So GC-2C has one job:

```text
show that C_A is only the trace/readout projection of a richer lane response.
```

---

# 2. STAKES

If this bridge fails:

```text
- the factor-of-two light-bending attack returns downstream;
- gamma=1 becomes a coefficient selection instead of a mechanism target;
- rotating mass writes the same record as static mass;
- LIGO/pulsar constraints remain category-fatal;
- the V13.8 projector partition does not actually support gravity.
```

If the bridge is overclaimed:

```text
- SFT pretends toys are a full covariant tensor theory;
- frame dragging/wave claims become unsafe;
- public narrative overstates the archive.
```

So the status must be exact:

```text
bridge earned / full tensor dynamics open
```

---

# 3. CAPSULE — minimal re-derivation path

## 3.1 Scalar projection is the trace channel

GC-2B gives the scalar settlement projection:

```text
C_A ~ trace response / isotropic settlement demand
```

A scalar projection is the part of the response that survives spherical averaging.

In a three-settlement-lane picture, any local settlement-gradient response can be split into:

```text
H_ij = (Tr H / 3) δ_ij + [H_ij - (Tr H / 3) δ_ij]
```

or:

```text
H = trace channel + trace-free channel
```

The trace channel is scalar.

The trace-free channel is anisotropic settlement/shear.

## 3.2 Orthogonal split

The decomposition is orthogonal:

```text
Tr(TF) = 0
<TracePart, TF> = 0
||H||² = ||TracePart||² + ||TF||²
```

Numeric capsule retest:

```text
Tr(TF) = 5.551e-17
<TracePart,TF> = 0.000e+00
decomposition error = 0.000e+00
```

Verdict:

```text
PASS_TRACE_TF_SEPARABILITY
```

## 3.3 Quadrupole/m=2 channel

A trace-free quadrupole tensor in the settlement lanes can be written:

```text
Q0 = diag(1, -1, 0)
```

Rotate the source by angle θ:

```text
Q(θ) = R(θ) Q0 R(θ)^T
```

The observable m=2 complex channel is:

```text
Z2 = (Q_xx - Q_yy) + 2 i Q_xy
```

For a rotating quadrupole:

```text
phase(Z2) = 2θ + constant
```

Numeric retest:

```text
measured m=2 phase slope = 2.000000000000
quadrupole amplitude std = 1.557e-16
max trace drift = 1.110e-16
max eigenvalue drift = 2.220e-16
```

Verdict:

```text
PASS_QUADRUPOLE_M2_SKELETON
```

This is the native location of the old V11.1B/V11.13 quadrupole insight.

It is **not** yet a full gravitational wave theory.

## 3.4 Mixed continuation-settlement channel

The V13.8 lane picture has:

```text
I4 = Π_settlement + Π_continuation
Tr(Π_settlement)=3
Tr(Π_continuation)=1
```

The three settlement lanes carry spatial settlement response. The continuation lane carries advancement/boundary continuation.

A rotating writer differs from a static writer by orientation/history flow, not only by scalar energy density. Therefore rotation must enter a **mixed** channel:

```text
settlement lane ↔ continuation lane
```

A minimal circulation readout toy has:

```text
A_mix ∝ J × r / r^3
|A_mix| ∝ r^-2
```

Numeric toy retest:

```text
mixed-channel falloff slope = -2.000000000000
spin reversal sign correlation = 1.000000000000
```

Verdict:

```text
PASS_TOY_MIXED_CHANNEL_PLACEHOLDER
```

This locates the native frame-dragging target:

```text
G-J: derive h_0i / Lense-Thirring from continuation-lane orientation.
```

It does not yet complete G-J.

---

# 4. STATUS LINE

```text
TENSOR_LANE_STATUS:
    BRIDGE_EARNED_TOY_SUPPORTED_FULL_COVARIANT_DYNAMICS_OPEN

EARNED:
    scalar trace vs trace-free split
    scalar/tensor separability at linear-lane level
    quadrupole/m=2 channel skeleton
    mixed continuation-settlement channel identified as rotation target

TOY_SUPPORTED:
    r^-2 mixed circulation falloff
    sign flip under spin reversal

OPEN:
    covariant field equation
    alpha=1 derivation from lane-democratic deposition
    frame-dragging magnitude/sign/falloff against Lense-Thirring
    gravitational-wave polarization count
    monopole/dipole suppression
    binary-pulsar energy loss
```

---

# 5. LIVE EDGES

## G-alpha — lane-democratic deposition

Question:

```text
Does equal footprint per available lane force spatial closure to match temporal lag, giving gamma=1 without selection?
```

## G-J — frame dragging

Question:

```text
Does continuation-lane orientation produce the h_0i sector with correct Lense-Thirring scaling?
```

## G-RAD — radiation and polarization

Question:

```text
Does the trace-free/mixed channel propagate only allowed tensor modes at c, suppressing scalar breathing/dipole radiation?
```

## G-SEP — equivalence/dipole

Question:

```text
Does the five-component active source couple universally enough to avoid Nordtvedt/dipole conflicts?
```

---

# 6. Referee intuition check

Does this match the physical picture?

```text
C_A is what you get after averaging the settlement response.
But a real write has orientation, lane distribution, and continuation history.
Spherical/static sources mostly show the trace.
Anisotropic/rotating/time-changing sources expose the trace-free and mixed channels.
```

If yes, proceed to GC-2D: one-speed metric closure.

If no, tensor/lane promotion must be corrected before γ=1 is rebuilt.
