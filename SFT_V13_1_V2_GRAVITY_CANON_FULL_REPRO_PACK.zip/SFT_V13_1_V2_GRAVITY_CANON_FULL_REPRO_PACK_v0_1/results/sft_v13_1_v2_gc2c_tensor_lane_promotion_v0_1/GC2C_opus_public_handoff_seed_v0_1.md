# GC2C Opus/Public Narrative Handoff Seed

## Public section title

**Why settlement is not only a scalar**

## Public claim

The scalar settlement field is the spherical/trace projection of a richer response. Once the source has direction, anisotropy, rotation, or time dependence, the response separates into trace, trace-free, and mixed continuation-settlement channels. The trace-free channel is where quadrupole structure lives; the mixed continuation channel is where rotating-source effects must be derived.

## Must include

- Scalar settlement is not the whole gravitational object.
- The trace-free channel naturally carries quadrupole/m=2 structure.
- The mixed continuation-settlement channel is the target for frame dragging.
- Full gravitational waves and frame dragging are not yet claimed as solved.

## Must not say

- "SFT has completed gravitational wave theory."
- "SFT has derived Lense-Thirring."
- "The trace-free toy is the Einstein tensor."
- "All scalar-tensor dangers are closed."
