# GC2H Opus/Public Narrative Handoff Seed

## Public section title

**What SFT claims about the strength of gravity**

## Public claim

SFT does not claim to derive the numerical value of G from nothing. It claims that the coupling has a root-area form: if the per-radian write area a_phi is supplied, then G_eff = a_phi c^3/hbar. The full-cycle write area is A0 = 2πa_phi, so per-radian and full-cycle clocks describe the same ledger when paired correctly. The 2π is earned by phase/cycle bookkeeping; the numerical value of the root area remains open.

## Must include

- Planck area cannot be used as derivation input because it already contains G.
- a_phi is the root area/theorem target.
- G_eff = a_phi c^3/hbar.
- A0 = 2πa_phi.
- Per-radian and full-cycle conventions are equivalent only when paired correctly.
- SFT compresses G to one root invariant; it does not yet derive the number.

## Must not say

- "SFT derives the numerical value of G from first principles."
- "Planck area proves G."
- "The 2π is tunable."
- "The clock-gauge convention is a physical fork if gauges are paired correctly."
