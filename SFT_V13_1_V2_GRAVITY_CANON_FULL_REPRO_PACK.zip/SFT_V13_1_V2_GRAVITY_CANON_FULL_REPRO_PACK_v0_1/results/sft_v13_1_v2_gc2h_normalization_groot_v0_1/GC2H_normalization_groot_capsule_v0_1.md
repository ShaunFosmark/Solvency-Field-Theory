# SFT V13.1-V2 GC-2H — Normalization, G-root, and 2π Clock Gauge v0.1

## Part V title

**The Normalization Boundary: what SFT earns about G, and what remains open**

## Status

```text
GC-2H_DRAFT_RETESTED_STRUCTURE_PASS_NUMERICAL_G_VALUE_OPEN
```

GC-2A through GC-2G rebuilt the source, scalar projection, tensor/lane bridge, one-speed metric closure, direct trajectories, and the G-alpha theorem.

GC-2H now handles the normalization layer:

```text
G_eff = a_phi c^3 / hbar
A0 = 2π a_phi
```

This gate is not allowed to claim more than it earns.

---

# 1. ATTACK

The attack:

> You smuggled G through the Planck area. The Planck area is l_P² = hbar G/c³. If SFT assumes Planck area and then "derives" G, the derivation is circular.

This attack is correct if Planck area is used as an input.

So GC-2H must state the boundary clearly:

```text
Planck area may appear after empirical calibration.
It may not be used as the primitive derivation of G.
```

---

# 2. STAKES

If this gate fails:

```text
- SFT's normalization is circular;
- the public paper overclaims G;
- the per-radian/full-cycle 2π convention remains ambiguous;
- Fork09 clock-gauge work risks mixing gauges;
- G-root becomes a numerology patch instead of a clean boundary.
```

If this gate passes:

```text
- SFT earns the structural form of the coupling;
- SFT earns the 2π clock/cycle bookkeeping;
- SFT compresses all normalization faces to one root invariant;
- SFT honestly leaves the numerical root value open.
```

---

# 3. CAPSULE — minimal re-derivation path

## 3.1 Define the root area per radian

Let:

```text
a_phi = root write area per radian
```

Then the source-side exterior readout from GC-2A was:

```text
C_A(E,r) = a_phi E / (hbar c r)
```

For E = M c²:

```text
C_A = a_phi M c / (hbar r)
```

To match the Newtonian compactness readout:

```text
C_A = G_eff M / (c² r)
```

therefore:

```text
G_eff = a_phi c³ / hbar
```

This is a structural identity.

It says:

```text
if a_phi is supplied, G_eff follows.
```

It does not say:

```text
a_phi has been derived numerically.
```

## 3.2 Full-cycle write area

Reduced/radian phase rate:

```text
omega = E / hbar
```

Full-cycle rate:

```text
f = E / h = E / (2π hbar)
```

For the ledger demand to be gauge-independent:

```text
a_phi omega = A0 f
```

so:

```text
a_phi E/hbar = A0 E/h
```

and:

```text
A0 = 2π a_phi
```

That is the earned 2π.

The 2π is not a fit. It is the conversion between reduced/radian and full-cycle accounting.

## 3.3 Same G in both gauges

Per-radian gauge:

```text
G_eff = a_phi c³ / hbar
```

Full-cycle gauge:

```text
G_eff = A0 c³ / h
```

Using:

```text
A0 = 2πa_phi
h = 2πhbar
```

gives:

```text
A0 c³ / h = a_phi c³ / hbar
```

So both gauges are identical if paired correctly.

## 3.4 Root invariant equivalence class

Once any one root face is supplied, the rest reconstruct:

```text
a_phi = A0/(2π)
      = l_root²
      = (c t_root)²
      = rho_A^-1
      = hbar G_eff/c³
      = hbar c/F_root
```

This is compression, not numerical derivation.

---

# 4. NUMERIC CALIBRATION CHECK

Using the runtime physical constants as diagnostic calibration:

| quantity | value |
|---|---:|
| a_phi = hbar G/c³ | 2.612280303975e-70 m² |
| A0 = 2πa_phi | 1.641344122417e-69 m²/cycle |
| l_root = sqrt(a_phi) | 1.616255024424e-35 m |
| t_root = l_root/c | 5.391246448314e-44 s |
| G_from_a_phi | 6.674300000000e-11 |
| G_from_A0 | 6.674300000000e-11 |
| relative G error, per-radian | 0.000e+00 |
| relative G error, full-cycle | 1.936e-16 |
| max per-radian/full-cycle demand-rate difference | 1.754e-16 |

Verdict:

```text
PASS_CALIBRATION_IDENTITY
PASS_2PI_GAUGE_EQUIVALENCE
```

But calibration identity is not first-principles derivation.

---

# 5. FORK09 CLOCK-GAUGE MAP

Valid gauges:

```text
K_a:
    write rate = E/hbar
    write area = a_phi
    demand = a_phi E/hbar

K_b:
    write rate = E/h
    write area = A0 = 2πa_phi
    demand = A0 E/h = a_phi E/hbar
```

Invalid mixed gauges:

```text
E/hbar with A0:
    double-counts 2π

E/h with a_phi:
    undercounts by 2π
```

Therefore the Fork09 clock-gauge issue is not physical if gauges are paired correctly. It is a bookkeeping convention.

The physical ledger demand is invariant:

```text
a_phi E/hbar = A0 E/h
```

---

# 6. NO-CHEAT ROUTE AUDIT

| route | verdict |
|---|---|
| assume Planck area l_P² | CIRCULAR_AS_DERIVATION |
| c + hbar + phase only | FAIL_DIMENSIONAL |
| Compton/phase closure | EARNS_2PI_NOT_AREA |
| particle-specific Compton area | FAIL_UNIVERSALITY |
| cosmological horizon area | FAIL_LOCAL_PRIMITIVE |
| root area a_phi | PASS_STRUCTURE_OPEN_VALUE |

---

# 7. STATUS LINE

```text
NORMALIZATION_STATUS:
    STRUCTURE_EARNED
    2PI_CYCLE_EARNED
    ROOT_INVARIANT_EQUIVALENCE_EARNED
    NUMERICAL_G_VALUE_OPEN

EARNED:
    G_eff = a_phi c³/hbar if a_phi is supplied
    A0 = 2πa_phi
    per-radian and full-cycle gauges are identical when paired correctly
    all root faces form one invariant equivalence class
    Planck area is rejected as a derivation input

OPEN:
    first-principles selection of a_phi
    microscopic root-state selector
    whether a_phi is fixed by a deeper closure/ledger theorem
```

---

# 8. LIVE EDGE

## G-root-2 — root-area selector

Question:

```text
What fixes a_phi numerically?
```

Allowed future routes:

```text
- no-overwrite + minimum admissible footprint
- projector/lane closure uniqueness
- black-hole/horizon thermodynamic bridge if non-circular
- particle/field closure root-state theorem
```

Disallowed route:

```text
Assume Planck area because it contains G, then claim G is derived.
```

---

# 9. Referee intuition check

Does this match the physical picture?

```text
The 2π is real, but it is a clock-gauge conversion.
The coupling form is real, but the root area value is still an open root-state problem.
Measured gravity tells us what a_phi equals numerically.
SFT has compressed G to one unresolved root invariant rather than derived the number from nothing.
```

If yes, GC-2H passes with honest boundaries.

If no, downgrade the public normalization claim before Opus writes it.
