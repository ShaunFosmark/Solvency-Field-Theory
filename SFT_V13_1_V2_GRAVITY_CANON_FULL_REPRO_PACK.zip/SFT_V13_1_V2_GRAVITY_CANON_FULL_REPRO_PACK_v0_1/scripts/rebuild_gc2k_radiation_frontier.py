#!/usr/bin/env python3
from pathlib import Path
import sys, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

out = Path(sys.argv[1]) / "gc2k_radiation_frontier"
out.mkdir(parents=True, exist_ok=True)

rng = np.random.default_rng(1327)
def normalize(v): return v / np.linalg.norm(v)

n = normalize(np.array([0.3, -0.4, 0.8660254]))
P = np.eye(3) - np.outer(n, n)
A = rng.normal(size=(3,3))
H = (A + A.T) / 2
PH = P @ H @ P
H_TT = PH - 0.5 * P * np.trace(PH)

tmp = np.array([1.0, 0.0, 0.0])
if abs(np.dot(tmp, n)) > 0.9:
    tmp = np.array([0.0, 1.0, 0.0])
e1 = normalize(tmp - np.dot(tmp, n)*n)
e2 = normalize(np.cross(n, e1))
e_plus = np.outer(e1, e1) - np.outer(e2, e2)
e_cross = np.outer(e1, e2) + np.outer(e2, e1)
plus_amp = 0.5 * float(np.sum(H_TT * e_plus))
cross_amp = 0.5 * float(np.sum(H_TT * e_cross))
H_recon = plus_amp * e_plus + cross_amp * e_cross

rows = [
    {"diagnostic":"trace_TT", "expected":"0", "measured":float(np.trace(H_TT)), "verdict":"PASS"},
    {"diagnostic":"transversality_norm", "expected":"0", "measured":float(np.linalg.norm(H_TT @ n)), "verdict":"PASS"},
    {"diagnostic":"symmetry_error", "expected":"0", "measured":float(np.linalg.norm(H_TT - H_TT.T)), "verdict":"PASS"},
    {"diagnostic":"two_polarization_reconstruction_error", "expected":"0", "measured":float(np.linalg.norm(H_TT - H_recon)), "verdict":"PASS"},
    {"diagnostic":"plus_amplitude", "expected":"free", "measured":plus_amp, "verdict":"READOUT"},
    {"diagnostic":"cross_amplitude", "expected":"free", "measured":cross_amp, "verdict":"READOUT"},
]
pd.DataFrame(rows).to_csv(out / "gc2k_TT_projection_diagnostic.csv", index=False)

t = np.linspace(0, 4*np.pi, 1000)
Omega = 1.0
Qplus = np.cos(2*Omega*t)
Qcross = np.sin(2*Omega*t)
dt = t[1]-t[0]
d2plus = np.gradient(np.gradient(Qplus, dt), dt)
expected = -4*Omega**2*Qplus
sl = slice(10, -10)
err = float(np.sqrt(np.mean((d2plus[sl]-expected[sl])**2)) / np.sqrt(np.mean(expected[sl]**2)))

pd.DataFrame({"t":t, "Q_plus":Qplus, "Q_cross":Qcross, "d2Q_plus":d2plus}).to_csv(out / "gc2k_quadrupole_m2_profile.csv", index=False)

plt.figure(figsize=(7,5))
plt.plot(t, Qplus, label="plus skeleton cos(2Ωt)")
plt.plot(t, Qcross, label="cross skeleton sin(2Ωt)")
plt.xlabel("t")
plt.ylabel("normalized strain skeleton")
plt.title("GC-2K quadrupole m=2 plus/cross skeleton")
plt.grid(alpha=0.3)
plt.legend()
plt.savefig(out / "gc2k_quadrupole_m2_plus_cross.png", dpi=160, bbox_inches="tight")
plt.close()

verdict = {
    "verdict": "PARTIAL_FRONTIER_PASS_TT_SKELETON_ONLY",
    "quadrupole_second_derivative_relative_rms_error": err,
    "open": ["scalar breathing suppression", "dipole suppression", "quadrupole power coefficient", "binary pulsar energy loss"]
}
(out / "gc2k_verdict.json").write_text(json.dumps(verdict, indent=2))
print("GC2K rebuilt:", out)
