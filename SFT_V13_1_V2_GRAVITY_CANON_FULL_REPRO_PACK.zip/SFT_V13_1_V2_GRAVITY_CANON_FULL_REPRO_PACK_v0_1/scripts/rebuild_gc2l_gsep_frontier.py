#!/usr/bin/env python3
from pathlib import Path
import sys, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

out = Path(sys.argv[1]) / "gc2l_gsep_frontier"
out.mkdir(parents=True, exist_ok=True)

m1, m2, a = 1.4, 1.3, 1.0
mu = m1*m2/(m1+m2)
x1 = m2/(m1+m2)*a
x2 = -m1/(m1+m2)*a
deltas = np.linspace(-1e-2, 1e-2, 401)
rows = []
for d in deltas:
    k1 = 1 + d/2
    k2 = 1 - d/2
    D = k1*m1*x1 + k2*m2*x2
    rows.append({
        "delta_kappa": d,
        "kappa1": k1,
        "kappa2": k2,
        "dipole_D_direct": D,
        "dipole_D_formula": mu*a*(k1-k2),
        "status": "ZERO_UNIVERSAL" if abs(d) < 1e-15 else "DIPOLE_IF_NONUNIVERSAL"
    })
df = pd.DataFrame(rows)
df.to_csv(out / "gc2l_binary_dipole_universality_sweep.csv", index=False)

plt.figure(figsize=(7,5))
plt.plot(df["delta_kappa"], df["dipole_D_direct"], label="D direct")
plt.plot(df["delta_kappa"], df["dipole_D_formula"], linestyle="--", label="μa Δκ")
plt.axhline(0, linestyle=":")
plt.axvline(0, linestyle=":")
plt.xlabel("Δκ = κ1 - κ2")
plt.ylabel("dipole D")
plt.title("GC-2L: binary dipole appears if universality fails")
plt.grid(alpha=0.3)
plt.legend()
plt.savefig(out / "gc2l_binary_dipole_sweep.png", dpi=160, bbox_inches="tight")
plt.close()

source_terms = [
    ["rest_mass_energy", "YES", "EARNED_SOURCE_SIDE"],
    ["internal_energy", "YES", "PARTIAL_CARRIED"],
    ["radiation_energy_pressure", "YES", "SOURCE_SIDE_PARTIAL"],
    ["binding_energy", "YES_WITH_SIGN_CONVENTION", "OPEN_HIGH_STAKES"],
    ["strong_nuclear_field_share", "YES", "OPEN_MICRO_TO_MACRO"],
    ["electromagnetic_binding", "YES", "OPEN_MICRO_TO_MACRO"],
]
pd.DataFrame(source_terms, columns=["term","must_couple","status"]).to_csv(out / "gc2l_universal_source_term_ledger.csv", index=False)

verdict = {
    "verdict": "PARTIAL_FRONTIER_PASS_UNIVERSALITY_SKELETON_ONLY",
    "dipole_condition": "D=0 if and only if kappa=q/m is universal in center-of-mass coordinates",
    "open": ["binding energy universality", "strong self-energy", "scalar charge danger", "full SEP"]
}
(out / "gc2l_verdict.json").write_text(json.dumps(verdict, indent=2))
print("GC2L rebuilt:", out)
