#!/usr/bin/env python3
from pathlib import Path
import sys, math, json, hashlib, datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

out = Path(sys.argv[1]) / "gc2j_r3_areal_capacity"
out.mkdir(parents=True, exist_ok=True)

C = np.linspace(0, 0.499, 1000)
q_values = [-2, -1, -0.5, 0, 0.5, 1, 2]

rows = []
for q in q_values:
    roots = np.roots([q, -2, 1]) if q != 0 else np.array([0.5])
    roots_real_pos = sorted([float(r.real) for r in roots if abs(r.imag) < 1e-12 and r.real > 0])
    C_h = roots_real_pos[0] if roots_real_pos else np.nan
    R_h = 1/C_h if C_h and not np.isnan(C_h) else np.nan
    rows.append({
        "q": q,
        "A_formula": "1-2C+qC^2",
        "K_consumed_formula": "2C-qC^2",
        "marginal_dK_dC_at_C0": 2.0,
        "marginal_dK_dC_at_C0p25": float(2-2*q*0.25),
        "marginal_dK_dC_at_C0p49": float(2-2*q*0.49),
        "curvature_d2K_dC2": float(-2*q),
        "horizon_C_if_A_zero": C_h,
        "horizon_R_over_M": R_h,
        "universal_footprint_status": "PASS_CONSTANT_MARGINAL" if q == 0 else "FAIL_VARIABLE_MARGINAL_OR_SELF_INTERACTION",
        "additivity_status": "PASS_ADDITIVE" if q == 0 else "FAIL_CROSS_TERM"
    })
pd.DataFrame(rows).to_csv(out / "gc2j_r3_q_family_capacity_audit.csv", index=False)

C1_vals = np.linspace(0.001, 0.2, 80)
C2_vals = np.linspace(0.001, 0.2, 80)
cross_rows = []
for q in q_values:
    max_abs_defect = 0
    rms_defect = []
    for C1 in C1_vals:
        for C2 in C2_vals:
            if C1 + C2 < 0.49:
                K = lambda x: 2*x - q*x*x
                defect = K(C1+C2) - K(C1) - K(C2)
                max_abs_defect = max(max_abs_defect, abs(defect))
                rms_defect.append(defect)
    cross_rows.append({
        "q": q,
        "max_abs_additivity_defect": max_abs_defect,
        "rms_additivity_defect": float(np.sqrt(np.mean(np.array(rms_defect)**2))),
        "analytic_defect": "-2 q C1 C2",
        "verdict": "PASS_ZERO_CROSS_TERM" if q == 0 else "FAIL_SETTLEMENT_SETTLEMENT_CROSS_TERM"
    })
pd.DataFrame(cross_rows).to_csv(out / "gc2j_r3_additivity_cross_term_audit.csv", index=False)

plt.figure(figsize=(7,5))
for q in q_values:
    K = 2*C - q*C**2
    plt.plot(C, K, label=f"q={q}")
plt.axhline(1, linestyle="--", label="capacity exhausted")
plt.axvline(0.5, linestyle=":", label="C=1/2")
plt.xlabel("compactness C=M/R")
plt.ylabel("consumed capacity K=1-A")
plt.title("GC-2J-R3: q=0 is linear capacity consumption")
plt.grid(alpha=0.3)
plt.legend(fontsize=8)
plt.savefig(out / "gc2j_r3_capacity_consumption_family.png", dpi=160, bbox_inches="tight")
plt.close()

plt.figure(figsize=(7,5))
for q in q_values:
    marginal = 2 - 2*q*C
    plt.plot(C, marginal, label=f"q={q}")
plt.xlabel("compactness C=M/R")
plt.ylabel("marginal capacity debit dK/dC")
plt.title("GC-2J-R3: q≠0 makes footprint cost depth-dependent")
plt.grid(alpha=0.3)
plt.legend(fontsize=8)
plt.savefig(out / "gc2j_r3_marginal_capacity_debit.png", dpi=160, bbox_inches="tight")
plt.close()

verdict = {
    "verdict": "STATIC_SPHERICAL_SCHWARZSCHILD_DERIVED_WITH_EXPLICIT_CAPACITY_AXIOMS",
    "logic": [
        "A_q(C)=1-2C+qC^2",
        "K_q(C)=1-A_q=2C-qC^2",
        "dK/dC=2-2qC, constant only if q=0",
        "K(C1+C2)-K(C1)-K(C2)=-2qC1C2, zero only if q=0",
        "therefore A=1-2M/R and radial reciprocity gives Schwarzschild exterior"
    ]
}
(out / "gc2j_r3_verdict.json").write_text(json.dumps(verdict, indent=2))
print("GC2J-R3 rebuilt:", out)
