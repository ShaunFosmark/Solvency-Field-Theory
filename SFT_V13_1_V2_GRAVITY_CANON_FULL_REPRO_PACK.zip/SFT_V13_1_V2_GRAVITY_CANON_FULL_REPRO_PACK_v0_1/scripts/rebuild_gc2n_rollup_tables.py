#!/usr/bin/env python3
from pathlib import Path
import sys, json
import pandas as pd

out = Path(sys.argv[1]) / "gc2n_rollup_tables"
out.mkdir(parents=True, exist_ok=True)

score_rows = [
    {"category":"Source and scalar field", "gates":"GC-2A/B", "score":"PASS/PARTIAL", "summary":"Source-side structure and Newtonian projection work; covariant source/binding details open."},
    {"category":"Weak-field metric and tests", "gates":"GC-2C/D/E/F/G", "score":"STRONG_PASS", "summary":"gamma=1, factor-two light bending, Shapiro/perihelion weak-field structure and direct paths survive."},
    {"category":"Normalization", "gates":"GC-2H", "score":"STRUCTURE_PASS_VALUE_OPEN", "summary":"G form and 2pi gauge earned; numeric root area open."},
    {"category":"Far-field galaxies/cosmology", "gates":"GC-2I", "score":"PARTIAL_ARCHITECTURE_PASS", "summary":"a_S and lambda/Pcoh split protected; high-z inequality derived; E reconciliation open."},
    {"category":"Static spherical strong field", "gates":"GC-2J/R1/R2/R3", "score":"BOUNDED_RESTORATION", "summary":"Exact Schwarzschild restored in static spherical areal-capacity sector with explicit axioms."},
    {"category":"Radiation", "gates":"GC-2K", "score":"FRONTIER_PARTIAL", "summary":"TT skeleton alive; scalar/dipole/power/binary pulsar open."},
    {"category":"Equivalence", "gates":"GC-2L", "score":"FRONTIER_PARTIAL", "summary":"Universal kappa route identified; binding/self-energy open."},
    {"category":"Frame dragging", "gates":"GC-2M", "score":"TOPOLOGY_PASS_ONLY", "summary":"Mixed channel topology works; coefficient/transport/Kerr open."},
]
pd.DataFrame(score_rows).to_csv(out / "gc2n_scorecard_summary.csv", index=False)

open_debts = [
    ["Numerical root area a_phi / measured G value", "FOUNDATIONAL_OPEN"],
    ["Full covariant field equation / tensor dynamics", "FOUNDATIONAL_OPEN"],
    ["Scalar breathing / dipole suppression proof", "HIGH_STAKES"],
    ["Quadrupole radiation power coefficient and binary-pulsar energy loss", "HIGH_STAKES"],
    ["Binding/self-energy universality and compact-object scalar sensitivity", "HIGH_STAKES"],
    ["Lense-Thirring coefficient and gyroscope transport law", "HIGH_STAKES"],
    ["Kerr / rotating black holes / strong-field spin", "HIGH_STAKES"],
    ["Dynamic collapse, ringdown, horizon microphysics, thermodynamics", "HIGH_STAKES"],
]
pd.DataFrame(open_debts, columns=["debt","severity"]).to_csv(out / "gc2n_open_debt_summary.csv", index=False)

verdict = {
    "verdict": "GRAVITY_CANON_MAINLINE_ROLLUP_COMPLETE",
    "weak_field_metric": "STRONG_PASS",
    "static_spherical_schwarzschild": "RESTORED_WITH_EXPLICIT_AREAL_CAPACITY_AXIOMS",
    "normalization": "STRUCTURE_PASS_VALUE_OPEN",
    "frontiers": ["radiation", "SEP", "frame dragging", "Kerr", "G-root numerical value"]
}
(out / "gc2n_verdict.json").write_text(json.dumps(verdict, indent=2))
print("GC2N rollup tables rebuilt:", out)
