#!/usr/bin/env python3
"""
Run all key SFT V13.1-V2 Gravity Canon repro scripts.

This regenerates the compact diagnostic outputs in ./repro_outputs.
The frozen archive results remain in ../results and should be treated as the canonical v0.1 outputs.
"""
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "repro_outputs"
OUT.mkdir(exist_ok=True)

scripts = [
    "rebuild_gc2j_r3_areal_capacity.py",
    "rebuild_gc2k_radiation_frontier.py",
    "rebuild_gc2l_gsep_frontier.py",
    "rebuild_gc2m_frame_dragging.py",
    "rebuild_gc2n_rollup_tables.py",
]

for script in scripts:
    print(f"\n=== running {script} ===")
    subprocess.check_call([sys.executable, str(HERE / script), str(OUT)])

print(f"\nDone. Rebuilt outputs in: {OUT}")
