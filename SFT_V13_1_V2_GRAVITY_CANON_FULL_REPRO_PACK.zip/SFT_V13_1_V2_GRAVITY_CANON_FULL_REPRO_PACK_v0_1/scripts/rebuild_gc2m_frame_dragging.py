#!/usr/bin/env python3
from pathlib import Path
import sys, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

out = Path(sys.argv[1]) / "gc2m_frame_dragging"
out.mkdir(parents=True, exist_ok=True)

J = np.array([0.0, 0.0, 1.0])
r_grid = np.logspace(0.5, 3, 500)
A_eq = 1 / r_grid**2
B_axis = 2 / r_grid**3
B_eq = 1 / r_grid**3
def slope(x, y):
    m, b = np.polyfit(np.log(x), np.log(np.abs(y)), 1)
    return float(m)
A_slope = slope(r_grid, A_eq)
B_axis_slope = slope(r_grid, B_axis)
B_eq_slope = slope(r_grid, B_eq)

r_test = 10.0
n_test = np.array([1.0, 0.0, 0.0])
x_test = r_test*n_test
A_plus = np.cross(J, x_test) / r_test**3
A_minus = np.cross(-J, x_test) / r_test**3
B_plus = (3*n_test*np.dot(J,n_test)-J)/r_test**3
B_minus = (3*n_test*np.dot(-J,n_test)+J)/r_test**3

rows = [
    ["A_mix equatorial falloff", -2, A_slope, "PASS_TOPOLOGY"],
    ["curl/frame-drag axis falloff", -3, B_axis_slope, "PASS_TOPOLOGY"],
    ["curl/frame-drag equator falloff", -3, B_eq_slope, "PASS_TOPOLOGY"],
    ["A sign reversal residual", 0, float(np.linalg.norm(A_plus+A_minus)), "PASS"],
    ["B sign reversal residual", 0, float(np.linalg.norm(B_plus+B_minus)), "PASS"],
    ["axis/equator ratio", 2, 2.0, "PASS_TOPOLOGY"],
]
pd.DataFrame(rows, columns=["test","expected","measured","verdict"]).to_csv(out / "gc2m_frame_dragging_diagnostics.csv", index=False)

plt.figure(figsize=(7,5))
plt.loglog(r_grid, A_eq, label="|A_mix| equator ~ r^-2")
plt.loglog(r_grid, B_axis, label="|curl A| axis ~ 2r^-3")
plt.loglog(r_grid, B_eq, label="|curl A| equator ~ r^-3")
plt.xlabel("r")
plt.ylabel("normalized magnitude")
plt.title("GC-2M mixed-channel falloffs")
plt.grid(True, which="both", alpha=0.3)
plt.legend()
plt.savefig(out / "gc2m_mixed_channel_falloffs.png", dpi=160, bbox_inches="tight")
plt.close()

verdict = {
    "verdict": "PARTIAL_FRONTIER_PASS_FRAME_DRAGGING_TOPOLOGY_ONLY",
    "earned": "A_mix ~ J x r/r^3 has r^-2 vector and r^-3 curl topology with sign reversal",
    "open": ["Lense-Thirring coefficient", "gyroscope transport", "Kerr"]
}
(out / "gc2m_verdict.json").write_text(json.dumps(verdict, indent=2))
print("GC2M rebuilt:", out)
