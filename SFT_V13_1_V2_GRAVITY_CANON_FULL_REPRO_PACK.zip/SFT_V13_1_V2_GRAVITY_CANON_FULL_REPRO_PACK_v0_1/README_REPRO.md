# SFT V13.1-V2 Gravity Canon Full Repro Pack v0.1

## Master verdict

```text
SFT_V13_1_V2_GRAVITY_CANON_FULL_REPRO_PACK_V0_1_CREATED_SCRIPTS_RESULTS_PRIOR_GATE_BUNDLES_PAPER_AND_MANIFESTS_INCLUDED
```

## Purpose

This pack preserves the route back to the SFT V13.1-V2 Gravity Canon derivation.

It includes:

```text
/paper
    PDF, DOCX, and paper bundle for the derivation paper

/scripts
    runnable scripts that regenerate key numeric diagnostics

/results
    frozen gate outputs: CSVs, PNGs, ledgers, capsules, scorecards, manifests

/prior_gate_bundles
    original gate bundles from GC-2A through GC-2N, including GC-2J-R1/R2/R3

/manifests
    top-level hash manifests and file inventories

/docs
    reproduction notes and claim-boundary notes
```

## Recommended use

To inspect the frozen canon, start with:

```text
paper/SFT_V13_1_V2_Gravity_Canon_Derivation_Paper_v0_1.pdf
results/sft_v13_1_v2_gc2n_gravity_canon_rollup_v0_1/GC2N_gravity_canon_mainline_rollup_v0_1.md
results/sft_v13_1_v2_gc2n_gravity_canon_rollup_v0_1/GC2N_public_claim_boundary_registry_v0_1.csv
```

To rerun the compact numeric diagnostics:

```bash
cd scripts
python run_all_gravity_canon.py
```

The scripts will write new outputs to:

```text
repro_outputs/
```

## Canon boundaries

This pack supports these bounded claims:

```text
weak-field metric gravity: strong pass
static spherical Schwarzschild: restored with explicit areal-capacity axioms
normalization: structure earned, numerical G/root area open
far-field: architecture partial, high-z inequality derived
radiation: TT skeleton only
SEP: universal-kappa route only
frame dragging: topology only
```

It does not claim:

```text
numerical derivation of G
full covariant field equations
binary-pulsar pass
complete gravitational waves
full SEP
Lense-Thirring coefficient
Kerr
dynamic collapse / ringdown / thermodynamics / horizon microphysics
```

## Missing items at creation

Missing prior bundles:
[]

Missing result directories:
[]
