# Claim Boundary Notes

Use GC2N_public_claim_boundary_registry_v0_1.csv as the source of truth.

Most important public boundary:

Allowed:
- Weak-field gamma=1 and factor-two light bending in the metric sector.
- Static spherical Schwarzschild exterior restored with explicit areal-capacity axioms.
- Horizon as continuation-capacity exhaustion at R=2M in that bounded sector.

Not allowed:
- Numerical derivation of G.
- SFT solved all black-hole physics.
- SFT passes binary pulsars.
- SFT derives Kerr.
- SFT derives frame-dragging coefficient.
- SFT proves full SEP.
