#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_07:
H as Background Settlement Update Rate Audit

Purpose
-------
GRAV_TRAJ_05 constrained the settlement acceleration scale to the horizon
phase-cycle class:

    a_S = cH/(2*pi).

GRAV_TRAJ_06 selected the 2*pi phase-cycle coupling operationally.

GRAV_TRAJ_07 now audits the remaining upstream question:

    Why should the background settlement update rate be H?

This gate does NOT fit MOND.
It does NOT use SPARC, galaxy data, kSZ data, or observed a0 as an input.
It does NOT claim a final microscopic derivation of H.

It tests whether H is the correct no-fit background update-rate candidate
because it is simultaneously:

    1. a fractional ledger update rate,
    2. a causal horizon-crossing rate c/R_H,
    3. the rate that makes H R_H / c = 1,
    4. compatible with the V12.1 recombination local-ledger radii,
    5. compatible with the GRAV_TRAJ_06 phase-cycle attachment,
    6. not target-inverted from observed a0.

Claim boundary
--------------
A pass means:
    H survives as the correct background settlement update-rate candidate
    for the GRAV_TRAJ_05/06 acceleration scale.

A pass does NOT mean:
    SFT derives cosmological expansion from first principles,
    SFT derives H0 numerically,
    SFT derives a0,
    SFT fits SPARC/RAR,
    SFT predicts kSZ,
    or SFT completes far-field gravity.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_07_OUTPUT")

# Constants.
C = 299_792_458.0
MPC = 3.0856775814913673e22
LY = 9.4607304725808e15
MLY = 1.0e6 * LY
EV = 1.602176634e-19
HBAR = 1.054571817e-34

# Fiducial background value. This is not a precision cosmology fit.
H0_FID_KM_S_MPC = 70.0
H0_FID = H0_FID_KM_S_MPC * 1000.0 / MPC
R_H_FID = C / H0_FID
T_H_FID = 1.0 / H0_FID

# Diagnostic only: not used to select H.
A0_BENCHMARK_OPTIONAL = 1.2e-10

# Prior SFT ledger radii from earlier gates.
R_REC_HUBBLE_MLY = 0.6246982112007
R_V12_EFF_REC_MLY = 0.6281043601339

# QG/V12 handoff energy scale used only as a "wrong class" microscopic clock control.
E_ROOT_MEV = 69.30067818338


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def a_phase_from_rate(rate: float) -> float:
    return C * rate / (2.0 * math.pi)


def candidate_rate_rows() -> list[dict]:
    exact_H_from_optional_a0 = 2.0 * math.pi * A0_BENCHMARK_OPTIONAL / C
    Eroot_J = E_ROOT_MEV * 1.0e6 * EV
    omega_root = Eroot_J / HBAR

    candidates = [
        {
            "candidate": "cosmological_fractional_rate_H",
            "rate_s_inv": H0_FID,
            "formula": "H = dot(a)/a",
            "role": "primary background fractional ledger update rate",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_kSZ_data": False,
            "class": "background_fractional",
        },
        {
            "candidate": "horizon_crossing_rate_c_over_RH",
            "rate_s_inv": C / R_H_FID,
            "formula": "c/R_H",
            "role": "equivalent horizon-crossing face of H",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_kSZ_data": False,
            "class": "background_horizon",
        },
        {
            "candidate": "post_phase_cycle_rate_H_over_2pi",
            "rate_s_inv": H0_FID / (2.0*math.pi),
            "formula": "H/(2*pi)",
            "role": "post-coupling completed-cycle rate, not base background update rate",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_kSZ_data": False,
            "class": "post_phase_conversion",
        },
        {
            "candidate": "double_count_angular_rate_2piH",
            "rate_s_inv": 2.0*math.pi*H0_FID,
            "formula": "2*pi*H",
            "role": "double-counted angular conversion control",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_kSZ_data": False,
            "class": "double_count_control",
        },
        {
            "candidate": "fixed_galactic_length_c_over_10kpc",
            "rate_s_inv": C / (10.0 * 1000.0 * 3.261563777 * LY),
            "formula": "c/(10 kpc)",
            "role": "arbitrary local length control",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_kSZ_data": False,
            "class": "arbitrary_local_length",
        },
        {
            "candidate": "microscopic_root_clock_Eroot_over_hbar",
            "rate_s_inv": omega_root,
            "formula": "E_root/hbar",
            "role": "microscopic phase clock control; wrong background class",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_kSZ_data": False,
            "class": "microscopic_local_clock",
        },
        {
            "candidate": "exact_H_from_optional_a0_control",
            "rate_s_inv": exact_H_from_optional_a0,
            "formula": "H = 2*pi*a0_optional/c",
            "role": "forbidden target inversion",
            "uses_observed_a0": True,
            "uses_galaxy_data": True,
            "uses_kSZ_data": False,
            "class": "forbidden_target_inversion",
        },
    ]

    rows = []
    for c in candidates:
        rate = c["rate_s_inv"]
        R_rate = C / rate if rate > 0 else float("nan")
        a_phase = a_phase_from_rate(rate)
        H_ratio = rate / H0_FID

        # Internal score: not numerical target agreement.
        fractional_pass = c["class"] in ["background_fractional", "background_horizon"]
        horizon_pass = abs(rate * R_rate / C - 1.0) < 1e-14 if rate > 0 else False
        global_background_pass = c["class"] in ["background_fractional", "background_horizon"]
        phase_attach_ready = c["class"] in ["background_fractional", "background_horizon"]
        no_target_pass = not c["uses_observed_a0"]

        score = sum([fractional_pass, horizon_pass, global_background_pass, phase_attach_ready, no_target_pass]) / 5.0

        if c["candidate"] == "cosmological_fractional_rate_H":
            status = "PRIMARY_SETTLEMENT_UPDATE_RATE_CANDIDATE"
        elif c["candidate"] == "horizon_crossing_rate_c_over_RH":
            status = "EQUIVALENT_PRIMARY_HORIZON_FACE"
        elif c["uses_observed_a0"]:
            status = "FORBIDDEN_TARGET_CONTROL"
        else:
            status = "REJECTED_RATE_CONTROL"

        rows.append({
            **c,
            "H_ratio": H_ratio,
            "implied_radius_m": R_rate,
            "implied_radius_Gly": R_rate / LY / 1.0e9,
            "rate_times_radius_over_c": rate * R_rate / C if rate > 0 else float("nan"),
            "phase_cycle_acceleration_m_s2": a_phase,
            "phase_acceleration_ratio_to_GRAV05_primary": a_phase / a_phase_from_rate(H0_FID),
            "factor_error_vs_optional_a0_benchmark": max(a_phase/A0_BENCHMARK_OPTIONAL, A0_BENCHMARK_OPTIONAL/a_phase),
            "fractional_ledger_rate_pass": fractional_pass,
            "horizon_crossing_identity_pass": horizon_pass,
            "global_background_class_pass": global_background_pass,
            "phase_attachment_ready_pass": phase_attach_ready,
            "no_target_pass": no_target_pass,
            "internal_settlement_rate_score": score,
            "status": status,
        })
    return rows


def ledger_bridge_rows() -> list[dict]:
    ledgers = [
        ("present_fiducial_Hubble_ledger", R_H_FID, "present background horizon from H0"),
        ("Gate11R_recombination_Hubble_radius", R_REC_HUBBLE_MLY*MLY, "Gate 11R local recombination Hubble ledger"),
        ("V12_1_locked_effective_recombination_radius", R_V12_EFF_REC_MLY*MLY, "V12.1 locked local recombination ledger"),
    ]
    rows = []
    for name, R, desc in ledgers:
        H_R = C/R
        tau = R/C
        a_phase = a_phase_from_rate(H_R)
        rows.append({
            "ledger": name,
            "description": desc,
            "R_m": R,
            "R_Mly": R/MLY,
            "R_Gly": R/LY/1e9,
            "tau_crossing_s": tau,
            "H_R_c_over_R_s_inv": H_R,
            "H_R_tau": H_R*tau,
            "H_R_R_over_c": H_R*R/C,
            "phase_cycle_rate_H_over_2pi": H_R/(2.0*math.pi),
            "a_phase_cH_over_2pi": a_phase,
            "a_phase_R_over_c2": a_phase*R/(C*C),
            "target_1_over_2pi": 1.0/(2.0*math.pi),
            "fractional_error_to_1_over_2pi": (a_phase*R/(C*C))/(1.0/(2.0*math.pi))-1.0,
            "status": "PASS_LEDGER_RATE_IDENTITY" if abs(H_R*R/C - 1.0) < 1e-14 else "FAIL",
        })
    return rows


def update_law_rows() -> list[dict]:
    """
    Toy ledger update laws to clarify what H does.
    x is a dimensionless ledger scale. H is a fractional update rate:
        dx/dt = H x.
    This is not a cosmology fit; it is an operational rate-class check.
    """
    rows = []
    t_values = [0.0, 0.25*T_H_FID, 0.5*T_H_FID, 1.0*T_H_FID, 2.0*T_H_FID]
    for rate_name, rate in [
        ("H", H0_FID),
        ("H_over_2pi_post_cycle", H0_FID/(2.0*math.pi)),
        ("two_pi_H_double_count", 2.0*math.pi*H0_FID),
    ]:
        for t in t_values:
            x = math.exp(rate*t)
            rows.append({
                "rate_case": rate_name,
                "rate_s_inv": rate,
                "t_over_Hubble_time": t/T_H_FID,
                "ledger_scale_factor_exp_rate_t": x,
                "ln_growth": math.log(x),
                "interpretation": (
                    "H gives one e-fold per Hubble time as fractional update; "
                    "H/(2pi) is post phase-cycle rate; 2piH is double-counted control"
                ),
            })
    return rows


def no_cheat_control_rows(candidates) -> list[dict]:
    rows = []
    for r in candidates:
        if r["status"] in ["PRIMARY_SETTLEMENT_UPDATE_RATE_CANDIDATE", "EQUIVALENT_PRIMARY_HORIZON_FACE"]:
            reason = "passes background fractional/horizon identity and uses no target acceleration"
        elif r["status"] == "FORBIDDEN_TARGET_CONTROL":
            reason = "constructed from optional observed a0 benchmark"
        elif r["candidate"] == "post_phase_cycle_rate_H_over_2pi":
            reason = "valid as completed-cycle rate after GRAV_TRAJ_06, but wrong as base update rate because it double-applies phase conversion"
        elif r["candidate"] == "double_count_angular_rate_2piH":
            reason = "double-counts angular conversion before phase-cycle attachment"
        elif r["candidate"] == "fixed_galactic_length_c_over_10kpc":
            reason = "arbitrary local length; not background settlement ledger"
        elif r["candidate"] == "microscopic_root_clock_Eroot_over_hbar":
            reason = "microscopic local clock; wrong class for background horizon update"
        else:
            reason = "rejected control"
        rows.append({
            "candidate": r["candidate"],
            "status": r["status"],
            "internal_settlement_rate_score": r["internal_settlement_rate_score"],
            "uses_observed_a0": r["uses_observed_a0"],
            "factor_error_vs_optional_a0_benchmark": r["factor_error_vs_optional_a0_benchmark"],
            "reason": reason,
        })
    return rows


def dependency_debt_rows() -> list[dict]:
    return [
        {
            "debt": "D1_microderive_H",
            "status": "PARTIALLY_CONSTRAINED_NOT_CLOSED",
            "description": "GRAV_TRAJ_07 identifies H as the correct background update-rate candidate, but does not derive H from microscopic SFT dynamics.",
            "next_test": "derive H from no-overwrite settlement ledger relaxation rather than assume cosmological background rate",
        },
        {
            "debt": "D2_link_H_to_expansion",
            "status": "OPEN",
            "description": "Need show how the same H-rate emerges from SFT expansion dynamics, not only from the horizon identity R=c/H.",
            "next_test": "connect V12.1 settlement relaxation Q(T) or V11.1B diffusion to H(t)",
        },
        {
            "debt": "D3_time_dependence_H_of_t",
            "status": "OPEN",
            "description": "Need extend from fiducial or local ledger H to time-dependent H(t) across cosmological epochs.",
            "next_test": "test a_S(t)=cH(t)/(2pi) across recombination/late-time ledgers without data fitting",
        },
        {
            "debt": "D4_environment_factor_E",
            "status": "OPEN",
            "description": "Need derive environment factor E from settlement density/boundary connectivity, not per-galaxy tuning.",
            "next_test": "build falsifiable E predictor before SPARC/kSZ comparison",
        },
        {
            "debt": "D5_data_comparison",
            "status": "DEFERRED",
            "description": "SPARC/RAR/kSZ comparisons remain deferred until H(t) and E are mechanistically specified.",
            "next_test": "only compare to data after D1-D4 produce non-tuned predictions",
        },
    ]


def verdict_row(candidates, ledgers, controls):
    primary = next(r for r in candidates if r["candidate"] == "cosmological_fractional_rate_H")
    horizon = next(r for r in candidates if r["candidate"] == "horizon_crossing_rate_c_over_RH")
    forbidden = next(r for r in candidates if r["candidate"] == "exact_H_from_optional_a0_control")

    primary_pass = primary["status"] == "PRIMARY_SETTLEMENT_UPDATE_RATE_CANDIDATE" and primary["internal_settlement_rate_score"] == 1.0
    horizon_pass = horizon["status"] == "EQUIVALENT_PRIMARY_HORIZON_FACE" and abs(horizon["H_ratio"] - 1.0) < 1e-14
    ledger_pass = all(r["status"] == "PASS_LEDGER_RATE_IDENTITY" and abs(r["fractional_error_to_1_over_2pi"]) < 1e-14 for r in ledgers)
    forbidden_pass = forbidden["status"] == "FORBIDDEN_TARGET_CONTROL" and forbidden["uses_observed_a0"]
    rejected_controls_pass = all(
        r["status"] in ["PRIMARY_SETTLEMENT_UPDATE_RATE_CANDIDATE", "EQUIVALENT_PRIMARY_HORIZON_FACE", "REJECTED_RATE_CONTROL", "FORBIDDEN_TARGET_CONTROL"]
        for r in candidates
    )

    ok = primary_pass and horizon_pass and ledger_pass and forbidden_pass and rejected_controls_pass

    return {
        "verdict": "H_SURVIVES_AS_BACKGROUND_SETTLEMENT_UPDATE_RATE_CANDIDATE" if ok else "H_SETTLEMENT_RATE_IDENTIFICATION_REQUIRES_REVISION",
        "claim_boundary": "background-rate identification audit only; not microscopic derivation of H, a0, expansion, SPARC/RAR, kSZ, or nonlinear gravity",
        "selected_rate": "H",
        "selected_rate_s_inv_fiducial": H0_FID,
        "selected_rate_formula": "H = dot(a)/a = c/R_H",
        "H0_fid_km_s_Mpc": H0_FID_KM_S_MPC,
        "horizon_radius_Gly": R_H_FID/LY/1.0e9,
        "hubble_time_Gyr": T_H_FID/(365.25*24*3600)/1.0e9,
        "phase_attached_acceleration_cH_over_2pi": a_phase_from_rate(H0_FID),
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_kSZ_data": False,
        "primary_rate_pass": primary_pass,
        "horizon_equivalence_pass": horizon_pass,
        "ledger_identity_pass": ledger_pass,
        "forbidden_target_control_marked": forbidden_pass,
        "rejected_controls_pass": rejected_controls_pass,
        "main_result": "H is the unique no-fit background fractional/horizon update-rate candidate compatible with GRAV_TRAJ_06 phase-cycle attachment.",
        "paper_safe_sentence": (
            "GRAV_TRAJ_07 audits the remaining upstream assumption in the settlement acceleration chain: why the background update rate should be H. "
            "The cosmological fractional rate H and the causal horizon-crossing rate c/R_H are the same ledger identity, satisfying H R_H/c=1 and giving one fractional background update per Hubble time. "
            "The V12.1 recombination local-ledger radii obey the same identity when written as H_R=c/R, and after the GRAV_TRAJ_06 phase-cycle coupling they preserve a_R R/c^2=1/(2pi). "
            "Controls using H/(2pi) as the base rate, 2pi H, fixed galactic lengths, microscopic root clocks, or target-inverted observed a0 fail the rate-role audit or are quarantined. "
            "This supports H as the correct background settlement update-rate candidate for a_S=cH/(2pi), while leaving open the microscopic SFT derivation of H(t), the expansion dynamics, and the environment factor E."
        ),
        "next_gate": (
            "GRAV_TRAJ_08 should move from identifying H to deriving H(t) or E: either connect H(t) to V12.1/V11.1B settlement relaxation, "
            "or define the environment factor E from settlement density so that non-MOND deviations are predicted without tuning."
        ),
    }


def save_plots(candidates, ledgers, update_rows):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # Candidate rate scales.
        plt.figure(figsize=(10,5))
        labels = [r["candidate"] for r in candidates]
        vals = [r["rate_s_inv"] for r in candidates]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.yscale("log")
        plt.axhline(H0_FID, linestyle="--", linewidth=1, label="H fiducial")
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("rate (s^-1)")
        plt.title("GRAV_TRAJ_07: candidate background update rates")
        plt.legend()
        plt.tight_layout()
        p = OUT/"grav_traj_07_candidate_rates.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Scores.
        plt.figure(figsize=(10,5))
        scores = [r["internal_settlement_rate_score"] for r in candidates]
        plt.scatter(x, scores)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("internal settlement-rate score")
        plt.title("GRAV_TRAJ_07: H selector scores")
        plt.tight_layout()
        p = OUT/"grav_traj_07_rate_selector_scores.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Ledger invariant.
        plt.figure(figsize=(8,5))
        x2 = np.arange(len(ledgers))
        vals2 = [r["H_R_R_over_c"] for r in ledgers]
        labels2 = [r["ledger"] for r in ledgers]
        plt.scatter(x2, vals2)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xticks(x2, labels2, rotation=25, ha="right", fontsize=8)
        plt.ylabel("H_R R / c")
        plt.title("GRAV_TRAJ_07: horizon ledger identity")
        plt.tight_layout()
        p = OUT/"grav_traj_07_horizon_ledger_identity.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Update law.
        plt.figure(figsize=(8,5))
        for case in sorted(set(r["rate_case"] for r in update_rows)):
            sub = [r for r in update_rows if r["rate_case"] == case]
            plt.plot([r["t_over_Hubble_time"] for r in sub], [r["ledger_scale_factor_exp_rate_t"] for r in sub], marker="o", label=case)
        plt.xlabel("t / Hubble time")
        plt.ylabel("toy ledger scale exp(rate*t)")
        plt.title("GRAV_TRAJ_07: fractional update law controls")
        plt.legend()
        plt.tight_layout()
        p = OUT/"grav_traj_07_update_law_controls.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, candidates, ledgers, update_rows, controls, debts, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_07: H as Background Settlement Update Rate Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## Candidate update rates\n\n")
    lines.append("| Candidate | H ratio | rate | score | status |\n")
    lines.append("|---|---:|---:|---:|---|\n")
    for r in candidates:
        lines.append(f"| {r['candidate']} | {r['H_ratio']:.6e} | {r['rate_s_inv']:.6e} | {r['internal_settlement_rate_score']:.3f} | {r['status']} |\n")

    lines.append("\n## Horizon ledger bridge\n\n")
    lines.append("| Ledger | R (Mly) | H_R=c/R | H_R R/c | aR/c^2 after 2pi |\n")
    lines.append("|---|---:|---:|---:|---:|\n")
    for r in ledgers:
        lines.append(f"| {r['ledger']} | {r['R_Mly']:.12f} | {r['H_R_c_over_R_s_inv']:.6e} | {r['H_R_R_over_c']:.12f} | {r['a_phase_R_over_c2']:.12e} |\n")

    lines.append("\n## Controls\n\n")
    lines.append("| Candidate | status | reason |\n")
    lines.append("|---|---|---|\n")
    for r in controls:
        lines.append(f"| {r['candidate']} | {r['status']} | {r['reason']} |\n")

    lines.append("\n## Remaining debts\n\n")
    lines.append("| Debt | status | description |\n")
    lines.append("|---|---|---|\n")
    for r in debts:
        lines.append(f"| {r['debt']} | {r['status']} | {r['description']} |\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    candidates = candidate_rate_rows()
    ledgers = ledger_bridge_rows()
    updates = update_law_rows()
    controls = no_cheat_control_rows(candidates)
    debts = dependency_debt_rows()
    verdict = verdict_row(candidates, ledgers, controls)

    write_csv(OUT/"grav_traj_07_H_settlement_rate_checks.csv", candidates)
    write_csv(OUT/"grav_traj_07_horizon_ledger_bridge.csv", ledgers)
    write_csv(OUT/"grav_traj_07_update_law_controls.csv", updates)
    write_csv(OUT/"grav_traj_07_controls.csv", controls)
    write_csv(OUT/"grav_traj_07_dependency_debts.csv", debts)
    write_csv(OUT/"grav_traj_07_verdict.csv", [verdict])

    plots = save_plots(candidates, ledgers, updates)
    write_report(OUT/"GRAV_TRAJ_07_H_settlement_rate_report.md", candidates, ledgers, updates, controls, debts, verdict)

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_07",
        "purpose": "H as background settlement update-rate audit",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "files": [
            "grav_traj_07_H_settlement_rate_checks.csv",
            "grav_traj_07_horizon_ledger_bridge.csv",
            "grav_traj_07_update_law_controls.csv",
            "grav_traj_07_controls.csv",
            "grav_traj_07_dependency_debts.csv",
            "grav_traj_07_verdict.csv",
            "GRAV_TRAJ_07_H_settlement_rate_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_07 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Audit why H is the background settlement update-rate candidate for a_S=cH/(2pi).")
    print("  No observed a0, SPARC, galaxy data, or kSZ data are used.")

    print("\nH settlement-rate candidate audit:")
    for r in candidates:
        print(
            f"  {r['candidate']:42s}  "
            f"rate={r['rate_s_inv']:.6e} s^-1  "
            f"H_ratio={r['H_ratio']:.6e}  "
            f"score={r['internal_settlement_rate_score']:.3f}  "
            f"a_phase={r['phase_cycle_acceleration_m_s2']:.6e}  "
            f"{r['status']}"
        )

    print("\nHorizon ledger bridge:")
    for r in ledgers:
        print(
            f"  {r['ledger']:45s}  "
            f"R={r['R_Mly']:.12f} Mly  "
            f"H_R=c/R={r['H_R_c_over_R_s_inv']:.6e}  "
            f"H_R R/c={r['H_R_R_over_c']:.12f}  "
            f"aR/c2={r['a_phase_R_over_c2']:.12e}"
        )

    print("\nUpdate-law controls:")
    for case in ["H", "H_over_2pi_post_cycle", "two_pi_H_double_count"]:
        sub = [r for r in updates if r["rate_case"] == case and abs(r["t_over_Hubble_time"]-1.0) < 1e-12][0]
        print(
            f"  {case:26s}  "
            f"at t=1/H: ln_growth={sub['ln_growth']:.6f}  "
            f"scale={sub['ledger_scale_factor_exp_rate_t']:.6f}"
        )

    print("\nControls:")
    for r in controls:
        print(
            f"  {r['candidate']:42s}  "
            f"score={r['internal_settlement_rate_score']:.3f}  "
            f"{r['status']}  "
            f"{r['reason']}"
        )

    print("\nRemaining debts:")
    for r in debts:
        print(f"  {r['debt']:26s}  {r['status']:32s}  {r['description']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_07_H_settlement_rate_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_07_verdict.csv'}")
    print(f"  H checks csv: {OUT/'grav_traj_07_H_settlement_rate_checks.csv'}")
    print(f"  horizon bridge csv: {OUT/'grav_traj_07_horizon_ledger_bridge.csv'}")
    print(f"  update controls csv: {OUT/'grav_traj_07_update_law_controls.csv'}")
    print(f"  controls csv: {OUT/'grav_traj_07_controls.csv'}")
    print(f"  debts csv: {OUT/'grav_traj_07_dependency_debts.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
