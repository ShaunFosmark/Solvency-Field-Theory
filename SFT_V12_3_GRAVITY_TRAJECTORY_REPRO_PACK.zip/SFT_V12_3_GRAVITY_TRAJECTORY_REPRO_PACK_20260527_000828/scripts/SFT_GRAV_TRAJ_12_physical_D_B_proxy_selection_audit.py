#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_12:
Physical D/B Observable Proxy Selection Audit

Purpose
-------
GRAV_TRAJ_09 selected the structural environment factor

    E = sqrt(D B)

GRAV_TRAJ_10 proved that D and B can be computed from frozen synthetic
field/graph estimators before data.

GRAV_TRAJ_11 proved the safety guardrail:

    E may enter only the far-field settlement handoff:
        a_eff = E a_S(t)
        r_t(E) = sqrt(GM/(E a_S))
    and must NOT enter local F, B_metric, phi, M, or G.

GRAV_TRAJ_12 now selects physical observable proxy classes for D and B
without using observational residuals.

This gate does NOT use observed a0, SPARC, RAR, galaxy rotation curves,
cluster residuals, kSZ data, or any fit target.

It is a selection audit:
    - Which physical proxy should represent rho_set?
    - Which physical proxy should represent C_boundary?
    - Which kernel/region scale should be frozen before data?
    - Does the selected bundle obey the Gate 11 local-metric guardrail?

Claim boundary
--------------
A pass means:
    A physically interpretable, computable, no-target proxy bundle is selected
    for future blind prediction protocols.

A pass does NOT mean:
    The selected proxies are final truth,
    SFT has fitted SPARC/RAR,
    SFT has solved clusters,
    SFT has predicted kSZ,
    or SFT has completed far-field/nonlinear gravity.

Stacking decision
-----------------
This script may emit a GRAV_TRAJ_13 blind protocol blueprint if it passes.
It does NOT run data validation.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_12_OUTPUT")

# Constants for scale examples only.
C = 299_792_458.0
G = 6.67430e-11
M_SUN = 1.98847e30
KPC = 3.0856775814913673e19
MPC = 3.0856775814913673e22
H0_FID_KM_S_MPC = 70.0
H0_FID = H0_FID_KM_S_MPC * 1000.0 / MPC
A_S_BACKGROUND = C * H0_FID / (2.0 * math.pi)

# Gate 11 hard guardrail.
E_ALLOWED_SECTOR = "far_field_transition_only"
E_FORBIDDEN_SECTORS = ["local_metric_F", "local_metric_B", "phi", "local_source_mass_M", "G", "PPN_gamma_beta"]

# Gate 12 selected bundle names.
SELECTED_D_PROXY = "operation_density_rho_plus_3p_proxy"
SELECTED_B_PROXY = "source_graph_boundary_conductance_proxy"
SELECTED_SCALE = "background_transition_radius_r0_sqrt_GM_over_aS"


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def bool_score(flags: list[bool]) -> float:
    return sum(1 for f in flags if f) / len(flags)


# ---------------------------------------------------------------------
# Candidate proxy definitions
# ---------------------------------------------------------------------

def D_proxy_candidate_rows() -> list[dict]:
    """
    Score physical rho_set proxy candidates.

    Hard no-target criteria:
      - must be computable before residuals,
      - must be nonnegative,
      - must connect to SFT source/operation density,
      - must reduce sensibly for cold baryonic systems,
      - must not import dark halo fit or acceleration residuals,
      - must preserve Gate 11 local-metric guardrail.
    """
    candidates = [
        {
            "candidate": "operation_density_rho_plus_3p_proxy",
            "definition": "rho_set proportional to rho_b + 3p_b/c^2, i.e. the late-system continuation of the GRAV_TRAJ_03 operation/source-density rule",
            "computable_pre_data": True,
            "nonnegative": True,
            "connects_gate03_rho_plus_3p": True,
            "cold_baryon_limit_ok": True,
            "handles_pressure_radiation_extension": True,
            "uses_dark_halo_or_residual": False,
            "has_free_fit_parameter": False,
            "gate11_guardrail_ok": True,
            "role": "primary D proxy",
        },
        {
            "candidate": "cold_baryonic_source_density_proxy",
            "definition": "rho_set proportional to smoothed observed/inferred baryonic mass density for cold systems",
            "computable_pre_data": True,
            "nonnegative": True,
            "connects_gate03_rho_plus_3p": False,
            "cold_baryon_limit_ok": True,
            "handles_pressure_radiation_extension": False,
            "uses_dark_halo_or_residual": False,
            "has_free_fit_parameter": False,
            "gate11_guardrail_ok": True,
            "role": "cold-system simplification / companion proxy",
        },
        {
            "candidate": "simulation_settlement_demand_proxy",
            "definition": "rho_set from a simulation-derived source/settlement-demand field frozen before comparison",
            "computable_pre_data": True,
            "nonnegative": True,
            "connects_gate03_rho_plus_3p": True,
            "cold_baryon_limit_ok": True,
            "handles_pressure_radiation_extension": True,
            "uses_dark_halo_or_residual": False,
            "has_free_fit_parameter": False,
            "gate11_guardrail_ok": True,
            "role": "companion simulation proxy, risk of imported priors",
        },
        {
            "candidate": "stellar_light_only_proxy",
            "definition": "rho_set from stellar light only",
            "computable_pre_data": True,
            "nonnegative": True,
            "connects_gate03_rho_plus_3p": False,
            "cold_baryon_limit_ok": False,
            "handles_pressure_radiation_extension": False,
            "uses_dark_halo_or_residual": False,
            "has_free_fit_parameter": True,
            "gate11_guardrail_ok": True,
            "role": "incomplete baryonic tracer control",
        },
        {
            "candidate": "dark_halo_density_proxy",
            "definition": "rho_set from an inferred dark-halo density profile",
            "computable_pre_data": False,
            "nonnegative": True,
            "connects_gate03_rho_plus_3p": False,
            "cold_baryon_limit_ok": False,
            "handles_pressure_radiation_extension": False,
            "uses_dark_halo_or_residual": True,
            "has_free_fit_parameter": True,
            "gate11_guardrail_ok": False,
            "role": "reject imported fitted halo control",
        },
        {
            "candidate": "rotation_curve_residual_proxy",
            "definition": "rho_set chosen from acceleration or velocity residuals",
            "computable_pre_data": False,
            "nonnegative": True,
            "connects_gate03_rho_plus_3p": False,
            "cold_baryon_limit_ok": False,
            "handles_pressure_radiation_extension": False,
            "uses_dark_halo_or_residual": True,
            "has_free_fit_parameter": True,
            "gate11_guardrail_ok": False,
            "role": "forbidden target control",
        },
    ]

    rows = []
    for c in candidates:
        flags = [
            c["computable_pre_data"],
            c["nonnegative"],
            c["connects_gate03_rho_plus_3p"],
            c["cold_baryon_limit_ok"],
            c["handles_pressure_radiation_extension"],
            not c["uses_dark_halo_or_residual"],
            not c["has_free_fit_parameter"],
            c["gate11_guardrail_ok"],
        ]
        score = bool_score(flags)

        if c["candidate"] == SELECTED_D_PROXY and score == 1.0:
            status = "SELECTED_PRIMARY_D_PROXY"
        elif c["uses_dark_halo_or_residual"] and c["candidate"] == "rotation_curve_residual_proxy":
            status = "FORBIDDEN_TARGET_CONTROL"
        elif c["uses_dark_halo_or_residual"]:
            status = "REJECT_IMPORTS_FITTED_DARK_SECTOR_OR_RESIDUAL"
        elif c["candidate"] in ["cold_baryonic_source_density_proxy", "simulation_settlement_demand_proxy"]:
            status = "VALID_COMPANION_OR_LIMIT_PROXY"
        else:
            status = "REJECT_INCOMPLETE_OR_TUNABLE_D_PROXY"

        rows.append({**c, "score": score, "status": status})
    return rows


def B_proxy_candidate_rows() -> list[dict]:
    """
    Score physical C_boundary proxy candidates.
    """
    candidates = [
        {
            "candidate": "source_graph_boundary_conductance_proxy",
            "definition": "C_boundary from weighted graph cut conductance of pre-declared source/settlement nodes",
            "computable_pre_data": True,
            "topological_or_connectivity_quantity": True,
            "same_source_dictionary_as_D_possible": True,
            "normalizable_to_background": True,
            "supports_compensation_channel": True,
            "uses_environment_catalog_posthoc": False,
            "uses_residual_or_target": False,
            "has_free_fit_parameter": False,
            "gate11_guardrail_ok": True,
            "role": "primary B proxy",
        },
        {
            "candidate": "tidal_filament_connectivity_proxy",
            "definition": "C_boundary from pre-declared cosmic-web, tidal, or filament graph connectivity",
            "computable_pre_data": True,
            "topological_or_connectivity_quantity": True,
            "same_source_dictionary_as_D_possible": False,
            "normalizable_to_background": True,
            "supports_compensation_channel": True,
            "uses_environment_catalog_posthoc": False,
            "uses_residual_or_target": False,
            "has_free_fit_parameter": False,
            "gate11_guardrail_ok": True,
            "role": "valid external-connectivity companion proxy",
        },
        {
            "candidate": "nearest_neighbor_density_proxy",
            "definition": "C_boundary approximated from nearest-neighbor density only",
            "computable_pre_data": True,
            "topological_or_connectivity_quantity": False,
            "same_source_dictionary_as_D_possible": True,
            "normalizable_to_background": True,
            "supports_compensation_channel": False,
            "uses_environment_catalog_posthoc": False,
            "uses_residual_or_target": False,
            "has_free_fit_parameter": False,
            "gate11_guardrail_ok": True,
            "role": "density-like control, not true B channel",
        },
        {
            "candidate": "visual_morphology_label_proxy",
            "definition": "C_boundary assigned from morphology labels such as cluster/void/filament after inspection",
            "computable_pre_data": False,
            "topological_or_connectivity_quantity": False,
            "same_source_dictionary_as_D_possible": False,
            "normalizable_to_background": False,
            "supports_compensation_channel": False,
            "uses_environment_catalog_posthoc": True,
            "uses_residual_or_target": False,
            "has_free_fit_parameter": True,
            "gate11_guardrail_ok": False,
            "role": "reject post-hoc label control",
        },
        {
            "candidate": "residual_fit_connectivity_proxy",
            "definition": "C_boundary chosen to make observed residuals match",
            "computable_pre_data": False,
            "topological_or_connectivity_quantity": False,
            "same_source_dictionary_as_D_possible": False,
            "normalizable_to_background": True,
            "supports_compensation_channel": True,
            "uses_environment_catalog_posthoc": True,
            "uses_residual_or_target": True,
            "has_free_fit_parameter": True,
            "gate11_guardrail_ok": False,
            "role": "forbidden target control",
        },
    ]

    rows = []
    for c in candidates:
        flags = [
            c["computable_pre_data"],
            c["topological_or_connectivity_quantity"],
            c["same_source_dictionary_as_D_possible"],
            c["normalizable_to_background"],
            c["supports_compensation_channel"],
            not c["uses_environment_catalog_posthoc"],
            not c["uses_residual_or_target"],
            not c["has_free_fit_parameter"],
            c["gate11_guardrail_ok"],
        ]
        score = bool_score(flags)

        if c["candidate"] == SELECTED_B_PROXY and score == 1.0:
            status = "SELECTED_PRIMARY_B_PROXY"
        elif c["uses_residual_or_target"]:
            status = "FORBIDDEN_TARGET_CONTROL"
        elif c["uses_environment_catalog_posthoc"]:
            status = "REJECT_POSTHOC_ENVIRONMENT_LABEL"
        elif c["candidate"] == "tidal_filament_connectivity_proxy":
            status = "VALID_COMPANION_B_PROXY"
        else:
            status = "REJECT_INCOMPLETE_OR_BIASED_B_PROXY"

        rows.append({**c, "score": score, "status": status})
    return rows


def scale_candidate_rows() -> list[dict]:
    """
    Freeze a scale selector for D/B smoothing and region definitions.
    No real data are used. The selected primary is the background transition
    radius r0=sqrt(GM/a_S), because it is already derived/selected by the
    GRAV_TRAJ_04-08 chain and does not use residuals.
    """
    candidates = [
        {
            "candidate": "background_transition_radius_r0_sqrt_GM_over_aS",
            "definition": "use r0=sqrt(GM/a_S(t)) as the environment region/smoothing scale before applying E",
            "derived_from_prior_gates": True,
            "uses_source_mass": True,
            "uses_E_feedback": False,
            "uses_residual_fit": False,
            "dimensionally_correct": True,
            "gate11_guardrail_ok": True,
            "role": "primary scale selector",
        },
        {
            "candidate": "source_half_mass_radius_companion",
            "definition": "use observed/source half-mass radius as a local source-structure scale",
            "derived_from_prior_gates": False,
            "uses_source_mass": True,
            "uses_E_feedback": False,
            "uses_residual_fit": False,
            "dimensionally_correct": True,
            "gate11_guardrail_ok": True,
            "role": "valid companion but not primary transition scale",
        },
        {
            "candidate": "E_dependent_transition_radius_fixed_point",
            "definition": "solve r_t=sqrt(GM/(E(r_t)a_S)) self-consistently",
            "derived_from_prior_gates": True,
            "uses_source_mass": True,
            "uses_E_feedback": True,
            "uses_residual_fit": False,
            "dimensionally_correct": True,
            "gate11_guardrail_ok": True,
            "role": "defer until E observable is frozen",
        },
        {
            "candidate": "fixed_10kpc_scale",
            "definition": "use a universal 10 kpc smoothing/region scale",
            "derived_from_prior_gates": False,
            "uses_source_mass": False,
            "uses_E_feedback": False,
            "uses_residual_fit": False,
            "dimensionally_correct": True,
            "gate11_guardrail_ok": True,
            "role": "arbitrary fixed-length control",
        },
        {
            "candidate": "best_fit_kernel_scale",
            "definition": "choose smoothing scale to minimize observed residuals",
            "derived_from_prior_gates": False,
            "uses_source_mass": False,
            "uses_E_feedback": True,
            "uses_residual_fit": True,
            "dimensionally_correct": True,
            "gate11_guardrail_ok": False,
            "role": "forbidden target control",
        },
    ]

    rows = []
    for c in candidates:
        flags = [
            c["derived_from_prior_gates"],
            c["uses_source_mass"],
            not c["uses_E_feedback"],
            not c["uses_residual_fit"],
            c["dimensionally_correct"],
            c["gate11_guardrail_ok"],
        ]
        score = bool_score(flags)

        if c["candidate"] == SELECTED_SCALE and score == 1.0:
            status = "SELECTED_PRIMARY_SCALE"
        elif c["uses_residual_fit"]:
            status = "FORBIDDEN_TARGET_CONTROL"
        elif c["uses_E_feedback"]:
            status = "DEFER_SELF_CONSISTENT_E_SCALE"
        elif c["candidate"] == "source_half_mass_radius_companion":
            status = "VALID_COMPANION_SCALE"
        else:
            status = "REJECT_ARBITRARY_SCALE_CONTROL"

        rows.append({**c, "score": score, "status": status})
    return rows


# ---------------------------------------------------------------------
# Bundle and guardrail checks
# ---------------------------------------------------------------------

def selected_bundle_rows(D_rows, B_rows, scale_rows) -> list[dict]:
    D = next(r for r in D_rows if r["candidate"] == SELECTED_D_PROXY)
    B = next(r for r in B_rows if r["candidate"] == SELECTED_B_PROXY)
    S = next(r for r in scale_rows if r["candidate"] == SELECTED_SCALE)

    return [
        {
            "bundle_item": "D_proxy",
            "selected": D["candidate"],
            "definition": D["definition"],
            "status": D["status"],
            "score": D["score"],
        },
        {
            "bundle_item": "B_proxy",
            "selected": B["candidate"],
            "definition": B["definition"],
            "status": B["status"],
            "score": B["score"],
        },
        {
            "bundle_item": "scale_selector",
            "selected": S["candidate"],
            "definition": S["definition"],
            "status": S["status"],
            "score": S["score"],
        },
        {
            "bundle_item": "E_law",
            "selected": "E=sqrt(D*B)",
            "definition": "GRAV_TRAJ_09 no-bias equal-log law",
            "status": "LOCKED_FROM_GATE09",
            "score": 1.0,
        },
        {
            "bundle_item": "E_attachment",
            "selected": "far_field_transition_only",
            "definition": "GRAV_TRAJ_11 guardrail: E enters only a_eff and r_t, never local metric/source",
            "status": "LOCKED_FROM_GATE11",
            "score": 1.0,
        },
    ]


def scale_examples_rows() -> list[dict]:
    masses = [
        ("dwarf_1e8_Msun", 1e8*M_SUN),
        ("galaxy_1e10_Msun", 1e10*M_SUN),
        ("large_galaxy_1e11_Msun", 1e11*M_SUN),
        ("cluster_1e14_Msun", 1e14*M_SUN),
    ]
    rows = []
    for name, M in masses:
        r0 = math.sqrt(G*M/A_S_BACKGROUND)
        rows.append({
            "system_label": name,
            "M_kg": M,
            "M_Msun": M/M_SUN,
            "aS_background_m_s2": A_S_BACKGROUND,
            "r0_m": r0,
            "r0_kpc": r0/KPC,
            "ell_D_example_0p1_r0_kpc": 0.1*r0/KPC,
            "ell_B_example_0p16_r0_kpc": 0.16*r0/KPC,
            "region_radius_example_0p18_r0_kpc": 0.18*r0/KPC,
            "uses_residuals": False,
            "interpretation": "scale follows from prior handoff radius, not a fitted length",
        })
    return rows


def guardrail_check_rows(bundle_rows) -> list[dict]:
    rows = []

    rows.append({
        "guardrail": "E_sector_allowed",
        "value": E_ALLOWED_SECTOR,
        "pass": True,
        "reason": "E is attached only to a_eff and r_t",
    })

    for sector in E_FORBIDDEN_SECTORS:
        rows.append({
            "guardrail": f"E_not_in_{sector}",
            "value": "absent",
            "pass": True,
            "reason": "Gate 11 forbids E from local metric/source sectors",
        })

    rows.append({
        "guardrail": "no_target_data_used",
        "value": "observed_a0=False; SPARC/RAR=False; cluster=False; kSZ=False",
        "pass": True,
        "reason": "Gate 12 is a proxy-selection audit only",
    })

    rows.append({
        "guardrail": "selected_bundle_complete",
        "value": ",".join(r["bundle_item"] for r in bundle_rows),
        "pass": all(r["status"].startswith("SELECTED") or r["status"].startswith("LOCKED") for r in bundle_rows),
        "reason": "D, B, scale, E law, and E attachment are all specified",
    })

    return rows


def protocol_field_rows() -> list[dict]:
    return [
        {
            "field": "source_catalog",
            "required_for_gate13": True,
            "definition": "pre-declared source nodes/fields used to compute rho_set and graph connectivity",
            "no_target_rule": "must be chosen before residual comparison",
        },
        {
            "field": "rho_set_proxy",
            "required_for_gate13": True,
            "definition": SELECTED_D_PROXY,
            "no_target_rule": "compute from baryonic/operation source fields only",
        },
        {
            "field": "C_boundary_proxy",
            "required_for_gate13": True,
            "definition": SELECTED_B_PROXY,
            "no_target_rule": "graph nodes, edges, weights, and cut regions frozen before data",
        },
        {
            "field": "scale_selector",
            "required_for_gate13": True,
            "definition": SELECTED_SCALE,
            "no_target_rule": "use r0=sqrt(GM/a_S) before E feedback or residual fitting",
        },
        {
            "field": "D_value",
            "required_for_gate13": True,
            "definition": "D=rho_set/<rho_set>_background",
            "no_target_rule": "normalization background must be declared before comparison",
        },
        {
            "field": "B_value",
            "required_for_gate13": True,
            "definition": "B=C_boundary/<C_boundary>_background",
            "no_target_rule": "background normalization must be declared before comparison",
        },
        {
            "field": "E_value",
            "required_for_gate13": True,
            "definition": "E=sqrt(D*B)",
            "no_target_rule": "no exponent, offset, or residual correction allowed",
        },
        {
            "field": "far_field_attachment",
            "required_for_gate13": True,
            "definition": "a_eff=E*a_S and r_t=sqrt(GM/(E*a_S))",
            "no_target_rule": "E must not enter F, B_metric, phi, M, or G",
        },
        {
            "field": "prediction_outputs",
            "required_for_gate13": True,
            "definition": "predicted sqrt(E) deviation, r_t shift, and a_eff before looking at residuals",
            "no_target_rule": "outputs must be frozen before observational comparison",
        },
    ]


def dependency_debt_rows() -> list[dict]:
    return [
        {
            "debt": "D1_choose_actual_dataset_implementation",
            "status": "OPEN",
            "description": "Gate 12 selects proxy classes, but not a specific observational/simulation catalog implementation.",
            "next_test": "Gate 13 must freeze exactly which catalog/fields and graph construction are allowed.",
        },
        {
            "debt": "D2_pressure_operation_density_practicality",
            "status": "WATCH",
            "description": "rho+3p proxy is conceptually strongest, but in cold galaxy systems pressure terms may be unavailable or negligible.",
            "next_test": "Gate 13 should specify cold-limit fallback rho_set≈rho_b when p is negligible.",
        },
        {
            "debt": "D3_graph_construction_details",
            "status": "OPEN",
            "description": "B proxy requires frozen node, edge, weight, kernel, and boundary-region definitions.",
            "next_test": "Gate 13 should pre-register graph construction details.",
        },
        {
            "debt": "D4_kernel_scale_fixed_point",
            "status": "DEFERRED",
            "description": "Primary scale uses background r0 before E feedback; self-consistent E-dependent r_t is deferred.",
            "next_test": "Only after blind tests should a fixed-point E scale be considered.",
        },
        {
            "debt": "D5_data_validation",
            "status": "DEFERRED",
            "description": "SPARC/RAR/cluster/kSZ comparison remains forbidden until Gate 13 protocol is frozen.",
            "next_test": "Gate 14+ data validation after Gate 13.",
        },
    ]


def stack_decision_rows(verdict_ok: bool) -> list[dict]:
    if verdict_ok:
        return [
            {
                "stack_action": "WRITE_GATE13_BLUEPRINT_ONLY",
                "execute_gate13_now": False,
                "reason": "Gate 13 must freeze dataset/protocol implementation details; this should be reviewed explicitly before writing validation-ready code.",
                "generated_file": "grav_traj_12_gate13_blueprint.csv",
            }
        ]
    return [
        {
            "stack_action": "DO_NOT_STACK",
            "execute_gate13_now": False,
            "reason": "Gate 12 did not pass, so Gate 13 should not be prepared.",
            "generated_file": "",
        }
    ]


def gate13_blueprint_rows() -> list[dict]:
    return [
        {
            "gate13_step": "freeze_allowed_inputs",
            "description": "declare source catalog, allowed fields, units, masks, and background normalization",
            "hard_rule": "no residuals, rotation-curve errors, cluster residuals, or kSZ values may enter",
        },
        {
            "gate13_step": "freeze_D_computation",
            "description": "compute rho_set using operation-density proxy, with cold-limit rho_b fallback if p unavailable",
            "hard_rule": "D must be computed before acceleration residual comparison",
        },
        {
            "gate13_step": "freeze_B_graph",
            "description": "declare nodes, edges, edge weights, conductance boundary, and graph scale",
            "hard_rule": "graph cannot be altered after seeing residuals",
        },
        {
            "gate13_step": "freeze_scale",
            "description": "use r0=sqrt(GM/a_S) and pre-declared fractions for smoothing/region scale",
            "hard_rule": "no best-fit kernel length",
        },
        {
            "gate13_step": "compute_E_predictions",
            "description": "compute E=sqrt(DB), sqrt(E) deviation, a_eff=E a_S, r_t=sqrt(GM/(E a_S))",
            "hard_rule": "E may enter only far-field handoff",
        },
        {
            "gate13_step": "produce_prediction_table",
            "description": "write per-object or per-region predictions before observational comparison",
            "hard_rule": "table is sealed before Gate 14 validation",
        },
        {
            "gate13_step": "validation_handoff",
            "description": "handoff to Gate 14+ SPARC/RAR/cluster/kSZ tests only after protocol is sealed",
            "hard_rule": "no tuning after validation begins",
        },
    ]


def verdict_row(D_rows, B_rows, scale_rows, bundle_rows, guardrails):
    D_primary = next(r for r in D_rows if r["candidate"] == SELECTED_D_PROXY)
    B_primary = next(r for r in B_rows if r["candidate"] == SELECTED_B_PROXY)
    S_primary = next(r for r in scale_rows if r["candidate"] == SELECTED_SCALE)

    D_pass = D_primary["status"] == "SELECTED_PRIMARY_D_PROXY" and abs(D_primary["score"] - 1.0) < 1e-12
    B_pass = B_primary["status"] == "SELECTED_PRIMARY_B_PROXY" and abs(B_primary["score"] - 1.0) < 1e-12
    S_pass = S_primary["status"] == "SELECTED_PRIMARY_SCALE" and abs(S_primary["score"] - 1.0) < 1e-12
    guardrail_pass = all(r["pass"] for r in guardrails)

    forbidden_D_marked = any(r["status"] == "FORBIDDEN_TARGET_CONTROL" for r in D_rows)
    forbidden_B_marked = any(r["status"] == "FORBIDDEN_TARGET_CONTROL" for r in B_rows)
    forbidden_S_marked = any(r["status"] == "FORBIDDEN_TARGET_CONTROL" for r in scale_rows)

    bundle_complete = all(r["status"].startswith("SELECTED") or r["status"].startswith("LOCKED") for r in bundle_rows)

    ok = D_pass and B_pass and S_pass and guardrail_pass and forbidden_D_marked and forbidden_B_marked and forbidden_S_marked and bundle_complete

    return {
        "verdict": "PHYSICAL_D_B_PROXY_BUNDLE_SELECTED_WITH_GATE11_GUARDRAIL" if ok else "PHYSICAL_D_B_PROXY_SELECTION_REQUIRES_REVISION",
        "claim_boundary": "proxy-selection audit only; not final observable truth, not SPARC/RAR fit, not cluster solution, not kSZ prediction, and not completed gravity",
        "selected_D_proxy": SELECTED_D_PROXY,
        "selected_B_proxy": SELECTED_B_PROXY,
        "selected_scale": SELECTED_SCALE,
        "selected_E_law": "E=sqrt(D*B)",
        "selected_E_attachment": "far_field_transition_only",
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_SPARC_or_RAR_data": False,
        "uses_cluster_data": False,
        "uses_kSZ_data": False,
        "D_proxy_pass": D_pass,
        "B_proxy_pass": B_pass,
        "scale_selector_pass": S_pass,
        "gate11_guardrail_pass": guardrail_pass,
        "forbidden_target_controls_marked": forbidden_D_marked and forbidden_B_marked and forbidden_S_marked,
        "bundle_complete": bundle_complete,
        "background_aS_m_s2_at_H0_70": A_S_BACKGROUND,
        "main_result": "A no-target physical proxy bundle is selected: rho_set uses the rho+3p operation-density proxy, C_boundary uses source-graph boundary conductance, and smoothing/region scale is tied to the background transition radius r0=sqrt(GM/a_S).",
        "paper_safe_sentence": (
            "GRAV_TRAJ_12 selects physical proxy classes for the GRAV_TRAJ_09/10 environment factor while enforcing the GRAV_TRAJ_11 guardrail. "
            "The selected settlement-density proxy is the operation-density continuation rho_set proportional to rho_b+3p_b/c^2, reducing to baryonic source density in cold systems while preserving the GRAV_TRAJ_03 rho+3p source logic. "
            "The selected boundary-connectivity proxy is source-graph cut conductance per node, normalized to a background conductance, so B remains a genuine connectivity channel rather than a second density proxy. "
            "The selected scale is the background transition radius r0=sqrt(GM/a_S), derived from the prior handoff chain before applying E, while fixed arbitrary lengths, fitted kernels, dark-halo imports, residual-derived proxies, and post-hoc environment labels are rejected or forbidden. "
            "The resulting bundle D, B, E=sqrt(DB), and a_eff=E a_S is ready for a blind-protocol freeze, but it is not yet an observational fit or validation."
        ),
        "next_gate": "GRAV_TRAJ_13 should freeze the blind prediction protocol: allowed inputs, D/B computation, graph construction, scale fractions, prediction outputs, and no-retuning handoff to Gate 14+ validation.",
    }


def save_plots(D_rows, B_rows, scale_rows, scale_examples):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # D scores.
        plt.figure(figsize=(10,5))
        labels = [r["candidate"] for r in D_rows]
        vals = [r["score"] for r in D_rows]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("D proxy score")
        plt.title("GRAV_TRAJ_12: D proxy candidate scores")
        plt.tight_layout()
        p = OUT/"grav_traj_12_D_proxy_scores.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # B scores.
        plt.figure(figsize=(10,5))
        labels = [r["candidate"] for r in B_rows]
        vals = [r["score"] for r in B_rows]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("B proxy score")
        plt.title("GRAV_TRAJ_12: B proxy candidate scores")
        plt.tight_layout()
        p = OUT/"grav_traj_12_B_proxy_scores.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Scale scores.
        plt.figure(figsize=(10,5))
        labels = [r["candidate"] for r in scale_rows]
        vals = [r["score"] for r in scale_rows]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("scale selector score")
        plt.title("GRAV_TRAJ_12: scale selector scores")
        plt.tight_layout()
        p = OUT/"grav_traj_12_scale_selector_scores.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Scale examples.
        plt.figure(figsize=(8,5))
        labels = [r["system_label"] for r in scale_examples]
        vals = [r["r0_kpc"] for r in scale_examples]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.yscale("log")
        plt.xticks(x, labels, rotation=25, ha="right", fontsize=8)
        plt.ylabel("r0 = sqrt(GM/aS) [kpc]")
        plt.title("GRAV_TRAJ_12: background transition scale examples")
        plt.tight_layout()
        p = OUT/"grav_traj_12_transition_scale_examples.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, D_rows, B_rows, scale_rows, bundle_rows, guardrails, debts, stack_rows, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_12: Physical D/B Observable Proxy Selection Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## Selected bundle\n\n")
    lines.append("| Bundle item | selected | status | score |\n")
    lines.append("|---|---|---|---:|\n")
    for r in bundle_rows:
        lines.append(f"| {r['bundle_item']} | {r['selected']} | {r['status']} | {r['score']:.3f} |\n")

    lines.append("\n## D proxy candidates\n\n")
    lines.append("| Candidate | score | status | role |\n")
    lines.append("|---|---:|---|---|\n")
    for r in D_rows:
        lines.append(f"| {r['candidate']} | {r['score']:.3f} | {r['status']} | {r['role']} |\n")

    lines.append("\n## B proxy candidates\n\n")
    lines.append("| Candidate | score | status | role |\n")
    lines.append("|---|---:|---|---|\n")
    for r in B_rows:
        lines.append(f"| {r['candidate']} | {r['score']:.3f} | {r['status']} | {r['role']} |\n")

    lines.append("\n## Scale candidates\n\n")
    lines.append("| Candidate | score | status | role |\n")
    lines.append("|---|---:|---|---|\n")
    for r in scale_rows:
        lines.append(f"| {r['candidate']} | {r['score']:.3f} | {r['status']} | {r['role']} |\n")

    lines.append("\n## Gate 11 guardrails\n\n")
    lines.append("| Guardrail | pass | reason |\n")
    lines.append("|---|---|---|\n")
    for r in guardrails:
        lines.append(f"| {r['guardrail']} | {r['pass']} | {r['reason']} |\n")

    lines.append("\n## Remaining debts\n\n")
    lines.append("| Debt | status | description |\n")
    lines.append("|---|---|---|\n")
    for r in debts:
        lines.append(f"| {r['debt']} | {r['status']} | {r['description']} |\n")

    lines.append("\n## Stack decision\n\n")
    for r in stack_rows:
        lines.append(f"- {r['stack_action']}: execute_gate13_now={r['execute_gate13_now']}. {r['reason']}\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    D_rows = D_proxy_candidate_rows()
    B_rows = B_proxy_candidate_rows()
    scale_rows = scale_candidate_rows()
    bundle_rows = selected_bundle_rows(D_rows, B_rows, scale_rows)
    scale_examples = scale_examples_rows()
    guardrails = guardrail_check_rows(bundle_rows)
    protocol_fields = protocol_field_rows()
    debts = dependency_debt_rows()
    verdict = verdict_row(D_rows, B_rows, scale_rows, bundle_rows, guardrails)
    verdict_ok = verdict["verdict"] == "PHYSICAL_D_B_PROXY_BUNDLE_SELECTED_WITH_GATE11_GUARDRAIL"
    stack_rows = stack_decision_rows(verdict_ok)
    gate13_blueprint = gate13_blueprint_rows() if verdict_ok else []

    write_csv(OUT/"grav_traj_12_D_proxy_candidates.csv", D_rows)
    write_csv(OUT/"grav_traj_12_B_proxy_candidates.csv", B_rows)
    write_csv(OUT/"grav_traj_12_scale_candidates.csv", scale_rows)
    write_csv(OUT/"grav_traj_12_selected_proxy_bundle.csv", bundle_rows)
    write_csv(OUT/"grav_traj_12_scale_examples.csv", scale_examples)
    write_csv(OUT/"grav_traj_12_gate11_guardrail_checks.csv", guardrails)
    write_csv(OUT/"grav_traj_12_protocol_fields.csv", protocol_fields)
    write_csv(OUT/"grav_traj_12_dependency_debts.csv", debts)
    write_csv(OUT/"grav_traj_12_stack_decision.csv", stack_rows)
    write_csv(OUT/"grav_traj_12_gate13_blueprint.csv", gate13_blueprint)
    write_csv(OUT/"grav_traj_12_verdict.csv", [verdict])

    plots = save_plots(D_rows, B_rows, scale_rows, scale_examples)
    write_report(
        OUT/"GRAV_TRAJ_12_physical_D_B_proxy_selection_report.md",
        D_rows, B_rows, scale_rows, bundle_rows, guardrails, debts, stack_rows, verdict
    )

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_12",
        "purpose": "select physical proxy classes for rho_set and C_boundary while enforcing Gate 11 guardrail",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "stack_decision": stack_rows,
        "files": [
            "grav_traj_12_D_proxy_candidates.csv",
            "grav_traj_12_B_proxy_candidates.csv",
            "grav_traj_12_scale_candidates.csv",
            "grav_traj_12_selected_proxy_bundle.csv",
            "grav_traj_12_scale_examples.csv",
            "grav_traj_12_gate11_guardrail_checks.csv",
            "grav_traj_12_protocol_fields.csv",
            "grav_traj_12_dependency_debts.csv",
            "grav_traj_12_stack_decision.csv",
            "grav_traj_12_gate13_blueprint.csv",
            "grav_traj_12_verdict.csv",
            "GRAV_TRAJ_12_physical_D_B_proxy_selection_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_12 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Select physical D/B observable proxy classes while enforcing the Gate 11 far-field-only E guardrail.")
    print("  No observed a0, SPARC/RAR, galaxy data, cluster data, or kSZ data are used.")

    print("\nSelected proxy bundle:")
    for r in bundle_rows:
        print(
            f"  {r['bundle_item']:18s}  "
            f"{r['selected']:52s}  "
            f"score={r['score']:.3f}  {r['status']}"
        )

    print("\nD proxy candidate audit:")
    for r in D_rows:
        print(
            f"  {r['candidate']:42s}  "
            f"score={r['score']:.3f}  "
            f"gate03={r['connects_gate03_rho_plus_3p']}  "
            f"cold={r['cold_baryon_limit_ok']}  "
            f"no_target={not r['uses_dark_halo_or_residual']}  "
            f"{r['status']}"
        )

    print("\nB proxy candidate audit:")
    for r in B_rows:
        print(
            f"  {r['candidate']:42s}  "
            f"score={r['score']:.3f}  "
            f"connectivity={r['topological_or_connectivity_quantity']}  "
            f"compensation={r['supports_compensation_channel']}  "
            f"no_target={not r['uses_residual_or_target']}  "
            f"{r['status']}"
        )

    print("\nScale selector audit:")
    for r in scale_rows:
        print(
            f"  {r['candidate']:48s}  "
            f"score={r['score']:.3f}  "
            f"prior={r['derived_from_prior_gates']}  "
            f"E_feedback={r['uses_E_feedback']}  "
            f"no_fit={not r['uses_residual_fit']}  "
            f"{r['status']}"
        )

    print("\nScale examples:")
    for r in scale_examples:
        print(
            f"  {r['system_label']:24s}  "
            f"M={r['M_Msun']:.3e} Msun  "
            f"r0={r['r0_kpc']:.6f} kpc  "
            f"ell_D~0.1r0={r['ell_D_example_0p1_r0_kpc']:.6f} kpc"
        )

    print("\nGate 11 guardrail checks:")
    for r in guardrails:
        print(f"  {r['guardrail']:36s}  PASS={r['pass']}  {r['reason']}")

    print("\nProtocol fields for Gate 13:")
    for r in protocol_fields:
        print(f"  {r['field']:24s}  required={r['required_for_gate13']}  {r['definition']}")

    print("\nRemaining debts:")
    for r in debts:
        print(f"  {r['debt']:40s}  {r['status']:10s}  {r['description']}")

    print("\nStack decision:")
    for r in stack_rows:
        print(f"  {r['stack_action']}: execute_gate13_now={r['execute_gate13_now']}  reason={r['reason']}")

    if gate13_blueprint:
        print("\nGate 13 blueprint emitted:")
        for r in gate13_blueprint:
            print(f"  {r['gate13_step']:30s}  {r['description']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_12_physical_D_B_proxy_selection_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_12_verdict.csv'}")
    print(f"  D candidates csv: {OUT/'grav_traj_12_D_proxy_candidates.csv'}")
    print(f"  B candidates csv: {OUT/'grav_traj_12_B_proxy_candidates.csv'}")
    print(f"  scale candidates csv: {OUT/'grav_traj_12_scale_candidates.csv'}")
    print(f"  selected bundle csv: {OUT/'grav_traj_12_selected_proxy_bundle.csv'}")
    print(f"  guardrail checks csv: {OUT/'grav_traj_12_gate11_guardrail_checks.csv'}")
    print(f"  protocol fields csv: {OUT/'grav_traj_12_protocol_fields.csv'}")
    print(f"  debts csv: {OUT/'grav_traj_12_dependency_debts.csv'}")
    print(f"  stack decision csv: {OUT/'grav_traj_12_stack_decision.csv'}")
    print(f"  Gate13 blueprint csv: {OUT/'grav_traj_12_gate13_blueprint.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
