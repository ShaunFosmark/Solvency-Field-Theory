#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_08:
No-Overwrite Settlement Radius H(t) Audit

Purpose
-------
GRAV_TRAJ_05 constrained the acceleration scale to:

    a_S = cH/(2*pi).

GRAV_TRAJ_06 selected the 2*pi phase-cycle coupling.

GRAV_TRAJ_07 identified H as the correct background fractional/horizon
update-rate candidate:

    H = c/R_H.

GRAV_TRAJ_08 now audits the next upstream step:

    Can H(t) be obtained from an SFT no-overwrite settlement-radius rule?

Core SFT move
-------------
If the effective settlement ledger radius R(t) grows by the one-speed
no-overwrite causal rule,

    dR/dt = c,

then the fractional update rate of that ledger radius is

    H_set(t) = d ln R / dt = (1/R) dR/dt = c/R(t).

Therefore the same quantity previously identified as H=c/R is now recovered
as the differential fractional update rate of the no-overwrite settlement
radius.

This is a structural derivation of the rate class, not a precision
cosmological expansion model.

What this tests
---------------
1. Differential identity:
       d ln R/dt = c/R.

2. Integral closure:
       ∫ H_set dt = ∫ (c/R)(dR/c) = ln(R_f/R_i).

3. V12.1 local-ledger bridge:
       Apply the rule from recombination local-ledger radii to the present
       fiducial horizon radius.

4. Phase-cycle attachment:
       a_S(t) = c H_set(t)/(2*pi) = c^2/(2*pi R(t)),
       so a_S(t) R(t) / c^2 = 1/(2*pi) at every time.

5. Controls:
       constant H0, H/(2*pi) as base rate, 2*pi H, fixed local length,
       microscopic root clock, and optional target-inverted H are rejected
       or quarantined.

Claim boundary
--------------
A pass means:
    H(t)=c/R(t) survives as the no-overwrite settlement-radius fractional
    update rate, and the phase-cycle acceleration becomes a_S(t)=cH(t)/(2pi).

A pass does NOT mean:
    SFT derives the observed expansion history,
    SFT derives Friedmann equations,
    SFT fits H(z),
    SFT derives a0,
    SFT fits SPARC/RAR,
    SFT predicts kSZ,
    or SFT completes far-field gravity.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_08_OUTPUT")

# Constants.
C = 299_792_458.0
MPC = 3.0856775814913673e22
LY = 9.4607304725808e15
MLY = 1.0e6 * LY
EV = 1.602176634e-19
HBAR = 1.054571817e-34

# Fiducial background value used throughout the trajectory audits.
H0_FID_KM_S_MPC = 70.0
H0_FID = H0_FID_KM_S_MPC * 1000.0 / MPC
R_PRESENT = C / H0_FID

# Prior SFT ledger radii from earlier gates.
R_REC_GATE11R = 0.6246982112007 * MLY
R_REC_V12_LOCKED = 0.6281043601339 * MLY

# Diagnostic only. Not used to select candidate.
A0_BENCHMARK_OPTIONAL = 1.2e-10

# Microscopic wrong-class control.
E_ROOT_MEV = 69.30067818338
E_ROOT_J = E_ROOT_MEV * 1e6 * EV
OMEGA_ROOT = E_ROOT_J / HBAR


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def H_set(R: float) -> float:
    return C / R


def a_phase(R: float) -> float:
    return C * H_set(R) / (2.0 * math.pi)


def path_definitions():
    return [
        {
            "path": "Gate11R_recombination_to_present",
            "R_i": R_REC_GATE11R,
            "R_f": R_PRESENT,
            "description": "Gate11R recombination local-ledger radius to present fiducial Hubble ledger",
        },
        {
            "path": "V12_1_locked_recombination_to_present",
            "R_i": R_REC_V12_LOCKED,
            "R_f": R_PRESENT,
            "description": "V12.1 locked effective recombination radius to present fiducial Hubble ledger",
        },
    ]


def settlement_path_rows() -> list[dict]:
    rows = []
    for p in path_definitions():
        Ri, Rf = p["R_i"], p["R_f"]
        dt = (Rf - Ri) / C
        log_growth = math.log(Rf/Ri)
        H_i = H_set(Ri)
        H_f = H_set(Rf)
        a_i = a_phase(Ri)
        a_f = a_phase(Rf)
        rows.append({
            "path": p["path"],
            "description": p["description"],
            "R_i_Mly": Ri/MLY,
            "R_f_Mly": Rf/MLY,
            "R_f_over_R_i": Rf/Ri,
            "delta_t_s_no_overwrite": dt,
            "delta_t_Gyr_no_overwrite": dt/(365.25*24*3600)/1e9,
            "ln_R_growth": log_growth,
            "H_i_s_inv": H_i,
            "H_f_s_inv": H_f,
            "H_i_over_H0": H_i/H0_FID,
            "H_f_over_H0": H_f/H0_FID,
            "aS_i_m_s2": a_i,
            "aS_f_m_s2": a_f,
            "aS_i_over_aS_f": a_i/a_f,
            "aR_over_c2_initial": a_i*Ri/(C*C),
            "aR_over_c2_final": a_f*Rf/(C*C),
            "target_1_over_2pi": 1.0/(2.0*math.pi),
            "status": "PASS_PATH_DEFINED",
        })
    return rows


def time_dependence_sample_rows(n: int = 121) -> list[dict]:
    rows = []
    for p in path_definitions():
        Ri, Rf = p["R_i"], p["R_f"]
        for f in np.linspace(0.0, 1.0, n):
            # One-speed no-overwrite radius interpolation.
            R = Ri + f*(Rf - Ri)
            t = (R - Ri)/C
            H = H_set(R)
            aS = C*H/(2.0*math.pi)
            rows.append({
                "path": p["path"],
                "fraction_of_no_overwrite_path": float(f),
                "t_since_start_s": t,
                "t_since_start_Gyr": t/(365.25*24*3600)/1e9,
                "R_Mly": R/MLY,
                "R_over_R_initial": R/Ri,
                "H_set_c_over_R_s_inv": H,
                "H_over_H0": H/H0_FID,
                "dlnR_dt_s_inv": H,
                "aS_t_m_s2": aS,
                "aS_over_present_primary": aS/(C*H0_FID/(2.0*math.pi)),
                "aS_R_over_c2": aS*R/(C*C),
                "target_1_over_2pi": 1.0/(2.0*math.pi),
                "invariant_error": (aS*R/(C*C))/(1.0/(2.0*math.pi))-1.0,
            })
    return rows


def integral_closure_rows() -> list[dict]:
    rows = []
    for p in path_definitions():
        Ri, Rf = p["R_i"], p["R_f"]
        dt = (Rf - Ri)/C
        exact_ln = math.log(Rf/Ri)

        # Integrate in R-space; dt=dR/c.
        R_grid = np.geomspace(Ri, Rf, 20001)
        H_grid = C / R_grid
        dt_dR = 1.0 / C
        integral_primary = float(np.trapezoid(H_grid * dt_dR, R_grid))

        # Controls over same path.
        integral_constant_H0 = H0_FID * dt
        integral_post_phase_as_base = integral_primary/(2.0*math.pi)
        integral_double_count = integral_primary*(2.0*math.pi)
        integral_fixed_10kpc = (C/(10.0 * 1000.0 * 3.261563777 * LY)) * dt
        integral_micro_root = OMEGA_ROOT * dt

        controls = [
            ("primary_no_overwrite_H_c_over_R", integral_primary, "PASS_PRIMARY"),
            ("constant_H0_control", integral_constant_H0, "REJECT_CONSTANT_LATE_RATE_FOR_FULL_PATH"),
            ("H_over_2pi_as_base_control", integral_post_phase_as_base, "REJECT_POST_PHASE_RATE_AS_BASE"),
            ("two_pi_H_double_count_control", integral_double_count, "REJECT_DOUBLE_COUNTED_RATE"),
            ("fixed_10kpc_rate_control", integral_fixed_10kpc, "REJECT_ARBITRARY_LOCAL_LENGTH"),
            ("microscopic_root_clock_control", integral_micro_root, "REJECT_WRONG_CLASS_MICROSCOPIC_CLOCK"),
        ]

        for name, val, status in controls:
            rows.append({
                "path": p["path"],
                "rate_model": name,
                "integral_Hdt": val,
                "expected_ln_Rf_over_Ri": exact_ln,
                "absolute_error_vs_ln_growth": val - exact_ln,
                "relative_error_vs_ln_growth": (val/exact_ln)-1.0,
                "closure_pass": abs(val - exact_ln) < 1e-8 if name == "primary_no_overwrite_H_c_over_R" else False,
                "status": status,
            })
    return rows


def differential_identity_rows() -> list[dict]:
    rows = []
    for p in path_definitions():
        Ri, Rf = p["R_i"], p["R_f"]
        for R in np.geomspace(Ri, Rf, 9):
            H = H_set(R)
            # If dR/dt=c, then dlnR/dt=(1/R)c.
            dlnRdt = C/R
            rows.append({
                "path": p["path"],
                "R_Mly": R/MLY,
                "H_set_c_over_R": H,
                "dlnRdt_from_no_overwrite": dlnRdt,
                "difference": H - dlnRdt,
                "relative_difference": (H/dlnRdt)-1.0,
                "identity_pass": abs(H-dlnRdt) < 1e-30,
            })
    return rows


def candidate_control_rows() -> list[dict]:
    exact_H_from_optional_a0 = 2.0*math.pi*A0_BENCHMARK_OPTIONAL/C
    candidates = [
        ("H_of_t_c_over_R", "H(t)=c/R(t)", "PRIMARY_NO_OVERWRITE_SETTLEMENT_RADIUS_RATE", False, False),
        ("constant_H0", "H(t)=H0", "REJECT_LATE_RATE_NOT_FULL_PATH_RATE", False, False),
        ("H_over_2pi_as_base", "H_base=c/(2pi R)", "REJECT_DOUBLE_APPLIES_PHASE_COUPLING", False, False),
        ("two_pi_H_as_base", "H_base=2pi c/R", "REJECT_DOUBLE_COUNTS_ANGULAR_CONVERSION", False, False),
        ("fixed_10kpc_rate", "c/(10 kpc)", "REJECT_ARBITRARY_LOCAL_LENGTH", False, False),
        ("microscopic_root_clock", "E_root/hbar", "REJECT_WRONG_CLASS_LOCAL_CLOCK", False, False),
        ("exact_H_from_optional_a0", "2pi*a0_optional/c", "FORBIDDEN_TARGET_CONTROL", True, True),
    ]
    rows = []
    for name, formula, status, uses_a0, uses_galaxy in candidates:
        if name == "H_of_t_c_over_R":
            role_score = 1.0
            reason = "derives fractional update rate from no-overwrite radius law dR/dt=c"
        elif name == "constant_H0":
            role_score = 0.4
            reason = "valid endpoint value but fails integrated growth from early ledger to present"
        elif name == "H_over_2pi_as_base":
            role_score = 0.4
            reason = "valid completed-cycle rate after phase coupling, not base H(t)"
        elif name == "two_pi_H_as_base":
            role_score = 0.2
            reason = "double-counts phase/radian conversion"
        elif name == "fixed_10kpc_rate":
            role_score = 0.2
            reason = "arbitrary local length and wrong background class"
        elif name == "microscopic_root_clock":
            role_score = 0.2
            reason = "microscopic clock and wrong background class"
        else:
            role_score = 0.0
            reason = "target-inverted from optional acceleration benchmark"
        rows.append({
            "candidate": name,
            "formula": formula,
            "status": status,
            "uses_observed_a0": uses_a0,
            "uses_galaxy_data": uses_galaxy,
            "uses_kSZ_data": False,
            "internal_role_score": role_score,
            "reason": reason,
        })
    return rows


def dependency_debt_rows() -> list[dict]:
    return [
        {
            "debt": "D1_R_of_t_dynamics",
            "status": "PARTIALLY_CONSTRAINED_NOT_CLOSED",
            "description": "GRAV_TRAJ_08 derives H(t)=c/R(t) if the effective settlement radius obeys dR/dt=c, but does not yet derive the full R(t) from microscopic ledger dynamics.",
            "next_test": "derive R(t) from no-overwrite boundary writing, V12.1 settlement relaxation Q(T), or V11.1B diffusion",
        },
        {
            "debt": "D2_map_ledger_R_to_cosmological_observables",
            "status": "OPEN",
            "description": "Need distinguish settlement ledger radius from ordinary FRW scale factor and map to observables carefully.",
            "next_test": "construct observational dictionary only after H(t) and R(t) are mechanistically defined",
        },
        {
            "debt": "D3_environment_factor_E",
            "status": "OPEN",
            "description": "Need derive E from local settlement density or boundary connectivity, not per-system tuning.",
            "next_test": "GRAV_TRAJ_09 should define E and test non-MOND deviations without using residuals as targets",
        },
        {
            "debt": "D4_data_comparison",
            "status": "DEFERRED",
            "description": "SPARC/RAR/kSZ comparisons remain deferred until R(t) and E are mechanistically specified.",
            "next_test": "only compare to data after non-tuned predictions exist",
        },
    ]


def verdict_row(paths, samples, integrals, differentials, controls):
    primary_integrals = [r for r in integrals if r["rate_model"] == "primary_no_overwrite_H_c_over_R"]
    constant_controls = [r for r in integrals if r["rate_model"] == "constant_H0_control"]
    post_controls = [r for r in integrals if r["rate_model"] == "H_over_2pi_as_base_control"]
    double_controls = [r for r in integrals if r["rate_model"] == "two_pi_H_double_count_control"]

    differential_pass = all(r["identity_pass"] for r in differentials)
    integral_pass = all(r["closure_pass"] for r in primary_integrals)
    invariant_pass = all(abs(r["invariant_error"]) < 1e-12 for r in samples)
    constant_rejected = all(not r["closure_pass"] and abs(r["relative_error_vs_ln_growth"]) > 0.5 for r in constant_controls)
    phase_base_rejected = all(not r["closure_pass"] for r in post_controls)
    double_rejected = all(not r["closure_pass"] for r in double_controls)
    primary_control = next(r for r in controls if r["candidate"] == "H_of_t_c_over_R")
    forbidden = next(r for r in controls if r["candidate"] == "exact_H_from_optional_a0")
    controls_pass = primary_control["status"] == "PRIMARY_NO_OVERWRITE_SETTLEMENT_RADIUS_RATE" and forbidden["status"] == "FORBIDDEN_TARGET_CONTROL"

    ok = differential_pass and integral_pass and invariant_pass and constant_rejected and phase_base_rejected and double_rejected and controls_pass

    return {
        "verdict": "H_OF_T_SURVIVES_AS_NO_OVERWRITE_SETTLEMENT_RADIUS_RATE" if ok else "H_OF_T_SETTLEMENT_RELAXATION_REQUIRES_REVISION",
        "claim_boundary": "settlement-radius rate audit only; not full expansion derivation, Friedmann equation, H(z) fit, a0 derivation, SPARC/RAR fit, kSZ prediction, or nonlinear gravity",
        "selected_rate_law": "H_set(t)=d ln R/dt=c/R(t), given dR/dt=c",
        "selected_acceleration_law": "a_S(t)=cH_set(t)/(2*pi)=c^2/(2*pi R(t))",
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_kSZ_data": False,
        "differential_identity_pass": differential_pass,
        "integral_closure_pass": integral_pass,
        "phase_cycle_invariant_all_samples_pass": invariant_pass,
        "constant_H0_full_path_control_rejected": constant_rejected,
        "post_phase_rate_as_base_rejected": phase_base_rejected,
        "two_pi_double_count_rejected": double_rejected,
        "forbidden_target_control_marked": forbidden["status"] == "FORBIDDEN_TARGET_CONTROL",
        "main_result": "If SFT no-overwrite settlement radius grows at the one-speed causal rate dR/dt=c, then H(t)=c/R(t) follows as the ledger fractional update rate and integrates exactly to ln(R_f/R_i).",
        "paper_safe_sentence": (
            "GRAV_TRAJ_08 audits the time-dependent origin of the settlement update rate. "
            "If the effective no-overwrite settlement radius obeys dR/dt=c, then the fractional ledger update rate is H_set(t)=dlnR/dt=c/R(t). "
            "This rate integrates exactly as ∫H_set dt=ln(R_f/R_i), preserves the horizon identity H_R R/c=1 for both present and V12.1 recombination local-ledger radii, and after the GRAV_TRAJ_06 phase-cycle coupling gives a_S(t)=cH_set(t)/(2pi)=c^2/(2pi R(t)) with a_S(t)R(t)/c^2=1/(2pi). "
            "Constant late-time H0, H/(2pi) used as a base rate, 2piH, fixed local lengths, microscopic root clocks, and optional target-inverted H controls fail the role audit or are quarantined. "
            "This constrains H(t) as a no-overwrite settlement-radius rate, while leaving open the microscopic derivation of R(t), the mapping to FRW observables, and the environment factor E."
        ),
        "next_gate": "GRAV_TRAJ_09 should derive the environment factor E from settlement density/boundary connectivity so non-MOND deviations become falsifiable without tuning.",
    }


def save_plots(paths, samples, integrals):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # H(t) samples.
        plt.figure(figsize=(8,5))
        for path in sorted(set(r["path"] for r in samples)):
            sub = [r for r in samples if r["path"] == path]
            plt.loglog([r["R_Mly"] for r in sub], [r["H_over_H0"] for r in sub], label=path)
        plt.xlabel("settlement radius R (Mly)")
        plt.ylabel("H_set / H0")
        plt.title("GRAV_TRAJ_08: H(t)=c/R(t)")
        plt.legend(fontsize=8)
        plt.tight_layout()
        p = OUT/"grav_traj_08_H_of_R.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # aS invariant.
        plt.figure(figsize=(8,5))
        for path in sorted(set(r["path"] for r in samples)):
            sub = [r for r in samples if r["path"] == path]
            plt.plot([r["fraction_of_no_overwrite_path"] for r in sub], [r["aS_R_over_c2"] for r in sub], label=path)
        plt.axhline(1.0/(2.0*math.pi), linestyle="--", linewidth=1)
        plt.xlabel("fraction of no-overwrite path")
        plt.ylabel("aS(t) R(t) / c^2")
        plt.title("GRAV_TRAJ_08: phase-cycle invariant over time")
        plt.legend(fontsize=8)
        plt.tight_layout()
        p = OUT/"grav_traj_08_phase_invariant.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Integral closure controls.
        plt.figure(figsize=(10,5))
        rows = [r for r in integrals if r["path"] == "V12_1_locked_recombination_to_present"]
        labels = [r["rate_model"] for r in rows]
        vals = [r["integral_Hdt"] for r in rows]
        target = rows[0]["expected_ln_Rf_over_Ri"]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.axhline(target, linestyle="--", linewidth=1, label="ln(Rf/Ri)")
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("integral H dt")
        plt.title("GRAV_TRAJ_08: integral closure controls")
        plt.legend()
        plt.tight_layout()
        p = OUT/"grav_traj_08_integral_closure_controls.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Path summary.
        plt.figure(figsize=(8,5))
        labels = [r["path"] for r in paths]
        vals = [r["ln_R_growth"] for r in paths]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=25, ha="right", fontsize=8)
        plt.ylabel("ln(Rf/Ri)")
        plt.title("GRAV_TRAJ_08: ledger growth from recombination to present")
        plt.tight_layout()
        p = OUT/"grav_traj_08_path_growth.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, paths, samples, integrals, differentials, controls, debts, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_08: No-Overwrite Settlement Radius H(t) Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## Settlement paths\n\n")
    lines.append("| Path | R_i (Mly) | R_f (Mly) | ln growth | delta t (Gyr) | H_i/H0 |\n")
    lines.append("|---|---:|---:|---:|---:|---:|\n")
    for r in paths:
        lines.append(f"| {r['path']} | {r['R_i_Mly']:.12f} | {r['R_f_Mly']:.6f} | {r['ln_R_growth']:.6f} | {r['delta_t_Gyr_no_overwrite']:.6f} | {r['H_i_over_H0']:.6f} |\n")

    lines.append("\n## Integral closure\n\n")
    lines.append("| Path | Model | integral Hdt | target ln(Rf/Ri) | rel error | status |\n")
    lines.append("|---|---|---:|---:|---:|---|\n")
    for r in integrals:
        lines.append(f"| {r['path']} | {r['rate_model']} | {r['integral_Hdt']:.6e} | {r['expected_ln_Rf_over_Ri']:.6e} | {r['relative_error_vs_ln_growth']:.6e} | {r['status']} |\n")

    lines.append("\n## Controls\n\n")
    lines.append("| Candidate | status | reason |\n")
    lines.append("|---|---|---|\n")
    for r in controls:
        lines.append(f"| {r['candidate']} | {r['status']} | {r['reason']} |\n")

    lines.append("\n## Remaining debts\n\n")
    lines.append("| Debt | status | description |\n")
    lines.append("|---|---|---|\n")
    for r in debts:
        lines.append(f"| {r['debt']} | {r['status']} | {r['description']} |\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    paths = settlement_path_rows()
    samples = time_dependence_sample_rows()
    integrals = integral_closure_rows()
    differentials = differential_identity_rows()
    controls = candidate_control_rows()
    debts = dependency_debt_rows()
    verdict = verdict_row(paths, samples, integrals, differentials, controls)

    write_csv(OUT/"grav_traj_08_settlement_paths.csv", paths)
    write_csv(OUT/"grav_traj_08_time_dependence_samples.csv", samples)
    write_csv(OUT/"grav_traj_08_integral_closure.csv", integrals)
    write_csv(OUT/"grav_traj_08_differential_identity.csv", differentials)
    write_csv(OUT/"grav_traj_08_controls.csv", controls)
    write_csv(OUT/"grav_traj_08_dependency_debts.csv", debts)
    write_csv(OUT/"grav_traj_08_verdict.csv", [verdict])

    plots = save_plots(paths, samples, integrals)
    write_report(
        OUT/"GRAV_TRAJ_08_H_of_t_settlement_radius_report.md",
        paths, samples, integrals, differentials, controls, debts, verdict
    )

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_08",
        "purpose": "derive/constrain H(t) as no-overwrite settlement-radius rate",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "files": [
            "grav_traj_08_settlement_paths.csv",
            "grav_traj_08_time_dependence_samples.csv",
            "grav_traj_08_integral_closure.csv",
            "grav_traj_08_differential_identity.csv",
            "grav_traj_08_controls.csv",
            "grav_traj_08_dependency_debts.csv",
            "grav_traj_08_verdict.csv",
            "GRAV_TRAJ_08_H_of_t_settlement_radius_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_08 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Audit whether H(t)=c/R(t) follows from no-overwrite settlement-radius dynamics dR/dt=c.")
    print("  No observed a0, SPARC/RAR, galaxy data, or kSZ data are used.")

    print("\nSettlement H(t) paths:")
    for r in paths:
        print(
            f"  {r['path']:42s}  "
            f"R_i={r['R_i_Mly']:.12f} Mly  "
            f"R_f={r['R_f_Mly']:.6f} Mly  "
            f"ln_growth={r['ln_R_growth']:.6f}  "
            f"dt={r['delta_t_Gyr_no_overwrite']:.6f} Gyr  "
            f"H_i/H0={r['H_i_over_H0']:.6f}  "
            f"a_i/a_f={r['aS_i_over_aS_f']:.6f}"
        )

    print("\nDifferential identity checks:")
    for path in sorted(set(r["path"] for r in differentials)):
        sub = [r for r in differentials if r["path"] == path]
        max_abs = max(abs(r["difference"]) for r in sub)
        all_pass = all(r["identity_pass"] for r in sub)
        print(f"  {path:42s}  max|H-dlnRdt|={max_abs:.3e}  PASS={all_pass}")

    print("\nIntegral closure tests:")
    for r in integrals:
        print(
            f"  {r['path']:42s}  "
            f"{r['rate_model']:34s}  "
            f"intHdt={r['integral_Hdt']:.6e}  "
            f"target={r['expected_ln_Rf_over_Ri']:.6e}  "
            f"rel_err={r['relative_error_vs_ln_growth']:+.3e}  "
            f"{r['status']}"
        )

    print("\nCandidate controls:")
    for r in controls:
        print(
            f"  {r['candidate']:30s}  "
            f"score={r['internal_role_score']:.3f}  "
            f"{r['status']}  "
            f"{r['reason']}"
        )

    print("\nRemaining debts:")
    for r in debts:
        print(f"  {r['debt']:38s}  {r['status']:32s}  {r['description']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_08_H_of_t_settlement_radius_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_08_verdict.csv'}")
    print(f"  settlement paths csv: {OUT/'grav_traj_08_settlement_paths.csv'}")
    print(f"  time samples csv: {OUT/'grav_traj_08_time_dependence_samples.csv'}")
    print(f"  integral closure csv: {OUT/'grav_traj_08_integral_closure.csv'}")
    print(f"  differential identity csv: {OUT/'grav_traj_08_differential_identity.csv'}")
    print(f"  controls csv: {OUT/'grav_traj_08_controls.csv'}")
    print(f"  debts csv: {OUT/'grav_traj_08_dependency_debts.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
