#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_02:
Helix Source Kernel -> V11.13 One-Speed Metric Closure Audit

Purpose
-------
GRAV_TRAJ_01 showed that a time-averaged one-speed internal circulation
(modeled as a ring source) gives:

    Lambda(r,theta) = Lambda0(r) [1 + epsilon(r)(sin^2(theta)-2/3)]
    Lambda0(r) ~ 1/r
    epsilon(r) -> (3/4)(a/r)^2

GRAV_TRAJ_02 asks the next appropriate question:

    Can that source kernel feed the V11.13 weak-field metric scaffold
    without breaking one-speed reciprocal closure?

V11.13 closure
--------------
Use a dimensionless lag potential phi proportional to Lambda. Then define

    F = exp(-phi)
    B = exp(+alpha phi)

V11.13 one-speed reciprocal closure selects

    alpha = 1

so

    F B = 1

and weak-field metric markers are

    g_tt = -F^2 = -1 + 2 phi - 2 phi^2 + ...
    g_rr =  B^2 =  1 + 2 alpha phi + ...

Therefore alpha=1 gives the PPN weak-field markers

    gamma = 1
    beta  = 1

What this tests
---------------
1. The GRAV_TRAJ_01 source kernel supplies a Newtonian monopole:
       <Lambda>_Omega ~ 1/r,  -d<Lambda>/dr ~ 1/r^2.

2. The quadrupole is trace-free under spherical averaging:
       <sin^2(theta)-2/3>_Omega = 0,
   so the directional correction does not corrupt the monopole weak-field limit.

3. The one-speed closure map F=exp(-phi), B=exp(+phi) preserves:
       F B = 1
   for both monopole and directional source.

4. Alpha alternatives fail either reciprocal closure or PPN gamma.

What this does NOT test
-----------------------
This does not derive the full Einstein equations, nonlinear GR, MOND,
expansion, frame dragging, or jets. It also does not derive the absolute
normalization of phi. V12.2 attaches later as the amplitude/root-scale branch.

Claim boundary
--------------
A pass means the helical/ring source kernel is compatible with the V11.13
one-speed weak-field metric closure. It is not yet a full gravity derivation.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_02_OUTPUT")


# -----------------------------
# Source kernel: same as GRAV_TRAJ_01, but using np.trapezoid.
# -----------------------------

def ring_kernel(r: float, theta: np.ndarray, a: float = 1.0, n_phase: int = 4096) -> np.ndarray:
    phi = np.linspace(0.0, 2.0 * math.pi, n_phase, endpoint=False)
    cos_phi = np.cos(phi)
    theta = np.asarray(theta)
    sin_theta = np.sin(theta)[:, None]
    denom2 = r*r + a*a - 2.0*r*a*sin_theta*cos_phi[None, :]
    denom2 = np.maximum(denom2, 1e-300)
    return np.mean(1.0 / np.sqrt(denom2), axis=1)


def source_fit(r: float, a: float = 1.0, n_mu: int = 601, n_phase: int = 4096) -> dict:
    mu = np.linspace(-1.0, 1.0, n_mu)
    theta = np.arccos(mu)
    lam = ring_kernel(r, theta, a=a, n_phase=n_phase)

    lam0 = np.trapezoid(lam, mu) / 2.0
    expected = 1.0 / r

    q = np.sin(theta)**2 - 2.0/3.0
    delta = lam / lam0 - 1.0
    eps = np.trapezoid(delta*q, mu) / np.trapezoid(q*q, mu)

    model = lam0 * (1.0 + eps*q)
    rms_resid = math.sqrt(float(np.trapezoid(((lam-model)/lam0)**2, mu) / 2.0))

    # Gradient of spherical average for Newtonian check.
    dr = max(1e-4*r, 1e-5)
    mu_g = np.linspace(-1.0, 1.0, 401)
    th_g = np.arccos(mu_g)
    lam_p = np.trapezoid(ring_kernel(r+dr, th_g, a=a, n_phase=n_phase), mu_g)/2.0
    lam_m = np.trapezoid(ring_kernel(r-dr, th_g, a=a, n_phase=n_phase), mu_g)/2.0
    grad_inward = -(lam_p-lam_m)/(2*dr)
    newton_grad = 1.0/(r*r)

    lam_eq = float(ring_kernel(r, np.array([math.pi/2]), a=a, n_phase=n_phase)[0])
    lam_pole = float(ring_kernel(r, np.array([0.0]), a=a, n_phase=n_phase)[0])

    return {
        "r_over_a": r/a,
        "lambda0": lam0,
        "expected_1_over_r": expected,
        "monopole_error": lam0/expected - 1.0,
        "inward_gradient_avg": grad_inward,
        "newton_gradient": newton_grad,
        "gradient_over_newton": grad_inward/newton_grad,
        "epsilon_fit": eps,
        "epsilon_pred": 0.75*(a/r)**2,
        "epsilon_fit_over_pred": eps/(0.75*(a/r)**2),
        "quadrupole_rms_residual": rms_resid,
        "equator_excess": lam_eq/lam0 - 1.0,
        "pole_deficit": lam_pole/lam0 - 1.0,
    }


# -----------------------------
# Metric closure
# -----------------------------

def metric_from_phi(phi: np.ndarray, alpha: float = 1.0) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Returns F, B, g_tt, g_rr for dimensionless phi.

        F = exp(-phi)
        B = exp(alpha phi)
        g_tt = -F^2
        g_rr = B^2
    """
    F = np.exp(-phi)
    B = np.exp(alpha*phi)
    g_tt = -F*F
    g_rr = B*B
    return F, B, g_tt, g_rr


def ppn_markers_from_alpha(alpha: float) -> dict:
    """
    Weak-field expansion:
        g_tt = -exp(-2phi) = -1 + 2phi - 2phi^2 + ...
        g_rr = exp(2 alpha phi) = 1 + 2 alpha phi + ...
    PPN gamma = alpha, beta = 1 for this exponential F choice.
    """
    return {
        "alpha": alpha,
        "gamma_marker": alpha,
        "beta_marker": 1.0,
        "gamma_error": abs(alpha-1.0),
        "beta_error": 0.0,
    }


def closure_diagnostics_for_alpha(alpha: float, phi_values: np.ndarray) -> dict:
    F, B, _, _ = metric_from_phi(phi_values, alpha=alpha)
    FB = F*B
    log_FB = np.log(FB)
    return {
        "alpha": alpha,
        "max_abs_log_FB": float(np.max(np.abs(log_FB))),
        "rms_log_FB": float(math.sqrt(np.mean(log_FB*log_FB))),
        "max_abs_FB_minus_1": float(np.max(np.abs(FB-1.0))),
        **ppn_markers_from_alpha(alpha),
    }


def alpha_selection_rows(phi_grid: np.ndarray) -> list[dict]:
    alphas = [-1.0, -0.5, 0.0, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
    rows = []
    for alpha in alphas:
        d = closure_diagnostics_for_alpha(alpha, phi_grid)
        # Score: reciprocal closure + PPN gamma. beta is already fixed by F.
        score = d["rms_log_FB"] + d["gamma_error"]
        d["combined_closure_ppn_score"] = score
        d["status"] = "SELECTED_ONE_SPEED_RECIPROCAL_CLOSURE" if abs(alpha-1.0) < 1e-12 else "FAILS_RECIPROCAL_OR_GAMMA"
        rows.append(d)
    return rows


def source_metric_rows(r_values: list[float], a: float = 1.0, phi_ref_at_r10: float = 1e-6) -> list[dict]:
    """
    Build metric diagnostics for the ring source. Normalize dimensionless phi so that
    phi_monopole(r/a=10) = phi_ref_at_r10. This is shape-only; amplitude is not derived here.
    """
    # lambda0 at r=10a is approximately 0.1; use exact fit for stable normalization.
    fit10 = source_fit(10.0*a, a=a, n_mu=401, n_phase=2048)
    kappa = phi_ref_at_r10 / fit10["lambda0"]

    rows = []
    for r in r_values:
        f = source_fit(r, a=a, n_mu=501, n_phase=4096)
        phi0 = kappa * f["lambda0"]
        phi_eq = phi0 * (1.0 + f["equator_excess"])
        phi_pole = phi0 * (1.0 + f["pole_deficit"])

        for label, phi in [("spherical_average", phi0), ("equator", phi_eq), ("pole", phi_pole)]:
            F, B, gtt, grr = metric_from_phi(np.array([phi]), alpha=1.0)
            # Weak-field reconstructed potential from gtt and grr.
            phi_from_gtt_linear = (gtt[0] + 1.0) / 2.0  # because gtt=-1+2phi+...
            phi_from_grr_linear = (grr[0] - 1.0) / 2.0  # because grr=1+2phi+...
            rows.append({
                "r_over_a": f["r_over_a"],
                "sample": label,
                "kappa_shape_normalization": kappa,
                "phi": phi,
                "F": float(F[0]),
                "B": float(B[0]),
                "F_times_B_minus_1": float(F[0]*B[0]-1.0),
                "g_tt": float(gtt[0]),
                "g_rr": float(grr[0]),
                "phi_from_gtt_linear": float(phi_from_gtt_linear),
                "phi_from_grr_linear": float(phi_from_grr_linear),
                "linear_phi_gtt_fractional_error": float(phi_from_gtt_linear/phi - 1.0) if phi != 0 else 0.0,
                "linear_phi_grr_fractional_error": float(phi_from_grr_linear/phi - 1.0) if phi != 0 else 0.0,
                "gamma_marker": 1.0,
                "beta_marker": 1.0,
                "closure_status": "PASS_FB_EQUALS_1",
                **{f"source_{k}": v for k, v in f.items()},
            })
    return rows


def angular_metric_profile_rows(r: float, a: float = 1.0, phi_ref_at_r10: float = 1e-6) -> list[dict]:
    fit10 = source_fit(10.0*a, a=a, n_mu=401, n_phase=2048)
    kappa = phi_ref_at_r10 / fit10["lambda0"]

    mu = np.linspace(-1.0, 1.0, 401)
    theta = np.arccos(mu)
    lam_mu = ring_kernel(r, theta, a=a, n_phase=4096)
    lam0 = np.trapezoid(lam_mu, mu)/2.0

    theta_plot = np.linspace(0.0, math.pi, 181)
    lam = ring_kernel(r, theta_plot, a=a, n_phase=4096)
    phi = kappa * lam
    phi0 = kappa * lam0
    F, B, gtt, grr = metric_from_phi(phi, alpha=1.0)

    return [
        {
            "r_over_a": r/a,
            "theta_deg": float(t*180.0/math.pi),
            "lambda_over_lambda0": float(L/lam0),
            "phi_over_phi0": float(p/phi0),
            "phi": float(p),
            "F": float(f),
            "B": float(b),
            "F_times_B_minus_1": float(f*b-1.0),
            "g_tt": float(gt),
            "g_rr": float(gr),
        }
        for t, L, p, f, b, gt, gr in zip(theta_plot, lam, phi, F, B, gtt, grr)
    ]


def verdict_row(source_rows: list[dict], alpha_rows: list[dict], metric_rows: list[dict]) -> dict:
    src_avg = [r for r in source_rows if r["sample"] == "spherical_average"]
    monopole_pass = all(abs(r["source_monopole_error"]) < 5e-4 for r in src_avg)
    gradient_pass = all(abs(r["source_gradient_over_newton"] - 1.0) < 5e-3 for r in src_avg if r["r_over_a"] >= 3.0)
    direction_pass = all(r["source_equator_excess"] > 0 and r["source_pole_deficit"] < 0 for r in src_avg)
    closure_pass = all(abs(r["F_times_B_minus_1"]) < 1e-14 for r in metric_rows)
    selected = min(alpha_rows, key=lambda r: r["combined_closure_ppn_score"])
    alpha_pass = abs(selected["alpha"] - 1.0) < 1e-12

    if monopole_pass and gradient_pass and direction_pass and closure_pass and alpha_pass:
        verdict = "HELIX_SOURCE_COMPATIBLE_WITH_V11_13_ONE_SPEED_METRIC_CLOSURE"
    else:
        verdict = "HELIX_SOURCE_TO_METRIC_CLOSURE_REQUIRES_REVISION"

    return {
        "verdict": verdict,
        "claim_boundary": "metric-closure compatibility audit only; not full GR, MOND, expansion, frame dragging, or G derivation",
        "monopole_pass": monopole_pass,
        "gradient_pass": gradient_pass,
        "directionality_pass": direction_pass,
        "FB_closure_pass": closure_pass,
        "alpha_selection_pass": alpha_pass,
        "selected_alpha": selected["alpha"],
        "selected_alpha_score": selected["combined_closure_ppn_score"],
        "gamma_marker": 1.0,
        "beta_marker": 1.0,
        "main_result": "the helical/ring source kernel can feed V11.13 F=exp(-phi), B=exp(+phi) closure without corrupting the Newtonian monopole",
        "paper_safe_sentence": (
            "GRAV_TRAJ_02 feeds the GRAV_TRAJ_01 helical/ring source kernel into the V11.13 weak-field metric scaffold. "
            "The spherical average of the source supplies the Newtonian 1/r monopole and 1/r^2 gradient, while the leading "
            "quadrupole is trace-free and remains a directional correction. Mapping the dimensionless lag potential by "
            "F=exp(-phi) and B=exp(+phi) gives FB=1 pointwise and the weak-field markers gamma=1 and beta=1. "
            "Alpha alternatives in B=exp(alpha phi) fail reciprocal closure or gamma. This supports compatibility between "
            "the one-helix source kernel and the V11.13 one-speed metric closure, while not yet deriving the dynamical field "
            "equations, MOND-like transition, expansion, frame dragging, jets, or the absolute normalization."
        ),
        "next_gate": "GRAV_TRAJ_03 should test radiation/matter source continuity or settlement-diffusion near-field/far-field transition without tuning to MOND.",
        "v12_2_attachment": "V12.2 remains an amplitude/root-scale attachment; GRAV_TRAJ_02 tests shape-to-metric compatibility only.",
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row.keys():
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def save_plots(source_metric: list[dict], alpha_rows: list[dict], profiles: list[dict]) -> list[str]:
    plots = []
    try:
        import matplotlib.pyplot as plt

        avg = [r for r in source_metric if r["sample"] == "spherical_average"]
        r = np.array([x["r_over_a"] for x in avg])

        plt.figure(figsize=(8,5))
        plt.semilogx(r, [x["source_gradient_over_newton"] for x in avg], marker="o")
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xlabel("r/a")
        plt.ylabel("spherical-average inward gradient / 1/r^2")
        plt.title("GRAV_TRAJ_02: Newtonian monopole gradient check")
        plt.tight_layout()
        p = OUT/"grav_traj_02_newtonian_gradient_check.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        plt.figure(figsize=(8,5))
        plt.scatter([x["alpha"] for x in alpha_rows], [x["combined_closure_ppn_score"] for x in alpha_rows])
        plt.axvline(1.0, linestyle="--", linewidth=1)
        plt.xlabel("alpha in B=exp(alpha phi)")
        plt.ylabel("closure + gamma score")
        plt.title("GRAV_TRAJ_02: alpha selection")
        plt.tight_layout()
        p = OUT/"grav_traj_02_alpha_selection.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        for rr in [5.0, 20.0]:
            rows = [x for x in profiles if abs(x["r_over_a"]-rr) < 1e-9]
            if not rows:
                continue
            theta = [x["theta_deg"] for x in rows]
            phi_ratio = [x["phi_over_phi0"] for x in rows]
            gtt = [x["g_tt"] for x in rows]
            grr = [x["g_rr"] for x in rows]

            plt.figure(figsize=(8,5))
            plt.plot(theta, phi_ratio)
            plt.xlabel("theta degrees: 0=pole, 90=equator")
            plt.ylabel("phi / <phi>")
            plt.title(f"GRAV_TRAJ_02: directional potential profile r/a={rr:g}")
            plt.tight_layout()
            p = OUT/f"grav_traj_02_phi_profile_r_over_a_{rr:g}.png"
            plt.savefig(p, dpi=160)
            plt.close()
            plots.append(str(p))

            plt.figure(figsize=(8,5))
            plt.plot(theta, [-x-1.0 for x in gtt], label="-g_tt - 1")
            plt.plot(theta, [x-1.0 for x in grr], linestyle="--", label="g_rr - 1")
            plt.xlabel("theta degrees: 0=pole, 90=equator")
            plt.ylabel("weak-field metric deviation")
            plt.title(f"GRAV_TRAJ_02: metric deviations r/a={rr:g}")
            plt.legend()
            plt.tight_layout()
            p = OUT/f"grav_traj_02_metric_deviation_r_over_a_{rr:g}.png"
            plt.savefig(p, dpi=160)
            plt.close()
            plots.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path: Path, source_metric: list[dict], alpha_rows: list[dict], verdict: dict) -> None:
    avg = [r for r in source_metric if r["sample"] == "spherical_average"]
    lines = []
    lines.append("# SFT GRAV_TRAJ_02: Helix Source Kernel to One-Speed Metric Closure Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")
    lines.append("## Source-to-metric checks\n\n")
    lines.append("| r/a | monopole error | gradient/Newton | epsilon | eq excess | pole deficit | FB-1 avg |\n")
    lines.append("|---:|---:|---:|---:|---:|---:|---:|\n")
    for r in avg:
        lines.append(
            f"| {r['r_over_a']:.1f} | {r['source_monopole_error']:.3e} | {r['source_gradient_over_newton']:.6f} | "
            f"{r['source_epsilon_fit']:.3e} | {r['source_equator_excess']:.3e} | {r['source_pole_deficit']:.3e} | "
            f"{r['F_times_B_minus_1']:.3e} |\n"
        )
    lines.append("\n## Alpha selection\n\n")
    lines.append("| alpha | gamma | max |FB-1| | score | status |\n")
    lines.append("|---:|---:|---:|---:|---|\n")
    for a in alpha_rows:
        lines.append(
            f"| {a['alpha']:.2f} | {a['gamma_marker']:.2f} | {a['max_abs_FB_minus_1']:.3e} | "
            f"{a['combined_closure_ppn_score']:.3e} | {a['status']} |\n"
        )
    lines.append("\n## V12.2 attachment\n\n")
    lines.append(verdict["v12_2_attachment"] + "\n\n")
    lines.append("## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    r_values = [2.0, 3.0, 5.0, 10.0, 20.0, 50.0, 100.0]
    source_metric = source_metric_rows(r_values, a=1.0, phi_ref_at_r10=1e-6)

    # Build a representative phi grid from all metric rows plus a dense small-field range.
    phi_vals = np.array([abs(r["phi"]) for r in source_metric] + list(np.linspace(0.0, 2e-6, 500)))
    alpha_rows = alpha_selection_rows(phi_vals)

    profiles = []
    for rr in [5.0, 20.0]:
        profiles.extend(angular_metric_profile_rows(rr, a=1.0, phi_ref_at_r10=1e-6))

    verdict = verdict_row(source_metric, alpha_rows, source_metric)

    write_csv(OUT/"grav_traj_02_source_metric_checks.csv", source_metric)
    write_csv(OUT/"grav_traj_02_alpha_selection.csv", alpha_rows)
    write_csv(OUT/"grav_traj_02_angular_metric_profiles.csv", profiles)
    write_csv(OUT/"grav_traj_02_verdict.csv", [verdict])

    plots = save_plots(source_metric, alpha_rows, profiles)
    write_report(OUT/"GRAV_TRAJ_02_source_to_metric_closure_report.md", source_metric, alpha_rows, verdict)

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_02",
        "purpose": "test compatibility of helical/ring source kernel with V11.13 one-speed metric closure",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "files": [
            "grav_traj_02_source_metric_checks.csv",
            "grav_traj_02_alpha_selection.csv",
            "grav_traj_02_angular_metric_profiles.csv",
            "grav_traj_02_verdict.csv",
            "GRAV_TRAJ_02_source_to_metric_closure_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_02 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Feed the GRAV_TRAJ_01 one-helix source kernel into the V11.13 one-speed metric closure.")
    print("  Test Newtonian monopole, trace-free directional correction, FB=1 closure, and alpha=1 selection.")

    print("\nSource-to-metric summary:")
    for r in [x for x in source_metric if x["sample"] == "spherical_average"]:
        print(
            f"  r/a={r['r_over_a']:7.1f}  "
            f"monopole_err={r['source_monopole_error']:+.3e}  "
            f"grad/Newton={r['source_gradient_over_newton']:.8f}  "
            f"eps={r['source_epsilon_fit']:.6e}  "
            f"eq_excess={r['source_equator_excess']:+.3e}  "
            f"pole_deficit={r['source_pole_deficit']:+.3e}  "
            f"FB-1={r['F_times_B_minus_1']:+.3e}"
        )

    print("\nAlpha selection:")
    for a in alpha_rows:
        print(
            f"  alpha={a['alpha']:5.2f}  "
            f"gamma={a['gamma_marker']:.3f}  "
            f"max|FB-1|={a['max_abs_FB_minus_1']:.3e}  "
            f"score={a['combined_closure_ppn_score']:.3e}  "
            f"{a['status']}"
        )

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_02_source_to_metric_closure_report.md'}")
    print(f"  source metric csv: {OUT/'grav_traj_02_source_metric_checks.csv'}")
    print(f"  alpha csv: {OUT/'grav_traj_02_alpha_selection.csv'}")
    print(f"  profiles csv: {OUT/'grav_traj_02_angular_metric_profiles.csv'}")
    print(f"  verdict csv: {OUT/'grav_traj_02_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
