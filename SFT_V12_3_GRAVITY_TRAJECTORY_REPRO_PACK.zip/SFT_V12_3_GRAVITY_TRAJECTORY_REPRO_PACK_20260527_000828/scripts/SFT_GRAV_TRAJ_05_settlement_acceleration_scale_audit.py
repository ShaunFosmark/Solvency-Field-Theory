#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_05:
Settlement Acceleration Scale Constraint Audit

Purpose
-------
GRAV_TRAJ_04 selected an acceleration-triggered settlement handoff as the
only scale-free structure that preserves:

    near-field Newtonian behavior,
    far-field 1/r acceleration,
    RAR-like slopes,
    and v_flat^4 proportional to M.

GRAV_TRAJ_05 asks the next disciplined question:

    Can SFT constrain the acceleration scale a_S without fitting MOND?

This script DOES NOT fit observed a0.
It DOES NOT use SPARC, kSZ, or galaxy data.
It DOES NOT claim to derive a_S from first principles.

It tests whether a horizon/settlement-cycle acceleration scale has the right
structural form:

    a_S = c^2 / (K R_settlement)

with the phase-cycle candidate

    K = 2*pi,
    R_settlement = c/H

so

    a_S = c H / (2*pi).

Why this is SFT-relevant
------------------------
V11.1/V11.5 use cycles/phase as operational units.
V11.1B uses settlement lag and diffusion against a background.
V12.1 uses horizon/local-ledger geometry as a settlement scale.
GRAV_TRAJ_04 needs an acceleration scale, not a fixed length.

A horizon-cycle acceleration is the simplest background settlement scale:
    one-speed budget c,
    horizon/settlement radius R,
    one phase cycle 2*pi.

This is a constraint candidate, not a proof.

What this tests
---------------
1. Candidate dimensional classes:
   - local microscopic/root scales,
   - fixed length scales,
   - horizon acceleration cH,
   - horizon phase-cycle acceleration cH/(2*pi),
   - forbidden observed-a0 fit control.

2. No-cheat status:
   The primary candidate uses c, H, and 2*pi only.
   The observed MOND-like benchmark is optional scoring only and is not used
   to select the candidate.

3. V12.1 consistency:
   Recombination local Hubble ledger and V12.1 effective recombination radius
   both give the same dimensionless invariant:
       a_S R / c^2 ~= 1/(2*pi)
   when the phase-cycle rule is applied.

4. Environment channel:
   a_eff = E a_S naturally shifts the effective transition scale, preserving
   the MOND-like local kernel while allowing non-MOND universal deviations.

Claim boundary
--------------
A pass means:
    horizon phase-cycle settlement acceleration is the strongest current
    no-fit constraint candidate for a_S.

A pass does NOT mean:
    SFT derives a0,
    SFT fits SPARC,
    SFT predicts kSZ,
    SFT derives expansion,
    or SFT completes far-field gravity.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_05_OUTPUT")

# SI constants and fiducial cosmology parameters.
# H0 is intentionally configurable. This is a scale audit, not a precision cosmology fit.
C = 299_792_458.0
MPC = 3.0856775814913673e22
LY = 9.4607304725808e15
MLY = 1.0e6 * LY

H0_FID_KM_S_MPC = 70.0
H0_FID = H0_FID_KM_S_MPC * 1000.0 / MPC

# Optional benchmark used only for diagnostic scoring, never for candidate construction.
# This is a conventional MOND-like acceleration scale placeholder, not a fit target.
A0_BENCHMARK_OPTIONAL = 1.2e-10

# V12.1 / Gate 11R style recombination ledger values already used in the SFT run history.
R_REC_HUBBLE_MLY = 0.6246982112007
R_V12_EFF_REC_MLY = 0.6281043601339


def a_from_radius(R_m: float, K: float) -> float:
    return C*C/(K*R_m)


def horizon_radius(H: float) -> float:
    return C/H


def candidate_rows() -> list[dict]:
    R_H = horizon_radius(H0_FID)
    candidates = []

    def add(name, formula, a_val, ingredients, no_cheat_status, role, K=None, R=None):
        candidates.append({
            "candidate": name,
            "formula": formula,
            "a_S_m_s2": a_val,
            "K": K,
            "R_m": R,
            "R_Gly": R/LY/1e9 if R is not None else None,
            "ingredients": ingredients,
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_kSZ_data": False,
            "no_cheat_status": no_cheat_status,
            "role": role,
            "ratio_to_optional_a0_benchmark": a_val/A0_BENCHMARK_OPTIONAL,
            "factor_error_vs_optional_a0_benchmark": max(a_val/A0_BENCHMARK_OPTIONAL, A0_BENCHMARK_OPTIONAL/a_val),
            "dimensionless_aR_over_c2": (a_val*R/(C*C)) if R is not None else None,
            "target_phase_cycle_1_over_2pi": 1.0/(2.0*math.pi),
        })

    add(
        "horizon_raw_cH",
        "a_S = c H0 = c^2/R_H",
        C*H0_FID,
        "c,H0",
        "ALLOWED_BACKGROUND_SCALE",
        "raw horizon acceleration control",
        K=1.0,
        R=R_H,
    )

    add(
        "horizon_phase_cycle_cH_over_2pi",
        "a_S = c H0/(2*pi) = c^2/(2*pi R_H)",
        C*H0_FID/(2.0*math.pi),
        "c,H0,phase_cycle_2pi",
        "PRIMARY_NO_FIT_CANDIDATE",
        "phase-cycle settlement acceleration",
        K=2.0*math.pi,
        R=R_H,
    )

    add(
        "horizon_fourpi_control",
        "a_S = c H0/(4*pi)",
        C*H0_FID/(4.0*math.pi),
        "c,H0,4pi_control",
        "CONTROL_GEOMETRY_FACTOR",
        "alternative geometric factor control",
        K=4.0*math.pi,
        R=R_H,
    )

    add(
        "horizon_two_control",
        "a_S = c H0/2",
        C*H0_FID/2.0,
        "c,H0,2_control",
        "CONTROL_GEOMETRY_FACTOR",
        "alternative geometric factor control",
        K=2.0,
        R=R_H,
    )

    # Fixed galactic-length controls: illustrate arbitrary length dependence.
    for L_kpc in [1.0, 10.0, 100.0]:
        R = L_kpc * 1000.0 * LY * 3.261563777
        add(
            f"fixed_length_{L_kpc:g}_kpc",
            f"a_S = c^2/L, L={L_kpc:g} kpc",
            C*C/R,
            "c,arbitrary_galactic_length",
            "REJECT_ARBITRARY_LENGTH_CONTROL",
            "fixed length control",
            K=1.0,
            R=R,
        )

    # Forbidden control: exact benchmark by definition.
    candidates.append({
        "candidate": "observed_a0_fit_control",
        "formula": "a_S = a0_benchmark",
        "a_S_m_s2": A0_BENCHMARK_OPTIONAL,
        "K": None,
        "R_m": None,
        "R_Gly": None,
        "ingredients": "observed benchmark",
        "uses_observed_a0": True,
        "uses_galaxy_data": True,
        "uses_kSZ_data": False,
        "no_cheat_status": "FORBIDDEN_CONTROL_ONLY",
        "role": "not allowed for derivation",
        "ratio_to_optional_a0_benchmark": 1.0,
        "factor_error_vs_optional_a0_benchmark": 1.0,
        "dimensionless_aR_over_c2": None,
        "target_phase_cycle_1_over_2pi": 1.0/(2.0*math.pi),
    })

    return candidates


def h0_sensitivity_rows() -> list[dict]:
    rows = []
    for H0 in np.linspace(60.0, 80.0, 41):
        H = H0*1000.0/MPC
        R = horizon_radius(H)
        a_phase = C*H/(2.0*math.pi)
        rows.append({
            "H0_km_s_Mpc": float(H0),
            "H0_s_inv": H,
            "R_H_Gly": R/LY/1e9,
            "a_phase_cH_over_2pi": a_phase,
            "ratio_to_optional_a0_benchmark": a_phase/A0_BENCHMARK_OPTIONAL,
            "factor_error_vs_optional_a0_benchmark": max(a_phase/A0_BENCHMARK_OPTIONAL, A0_BENCHMARK_OPTIONAL/a_phase),
            "dimensionless_aR_over_c2": a_phase*R/(C*C),
        })
    return rows


def recombination_invariant_rows() -> list[dict]:
    rows = []
    for name, R_mly in [
        ("Gate11R_recombination_Hubble_radius", R_REC_HUBBLE_MLY),
        ("V12_1_locked_effective_recombination_radius", R_V12_EFF_REC_MLY),
    ]:
        R = R_mly * MLY
        a_phase = a_from_radius(R, 2.0*math.pi)
        rows.append({
            "ledger": name,
            "R_Mly": R_mly,
            "R_m": R,
            "a_phase_cycle_m_s2": a_phase,
            "dimensionless_aR_over_c2": a_phase*R/(C*C),
            "target_1_over_2pi": 1.0/(2.0*math.pi),
            "fractional_error_to_1_over_2pi": (a_phase*R/(C*C))/(1.0/(2.0*math.pi))-1.0,
            "interpretation": "same phase-cycle horizon invariant at recombination/local-ledger scale",
        })
    return rows


def btfr_prediction_rows() -> list[dict]:
    """
    Uses primary a_S to produce scale examples only.
    No galaxy data are used.
    """
    aS = C*H0_FID/(2.0*math.pi)
    G_SI = 6.67430e-11
    M_sun = 1.98847e30
    masses = np.logspace(7, 12, 11) * M_sun
    rows = []
    for M in masses:
        v4 = G_SI*M*aS
        v = v4**0.25
        rows.append({
            "M_baryon_Msun": M/M_sun,
            "aS_used_m_s2": aS,
            "v_flat_m_s": v,
            "v_flat_km_s": v/1000.0,
            "v4_over_GM": v4/(G_SI*M),
            "expected_aS": aS,
            "role": "scale example only; no galaxy fit",
        })
    return rows


def environment_rows() -> list[dict]:
    aS = C*H0_FID/(2.0*math.pi)
    rows = []
    for E in [0.5, 0.75, 1.0, 1.25, 2.0]:
        a_eff = E*aS
        rows.append({
            "environment_factor_E": E,
            "a_eff_m_s2": a_eff,
            "a_eff_over_primary_aS": E,
            "transition_radius_factor_vs_primary": math.sqrt(1.0/E),
            "BTFR_amplitude_factor_vs_primary": E,
            "interpretation": "environmental settlement density can shift effective acceleration without changing local kernel",
        })
    return rows


def controls_summary_rows(candidates: list[dict]) -> list[dict]:
    rows = []
    for c in candidates:
        if c["candidate"] == "horizon_phase_cycle_cH_over_2pi":
            status = "PRIMARY_SURVIVES"
            reason = "uses background horizon scale and phase-cycle 2pi; no observed a0 input"
        elif c["candidate"] == "observed_a0_fit_control":
            status = "FORBIDDEN"
            reason = "uses target acceleration directly"
        elif "fixed_length" in c["candidate"]:
            status = "REJECT"
            reason = "arbitrary fixed length; GRAV_TRAJ_04 showed fixed-length handoff fails BTFR scaling"
        elif c["candidate"] == "horizon_raw_cH":
            status = "CONTROL"
            reason = "same horizon class but lacks phase-cycle normalization"
        else:
            status = "CONTROL"
            reason = "alternative dimensionless geometric factor"
        rows.append({
            "candidate": c["candidate"],
            "status": status,
            "reason": reason,
            "uses_observed_a0": c["uses_observed_a0"],
            "factor_error_vs_optional_a0_benchmark": c["factor_error_vs_optional_a0_benchmark"],
            "no_cheat_status": c["no_cheat_status"],
        })
    return rows


def verdict_row(candidates, h0_rows, rec_rows):
    primary = next(c for c in candidates if c["candidate"] == "horizon_phase_cycle_cH_over_2pi")
    forbidden = next(c for c in candidates if c["candidate"] == "observed_a0_fit_control")
    fixed = [c for c in candidates if "fixed_length" in c["candidate"]]
    primary_no_cheat = (
        not primary["uses_observed_a0"] and
        not primary["uses_galaxy_data"] and
        primary["no_cheat_status"] == "PRIMARY_NO_FIT_CANDIDATE"
    )
    invariant_pass = all(abs(r["fractional_error_to_1_over_2pi"]) < 1e-14 for r in rec_rows)
    h0_order_pass = max(r["factor_error_vs_optional_a0_benchmark"] for r in h0_rows) < 2.5
    fixed_rejected = all(c["no_cheat_status"] == "REJECT_ARBITRARY_LENGTH_CONTROL" for c in fixed)
    forbidden_marked = forbidden["no_cheat_status"] == "FORBIDDEN_CONTROL_ONLY"

    ok = primary_no_cheat and invariant_pass and h0_order_pass and fixed_rejected and forbidden_marked
    return {
        "verdict": "HORIZON_PHASE_CYCLE_SETTLEMENT_ACCELERATION_SURVIVES_NO_FIT_CONSTRAINT_AUDIT" if ok else "SETTLEMENT_ACCELERATION_SCALE_CONSTRAINT_REQUIRES_REVISION",
        "claim_boundary": "constraint audit only; not a first-principles derivation of a0, not a SPARC fit, not a kSZ prediction, not expansion derivation",
        "primary_candidate": "horizon_phase_cycle_cH_over_2pi",
        "primary_formula": "a_S = c H0/(2*pi) = c^2/(2*pi R_H)",
        "primary_aS_m_s2": primary["a_S_m_s2"],
        "H0_fid_km_s_Mpc": H0_FID_KM_S_MPC,
        "primary_ratio_to_optional_a0_benchmark": primary["ratio_to_optional_a0_benchmark"],
        "primary_factor_error_vs_optional_a0_benchmark": primary["factor_error_vs_optional_a0_benchmark"],
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_kSZ_data": False,
        "phase_cycle_invariant_pass": invariant_pass,
        "H0_range_order_pass_optional_benchmark": h0_order_pass,
        "fixed_length_controls_rejected": fixed_rejected,
        "forbidden_observed_a0_control_marked": forbidden_marked,
        "main_result": "The strongest no-fit constraint candidate for a_S is horizon phase-cycle settlement acceleration cH/(2*pi); this constrains the scale and class but does not derive the microscopic settlement operator.",
        "paper_safe_sentence": (
            "GRAV_TRAJ_05 audits the acceleration scale required by the GRAV_TRAJ_04 settlement handoff without fitting MOND or observed a0. "
            "The strongest no-fit candidate is a horizon phase-cycle settlement scale, a_S=cH/(2*pi)=c^2/(2*pi R_H), built from one-speed propagation, a background settlement radius, and the operational phase-cycle factor already used throughout SFT. "
            "At fiducial H0=70 km/s/Mpc it gives a_S={:.6e} m/s^2, with the optional MOND-like benchmark used only as a diagnostic. "
            "The same rule gives the invariant a_S R/c^2=1/(2*pi) for the V12.1 recombination local-ledger radii. "
            "Thus GRAV_TRAJ_05 constrains the correct class and order of the settlement acceleration scale, while leaving the microscopic derivation of H, the settlement radius, and the phase-cycle coupling as open debts."
        ).format(primary["a_S_m_s2"]),
        "next_gate": (
            "GRAV_TRAJ_06 should derive the phase-cycle coupling from V11.1B settlement dynamics or test environment-dependent a_eff=E a_S against non-MOND large-scale behavior without tuning."
        ),
    }


def write_csv(path: Path, rows: list[dict]):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def save_plots(candidates, h0_rows, btfr_rows, env_rows):
    plots = []
    try:
        import matplotlib.pyplot as plt

        plt.figure(figsize=(9,5))
        labels = [c["candidate"] for c in candidates if c["candidate"] != "observed_a0_fit_control"]
        vals = [c["a_S_m_s2"] for c in candidates if c["candidate"] != "observed_a0_fit_control"]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.axhline(A0_BENCHMARK_OPTIONAL, linestyle="--", linewidth=1, label="optional benchmark")
        plt.yscale("log")
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("a_S candidate (m/s^2)")
        plt.title("GRAV_TRAJ_05: candidate acceleration scales")
        plt.legend()
        plt.tight_layout()
        p = OUT/"grav_traj_05_candidate_scales.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        plt.figure(figsize=(8,5))
        plt.plot([r["H0_km_s_Mpc"] for r in h0_rows], [r["a_phase_cH_over_2pi"] for r in h0_rows])
        plt.axhline(A0_BENCHMARK_OPTIONAL, linestyle="--", linewidth=1)
        plt.xlabel("H0 (km/s/Mpc)")
        plt.ylabel("cH0/(2pi) (m/s^2)")
        plt.title("GRAV_TRAJ_05: H0 sensitivity")
        plt.tight_layout()
        p = OUT/"grav_traj_05_H0_sensitivity.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        plt.figure(figsize=(8,5))
        plt.loglog([r["M_baryon_Msun"] for r in btfr_rows], [r["v_flat_km_s"] for r in btfr_rows], marker="o")
        plt.xlabel("baryonic mass (Msun)")
        plt.ylabel("v_flat example (km/s)")
        plt.title("GRAV_TRAJ_05: scale example, no galaxy fit")
        plt.tight_layout()
        p = OUT/"grav_traj_05_BTFR_scale_examples.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        plt.figure(figsize=(8,5))
        plt.scatter([r["environment_factor_E"] for r in env_rows], [r["BTFR_amplitude_factor_vs_primary"] for r in env_rows])
        plt.xlabel("environment factor E")
        plt.ylabel("BTFR amplitude factor")
        plt.title("GRAV_TRAJ_05: environment channel")
        plt.tight_layout()
        p = OUT/"grav_traj_05_environment_channel.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, candidates, h0_rows, rec_rows, btfr_rows, env_rows, controls, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_05: Settlement Acceleration Scale Constraint Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## Candidate scales\n\n")
    lines.append("| Candidate | a_S (m/s^2) | no-cheat status | factor vs optional benchmark | role |\n")
    lines.append("|---|---:|---|---:|---|\n")
    for c in candidates:
        lines.append(f"| {c['candidate']} | {c['a_S_m_s2']:.6e} | {c['no_cheat_status']} | {c['factor_error_vs_optional_a0_benchmark']:.6f} | {c['role']} |\n")

    lines.append("\n## H0 sensitivity, primary candidate\n\n")
    lines.append("| H0 | cH/(2pi) | factor vs optional benchmark |\n")
    lines.append("|---:|---:|---:|\n")
    for r in h0_rows[::10]:
        lines.append(f"| {r['H0_km_s_Mpc']:.1f} | {r['a_phase_cH_over_2pi']:.6e} | {r['factor_error_vs_optional_a0_benchmark']:.6f} |\n")

    lines.append("\n## Recombination local-ledger invariant\n\n")
    lines.append("| Ledger | R (Mly) | a_phase | aR/c^2 |\n")
    lines.append("|---|---:|---:|---:|\n")
    for r in rec_rows:
        lines.append(f"| {r['ledger']} | {r['R_Mly']:.12f} | {r['a_phase_cycle_m_s2']:.6e} | {r['dimensionless_aR_over_c2']:.12e} |\n")

    lines.append("\n## Environment channel\n\n")
    lines.append("| E | a_eff | transition radius factor | BTFR amplitude factor |\n")
    lines.append("|---:|---:|---:|---:|\n")
    for r in env_rows:
        lines.append(f"| {r['environment_factor_E']:.3f} | {r['a_eff_m_s2']:.6e} | {r['transition_radius_factor_vs_primary']:.6f} | {r['BTFR_amplitude_factor_vs_primary']:.6f} |\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    candidates = candidate_rows()
    h0_rows = h0_sensitivity_rows()
    rec_rows = recombination_invariant_rows()
    btfr_rows = btfr_prediction_rows()
    env_rows = environment_rows()
    controls = controls_summary_rows(candidates)
    verdict = verdict_row(candidates, h0_rows, rec_rows)

    write_csv(OUT/"grav_traj_05_candidate_scales.csv", candidates)
    write_csv(OUT/"grav_traj_05_H0_sensitivity.csv", h0_rows)
    write_csv(OUT/"grav_traj_05_recombination_invariants.csv", rec_rows)
    write_csv(OUT/"grav_traj_05_BTFR_scale_examples.csv", btfr_rows)
    write_csv(OUT/"grav_traj_05_environment_channel.csv", env_rows)
    write_csv(OUT/"grav_traj_05_controls.csv", controls)
    write_csv(OUT/"grav_traj_05_verdict.csv", [verdict])

    plots = save_plots(candidates, h0_rows, btfr_rows, env_rows)
    write_report(OUT/"GRAV_TRAJ_05_settlement_acceleration_scale_report.md", candidates, h0_rows, rec_rows, btfr_rows, env_rows, controls, verdict)

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_05",
        "purpose": "settlement acceleration scale no-fit constraint audit",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "files": [
            "grav_traj_05_candidate_scales.csv",
            "grav_traj_05_H0_sensitivity.csv",
            "grav_traj_05_recombination_invariants.csv",
            "grav_traj_05_BTFR_scale_examples.csv",
            "grav_traj_05_environment_channel.csv",
            "grav_traj_05_controls.csv",
            "grav_traj_05_verdict.csv",
            "GRAV_TRAJ_05_settlement_acceleration_scale_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_05 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Constrain the settlement acceleration scale a_S without fitting MOND or observed a0.")
    print("  Test horizon phase-cycle scale a_S=cH/(2pi), fixed-length controls, and forbidden observed-a0 control.")

    print("\nCandidate acceleration scales:")
    for c in candidates:
        print(
            f"  {c['candidate']:38s}  "
            f"aS={c['a_S_m_s2']:.6e} m/s^2  "
            f"factor_vs_optional_benchmark={c['factor_error_vs_optional_a0_benchmark']:.6f}  "
            f"{c['no_cheat_status']}"
        )

    print("\nH0 sensitivity for primary candidate:")
    for r in h0_rows[::10]:
        print(
            f"  H0={r['H0_km_s_Mpc']:.1f}  "
            f"aS=cH/(2pi)={r['a_phase_cH_over_2pi']:.6e}  "
            f"factor_vs_optional_benchmark={r['factor_error_vs_optional_a0_benchmark']:.6f}  "
            f"aR/c2={r['dimensionless_aR_over_c2']:.12e}"
        )

    print("\nV12.1 / recombination local-ledger invariant:")
    for r in rec_rows:
        print(
            f"  {r['ledger']:45s}  "
            f"R={r['R_Mly']:.12f} Mly  "
            f"a_phase={r['a_phase_cycle_m_s2']:.6e}  "
            f"aR/c2={r['dimensionless_aR_over_c2']:.12e}  "
            f"frac_err={r['fractional_error_to_1_over_2pi']:+.3e}"
        )

    print("\nEnvironment channel:")
    for r in env_rows:
        print(
            f"  E={r['environment_factor_E']:.3f}  "
            f"a_eff={r['a_eff_m_s2']:.6e}  "
            f"r_t_factor={r['transition_radius_factor_vs_primary']:.6f}  "
            f"BTFR_amp_factor={r['BTFR_amplitude_factor_vs_primary']:.6f}"
        )

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_05_settlement_acceleration_scale_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_05_verdict.csv'}")
    print(f"  candidate scales csv: {OUT/'grav_traj_05_candidate_scales.csv'}")
    print(f"  H0 sensitivity csv: {OUT/'grav_traj_05_H0_sensitivity.csv'}")
    print(f"  recombination invariants csv: {OUT/'grav_traj_05_recombination_invariants.csv'}")
    print(f"  environment csv: {OUT/'grav_traj_05_environment_channel.csv'}")
    print(f"  controls csv: {OUT/'grav_traj_05_controls.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
