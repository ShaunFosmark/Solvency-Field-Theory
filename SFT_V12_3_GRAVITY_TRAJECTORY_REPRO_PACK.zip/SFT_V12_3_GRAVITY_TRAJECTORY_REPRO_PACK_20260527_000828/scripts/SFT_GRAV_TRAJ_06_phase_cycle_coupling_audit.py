#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_06:
Phase-Cycle Coupling / 2pi Selector Audit

Purpose
-------
GRAV_TRAJ_05 found that the strongest no-fit acceleration-scale candidate is

    a_S = c H / (2*pi) = c^2 / (2*pi R_H).

GRAV_TRAJ_06 asks the next disciplined question:

    Why 2*pi?

This gate does NOT try to fit MOND.
It does NOT use galaxy data, SPARC, kSZ, or observed a0 as an input.
It does NOT claim a final microscopic derivation of a_S.

It tests whether the 2*pi factor is selected by SFT's own operational
phase-cycle rules rather than by numerical coincidence.

Operational claim being audited
-------------------------------
If H is the horizon/settlement angular update rate, then the physical
cycle rate is

    nu_H = H / (2*pi)

because one completed phase identity requires 2*pi radians.

The corresponding one-speed settlement acceleration is

    a_S = c * nu_H = c H / (2*pi).

This is the same cycle-vs-radian distinction that appears in:
    E = h nu = hbar omega,
    omega = 2*pi nu,
    A_cycle = h G / c^3 = 2*pi (hbar G/c^3).

Candidate normalizations
------------------------
K defines:

    a_K = c H / K = c^2 / (K R_H).

The audit compares:
    K = 1          raw angular horizon rate
    K = pi        half-cycle / sign-flip
    K = 2*pi      full phase-cycle identity
    K = 4*pi      spherical-area control
    K = K_exact   forbidden optional benchmark-fit control

Claim boundary
--------------
A pass means:
    the 2*pi normalization survives as the unique operational phase-cycle
    coupling candidate for a_S.

A pass does NOT mean:
    SFT fully derives H,
    SFT fully derives a0,
    SFT fits SPARC,
    SFT predicts kSZ,
    or SFT completes far-field gravity.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_06_OUTPUT")

# Constants.
C = 299_792_458.0
MPC = 3.0856775814913673e22
LY = 9.4607304725808e15
MLY = 1.0e6 * LY

H0_FID_KM_S_MPC = 70.0
H0_FID = H0_FID_KM_S_MPC * 1000.0 / MPC
R_H_FID = C / H0_FID

# Diagnostic only. Not used to select a candidate.
A0_BENCHMARK_OPTIONAL = 1.2e-10

# V12.1 / Gate 11R values used in prior gates.
R_REC_HUBBLE_MLY = 0.6246982112007
R_V12_EFF_REC_MLY = 0.6281043601339

# Root/radian/cycle relation from SFT root-scale language.
# Only the ratio is needed here.
A_CYCLE_OVER_A_RADIAN = 2.0 * math.pi


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def a_from_K(K: float, H: float = H0_FID) -> float:
    return C * H / K


def phase_identity_score(K: float) -> tuple[bool, str]:
    if abs(K - 2.0*math.pi) < 1e-12:
        return True, "full phase identity exp(i theta)=1 after 2pi"
    if abs(K - math.pi) < 1e-12:
        return False, "half-cycle returns sign flip, not same phase identity"
    if abs(K - 1.0) < 1e-12:
        return False, "one radian is not a completed physical cycle"
    if abs(K - 4.0*math.pi) < 1e-12:
        return False, "sphere-area factor is not one phase identity cycle"
    return False, "not selected by phase identity"


def h_hbar_score(K: float) -> tuple[bool, str]:
    if abs(K - 2.0*math.pi) < 1e-12:
        return True, "converts angular rate omega to cycle rate nu=omega/(2pi), E=h nu=hbar omega"
    return False, "does not implement cycle-vs-radian conversion"


def root_area_score(K: float) -> tuple[bool, str]:
    # A_cycle/A_radian = 2pi. Therefore cycle accounting selects K=2pi.
    if abs(K - A_CYCLE_OVER_A_RADIAN) < 1e-12:
        return True, "matches A_cycle/A_radian = h/hbar = 2pi"
    return False, "not aligned with SFT cycle/radian root-area relation"


def no_target_score(name: str) -> tuple[bool, str]:
    if "exact_optional" in name or "observed" in name:
        return False, "uses optional observed benchmark; forbidden control only"
    return True, "does not use observed a0, galaxy data, SPARC, or kSZ"


def candidate_rows() -> list[dict]:
    K_exact = C * H0_FID / A0_BENCHMARK_OPTIONAL
    candidates = [
        ("raw_angular_horizon_rate", 1.0, "a=cH", "raw angular rate control"),
        ("half_cycle_sign_flip", math.pi, "a=cH/pi", "half-cycle control"),
        ("full_phase_cycle_2pi", 2.0*math.pi, "a=cH/(2pi)", "primary phase-cycle candidate"),
        ("sphere_area_4pi_control", 4.0*math.pi, "a=cH/(4pi)", "geometry-area control"),
        ("exact_optional_benchmark_K", K_exact, "a=optional benchmark by construction", "forbidden fit control"),
    ]

    rows = []
    for name, K, formula, role in candidates:
        a = a_from_K(K)
        phase_pass, phase_reason = phase_identity_score(K)
        hpass, hreason = h_hbar_score(K)
        rpass, rreason = root_area_score(K)
        npass, nreason = no_target_score(name)

        # Selection is by internal SFT operational rules only.
        internal_score = sum([phase_pass, hpass, rpass, npass]) / 4.0

        rows.append({
            "candidate": name,
            "K": K,
            "formula": formula,
            "role": role,
            "a_S_m_s2": a,
            "aR_over_c2": a * R_H_FID / (C*C),
            "expected_1_over_K": 1.0/K,
            "ratio_to_optional_a0_benchmark": a/A0_BENCHMARK_OPTIONAL,
            "factor_error_vs_optional_a0_benchmark": max(a/A0_BENCHMARK_OPTIONAL, A0_BENCHMARK_OPTIONAL/a),
            "phase_identity_pass": phase_pass,
            "phase_identity_reason": phase_reason,
            "h_hbar_cycle_conversion_pass": hpass,
            "h_hbar_reason": hreason,
            "root_area_cycle_relation_pass": rpass,
            "root_area_reason": rreason,
            "no_target_pass": npass,
            "no_target_reason": nreason,
            "internal_operational_score_fraction": internal_score,
            "status": (
                "PRIMARY_OPERATIONAL_SELECTOR"
                if phase_pass and hpass and rpass and npass else
                ("FORBIDDEN_TARGET_CONTROL" if not npass else "REJECTED_OPERATIONAL_CONTROL")
            ),
        })
    return rows


def rule_clause_rows() -> list[dict]:
    rows = [
        {
            "clause": "phase_identity",
            "statement": "A physical phase cycle returns to identity only after theta=2pi, not after one radian or half-cycle.",
            "selects_K": 2.0*math.pi,
            "selected_factor": "1/(2pi)",
            "status": "PASS_SELECTOR_RULE",
        },
        {
            "clause": "cycle_vs_radian_accounting",
            "statement": "E=h nu=hbar omega with omega=2pi nu, so an angular settlement rate H corresponds to cycle rate H/(2pi).",
            "selects_K": 2.0*math.pi,
            "selected_factor": "1/(2pi)",
            "status": "PASS_SELECTOR_RULE",
        },
        {
            "clause": "root_area_cycle_relation",
            "statement": "The cycle-area/radian-area relation A_cycle/a_phi = h/hbar = 2pi uses the same operational conversion.",
            "selects_K": 2.0*math.pi,
            "selected_factor": "1/(2pi)",
            "status": "PASS_SELECTOR_RULE",
        },
        {
            "clause": "one_speed_horizon_settlement",
            "statement": "A settlement horizon radius R gives raw crossing scale c^2/R=cH; phase-cycle settlement divides by one completed cycle 2pi.",
            "selects_K": 2.0*math.pi,
            "selected_factor": "1/(2pi)",
            "status": "PASS_SELECTOR_RULE",
        },
        {
            "clause": "target_hygiene",
            "statement": "Observed a0 is not allowed to select K. The exact K from a0 is retained only as a forbidden control.",
            "selects_K": None,
            "selected_factor": "none",
            "status": "PASS_NO_CHEAT_BOUNDARY",
        },
    ]
    return rows


def radius_invariant_rows() -> list[dict]:
    radii = [
        ("present_fiducial_Hubble_radius", R_H_FID, R_H_FID/LY/1e9),
        ("Gate11R_recombination_Hubble_radius", R_REC_HUBBLE_MLY*MLY, R_REC_HUBBLE_MLY/1000.0),
        ("V12_1_locked_effective_recombination_radius", R_V12_EFF_REC_MLY*MLY, R_V12_EFF_REC_MLY/1000.0),
    ]
    rows = []
    for name, R, R_Gly in radii:
        for K_name, K in [
            ("raw_K_1", 1.0),
            ("phase_cycle_K_2pi", 2.0*math.pi),
            ("sphere_K_4pi", 4.0*math.pi),
        ]:
            a = C*C/(K*R)
            rows.append({
                "radius_case": name,
                "K_case": K_name,
                "K": K,
                "R_m": R,
                "R_Gly": R_Gly,
                "a_m_s2": a,
                "aR_over_c2": a*R/(C*C),
                "expected_1_over_K": 1.0/K,
                "phase_cycle_invariant_error": (a*R/(C*C))/(1.0/(2.0*math.pi))-1.0 if K_name == "phase_cycle_K_2pi" else None,
                "status": "PHASE_CYCLE_INVARIANT_PASS" if K_name == "phase_cycle_K_2pi" else "CONTROL",
            })
    return rows


def exact_control_rows() -> list[dict]:
    K_exact = C*H0_FID/A0_BENCHMARK_OPTIONAL
    H0_required_for_2pi = (2.0*math.pi*A0_BENCHMARK_OPTIONAL/C) * MPC / 1000.0
    return [
        {
            "control": "exact_K_from_optional_benchmark",
            "value": K_exact,
            "compare_to_2pi": K_exact/(2.0*math.pi),
            "factor_difference_from_2pi": max(K_exact/(2.0*math.pi), (2.0*math.pi)/K_exact),
            "status": "FORBIDDEN_TARGET_INVERSION_ONLY",
            "interpretation": "diagnostic only; cannot select K",
        },
        {
            "control": "H0_required_for_a0_if_K_2pi",
            "value_km_s_Mpc": H0_required_for_2pi,
            "compare_to_fiducial_H0": H0_required_for_2pi/H0_FID_KM_S_MPC,
            "status": "FORBIDDEN_TARGET_INVERSION_ONLY",
            "interpretation": "diagnostic only; cannot select H0",
        },
    ]


def environment_rows() -> list[dict]:
    """
    Reuses the selected K=2pi and tests whether environment factors change
    amplitude but not the phase-cycle coupling.
    """
    K = 2.0*math.pi
    aS = a_from_K(K)
    rows = []
    for E in [0.5, 0.75, 1.0, 1.25, 2.0]:
        rows.append({
            "environment_factor_E": E,
            "K_phase_cycle": K,
            "a_eff_m_s2": E*aS,
            "a_eff_over_aS": E,
            "effective_aR_over_c2": E/(2.0*math.pi),
            "K_unchanged": True,
            "interpretation": "environment changes settlement amplitude, not the operational 2pi phase-cycle coupling",
        })
    return rows


def dependency_debt_rows() -> list[dict]:
    return [
        {
            "debt": "D1_H_as_settlement_rate",
            "status": "OPEN",
            "description": "Need microscopic derivation that the relevant background settlement angular update rate is H.",
            "next_test": "derive H from V11.1B/V12.1 ledger relaxation, not from observational fitting",
        },
        {
            "debt": "D2_phase_cycle_coupling",
            "status": "PARTIALLY_CONSTRAINED",
            "description": "GRAV_TRAJ_06 selects 2pi operationally from phase identity, h/hbar accounting, and root-area cycle relation.",
            "next_test": "write formal operator mapping from angular settlement update to completed-cycle write rate",
        },
        {
            "debt": "D3_environment_factor",
            "status": "OPEN",
            "description": "Need derive E from local settlement density/boundary connectivity rather than fit per galaxy or cluster.",
            "next_test": "predict environment deviations without using MOND residuals as tuning target",
        },
        {
            "debt": "D4_data_comparison",
            "status": "DEFERRED",
            "description": "SPARC/RAR/kSZ comparisons are forbidden until the mechanism and environment factor are defined.",
            "next_test": "only after D1-D3 make falsifiable predictions",
        },
    ]


def verdict_row(candidates, clauses, invariants, exact_controls):
    primary = next(r for r in candidates if r["candidate"] == "full_phase_cycle_2pi")
    forbidden = next(r for r in candidates if r["candidate"] == "exact_optional_benchmark_K")
    controls_rejected = all(
        r["status"] in ["REJECTED_OPERATIONAL_CONTROL", "FORBIDDEN_TARGET_CONTROL", "PRIMARY_OPERATIONAL_SELECTOR"]
        for r in candidates
    )
    clause_pass = all(r["status"].startswith("PASS") for r in clauses)
    inv_pass = all(
        abs(r["phase_cycle_invariant_error"]) < 1e-14
        for r in invariants if r["K_case"] == "phase_cycle_K_2pi"
    )
    primary_pass = (
        primary["status"] == "PRIMARY_OPERATIONAL_SELECTOR" and
        abs(primary["K"] - 2.0*math.pi) < 1e-12 and
        primary["internal_operational_score_fraction"] == 1.0
    )
    forbidden_pass = forbidden["status"] == "FORBIDDEN_TARGET_CONTROL"

    ok = primary_pass and controls_rejected and clause_pass and inv_pass and forbidden_pass

    return {
        "verdict": "PHASE_CYCLE_2PI_COUPLING_SURVIVES_OPERATIONAL_SELECTOR_AUDIT" if ok else "PHASE_CYCLE_COUPLING_REQUIRES_REVISION",
        "claim_boundary": "operational selector audit only; not full microscopic derivation of H, a0, SPARC/RAR, kSZ, expansion, or nonlinear gravity",
        "selected_K": 2.0*math.pi if ok else None,
        "selected_factor": 1.0/(2.0*math.pi) if ok else None,
        "selected_formula": "a_S = c H/(2*pi)",
        "selected_aS_m_s2_at_H0_70": a_from_K(2.0*math.pi),
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_kSZ_data": False,
        "primary_operational_score": primary["internal_operational_score_fraction"],
        "phase_identity_pass": primary["phase_identity_pass"],
        "h_hbar_cycle_conversion_pass": primary["h_hbar_cycle_conversion_pass"],
        "root_area_cycle_relation_pass": primary["root_area_cycle_relation_pass"],
        "radius_invariant_pass": inv_pass,
        "forbidden_target_control_marked": forbidden_pass,
        "main_result": "The 2pi factor is selected by completed phase-cycle accounting, not by matching the optional acceleration benchmark.",
        "paper_safe_sentence": (
            "GRAV_TRAJ_06 audits the origin of the 2pi factor in the settlement acceleration scale. "
            "If the horizon/settlement update rate H is an angular phase rate, then the completed-cycle rate is H/(2pi), because phase identity returns only after 2pi radians. "
            "The same conversion is required by E=h nu=hbar omega and by the SFT cycle/radian root-area relation A_cycle/a_phi=h/hbar=2pi. "
            "Therefore the operational phase-cycle coupling selects a_S=cH/(2pi), while K=1, pi, and 4pi controls fail the cycle-identity or cycle-accounting tests and the exact optional-benchmark K is quarantined as a forbidden target inversion. "
            "This strengthens the no-fit status of the GRAV_TRAJ_05 acceleration scale, but still leaves open the microscopic derivation of H as the relevant settlement update rate and the environment factor E."
        ),
        "next_gate": (
            "GRAV_TRAJ_07 should either derive H as the settlement update rate from V11.1B/V12.1 ledger relaxation, "
            "or define the environment factor E from settlement density so that non-MOND deviations become falsifiable without tuning."
        ),
    }


def save_plots(candidates, invariants, env):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # Candidate K scores.
        plt.figure(figsize=(9,5))
        labels = [r["candidate"] for r in candidates]
        scores = [r["internal_operational_score_fraction"] for r in candidates]
        x = np.arange(len(labels))
        plt.scatter(x, scores)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("internal operational score")
        plt.title("GRAV_TRAJ_06: phase-cycle K selector")
        plt.tight_layout()
        p = OUT/"grav_traj_06_K_selector_scores.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Candidate acceleration scales.
        plt.figure(figsize=(9,5))
        vals = [r["a_S_m_s2"] for r in candidates]
        plt.scatter(x, vals)
        plt.axhline(A0_BENCHMARK_OPTIONAL, linestyle="--", linewidth=1, label="optional benchmark")
        plt.yscale("log")
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("a_K = cH/K (m/s^2)")
        plt.title("GRAV_TRAJ_06: K-normalized acceleration scales")
        plt.legend()
        plt.tight_layout()
        p = OUT/"grav_traj_06_K_acceleration_scales.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Radius invariant.
        phase = [r for r in invariants if r["K_case"] == "phase_cycle_K_2pi"]
        plt.figure(figsize=(8,5))
        labels2 = [r["radius_case"] for r in phase]
        vals2 = [r["aR_over_c2"] for r in phase]
        x2 = np.arange(len(labels2))
        plt.scatter(x2, vals2)
        plt.axhline(1.0/(2.0*math.pi), linestyle="--", linewidth=1)
        plt.xticks(x2, labels2, rotation=25, ha="right", fontsize=8)
        plt.ylabel("a R / c^2")
        plt.title("GRAV_TRAJ_06: phase-cycle invariant across ledgers")
        plt.tight_layout()
        p = OUT/"grav_traj_06_radius_invariant.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Environment factor leaves K unchanged.
        plt.figure(figsize=(8,5))
        plt.scatter([r["environment_factor_E"] for r in env], [r["effective_aR_over_c2"] for r in env])
        plt.xlabel("environment factor E")
        plt.ylabel("effective aR/c^2 = E/(2pi)")
        plt.title("GRAV_TRAJ_06: environment amplitude, K unchanged")
        plt.tight_layout()
        p = OUT/"grav_traj_06_environment_K_unchanged.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, candidates, clauses, invariants, exact_controls, env, debts, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_06: Phase-Cycle Coupling / 2pi Selector Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## K candidates\n\n")
    lines.append("| Candidate | K | a_K | score | status |\n")
    lines.append("|---|---:|---:|---:|---|\n")
    for r in candidates:
        lines.append(f"| {r['candidate']} | {r['K']:.12g} | {r['a_S_m_s2']:.6e} | {r['internal_operational_score_fraction']:.3f} | {r['status']} |\n")

    lines.append("\n## Selector clauses\n\n")
    lines.append("| Clause | selects K | status | statement |\n")
    lines.append("|---|---:|---|---|\n")
    for r in clauses:
        sel = "" if r["selects_K"] is None else f"{r['selects_K']:.12g}"
        lines.append(f"| {r['clause']} | {sel} | {r['status']} | {r['statement']} |\n")

    lines.append("\n## Radius invariants\n\n")
    lines.append("| Radius case | K case | aR/c^2 | status |\n")
    lines.append("|---|---|---:|---|\n")
    for r in invariants:
        lines.append(f"| {r['radius_case']} | {r['K_case']} | {r['aR_over_c2']:.12e} | {r['status']} |\n")

    lines.append("\n## Forbidden target controls\n\n")
    lines.append("| Control | value | status | interpretation |\n")
    lines.append("|---|---:|---|---|\n")
    for r in exact_controls:
        val = r.get("value", r.get("value_km_s_Mpc"))
        lines.append(f"| {r['control']} | {val:.12g} | {r['status']} | {r['interpretation']} |\n")

    lines.append("\n## Remaining debts\n\n")
    lines.append("| Debt | status | description |\n")
    lines.append("|---|---|---|\n")
    for r in debts:
        lines.append(f"| {r['debt']} | {r['status']} | {r['description']} |\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    candidates = candidate_rows()
    clauses = rule_clause_rows()
    invariants = radius_invariant_rows()
    exact_controls = exact_control_rows()
    env = environment_rows()
    debts = dependency_debt_rows()
    verdict = verdict_row(candidates, clauses, invariants, exact_controls)

    write_csv(OUT/"grav_traj_06_K_candidates.csv", candidates)
    write_csv(OUT/"grav_traj_06_selector_clauses.csv", clauses)
    write_csv(OUT/"grav_traj_06_radius_invariants.csv", invariants)
    write_csv(OUT/"grav_traj_06_forbidden_target_controls.csv", exact_controls)
    write_csv(OUT/"grav_traj_06_environment_channel.csv", env)
    write_csv(OUT/"grav_traj_06_dependency_debts.csv", debts)
    write_csv(OUT/"grav_traj_06_verdict.csv", [verdict])

    plots = save_plots(candidates, invariants, env)
    write_report(
        OUT/"GRAV_TRAJ_06_phase_cycle_coupling_report.md",
        candidates, clauses, invariants, exact_controls, env, debts, verdict
    )

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_06",
        "purpose": "phase-cycle 2pi coupling operational selector audit",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "files": [
            "grav_traj_06_K_candidates.csv",
            "grav_traj_06_selector_clauses.csv",
            "grav_traj_06_radius_invariants.csv",
            "grav_traj_06_forbidden_target_controls.csv",
            "grav_traj_06_environment_channel.csv",
            "grav_traj_06_dependency_debts.csv",
            "grav_traj_06_verdict.csv",
            "GRAV_TRAJ_06_phase_cycle_coupling_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_06 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Test why the settlement acceleration uses the 2pi phase-cycle coupling.")
    print("  Select K in a_S=cH/K using operational SFT rules, not observed a0.")

    print("\nK candidate audit:")
    for r in candidates:
        print(
            f"  {r['candidate']:34s}  "
            f"K={r['K']:.12g}  "
            f"aK={r['a_S_m_s2']:.6e}  "
            f"score={r['internal_operational_score_fraction']:.3f}  "
            f"factor_vs_optional_benchmark={r['factor_error_vs_optional_a0_benchmark']:.6f}  "
            f"{r['status']}"
        )

    print("\nSelector clauses:")
    for r in clauses:
        sel = "none" if r["selects_K"] is None else f"{r['selects_K']:.12g}"
        print(f"  {r['clause']:32s}  selects_K={sel:>14s}  {r['status']}")

    print("\nRadius invariant checks:")
    for r in invariants:
        if r["K_case"] == "phase_cycle_K_2pi":
            print(
                f"  {r['radius_case']:45s}  "
                f"aR/c2={r['aR_over_c2']:.12e}  "
                f"target=1/(2pi)  "
                f"err={r['phase_cycle_invariant_error']:+.3e}"
            )

    print("\nForbidden target controls:")
    for r in exact_controls:
        if "value" in r:
            print(
                f"  {r['control']:35s}  value={r['value']:.12g}  "
                f"compare_to_2pi={r.get('compare_to_2pi', float('nan')):.6f}  {r['status']}"
            )
        else:
            print(
                f"  {r['control']:35s}  value_km_s_Mpc={r['value_km_s_Mpc']:.6f}  "
                f"compare_to_fiducial={r['compare_to_fiducial_H0']:.6f}  {r['status']}"
            )

    print("\nRemaining debts:")
    for r in debts:
        print(f"  {r['debt']:28s}  {r['status']:22s}  {r['description']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_06_phase_cycle_coupling_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_06_verdict.csv'}")
    print(f"  K candidates csv: {OUT/'grav_traj_06_K_candidates.csv'}")
    print(f"  selector clauses csv: {OUT/'grav_traj_06_selector_clauses.csv'}")
    print(f"  radius invariants csv: {OUT/'grav_traj_06_radius_invariants.csv'}")
    print(f"  forbidden controls csv: {OUT/'grav_traj_06_forbidden_target_controls.csv'}")
    print(f"  debts csv: {OUT/'grav_traj_06_dependency_debts.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
