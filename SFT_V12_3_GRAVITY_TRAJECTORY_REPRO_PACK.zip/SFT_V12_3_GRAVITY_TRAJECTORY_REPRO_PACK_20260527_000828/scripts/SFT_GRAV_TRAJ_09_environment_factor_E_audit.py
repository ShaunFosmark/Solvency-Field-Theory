#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_09:
Environment Factor E from Settlement Density / Boundary Connectivity Audit

Purpose
-------
GRAV_TRAJ_04 selected an acceleration-triggered settlement handoff:

    a_eff = E a_S

GRAV_TRAJ_05-08 constrained the background piece:

    a_S(t) = c H(t)/(2*pi) = c^2/(2*pi R(t))

GRAV_TRAJ_09 audits the remaining environmental piece:

    Can E be defined from settlement density / boundary connectivity
    without fitting galaxy residuals?

This gate does NOT fit MOND.
It does NOT use SPARC, RAR, galaxy data, cluster data, kSZ data, or observed
a0 as an input.
It does NOT claim to predict real galaxy residuals yet.

It tests a no-bias candidate:

    D = rho_set / rho_bar             dimensionless settlement-density factor
    B = C_boundary / C_bar            dimensionless boundary-connectivity factor

    ln E = (ln D + ln B)/2

so

    E = sqrt(D B).

Why this candidate?
-------------------
The environment channel should:
    1. be dimensionless,
    2. be positive,
    3. equal 1 in a homogeneous background,
    4. use no observed residuals or target a0,
    5. treat settlement density and boundary connectivity without bias,
    6. work additively in log-capacity space,
    7. allow MOND-like local behavior but natural non-MOND deviations.

The equal-log geometric mean is the minimum no-bias two-channel selector:
    - density-only and connectivity-only controls are biased,
    - arithmetic controls fail reciprocal log-capacity symmetry,
    - free-exponent controls are tunable,
    - target-fitted E controls are forbidden.

Environment effect
------------------
With

    a_eff = E a_S,

the GRAV_TRAJ_04 transition gives:

    r_t(E) = sqrt(GM/(E a_S)) = r_t(1)/sqrt(E),

and the deep-regime scale becomes:

    g ~ sqrt(g_N a_S E),

so the local relation remains MOND-like in form but is not universal MOND:
different environments shift the amplitude by sqrt(E).

Claim boundary
--------------
A pass means:
    E=sqrt(D B) survives as a no-bias structural environment factor candidate.

A pass does NOT mean:
    SFT has fitted SPARC,
    SFT has explained cluster residuals,
    SFT has predicted kSZ,
    SFT has derived D or B from first principles,
    or SFT has completed far-field gravity.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_09_OUTPUT")

# Background scale values used only for dimensional examples.
C = 299_792_458.0
MPC = 3.0856775814913673e22
H0_FID_KM_S_MPC = 70.0
H0_FID = H0_FID_KM_S_MPC * 1000.0 / MPC
A_S_BACKGROUND = C * H0_FID / (2.0 * math.pi)


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


# ------------------------------------------------------------
# E candidates
# ------------------------------------------------------------

def E_geometric(D: float, B: float) -> float:
    return math.sqrt(D * B)


def E_arithmetic(D: float, B: float) -> float:
    return 0.5 * (D + B)


def E_density_only(D: float, B: float) -> float:
    return D


def E_connectivity_only(D: float, B: float) -> float:
    return B


def E_free_alpha(D: float, B: float, alpha: float = 0.7) -> float:
    return (D ** alpha) * (B ** (1.0 - alpha))


def safe_relerr(x: float, target: float) -> float:
    return x/target - 1.0


def candidate_score_rows() -> list[dict]:
    """
    Score candidate E rules by internal role constraints only.
    No observed residual or target acceleration appears here.
    """
    test_points = [
        (1.0, 1.0),
        (2.0, 2.0),
        (2.0, 0.5),
        (0.5, 2.0),
        (4.0, 0.25),
        (0.25, 4.0),
    ]

    candidates = [
        {
            "candidate": "equal_log_geometric_E_sqrt_DB",
            "formula": "E=sqrt(D*B)",
            "fn": E_geometric,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "role": "primary no-bias log-capacity selector",
        },
        {
            "candidate": "arithmetic_mean_control",
            "formula": "E=(D+B)/2",
            "fn": E_arithmetic,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "role": "linear average control",
        },
        {
            "candidate": "density_only_control",
            "formula": "E=D",
            "fn": E_density_only,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "role": "biased density-only control",
        },
        {
            "candidate": "connectivity_only_control",
            "formula": "E=B",
            "fn": E_connectivity_only,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "role": "biased connectivity-only control",
        },
        {
            "candidate": "free_alpha_log_power_control",
            "formula": "E=D^alpha B^(1-alpha), alpha fitted",
            "fn": lambda D, B: E_free_alpha(D, B, alpha=0.7),
            "has_free_parameter": True,
            "uses_target_residual": False,
            "role": "tunable exponent control",
        },
        {
            "candidate": "target_residual_fit_control",
            "formula": "E=(observed residual amplitude)^2",
            "fn": lambda D, B: 1.0,
            "has_free_parameter": True,
            "uses_target_residual": True,
            "role": "forbidden data-fit control",
        },
    ]

    rows = []
    for c in candidates:
        fn = c["fn"]
        vals = []
        for D, B in test_points:
            vals.append(fn(D, B))

        background_norm_pass = abs(fn(1.0, 1.0) - 1.0) < 1e-12
        positive_pass = all(v > 0 and math.isfinite(v) for v in vals)

        # Exchange symmetry: E(D,B)=E(B,D)
        exchange_errors = []
        for D, B in test_points:
            exchange_errors.append(abs(fn(D, B) - fn(B, D)))
        exchange_symmetry_pass = max(exchange_errors) < 1e-12

        # Reciprocal log-capacity neutrality: equal and opposite log shifts cancel.
        # For (D,B)=(x,1/x), no-bias log channels should give E=1.
        reciprocal_tests = []
        for x in [0.25, 0.5, 2.0, 4.0]:
            reciprocal_tests.append(abs(fn(x, 1.0/x) - 1.0))
        reciprocal_log_neutral_pass = max(reciprocal_tests) < 1e-12

        no_free_parameter_pass = not c["has_free_parameter"]
        no_target_pass = not c["uses_target_residual"]
        dimensionless_pass = True

        score_flags = [
            dimensionless_pass,
            background_norm_pass,
            positive_pass,
            exchange_symmetry_pass,
            reciprocal_log_neutral_pass,
            no_free_parameter_pass,
            no_target_pass,
        ]
        score = sum(score_flags) / len(score_flags)

        if c["candidate"] == "equal_log_geometric_E_sqrt_DB" and score == 1.0:
            status = "PRIMARY_ENVIRONMENT_SELECTOR"
        elif c["uses_target_residual"]:
            status = "FORBIDDEN_TARGET_CONTROL"
        elif c["has_free_parameter"]:
            status = "REJECT_TUNABLE_CONTROL"
        else:
            status = "REJECTED_ENVIRONMENT_CONTROL"

        rows.append({
            "candidate": c["candidate"],
            "formula": c["formula"],
            "role": c["role"],
            "dimensionless_pass": dimensionless_pass,
            "background_norm_pass": background_norm_pass,
            "positive_pass": positive_pass,
            "exchange_symmetry_pass": exchange_symmetry_pass,
            "reciprocal_log_neutral_pass": reciprocal_log_neutral_pass,
            "no_free_parameter_pass": no_free_parameter_pass,
            "no_target_pass": no_target_pass,
            "internal_score": score,
            "status": status,
        })

    return rows


# ------------------------------------------------------------
# Synthetic environment profiles
# ------------------------------------------------------------

def classify_environment(E: float) -> str:
    if E < 0.75:
        return "LOW_SETTLEMENT_ACCELERATION_ENVIRONMENT"
    if E > 1.333333333:
        return "HIGH_SETTLEMENT_ACCELERATION_ENVIRONMENT"
    return "NEAR_BACKGROUND_OR_COMPENSATED_ENVIRONMENT"


def synthetic_profile_rows() -> list[dict]:
    profiles = [
        ("homogeneous_background", 1.0, 1.0, "baseline"),
        ("isolated_underconnected_void", 0.5, 0.5, "both channels below background"),
        ("dense_connected_region", 2.0, 2.0, "both channels above background"),
        ("density_enhanced_connectivity_background", 2.0, 1.0, "density channel only"),
        ("connectivity_enhanced_density_background", 1.0, 2.0, "connectivity channel only"),
        ("dense_but_boundary_screened", 2.0, 0.5, "opposite log channels compensate"),
        ("diffuse_but_overconnected", 0.5, 2.0, "opposite log channels compensate"),
        ("strong_cluster_like_synthetic", 4.0, 2.0, "high synthetic environment"),
        ("deep_void_like_synthetic", 0.25, 0.5, "low synthetic environment"),
        ("extreme_compensated_synthetic", 4.0, 0.25, "exact log compensation"),
    ]

    rows = []
    for name, D, B, desc in profiles:
        E = E_geometric(D, B)
        a_eff = E * A_S_BACKGROUND
        rt_factor = 1.0 / math.sqrt(E)
        deep_rar_factor = math.sqrt(E)
        rows.append({
            "profile": name,
            "description": desc,
            "D_settlement_density_factor": D,
            "B_boundary_connectivity_factor": B,
            "lnD": math.log(D),
            "lnB": math.log(B),
            "lnE": math.log(E),
            "E_sqrt_DB": E,
            "a_eff_over_aS": E,
            "a_eff_m_s2_at_H0_70": a_eff,
            "transition_radius_factor_rt_over_background": rt_factor,
            "BTFR_amplitude_factor_v4_over_background": E,
            "deep_RAR_amplitude_factor_g_over_universal": deep_rar_factor,
            "environment_class": classify_environment(E),
            "compensation_flag": abs(E - 1.0) < 1e-12 and (abs(D-1.0) > 1e-12 or abs(B-1.0) > 1e-12),
        })
    return rows


def environment_grid_rows() -> list[dict]:
    rows = []
    Ds = np.logspace(math.log10(0.25), math.log10(4.0), 33)
    Bs = np.logspace(math.log10(0.25), math.log10(4.0), 33)
    for D in Ds:
        for B in Bs:
            E = E_geometric(float(D), float(B))
            rows.append({
                "D_settlement_density_factor": float(D),
                "B_boundary_connectivity_factor": float(B),
                "E_sqrt_DB": E,
                "lnE": math.log(E),
                "a_eff_over_aS": E,
                "transition_radius_factor": 1.0/math.sqrt(E),
                "BTFR_amplitude_factor": E,
                "deep_RAR_amplitude_factor": math.sqrt(E),
                "phase_environment_invariant_a_eff_R_over_c2_factor": E/(2.0*math.pi),
            })
    return rows


def transition_effect_rows() -> list[dict]:
    """
    Dimensionless GRAV_TRAJ_04 transition under environment E.

    Uses GM=1, aS=1:
        g_N = 1/r^2
        r_t(E)=1/sqrt(E)
        g = g_N sqrt(1+(r/r_t)^2)
    """
    rows = []
    profiles = synthetic_profile_rows()
    x_values = np.logspace(-3, 3, 121)  # x = r/r_t(E)
    for p in profiles:
        E = p["E_sqrt_DB"]
        rt = 1.0 / math.sqrt(E)
        for x in x_values:
            r = x * rt
            gN = 1.0/(r*r)
            g = gN * math.sqrt(1.0 + x*x)
            deep_universal = math.sqrt(gN * 1.0)
            deep_env = math.sqrt(gN * E)
            rows.append({
                "profile": p["profile"],
                "E": E,
                "x_r_over_rt_environment": float(x),
                "r_dimensionless": r,
                "gN_dimensionless": gN,
                "g_environment_transition": g,
                "g_over_gN": g/gN,
                "deep_env_factor_sqrtE": math.sqrt(E),
                "g_over_universal_deep_sqrt_gN_aS": g/deep_universal if deep_universal > 0 else None,
                "deep_limit_expected_factor_sqrtE": math.sqrt(E),
                "g_over_environment_deep_sqrt_gN_aEff": g/deep_env if deep_env > 0 else None,
            })
    return rows


def transition_summary_rows() -> list[dict]:
    rows = []
    trans = transition_effect_rows()
    for profile in sorted(set(r["profile"] for r in trans)):
        sub = [r for r in trans if r["profile"] == profile]
        E = sub[0]["E"]
        near = [r for r in sub if r["x_r_over_rt_environment"] < 0.01]
        deep = [r for r in sub if r["x_r_over_rt_environment"] > 100.0]
        near_g_over_gN = float(np.mean([r["g_over_gN"] for r in near]))
        deep_env_ratio = float(np.mean([r["g_over_environment_deep_sqrt_gN_aEff"] for r in deep]))
        deep_universal_ratio = float(np.mean([r["g_over_universal_deep_sqrt_gN_aS"] for r in deep]))
        rows.append({
            "profile": profile,
            "E": E,
            "near_mean_g_over_gN": near_g_over_gN,
            "near_newton_pass": abs(near_g_over_gN - 1.0) < 1e-3,
            "deep_mean_g_over_environment_sqrt_gN_aEff": deep_env_ratio,
            "deep_environment_MOND_like_pass": abs(deep_env_ratio - 1.0) < 1e-2,
            "deep_mean_g_over_universal_sqrt_gN_aS": deep_universal_ratio,
            "expected_universal_deviation_sqrtE": math.sqrt(E),
            "universal_deviation_factor_error": deep_universal_ratio / math.sqrt(E) - 1.0,
            "interpretation": "same local kernel; environment shifts universal MOND-like amplitude by sqrt(E)",
        })
    return rows


# ------------------------------------------------------------
# Controls / debts / verdict
# ------------------------------------------------------------

def control_rows(candidates) -> list[dict]:
    rows = []
    for c in candidates:
        if c["status"] == "PRIMARY_ENVIRONMENT_SELECTOR":
            reason = "dimensionless positive background-normalized equal-log no-bias selector with no target residual"
        elif c["status"] == "FORBIDDEN_TARGET_CONTROL":
            reason = "uses observed residuals or target acceleration; forbidden before mechanism/data stage"
        elif c["candidate"] == "arithmetic_mean_control":
            reason = "background normalized but fails reciprocal log-capacity neutrality"
        elif c["candidate"] == "density_only_control":
            reason = "biased to density channel and fails exchange symmetry"
        elif c["candidate"] == "connectivity_only_control":
            reason = "biased to connectivity channel and fails exchange symmetry"
        elif c["candidate"] == "free_alpha_log_power_control":
            reason = "would allow per-system or data-tuned exponent"
        else:
            reason = "rejected control"
        rows.append({
            "candidate": c["candidate"],
            "status": c["status"],
            "score": c["internal_score"],
            "reason": reason,
        })
    return rows


def dependency_debt_rows() -> list[dict]:
    return [
        {
            "debt": "D1_define_D_from_microphysics",
            "status": "OPEN",
            "description": "Need derive D=rho_set/rho_bar from SFT settlement density, not choose a proxy after seeing data.",
            "next_test": "map D to a computable quantity from source density, ledger write density, or simulation fields without fitting residuals",
        },
        {
            "debt": "D2_define_B_from_boundary_connectivity",
            "status": "OPEN",
            "description": "Need derive B=C_boundary/C_bar from boundary connectivity or settlement graph topology.",
            "next_test": "construct graph/spectral or horizon-connectivity estimator that can be computed before comparing to galaxy residuals",
        },
        {
            "debt": "D3_validate_E_against_blind_synthetic_predictions",
            "status": "DEFERRED",
            "description": "Need blind predictions for environments before SPARC/RAR/cluster/kSZ comparisons.",
            "next_test": "choose D and B observables, freeze them, then compare predicted deviations to data",
        },
        {
            "debt": "D4_link_E_to_cosmology_and_clusters",
            "status": "OPEN",
            "description": "Need determine whether E explains where MOND-like laws fail, such as clusters or large-scale flows, without tuning.",
            "next_test": "after D/B definitions, test cluster and kSZ channels with pre-registered predictions",
        },
        {
            "debt": "D5_preserve_near_field_GR",
            "status": "WATCH",
            "description": "Need ensure E modifies far-field settlement handoff without corrupting local weak-field metric closure from GRAV_TRAJ_02.",
            "next_test": "verify E enters transition scale, not local FB=1 metric closure",
        },
    ]


def verdict_row(candidates, profiles, grid, trans_summary, controls):
    primary = next(c for c in candidates if c["candidate"] == "equal_log_geometric_E_sqrt_DB")
    forbidden = next(c for c in candidates if c["candidate"] == "target_residual_fit_control")

    primary_pass = primary["status"] == "PRIMARY_ENVIRONMENT_SELECTOR" and abs(primary["internal_score"] - 1.0) < 1e-12
    forbidden_pass = forbidden["status"] == "FORBIDDEN_TARGET_CONTROL"
    profile_pass = all(p["E_sqrt_DB"] > 0 and math.isfinite(p["E_sqrt_DB"]) for p in profiles)
    compensation_pass = any(p["compensation_flag"] for p in profiles)
    grid_pass = all(r["E_sqrt_DB"] > 0 and math.isfinite(r["E_sqrt_DB"]) for r in grid)
    transition_pass = all(r["near_newton_pass"] and r["deep_environment_MOND_like_pass"] for r in trans_summary)

    # Make sure universal deviations are present for non-background environments.
    deviations = [abs(r["deep_mean_g_over_universal_sqrt_gN_aS"] - 1.0) for r in trans_summary if abs(r["E"] - 1.0) > 1e-12]
    non_mond_deviation_channel_pass = max(deviations) > 0.1

    ok = primary_pass and forbidden_pass and profile_pass and compensation_pass and grid_pass and transition_pass and non_mond_deviation_channel_pass

    return {
        "verdict": "ENVIRONMENT_FACTOR_E_SURVIVES_NO_BIAS_SETTLEMENT_DENSITY_CONNECTIVITY_AUDIT" if ok else "ENVIRONMENT_FACTOR_E_REQUIRES_REVISION",
        "claim_boundary": "structural environment-factor audit only; not a SPARC/RAR fit, not cluster solution, not kSZ prediction, not derivation of D or B, and not completed far-field gravity",
        "selected_E_law": "E=sqrt(D*B)",
        "selected_log_law": "ln E = (ln D + ln B)/2",
        "D_definition_placeholder": "D=rho_set/rho_bar",
        "B_definition_placeholder": "B=C_boundary/C_bar",
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_SPARC_or_RAR_data": False,
        "uses_cluster_data": False,
        "uses_kSZ_data": False,
        "primary_selector_pass": primary_pass,
        "forbidden_target_control_marked": forbidden_pass,
        "positive_grid_pass": grid_pass,
        "compensated_environment_channel_present": compensation_pass,
        "transition_kernel_preserved_pass": transition_pass,
        "non_MOND_deviation_channel_present": non_mond_deviation_channel_pass,
        "background_aS_m_s2_at_H0_70": A_S_BACKGROUND,
        "main_result": "The no-bias equal-log selector E=sqrt(D B) supplies a dimensionless, positive, background-normalized environment factor that shifts the GRAV_TRAJ_04 far-field amplitude without fitting residuals.",
        "paper_safe_sentence": (
            "GRAV_TRAJ_09 audits the environmental deformation of the GRAV_TRAJ_04 settlement handoff. "
            "Defining dimensionless settlement-density and boundary-connectivity channels D=rho_set/rho_bar and B=C_boundary/C_bar, the no-bias log-capacity selector lnE=(lnD+lnB)/2 gives E=sqrt(DB). "
            "This factor is positive, equals one in the homogeneous background, treats density and connectivity symmetrically, and cancels equal-and-opposite log-channel shifts, while density-only, connectivity-only, arithmetic, free-exponent, and target-residual controls fail the role audit or are quarantined. "
            "With a_eff=E a_S(t), the near-field Newtonian limit and local transition kernel are preserved, while the deep-regime amplitude shifts by sqrt(E), providing a MOND-like but not universal-MOND deviation channel. "
            "This is only a structural environment-factor candidate: D and B must still be derived from SFT settlement density and boundary connectivity before any SPARC, cluster, or kSZ comparison."
        ),
        "next_gate": "GRAV_TRAJ_10 should define computable D and B estimators, preferably from a frozen synthetic graph/field rule, before any observational comparison.",
    }


def save_plots(candidates, profiles, grid, trans_summary):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # Candidate scores.
        plt.figure(figsize=(10,5))
        labels = [r["candidate"] for r in candidates]
        vals = [r["internal_score"] for r in candidates]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("internal role score")
        plt.title("GRAV_TRAJ_09: E selector scores")
        plt.tight_layout()
        p = OUT/"grav_traj_09_E_candidate_scores.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Synthetic profile E factors.
        plt.figure(figsize=(10,5))
        labels = [r["profile"] for r in profiles]
        vals = [r["E_sqrt_DB"] for r in profiles]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("E=sqrt(D B)")
        plt.title("GRAV_TRAJ_09: synthetic environment factors")
        plt.tight_layout()
        p = OUT/"grav_traj_09_synthetic_E_profiles.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Grid heatmap.
        D_vals = sorted(set(round(r["D_settlement_density_factor"], 12) for r in grid))
        B_vals = sorted(set(round(r["B_boundary_connectivity_factor"], 12) for r in grid))
        Z = np.zeros((len(B_vals), len(D_vals)))
        index_D = {v:i for i,v in enumerate(D_vals)}
        index_B = {v:i for i,v in enumerate(B_vals)}
        for r in grid:
            i = index_B[round(r["B_boundary_connectivity_factor"], 12)]
            j = index_D[round(r["D_settlement_density_factor"], 12)]
            Z[i,j] = r["E_sqrt_DB"]
        plt.figure(figsize=(7,6))
        plt.imshow(Z, origin="lower", aspect="auto", extent=[min(D_vals), max(D_vals), min(B_vals), max(B_vals)])
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("D settlement-density factor")
        plt.ylabel("B boundary-connectivity factor")
        plt.title("GRAV_TRAJ_09: E=sqrt(D B)")
        plt.colorbar(label="E")
        plt.tight_layout()
        p = OUT/"grav_traj_09_E_grid.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # RAR deviation factor.
        plt.figure(figsize=(10,5))
        labels = [r["profile"] for r in trans_summary]
        vals = [r["deep_mean_g_over_universal_sqrt_gN_aS"] for r in trans_summary]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("deep g / universal sqrt(gN aS)")
        plt.title("GRAV_TRAJ_09: non-universal MOND-like deviation channel")
        plt.tight_layout()
        p = OUT/"grav_traj_09_deep_RAR_deviation.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, candidates, profiles, trans_summary, controls, debts, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_09: Environment Factor E Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## Candidate E selectors\n\n")
    lines.append("| Candidate | formula | score | status |\n")
    lines.append("|---|---|---:|---|\n")
    for r in candidates:
        lines.append(f"| {r['candidate']} | {r['formula']} | {r['internal_score']:.3f} | {r['status']} |\n")

    lines.append("\n## Synthetic environment profiles\n\n")
    lines.append("| Profile | D | B | E | rt factor | deep deviation sqrt(E) | class |\n")
    lines.append("|---|---:|---:|---:|---:|---:|---|\n")
    for r in profiles:
        lines.append(
            f"| {r['profile']} | {r['D_settlement_density_factor']:.6f} | {r['B_boundary_connectivity_factor']:.6f} | "
            f"{r['E_sqrt_DB']:.6f} | {r['transition_radius_factor_rt_over_background']:.6f} | "
            f"{r['deep_RAR_amplitude_factor_g_over_universal']:.6f} | {r['environment_class']} |\n"
        )

    lines.append("\n## Transition summary\n\n")
    lines.append("| Profile | E | near Newton pass | deep env pass | universal deviation |\n")
    lines.append("|---|---:|---|---|---:|\n")
    for r in trans_summary:
        lines.append(
            f"| {r['profile']} | {r['E']:.6f} | {r['near_newton_pass']} | {r['deep_environment_MOND_like_pass']} | "
            f"{r['deep_mean_g_over_universal_sqrt_gN_aS']:.6f} |\n"
        )

    lines.append("\n## Controls\n\n")
    lines.append("| Candidate | status | reason |\n")
    lines.append("|---|---|---|\n")
    for r in controls:
        lines.append(f"| {r['candidate']} | {r['status']} | {r['reason']} |\n")

    lines.append("\n## Remaining debts\n\n")
    lines.append("| Debt | status | description |\n")
    lines.append("|---|---|---|\n")
    for r in debts:
        lines.append(f"| {r['debt']} | {r['status']} | {r['description']} |\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    candidates = candidate_score_rows()
    profiles = synthetic_profile_rows()
    grid = environment_grid_rows()
    trans = transition_effect_rows()
    trans_summary = transition_summary_rows()
    controls = control_rows(candidates)
    debts = dependency_debt_rows()
    verdict = verdict_row(candidates, profiles, grid, trans_summary, controls)

    write_csv(OUT/"grav_traj_09_E_candidates.csv", candidates)
    write_csv(OUT/"grav_traj_09_synthetic_environment_profiles.csv", profiles)
    write_csv(OUT/"grav_traj_09_environment_grid.csv", grid)
    write_csv(OUT/"grav_traj_09_transition_effect_rows.csv", trans)
    write_csv(OUT/"grav_traj_09_transition_summary.csv", trans_summary)
    write_csv(OUT/"grav_traj_09_controls.csv", controls)
    write_csv(OUT/"grav_traj_09_dependency_debts.csv", debts)
    write_csv(OUT/"grav_traj_09_verdict.csv", [verdict])

    plots = save_plots(candidates, profiles, grid, trans_summary)
    write_report(
        OUT/"GRAV_TRAJ_09_environment_factor_E_report.md",
        candidates, profiles, trans_summary, controls, debts, verdict
    )

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_09",
        "purpose": "derive/constrain environment factor E from settlement density and boundary connectivity",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "files": [
            "grav_traj_09_E_candidates.csv",
            "grav_traj_09_synthetic_environment_profiles.csv",
            "grav_traj_09_environment_grid.csv",
            "grav_traj_09_transition_effect_rows.csv",
            "grav_traj_09_transition_summary.csv",
            "grav_traj_09_controls.csv",
            "grav_traj_09_dependency_debts.csv",
            "grav_traj_09_verdict.csv",
            "GRAV_TRAJ_09_environment_factor_E_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_09 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Audit environment factor E from settlement density D and boundary connectivity B.")
    print("  No observed a0, SPARC/RAR, galaxy data, cluster data, or kSZ data are used.")

    print("\nE candidate selector audit:")
    for r in candidates:
        print(
            f"  {r['candidate']:34s}  "
            f"score={r['internal_score']:.3f}  "
            f"background={r['background_norm_pass']}  "
            f"exchange={r['exchange_symmetry_pass']}  "
            f"reciprocal_log={r['reciprocal_log_neutral_pass']}  "
            f"no_target={r['no_target_pass']}  "
            f"{r['status']}"
        )

    print("\nSynthetic environment profiles:")
    for r in profiles:
        print(
            f"  {r['profile']:40s}  "
            f"D={r['D_settlement_density_factor']:.4f}  "
            f"B={r['B_boundary_connectivity_factor']:.4f}  "
            f"E={r['E_sqrt_DB']:.6f}  "
            f"rt_factor={r['transition_radius_factor_rt_over_background']:.6f}  "
            f"deep_factor={r['deep_RAR_amplitude_factor_g_over_universal']:.6f}  "
            f"{r['environment_class']}"
        )

    print("\nTransition kernel summary:")
    for r in trans_summary:
        print(
            f"  {r['profile']:40s}  "
            f"E={r['E']:.6f}  "
            f"near_g/gN={r['near_mean_g_over_gN']:.6f}  "
            f"deep_env_ratio={r['deep_mean_g_over_environment_sqrt_gN_aEff']:.6f}  "
            f"deep_universal_ratio={r['deep_mean_g_over_universal_sqrt_gN_aS']:.6f}"
        )

    print("\nControls:")
    for r in controls:
        print(
            f"  {r['candidate']:34s}  "
            f"score={r['score']:.3f}  "
            f"{r['status']}  "
            f"{r['reason']}"
        )

    print("\nRemaining debts:")
    for r in debts:
        print(f"  {r['debt']:42s}  {r['status']:12s}  {r['description']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_09_environment_factor_E_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_09_verdict.csv'}")
    print(f"  E candidates csv: {OUT/'grav_traj_09_E_candidates.csv'}")
    print(f"  synthetic profiles csv: {OUT/'grav_traj_09_synthetic_environment_profiles.csv'}")
    print(f"  environment grid csv: {OUT/'grav_traj_09_environment_grid.csv'}")
    print(f"  transition summary csv: {OUT/'grav_traj_09_transition_summary.csv'}")
    print(f"  controls csv: {OUT/'grav_traj_09_controls.csv'}")
    print(f"  debts csv: {OUT/'grav_traj_09_dependency_debts.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
