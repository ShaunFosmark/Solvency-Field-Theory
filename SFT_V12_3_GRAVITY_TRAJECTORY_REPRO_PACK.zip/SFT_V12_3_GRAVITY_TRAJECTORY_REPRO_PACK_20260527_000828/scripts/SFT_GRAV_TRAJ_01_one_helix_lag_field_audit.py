#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_01:
Single One-Speed Helical Worldline Lag-Field Audit

Purpose
-------
This is the first geometry/source audit after the V12.2 root-scale closure.

It tests the minimal version of the Opus/SFT claim:

    A one-speed internal circulation, time-averaged over one Compton cycle,
    produces a lag field with:
      1. a Newtonian monopole after spherical averaging,
      2. an equatorial enhancement,
      3. a polar deficit,
      4. a leading quadrupole of the form

            Lambda(r,theta) ~= Lambda0(r) * [1 + epsilon(r) * (sin^2(theta) - 2/3)]

         with epsilon(r) ~ (3/4) * (a/r)^2 for a circular helix/ring source.

What this DOES test
-------------------
A single circular one-speed internal orbit is modeled as a time-averaged ring
source with Green kernel 1/|x-x'|. This is the simplest stationary rest-frame
proxy for a Compton helix's internal circulation.

The script checks:
    - spherical average recovers 1/r outside the ring,
    - quadrupole sign is equatorial-positive / polar-negative,
    - fitted epsilon approaches 0.75*(a/r)^2,
    - residual after monopole+quadrupole falls with radius,
    - V12.2 normalization would attach as amplitude, not shape.

What this DOES NOT test
-----------------------
This does not yet derive full GR, full tensor gravity, MOND, expansion, jets,
or frame dragging. Those require a dynamical settlement equation and/or spin/
current/torsion channels. This is a first source-kernel audit only.

Claim boundary
--------------
A pass means the one-helix geometry naturally supplies the directional-lag
seed that V11.14/V13 needs. It does not prove the full gravity theory.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_01_OUTPUT")


# -----------------------------
# Numerical kernel
# -----------------------------

def ring_kernel(r: float, theta: np.ndarray, a: float = 1.0, n_phase: int = 4096) -> np.ndarray:
    """
    Time-averaged Green kernel for a circular internal orbit/ring in the xy plane.

    Field point:
        x = r sin(theta), z = r cos(theta)
    Source point:
        x' = a cos(phi), y'=a sin(phi), z'=0

    Averaged kernel:
        <1/sqrt(r^2 + a^2 - 2 r a sin(theta) cos(phi))>_phi
    """
    phi = np.linspace(0.0, 2.0 * math.pi, n_phase, endpoint=False)
    cos_phi = np.cos(phi)
    theta = np.asarray(theta)
    sin_theta = np.sin(theta)[:, None]
    denom2 = r*r + a*a - 2.0*r*a*sin_theta*cos_phi[None, :]
    denom2 = np.maximum(denom2, 1e-300)
    return np.mean(1.0 / np.sqrt(denom2), axis=1)


def fit_quadrupole(r: float, a: float = 1.0, n_mu: int = 401, n_phase: int = 4096) -> dict:
    """
    Fit exact ring kernel to:
        Lambda = Lambda0 * [1 + epsilon * q(theta)]
        q = sin^2(theta) - 2/3 = 1/3 - mu^2

    Uses uniform integration in mu=cos(theta), equivalent to spherical weighting.
    """
    mu = np.linspace(-1.0, 1.0, n_mu)
    theta = np.arccos(mu)
    lam = ring_kernel(r, theta, a=a, n_phase=n_phase)

    # Spherical average = (1/2) int_{-1}^{1} Lambda dmu.
    lam0 = np.trapz(lam, mu) / 2.0
    expected_monopole = 1.0 / r

    q = 1.0 - mu**2 - 2.0/3.0
    delta = lam / lam0 - 1.0

    eps = np.trapz(delta*q, mu) / np.trapz(q*q, mu)
    model = lam0 * (1.0 + eps*q)
    residual = lam - model
    rms_frac = math.sqrt(float(np.trapz((residual/lam0)**2, mu) / 2.0))
    max_frac = float(np.max(np.abs(residual/lam0)))

    # Diagnostics at equator and pole.
    lam_equator = float(ring_kernel(r, np.array([math.pi/2]), a=a, n_phase=n_phase)[0])
    lam_pole = float(ring_kernel(r, np.array([0.0]), a=a, n_phase=n_phase)[0])
    equator_frac = lam_equator / lam0 - 1.0
    pole_frac = lam_pole / lam0 - 1.0

    eps_pred = 0.75 * (a/r)**2
    eps_scaled = eps / ((a/r)**2)

    # Finite-difference radial gradients, positive inward magnitude approximately -dLambda/dr.
    dr = max(1e-4*r, 1e-5)
    lam_eq_plus = float(ring_kernel(r+dr, np.array([math.pi/2]), a=a, n_phase=n_phase)[0])
    lam_eq_minus = float(ring_kernel(r-dr, np.array([math.pi/2]), a=a, n_phase=n_phase)[0])
    lam_pole_plus = float(ring_kernel(r+dr, np.array([0.0]), a=a, n_phase=n_phase)[0])
    lam_pole_minus = float(ring_kernel(r-dr, np.array([0.0]), a=a, n_phase=n_phase)[0])
    g_eq = -(lam_eq_plus-lam_eq_minus)/(2*dr)
    g_pole = -(lam_pole_plus-lam_pole_minus)/(2*dr)
    g_newton = 1.0/(r*r)

    return {
        "r_over_a": r/a,
        "r": r,
        "a": a,
        "lambda0_spherical_average": lam0,
        "expected_monopole_1_over_r": expected_monopole,
        "monopole_fractional_error": lam0/expected_monopole - 1.0,
        "epsilon_fit": eps,
        "epsilon_pred_0p75_a2_over_r2": eps_pred,
        "epsilon_fit_over_pred": eps/eps_pred,
        "epsilon_scaled_by_r2_over_a2": eps_scaled,
        "quadrupole_basis": "sin^2(theta)-2/3",
        "rms_fractional_residual_after_quadrupole": rms_frac,
        "max_fractional_residual_after_quadrupole": max_frac,
        "equator_fractional_excess": equator_frac,
        "pole_fractional_deficit": pole_frac,
        "equator_over_pole_lambda": lam_equator/lam_pole,
        "inward_gradient_equator": g_eq,
        "inward_gradient_pole": g_pole,
        "newton_gradient_1_over_r2": g_newton,
        "equator_gradient_over_newton": g_eq/g_newton,
        "pole_gradient_over_newton": g_pole/g_newton,
        "directionality_pass": bool(equator_frac > 0 and pole_frac < 0),
        "monopole_pass": bool(abs(lam0/expected_monopole - 1.0) < 5e-4),
        "quadrupole_far_field_pass": bool(abs(eps/eps_pred - 1.0) < 0.05) if r/a >= 5 else None,
    }


def multipole_coefficients(r: float, a: float = 1.0, n_mu: int = 801, n_phase: int = 4096, lmax: int = 8) -> list[dict]:
    """
    Computes Legendre coefficients A_l of Lambda/Lambda0 - 1:
        delta(mu) = sum_l A_l P_l(mu)
    using orthogonality. Odd l should be ~0 by north/south symmetry.
    """
    from numpy.polynomial.legendre import legval

    mu = np.linspace(-1.0, 1.0, n_mu)
    theta = np.arccos(mu)
    lam = ring_kernel(r, theta, a=a, n_phase=n_phase)
    lam0 = np.trapz(lam, mu)/2.0
    delta = lam/lam0 - 1.0
    rows = []
    for l in range(lmax+1):
        coeffs = [0.0]*l + [1.0]
        Pl = legval(mu, coeffs)
        A = (2*l+1)/2.0 * np.trapz(delta*Pl, mu)
        rows.append({
            "r_over_a": r/a,
            "l": l,
            "A_l_fractional": float(A),
            "abs_A_l": float(abs(A)),
            "parity": "even" if l % 2 == 0 else "odd",
        })
    return rows


def stage_level_rows() -> list[dict]:
    return [
        {
            "level": 0,
            "name": "scalar point lag",
            "added_physics": "monopole 1/r source only",
            "photon": "unclear",
            "MOND": "no",
            "expansion": "separate",
            "direction": "no",
            "status": "pre-helix baseline",
        },
        {
            "level": 1,
            "name": "settlement dynamics",
            "added_physics": "lag residual has relaxation/diffusion",
            "photon": "unclear",
            "MOND": "emerging scale possibility",
            "expansion": "connected in principle",
            "direction": "no",
            "status": "needs source geometry",
        },
        {
            "level": 2,
            "name": "one-speed c-budget",
            "added_physics": "motion at c is universal source logic",
            "photon": "yes conceptually",
            "MOND": "not derived",
            "expansion": "same budget pressure possible",
            "direction": "helix implied",
            "status": "mechanism reframed",
        },
        {
            "level": 3,
            "name": "helical/ring source kernel",
            "added_physics": "time-averaged internal circulation creates angular lag pattern",
            "photon": "source continuity still pending",
            "MOND": "not derived",
            "expansion": "not derived",
            "direction": "yes: equatorial enhancement and polar deficit",
            "status": "tested by this script",
        },
        {
            "level": 4,
            "name": "rho+3p operation source",
            "added_physics": "radiation/matter source weighting",
            "photon": "quantified at 2x",
            "MOND": "not derived",
            "expansion": "pressure contribution quantified",
            "direction": "source current implied",
            "status": "requires merge with helix kernel",
        },
        {
            "level": 5,
            "name": "V11.13 weak-field metric scaffold",
            "added_physics": "B=F^-1, PPN markers, light/perihelion scaffold",
            "photon": "metric response present",
            "MOND": "not derived",
            "expansion": "not unified",
            "direction": "not sourced from helix yet",
            "status": "geometry scaffold passed",
        },
        {
            "level": 6,
            "name": "V12.1 settlement relaxation",
            "added_physics": "cosmological shatter/relaxation and Q=a_T^(1/6)",
            "photon": "thermal history separated",
            "MOND": "transition hint only",
            "expansion": "settlement relaxation quantified toy-level",
            "direction": "far-field direction implied",
            "status": "cosmological branch passed toy closure",
        },
        {
            "level": 7,
            "name": "target unified directional lag",
            "added_physics": "near-field gravity and far-field expansion from one directional lag field",
            "photon": "should be same one-speed source",
            "MOND": "to be tested",
            "expansion": "to be unified",
            "direction": "full target",
            "status": "not yet computed; next V11.14/V13 target",
        },
        {
            "level": 8,
            "name": "V12.2 root-scale attachment",
            "added_physics": "a_phi,cand normalization attaches after geometry",
            "photon": "unchanged shape; amplitude only",
            "MOND": "unchanged shape; amplitude only",
            "expansion": "unchanged shape; amplitude only",
            "direction": "unchanged shape; amplitude only",
            "status": "valid normalization branch if geometry kernel passes",
        },
    ]


def endpoint_summary(fits: list[dict]) -> dict:
    far = [r for r in fits if r["r_over_a"] >= 10]
    direction_pass = all(r["directionality_pass"] for r in fits)
    monopole_pass = all(r["monopole_pass"] for r in fits)
    quad_pass = all(abs(r["epsilon_fit_over_pred"] - 1.0) < 0.02 for r in far)
    residual_far = max(r["rms_fractional_residual_after_quadrupole"] for r in far)
    if direction_pass and monopole_pass and quad_pass:
        verdict = "ONE_HELIX_RING_SOURCE_PASSES_DIRECTIONAL_LAG_SEED_AUDIT"
    else:
        verdict = "ONE_HELIX_RING_SOURCE_NEEDS_REVISION"
    return {
        "verdict": verdict,
        "claim_boundary": "source-kernel seed only; not full gravity, MOND, expansion, frame dragging, or jets",
        "directionality_all_r_pass": direction_pass,
        "monopole_all_r_pass": monopole_pass,
        "quadrupole_far_field_pass": quad_pass,
        "max_far_rms_residual_after_quadrupole": residual_far,
        "main_result": "time-averaged helical/ring source has Newtonian monopole plus equatorial-positive quadrupole",
        "paper_safe_sentence": (
            "The first directional-lag source audit models a rest-frame one-speed internal circulation as a "
            "time-averaged ring source. Outside the circulation radius, the spherical average recovers the "
            "Newtonian 1/r monopole, while the leading angular correction is an equatorial enhancement and "
            "polar deficit fit by Lambda/Lambda0 = 1 + epsilon(r)(sin^2 theta - 2/3), with "
            "epsilon(r) approaching 0.75(a/r)^2. This supplies a concrete directional-lag seed for the "
            "next SFT gravity geometry document, but it does not yet derive the full metric, MOND, "
            "expansion, or jet channels."
        ),
        "next_gate": "GRAV_TRAJ_02 should connect this source kernel to V11.13 one-speed metric closure B=F^-1.",
        "v12_2_attachment": "V12.2 can attach as amplitude/root-scale normalization only after the geometry/source kernel is accepted.",
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def save_plots(fits: list[dict], profile_rows: list[dict]) -> list[str]:
    plots = []
    try:
        import matplotlib.pyplot as plt

        r = np.array([x["r_over_a"] for x in fits])
        eps = np.array([x["epsilon_fit"] for x in fits])
        pred = np.array([x["epsilon_pred_0p75_a2_over_r2"] for x in fits])
        plt.figure(figsize=(8,5))
        plt.loglog(r, eps, marker="o", label="fit epsilon")
        plt.loglog(r, pred, marker="o", label="0.75(a/r)^2 prediction")
        plt.xlabel("r/a")
        plt.ylabel("epsilon")
        plt.title("GRAV_TRAJ_01: fitted quadrupole strength")
        plt.legend()
        plt.tight_layout()
        p = OUT / "grav_traj_01_epsilon_scaling.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        plt.figure(figsize=(8,5))
        plt.semilogx(r, [x["equator_fractional_excess"] for x in fits], marker="o", label="equator excess")
        plt.semilogx(r, [x["pole_fractional_deficit"] for x in fits], marker="o", label="pole deficit")
        plt.axhline(0.0, linewidth=1, linestyle="--")
        plt.xlabel("r/a")
        plt.ylabel("fractional deviation from spherical mean")
        plt.title("GRAV_TRAJ_01: equatorial enhancement / polar deficit")
        plt.legend()
        plt.tight_layout()
        p = OUT / "grav_traj_01_directionality.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Angular profile for representative r/a=5 and 20.
        for rr in [5.0, 20.0]:
            rows = [x for x in profile_rows if abs(x["r_over_a"]-rr) < 1e-9]
            if not rows:
                continue
            theta_deg = [x["theta_deg"] for x in rows]
            exact = [x["lambda_over_lambda0"] for x in rows]
            model = [x["quadrupole_model_over_lambda0"] for x in rows]
            plt.figure(figsize=(8,5))
            plt.plot(theta_deg, exact, label="exact ring average")
            plt.plot(theta_deg, model, linestyle="--", label="monopole+quadrupole fit")
            plt.xlabel("theta degrees: 0=pole, 90=equator")
            plt.ylabel("Lambda / Lambda0")
            plt.title(f"GRAV_TRAJ_01: angular lag profile r/a={rr:g}")
            plt.legend()
            plt.tight_layout()
            p = OUT / f"grav_traj_01_angular_profile_r_over_a_{rr:g}.png"
            plt.savefig(p, dpi=160)
            plt.close()
            plots.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def angular_profile_rows(r: float, eps: float, a: float = 1.0, n_phase: int = 4096) -> list[dict]:
    theta = np.linspace(0.0, math.pi, 181)
    lam = ring_kernel(r, theta, a=a, n_phase=n_phase)
    # Use direct mean over uniform mu for lambda0.
    mu = np.linspace(-1.0, 1.0, 401)
    lam_mu = ring_kernel(r, np.arccos(mu), a=a, n_phase=n_phase)
    lam0 = np.trapz(lam_mu, mu)/2.0
    q = np.sin(theta)**2 - 2.0/3.0
    model = lam0 * (1.0 + eps*q)
    return [
        {
            "r_over_a": r/a,
            "theta_deg": float(t*180.0/math.pi),
            "lambda_over_lambda0": float(L/lam0),
            "quadrupole_model_over_lambda0": float(M/lam0),
            "q_sin2_minus_2thirds": float(qq),
        }
        for t, L, M, qq in zip(theta, lam, model, q)
    ]


def write_report(path: Path, fits: list[dict], summary: dict, stages: list[dict]) -> None:
    lines = []
    lines.append("# SFT GRAV_TRAJ_01: Single Helical Worldline Lag-Field Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{summary['verdict']}**\n\n")
    lines.append(summary["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(summary["claim_boundary"] + "\n\n")
    lines.append("## Fit summary\n\n")
    lines.append("| r/a | monopole error | epsilon fit | epsilon predicted | fit/pred | RMS residual | equator excess | pole deficit |\n")
    lines.append("|---:|---:|---:|---:|---:|---:|---:|---:|\n")
    for r in fits:
        lines.append(
            f"| {r['r_over_a']:.1f} | {r['monopole_fractional_error']:.3e} | "
            f"{r['epsilon_fit']:.3e} | {r['epsilon_pred_0p75_a2_over_r2']:.3e} | "
            f"{r['epsilon_fit_over_pred']:.5f} | {r['rms_fractional_residual_after_quadrupole']:.3e} | "
            f"{r['equator_fractional_excess']:.3e} | {r['pole_fractional_deficit']:.3e} |\n"
        )
    lines.append("\n## Level interpretation\n\n")
    lines.append("| Level | Name | Direction | Expansion | MOND | Status |\n")
    lines.append("|---:|---|---|---|---|---|\n")
    for s in stages:
        lines.append(f"| {s['level']} | {s['name']} | {s['direction']} | {s['expansion']} | {s['MOND']} | {s['status']} |\n")
    lines.append("\n## V12.2 attachment\n\n")
    lines.append(summary["v12_2_attachment"] + "\n\n")
    lines.append("## Next gate\n\n")
    lines.append(summary["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    a = 1.0
    r_values = [2.0, 3.0, 5.0, 10.0, 20.0, 50.0, 100.0]
    fits = [fit_quadrupole(r, a=a, n_mu=501, n_phase=4096) for r in r_values]

    multipoles = []
    for r in [3.0, 5.0, 10.0, 20.0, 50.0]:
        multipoles.extend(multipole_coefficients(r, a=a, n_mu=801, n_phase=4096, lmax=8))

    profiles = []
    fit_by_r = {round(f["r_over_a"], 10): f for f in fits}
    for r in [5.0, 20.0]:
        profiles.extend(angular_profile_rows(r, fit_by_r[round(r/a,10)]["epsilon_fit"], a=a, n_phase=4096))

    stages = stage_level_rows()
    summary = endpoint_summary(fits)

    write_csv(OUT/"grav_traj_01_quadrupole_fits.csv", fits)
    write_csv(OUT/"grav_traj_01_multipoles.csv", multipoles)
    write_csv(OUT/"grav_traj_01_angular_profiles.csv", profiles)
    write_csv(OUT/"grav_traj_01_level_status.csv", stages)
    write_csv(OUT/"grav_traj_01_verdict.csv", [summary])

    plots = save_plots(fits, profiles)
    write_report(OUT/"GRAV_TRAJ_01_one_helix_lag_field_report.md", fits, summary, stages)
    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_01",
        "purpose": "single one-speed helical/ring lag-field source audit",
        "claim_boundary": summary["claim_boundary"],
        "verdict": summary["verdict"],
        "files": [
            "grav_traj_01_quadrupole_fits.csv",
            "grav_traj_01_multipoles.csv",
            "grav_traj_01_angular_profiles.csv",
            "grav_traj_01_level_status.csv",
            "grav_traj_01_verdict.csv",
            "GRAV_TRAJ_01_one_helix_lag_field_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_01 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Test whether a time-averaged one-speed helical/ring source gives a Newtonian monopole plus directional quadrupole.")
    print("  This is a source-kernel seed only, not full gravity/MOND/expansion.")

    print("\nQuadrupole fit summary:")
    for f in fits:
        print(
            f"  r/a={f['r_over_a']:7.1f}  "
            f"monopole_err={f['monopole_fractional_error']:+.3e}  "
            f"eps_fit={f['epsilon_fit']:.6e}  "
            f"eps_pred={f['epsilon_pred_0p75_a2_over_r2']:.6e}  "
            f"fit/pred={f['epsilon_fit_over_pred']:.6f}  "
            f"eq_excess={f['equator_fractional_excess']:+.3e}  "
            f"pole_deficit={f['pole_fractional_deficit']:+.3e}  "
            f"rms_resid={f['rms_fractional_residual_after_quadrupole']:.3e}"
        )

    print("\nVerdict:")
    for k, v in summary.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_01_one_helix_lag_field_report.md'}")
    print(f"  fits csv: {OUT/'grav_traj_01_quadrupole_fits.csv'}")
    print(f"  multipoles csv: {OUT/'grav_traj_01_multipoles.csv'}")
    print(f"  profiles csv: {OUT/'grav_traj_01_angular_profiles.csv'}")
    print(f"  verdict csv: {OUT/'grav_traj_01_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
