#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_04:
Settlement Diffusion Near-Field / Far-Field Transition Audit

Purpose
-------
GRAV_TRAJ_01: one-speed helix/ring source gives Newtonian monopole + directional quadrupole.
GRAV_TRAJ_02: that source feeds V11.13 one-speed metric closure without breaking FB=1.
GRAV_TRAJ_03: matter and radiation are endpoints of one source rule rho+3p.

GRAV_TRAJ_04 asks the next disciplined question:

    What kind of settlement-transition law can connect near-field Newtonian
    gravity to a MOND-like galactic far-field WITHOUT simply "matching MOND"?

Core principle
--------------
SFT should be MOND-like, not MOND.

This means:
    - recover Newtonian behavior in the near field,
    - produce a MOND/RAR-like deep transition if the mechanism earns it,
    - recover BTFR-like mass scaling if the transition is galactic,
    - naturally allow environment/large-scale deviations,
    - avoid tuning directly to MOND or observed a0.

This script works in dimensionless units:
    G = 1
    a_S = 1

It does NOT use observed a0, SPARC, kSZ, or cosmological data.
The question is structural: which transition type has the right no-cheat scaling?

Candidate transition types
--------------------------
1. Newton only:
       g = g_N
   Control: no far-field transition.

2. Yukawa/linear-relaxation handoff:
       g = g_N exp(-r/L)(1+r/L)
   This is the direct static screened Green-function behavior of a simple
   relaxation-diffusion equation. It has a length transition, but not a
   MOND-like attraction tail.

3. Fixed-length dimensional handoff:
       g = g_N sqrt(1+(r/L)^2)
   Near field: g ~ g_N.
   Far field: g ~ GM/(L r), giving flat rotation for one mass, but
   v_flat^4 ∝ M^2 if L is universal. Therefore it fails BTFR.

4. Acceleration-triggered settlement handoff:
       r_t(M) = sqrt(GM/a_S)
       g = g_N sqrt(1+(r/r_t)^2)

   Near field: g ~ g_N.
   Far field:
       g ~ sqrt(GM a_S)/r
       v_flat^4 ∝ G M a_S

   This is MOND-like in the galactic limit, but it is not MOND itself:
   the kernel is a settlement handoff model and a_S is not fit here.

5. Environment-dependent acceleration handoff:
       a_eff = a_S * E
       r_t(M,E) = sqrt(GM/a_eff)

   This preserves the local structure while allowing non-MOND large-scale
   deviations from environment/settlement-density effects. This is only a
   future-channel diagnostic, not a fitted model.

Claim boundary
--------------
A pass means: the next gravity line should use an acceleration-triggered
settlement handoff, not a universal fixed length, if it wants a no-cheat
MOND-like galaxy limit with BTFR scaling.

A pass does NOT mean:
    - SFT derives a0,
    - SFT fits SPARC,
    - SFT explains kSZ,
    - SFT derives Friedmann expansion,
    - SFT has a completed far-field theory.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_04_OUTPUT")

G = 1.0
A_S = 1.0
L_FIXED = 1.0


# -----------------------------
# Model definitions
# -----------------------------

def g_newton(M, r):
    return G*M/(r*r)


def g_yukawa(M, r, L=L_FIXED):
    x = r/L
    return g_newton(M, r) * np.exp(-x) * (1.0 + x)


def g_fixed_length_handoff(M, r, L=L_FIXED):
    x = r/L
    return g_newton(M, r) * np.sqrt(1.0 + x*x)


def r_transition_acceleration(M, a_eff=A_S):
    return math.sqrt(G*M/a_eff)


def g_accel_handoff(M, r, a_eff=A_S):
    rt = math.sqrt(G*M/a_eff)
    x = r/rt
    return g_newton(M, r) * np.sqrt(1.0 + x*x)


def log_slope_r(func, M, r):
    eps = 1e-4
    r1, r2 = r*(1-eps), r*(1+eps)
    g1, g2 = func(M, r1), func(M, r2)
    return math.log(g2/g1)/math.log(r2/r1)


def fit_log_slope(x, y):
    lx = np.log(np.asarray(x, dtype=float))
    ly = np.log(np.asarray(y, dtype=float))
    coeff = np.polyfit(lx, ly, 1)
    return float(coeff[0]), float(coeff[1])


# -----------------------------
# Audits
# -----------------------------

def transition_checks():
    rows = []
    M = 1.0
    rt = r_transition_acceleration(M)
    # Use r in units of the relevant transition scale for each model.
    models = [
        ("newton_only", lambda M,r: g_newton(M,r), rt, "control: no far-field transition"),
        ("yukawa_linear_relaxation", lambda M,r: g_yukawa(M,r,L_FIXED), L_FIXED, "screened relaxation-diffusion Green function"),
        ("fixed_length_handoff", lambda M,r: g_fixed_length_handoff(M,r,L_FIXED), L_FIXED, "universal length handoff control"),
        ("acceleration_handoff", lambda M,r: g_accel_handoff(M,r,A_S), rt, "mass-dependent acceleration-triggered settlement handoff"),
    ]

    for name, func, scale, desc in models:
        near_r = 1e-3 * scale
        mid_r = 1.0 * scale
        far_r = 1e3 * scale
        gN_near = g_newton(M, near_r)
        gN_mid = g_newton(M, mid_r)
        gN_far = g_newton(M, far_r)
        g_near = func(M, near_r)
        g_mid = func(M, mid_r)
        g_far = func(M, far_r)
        far_slope = log_slope_r(func, M, far_r)
        near_slope = log_slope_r(func, M, near_r)
        rows.append({
            "model": name,
            "description": desc,
            "scale_used": scale,
            "near_r_over_scale": 1e-3,
            "near_g_over_newton": g_near/gN_near,
            "near_log_slope_dlogg_dlogr": near_slope,
            "mid_g_over_newton": g_mid/gN_mid,
            "far_r_over_scale": 1e3,
            "far_g_over_newton": g_far/gN_far if gN_far != 0 else float("nan"),
            "far_log_slope_dlogg_dlogr": far_slope,
            "newton_near_pass": abs(g_near/gN_near - 1.0) < 1e-3,
            "mond_like_far_slope_pass": abs(far_slope + 1.0) < 1e-2,
            "status": "TO_BE_CLASSIFIED",
        })

    for r in rows:
        if r["model"] == "acceleration_handoff":
            r["status"] = "PRIMARY_STRUCTURAL_CANDIDATE" if r["newton_near_pass"] and r["mond_like_far_slope_pass"] else "FAIL"
        elif r["model"] == "fixed_length_handoff":
            r["status"] = "CONTROL_PASSES_SINGLE_MASS_BUT_TEST_BTF_RELATION"
        elif r["model"] == "yukawa_linear_relaxation":
            r["status"] = "REJECT_AS_MOND_LIKE_ATTRACTION_TAIL_BUT_KEEP_AS_HANDOFF_CHANNEL"
        elif r["model"] == "newton_only":
            r["status"] = "CONTROL_NO_TRANSITION"
    return rows


def mass_scaling_rows():
    masses = np.logspace(-6, 6, 49)
    rows = []

    # Evaluate "flat" proxy v^2 = r g at far r=100*transition scale.
    for model in ["fixed_length_handoff", "acceleration_handoff"]:
        v4s = []
        Ms = []
        for M in masses:
            if model == "fixed_length_handoff":
                r = 100.0 * L_FIXED
                g = g_fixed_length_handoff(M, r, L_FIXED)
            else:
                rt = r_transition_acceleration(M, A_S)
                r = 100.0 * rt
                g = g_accel_handoff(M, r, A_S)
            v2 = r*g
            v4 = v2*v2
            rows.append({
                "model": model,
                "M": float(M),
                "r_eval": float(r),
                "g": float(g),
                "v2_proxy": float(v2),
                "v4_proxy": float(v4),
                "v4_over_M": float(v4/M),
                "expected_BTFR_v4_over_M": G*A_S if model == "acceleration_handoff" else None,
            })
            Ms.append(M)
            v4s.append(v4)

    # Attach model-level slopes in separate summary rows later.
    return rows


def mass_scaling_summary(rows):
    out = []
    for model in sorted(set(r["model"] for r in rows)):
        sub = [r for r in rows if r["model"] == model]
        slope, intercept = fit_log_slope([r["M"] for r in sub], [r["v4_proxy"] for r in sub])
        v4_over_M_vals = np.array([r["v4_over_M"] for r in sub], dtype=float)
        rel_spread = float(np.max(v4_over_M_vals)/np.min(v4_over_M_vals))
        btfr_pass = abs(slope - 1.0) < 1e-3
        out.append({
            "model": model,
            "log_slope_v4_vs_M": slope,
            "BTFR_target_slope": 1.0,
            "slope_error": slope - 1.0,
            "v4_over_M_min": float(np.min(v4_over_M_vals)),
            "v4_over_M_max": float(np.max(v4_over_M_vals)),
            "v4_over_M_spread_factor": rel_spread,
            "BTFR_scaling_pass": btfr_pass,
            "status": "PASS_BTFR_SCALING" if btfr_pass else "FAIL_BTFR_SCALING",
        })
    return out


def rar_grid_rows():
    """
    Scale-free RAR-like relation for acceleration handoff.
    Uses M=1 and samples x=r/r_t. Since gN=A_S/x^2 for M=1, this scans gN/A_S.
    """
    M = 1.0
    rt = r_transition_acceleration(M, A_S)
    rows = []
    for x in np.logspace(-3, 3, 241):
        r = x*rt
        gN = g_newton(M, r)
        g = g_accel_handoff(M, r, A_S)
        rows.append({
            "x_r_over_rt": float(x),
            "gN_over_aS": float(gN/A_S),
            "g_over_aS": float(g/A_S),
            "g_over_gN": float(g/gN),
            "deep_mond_proxy_sqrt_gN_aS": float(math.sqrt(gN*A_S)),
            "g_over_sqrt_gN_aS": float(g/math.sqrt(gN*A_S)),
            "near_newton_region": bool(gN/A_S > 100.0),
            "deep_transition_region": bool(gN/A_S < 0.01),
        })
    return rows


def rar_summary(rows):
    near = [r for r in rows if r["near_newton_region"]]
    deep = [r for r in rows if r["deep_transition_region"]]
    near_ratio = np.array([r["g_over_gN"] for r in near], dtype=float)
    deep_ratio = np.array([r["g_over_sqrt_gN_aS"] for r in deep], dtype=float)

    # Slopes: log g vs log gN.
    near_slope, _ = fit_log_slope([r["gN_over_aS"] for r in near], [r["g_over_aS"] for r in near])
    deep_slope, _ = fit_log_slope([r["gN_over_aS"] for r in deep], [r["g_over_aS"] for r in deep])

    return [{
        "model": "acceleration_handoff",
        "near_mean_g_over_gN": float(np.mean(near_ratio)),
        "near_max_abs_g_over_gN_minus_1": float(np.max(np.abs(near_ratio-1.0))),
        "near_log_slope_g_vs_gN": near_slope,
        "near_target_slope": 1.0,
        "deep_mean_g_over_sqrt_gN_aS": float(np.mean(deep_ratio)),
        "deep_max_abs_ratio_minus_1": float(np.max(np.abs(deep_ratio-1.0))),
        "deep_log_slope_g_vs_gN": deep_slope,
        "deep_target_slope": 0.5,
        "RAR_like_pass": bool(
            abs(near_slope-1.0) < 1e-2 and
            abs(deep_slope-0.5) < 1e-2 and
            abs(np.mean(deep_ratio)-1.0) < 1e-2
        ),
    }]


def environment_rows():
    """
    Diagnostic only: environment changes effective settlement acceleration.
    This is how SFT can be MOND-like but not MOND. No observational data.
    """
    M = 1.0
    env_factors = [0.5, 0.75, 1.0, 1.25, 2.0]
    rows = []
    for E in env_factors:
        a_eff = A_S * E
        rt = r_transition_acceleration(M, a_eff)
        r = 100.0 * rt
        gN = g_newton(M, r)
        g = g_accel_handoff(M, r, a_eff)
        v2 = r*g
        v4 = v2*v2
        rows.append({
            "environment_factor_E": E,
            "a_eff_over_aS": E,
            "transition_radius": rt,
            "far_eval_r": r,
            "gN_over_a_eff": gN/a_eff,
            "g_over_sqrt_gN_a_eff": g/math.sqrt(gN*a_eff),
            "v4_over_M": v4/M,
            "expected_v4_over_M": G*a_eff,
            "deviation_from_universal_MOND_aS": v4/(M*G*A_S),
            "interpretation": "diagnostic: environment can shift amplitude without changing local kernel",
        })
    return rows


def control_rows():
    trans = transition_checks()
    mass_sum = mass_scaling_summary(mass_scaling_rows())
    rar_sum = rar_summary(rar_grid_rows())[0]
    rows = []

    for r in trans:
        rows.append({
            "control_or_candidate": r["model"],
            "test": "near_field_and_far_slope",
            "pass": r["newton_near_pass"] and r["mond_like_far_slope_pass"],
            "status": r["status"],
            "reason": (
                "primary if acceleration handoff; fixed length needs BTFR test; yukawa is screened tail not MOND-like; Newton has no transition"
            ),
        })

    for r in mass_sum:
        rows.append({
            "control_or_candidate": r["model"],
            "test": "BTFR_mass_scaling_v4_vs_M",
            "pass": r["BTFR_scaling_pass"],
            "status": r["status"],
            "reason": "BTFR-like scaling requires v4 proportional to M, not M^2",
        })

    rows.append({
        "control_or_candidate": "acceleration_handoff",
        "test": "RAR_like_near_deep_slopes",
        "pass": rar_sum["RAR_like_pass"],
        "status": "PASS_RAR_LIKE_STRUCTURE" if rar_sum["RAR_like_pass"] else "FAIL",
        "reason": "near slope should be 1 and deep slope should be 1/2 in scale-free units",
    })

    rows.append({
        "control_or_candidate": "observed_a0_fit",
        "test": "no_cheat_boundary",
        "pass": False,
        "status": "FORBIDDEN_NOT_USED",
        "reason": "GRAV_TRAJ_04 uses dimensionless a_S=1 and does not fit observed MOND a0",
    })

    return rows


def verdict_row(trans, mass_sum, rar_sum, env):
    accel = next(r for r in trans if r["model"] == "acceleration_handoff")
    fixed = next(r for r in mass_sum if r["model"] == "fixed_length_handoff")
    accel_mass = next(r for r in mass_sum if r["model"] == "acceleration_handoff")
    rar = rar_sum[0]

    primary_pass = (
        accel["newton_near_pass"] and
        accel["mond_like_far_slope_pass"] and
        accel_mass["BTFR_scaling_pass"] and
        rar["RAR_like_pass"] and
        not fixed["BTFR_scaling_pass"]
    )

    verdict = (
        "ACCELERATION_TRIGGERED_SETTLEMENT_HANDOFF_SELECTED_AS_MOND_LIKE_NOT_MOND_STRUCTURE"
        if primary_pass else
        "SETTLEMENT_TRANSITION_STRUCTURE_REQUIRES_REVISION"
    )

    return {
        "verdict": verdict,
        "claim_boundary": "scale-free transition-structure audit only; not a derivation of a0, SPARC fit, kSZ prediction, expansion, nonlinear GR, or G",
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_kSZ_data": False,
        "newton_near_field_pass": accel["newton_near_pass"],
        "far_field_1_over_r_pass": accel["mond_like_far_slope_pass"],
        "BTFR_scaling_pass": accel_mass["BTFR_scaling_pass"],
        "fixed_length_BTFR_rejected": not fixed["BTFR_scaling_pass"],
        "RAR_like_structure_pass": rar["RAR_like_pass"],
        "environment_deviation_channel_present": True,
        "main_result": (
            "A universal fixed settlement length can mimic a flat curve for one mass but fails BTFR scaling; "
            "an acceleration-triggered settlement handoff recovers near-field Newtonian behavior, far-field 1/r acceleration, "
            "RAR-like slopes, and v_flat^4 proportional to M in scale-free units."
        ),
        "paper_safe_sentence": (
            "GRAV_TRAJ_04 audits the settlement near-field/far-field transition without fitting MOND or observed a0. "
            "A fixed-length handoff can produce a flat far-field curve for one mass, but fails the baryonic Tully-Fisher scaling because "
            "it gives v_flat^4 proportional to M^2. An acceleration-triggered settlement handoff with r_t=sqrt(GM/a_S) recovers Newtonian "
            "behavior at r<<r_t, gives a 1/r far-field acceleration at r>>r_t, yields the scale-free RAR-like relation "
            "g≈sqrt(g_N a_S) in the deep regime, and gives v_flat^4 proportional to G M a_S. This selects the structural form of the "
            "SFT transition as MOND-like but not MOND: a_S is not derived or fitted here, and environment-dependent settlement factors can "
            "produce natural deviations from universal MOND behavior at larger scales."
        ),
        "next_gate": (
            "GRAV_TRAJ_05 should derive or constrain the settlement acceleration scale a_S from V11.1B/V12.1 quantities, "
            "or test an environment-dependent settlement factor without tuning to observed MOND."
        ),
    }


def write_csv(path: Path, rows: list[dict]):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def save_plots(trans, mass_rows, rar_rows, env_rows):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # RAR-like plot.
        plt.figure(figsize=(8,5))
        plt.loglog([r["gN_over_aS"] for r in rar_rows], [r["g_over_aS"] for r in rar_rows], label="acceleration handoff")
        gN = np.logspace(-6, 6, 200)
        plt.loglog(gN, gN, linestyle="--", label="Newton g=gN")
        plt.loglog(gN, np.sqrt(gN), linestyle=":", label="deep sqrt(gN)")
        plt.xlabel("gN / aS")
        plt.ylabel("g / aS")
        plt.title("GRAV_TRAJ_04: scale-free RAR-like transition")
        plt.legend()
        plt.tight_layout()
        p = OUT/"grav_traj_04_rar_like_transition.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Mass scaling.
        plt.figure(figsize=(8,5))
        for model in sorted(set(r["model"] for r in mass_rows)):
            sub = [r for r in mass_rows if r["model"] == model]
            plt.loglog([r["M"] for r in sub], [r["v4_proxy"] for r in sub], marker=".", label=model)
        plt.xlabel("M")
        plt.ylabel("v_flat^4 proxy")
        plt.title("GRAV_TRAJ_04: BTFR mass-scaling audit")
        plt.legend()
        plt.tight_layout()
        p = OUT/"grav_traj_04_mass_scaling.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Environment deviations.
        plt.figure(figsize=(8,5))
        plt.scatter([r["environment_factor_E"] for r in env_rows], [r["deviation_from_universal_MOND_aS"] for r in env_rows])
        plt.xlabel("environment factor E = a_eff/aS")
        plt.ylabel("v4/M relative to universal aS")
        plt.title("GRAV_TRAJ_04: environment deviation channel")
        plt.tight_layout()
        p = OUT/"grav_traj_04_environment_deviation.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Transition slopes.
        plt.figure(figsize=(8,5))
        labels = [r["model"] for r in trans]
        slopes = [r["far_log_slope_dlogg_dlogr"] for r in trans]
        x = np.arange(len(labels))
        plt.scatter(x, slopes)
        plt.axhline(-1.0, linestyle="--", linewidth=1)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("far-field d log g / d log r")
        plt.title("GRAV_TRAJ_04: far-field slope")
        plt.tight_layout()
        p = OUT/"grav_traj_04_far_field_slope.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, trans, mass_sum, rar_sum, env, controls, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_04: Settlement Near-Field / Far-Field Transition Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## Transition checks\n\n")
    lines.append("| Model | near g/gN | far slope | far slope pass | status |\n")
    lines.append("|---|---:|---:|---|---|\n")
    for r in trans:
        lines.append(f"| {r['model']} | {r['near_g_over_newton']:.6f} | {r['far_log_slope_dlogg_dlogr']:.6f} | {r['mond_like_far_slope_pass']} | {r['status']} |\n")

    lines.append("\n## Mass scaling\n\n")
    lines.append("| Model | slope log(v4) vs log(M) | BTFR pass | spread v4/M | status |\n")
    lines.append("|---|---:|---|---:|---|\n")
    for r in mass_sum:
        lines.append(f"| {r['model']} | {r['log_slope_v4_vs_M']:.6f} | {r['BTFR_scaling_pass']} | {r['v4_over_M_spread_factor']:.3e} | {r['status']} |\n")

    r = rar_sum[0]
    lines.append("\n## RAR-like scale-free check\n\n")
    lines.append(f"- Near slope g vs gN: {r['near_log_slope_g_vs_gN']:.6f}\n")
    lines.append(f"- Deep slope g vs gN: {r['deep_log_slope_g_vs_gN']:.6f}\n")
    lines.append(f"- Deep mean g/sqrt(gN aS): {r['deep_mean_g_over_sqrt_gN_aS']:.6f}\n")
    lines.append(f"- Pass: {r['RAR_like_pass']}\n\n")

    lines.append("## Environment channel\n\n")
    lines.append("| E=a_eff/aS | transition radius | v4/M relative to universal aS |\n")
    lines.append("|---:|---:|---:|\n")
    for e in env:
        lines.append(f"| {e['environment_factor_E']:.3f} | {e['transition_radius']:.6f} | {e['deviation_from_universal_MOND_aS']:.6f} |\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    trans = transition_checks()
    mass_rows = mass_scaling_rows()
    mass_sum = mass_scaling_summary(mass_rows)
    rar_rows = rar_grid_rows()
    rar_sum = rar_summary(rar_rows)
    env = environment_rows()
    controls = control_rows()
    verdict = verdict_row(trans, mass_sum, rar_sum, env)

    write_csv(OUT/"grav_traj_04_transition_checks.csv", trans)
    write_csv(OUT/"grav_traj_04_mass_scaling_rows.csv", mass_rows)
    write_csv(OUT/"grav_traj_04_mass_scaling_summary.csv", mass_sum)
    write_csv(OUT/"grav_traj_04_rar_grid.csv", rar_rows)
    write_csv(OUT/"grav_traj_04_rar_summary.csv", rar_sum)
    write_csv(OUT/"grav_traj_04_environment_deviation.csv", env)
    write_csv(OUT/"grav_traj_04_controls.csv", controls)
    write_csv(OUT/"grav_traj_04_verdict.csv", [verdict])

    plots = save_plots(trans, mass_rows, rar_rows, env)
    write_report(OUT/"GRAV_TRAJ_04_settlement_transition_report.md", trans, mass_sum, rar_sum, env, controls, verdict)

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_04",
        "purpose": "settlement diffusion near-field/far-field transition structure audit",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "files": [
            "grav_traj_04_transition_checks.csv",
            "grav_traj_04_mass_scaling_rows.csv",
            "grav_traj_04_mass_scaling_summary.csv",
            "grav_traj_04_rar_grid.csv",
            "grav_traj_04_rar_summary.csv",
            "grav_traj_04_environment_deviation.csv",
            "grav_traj_04_controls.csv",
            "grav_traj_04_verdict.csv",
            "GRAV_TRAJ_04_settlement_transition_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_04 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Test settlement near-field/far-field transition structure without fitting MOND or observed a0.")
    print("  Select between fixed-length handoff, screened diffusion, and acceleration-triggered settlement handoff.")

    print("\nTransition checks:")
    for r in trans:
        print(
            f"  {r['model']:30s}  "
            f"near g/gN={r['near_g_over_newton']:.8f}  "
            f"near slope={r['near_log_slope_dlogg_dlogr']:.6f}  "
            f"far g/gN={r['far_g_over_newton']:.6e}  "
            f"far slope={r['far_log_slope_dlogg_dlogr']:.6f}  "
            f"{r['status']}"
        )

    print("\nMass scaling summary:")
    for r in mass_sum:
        print(
            f"  {r['model']:30s}  "
            f"slope log(v4)-log(M)={r['log_slope_v4_vs_M']:.6f}  "
            f"target=1.000000  "
            f"spread(v4/M)={r['v4_over_M_spread_factor']:.3e}  "
            f"{r['status']}"
        )

    print("\nRAR-like summary:")
    for r in rar_sum:
        print(
            f"  near slope={r['near_log_slope_g_vs_gN']:.6f} target=1  "
            f"deep slope={r['deep_log_slope_g_vs_gN']:.6f} target=0.5  "
            f"deep mean g/sqrt(gN aS)={r['deep_mean_g_over_sqrt_gN_aS']:.6f}  "
            f"PASS={r['RAR_like_pass']}"
        )

    print("\nEnvironment deviation channel:")
    for r in env:
        print(
            f"  E={r['environment_factor_E']:.3f}  "
            f"a_eff/aS={r['a_eff_over_aS']:.3f}  "
            f"r_t={r['transition_radius']:.6f}  "
            f"v4/M relative universal={r['deviation_from_universal_MOND_aS']:.6f}"
        )

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_04_settlement_transition_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_04_verdict.csv'}")
    print(f"  transition csv: {OUT/'grav_traj_04_transition_checks.csv'}")
    print(f"  mass summary csv: {OUT/'grav_traj_04_mass_scaling_summary.csv'}")
    print(f"  rar summary csv: {OUT/'grav_traj_04_rar_summary.csv'}")
    print(f"  environment csv: {OUT/'grav_traj_04_environment_deviation.csv'}")
    print(f"  controls csv: {OUT/'grav_traj_04_controls.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
