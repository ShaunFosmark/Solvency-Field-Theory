#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_03:
Matter/Radiation One-Speed Source Continuity Audit

Tests whether massive matter and radiation are endpoints of one SFT source rule:
    rho_ops ∝ rho + 3p = rho(1 + 3w)

For isotropic one-speed budget:
    beta_space^2 = 3w
    source_factor = 1 + beta_space^2 = 1 + 3w

Cold matter: w=0 -> factor 1.
Radiation: w=1/3 -> factor 2.

Also tests that anisotropy contributes a traceless directional tensor Q_ij,
while the scalar trace source remains rho + Tr(P).

Claim boundary: source-continuity audit only; not MOND, expansion, kSZ,
nonlinear GR, frame dragging, jets, or G derivation.
"""

from __future__ import annotations
import csv, json, math
from pathlib import Path
import numpy as np

OUT = Path("SFT_GRAV_TRAJ_03_OUTPUT")


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def metric_closure(phi, alpha=1.0):
    phi = np.asarray(phi, dtype=float)
    F = np.exp(-phi)
    B = np.exp(alpha * phi)
    return F, B, -F * F, B * B


def eos_rows():
    cases = [
        ("cold_matter_rest", 0.0, "massive rest matter / internal phase circulation endpoint"),
        ("warm_matter_low_dispersion", 1.0/300.0, "small spatial velocity dispersion"),
        ("hot_matter_intermediate", 1.0/9.0, "intermediate relativistic toy"),
        ("ultrarelativistic_transition", 0.25, "approaching radiation-like source"),
        ("radiation_photon_gas", 1.0/3.0, "null/spatial one-speed endpoint"),
    ]
    rows = []
    for name, w, desc in cases:
        beta2 = 3.0 * w
        f1 = 1.0 + 3.0 * w
        f2 = 1.0 + beta2
        rows.append({
            "case": name,
            "description": desc,
            "w_p_over_rho": w,
            "beta_space_squared_isotropic": beta2,
            "beta_phase_squared": 1.0 - min(beta2, 1.0),
            "source_factor_1_plus_3w": f1,
            "source_factor_1_plus_beta2": f2,
            "factor_difference": f1 - f2,
            "endpoint": "matter" if abs(w) < 1e-15 else ("radiation" if abs(w-1.0/3.0) < 1e-15 else "intermediate"),
            "status": "PASS_CONTINUITY" if abs(f1-f2) < 1e-14 and 0.0 <= beta2 <= 1.0 else "FAIL",
        })
    return rows


def continuous_grid(n=101):
    rows = []
    for w in np.linspace(0.0, 1.0/3.0, n):
        beta2 = 3.0 * float(w)
        rows.append({
            "w": float(w),
            "beta_space_squared": beta2,
            "source_factor": 1.0 + beta2,
            "d_source_factor_dw": 3.0,
            "continuity_status": "PASS",
        })
    return rows


def unit_sphere_dirs(n_theta=41, n_phi=82):
    dirs, weights = [], []
    for i in range(n_theta):
        th = math.pi * (i + 0.5) / n_theta
        for j in range(n_phi):
            ph = 2.0 * math.pi * (j + 0.5) / n_phi
            dirs.append([math.sin(th)*math.cos(ph), math.sin(th)*math.sin(ph), math.cos(th)])
            weights.append(math.sin(th))
    return np.array(dirs, dtype=float), np.array(weights, dtype=float)


def tensor_average(vecs, weights=None, beta2=1.0):
    vecs = np.asarray(vecs, dtype=float)
    if weights is None:
        weights = np.ones(len(vecs)) / len(vecs)
    else:
        weights = np.asarray(weights, dtype=float)
        weights = weights / np.sum(weights)
    T = np.zeros((3,3))
    for v, w in zip(vecs, weights):
        v = v / np.linalg.norm(v)
        T += w * beta2 * np.outer(v, v)
    return T


def orientation_rows():
    I = np.eye(3)
    iso_dirs, iso_w = unit_sphere_dirs()

    disk_dirs = []
    for j in range(180):
        ph = 2.0 * math.pi * (j + 0.5) / 180
        disk_dirs.append([math.cos(ph), math.sin(ph), 0.0])
    disk_dirs = np.array(disk_dirs, dtype=float)

    cases = [
        ("isotropic_radiation", iso_dirs, iso_w, 1.0, "photon gas: trace source 2, no preferred direction"),
        ("single_photon_beam_z", np.array([[0,0,1.0]]), np.array([1.0]), 1.0, "null beam: trace factor 2, strong anisotropic Q"),
        ("opposed_beams_z", np.array([[0,0,1.0],[0,0,-1.0]]), np.array([0.5,0.5]), 1.0, "two-beam axis: trace factor 2, same quadrupole"),
        ("disk_plane_spatial_motion", disk_dirs, np.ones(len(disk_dirs)), 1.0, "spatial budget confined to disk plane"),
        ("isotropic_warm_matter_beta2_0p1", iso_dirs, iso_w, 0.1, "intermediate isotropic spatial budget"),
    ]

    rows = []
    for name, vecs, weights, beta2, desc in cases:
        T = tensor_average(vecs, weights, beta2=beta2)
        tr = float(np.trace(T))
        Q = T - (tr/3.0)*I
        eig = np.linalg.eigvalsh(Q)
        qnorm = float(np.sqrt(np.sum(Q*Q)))
        rows.append({
            "case": name,
            "description": desc,
            "beta_space_squared_trace": tr,
            "source_factor_1_plus_trace": 1.0 + tr,
            "Q_xx": float(Q[0,0]), "Q_yy": float(Q[1,1]), "Q_zz": float(Q[2,2]),
            "Q_xy": float(Q[0,1]), "Q_xz": float(Q[0,2]), "Q_yz": float(Q[1,2]),
            "Q_trace": float(np.trace(Q)),
            "Q_frobenius_norm": qnorm,
            "Q_eigen_min": float(eig[0]), "Q_eigen_mid": float(eig[1]), "Q_eigen_max": float(eig[2]),
            "trace_source_status": "PASS_TRACE_SOURCE",
            "directional_status": "ISOTROPIC_NO_Q" if qnorm < 1e-3 else "ANISOTROPIC_DIRECTIONAL_Q",
        })
    return rows


def metric_rows():
    rows = []
    base_phi = 1e-6
    for r in eos_rows():
        fac = r["source_factor_1_plus_3w"]
        phi = base_phi * fac
        F, B, gtt, grr = metric_closure([phi], alpha=1.0)
        rows.append({
            "case": r["case"],
            "source_factor": fac,
            "phi_scaled": phi,
            "F": float(F[0]),
            "B": float(B[0]),
            "F_times_B_minus_1": float(F[0]*B[0] - 1.0),
            "g_tt": float(gtt[0]),
            "g_rr": float(grr[0]),
            "gamma_marker": 1.0,
            "beta_marker": 1.0,
            "closure_status": "PASS_FB_EQUALS_1",
        })
    return rows


def control_rows():
    rows = []
    for r in eos_rows():
        w = r["w_p_over_rho"]
        correct = 1.0 + 3.0*w
        controls = [
            ("mass_only_source", 1.0, "fails radiation 2x"),
            ("pressure_weak_1_plus_w", 1.0 + w, "underweights radiation as 4/3 not 2"),
            ("arbitrary_universal_1p5", 1.5, "arbitrary boost, no endpoint logic"),
            ("step_if_pressure_nonzero", 2.0 if w > 0 else 1.0, "step function, not continuous"),
        ]
        for name, val, reason in controls:
            rows.append({
                "case": r["case"],
                "control_rule": name,
                "control_source_factor": val,
                "correct_source_factor": correct,
                "factor_error_vs_correct": val/correct if correct else float("nan"),
                "reason_rejected": reason,
                "status": "CONTROL_ONLY_REJECTED" if abs(val-correct) > 1e-12 else "ACCIDENTAL_ENDPOINT_MATCH",
            })
    return rows


def verdict(eos, orient, metric, controls):
    matter = next(r for r in eos if r["case"] == "cold_matter_rest")
    rad = next(r for r in eos if r["case"] == "radiation_photon_gas")
    endpoints = abs(matter["source_factor_1_plus_3w"]-1.0) < 1e-14 and abs(rad["source_factor_1_plus_3w"]-2.0) < 1e-14
    continuity = all(r["status"] == "PASS_CONTINUITY" for r in eos)
    trace_q = all(abs(r["Q_trace"]) < 1e-12 for r in orient)
    isotropic_zero = next(r for r in orient if r["case"] == "isotropic_radiation")["Q_frobenius_norm"] < 1e-3
    anis = [r for r in orient if ("beam" in r["case"] or "disk" in r["case"])]
    anis_pass = all(r["Q_frobenius_norm"] > 0.1 for r in anis)
    closure = all(abs(r["F_times_B_minus_1"]) < 1e-14 for r in metric)
    mass_only_rejected = any(r["control_rule"] == "mass_only_source" and r["case"] == "radiation_photon_gas" and r["status"] == "CONTROL_ONLY_REJECTED" for r in controls)

    ok = endpoints and continuity and trace_q and isotropic_zero and anis_pass and closure and mass_only_rejected
    return {
        "verdict": "MATTER_RADIATION_ONE_SPEED_SOURCE_CONTINUITY_PASSES" if ok else "MATTER_RADIATION_SOURCE_CONTINUITY_REQUIRES_REVISION",
        "claim_boundary": "source-continuity audit only; not MOND, expansion, kSZ, nonlinear GR, frame dragging, jets, or G derivation",
        "matter_endpoint_factor": matter["source_factor_1_plus_3w"],
        "radiation_endpoint_factor": rad["source_factor_1_plus_3w"],
        "endpoints_pass": endpoints,
        "continuity_pass": continuity,
        "traceless_Q_pass": trace_q,
        "anisotropic_directional_Q_pass": anis_pass,
        "isotropic_radiation_Q_zero_pass": isotropic_zero,
        "metric_closure_amplitude_pass": closure,
        "controls_rejected": mass_only_rejected,
        "main_result": "rho+3p equals one-speed source factor rho*(1+<beta_space^2>) for isotropic matter-radiation continuum",
        "paper_safe_sentence": "GRAV_TRAJ_03 audits source continuity between massive matter and radiation. Writing the isotropic spatial one-speed budget as b=<beta_space^2>=3p/rho gives a single source factor 1+b=1+3p/rho. Cold matter has b=0 and source factor 1, while radiation has b=1 and source factor 2. Anisotropic orientation distributions preserve the same trace source rho+Tr(P) while generating a traceless directional tensor Q_ij, so morphology can affect directional lag without changing the scalar trace rule. Scaling the metric potential by this source factor leaves the V11.13 one-speed closure FB=1 intact. This supports continuity among V11.5 one-speed motion, V11.11 rho+3p operation density, and GRAV_TRAJ_01/02 source-to-metric logic, while not yet deriving the settlement-diffusion far-field transition.",
        "next_gate": "GRAV_TRAJ_04 should test settlement diffusion near-field/far-field transition: MOND-like, not MOND, with no tuning.",
    }


def save_plots(eos, orient, metric):
    plots = []
    try:
        import matplotlib.pyplot as plt
        grid = continuous_grid()
        plt.figure(figsize=(8,5))
        plt.plot([r["w"] for r in grid], [r["source_factor"] for r in grid])
        plt.scatter([r["w_p_over_rho"] for r in eos], [r["source_factor_1_plus_3w"] for r in eos])
        plt.xlabel("w = p/rho"); plt.ylabel("source factor = 1 + 3w")
        plt.title("GRAV_TRAJ_03: matter-radiation source continuity")
        plt.tight_layout()
        p = OUT/"grav_traj_03_source_factor_vs_w.png"; plt.savefig(p, dpi=160); plt.close(); plots.append(str(p))

        plt.figure(figsize=(9,5))
        labels = [r["case"] for r in orient]; vals = [r["Q_frobenius_norm"] for r in orient]
        x = np.arange(len(labels)); plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("||Q||_F"); plt.title("GRAV_TRAJ_03: traceless directional source strength")
        plt.tight_layout()
        p = OUT/"grav_traj_03_directional_Q_norm.png"; plt.savefig(p, dpi=160); plt.close(); plots.append(str(p))

        plt.figure(figsize=(8,5))
        labels = [r["case"] for r in metric]; vals = [abs(r["F_times_B_minus_1"]) for r in metric]
        x = np.arange(len(labels)); plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("|FB-1|"); plt.title("GRAV_TRAJ_03: metric closure under source amplitude changes")
        plt.tight_layout()
        p = OUT/"grav_traj_03_metric_closure_amplitude.png"; plt.savefig(p, dpi=160); plt.close(); plots.append(str(p))
    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def report(path, eos, orient, metric, v):
    lines = ["# SFT GRAV_TRAJ_03: Matter/Radiation One-Speed Source Continuity Audit\n\n"]
    lines.append("## Verdict\n\n**" + v["verdict"] + "**\n\n")
    lines.append(v["paper_safe_sentence"] + "\n\n")
    lines.append("## EOS source continuity\n\n| Case | w | beta2 | factor | status |\n|---|---:|---:|---:|---|\n")
    for r in eos:
        lines.append(f"| {r['case']} | {r['w_p_over_rho']:.6f} | {r['beta_space_squared_isotropic']:.6f} | {r['source_factor_1_plus_3w']:.6f} | {r['status']} |\n")
    lines.append("\n## Orientation tensor\n\n| Case | source factor | Q norm | Q trace | status |\n|---|---:|---:|---:|---|\n")
    for r in orient:
        lines.append(f"| {r['case']} | {r['source_factor_1_plus_trace']:.6f} | {r['Q_frobenius_norm']:.6e} | {r['Q_trace']:.3e} | {r['directional_status']} |\n")
    lines.append("\n## Metric amplitude closure\n\n| Case | factor | phi | FB-1 |\n|---|---:|---:|---:|\n")
    for r in metric:
        lines.append(f"| {r['case']} | {r['source_factor']:.6f} | {r['phi_scaled']:.6e} | {r['F_times_B_minus_1']:.3e} |\n")
    lines.append("\n## Next gate\n\n" + v["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    eos = eos_rows()
    grid = continuous_grid()
    orient = orientation_rows()
    metric = metric_rows()
    controls = control_rows()
    v = verdict(eos, orient, metric, controls)

    write_csv(OUT/"grav_traj_03_eos_source_continuity.csv", eos)
    write_csv(OUT/"grav_traj_03_continuous_w_grid.csv", grid)
    write_csv(OUT/"grav_traj_03_orientation_tensor_audit.csv", orient)
    write_csv(OUT/"grav_traj_03_metric_amplitude_closure.csv", metric)
    write_csv(OUT/"grav_traj_03_controls.csv", controls)
    write_csv(OUT/"grav_traj_03_verdict.csv", [v])
    plots = save_plots(eos, orient, metric)
    report(OUT/"GRAV_TRAJ_03_matter_radiation_source_continuity_report.md", eos, orient, metric, v)

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_03",
        "verdict": v["verdict"],
        "claim_boundary": v["claim_boundary"],
        "files": [
            "grav_traj_03_eos_source_continuity.csv",
            "grav_traj_03_orientation_tensor_audit.csv",
            "grav_traj_03_metric_amplitude_closure.csv",
            "grav_traj_03_controls.csv",
            "grav_traj_03_verdict.csv",
            "GRAV_TRAJ_03_matter_radiation_source_continuity_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_03 RESULTS")
    print("========================")
    print("\nEquation-of-state source continuity:")
    for r in eos:
        print(f"  {r['case']:34s}  w={r['w_p_over_rho']:.6f}  beta2={r['beta_space_squared_isotropic']:.6f}  factor={r['source_factor_1_plus_3w']:.6f}  diff={r['factor_difference']:+.3e}  {r['status']}")
    print("\nOrientation tensor audit:")
    for r in orient:
        print(f"  {r['case']:34s}  trace_beta2={r['beta_space_squared_trace']:.6f}  source_factor={r['source_factor_1_plus_trace']:.6f}  Q_norm={r['Q_frobenius_norm']:.6e}  Q_trace={r['Q_trace']:+.3e}  {r['directional_status']}")
    print("\nMetric amplitude closure:")
    for r in metric:
        print(f"  {r['case']:34s}  source_factor={r['source_factor']:.6f}  phi={r['phi_scaled']:.6e}  FB-1={r['F_times_B_minus_1']:+.3e}  {r['closure_status']}")
    print("\nVerdict:")
    for k, val in v.items():
        print(f"  {k}: {val}")
    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_03_matter_radiation_source_continuity_report.md'}")
    print(f"  eos csv: {OUT/'grav_traj_03_eos_source_continuity.csv'}")
    print(f"  orientation csv: {OUT/'grav_traj_03_orientation_tensor_audit.csv'}")
    print(f"  metric closure csv: {OUT/'grav_traj_03_metric_amplitude_closure.csv'}")
    print(f"  controls csv: {OUT/'grav_traj_03_controls.csv'}")
    print(f"  verdict csv: {OUT/'grav_traj_03_verdict.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
