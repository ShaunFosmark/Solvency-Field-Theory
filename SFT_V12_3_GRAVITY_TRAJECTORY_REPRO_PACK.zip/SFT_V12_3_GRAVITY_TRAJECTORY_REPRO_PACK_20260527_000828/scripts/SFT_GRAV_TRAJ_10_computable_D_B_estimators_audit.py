#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_10:
Computable D and B Estimator Audit

Purpose
-------
GRAV_TRAJ_09 selected the structural environment factor

    E = sqrt(D B)

where

    D = rho_set / rho_bar
    B = C_boundary / C_bar

but left D and B as placeholders.

GRAV_TRAJ_10 freezes a computable synthetic graph/field rule for D and B
before any observational comparison.

This gate does NOT use SPARC, RAR, galaxy data, cluster data, kSZ data,
or observed a0.
It does NOT claim that the synthetic environments are real galaxies.
It does NOT claim that D and B are final observational estimators.

It tests whether D and B can be computed from pre-declared settlement
field and graph rules without residual fitting.

Frozen estimator definitions
----------------------------
Synthetic settlement graph:
    Nodes i carry settlement demand weight w_i and position x_i.

Settlement density field:
    rho_set(x) = sum_i w_i K(|x-x_i|; ell_D)
    K is a normalized positive Gaussian kernel.

D estimator:
    D(x) = rho_set(x) / <rho_set>_background

Boundary connectivity graph:
    A weighted graph has edge weights

        A_ij = sqrt(w_i w_j) exp(-|x_i-x_j|^2 / (2 ell_B^2))

    across allowed synthetic connectivity rules.

For a region S around probe point x, boundary connectivity is the cut
conductance from S to its complement, normalized by region size:

        C_boundary(S) = sum_{i in S, j not in S} A_ij / |S|

B estimator:
    B(S) = C_boundary(S) / <C_boundary>_background.

Environment:
    E = sqrt(D B).

Why this audit exists
---------------------
The point is not to match any real dataset. The point is to freeze a
computable, non-targeted D/B dictionary:
    - D comes from smoothed settlement density.
    - B comes from graph boundary conductance.
    - E follows from GRAV_TRAJ_09.
    - No residuals or observed accelerations are used.

Claim boundary
--------------
A pass means:
    D and B can be computed from a frozen synthetic field/graph rule and
    reproduce the expected qualitative environment classes before data.

A pass does NOT mean:
    D and B are final physical observables,
    SFT fits galaxy rotation curves,
    SFT solves clusters,
    SFT predicts kSZ,
    or SFT completes far-field gravity.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_10_OUTPUT")

# Reproducible synthetic audit only.
RNG_SEED = 12010
RNG = np.random.default_rng(RNG_SEED)

# Synthetic domain.
BOX_SIZE = 1.0
N_BACKGROUND = 240
N_PROBE_GRID = 19

# Frozen estimator scales.
ELL_D = 0.10
ELL_B = 0.16
REGION_RADIUS = 0.18

# Numerical stability.
EPS = 1e-30


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def gaussian_kernel_2d(r2: np.ndarray, ell: float) -> np.ndarray:
    # Normalization cancels in D ratios, but keep it explicit.
    return np.exp(-0.5 * r2/(ell*ell)) / (2.0 * math.pi * ell * ell)


def pairwise_r2(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    d = A[:, None, :] - B[None, :, :]
    return np.sum(d*d, axis=2)


def make_probe_grid(n: int = N_PROBE_GRID) -> np.ndarray:
    xs = np.linspace(0.08, 0.92, n)
    ys = np.linspace(0.08, 0.92, n)
    return np.array([(x, y) for x in xs for y in ys], dtype=float)


PROBES = make_probe_grid()


def base_uniform_nodes(n=N_BACKGROUND, weight=1.0):
    pos = RNG.uniform(0.0, BOX_SIZE, size=(n, 2))
    weights = np.full(n, weight, dtype=float)
    return pos, weights


def add_cluster(pos, weights, center=(0.5, 0.5), n=80, spread=0.055, weight=1.0):
    cluster = RNG.normal(loc=np.array(center), scale=spread, size=(n, 2))
    cluster = np.clip(cluster, 0.02, 0.98)
    pos2 = np.vstack([pos, cluster])
    w2 = np.concatenate([weights, np.full(n, weight, dtype=float)])
    return pos2, w2


def remove_void(pos, weights, center=(0.5,0.5), radius=0.22, keep_fraction=0.20):
    r = np.linalg.norm(pos - np.array(center), axis=1)
    inside = r < radius
    keep = np.ones(len(pos), dtype=bool)
    idx_inside = np.where(inside)[0]
    drop_mask = RNG.random(len(idx_inside)) > keep_fraction
    keep[idx_inside[drop_mask]] = False
    return pos[keep], weights[keep]


def add_filament(pos, weights, x0=0.5, n=90, spread_x=0.025, weight=1.0):
    y = RNG.uniform(0.05, 0.95, size=n)
    x = RNG.normal(x0, spread_x, size=n)
    fil = np.column_stack([np.clip(x,0.02,0.98), y])
    return np.vstack([pos, fil]), np.concatenate([weights, np.full(n, weight)])


def apply_screening(weights, pos, center=(0.5,0.5), radius=0.24, factor=0.45):
    # Screening lowers graph weights for the local region without moving nodes.
    # It is a synthetic proxy for reduced boundary connectivity despite high density.
    r = np.linalg.norm(pos - np.array(center), axis=1)
    w = weights.copy()
    w[r < radius] *= factor
    return w


def apply_overconnect(weights, pos, center=(0.5,0.5), radius=0.24, factor=2.2):
    # Synthetic proxy for enhanced connectivity weights in a diffuse region.
    r = np.linalg.norm(pos - np.array(center), axis=1)
    w = weights.copy()
    w[r < radius] *= factor
    return w


def synthetic_environment_builders():
    """
    Returns name, positions, density_weights, connectivity_weights, description.
    Density and connectivity weights may differ in synthetic controls so that
    dense-screened and diffuse-overconnected cases can be represented before data.
    """
    envs = []

    # Background.
    pos, w = base_uniform_nodes()
    envs.append((
        "homogeneous_background",
        pos, w, w.copy(),
        "uniform settlement field and uniform connectivity"
    ))

    # Dense connected.
    pos, w = base_uniform_nodes()
    pos, w = add_cluster(pos, w, n=100, spread=0.05, weight=1.4)
    envs.append((
        "dense_connected_synthetic",
        pos, w, w.copy(),
        "dense central settlement with matching connectivity"
    ))

    # Underconnected void.
    pos, w = base_uniform_nodes()
    pos, w = remove_void(pos, w, keep_fraction=0.12)
    envs.append((
        "underconnected_void_synthetic",
        pos, w, w.copy(),
        "depleted central settlement and reduced cut connectivity"
    ))

    # Dense but boundary-screened.
    pos, wD = base_uniform_nodes()
    pos, wD = add_cluster(pos, wD, n=100, spread=0.05, weight=1.6)
    wB = apply_screening(wD, pos, factor=0.22)
    envs.append((
        "dense_but_boundary_screened_synthetic",
        pos, wD, wB,
        "density high but boundary connectivity suppressed"
    ))

    # Diffuse but overconnected.
    pos, wD = base_uniform_nodes()
    pos, wD = remove_void(pos, wD, keep_fraction=0.20)
    wB = apply_overconnect(wD, pos, factor=3.0)
    envs.append((
        "diffuse_but_overconnected_synthetic",
        pos, wD, wB,
        "density low but remaining boundary connectivity enhanced"
    ))

    # Filament.
    pos, wD = base_uniform_nodes()
    pos, wD = add_filament(pos, wD, n=100, x0=0.5, spread_x=0.018, weight=1.2)
    envs.append((
        "filamentary_connected_synthetic",
        pos, wD, wD.copy(),
        "anisotropic connected settlement filament"
    ))

    # Strong cluster-like synthetic.
    pos, wD = base_uniform_nodes()
    pos, wD = add_cluster(pos, wD, n=150, spread=0.04, weight=2.0)
    wB = apply_overconnect(wD, pos, factor=1.5)
    envs.append((
        "strong_cluster_like_synthetic",
        pos, wD, wB,
        "high density and enhanced boundary connectivity"
    ))

    return envs


def density_field_at_probes(pos: np.ndarray, density_weights: np.ndarray, probes: np.ndarray) -> np.ndarray:
    r2 = pairwise_r2(probes, pos)
    K = gaussian_kernel_2d(r2, ELL_D)
    return K @ density_weights


def adjacency_matrix(pos: np.ndarray, conn_weights: np.ndarray) -> np.ndarray:
    r2 = pairwise_r2(pos, pos)
    Wouter = np.sqrt(np.outer(conn_weights, conn_weights))
    A = Wouter * np.exp(-0.5 * r2/(ELL_B*ELL_B))
    np.fill_diagonal(A, 0.0)
    return A


def boundary_conductance_at_probes(pos: np.ndarray, conn_weights: np.ndarray, probes: np.ndarray) -> np.ndarray:
    A = adjacency_matrix(pos, conn_weights)
    out = []
    d2_probe_node = pairwise_r2(probes, pos)
    for k in range(len(probes)):
        mask = d2_probe_node[k] <= REGION_RADIUS*REGION_RADIUS
        nS = int(mask.sum())
        if nS == 0 or nS == len(pos):
            out.append(0.0)
            continue
        cut = A[np.ix_(mask, ~mask)].sum()
        out.append(cut / max(nS, 1))
    return np.array(out, dtype=float)


def compute_environment_estimators():
    envs = synthetic_environment_builders()

    # Background normalization uses the first environment by declaration.
    bg_name, bg_pos, bg_wD, bg_wB, _ = envs[0]
    bg_rho = density_field_at_probes(bg_pos, bg_wD, PROBES)
    bg_C = boundary_conductance_at_probes(bg_pos, bg_wB, PROBES)
    rho_bar = float(np.mean(bg_rho))
    C_bar = float(np.mean(bg_C))

    rows = []
    probe_rows = []
    for name, pos, wD, wB, desc in envs:
        rho = density_field_at_probes(pos, wD, PROBES)
        Cb = boundary_conductance_at_probes(pos, wB, PROBES)
        D = rho / (rho_bar + EPS)
        B = Cb / (C_bar + EPS)
        E = np.sqrt(np.maximum(D*B, 0.0))

        # Summaries at all probes and in central region.
        center = np.array([0.5, 0.5])
        r_probe = np.linalg.norm(PROBES - center, axis=1)
        central = r_probe < 0.22
        outer = r_probe > 0.38

        def stats(arr, mask=None):
            data = arr if mask is None else arr[mask]
            return {
                "mean": float(np.mean(data)),
                "median": float(np.median(data)),
                "p16": float(np.percentile(data, 16)),
                "p84": float(np.percentile(data, 84)),
                "min": float(np.min(data)),
                "max": float(np.max(data)),
            }

        D_all, B_all, E_all = stats(D), stats(B), stats(E)
        D_c, B_c, E_c = stats(D, central), stats(B, central), stats(E, central)
        D_o, B_o, E_o = stats(D, outer), stats(B, outer), stats(E, outer)

        rows.append({
            "environment": name,
            "description": desc,
            "node_count": len(pos),
            "rho_bar_background": rho_bar,
            "C_bar_background": C_bar,
            "D_mean_all": D_all["mean"],
            "B_mean_all": B_all["mean"],
            "E_mean_all": E_all["mean"],
            "D_median_all": D_all["median"],
            "B_median_all": B_all["median"],
            "E_median_all": E_all["median"],
            "D_mean_central": D_c["mean"],
            "B_mean_central": B_c["mean"],
            "E_mean_central": E_c["mean"],
            "D_median_central": D_c["median"],
            "B_median_central": B_c["median"],
            "E_median_central": E_c["median"],
            "D_mean_outer": D_o["mean"],
            "B_mean_outer": B_o["mean"],
            "E_mean_outer": E_o["mean"],
            "central_deep_deviation_sqrtE": math.sqrt(max(E_c["mean"], 0.0)),
            "central_transition_radius_factor": 1.0/math.sqrt(max(E_c["mean"], EPS)),
            "compensation_indicator_abs_lnD_plus_lnB": abs(math.log(max(D_c["mean"], EPS)) + math.log(max(B_c["mean"], EPS))),
            "status": "COMPUTED_FROM_FROZEN_ESTIMATORS",
        })

        for i, probe in enumerate(PROBES):
            probe_rows.append({
                "environment": name,
                "probe_index": i,
                "x": float(probe[0]),
                "y": float(probe[1]),
                "rho_set": float(rho[i]),
                "C_boundary": float(Cb[i]),
                "D": float(D[i]),
                "B": float(B[i]),
                "E": float(E[i]),
                "sqrtE_deep_deviation": float(math.sqrt(max(E[i], 0.0))),
                "transition_radius_factor": float(1.0/math.sqrt(max(E[i], EPS))),
            })

    return rows, probe_rows, rho_bar, C_bar


def estimator_invariance_rows(summary_rows, probe_rows):
    """
    Audit estimator properties that should not depend on target data.
    """
    rows = []

    # Background normalization.
    bg = next(r for r in summary_rows if r["environment"] == "homogeneous_background")
    rows.append({
        "test": "background_D_normalization",
        "metric": "D_mean_all",
        "value": bg["D_mean_all"],
        "target": 1.0,
        "pass": abs(bg["D_mean_all"] - 1.0) < 1e-12,
        "interpretation": "background D normalizes to one by frozen rule",
    })
    rows.append({
        "test": "background_B_normalization",
        "metric": "B_mean_all",
        "value": bg["B_mean_all"],
        "target": 1.0,
        "pass": abs(bg["B_mean_all"] - 1.0) < 1e-12,
        "interpretation": "background B normalizes to one by frozen rule",
    })

    # Positivity.
    all_probe_E = [r["E"] for r in probe_rows]
    rows.append({
        "test": "positive_E_all_probes",
        "metric": "min_E",
        "value": min(all_probe_E),
        "target": 0.0,
        "pass": min(all_probe_E) >= 0.0 and all(math.isfinite(v) for v in all_probe_E),
        "interpretation": "computed E is nonnegative and finite everywhere",
    })

    # Qualitative environment ordering in central region.
    dense = next(r for r in summary_rows if r["environment"] == "dense_connected_synthetic")
    void = next(r for r in summary_rows if r["environment"] == "underconnected_void_synthetic")
    cluster = next(r for r in summary_rows if r["environment"] == "strong_cluster_like_synthetic")
    rows.append({
        "test": "dense_connected_E_above_background",
        "metric": "central_E",
        "value": dense["E_mean_central"],
        "target": 1.0,
        "pass": dense["E_mean_central"] > 1.0,
        "interpretation": "dense connected synthetic environment raises E",
    })
    rows.append({
        "test": "void_E_below_background",
        "metric": "central_E",
        "value": void["E_mean_central"],
        "target": 1.0,
        "pass": void["E_mean_central"] < 1.0,
        "interpretation": "underconnected void synthetic environment lowers E",
    })
    rows.append({
        "test": "cluster_like_E_above_dense",
        "metric": "central_E",
        "value": cluster["E_mean_central"],
        "target": dense["E_mean_central"],
        "pass": cluster["E_mean_central"] > dense["E_mean_central"],
        "interpretation": "strong synthetic cluster produces stronger E than ordinary dense case",
    })

    # Compensation channel: dense-screened and diffuse-overconnected should be closer to background than raw D alone suggests in at least one direction.
    screened = next(r for r in summary_rows if r["environment"] == "dense_but_boundary_screened_synthetic")
    over = next(r for r in summary_rows if r["environment"] == "diffuse_but_overconnected_synthetic")
    rows.append({
        "test": "dense_screened_compensation_channel",
        "metric": "E_vs_D_central",
        "value": screened["E_mean_central"]/max(screened["D_mean_central"], EPS),
        "target": 1.0,
        "pass": screened["E_mean_central"] < screened["D_mean_central"],
        "interpretation": "screened boundary connectivity reduces the density-only environmental boost",
    })
    rows.append({
        "test": "diffuse_overconnected_compensation_channel",
        "metric": "E_vs_D_central",
        "value": over["E_mean_central"]/max(over["D_mean_central"], EPS),
        "target": 1.0,
        "pass": over["E_mean_central"] > over["D_mean_central"],
        "interpretation": "enhanced connectivity raises the density-only void estimate",
    })

    return rows


def no_cheat_control_rows():
    return [
        {
            "control": "observed_residual_fit",
            "status": "FORBIDDEN",
            "uses_observed_a0": True,
            "uses_galaxy_data": True,
            "uses_cluster_data": True,
            "uses_kSZ_data": True,
            "reason": "would choose D or B to match data residuals; forbidden before estimator freeze",
        },
        {
            "control": "free_kernel_length_fit",
            "status": "REJECT_TUNABLE",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_cluster_data": False,
            "uses_kSZ_data": False,
            "reason": "kernel lengths ell_D and ell_B are frozen constants in this audit, not fitted",
        },
        {
            "control": "density_only_estimator",
            "status": "REJECT_BIASED",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_cluster_data": False,
            "uses_kSZ_data": False,
            "reason": "drops boundary-connectivity channel from GRAV_TRAJ_09",
        },
        {
            "control": "connectivity_only_estimator",
            "status": "REJECT_BIASED",
            "uses_observed_a0": False,
            "uses_galaxy_data": False,
            "uses_cluster_data": False,
            "uses_kSZ_data": False,
            "reason": "drops settlement-density channel from GRAV_TRAJ_09",
        },
        {
            "control": "posthoc_environment_labeling",
            "status": "FORBIDDEN",
            "uses_observed_a0": False,
            "uses_galaxy_data": True,
            "uses_cluster_data": True,
            "uses_kSZ_data": True,
            "reason": "environment labels must be computed from frozen graph/field rules before observational comparison",
        },
    ]


def dependency_debt_rows():
    return [
        {
            "debt": "D1_physical_settlement_density_observable",
            "status": "OPEN",
            "description": "Need map rho_set to real computable fields such as baryonic source density, operation density, or simulation-derived settlement demand.",
            "next_test": "freeze physical rho_set proxy before data comparison",
        },
        {
            "debt": "D2_physical_boundary_connectivity_observable",
            "status": "OPEN",
            "description": "Need map C_boundary to real graph/topological estimator such as tidal connectivity, filament connectivity, horizon access, or settlement graph conductance.",
            "next_test": "freeze physical C_boundary proxy before data comparison",
        },
        {
            "debt": "D3_kernel_scale_derivation",
            "status": "OPEN",
            "description": "ell_D, ell_B, and region radius are fixed synthetic constants here, not derived from SFT scales.",
            "next_test": "derive smoothing scales from transition radius, source scale, or no-overwrite ledger scale",
        },
        {
            "debt": "D4_blind_prediction_protocol",
            "status": "DEFERRED",
            "description": "Need pre-register D/B computation before SPARC/RAR/cluster/kSZ comparisons.",
            "next_test": "only compare after D1-D3 are frozen",
        },
        {
            "debt": "D5_local_metric_preservation",
            "status": "WATCH",
            "description": "Need ensure graph-computed E enters only far-field handoff, not local FB=1 metric closure.",
            "next_test": "explicitly attach E to r_t/a_eff and verify local weak-field closure unchanged",
        },
    ]


def verdict_row(summary_rows, probe_rows, estimator_tests, controls):
    all_tests_pass = all(r["pass"] for r in estimator_tests)
    no_forbidden_used = all(
        (not r["uses_observed_a0"] and not r["uses_galaxy_data"] and not r["uses_cluster_data"] and not r["uses_kSZ_data"])
        for r in controls if r["status"] not in ["FORBIDDEN"]
    )
    forbidden_marked = all(r["status"] == "FORBIDDEN" for r in controls if r["control"] in ["observed_residual_fit", "posthoc_environment_labeling"])

    has_computed_rows = len(summary_rows) > 0 and len(probe_rows) > 0
    computed_from_frozen = all(r["status"] == "COMPUTED_FROM_FROZEN_ESTIMATORS" for r in summary_rows)

    ok = all_tests_pass and no_forbidden_used and forbidden_marked and has_computed_rows and computed_from_frozen

    return {
        "verdict": "COMPUTABLE_D_B_ESTIMATORS_SURVIVE_FROZEN_SYNTHETIC_GRAPH_FIELD_AUDIT" if ok else "COMPUTABLE_D_B_ESTIMATORS_REQUIRE_REVISION",
        "claim_boundary": "synthetic estimator-freeze audit only; not final physical observables, not SPARC/RAR fit, not cluster solution, not kSZ prediction, and not completed far-field gravity",
        "D_estimator": "D(x)=rho_set(x)/<rho_set>_background using Gaussian-smoothed settlement weights",
        "B_estimator": "B(S)=C_boundary(S)/<C_boundary>_background using graph cut conductance per node",
        "E_law": "E=sqrt(D*B)",
        "ell_D": ELL_D,
        "ell_B": ELL_B,
        "region_radius": REGION_RADIUS,
        "rng_seed": RNG_SEED,
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_SPARC_or_RAR_data": False,
        "uses_cluster_data": False,
        "uses_kSZ_data": False,
        "estimator_tests_pass": all_tests_pass,
        "forbidden_controls_marked": forbidden_marked,
        "computed_from_frozen_rules": computed_from_frozen,
        "main_result": "D and B can be computed from a frozen synthetic settlement field and graph boundary-conductance rule, making E=sqrt(D B) evaluable before observational comparison.",
        "paper_safe_sentence": (
            "GRAV_TRAJ_10 freezes computable synthetic estimators for the GRAV_TRAJ_09 environment factor before any observational comparison. "
            "The settlement-density channel is defined by a Gaussian-smoothed settlement field, D(x)=rho_set(x)/<rho_set>_background, while the boundary-connectivity channel is defined by graph cut conductance per node, B(S)=C_boundary(S)/<C_boundary>_background. "
            "Using the previously selected no-bias law E=sqrt(DB), synthetic dense-connected regions raise E, underconnected voids lower E, and compensated dense-screened or diffuse-overconnected cases demonstrate that boundary connectivity can reduce or enhance the density-only expectation. "
            "No observed a0, SPARC/RAR, galaxy, cluster, or kSZ data are used, and target-residual controls are forbidden. "
            "This gate does not identify the final physical observables for D and B; it only proves that the environment channel can be computed from frozen graph/field rules before data fitting."
        ),
        "next_gate": "GRAV_TRAJ_11 should either derive the physical rho_set and C_boundary observables, or attach the computed E only to the far-field transition while proving local FB=1 metric closure remains unchanged.",
    }


def save_plots(summary_rows, probe_rows, tests):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # Summary E central.
        labels = [r["environment"] for r in summary_rows]
        vals = [r["E_mean_central"] for r in summary_rows]
        x = np.arange(len(labels))
        plt.figure(figsize=(10,5))
        plt.scatter(x, vals)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("central mean E")
        plt.title("GRAV_TRAJ_10: computed central environment factor")
        plt.tight_layout()
        p = OUT/"grav_traj_10_central_E_summary.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # D vs B central.
        plt.figure(figsize=(7,6))
        for r in summary_rows:
            plt.scatter(r["D_mean_central"], r["B_mean_central"])
            plt.text(r["D_mean_central"], r["B_mean_central"], r["environment"][:12], fontsize=7)
        plt.axvline(1.0, linestyle="--", linewidth=1)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("central D")
        plt.ylabel("central B")
        plt.title("GRAV_TRAJ_10: computed D/B channel map")
        plt.tight_layout()
        p = OUT/"grav_traj_10_D_B_channel_map.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Probe E heatmaps for selected environments.
        selected = ["homogeneous_background", "dense_connected_synthetic", "underconnected_void_synthetic", "dense_but_boundary_screened_synthetic"]
        for env in selected:
            sub = [r for r in probe_rows if r["environment"] == env]
            xs = sorted(set(round(r["x"], 12) for r in sub))
            ys = sorted(set(round(r["y"], 12) for r in sub))
            Z = np.zeros((len(ys), len(xs)))
            ix = {v:i for i,v in enumerate(xs)}
            iy = {v:i for i,v in enumerate(ys)}
            for r in sub:
                Z[iy[round(r["y"], 12)], ix[round(r["x"], 12)]] = r["E"]
            plt.figure(figsize=(6,5))
            plt.imshow(Z, origin="lower", extent=[min(xs), max(xs), min(ys), max(ys)], aspect="equal")
            plt.colorbar(label="E")
            plt.title(f"GRAV_TRAJ_10: E field {env}")
            plt.xlabel("x")
            plt.ylabel("y")
            plt.tight_layout()
            p = OUT/f"grav_traj_10_E_field_{env}.png"
            plt.savefig(p, dpi=160)
            plt.close()
            plots.append(str(p))

        # Estimator tests.
        plt.figure(figsize=(9,5))
        labels = [r["test"] for r in tests]
        vals = [1 if r["pass"] else 0 for r in tests]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("pass flag")
        plt.title("GRAV_TRAJ_10: estimator invariance tests")
        plt.tight_layout()
        p = OUT/"grav_traj_10_estimator_tests.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, summary_rows, tests, controls, debts, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_10: Computable D and B Estimator Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## Frozen estimator definitions\n\n")
    lines.append(f"- {verdict['D_estimator']}\n")
    lines.append(f"- {verdict['B_estimator']}\n")
    lines.append(f"- {verdict['E_law']}\n")
    lines.append(f"- ell_D={ELL_D}, ell_B={ELL_B}, region_radius={REGION_RADIUS}, rng_seed={RNG_SEED}\n\n")

    lines.append("## Environment summaries\n\n")
    lines.append("| Environment | D central | B central | E central | sqrt(E) | status |\n")
    lines.append("|---|---:|---:|---:|---:|---|\n")
    for r in summary_rows:
        lines.append(
            f"| {r['environment']} | {r['D_mean_central']:.6f} | {r['B_mean_central']:.6f} | "
            f"{r['E_mean_central']:.6f} | {r['central_deep_deviation_sqrtE']:.6f} | {r['status']} |\n"
        )

    lines.append("\n## Estimator tests\n\n")
    lines.append("| Test | value | target | pass | interpretation |\n")
    lines.append("|---|---:|---:|---|---|\n")
    for r in tests:
        lines.append(f"| {r['test']} | {r['value']:.6e} | {r['target']:.6e} | {r['pass']} | {r['interpretation']} |\n")

    lines.append("\n## Controls\n\n")
    lines.append("| Control | status | reason |\n")
    lines.append("|---|---|---|\n")
    for r in controls:
        lines.append(f"| {r['control']} | {r['status']} | {r['reason']} |\n")

    lines.append("\n## Remaining debts\n\n")
    lines.append("| Debt | status | description |\n")
    lines.append("|---|---|---|\n")
    for r in debts:
        lines.append(f"| {r['debt']} | {r['status']} | {r['description']} |\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    summary_rows, probe_rows, rho_bar, C_bar = compute_environment_estimators()
    tests = estimator_invariance_rows(summary_rows, probe_rows)
    controls = no_cheat_control_rows()
    debts = dependency_debt_rows()
    verdict = verdict_row(summary_rows, probe_rows, tests, controls)

    write_csv(OUT/"grav_traj_10_environment_summary.csv", summary_rows)
    write_csv(OUT/"grav_traj_10_probe_estimators.csv", probe_rows)
    write_csv(OUT/"grav_traj_10_estimator_tests.csv", tests)
    write_csv(OUT/"grav_traj_10_controls.csv", controls)
    write_csv(OUT/"grav_traj_10_dependency_debts.csv", debts)
    write_csv(OUT/"grav_traj_10_verdict.csv", [verdict])

    plots = save_plots(summary_rows, probe_rows, tests)
    write_report(OUT/"GRAV_TRAJ_10_computable_D_B_estimators_report.md", summary_rows, tests, controls, debts, verdict)

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_10",
        "purpose": "freeze computable D and B synthetic graph/field estimators before observational comparison",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "files": [
            "grav_traj_10_environment_summary.csv",
            "grav_traj_10_probe_estimators.csv",
            "grav_traj_10_estimator_tests.csv",
            "grav_traj_10_controls.csv",
            "grav_traj_10_dependency_debts.csv",
            "grav_traj_10_verdict.csv",
            "GRAV_TRAJ_10_computable_D_B_estimators_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_10 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Freeze computable synthetic D and B estimators before observational comparison.")
    print("  No observed a0, SPARC/RAR, galaxy data, cluster data, or kSZ data are used.")

    print("\nFrozen estimator definitions:")
    print(f"  D: {verdict['D_estimator']}")
    print(f"  B: {verdict['B_estimator']}")
    print(f"  E: {verdict['E_law']}")
    print(f"  ell_D={ELL_D}, ell_B={ELL_B}, region_radius={REGION_RADIUS}, rng_seed={RNG_SEED}")
    print(f"  background rho_bar={rho_bar:.6e}, C_bar={C_bar:.6e}")

    print("\nEnvironment estimator summary:")
    for r in summary_rows:
        print(
            f"  {r['environment']:42s}  "
            f"D_c={r['D_mean_central']:.6f}  "
            f"B_c={r['B_mean_central']:.6f}  "
            f"E_c={r['E_mean_central']:.6f}  "
            f"sqrtE={r['central_deep_deviation_sqrtE']:.6f}  "
            f"rt_factor={r['central_transition_radius_factor']:.6f}"
        )

    print("\nEstimator invariance / role tests:")
    for r in tests:
        print(
            f"  {r['test']:40s}  "
            f"value={r['value']:.6e}  "
            f"target={r['target']:.6e}  "
            f"PASS={r['pass']}  "
            f"{r['interpretation']}"
        )

    print("\nControls:")
    for r in controls:
        print(
            f"  {r['control']:32s}  "
            f"{r['status']:16s}  "
            f"{r['reason']}"
        )

    print("\nRemaining debts:")
    for r in debts:
        print(f"  {r['debt']:42s}  {r['status']:10s}  {r['description']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_10_computable_D_B_estimators_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_10_verdict.csv'}")
    print(f"  environment summary csv: {OUT/'grav_traj_10_environment_summary.csv'}")
    print(f"  probe estimators csv: {OUT/'grav_traj_10_probe_estimators.csv'}")
    print(f"  estimator tests csv: {OUT/'grav_traj_10_estimator_tests.csv'}")
    print(f"  controls csv: {OUT/'grav_traj_10_controls.csv'}")
    print(f"  debts csv: {OUT/'grav_traj_10_dependency_debts.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
