#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_13:
Blind Prediction Protocol Freeze / No-Retuning Lockbox Audit

Purpose
-------
GRAV_TRAJ_12 selected the physical proxy bundle:

    D proxy:
        rho_set ∝ rho_b + 3 p_b / c^2
        cold-system fallback: rho_set -> rho_b when p_b is unavailable/negligible

    B proxy:
        source-graph boundary conductance per node

    scale:
        r0 = sqrt(GM/a_S)

    E law:
        E = sqrt(D B)

    Gate 11 guardrail:
        E enters only the far-field handoff:
            a_eff = E a_S
            r_t = sqrt(GM/(E a_S))
        E never enters local F, B_metric, phi, M, G, gamma, or beta.

GRAV_TRAJ_13 freezes the blind prediction protocol before any data-facing
validation.

This gate does NOT use observed a0, SPARC, RAR, galaxy rotation curves,
cluster residuals, kSZ data, or any validation target.

It writes a protocol lockbox:
    - allowed inputs
    - forbidden inputs
    - D computation spec
    - B graph spec
    - scale spec
    - prediction output schema
    - no-retuning firewall
    - protocol hash
    - Gate 14 validation blueprint

Claim boundary
--------------
A pass means:
    The pre-data prediction machinery is frozen and ready for a future
    validation gate.

A pass does NOT mean:
    SFT fits SPARC/RAR,
    SFT solves clusters,
    SFT predicts kSZ,
    SFT derives final nonlinear gravity,
    or any observational result has been tested.

Stacking decision
-----------------
This script may emit a GRAV_TRAJ_14 validation blueprint if it passes.
It does NOT run validation. Gate 14 requires explicit dataset availability
and a separate decision to begin data-facing tests.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_13_OUTPUT")

# Physical constants for prediction formulas.
C = 299_792_458.0
G = 6.67430e-11
MPC = 3.0856775814913673e22
M_SUN = 1.98847e30
KPC = 3.0856775814913673e19

# Frozen background scale from prior gates.
H0_FID_KM_S_MPC = 70.0
H0_FID = H0_FID_KM_S_MPC * 1000.0 / MPC
A_S_BACKGROUND = C * H0_FID / (2.0 * math.pi)

# Frozen protocol fractions inherited from the synthetic estimator line.
F_ELL_D = 0.10
F_ELL_B = 0.16
F_REGION = 0.18

# Frozen equations / labels.
D_PROXY = "operation_density_rho_plus_3p_proxy"
B_PROXY = "source_graph_boundary_conductance_proxy"
SCALE_SELECTOR = "background_transition_radius_r0_sqrt_GM_over_aS"
E_LAW = "E=sqrt(D*B)"
E_ATTACHMENT = "far_field_transition_only"
LOCAL_GUARDRAIL = "E_not_in_F_Bmetric_phi_M_G_gamma_beta"

# Protocol version tag.
PROTOCOL_VERSION = "GRAV_TRAJ_13_BLIND_PROTOCOL_FREEZE_v1"


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------
# Protocol specs
# ---------------------------------------------------------------------

def allowed_inputs_rows() -> list[dict]:
    return [
        {
            "input": "source_catalog",
            "allowed": True,
            "required": True,
            "description": "pre-declared source objects/nodes/fields used to compute mass, rho_set, and graph connectivity",
            "examples": "baryonic mass maps, gas maps, stellar mass maps, simulation source fields",
            "freeze_rule": "catalog choice must be declared before any residual comparison",
        },
        {
            "input": "baryonic_mass_or_source_weight",
            "allowed": True,
            "required": True,
            "description": "node/source weights used for M, rho_b, and graph weights",
            "examples": "M_b, cell baryonic mass, particle baryonic mass, operation-density source weight",
            "freeze_rule": "mass-to-light or conversion rules must be fixed before validation",
        },
        {
            "input": "pressure_or_state_proxy",
            "allowed": True,
            "required": False,
            "description": "optional p_b field for rho_b+3p_b/c^2 operation-density proxy",
            "examples": "gas pressure, equation-of-state proxy, simulation pressure field",
            "freeze_rule": "if unavailable, cold-system fallback rho_set=rho_b is used automatically",
        },
        {
            "input": "positions_or_graph_coordinates",
            "allowed": True,
            "required": True,
            "description": "positions needed to build source graph and boundary conductance",
            "examples": "2D disk coordinates, 3D source positions, simulation cell centers",
            "freeze_rule": "coordinate projection/geometry must be declared before validation",
        },
        {
            "input": "background_normalization_sample",
            "allowed": True,
            "required": True,
            "description": "pre-declared background/reference sample for normalizing D and B",
            "examples": "control regions, full sample mean, simulation background, matched source population",
            "freeze_rule": "background definition cannot be changed after predictions are generated",
        },
        {
            "input": "object_or_region_mass_M",
            "allowed": True,
            "required": True,
            "description": "mass used to compute r0=sqrt(GM/aS)",
            "examples": "baryonic mass within source region or pre-declared aperture",
            "freeze_rule": "aperture/mass definition frozen before validation",
        },
    ]


def forbidden_inputs_rows() -> list[dict]:
    return [
        {
            "input": "observed_a0_target",
            "forbidden": True,
            "reason": "a_S already fixed by cH/(2pi); observed a0 cannot tune the protocol",
        },
        {
            "input": "rotation_curve_residuals",
            "forbidden": True,
            "reason": "residuals are validation targets, not inputs to D, B, or E",
        },
        {
            "input": "SPARC_RAR_fit_residuals",
            "forbidden": True,
            "reason": "SPARC/RAR comparisons are Gate 14+ validation only",
        },
        {
            "input": "cluster_mass_discrepancy_residuals",
            "forbidden": True,
            "reason": "cluster residuals are future validation targets",
        },
        {
            "input": "kSZ_velocity_or_temperature_residuals",
            "forbidden": True,
            "reason": "kSZ is future validation target, not protocol input",
        },
        {
            "input": "dark_halo_best_fit_parameters",
            "forbidden": True,
            "reason": "would import fitted dark-sector residuals into rho_set",
        },
        {
            "input": "posthoc_environment_labels",
            "forbidden": True,
            "reason": "environment must be computed from frozen graph/field rules",
        },
        {
            "input": "best_fit_kernel_lengths",
            "forbidden": True,
            "reason": "kernel/region scales must be fixed from r0 fractions, not optimized",
        },
        {
            "input": "per_object_free_exponent_or_offset",
            "forbidden": True,
            "reason": "E=sqrt(D B) has no fitted exponent, offset, or per-object correction",
        },
    ]


def D_computation_spec_rows() -> list[dict]:
    return [
        {
            "step": "D1_source_density",
            "formula": "rho_set = rho_b + 3 p_b/c^2",
            "cold_fallback": "if p_b unavailable/negligible, use rho_set=rho_b",
            "target_free": True,
            "notes": "preserves GRAV_TRAJ_03 rho+3p source logic",
        },
        {
            "step": "D2_smoothing_scale",
            "formula": "ell_D = f_D r0, f_D=0.10",
            "cold_fallback": "",
            "target_free": True,
            "notes": "r0 computed before E feedback",
        },
        {
            "step": "D3_smooth_field",
            "formula": "rho_set_smoothed(x)=sum_i rho_set_i K(|x-x_i|; ell_D)",
            "cold_fallback": "",
            "target_free": True,
            "notes": "kernel family and scale must be frozen before validation",
        },
        {
            "step": "D4_background_normalization",
            "formula": "D(x)=rho_set_smoothed(x)/<rho_set_smoothed>_background",
            "cold_fallback": "",
            "target_free": True,
            "notes": "background sample declared before comparison",
        },
    ]


def B_graph_spec_rows() -> list[dict]:
    return [
        {
            "step": "B1_graph_nodes",
            "formula": "nodes = pre-declared source elements used for rho_set",
            "target_free": True,
            "notes": "same source dictionary as D when possible",
        },
        {
            "step": "B2_edge_weights",
            "formula": "A_ij = sqrt(w_i w_j) exp(-d_ij^2/(2 ell_B^2))",
            "target_free": True,
            "notes": "w_i from source/operation weights; ell_B=f_B r0",
        },
        {
            "step": "B3_graph_scale",
            "formula": "ell_B = f_B r0, f_B=0.16",
            "target_free": True,
            "notes": "fixed fraction; no best-fit graph length",
        },
        {
            "step": "B4_boundary_region",
            "formula": "S = nodes within region radius R_S=f_region r0, f_region=0.18",
            "target_free": True,
            "notes": "region rule frozen before validation",
        },
        {
            "step": "B5_cut_conductance",
            "formula": "C_boundary(S)=sum_{i in S,j notin S} A_ij / |S|",
            "target_free": True,
            "notes": "conductance per node",
        },
        {
            "step": "B6_background_normalization",
            "formula": "B(S)=C_boundary(S)/<C_boundary>_background",
            "target_free": True,
            "notes": "background sample declared before comparison",
        },
    ]


def scale_spec_rows() -> list[dict]:
    return [
        {
            "scale": "a_S",
            "formula": "a_S(t)=cH(t)/(2pi)",
            "gate_origin": "GRAV_TRAJ_05_to_08",
            "value_for_fiducial_H0_70": A_S_BACKGROUND,
            "target_free": True,
        },
        {
            "scale": "r0",
            "formula": "r0=sqrt(GM/a_S)",
            "gate_origin": "GRAV_TRAJ_12",
            "value_for_fiducial_H0_70": "",
            "target_free": True,
        },
        {
            "scale": "ell_D",
            "formula": "ell_D=0.10*r0",
            "gate_origin": "GRAV_TRAJ_10_to_12",
            "value_for_fiducial_H0_70": "",
            "target_free": True,
        },
        {
            "scale": "ell_B",
            "formula": "ell_B=0.16*r0",
            "gate_origin": "GRAV_TRAJ_10_to_12",
            "value_for_fiducial_H0_70": "",
            "target_free": True,
        },
        {
            "scale": "region_radius",
            "formula": "R_S=0.18*r0",
            "gate_origin": "GRAV_TRAJ_10_to_12",
            "value_for_fiducial_H0_70": "",
            "target_free": True,
        },
    ]


def prediction_output_schema_rows() -> list[dict]:
    return [
        {
            "output": "D",
            "formula": "rho_set_smoothed/<rho_set_smoothed>_background",
            "meaning": "settlement-density channel",
            "must_exist_before_validation": True,
        },
        {
            "output": "B",
            "formula": "C_boundary/<C_boundary>_background",
            "meaning": "boundary-connectivity channel",
            "must_exist_before_validation": True,
        },
        {
            "output": "E",
            "formula": "sqrt(D*B)",
            "meaning": "environment factor",
            "must_exist_before_validation": True,
        },
        {
            "output": "sqrtE_deviation",
            "formula": "sqrt(E)",
            "meaning": "deep-regime deviation from universal MOND-like amplitude",
            "must_exist_before_validation": True,
        },
        {
            "output": "a_eff",
            "formula": "E*a_S",
            "meaning": "environment-deformed settlement acceleration",
            "must_exist_before_validation": True,
        },
        {
            "output": "r0",
            "formula": "sqrt(GM/a_S)",
            "meaning": "background transition radius before E",
            "must_exist_before_validation": True,
        },
        {
            "output": "r_t",
            "formula": "sqrt(GM/(E*a_S)) = r0/sqrt(E)",
            "meaning": "environment-shifted transition radius",
            "must_exist_before_validation": True,
        },
        {
            "output": "local_metric_guardrail",
            "formula": "F=e^-phi, B_metric=e^+phi, FB=1; E absent",
            "meaning": "local closure preservation",
            "must_exist_before_validation": True,
        },
    ]


def no_retuning_firewall_rows() -> list[dict]:
    return [
        {
            "firewall": "hash_protocol_before_validation",
            "pass_condition": "protocol JSON and hash written before validation",
            "locked": True,
            "reason": "prevents silent changes after seeing data",
        },
        {
            "firewall": "no_kernel_refit",
            "pass_condition": "ell_D, ell_B, and region radius fractions fixed",
            "locked": True,
            "reason": "prevents residual-optimized smoothing",
        },
        {
            "firewall": "no_E_exponent_refit",
            "pass_condition": "E=sqrt(D*B), no alpha, offset, or intercept",
            "locked": True,
            "reason": "preserves Gate 09 no-bias selector",
        },
        {
            "firewall": "no_local_metric_modification",
            "pass_condition": "E absent from local F, B_metric, phi, M, G, gamma, beta",
            "locked": True,
            "reason": "preserves Gate 11 local metric closure",
        },
        {
            "firewall": "no_target_inputs",
            "pass_condition": "forbidden inputs list excluded from computation",
            "locked": True,
            "reason": "keeps data validation blind",
        },
        {
            "firewall": "prediction_table_sealed",
            "pass_condition": "D/B/E/a_eff/r_t outputs written before residual comparison",
            "locked": True,
            "reason": "separates prediction from validation",
        },
    ]


# ---------------------------------------------------------------------
# Synthetic smoke prediction table
# ---------------------------------------------------------------------

def synthetic_sources() -> list[dict]:
    """
    Tiny target-free smoke set to prove protocol equations produce a prediction
    table. These are NOT real systems and are not validation data.
    """
    return [
        {"object_id": "smoke_dwarf_background", "M_Msun": 1e8, "D": 1.0, "B": 1.0},
        {"object_id": "smoke_galaxy_dense_connected", "M_Msun": 1e10, "D": 2.0, "B": 2.0},
        {"object_id": "smoke_large_screened", "M_Msun": 1e11, "D": 4.0, "B": 0.25},
        {"object_id": "smoke_void_like", "M_Msun": 1e10, "D": 0.5, "B": 0.5},
        {"object_id": "smoke_cluster_connected", "M_Msun": 1e14, "D": 4.0, "B": 2.0},
    ]


def smoke_prediction_rows() -> list[dict]:
    rows = []
    for s in synthetic_sources():
        M = s["M_Msun"] * M_SUN
        D = s["D"]
        B = s["B"]
        E = math.sqrt(D*B)
        sqrtE = math.sqrt(E)
        r0 = math.sqrt(G*M/A_S_BACKGROUND)
        rt = r0 / math.sqrt(E)
        a_eff = E*A_S_BACKGROUND
        rows.append({
            "object_id": s["object_id"],
            "synthetic_only": True,
            "M_Msun": s["M_Msun"],
            "D": D,
            "B": B,
            "E": E,
            "sqrtE_deviation": sqrtE,
            "aS_background_m_s2": A_S_BACKGROUND,
            "a_eff_m_s2": a_eff,
            "r0_kpc": r0/KPC,
            "rt_kpc": rt/KPC,
            "rt_over_r0": rt/r0,
            "ell_D_kpc": F_ELL_D*r0/KPC,
            "ell_B_kpc": F_ELL_B*r0/KPC,
            "region_radius_kpc": F_REGION*r0/KPC,
            "local_metric_guardrail": "E_absent_from_local_metric_source",
        })
    return rows


# ---------------------------------------------------------------------
# Protocol object / checks / verdict
# ---------------------------------------------------------------------

def protocol_object() -> dict:
    return {
        "protocol_version": PROTOCOL_VERSION,
        "claim_boundary": "blind protocol freeze only; no observational validation",
        "constants": {
            "c": C,
            "G": G,
            "H0_fid_km_s_Mpc": H0_FID_KM_S_MPC,
            "aS_background_m_s2": A_S_BACKGROUND,
        },
        "selected_bundle": {
            "D_proxy": D_PROXY,
            "B_proxy": B_PROXY,
            "scale_selector": SCALE_SELECTOR,
            "E_law": E_LAW,
            "E_attachment": E_ATTACHMENT,
            "local_guardrail": LOCAL_GUARDRAIL,
        },
        "scale_fractions": {
            "f_ell_D": F_ELL_D,
            "f_ell_B": F_ELL_B,
            "f_region": F_REGION,
        },
        "allowed_inputs": allowed_inputs_rows(),
        "forbidden_inputs": forbidden_inputs_rows(),
        "D_computation": D_computation_spec_rows(),
        "B_graph": B_graph_spec_rows(),
        "scale_spec": scale_spec_rows(),
        "prediction_outputs": prediction_output_schema_rows(),
        "no_retuning_firewall": no_retuning_firewall_rows(),
        "hard_rules": [
            "No observed a0 target may enter.",
            "No rotation curve, SPARC/RAR, cluster, or kSZ residual may enter prediction computation.",
            "No dark-halo best-fit parameter may enter rho_set.",
            "No post-hoc environment label may replace graph conductance.",
            "No kernel length or exponent may be fit to residuals.",
            "E may enter only a_eff and r_t, never local metric/source sectors.",
            "Prediction table must be sealed before validation begins.",
        ],
    }


def protocol_freeze_rows(protocol_hash: str) -> list[dict]:
    return [
        {
            "item": "protocol_version",
            "value": PROTOCOL_VERSION,
            "locked": True,
            "hash": protocol_hash,
        },
        {
            "item": "D_proxy",
            "value": D_PROXY,
            "locked": True,
            "hash": protocol_hash,
        },
        {
            "item": "B_proxy",
            "value": B_PROXY,
            "locked": True,
            "hash": protocol_hash,
        },
        {
            "item": "scale_selector",
            "value": SCALE_SELECTOR,
            "locked": True,
            "hash": protocol_hash,
        },
        {
            "item": "E_law",
            "value": E_LAW,
            "locked": True,
            "hash": protocol_hash,
        },
        {
            "item": "E_attachment",
            "value": E_ATTACHMENT,
            "locked": True,
            "hash": protocol_hash,
        },
        {
            "item": "scale_fractions",
            "value": f"ell_D={F_ELL_D}, ell_B={F_ELL_B}, region={F_REGION}",
            "locked": True,
            "hash": protocol_hash,
        },
    ]


def protocol_checks_rows(protocol: dict, smoke_rows: list[dict]) -> list[dict]:
    allowed = protocol["allowed_inputs"]
    forbidden = protocol["forbidden_inputs"]
    firewall = protocol["no_retuning_firewall"]
    outputs = protocol["prediction_outputs"]

    rows = [
        {
            "check": "allowed_inputs_declared",
            "pass": all(r["allowed"] and r["required"] is not None for r in allowed),
            "value": len(allowed),
            "required": ">=1",
            "reason": "allowed inputs are explicitly declared",
        },
        {
            "check": "forbidden_inputs_declared",
            "pass": all(r["forbidden"] for r in forbidden),
            "value": len(forbidden),
            "required": ">=1",
            "reason": "target/residual inputs are explicitly forbidden",
        },
        {
            "check": "D_computation_frozen",
            "pass": protocol["selected_bundle"]["D_proxy"] == D_PROXY and len(protocol["D_computation"]) >= 4,
            "value": protocol["selected_bundle"]["D_proxy"],
            "required": D_PROXY,
            "reason": "D proxy and steps are frozen",
        },
        {
            "check": "B_graph_frozen",
            "pass": protocol["selected_bundle"]["B_proxy"] == B_PROXY and len(protocol["B_graph"]) >= 6,
            "value": protocol["selected_bundle"]["B_proxy"],
            "required": B_PROXY,
            "reason": "B proxy and graph steps are frozen",
        },
        {
            "check": "scale_fractions_frozen",
            "pass": protocol["scale_fractions"] == {"f_ell_D": F_ELL_D, "f_ell_B": F_ELL_B, "f_region": F_REGION},
            "value": str(protocol["scale_fractions"]),
            "required": "fixed fractions",
            "reason": "smoothing/region fractions are frozen",
        },
        {
            "check": "E_law_no_free_exponent",
            "pass": protocol["selected_bundle"]["E_law"] == "E=sqrt(D*B)",
            "value": protocol["selected_bundle"]["E_law"],
            "required": "E=sqrt(D*B)",
            "reason": "Gate 09 no-bias law preserved",
        },
        {
            "check": "Gate11_local_guardrail_preserved",
            "pass": protocol["selected_bundle"]["E_attachment"] == E_ATTACHMENT and "local_guardrail" in protocol["selected_bundle"],
            "value": protocol["selected_bundle"]["E_attachment"],
            "required": E_ATTACHMENT,
            "reason": "E attaches only to far-field handoff",
        },
        {
            "check": "prediction_outputs_declared",
            "pass": all(r["must_exist_before_validation"] for r in outputs),
            "value": len(outputs),
            "required": "all outputs predeclared",
            "reason": "future prediction table schema is frozen",
        },
        {
            "check": "no_retuning_firewall_locked",
            "pass": all(r["locked"] for r in firewall),
            "value": len(firewall),
            "required": "all locked",
            "reason": "no-retuning firewall is active",
        },
        {
            "check": "smoke_predictions_finite",
            "pass": all(math.isfinite(r["E"]) and math.isfinite(r["a_eff_m_s2"]) and math.isfinite(r["rt_kpc"]) for r in smoke_rows),
            "value": len(smoke_rows),
            "required": "all finite",
            "reason": "protocol equations generate prediction rows without data targets",
        },
    ]
    return rows


def gate14_blueprint_rows(protocol_hash: str) -> list[dict]:
    return [
        {
            "gate14_item": "validation_readiness_check",
            "description": "confirm protocol hash and prediction table exist before loading validation targets",
            "requires_protocol_hash": protocol_hash,
            "no_retuning_rule": "abort if protocol hash changes after validation starts",
        },
        {
            "gate14_item": "SPARC_RAR_validation_candidate",
            "description": "compare sealed predicted sqrt(E), r_t, and a_eff patterns to rotation/RAR residual structure",
            "requires_protocol_hash": protocol_hash,
            "no_retuning_rule": "no adjustment of D/B graph, kernel fractions, E law, or a_S",
        },
        {
            "gate14_item": "cluster_validation_candidate",
            "description": "test whether high-connectivity/high-density E predicts cluster-scale deviations before fitting",
            "requires_protocol_hash": protocol_hash,
            "no_retuning_rule": "no cluster-specific E correction",
        },
        {
            "gate14_item": "kSZ_large_scale_flow_candidate",
            "description": "test whether connectivity-derived B correlates with large-scale flow/kSZ channels",
            "requires_protocol_hash": protocol_hash,
            "no_retuning_rule": "B graph must be same predeclared conductance proxy",
        },
        {
            "gate14_item": "null_controls",
            "description": "compare against shuffled B, density-only D, and forbidden residual-fit controls as post-validation diagnostics",
            "requires_protocol_hash": protocol_hash,
            "no_retuning_rule": "controls cannot replace primary protocol after seeing outcomes",
        },
    ]


def stack_decision_rows(verdict_ok: bool) -> list[dict]:
    if verdict_ok:
        return [
            {
                "stack_action": "WRITE_GATE14_VALIDATION_BLUEPRINT_ONLY",
                "execute_gate14_now": False,
                "reason": "Gate 14 is data-facing validation and requires explicit dataset choice; protocol is frozen but validation is not auto-run.",
                "generated_file": "grav_traj_13_gate14_blueprint.csv",
            }
        ]
    return [
        {
            "stack_action": "DO_NOT_STACK",
            "execute_gate14_now": False,
            "reason": "Gate 13 did not pass, so validation blueprint is not actionable.",
            "generated_file": "",
        }
    ]


def dependency_debt_rows() -> list[dict]:
    return [
        {
            "debt": "D1_dataset_selection",
            "status": "OPEN_FOR_GATE14",
            "description": "Need choose the first validation dataset or simulation source explicitly.",
            "next_test": "Gate 14 should start with a readiness check and then one validation domain.",
        },
        {
            "debt": "D2_real_graph_implementation",
            "status": "OPEN_FOR_GATE14",
            "description": "Need implement source graph construction on real catalog/simulation fields exactly as frozen here.",
            "next_test": "write graph builder that produces D/B/E predictions before residual comparison.",
        },
        {
            "debt": "D3_pressure_proxy_availability",
            "status": "WATCH",
            "description": "If p_b is unavailable in cold systems, protocol uses rho_set=rho_b fallback.",
            "next_test": "validation script must record whether pressure channel was available or fallback used.",
        },
        {
            "debt": "D4_background_normalization_choice",
            "status": "OPEN_FOR_GATE14",
            "description": "Need choose background normalization sample for each validation domain before comparison.",
            "next_test": "Gate 14 readiness check must freeze background sample.",
        },
        {
            "debt": "D5_validation_outcome_risk",
            "status": "HONEST_RISK",
            "description": "Protocol may fail against data; failure must be reported rather than retuned.",
            "next_test": "Gate 14 must include pass/fail and ablation controls.",
        },
    ]


def verdict_row(protocol_hash: str, checks: list[dict], smoke_rows: list[dict]) -> dict:
    checks_pass = all(r["pass"] for r in checks)
    smoke_pass = all(r["synthetic_only"] and r["local_metric_guardrail"] == "E_absent_from_local_metric_source" for r in smoke_rows)
    hash_pass = isinstance(protocol_hash, str) and len(protocol_hash) == 64
    ok = checks_pass and smoke_pass and hash_pass

    return {
        "verdict": "BLIND_PREDICTION_PROTOCOL_FROZEN_READY_FOR_DATA_FACING_GATE14" if ok else "BLIND_PREDICTION_PROTOCOL_REQUIRES_REVISION",
        "claim_boundary": "protocol-freeze audit only; not SPARC/RAR fit, not cluster solution, not kSZ prediction, not data validation, and not completed gravity",
        "protocol_version": PROTOCOL_VERSION,
        "protocol_hash_sha256": protocol_hash,
        "selected_D_proxy": D_PROXY,
        "selected_B_proxy": B_PROXY,
        "selected_scale": SCALE_SELECTOR,
        "selected_E_law": E_LAW,
        "selected_E_attachment": E_ATTACHMENT,
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_SPARC_or_RAR_data": False,
        "uses_cluster_data": False,
        "uses_kSZ_data": False,
        "checks_pass": checks_pass,
        "hash_pass": hash_pass,
        "smoke_prediction_pass": smoke_pass,
        "no_retuning_firewall_active": True,
        "background_aS_m_s2_at_H0_70": A_S_BACKGROUND,
        "main_result": "The blind prediction protocol is frozen: allowed inputs, forbidden inputs, D/B computation, graph rules, scale fractions, E outputs, and no-retuning firewall are sealed before validation.",
        "paper_safe_sentence": (
            "GRAV_TRAJ_13 freezes the pre-data prediction protocol for the SFT gravity trajectory. "
            "The locked protocol computes rho_set from the operation-density proxy rho_b+3p_b/c^2 with a cold-system rho_b fallback, computes D by background-normalized smoothing, computes B from predeclared source-graph boundary conductance, uses r0=sqrt(GM/a_S) with fixed scale fractions for smoothing and regions, and then predicts E=sqrt(DB), a_eff=E a_S, r_t=r0/sqrt(E), and the deep-regime sqrt(E) deviation. "
            "Observed a0, rotation-curve residuals, SPARC/RAR residuals, cluster residuals, kSZ targets, fitted dark-halo parameters, post-hoc environment labels, best-fit kernel lengths, and per-object exponents are explicitly forbidden inputs. "
            "The protocol writes a SHA-256 hash and a no-retuning firewall, so any future Gate 14 validation must use the sealed recipe or report that the protocol was changed. "
            "This is readiness for blind validation, not an observational fit or a claim of empirical success."
        ),
        "next_gate": "GRAV_TRAJ_14 may begin data-facing validation only after choosing a specific dataset and confirming the protocol hash remains unchanged.",
    }


def save_plots(smoke_rows, checks):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # Smoke E values.
        plt.figure(figsize=(9,5))
        labels = [r["object_id"] for r in smoke_rows]
        vals = [r["E"] for r in smoke_rows]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("E=sqrt(D B)")
        plt.title("GRAV_TRAJ_13: synthetic smoke E predictions")
        plt.tight_layout()
        p = OUT/"grav_traj_13_smoke_E_predictions.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Smoke transition radii.
        plt.figure(figsize=(9,5))
        vals = [r["rt_kpc"] for r in smoke_rows]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.yscale("log")
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("r_t [kpc]")
        plt.title("GRAV_TRAJ_13: synthetic smoke transition radii")
        plt.tight_layout()
        p = OUT/"grav_traj_13_smoke_rt_predictions.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Checks.
        plt.figure(figsize=(10,5))
        labels = [r["check"] for r in checks]
        vals = [1 if r["pass"] else 0 for r in checks]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("pass flag")
        plt.title("GRAV_TRAJ_13: protocol lockbox checks")
        plt.tight_layout()
        p = OUT/"grav_traj_13_protocol_checks.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, freeze_rows, checks, smoke_rows, forbidden, debts, stack_rows, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_13: Blind Prediction Protocol Freeze\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Protocol hash\n\n")
    lines.append(f"`{verdict['protocol_hash_sha256']}`\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## Frozen protocol items\n\n")
    lines.append("| Item | value | locked |\n")
    lines.append("|---|---|---|\n")
    for r in freeze_rows:
        lines.append(f"| {r['item']} | {r['value']} | {r['locked']} |\n")

    lines.append("\n## Protocol checks\n\n")
    lines.append("| Check | pass | reason |\n")
    lines.append("|---|---|---|\n")
    for r in checks:
        lines.append(f"| {r['check']} | {r['pass']} | {r['reason']} |\n")

    lines.append("\n## Forbidden inputs\n\n")
    lines.append("| Input | reason |\n")
    lines.append("|---|---|\n")
    for r in forbidden:
        lines.append(f"| {r['input']} | {r['reason']} |\n")

    lines.append("\n## Synthetic smoke predictions\n\n")
    lines.append("| Object | D | B | E | sqrt(E) | r_t/r0 |\n")
    lines.append("|---|---:|---:|---:|---:|---:|\n")
    for r in smoke_rows:
        lines.append(f"| {r['object_id']} | {r['D']:.6f} | {r['B']:.6f} | {r['E']:.6f} | {r['sqrtE_deviation']:.6f} | {r['rt_over_r0']:.6f} |\n")

    lines.append("\n## Remaining debts\n\n")
    lines.append("| Debt | status | description |\n")
    lines.append("|---|---|---|\n")
    for r in debts:
        lines.append(f"| {r['debt']} | {r['status']} | {r['description']} |\n")

    lines.append("\n## Stack decision\n\n")
    for r in stack_rows:
        lines.append(f"- {r['stack_action']}: execute_gate14_now={r['execute_gate14_now']}. {r['reason']}\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    protocol = protocol_object()
    protocol_text = canonical_json(protocol)
    protocol_hash = sha256_text(protocol_text)

    smoke_rows = smoke_prediction_rows()
    checks = protocol_checks_rows(protocol, smoke_rows)
    freeze_rows = protocol_freeze_rows(protocol_hash)
    debts = dependency_debt_rows()
    verdict = verdict_row(protocol_hash, checks, smoke_rows)
    verdict_ok = verdict["verdict"] == "BLIND_PREDICTION_PROTOCOL_FROZEN_READY_FOR_DATA_FACING_GATE14"
    stack_rows = stack_decision_rows(verdict_ok)
    gate14_blueprint = gate14_blueprint_rows(protocol_hash) if verdict_ok else []

    # Write protocol lockbox files.
    (OUT/"grav_traj_13_protocol_freeze.json").write_text(json.dumps(protocol, indent=2, sort_keys=True), encoding="utf-8")
    (OUT/"grav_traj_13_protocol_hash.txt").write_text(protocol_hash + "\n", encoding="utf-8")

    write_csv(OUT/"grav_traj_13_allowed_inputs.csv", protocol["allowed_inputs"])
    write_csv(OUT/"grav_traj_13_forbidden_inputs.csv", protocol["forbidden_inputs"])
    write_csv(OUT/"grav_traj_13_D_computation_spec.csv", protocol["D_computation"])
    write_csv(OUT/"grav_traj_13_B_graph_spec.csv", protocol["B_graph"])
    write_csv(OUT/"grav_traj_13_scale_spec.csv", protocol["scale_spec"])
    write_csv(OUT/"grav_traj_13_prediction_output_schema.csv", protocol["prediction_outputs"])
    write_csv(OUT/"grav_traj_13_no_retuning_firewall.csv", protocol["no_retuning_firewall"])
    write_csv(OUT/"grav_traj_13_protocol_freeze_items.csv", freeze_rows)
    write_csv(OUT/"grav_traj_13_protocol_checks.csv", checks)
    write_csv(OUT/"grav_traj_13_synthetic_smoke_predictions.csv", smoke_rows)
    write_csv(OUT/"grav_traj_13_dependency_debts.csv", debts)
    write_csv(OUT/"grav_traj_13_stack_decision.csv", stack_rows)
    write_csv(OUT/"grav_traj_13_gate14_blueprint.csv", gate14_blueprint)
    write_csv(OUT/"grav_traj_13_verdict.csv", [verdict])

    plots = save_plots(smoke_rows, checks)
    write_report(
        OUT/"GRAV_TRAJ_13_blind_prediction_protocol_report.md",
        freeze_rows, checks, smoke_rows, protocol["forbidden_inputs"], debts, stack_rows, verdict
    )

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_13",
        "purpose": "freeze blind prediction protocol before data-facing validation",
        "claim_boundary": verdict["claim_boundary"],
        "verdict": verdict["verdict"],
        "protocol_hash_sha256": protocol_hash,
        "stack_decision": stack_rows,
        "files": [
            "grav_traj_13_protocol_freeze.json",
            "grav_traj_13_protocol_hash.txt",
            "grav_traj_13_allowed_inputs.csv",
            "grav_traj_13_forbidden_inputs.csv",
            "grav_traj_13_D_computation_spec.csv",
            "grav_traj_13_B_graph_spec.csv",
            "grav_traj_13_scale_spec.csv",
            "grav_traj_13_prediction_output_schema.csv",
            "grav_traj_13_no_retuning_firewall.csv",
            "grav_traj_13_protocol_freeze_items.csv",
            "grav_traj_13_protocol_checks.csv",
            "grav_traj_13_synthetic_smoke_predictions.csv",
            "grav_traj_13_dependency_debts.csv",
            "grav_traj_13_stack_decision.csv",
            "grav_traj_13_gate14_blueprint.csv",
            "grav_traj_13_verdict.csv",
            "GRAV_TRAJ_13_blind_prediction_protocol_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_13 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Freeze the blind prediction protocol before any data-facing validation.")
    print("  No observed a0, SPARC/RAR, galaxy data, cluster data, or kSZ data are used.")

    print("\nProtocol lockbox:")
    print(f"  protocol_version: {PROTOCOL_VERSION}")
    print(f"  protocol_hash_sha256: {protocol_hash}")
    print(f"  D_proxy: {D_PROXY}")
    print(f"  B_proxy: {B_PROXY}")
    print(f"  scale_selector: {SCALE_SELECTOR}")
    print(f"  E_law: {E_LAW}")
    print(f"  E_attachment: {E_ATTACHMENT}")
    print(f"  scale_fractions: ell_D={F_ELL_D}, ell_B={F_ELL_B}, region={F_REGION}")

    print("\nAllowed inputs:")
    for r in protocol["allowed_inputs"]:
        print(f"  {r['input']:34s} required={r['required']}  {r['description']}")

    print("\nForbidden inputs:")
    for r in protocol["forbidden_inputs"]:
        print(f"  {r['input']:34s} FORBIDDEN  {r['reason']}")

    print("\nProtocol checks:")
    for r in checks:
        print(
            f"  {r['check']:38s} PASS={r['pass']}  "
            f"value={r['value']}  required={r['required']}  {r['reason']}"
        )

    print("\nSynthetic smoke predictions:")
    for r in smoke_rows:
        print(
            f"  {r['object_id']:32s} "
            f"M={r['M_Msun']:.3e} Msun  D={r['D']:.3f}  B={r['B']:.3f}  "
            f"E={r['E']:.6f}  sqrtE={r['sqrtE_deviation']:.6f}  "
            f"r0={r['r0_kpc']:.6f} kpc  rt={r['rt_kpc']:.6f} kpc"
        )

    print("\nNo-retuning firewall:")
    for r in protocol["no_retuning_firewall"]:
        print(f"  {r['firewall']:34s} locked={r['locked']}  {r['reason']}")

    print("\nRemaining debts:")
    for r in debts:
        print(f"  {r['debt']:38s} {r['status']:18s} {r['description']}")

    print("\nStack decision:")
    for r in stack_rows:
        print(f"  {r['stack_action']}: execute_gate14_now={r['execute_gate14_now']}  reason={r['reason']}")

    if gate14_blueprint:
        print("\nGate 14 blueprint emitted:")
        for r in gate14_blueprint:
            print(f"  {r['gate14_item']:34s} {r['description']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_13_blind_prediction_protocol_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_13_verdict.csv'}")
    print(f"  protocol json: {OUT/'grav_traj_13_protocol_freeze.json'}")
    print(f"  protocol hash: {OUT/'grav_traj_13_protocol_hash.txt'}")
    print(f"  checks csv: {OUT/'grav_traj_13_protocol_checks.csv'}")
    print(f"  forbidden inputs csv: {OUT/'grav_traj_13_forbidden_inputs.csv'}")
    print(f"  smoke predictions csv: {OUT/'grav_traj_13_synthetic_smoke_predictions.csv'}")
    print(f"  stack decision csv: {OUT/'grav_traj_13_stack_decision.csv'}")
    print(f"  Gate14 blueprint csv: {OUT/'grav_traj_13_gate14_blueprint.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
