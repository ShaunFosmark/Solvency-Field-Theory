#!/usr/bin/env python3
"""
SFT GRAV_TRAJ_11:
Far-Field Environment Attachment / Local Metric Preservation Audit

Purpose
-------
GRAV_TRAJ_09 selected:

    E = sqrt(D B)

GRAV_TRAJ_10 froze synthetic computable estimators for D and B.

GRAV_TRAJ_11 now audits the safety condition:

    E may deform the far-field settlement handoff,
    but E must NOT corrupt the local weak-field metric closure earned in GRAV_TRAJ_02.

The local closure to preserve is:

    F = exp(-phi)
    B = exp(+phi)
    F B = 1
    gamma = 1
    beta = 1

The permitted attachment is:

    a_eff = E a_S(t)

with transition radius:

    r_t(E) = sqrt(GM/(E a_S))

and a dimensionless handoff kernel, for audit purposes:

    g(r) = g_N sqrt(1 + (r/r_t)^2)

so:
    near field r << r_t:
        g/g_N -> 1

    deep field r >> r_t:
        g -> sqrt(g_N E a_S)

This is MOND-like but not universal MOND:
    universal deep amplitude shifts by sqrt(E).

Claim boundary
--------------
A pass means:
    E survives as a far-field-only transition modifier that preserves
    local FB=1 metric closure and near-field Newtonian behavior.

A pass does NOT mean:
    SFT fits SPARC/RAR,
    SFT solves clusters,
    SFT predicts kSZ,
    SFT derives final physical D/B observables,
    or SFT completes nonlinear gravity.

Stacking decision
-----------------
This script may emit a GRAV_TRAJ_12 blueprint if GRAV_TRAJ_11 passes.
It does NOT automatically execute GRAV_TRAJ_12, because Gate 12 requires
choosing physical rho_set and C_boundary observable proxies. That choice
should be explicit and frozen before data.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path("SFT_GRAV_TRAJ_11_OUTPUT")

# Numerical audit constants.
PHI_VALUES = [1e-8, 1e-6, 1e-4, 1e-3]
NEAR_X_VALUES = [1e-4, 1e-3, 1e-2]  # x = r/r_t
FAR_X_VALUES = [1e2, 1e3, 1e4]
LOCAL_TOL_FB = 1e-12
LOCAL_TOL_PPN = 1e-12
NEAR_TOL = 1e-4
FAR_TOL = 1e-3

# Synthetic background acceleration only for dimensional labels.
C = 299_792_458.0
MPC = 3.0856775814913673e22
H0_FID_KM_S_MPC = 70.0
H0_FID = H0_FID_KM_S_MPC * 1000.0 / MPC
A_S_BACKGROUND = C * H0_FID / (2.0 * math.pi)


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for k in row:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def read_csv_rows(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def load_E_profiles() -> tuple[list[dict], str]:
    """
    Prefer real Gate10 output if it is in the working directory.
    Otherwise use the frozen Gate10 central values as a fallback.
    """
    candidates = [
        Path("SFT_GRAV_TRAJ_10_OUTPUT/grav_traj_10_environment_summary.csv"),
        Path("grav_traj_10_environment_summary.csv"),
        Path("../SFT_GRAV_TRAJ_10_OUTPUT/grav_traj_10_environment_summary.csv"),
    ]
    for p in candidates:
        if p.exists():
            rows = []
            for r in read_csv_rows(p):
                rows.append({
                    "environment": r["environment"],
                    "D": float(r.get("D_mean_central", r.get("D_mean_all", 1.0))),
                    "B": float(r.get("B_mean_central", r.get("B_mean_all", 1.0))),
                    "E": float(r.get("E_mean_central", r.get("E_mean_all", 1.0))),
                    "source": str(p),
                })
            return rows, f"loaded_from_{p}"

    fallback = [
        ("homogeneous_background", 0.997760, 1.282446, 1.127057),
        ("dense_connected_synthetic", 4.674410, 3.360226, 3.706931),
        ("underconnected_void_synthetic", 0.509480, 1.263604, 0.781889),
        ("dense_but_boundary_screened_synthetic", 5.320107, 1.134998, 2.300403),
        ("diffuse_but_overconnected_synthetic", 0.575371, 1.798944, 0.979483),
        ("filamentary_connected_synthetic", 2.525657, 2.474249, 2.450257),
        ("strong_cluster_like_synthetic", 9.287662, 8.706690, 7.665444),
    ]
    rows = [{"environment": n, "D": D, "B": B, "E": E, "source": "fallback_gate10_central_values"} for n, D, B, E in fallback]
    return rows, "fallback_gate10_central_values"


# ------------------------------------------------------------
# Attachment models
# ------------------------------------------------------------

def attachment_candidate_rows() -> list[dict]:
    """
    Define candidate ways E could enter gravity. Only one should survive:
        far_field_transition_only.
    """
    rows = [
        {
            "candidate": "far_field_transition_only",
            "description": "E enters only a_eff=E a_S and r_t=sqrt(GM/(E a_S)); local metric F=exp(-phi), B=exp(phi) unchanged.",
            "E_in_metric_potential": False,
            "E_in_spatial_metric_alpha": False,
            "E_in_source_mass": False,
            "E_in_transition_radius": True,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "status_expected": "PRIMARY_ATTACHMENT",
        },
        {
            "candidate": "metric_potential_scaled_by_E",
            "description": "phi -> E phi inside F and B; preserves FB if both scale, but changes local source strength/G.",
            "E_in_metric_potential": True,
            "E_in_spatial_metric_alpha": False,
            "E_in_source_mass": False,
            "E_in_transition_radius": False,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "status_expected": "REJECT_LOCAL_SOURCE_RENORMALIZATION",
        },
        {
            "candidate": "spatial_metric_alpha_scaled_by_E",
            "description": "B=exp(E phi) while F=exp(-phi); breaks FB=1 and gamma=1 for E != 1.",
            "E_in_metric_potential": False,
            "E_in_spatial_metric_alpha": True,
            "E_in_source_mass": False,
            "E_in_transition_radius": False,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "status_expected": "REJECT_BREAKS_FB_AND_GAMMA",
        },
        {
            "candidate": "source_mass_scaled_by_E",
            "description": "M -> E M locally; changes near-field Newtonian acceleration and violates source conservation.",
            "E_in_metric_potential": False,
            "E_in_spatial_metric_alpha": False,
            "E_in_source_mass": True,
            "E_in_transition_radius": False,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "status_expected": "REJECT_LOCAL_SOURCE_RENORMALIZATION",
        },
        {
            "candidate": "additive_acceleration_floor",
            "description": "g=g_N+sqrt(g_N E a_S); bypasses metric closure and injects nonlocal acceleration term directly.",
            "E_in_metric_potential": False,
            "E_in_spatial_metric_alpha": False,
            "E_in_source_mass": False,
            "E_in_transition_radius": False,
            "has_free_parameter": False,
            "uses_target_residual": False,
            "status_expected": "REJECT_BYPASSES_TRANSITION_KERNEL",
        },
        {
            "candidate": "target_residual_metric_patch",
            "description": "Modify metric/source by fitted residuals; forbidden before blind data protocol.",
            "E_in_metric_potential": True,
            "E_in_spatial_metric_alpha": True,
            "E_in_source_mass": True,
            "E_in_transition_radius": True,
            "has_free_parameter": True,
            "uses_target_residual": True,
            "status_expected": "FORBIDDEN_TARGET_CONTROL",
        },
    ]
    return rows


def metric_scales(candidate: str, E: float) -> tuple[float, float, float, str]:
    """
    Return local time-potential scale sF, spatial-potential scale sB,
    local source acceleration scale sG, and comment.

    F=exp(-sF phi), B=exp(+sB phi).
    Local Newtonian source acceleration scales with sG.
    """
    if candidate == "far_field_transition_only":
        return 1.0, 1.0, 1.0, "E absent from local metric/source"
    if candidate == "metric_potential_scaled_by_E":
        return E, E, E, "FB remains reciprocal but local source strength scales with E"
    if candidate == "spatial_metric_alpha_scaled_by_E":
        return 1.0, E, 1.0, "spatial closure alpha becomes E"
    if candidate == "source_mass_scaled_by_E":
        return E, E, E, "equivalent local source mass/G scaling"
    if candidate == "additive_acceleration_floor":
        return 1.0, 1.0, 1.0, "metric formally unchanged but acceleration injected outside closure"
    if candidate == "target_residual_metric_patch":
        return E, E, E, "target-fitted metric/source patch"
    raise ValueError(candidate)


def metric_closure_rows(E_profiles: list[dict]) -> list[dict]:
    rows = []
    for cand in attachment_candidate_rows():
        name = cand["candidate"]
        for prof in E_profiles:
            E = prof["E"]
            sF, sB, sG, comment = metric_scales(name, E)
            gamma = sB/sF if sF != 0 else float("nan")
            beta = 1.0  # exponential time-potential skeleton retains beta marker if local potential is not target patched
            for phi in PHI_VALUES:
                F = math.exp(-sF*phi)
                B = math.exp(+sB*phi)
                FB = F*B
                rows.append({
                    "candidate": name,
                    "environment": prof["environment"],
                    "E": E,
                    "phi": phi,
                    "sF_time_potential_scale": sF,
                    "sB_spatial_potential_scale": sB,
                    "local_source_scale": sG,
                    "F": F,
                    "B": B,
                    "FB": FB,
                    "FB_minus_1": FB - 1.0,
                    "gamma_marker": gamma,
                    "beta_marker": beta,
                    "FB_pass": abs(FB - 1.0) < LOCAL_TOL_FB,
                    "gamma_pass": abs(gamma - 1.0) < LOCAL_TOL_PPN,
                    "beta_pass": abs(beta - 1.0) < LOCAL_TOL_PPN,
                    "local_source_invariant_pass": abs(sG - 1.0) < LOCAL_TOL_PPN,
                    "comment": comment,
                })
    return rows


# ------------------------------------------------------------
# Transition kernel checks
# ------------------------------------------------------------

def primary_transition_kernel(x: float) -> float:
    # g/g_N as function of x=r/r_t.
    return math.sqrt(1.0 + x*x)


def transition_kernel_rows(E_profiles: list[dict]) -> list[dict]:
    rows = []
    for prof in E_profiles:
        E = prof["E"]
        rt_factor = 1.0 / math.sqrt(max(E, 1e-300))
        deep_factor = math.sqrt(max(E, 0.0))

        # Near field.
        for x in NEAR_X_VALUES:
            ratio = primary_transition_kernel(x)
            rows.append({
                "environment": prof["environment"],
                "E": E,
                "regime": "near",
                "x_r_over_rt": x,
                "g_over_gN": ratio,
                "near_error_from_Newtonian": ratio - 1.0,
                "near_pass": abs(ratio - 1.0) < NEAR_TOL,
                "deep_env_ratio": None,
                "far_pass": None,
                "transition_radius_factor": rt_factor,
                "deep_universal_deviation_sqrtE": deep_factor,
            })

        # Far/deep field.
        # g / sqrt(g_N E aS) = sqrt(1+x^2)/x.
        for x in FAR_X_VALUES:
            env_ratio = primary_transition_kernel(x) / x
            rows.append({
                "environment": prof["environment"],
                "E": E,
                "regime": "far",
                "x_r_over_rt": x,
                "g_over_gN": primary_transition_kernel(x),
                "near_error_from_Newtonian": None,
                "near_pass": None,
                "deep_env_ratio": env_ratio,
                "far_pass": abs(env_ratio - 1.0) < FAR_TOL,
                "transition_radius_factor": rt_factor,
                "deep_universal_deviation_sqrtE": deep_factor,
            })
    return rows


def near_field_preservation_rows(E_profiles: list[dict]) -> list[dict]:
    rows = []
    candidates = [r["candidate"] for r in attachment_candidate_rows()]
    for cand in candidates:
        for prof in E_profiles:
            E = prof["E"]
            sF, sB, sG, comment = metric_scales(cand, E)

            # local Newtonian metric/source ratio at r/r_t -> 0.
            if cand == "far_field_transition_only":
                local_g_ratio = 1.0
                reason = "E enters only r_t/a_eff, so local limit is unchanged"
            elif cand in ["metric_potential_scaled_by_E", "source_mass_scaled_by_E", "target_residual_metric_patch"]:
                local_g_ratio = sG
                reason = "local source/potential strength is renormalized by E"
            elif cand == "spatial_metric_alpha_scaled_by_E":
                local_g_ratio = 1.0
                reason = "local acceleration may remain but spatial PPN closure fails"
            elif cand == "additive_acceleration_floor":
                # Evaluate a representative local correction at x=1e-2; not source invariant in kernel role.
                local_g_ratio = 1.0 + math.sqrt(E)*1e-2
                reason = "injects direct acceleration term instead of transition-kernel deformation"
            else:
                local_g_ratio = float("nan")
                reason = "unknown"

            rows.append({
                "candidate": cand,
                "environment": prof["environment"],
                "E": E,
                "local_g_ratio_to_GRAV02_Newtonian": local_g_ratio,
                "local_metric_FB_expected": "unchanged" if cand == "far_field_transition_only" else "changed_or_bypassed",
                "local_g_invariant_pass": abs(local_g_ratio - 1.0) < NEAR_TOL,
                "reason": reason,
            })
    return rows


def candidate_score_rows(metric_rows, transition_rows, near_rows) -> list[dict]:
    rows = []
    for cand in attachment_candidate_rows():
        name = cand["candidate"]
        m = [r for r in metric_rows if r["candidate"] == name]
        n = [r for r in near_rows if r["candidate"] == name]

        FB_pass = all(r["FB_pass"] for r in m)
        gamma_pass = all(r["gamma_pass"] for r in m)
        beta_pass = all(r["beta_pass"] for r in m)
        local_source_pass = all(r["local_source_invariant_pass"] for r in m)
        local_g_pass = all(r["local_g_invariant_pass"] for r in n)

        if name == "far_field_transition_only":
            near_kernel_pass = all(r["near_pass"] for r in transition_rows if r["regime"] == "near")
            far_kernel_pass = all(r["far_pass"] for r in transition_rows if r["regime"] == "far")
            E_enters_only_transition_pass = True
        else:
            near_kernel_pass = False
            far_kernel_pass = False
            E_enters_only_transition_pass = False

        no_target_pass = not cand["uses_target_residual"]
        no_free_parameter_pass = not cand["has_free_parameter"]

        flags = [
            FB_pass,
            gamma_pass,
            beta_pass,
            local_source_pass,
            local_g_pass,
            near_kernel_pass,
            far_kernel_pass,
            E_enters_only_transition_pass,
            no_target_pass,
            no_free_parameter_pass,
        ]
        score = sum(flags) / len(flags)

        if name == "far_field_transition_only" and score == 1.0:
            status = "PRIMARY_FAR_FIELD_ONLY_ATTACHMENT"
        elif cand["uses_target_residual"]:
            status = "FORBIDDEN_TARGET_CONTROL"
        elif not FB_pass or not gamma_pass:
            status = "REJECT_BREAKS_LOCAL_METRIC_CLOSURE"
        elif not local_source_pass or not local_g_pass:
            status = "REJECT_RENORMALIZES_LOCAL_SOURCE"
        else:
            status = "REJECT_BYPASSES_OR_MISPLACES_ENVIRONMENT_CHANNEL"

        rows.append({
            "candidate": name,
            "description": cand["description"],
            "FB_pass": FB_pass,
            "gamma_pass": gamma_pass,
            "beta_pass": beta_pass,
            "local_source_invariant_pass": local_source_pass,
            "local_g_invariant_pass": local_g_pass,
            "near_transition_kernel_pass": near_kernel_pass,
            "deep_transition_kernel_pass": far_kernel_pass,
            "E_enters_only_transition_pass": E_enters_only_transition_pass,
            "no_target_pass": no_target_pass,
            "no_free_parameter_pass": no_free_parameter_pass,
            "internal_score": score,
            "status": status,
        })
    return rows


def control_rows(candidate_scores) -> list[dict]:
    rows = []
    for r in candidate_scores:
        if r["status"] == "PRIMARY_FAR_FIELD_ONLY_ATTACHMENT":
            reason = "E modifies a_eff/r_t only; local FB=1, gamma=1, beta=1, and local source strength are preserved"
        elif r["status"] == "FORBIDDEN_TARGET_CONTROL":
            reason = "target residual or post-hoc metric patch is forbidden before blind prediction protocol"
        elif r["status"] == "REJECT_BREAKS_LOCAL_METRIC_CLOSURE":
            reason = "candidate fails FB=1 and/or gamma=1 local metric closure"
        elif r["status"] == "REJECT_RENORMALIZES_LOCAL_SOURCE":
            reason = "candidate changes local Newtonian source strength or effective G"
        else:
            reason = "candidate bypasses the declared transition handoff channel or places E in the wrong sector"
        rows.append({
            "candidate": r["candidate"],
            "status": r["status"],
            "score": r["internal_score"],
            "reason": reason,
        })
    return rows


def dependency_debt_rows() -> list[dict]:
    return [
        {
            "debt": "D1_physical_D_B_observables",
            "status": "OPEN",
            "description": "Need map synthetic D and B to physical, pre-registered observables.",
            "next_test": "GRAV_TRAJ_12 should select rho_set and C_boundary proxies without observing residuals.",
        },
        {
            "debt": "D2_kernel_scale_derivation",
            "status": "OPEN",
            "description": "Need derive ell_D, ell_B, and region radius from SFT scales or source geometry.",
            "next_test": "derive smoothing scales from r_t, source compactness, graph scale, or no-overwrite ledger scale.",
        },
        {
            "debt": "D3_transition_kernel_derivation",
            "status": "PARTIALLY_CONSTRAINED",
            "description": "This audit uses the GRAV_TRAJ_04 handoff kernel form as a test scaffold; a deeper derivation remains open.",
            "next_test": "derive the handoff kernel from settlement diffusion or no-overwrite relaxation.",
        },
        {
            "debt": "D4_non_linear_metric_completion",
            "status": "OPEN",
            "description": "Local weak-field FB=1 is preserved here, but full nonlinear field equations remain open.",
            "next_test": "only after D/B and transition kernel are frozen, test full metric behavior.",
        },
        {
            "debt": "D5_blind_data_protocol",
            "status": "DEFERRED",
            "description": "SPARC/RAR/cluster/kSZ comparisons remain forbidden until physical D/B observables and scales are frozen.",
            "next_test": "pre-register the prediction recipe before any comparison.",
        },
    ]


def gate12_blueprint_rows() -> list[dict]:
    return [
        {
            "gate12_item": "rho_set_candidate_baryonic_source_density",
            "role": "D observable candidate",
            "definition": "rho_set proportional to smoothed baryonic mass/source density",
            "risk": "may miss radiation/pressure/operation-density channels",
            "freeze_requirement": "choose smoothing and normalization before comparing residuals",
        },
        {
            "gate12_item": "rho_set_candidate_operation_density",
            "role": "D observable candidate",
            "definition": "rho_set proportional to rho+3p or an SFT operation-density proxy",
            "risk": "requires pressure/phase-state estimate in nonrelativistic systems",
            "freeze_requirement": "derive proxy from available fields without residual fitting",
        },
        {
            "gate12_item": "rho_set_candidate_simulation_settlement_demand",
            "role": "D observable candidate",
            "definition": "rho_set from simulation-derived source/settlement demand field",
            "risk": "simulation assumptions may import LCDM priors",
            "freeze_requirement": "state which fields are allowed before test",
        },
        {
            "gate12_item": "C_boundary_candidate_graph_conductance",
            "role": "B observable candidate",
            "definition": "boundary cut conductance on a source graph or settlement graph",
            "risk": "graph construction could become tunable",
            "freeze_requirement": "freeze nodes, edges, weights, and region rule before data",
        },
        {
            "gate12_item": "C_boundary_candidate_tidal_filament_connectivity",
            "role": "B observable candidate",
            "definition": "connectivity from cosmic-web/tidal/filament graph structure",
            "risk": "environment catalogs may be noisy or method-dependent",
            "freeze_requirement": "choose one catalog/procedure before residual comparison",
        },
        {
            "gate12_item": "kernel_scale_candidate_transition_radius",
            "role": "scale selector",
            "definition": "ell_D, ell_B tied to r_t or source-size fraction",
            "risk": "r_t depends on E if solved implicitly",
            "freeze_requirement": "define explicit fixed-point or background-scale procedure",
        },
        {
            "gate12_item": "local_metric_preservation_constraint",
            "role": "hard constraint",
            "definition": "E may enter only a_eff/r_t, not F, B, local source mass, or alpha",
            "risk": "none; this is now a guardrail from GRAV_TRAJ_11",
            "freeze_requirement": "all future D/B models must preserve FB=1 locally",
        },
    ]


def stack_decision_rows(verdict_ok: bool) -> list[dict]:
    if verdict_ok:
        return [
            {
                "stack_action": "WRITE_GATE12_BLUEPRINT_ONLY",
                "execute_gate12_now": False,
                "reason": "Gate 11 can identify the next gate, but Gate 12 requires explicit physical D/B observable choices; auto-running it would freeze assumptions without review.",
                "generated_file": "grav_traj_11_gate12_blueprint.csv",
            }
        ]
    return [
        {
            "stack_action": "DO_NOT_STACK",
            "execute_gate12_now": False,
            "reason": "Gate 11 did not pass, so Gate 12 should not be prepared.",
            "generated_file": "",
        }
    ]


def verdict_row(E_profiles, candidate_scores, metric_rows, transition_rows, near_rows):
    primary = next(r for r in candidate_scores if r["candidate"] == "far_field_transition_only")
    forbidden = next(r for r in candidate_scores if r["candidate"] == "target_residual_metric_patch")

    primary_pass = primary["status"] == "PRIMARY_FAR_FIELD_ONLY_ATTACHMENT" and abs(primary["internal_score"] - 1.0) < 1e-12
    forbidden_marked = forbidden["status"] == "FORBIDDEN_TARGET_CONTROL"
    local_metric_pass = all(r["FB_pass"] and r["gamma_pass"] and r["beta_pass"] and r["local_source_invariant_pass"]
                            for r in metric_rows if r["candidate"] == "far_field_transition_only")
    near_pass = all(r["near_pass"] for r in transition_rows if r["regime"] == "near")
    far_pass = all(r["far_pass"] for r in transition_rows if r["regime"] == "far")
    control_rejections_pass = all(
        r["status"] in [
            "PRIMARY_FAR_FIELD_ONLY_ATTACHMENT",
            "FORBIDDEN_TARGET_CONTROL",
            "REJECT_BREAKS_LOCAL_METRIC_CLOSURE",
            "REJECT_RENORMALIZES_LOCAL_SOURCE",
            "REJECT_BYPASSES_OR_MISPLACES_ENVIRONMENT_CHANNEL",
        ]
        for r in candidate_scores
    )
    positive_E_pass = all(r["E"] > 0 and math.isfinite(r["E"]) for r in E_profiles)

    ok = primary_pass and forbidden_marked and local_metric_pass and near_pass and far_pass and control_rejections_pass and positive_E_pass

    return {
        "verdict": "FAR_FIELD_ONLY_E_ATTACHMENT_PRESERVES_LOCAL_METRIC_CLOSURE" if ok else "E_ATTACHMENT_REQUIRES_REVISION",
        "claim_boundary": "attachment-safety audit only; not SPARC/RAR fit, not cluster solution, not kSZ prediction, not final D/B observables, and not completed nonlinear gravity",
        "selected_attachment": "E enters only a_eff=E a_S(t) and r_t=sqrt(GM/(E a_S)); local F=exp(-phi), B=exp(phi), FB=1 unchanged",
        "selected_transition_kernel": "g/g_N=sqrt(1+(r/r_t)^2) audit scaffold",
        "uses_observed_a0": False,
        "uses_galaxy_data": False,
        "uses_SPARC_or_RAR_data": False,
        "uses_cluster_data": False,
        "uses_kSZ_data": False,
        "primary_attachment_pass": primary_pass,
        "local_metric_closure_pass": local_metric_pass,
        "near_field_preservation_pass": near_pass,
        "deep_environment_transition_pass": far_pass,
        "forbidden_target_control_marked": forbidden_marked,
        "control_rejections_pass": control_rejections_pass,
        "positive_E_profiles_pass": positive_E_pass,
        "background_aS_m_s2_at_H0_70": A_S_BACKGROUND,
        "main_result": "E can be attached only to the far-field settlement handoff while preserving local FB=1 metric closure and Newtonian near-field behavior.",
        "paper_safe_sentence": (
            "GRAV_TRAJ_11 audits where the environment factor may enter the gravity trajectory. "
            "The surviving attachment places E only in the far-field settlement handoff, a_eff=E a_S(t), so r_t(E)=sqrt(GM/(E a_S)), while the local weak-field metric closure remains F=exp(-phi), B=exp(+phi), FB=1 with gamma=1 and beta=1. "
            "In the audit kernel g/g_N=sqrt(1+(r/r_t)^2), the near-field limit remains Newtonian, g/g_N -> 1, while the deep-regime amplitude becomes sqrt(g_N E a_S), giving the GRAV_TRAJ_09 sqrt(E) non-universal deviation channel. "
            "Controls that place E inside the metric potential, spatial closure alpha, local source mass, additive acceleration floor, or target-fitted residuals fail because they break local closure, renormalize the local source, bypass the declared handoff, or violate the no-target boundary. "
            "Thus E is allowed as a far-field-only settlement transition modifier, not as a local metric or source renormalization."
        ),
        "next_gate": "GRAV_TRAJ_12 should select physical rho_set and C_boundary observable proxies, using the Gate 11 guardrail that E may enter only the far-field handoff.",
    }


def save_plots(E_profiles, candidate_scores, transition_rows, near_rows):
    plots = []
    try:
        import matplotlib.pyplot as plt

        # Candidate scores.
        plt.figure(figsize=(10,5))
        labels = [r["candidate"] for r in candidate_scores]
        vals = [r["internal_score"] for r in candidate_scores]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("internal attachment score")
        plt.title("GRAV_TRAJ_11: E attachment candidate scores")
        plt.tight_layout()
        p = OUT/"grav_traj_11_attachment_candidate_scores.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # E profiles.
        plt.figure(figsize=(10,5))
        labels = [r["environment"] for r in E_profiles]
        vals = [r["E"] for r in E_profiles]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("E")
        plt.title("GRAV_TRAJ_11: E profiles used for attachment audit")
        plt.tight_layout()
        p = OUT/"grav_traj_11_E_profiles.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Near field errors.
        near = [r for r in transition_rows if r["regime"] == "near"]
        plt.figure(figsize=(8,5))
        for env in sorted(set(r["environment"] for r in near)):
            sub = [r for r in near if r["environment"] == env]
            plt.loglog([r["x_r_over_rt"] for r in sub], [abs(r["near_error_from_Newtonian"]) for r in sub], marker="o", label=env[:18])
        plt.axhline(NEAR_TOL, linestyle="--", linewidth=1)
        plt.xlabel("x=r/r_t")
        plt.ylabel("|g/gN - 1|")
        plt.title("GRAV_TRAJ_11: near-field preservation")
        plt.legend(fontsize=6)
        plt.tight_layout()
        p = OUT/"grav_traj_11_near_field_errors.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

        # Deep deviations sqrt(E).
        plt.figure(figsize=(10,5))
        labels = [r["environment"] for r in E_profiles]
        vals = [math.sqrt(r["E"]) for r in E_profiles]
        x = np.arange(len(labels))
        plt.scatter(x, vals)
        plt.axhline(1.0, linestyle="--", linewidth=1)
        plt.xticks(x, labels, rotation=45, ha="right", fontsize=8)
        plt.ylabel("deep universal deviation sqrt(E)")
        plt.title("GRAV_TRAJ_11: far-field-only environment deviation")
        plt.tight_layout()
        p = OUT/"grav_traj_11_deep_sqrtE_deviation.png"
        plt.savefig(p, dpi=160)
        plt.close()
        plots.append(str(p))

    except Exception as e:
        print(f"[plot warning] {e}")
    return plots


def write_report(path, E_profiles, candidate_scores, transition_rows, controls, debts, stack_rows, verdict):
    lines = []
    lines.append("# SFT GRAV_TRAJ_11: Far-Field E Attachment / Local Metric Preservation Audit\n\n")
    lines.append("## Verdict\n\n")
    lines.append(f"**{verdict['verdict']}**\n\n")
    lines.append(verdict["paper_safe_sentence"] + "\n\n")
    lines.append("## Claim boundary\n\n")
    lines.append(verdict["claim_boundary"] + "\n\n")

    lines.append("## E profiles\n\n")
    lines.append("| Environment | D | B | E | sqrt(E) |\n")
    lines.append("|---|---:|---:|---:|---:|\n")
    for r in E_profiles:
        lines.append(f"| {r['environment']} | {r['D']:.6f} | {r['B']:.6f} | {r['E']:.6f} | {math.sqrt(r['E']):.6f} |\n")

    lines.append("\n## Attachment candidates\n\n")
    lines.append("| Candidate | score | status |\n")
    lines.append("|---|---:|---|\n")
    for r in candidate_scores:
        lines.append(f"| {r['candidate']} | {r['internal_score']:.3f} | {r['status']} |\n")

    lines.append("\n## Transition kernel summary\n\n")
    lines.append("| Regime | max error | pass |\n")
    lines.append("|---|---:|---|\n")
    near = [r for r in transition_rows if r["regime"] == "near"]
    far = [r for r in transition_rows if r["regime"] == "far"]
    lines.append(f"| near g/gN -> 1 | {max(abs(r['near_error_from_Newtonian']) for r in near):.6e} | {all(r['near_pass'] for r in near)} |\n")
    lines.append(f"| far g/sqrt(gN E aS) -> 1 | {max(abs(r['deep_env_ratio']-1.0) for r in far):.6e} | {all(r['far_pass'] for r in far)} |\n")

    lines.append("\n## Controls\n\n")
    lines.append("| Candidate | status | reason |\n")
    lines.append("|---|---|---|\n")
    for r in controls:
        lines.append(f"| {r['candidate']} | {r['status']} | {r['reason']} |\n")

    lines.append("\n## Remaining debts\n\n")
    lines.append("| Debt | status | description |\n")
    lines.append("|---|---|---|\n")
    for r in debts:
        lines.append(f"| {r['debt']} | {r['status']} | {r['description']} |\n")

    lines.append("\n## Stack decision\n\n")
    for r in stack_rows:
        lines.append(f"- {r['stack_action']}: execute_gate12_now={r['execute_gate12_now']}. {r['reason']}\n")

    lines.append("\n## Next gate\n\n")
    lines.append(verdict["next_gate"] + "\n")
    path.write_text("".join(lines), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    E_profiles, E_source = load_E_profiles()
    attachment_candidates = attachment_candidate_rows()
    metric_rows = metric_closure_rows(E_profiles)
    transition_rows = transition_kernel_rows(E_profiles)
    near_rows = near_field_preservation_rows(E_profiles)
    candidate_scores = candidate_score_rows(metric_rows, transition_rows, near_rows)
    controls = control_rows(candidate_scores)
    debts = dependency_debt_rows()
    verdict = verdict_row(E_profiles, candidate_scores, metric_rows, transition_rows, near_rows)
    verdict_ok = verdict["verdict"] == "FAR_FIELD_ONLY_E_ATTACHMENT_PRESERVES_LOCAL_METRIC_CLOSURE"
    stack_rows = stack_decision_rows(verdict_ok)
    blueprint = gate12_blueprint_rows() if verdict_ok else []

    write_csv(OUT/"grav_traj_11_E_profiles.csv", E_profiles)
    write_csv(OUT/"grav_traj_11_attachment_candidates.csv", attachment_candidates)
    write_csv(OUT/"grav_traj_11_metric_closure_checks.csv", metric_rows)
    write_csv(OUT/"grav_traj_11_transition_kernel_checks.csv", transition_rows)
    write_csv(OUT/"grav_traj_11_near_field_preservation.csv", near_rows)
    write_csv(OUT/"grav_traj_11_candidate_scores.csv", candidate_scores)
    write_csv(OUT/"grav_traj_11_controls.csv", controls)
    write_csv(OUT/"grav_traj_11_dependency_debts.csv", debts)
    write_csv(OUT/"grav_traj_11_stack_decision.csv", stack_rows)
    write_csv(OUT/"grav_traj_11_gate12_blueprint.csv", blueprint)
    write_csv(OUT/"grav_traj_11_verdict.csv", [verdict])

    plots = save_plots(E_profiles, candidate_scores, transition_rows, near_rows)
    write_report(
        OUT/"GRAV_TRAJ_11_far_field_E_attachment_report.md",
        E_profiles, candidate_scores, transition_rows, controls, debts, stack_rows, verdict
    )

    (OUT/"MANIFEST.json").write_text(json.dumps({
        "gate": "GRAV_TRAJ_11",
        "purpose": "prove E attaches only to far-field transition and preserves local metric closure",
        "claim_boundary": verdict["claim_boundary"],
        "E_profile_source": E_source,
        "verdict": verdict["verdict"],
        "stack_decision": stack_rows,
        "files": [
            "grav_traj_11_E_profiles.csv",
            "grav_traj_11_attachment_candidates.csv",
            "grav_traj_11_metric_closure_checks.csv",
            "grav_traj_11_transition_kernel_checks.csv",
            "grav_traj_11_near_field_preservation.csv",
            "grav_traj_11_candidate_scores.csv",
            "grav_traj_11_controls.csv",
            "grav_traj_11_dependency_debts.csv",
            "grav_traj_11_stack_decision.csv",
            "grav_traj_11_gate12_blueprint.csv",
            "grav_traj_11_verdict.csv",
            "GRAV_TRAJ_11_far_field_E_attachment_report.md",
        ],
        "plots": plots,
    }, indent=2), encoding="utf-8")

    print("\nSFT GRAV_TRAJ_11 RESULTS")
    print("========================")
    print("\nPurpose:")
    print("  Audit that E attaches only to far-field settlement handoff and preserves local FB=1 metric closure.")
    print("  No observed a0, SPARC/RAR, galaxy data, cluster data, or kSZ data are used.")
    print(f"  E profile source: {E_source}")

    print("\nE profiles:")
    for r in E_profiles:
        print(
            f"  {r['environment']:42s}  "
            f"D={r['D']:.6f}  B={r['B']:.6f}  E={r['E']:.6f}  sqrtE={math.sqrt(r['E']):.6f}"
        )

    print("\nAttachment candidate audit:")
    for r in candidate_scores:
        print(
            f"  {r['candidate']:34s}  "
            f"score={r['internal_score']:.3f}  "
            f"FB={r['FB_pass']}  gamma={r['gamma_pass']}  source={r['local_source_invariant_pass']}  "
            f"near={r['near_transition_kernel_pass']}  deep={r['deep_transition_kernel_pass']}  "
            f"{r['status']}"
        )

    print("\nMetric closure summary:")
    primary_metric = [r for r in metric_rows if r["candidate"] == "far_field_transition_only"]
    print(f"  primary max |FB-1|: {max(abs(r['FB_minus_1']) for r in primary_metric):.3e}")
    print(f"  primary gamma pass all: {all(r['gamma_pass'] for r in primary_metric)}")
    print(f"  primary beta pass all: {all(r['beta_pass'] for r in primary_metric)}")
    print(f"  primary local source invariant all: {all(r['local_source_invariant_pass'] for r in primary_metric)}")

    print("\nTransition kernel summary:")
    near = [r for r in transition_rows if r["regime"] == "near"]
    far = [r for r in transition_rows if r["regime"] == "far"]
    print(f"  near max |g/gN - 1|: {max(abs(r['near_error_from_Newtonian']) for r in near):.6e}")
    print(f"  near pass all: {all(r['near_pass'] for r in near)}")
    print(f"  deep max |g/sqrt(gN E aS) - 1|: {max(abs(r['deep_env_ratio']-1.0) for r in far):.6e}")
    print(f"  deep pass all: {all(r['far_pass'] for r in far)}")

    print("\nControls:")
    for r in controls:
        print(
            f"  {r['candidate']:34s}  "
            f"score={r['score']:.3f}  "
            f"{r['status']}  "
            f"{r['reason']}"
        )

    print("\nRemaining debts:")
    for r in debts:
        print(f"  {r['debt']:36s}  {r['status']:24s}  {r['description']}")

    print("\nStack decision:")
    for r in stack_rows:
        print(f"  {r['stack_action']}: execute_gate12_now={r['execute_gate12_now']}  reason={r['reason']}")

    if blueprint:
        print("\nGate 12 blueprint emitted:")
        for r in blueprint:
            print(f"  {r['gate12_item']:48s}  {r['role']}")

    print("\nVerdict:")
    for k, v in verdict.items():
        print(f"  {k}: {v}")

    print("\nFiles:")
    print(f"  output directory: {OUT}")
    print(f"  report: {OUT/'GRAV_TRAJ_11_far_field_E_attachment_report.md'}")
    print(f"  verdict csv: {OUT/'grav_traj_11_verdict.csv'}")
    print(f"  E profiles csv: {OUT/'grav_traj_11_E_profiles.csv'}")
    print(f"  candidate scores csv: {OUT/'grav_traj_11_candidate_scores.csv'}")
    print(f"  metric closure checks csv: {OUT/'grav_traj_11_metric_closure_checks.csv'}")
    print(f"  transition kernel checks csv: {OUT/'grav_traj_11_transition_kernel_checks.csv'}")
    print(f"  near-field preservation csv: {OUT/'grav_traj_11_near_field_preservation.csv'}")
    print(f"  controls csv: {OUT/'grav_traj_11_controls.csv'}")
    print(f"  debts csv: {OUT/'grav_traj_11_dependency_debts.csv'}")
    print(f"  stack decision csv: {OUT/'grav_traj_11_stack_decision.csv'}")
    print(f"  Gate12 blueprint csv: {OUT/'grav_traj_11_gate12_blueprint.csv'}")
    for p in plots:
        print(f"  plot: {p}")


if __name__ == "__main__":
    main()
