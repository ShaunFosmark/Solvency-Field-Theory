# SFT V12.3 Gravity Trajectory Reproduction Pack

This pack preserves the core V12.3 gravity-trajectory gate scripts.

Scope:
- Included: GRAV_TRAJ gates 01 through 13.
- Included historical patch: Gate 08 and Gate 08R; use Gate 08R as the patched/authoritative Gate 08 run.
- Excluded: Gate 14 SPARC branch, old internal D/B/E SPARC branch, and Track2R morphology-readout restart branch.
- Excluded: generated outputs/plots. Whoever runs the scripts should generate their own outputs locally.

Claim boundary:
- This is a script preservation/reproduction pack, not a paper claim upgrade.
- Gates 01-13 define the V12.3 prevalidation spine.
- Gate 13 freezes the blind-prediction protocol boundary.
- SPARC lane work should be packaged separately.

Suggested run order:
1. SFT_GRAV_TRAJ_01_one_helix_lag_field_audit.py
2. SFT_GRAV_TRAJ_02_source_to_metric_closure_audit.py
3. SFT_GRAV_TRAJ_03_matter_radiation_source_continuity_audit.py
4. SFT_GRAV_TRAJ_04_settlement_transition_audit.py
5. SFT_GRAV_TRAJ_05_settlement_acceleration_scale_audit.py
6. SFT_GRAV_TRAJ_06_phase_cycle_coupling_audit.py
7. SFT_GRAV_TRAJ_07_H_settlement_rate_audit.py
8. SFT_GRAV_TRAJ_08R_H_of_t_settlement_radius_audit_PATCHED.py
9. SFT_GRAV_TRAJ_09_environment_factor_E_audit.py
10. SFT_GRAV_TRAJ_10_computable_D_B_estimators_audit.py
11. SFT_GRAV_TRAJ_11_far_field_E_attachment_audit.py
12. SFT_GRAV_TRAJ_12_physical_D_B_proxy_selection_audit.py
13. SFT_GRAV_TRAJ_13_blind_prediction_protocol_freeze.py

Notes:
- The original Gate 08 script is included for historical continuity, but the patched 08R script should be used for the final V12.3 spine.
- Run from a normal Python environment with numpy/pandas/matplotlib as needed by each script.
- Some scripts may write CSVs/plots into the current working directory or a local output directory.

Created: 20260527_000828
