SFT V11.7 Fluid Stress Seed v6 Repro Pack
==========================================

This pack accompanies the v6 final effective-theory update.

docs/
  SFT_V11_7_Lag_Field_Fluid_Stress_Seed_v6.pdf

scripts/
  sft_v117_big_validation_runner.py
  sft_v117_2d_robustness_runner.py

data/1d_viscosity_full/
  1D full viscosity separation run: runs, baselines, summary, correlations.

plots/1d_viscosity_full/
  Main aggregate response, high-k response, regime counts.

data/2d_hero/
  2D hero run: runs, baselines, summary, correlations, aggregate tables, config.

plots/2d_hero/
  Scalar-only, tensor-only, combined aggregate plots and vorticity high-k plots.

v6 adds the constitutive derivation of the scalar/tensor closure:
  sigma_SFT = -epsilon_chi chi I + epsilon_Q Q_chi
and keeps epsilon, alpha, tau, and D phenomenological pending future microscopic derivation.
