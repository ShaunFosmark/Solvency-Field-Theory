# SFT R279O — κ / P_dir / η_I Projector-Unification Audit, v0.1

**Status:** Cross-scale identity audit.  
**Date:** 2026-07-10.  
**Inputs:** V12.7 frozen theorem stack, V12.11 Master Action/SPARC bridge, V13.2 expansion mechanism, R278O tangent-lane proof, and the R276O/R277O operator/Rosetta chain.  
**Purpose:** Test whether the repeated `3/4` and `1/4` factors are the same geometric invariant or only numerically identical appearances.

---

## 1. Executive verdict

```text
R279O_V0_1_STRONG_PARTIAL_PASS_PROJECTOR_CLASS_UNIFICATION_KAPPA_PDIR_AND_ETA_COMPLEMENT_SHARE_RANK_ONE_EXCLUSION_OVER_3PLUS1_WRITE_CAPACITY_V12_7_AND_SPARK_DISK_LANES_MATCH_PROJECTOR_FORM_MASS_PDIR_PROVEN_BY_R278O_ETA_I_COMPLEMENT_PROMISING_BUT_REMAINS_CONVENTION_UNTIL_BOUNDARY_PROJECTOR_DERIVED
```

Short verdict:

```text
κ = P_dir = 3/4 is promoted as a common projector-class invariant.
η_I = 1/4 is promoted as its complement candidate.
Full freeze waits on one remaining proof: boundary-capacity η_I must be derived from the same projector partition, not carried as a convention.
```

The audit result is stronger than “same number,” but slightly weaker than “identical literal lane.”

The safe claim is:

```text
At particle, mass-compounding, and disk-projection scales, the same rank-one exclusion structure appears:

full 3+1 write capacity = 4 lanes
excluded/preferred/occupied/locked lane = 1 lane
available/projected/settlement-admissible capacity = 3 lanes

therefore

κ = P_dir = Tr(Π_available)/Tr(I_4) = 3/4.
```

The stricter claim:

```text
The excluded vector is literally the same physical direction in all contexts.
```

is **not** correct as written. The excluded lane changes presentation with the readout: tangent/continuation in particle closure, support-lock normal in disk morphology, denominator/base capacity in V12.7, and boundary writable-capacity complement in V13.2. What is invariant is the **projector form**:

```text
one rank-one lane is removed from a four-lane 3+1 write-capacity identity.
```

That is the object to freeze, not a single global vector.

---

## 2. Master projector partition

Define local 3+1 write-address capacity:

```text
I_4 = Π_excluded + Π_available
```

with:

```text
Tr(I_4) = 4
Tr(Π_excluded) = 1
Tr(Π_available) = 3
```

Then:

```text
κ_available = Tr(Π_available)/Tr(I_4) = 3/4
κ_excluded  = Tr(Π_excluded)/Tr(I_4)  = 1/4
```

Native SFT reading:

```text
3/4 = the fraction of 3+1 write capacity available to the relevant projected/settling/maintenance readout.
1/4 = the rank-one continuation/overhead/writable-address complement.
```

This is the object R279O audits across scales.

---

## 3. Appearance A — V12.7 particle spectrum / slot capacity

### Source claim

V12.7 freezes the exact seed:

```text
S_12.7 = {ρ in D_RC : ρ >= 1/2 and denom(ρ) <= 4}
        = {1/2, 2/3, 3/4, 1, 5/4, 4/3, 3/2, 5/3, 2}
```

The denominator branch is:

```text
one tangent/base cadence channel + three transverse normal-frame channels = 4 slots
therefore denom(ρ) <= 4.
```

V12.7 also identifies the primitive anchors:

```text
{1, 1/2, 1/3}
```

with `1/3` read as tri-normal virtual support rather than a stable species.

### Projector rewrite

V12.7 is not primarily written as `κ = 3/4`; it is written as a **slot-capacity theorem**:

```text
I_4 = Π_base/tangent + Π_3-normal
Tr(I_4) = 4
Tr(Π_3-normal) = 3
```

Therefore the projector ratio latent in V12.7 is:

```text
Tr(Π_3-normal)/Tr(I_4) = 3/4.
```

### Audit status

```text
PASS_PROJECTOR_STRUCTURE
PARTIAL_LABEL_IDENTITY
```

Meaning:

- V12.7 absolutely contains the same `1 + 3 = 4` capacity partition.
- The frozen V12.7 theorem stack uses it mainly as `denom(ρ) <= 4`, not as an explicitly named `κ` ratio.
- Therefore R279O may identify the **projector structure** with R278O `P_dir`, but should not pretend V12.7 itself already froze the name `κ = P_dir`.

Safe statement:

```text
V12.7 supplies the same 3+1 slot partition from which κ = 3/4 is formed.
```

Unsafe overclaim:

```text
V12.7 already proved the exact mass-compounding P_dir identity.
```

---

## 4. Appearance B — V12.11 / SPARC disk morphology κ

### Source claim

V12.11 says the disk normalization constant is not fitted:

```text
κ_disk = 3/4
```

and derives it from the 3+1 slot binary no-overwrite disk-cell constraint. The disk endpoint is:

```text
λ_disk = (π/2)(3/4) = 3π/8.
```

The smooth version is:

```text
Π_adm(x) = 1 - h_lock(x)/4.
```

For a settled razor-thin disk:

```text
h_lock -> 1
Π_adm -> 3/4.
```

For a sphere:

```text
h_lock -> 0
Π_adm -> 1.
```

### Projector rewrite

The disk-cell readout is:

```text
Π_adm = I_4 - Π_locked
```

with one rank-one locked/support-normal/preferred lane at the disk endpoint:

```text
Tr(Π_locked) = 1
Tr(I_4) = 4
Π_adm fraction = 1 - 1/4 = 3/4.
```

### Important correction to Opus wording

The excluded SPARC/disk lane should **not** be described generically as the observer line-of-sight. The V12.11 source language is support-lock / disk-cell / normal-history language. Observation enters through the circular-velocity observable downstream, but the native κ is a disk support-admissibility factor, not merely an optical line-of-sight projection.

Better wording:

```text
SPARC κ = 3/4 is the disk support-admissibility projector produced when one disk-cell support lane is locked/excluded by no-overwrite, leaving three of four 3+1 write-capacity lanes active in the projected morphology readout.
```

### Audit status

```text
PASS_KAPPA_PROJECTOR_FORM
PASS_CROSS_LINK_TO_V12_7
```

V12.11 explicitly connects the same no-overwrite structure that selects the nine particle modes to the disk morphology correction. This is the strongest historical support for the κ unification.

---

## 5. Appearance C — R278O mass compounding P_dir

### Source claim

R278O proved:

```text
Π_set = I_4 - Π_T
```

where `Π_T` is the tangent/continuation lane.

Then:

```text
P_dir = Tr(Π_set)/Tr(I_4)
      = 3/4.
```

Over one 4π spinor closure:

```text
G_closure = ∫_0^{4π} P_dir dφ
          = (3/4)(4π)
          = 3π.
```

Then:

```text
L_eff = 3π - 1/2 ln(25/13)
      = 9.097814727066048...
```

### Projector rewrite

This is already written in projector language:

```text
Π_available = Π_set
Π_excluded  = Π_T
κ = P_dir = Tr(Π_set)/Tr(I_4) = 3/4.
```

### Audit status

```text
PASS_DIRECT_PROJECTOR_PROOF
```

This is the cleanest proof of the ratio in the operator language.

---

## 6. Appearance D — V13.2 expansion η_I = 1/4

### Source claim

V13.2 freezes the native expansion stack:

```text
Ndot_write = Σ_a χ_a E_a/h
I_write = η_I A_boundary/A_write
H = Ndot_write/I_write
```

and uses the quarter-boundary convention:

```text
η_I = 1/4.
```

The narrative statement is:

```text
only one quarter of the boundary area is writable capacity;
the rest is structural overhead.
```

### Projector rewrite candidate

If R279O’s partition is universal, then:

```text
η_I = Tr(Π_excluded)/Tr(I_4) = 1/4
```

with the complement:

```text
1 - η_I = 3/4.
```

Native reading:

```text
The continuation/fresh-address lane is the rank-one writable-capacity channel.
The remaining three lanes are structural/settlement overhead in the boundary-capacity accounting.
```

This is exactly the complement of the settlement/morphology projector:

```text
P_dir + η_I = 3/4 + 1/4 = 1.
```

### Audit status

```text
PROMISING_COMPLEMENT_MATCH
NOT_YET_DERIVED
```

R279O should not yet freeze this as a theorem because V13.2 names `η_I = 1/4` as a quarter-boundary **convention**. It is now promoted as the obvious next derivation target:

```text
R280O — η_I Boundary Projector Derivation
```

Pass condition for R280O:

```text
derive η_I = Tr(Π_continuation)/Tr(I_4) = 1/4
from the same no-overwrite / 3+1 write-address partition,
without using the quarter-boundary value as an input.
```

---

## 7. Cross-scale audit table

| Appearance | Old/native form | Excluded rank-one lane | Available/complement lane | Ratio | Status |
|---|---|---|---|---:|---|
| V12.7 particle seed | `denom(ρ) <= 4` from `1 + 3` slots | tangent/base cadence lane | three transverse normal-frame channels | latent `3/4` | `PASS structure / PARTIAL name` |
| V12.11/SPARC disk | `κ_disk = 3/4`; `Π_adm = 1 - h_lock/4` | locked disk-cell/support-normal lane at disk endpoint | admissible projected morphology capacity | `3/4` | `PASS` |
| R278O mass compounding | `P_dir = Tr(Π_set)/Tr(I_4)` | tangent/continuation lane | settlement-coupled lanes | `3/4` | `PASS` |
| V13.2 expansion | `η_I = 1/4` quarter-boundary convention | continuation/writable-capacity lane candidate | structural/settlement overhead complement | `1/4` | `PROMISING / OPEN` |

---

## 8. What is unified and what is not

### Unified

The repeated factor is not random numerology. It has the same abstract form each time:

```text
rank-one exclusion over 3+1 write capacity.
```

The general invariant is:

```text
κ_projector = (D - 1)/D
```

with `D = 4`, so:

```text
κ_projector = 3/4.
```

Its complement is:

```text
η_projector = 1/D = 1/4.
```

### Not unified yet

The excluded lane is not literally the same vector in every readout. It is the same **rank-one role**:

```text
tangent / base / locked / continuation / writable-address lane
```

depending on which measurement/readout is being taken.

Therefore the frozen wording should be:

```text
κ = 3/4 is the 3+1 rank-one-exclusion projector invariant.
```

not:

```text
the exact same physical direction is excluded at all scales.
```

---

## 9. Dimensional fingerprint ledger

R279O also supports the broader “geometry stamps the object” interpretation, but this belongs in an interpretive ledger rather than the hard PASS line.

Promising dimensional fingerprints already visible in the stack:

```text
3/4      = rank-one exclusion in 3+1 write capacity
1/4      = rank-one continuation/writable-capacity complement
4π       = spinor closure / oriented exterior return
1/(16π²) = two-stage 4π directional projection candidate for α
2(2ℓ+1)  = 3D orbital degeneracy times spinor doubling
1/r²     = 3D flux/surface-area scaling
```

Safe synthesis sentence:

```text
SFT is increasingly showing that particle, galaxy, and expansion coefficients are not independent constants; they are dimensional fingerprints of energy-at-c writing through 3+1 no-overwrite geometry.
```

Stronger but not-yet-frozen sentence:

```text
Things look like the geometry that created them.
```

---

## 10. R279O final verdict

```text
R279O_V0_1_STRONG_PARTIAL_PASS_PROJECTOR_CLASS_UNIFICATION_KAPPA_PDIR_AND_ETA_COMPLEMENT_SHARE_RANK_ONE_EXCLUSION_OVER_3PLUS1_WRITE_CAPACITY_V12_7_AND_SPARK_DISK_LANES_MATCH_PROJECTOR_FORM_MASS_PDIR_PROVEN_BY_R278O_ETA_I_COMPLEMENT_PROMISING_BUT_REMAINS_CONVENTION_UNTIL_BOUNDARY_PROJECTOR_DERIVED
```

Human-readable verdict:

```text
R279O passes the main κ/P_dir unification at projector-class level.
The same 3+1 rank-one-exclusion invariant appears in V12.7 slot capacity, V12.11/SPARC disk admissibility, and R278O mass compounding.
V13.2 η_I = 1/4 is almost certainly the complement, but it remains an open derivation because V13.2 froze it as a convention rather than proving it from the projector partition.
```

---

## 11. Next gate

```text
R280O — η_I Boundary Projector Derivation
```

Question:

```text
Can the V13.2 quarter-boundary convention η_I = 1/4 be derived from the same 3+1 rank-one continuation projector that gives κ = P_dir = 3/4?
```

Pass condition:

```text
Show that global writable boundary capacity counts the rank-one continuation/fresh-address projector:
η_I = Tr(Π_continuation)/Tr(I_4) = 1/4.
```

Partial condition:

```text
The complement match is structurally consistent but still requires an independent boundary-normalization convention.
```

Fail condition:

```text
η_I = 1/4 depends on unrelated boundary accounting and cannot be identified with the κ/P_dir complement without adding a new primitive.
```
