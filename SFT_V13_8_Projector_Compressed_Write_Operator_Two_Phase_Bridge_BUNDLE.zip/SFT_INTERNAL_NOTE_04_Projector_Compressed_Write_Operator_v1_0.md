# SFT Internal Note 04 — Projector-Compressed Write Operator

**Subtitle:** κ + η_I = 1, L_eff Closure, and the 3:2 Sector Accessibility Tax  
**Status:** Internal note / freeze-ready checkpoint  
**Source gates:** R276O–R282O  
**Purpose:** Preserve the operator compression discovered across the Rosetta Stone, minimal kernel, tangent-lane projector, κ audit, η_I complement, compressed-write operator, and sector-tax gates.

---

## 0. One-sentence result

The microscopic write operator has a projector-compressed core: in 3+1 write capacity, one rank-one lane is reserved for continuation and three lanes are settlement-available, so the same partition gives

$$
I_4=\Pi_{\rm set}+\Pi_{\rm cont},
\qquad
\kappa=P_{\rm dir}=\frac34,
\qquad
\eta_I=\frac14,
\qquad
\kappa+\eta_I=1.
$$

The leading D-scale mass coefficient is then

$$
L_{\rm eff}
=\kappa(4\pi)-\frac12\ln N_{\rm eff}
=\frac34(4\pi)-\frac12\ln\left(\frac{25}{13}\right)
=3\pi-\frac12\ln\left(\frac{25}{13}\right)
=9.097814727066048\ldots
$$

with

$$
N_{\rm eff}=\frac{1}{(3/5)^2+(2/5)^2}=\frac{25}{13}.
$$

---

## 1. Claim boundary

This note freezes the **internal SFT operator compression**, not a finished public derivation.

### Claimed internally

1. The exterior settlement kernel is fixed by the weak-field gravity readout once energy is treated as write rate.
2. The factor \(3/4\) is derived as a projector trace ratio in 3+1 write capacity.
3. The factor \(1/4\) is the complementary continuation projector.
4. The leading \(3\pi\) term in \(L_{\rm eff}\) follows from \((3/4)(4\pi)\).
5. The tax term \(\frac12\ln(25/13)\) follows from a 3:2 grouped sector participation: three settlement channels plus two independent closure/phase channels.
6. The operator core is therefore:

$$
\boxed{\text{project}\;\to\;\text{count}\;\to\;\text{group}\;\to\;\text{tax}\;\to\;\text{compound}.}
$$

### Still open / not overclaimed

1. Full public proof that \(\phi_C\) and \(\theta_g\) are independent phase channels.
2. Microscopic form of \(K_{\rm set}\), beyond the exterior static kernel.
3. Microscopic form of \(P_{\rm coh}\).
4. Microscopic form of \(\Phi_{\rm relax}\).
5. Raw-lane versus readout-normalized convention for \(A_{\rm write}\).
6. Public translation of the boundary-area projector normalization.

---

## 2. Core notation

Let \(I_4\) denote the full local 3+1 write-address capacity.

Let \(\Pi_{\rm cont}\) denote the rank-one continuation/tangent projector: the lane required for the next write to continue.

Let \(\Pi_{\rm set}\) denote the settlement-available projector: the lanes into which settlement can be deposited without overwriting the continuation lane.

The partition is

$$
I_4=\Pi_{\rm set}+\Pi_{\rm cont}.
$$

The ranks/traces are

$$
\operatorname{Tr}(I_4)=4,
\qquad
\operatorname{Tr}(\Pi_{\rm cont})=1,
\qquad
\operatorname{Tr}(\Pi_{\rm set})=3.
$$

Therefore

$$
P_{\rm dir}
=\frac{\operatorname{Tr}(\Pi_{\rm set})}{\operatorname{Tr}(I_4)}
=\frac34,
$$

and

$$
\eta_I
=\frac{\operatorname{Tr}(\Pi_{\rm cont})}{\operatorname{Tr}(I_4)}
=\frac14.
$$

Thus

$$
P_{\rm dir}+\eta_I=\frac34+\frac14=1.
$$

The historical SFT symbol \(\kappa\) is identified internally with this same projector-class invariant:

$$
\boxed{\kappa=P_{\rm dir}=\frac34.}
$$

---

## 3. Count conventions: cycle gauge and reduced/radian gauge

The current stack uses both full-cycle and reduced/radian write counts. This note keeps them explicit.

Full-cycle count:

$$
dN_h=\frac{E\,dt}{h}.
$$

Reduced/radian count:

$$
dN_{\hbar}=d\phi=\frac{E\,dt}{\hbar}.
$$

Since \(h=2\pi\hbar\),

$$
dN_{\hbar}=2\pi\,dN_h.
$$

If the write footprint is written in both conventions, consistency requires

$$
A_h\,dN_h=A_{\hbar}\,dN_{\hbar},
$$

so

$$
A_h=2\pi A_{\hbar}.
$$

This note uses the reduced/radian convention unless otherwise stated.

---

## 4. R277O result: minimal exterior settlement kernel

The exterior compactness readout is

$$
C_A(E,r)=\frac{A_{\rm write}E}{\hbar c r}.
$$

This is naturally obtained if energy enters as write rate, not as extra per-write deposit.

Reduced write rate:

$$
\dot N_{\hbar}=\frac{E}{\hbar}.
$$

Minimal retarded settlement readout:

$$
C_A(x,t)
=A_{\rm write}\int
\frac{\rho_E(y,t-|x-y|/c)}{\hbar c |x-y|}\,d^3y.
$$

For a static point source of energy \(E\), this gives

$$
C_A(r)=\frac{A_{\rm write}E}{\hbar c r}.
$$

With the G-root identification

$$
A_{\rm write}=\frac{G\hbar}{c^3},
$$

we get

$$
C_A(r)
=\frac{G\hbar}{c^3}\frac{E}{\hbar c r}
=\frac{GE}{c^4r}.
$$

For rest energy \(E=Mc^2\),

$$
C_A(r)=\frac{GM}{c^2r}.
$$

The gravity readout is

$$
a=-c^2\nabla C_A.
$$

Thus

$$
|a|=c^2\frac{GM}{c^2r^2}=\frac{GM}{r^2}.
$$

So the static exterior kernel is fixed as

$$
K_{\rm static}(r)=\frac{1}{cr},
$$

up to normalization convention.

### Important bookkeeping result

Per write:

$$
\text{one universal write footprint is deposited.}
$$

Per unit time:

$$
\text{energy controls the number of writes.}
$$

Energy belongs in the write rate:

$$
\dot N\sim \frac{E}{\hbar},
$$

not as a second factor in the per-write deposit.

---

## 5. R278O result: tangent-lane exclusion and \(P_{\rm dir}=3/4\)

A locally real support cannot overwrite its own continuation lane. The tangent/continuation lane is already occupied by the next-write requirement.

Therefore settlement is projected off the continuation lane:

$$
\Pi_{\rm set}=I_4-\Pi_{\rm cont}.
$$

Taking traces:

$$
\operatorname{Tr}(\Pi_{\rm set})
=\operatorname{Tr}(I_4)-\operatorname{Tr}(\Pi_{\rm cont})
=4-1=3.
$$

Thus the directional settlement participation is

$$
P_{\rm dir}
=\frac{\operatorname{Tr}(\Pi_{\rm set})}{\operatorname{Tr}(I_4)}
=\frac34.
$$

Over one spinor closure,

$$
0\leq \phi<4\pi,
$$

so the closure gain is

$$
G_{\rm closure}
=\int_0^{4\pi}P_{\rm dir}\,d\phi
=\int_0^{4\pi}\frac34\,d\phi
=\frac34(4\pi)
=3\pi.
$$

This replaces the older semi-geometric route

$$
3\pi=\frac12(6\pi)
$$

with the operator-native route

$$
3\pi=\frac34(4\pi).
$$

---

## 6. R279O result: \(\kappa=P_{\rm dir}\) projector-class unification

The historical SFT constant \(\kappa=3/4\) is promoted internally to the same projector-class invariant as \(P_{\rm dir}\), subject to the claim boundary that historical uses must preserve the rank-one exclusion form.

The invariant form is

$$
\kappa=\frac{\operatorname{Tr}(\Pi_{\rm available})}{\operatorname{Tr}(I_4)}=\frac34.
$$

The complement is

$$
1-\kappa=\frac14.
$$

Cross-scale readout table:

| Readout | Full capacity | Excluded/locked lane | Available lanes | Ratio |
|---|---:|---|---:|---:|
| Particle closure / mass compounding | 4 | continuation/tangent lane | 3 | \(P_{\rm dir}=3/4\) |
| V12.7 binary no-overwrite slot capacity | 4 | occupied/base slot | 3 | \(\kappa=3/4\) |
| SPARC/disk morphology lane | 4 | support-locked lane | 3 | \(\kappa_{\rm disk}=3/4\) |
| Expansion boundary capacity | 4 | continuation lane | 1 active continuation projection | \(\eta_I=1/4\) |

The safe unified statement is not that every application excludes the exact same physical direction in ordinary coordinates. The safe internal statement is:

$$
\boxed{\text{each case realizes the same rank-one exclusion over 3+1 write capacity}.}
$$

---

## 7. R280O result: \(\eta_I=1/4\) as continuation complement

From the same projector partition,

$$
I_4=\Pi_{\rm set}+\Pi_{\rm cont}.
$$

The continuation fraction is

$$
\eta_I
=\frac{\operatorname{Tr}(\Pi_{\rm cont})}{\operatorname{Tr}(I_4)}
=\frac14.
$$

The settlement fraction is

$$
\kappa=P_{\rm dir}
=\frac{\operatorname{Tr}(\Pi_{\rm set})}{\operatorname{Tr}(I_4)}
=\frac34.
$$

Therefore

$$
\kappa+\eta_I=1.
$$

This gives the internal derivation of the V13.2 quarter-boundary factor:

$$
I_{\rm write}=\eta_I\frac{A_{\rm boundary}}{A_{\rm write}},
\qquad
\eta_I=\frac14.
$$

Key sentence:

> The same write that cannot settle its own continuation lane must grow the boundary through that lane.

So expansion is the continuation complement of settlement.

---

## 8. R281O result: projector-compressed write operator

The write operator is the irreversible update event. The projector table is its coordinate chart.

One write applies the 3+1 projector partition:

$$
W:
I_4\longrightarrow \Pi_{\rm set}\oplus \Pi_{\rm cont}.
$$

In readout language:

$$
W_{\rm set}=\Pi_{\rm set}W,
\qquad
W_{\rm cont}=\Pi_{\rm cont}W.
$$

Settlement readout:

$$
\frac{\operatorname{Tr}(W_{\rm set})}{\operatorname{Tr}(W)}=\frac34.
$$

Continuation/boundary readout:

$$
\frac{\operatorname{Tr}(W_{\rm cont})}{\operatorname{Tr}(W)}=\frac14.
$$

This is not an energy split. It is a lane/readout split.

One write remains one write. The split says how the write is projected into settlement and continuation readouts.

A schematic state update can be written as

$$
W_i[dN]:
(X_i,u_i,D_{\rm set},C_A,I_{\rm write})
\mapsto
(X_i',u_i',D_{\rm set}',C_A',I_{\rm write}').
$$

The update contains:

1. **Admissibility:**

$$
X_i'=\text{next legal no-overwrite address}.
$$

2. **One-speed continuation:**

$$
\text{support advancement respects the }c\text{-budget.}
$$

3. **Settlement projection:**

$$
D_{\rm set}'=D_{\rm set}+\Pi_{\rm set}K_{\rm set}\,dN-\Phi_{\rm relax}.
$$

4. **Continuation/capacity projection:**

$$
I_{\rm write}'=I_{\rm write}+\Pi_{\rm cont}\,dN
$$

in projected capacity units.

5. **Gravity readout:**

$$
a=-c^2\nabla C_A.
$$

6. **Mass/closure readout:**

$$
\Delta\ln D_{\rm set}=P_{\rm coh}L_{\rm eff}u-\Phi_{\rm relax}.
$$

The compressed operator core is:

$$
\boxed{
W=\text{irreversible write}\;+
\left(\Pi_{\rm set},\Pi_{\rm cont}\right)\;+
\text{no-overwrite admissibility}.
}
$$

---

## 9. R282O result: 3:2 sector accessibility tax and \(25/13\)

The settlement projector has rank three:

$$
\operatorname{rank}(\Pi_{\rm set})=3.
$$

These are the three spatial settlement channels.

The closure/particle program supplies two independent internal phase channels:

$$
\phi_C=\text{mass cadence / Compton closure phase},
$$

$$
\theta_g=\text{charge/framing holonomy phase}.
$$

Thus the participation structure is grouped as

$$
3:2.
$$

This means three settlement components and two phase components, not five spacetime dimensions.

The grouped weights are

$$
w_S=\frac35,
\qquad
w_\Phi=\frac25.
$$

The participation concentration is

$$
\chi=w_S^2+w_\Phi^2
=\left(\frac35\right)^2+\left(\frac25\right)^2
=\frac9{25}+\frac4{25}
=\frac{13}{25}.
$$

The effective participation number is

$$
N_{\rm eff}=\frac1\chi=\frac{25}{13}.
$$

The amplitude-level accessibility tax is

$$
T_{\rm amp}=\frac12\ln N_{\rm eff}
=\frac12\ln\left(\frac{25}{13}\right).
$$

Numerically,

$$
T_{\rm amp}=0.326963233703332\ldots
$$

### Uniqueness check

If the settlement rank is fixed at 3 and the internal phase count is \(n\), then

$$
N_{\rm eff}(n)=\frac{(3+n)^2}{9+n^2}.
$$

Requiring

$$
N_{\rm eff}=\frac{25}{13}
$$

selects

$$
n=2
$$

as the relevant integer internal-channel count, matching \(\phi_C\) and \(\theta_g\).

---

## 10. Full \(L_{\rm eff}\) derivation

Start from the operator-native form:

$$
L_{\rm eff}=\kappa(4\pi)-T_{\rm amp}.
$$

Insert the projector result:

$$
\kappa=\frac34.
$$

Thus

$$
\kappa(4\pi)=\frac34(4\pi)=3\pi.
$$

Insert the sector tax:

$$
T_{\rm amp}=\frac12\ln\left(\frac{25}{13}\right).
$$

Therefore

$$
L_{\rm eff}
=3\pi-\frac12\ln\left(\frac{25}{13}\right).
$$

Numerically,

$$
3\pi=9.42477796076938\ldots
$$

$$
\frac12\ln\left(\frac{25}{13}\right)=0.326963233703332\ldots
$$

so

$$
L_{\rm eff}=9.097814727066048\ldots
$$

This is the frozen V12.13 value recovered as a projector/sector result:

$$
\boxed{
L_{\rm eff}=\frac34(4\pi)-\frac12\ln\left(\frac{25}{13}\right).
}
$$

---

## 11. Interpretation by readout

### 11.1 Mass compounding

The D-scale compounding law becomes

$$
\Delta\ln D_{\rm set}=P_{\rm coh}L_{\rm eff}u-\Phi_{\rm relax},
$$

with

$$
L_{\rm eff}=\frac34(4\pi)-\frac12\ln\left(\frac{25}{13}\right).
$$

The leading gain is settlement-available spinor closure phase. The tax is the amplitude-level penalty from the protected 3:2 grouped participation.

### 11.2 Gravity

Gravity is the gradient readout of accumulated settlement:

$$
a=-c^2\nabla C_A.
$$

With

$$
C_A(E,r)=\frac{A_{\rm write}E}{\hbar c r},
$$

and

$$
A_{\rm write}=\frac{G\hbar}{c^3},
$$

this recovers the Newtonian exterior limit.

### 11.3 Expansion

Expansion is the continuation-capacity readout:

$$
H=\frac{\dot N_{\rm write}}{I_{\rm write}}.
$$

The boundary-capacity convention is now internally read as

$$
I_{\rm write}=\eta_I\frac{A_{\rm boundary}}{A_{\rm write}},
\qquad
\eta_I=\frac14.
$$

Thus the expansion lane is the complement of the settlement lane.

### 11.4 Particle spectrum and galactic morphology

The historical \(\kappa=3/4\) appearances are internally reinterpreted as the same projector-class invariant:

$$
\kappa=\frac{\operatorname{Tr}(\Pi_{\rm available})}{\operatorname{Tr}(I_4)}=\frac34.
$$

This does not require claiming the same coordinate direction is excluded in every readout. It requires the same rank-one exclusion structure over 3+1 write capacity.

---

## 12. The compressed physical picture

One irreversible write uses the full local 3+1 write capacity.

The write cannot settle the lane needed for its own continuation.

Therefore:

$$
\text{settlement lanes}=3,
\qquad
\text{continuation lane}=1.
$$

The settlement projection produces mass, gravity, and cumulative structure.

The continuation projection produces future-address demand and boundary growth.

The same event has two complementary projections:

$$
\Pi_{\rm set}:\frac34,
\qquad
\Pi_{\rm cont}:\frac14.
$$

The closure orbit adds \(4\pi\). The available settlement projection of that closure is \(3\pi\). The internal 3:2 channel grouping adds the amplitude tax \(\frac12\ln(25/13)\). The result is \(L_{\rm eff}\).

The operator is therefore not primarily a mysterious nonlinear functional. Its core is dimensional bookkeeping under no-overwrite:

$$
\boxed{\text{count lanes, project continuation out, group channels, tax unequal participation, compound.}}
$$

---

## 13. Freeze-ready verdict

### Internal verdict

$$
\boxed{\text{STRONG INTERNAL PASS / PUBLIC PARTIAL}.}
$$

### Status string

```text
FROZEN_INTERNAL_NOTE_04_PROJECTOR_COMPRESSED_WRITE_OPERATOR_KAPPA_PLUS_ETA_EQUALS_ONE_LEFF_FROM_3PLUS1_PROJECTOR_4PI_CLOSURE_AND_3TO2_SECTOR_TAX_GEOMETRIC_OPERATOR_CORE_KSET_PCOH_PHIRELAX_OPEN
```

### What is frozen by this note

1. \(P_{\rm dir}=3/4\) from tangent-lane exclusion in 3+1 write capacity.
2. \(\eta_I=1/4\) as the complementary continuation projector.
3. \(\kappa=P_{\rm dir}=3/4\) as a common projector-class invariant.
4. \(N_{\rm eff}=25/13\) from a 3:2 grouped participation space.
5. \(L_{\rm eff}=3\pi-\frac12\ln(25/13)\) as the leading geometric mass-compounding coefficient.
6. The compressed operator core:

$$
I_4=\Pi_{\rm set}+\Pi_{\rm cont},
\qquad
\operatorname{Tr}(\Pi_{\rm set}):\operatorname{Tr}(\Pi_{\rm cont})=3:1.
$$

### What remains open

1. Full public proof of \(\phi_C\) / \(\theta_g\) independence.
2. Microscopic \(K_{\rm set}\).
3. Microscopic \(P_{\rm coh}\).
4. Microscopic \(\Phi_{\rm relax}\).
5. Public normalization of \(A_{\rm write}\) across raw-lane and readout-normalized conventions.
6. Full paper-ready integration with V12.7, SPARC, V13.2, and V13.7 source documents.

---

## 14. Suggested next gate

The cleanest next gate is:

```text
R283O — φ_C / θ_g Independence Gate:
Mass Cadence and Charge Holonomy as Two Independent Closure Phases
```

Pass target:

$$
\phi_C\neq \theta_g
$$

as independent closure channels, supported by:

1. Same charge with different mass: electron, muon, tau.
2. Same mass/cadence with opposite charge: particle-antiparticle pairs.
3. Neutral massive composites: \(\phi_C\) remains active while net \(\theta_g\) cancels.
4. Photon/open support: no rest-mass closure cadence, but EM phase/holonomy remains meaningful.
5. Gauge distinction: \(\theta_g\) relabeling generates charge/EM behavior; \(\phi_C\) cadence generates proper-time/mass behavior.

---

## 15. Final internal summary

R277O–R282O convert the settlement-operator problem from a broad unknown functional into a compact projector problem.

The result is:

$$
\boxed{
\text{The write operator is a 3+1 projector partition applied to irreversible writes.}
}
$$

Three lanes settle. One lane continues. The settlement lanes generate mass/gravity/structure. The continuation lane generates boundary growth/expansion. The 4π spinor closure supplies the phase length. The 3:2 settlement/phase grouping supplies the accessibility tax. Together they give the frozen \(L_{\rm eff}\) coefficient with no new adjustable number.

The deepest current sentence is:

> The same write that cannot settle its own continuation lane must grow the boundary through that lane.

That is the operator compression preserved by this note.
