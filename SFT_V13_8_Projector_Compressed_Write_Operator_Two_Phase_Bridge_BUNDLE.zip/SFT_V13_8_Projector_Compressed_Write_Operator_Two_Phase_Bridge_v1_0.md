# SFT V13.8 - Projector-Compressed Write Operator and Two-Phase Bridge

**Subtitle:** `kappa + eta_I = 1`, `L_eff` closure, the 3:2 sector accessibility tax, and the `phi_C / theta_g` independence bridge  
**Status:** V13.8 internal elevation / freeze-ready checkpoint  
**Source gates:** R276O-R284O  
**Prior checkpoint:** Internal Note 04 - Projector-Compressed Write Operator  
**Purpose:** Elevate the Internal Note 04 operator compression into SFT V13.8 by adding the two immediate bridge gates: R283O, the internal `phi_C / theta_g` independence gate, and R284O, the public-facing independence derivation attempt.

---

## 0. One-sentence result

The microscopic write operator has a projector-compressed core and a two-phase closure bridge. In 3+1 write capacity, one rank-one lane is reserved for continuation and three lanes are settlement-available:

$$
I_4 = \Pi_{\rm set} + \Pi_{\rm cont},
\qquad
\operatorname{Tr}(\Pi_{\rm set}) = 3,
\qquad
\operatorname{Tr}(\Pi_{\rm cont}) = 1,
\qquad
\operatorname{Tr}(I_4) = 4.
$$

Therefore

$$
\kappa = P_{\rm dir} = \frac{\operatorname{Tr}(\Pi_{\rm set})}{\operatorname{Tr}(I_4)} = \frac34,
\qquad
\eta_I = \frac{\operatorname{Tr}(\Pi_{\rm cont})}{\operatorname{Tr}(I_4)} = \frac14,
\qquad
\kappa + \eta_I = 1.
$$

The leading D-scale mass coefficient is

$$
L_{\rm eff}
= \kappa(4\pi) - \frac12\ln N_{\rm eff}
= \frac34(4\pi) - \frac12\ln\left(\frac{25}{13}\right)
= 3\pi - \frac12\ln\left(\frac{25}{13}\right)
= 9.097814727066048\ldots
$$

with

$$
N_{\rm eff}
= \frac{1}{(3/5)^2 + (2/5)^2}
= \frac{25}{13}.
$$

The new V13.8 bridge is that the `2` in the 3:2 sector split is supported by two independent closure/phase channels:

$$
\operatorname{rank}\{\phi_C,\theta_g\}=2,
$$

where

$$
\phi_C = \text{mass cadence / Compton closure phase},
\qquad
\theta_g = \text{charge / framing holonomy phase}.
$$

---

## 1. Claim boundary

This document elevates Internal Note 04 into a V13.8 checkpoint. It freezes the internal operator compression and adds the two-phase bridge as an internal pass with a public-facing partial pass.

### Claimed internally

1. The exterior settlement kernel is fixed by the weak-field gravity readout once energy is treated as write rate.
2. The factor `3/4` is derived as a projector trace ratio in 3+1 write capacity.
3. The factor `1/4` is the complementary continuation projector.
4. The leading `3pi` term in `L_eff` follows from `(3/4)(4pi)`.
5. The tax term `(1/2)ln(25/13)` follows from a 3:2 grouped sector participation: three settlement channels plus two independent closure/phase channels.
6. R283O supports

$$
\operatorname{rank}\{\phi_C,\theta_g\}=2
$$

as an internal result.

7. R284O provides a public-facing independence bridge: same charge with different mass and same mass with opposite charge require two independent phase handles.
8. The operator core is therefore

$$
\boxed{\text{project} \;\to\; \text{count} \;\to\; \text{group} \;\to\; \text{tax} \;\to\; \text{compound}.}
$$

### Still open / not overclaimed

1. Full microscopic origin of `theta_g` as charge/framing holonomy without treating electric charge as primitive.
2. Full microscopic origin of `phi_C` as native mass cadence without merely importing the Compton clock as a postulate.
3. Charge quantization and fractional quark winding from the two-phase closure structure.
4. Microscopic form of `K_set`, beyond the exterior static kernel.
5. Microscopic form of `P_coh`.
6. Microscopic form of `Phi_relax`.
7. Raw-lane versus readout-normalized convention for `A_write`.
8. Public translation of the boundary-area projector normalization.

---

## 2. Core notation

Let `I_4` denote the full local 3+1 write-address capacity.

Let `Pi_cont` denote the rank-one continuation/tangent projector: the lane required for the next write to continue.

Let `Pi_set` denote the settlement-available projector: the lanes into which settlement can be deposited without overwriting the continuation lane.

The partition is

$$
I_4 = \Pi_{\rm set} + \Pi_{\rm cont}.
$$

The ranks/traces are

$$
\operatorname{Tr}(I_4)=4,
\qquad
\operatorname{Tr}(\Pi_{\rm cont})=1,
\qquad
\operatorname{Tr}(\Pi_{\rm set})=3.
$$

Therefore

$$
P_{\rm dir}
= \frac{\operatorname{Tr}(\Pi_{\rm set})}{\operatorname{Tr}(I_4)}
= \frac34,
$$

and

$$
\eta_I
= \frac{\operatorname{Tr}(\Pi_{\rm cont})}{\operatorname{Tr}(I_4)}
= \frac14.
$$

Thus

$$
P_{\rm dir}+\eta_I = \frac34+\frac14=1.
$$

The historical SFT symbol `kappa` is identified internally with this same projector-class invariant:

$$
\boxed{\kappa=P_{\rm dir}=\frac34.}
$$

---

## 3. Count conventions: cycle gauge and reduced/radian gauge

The current stack uses both full-cycle and reduced/radian write counts. V13.8 keeps them explicit.

Full-cycle count:

$$
dN_h = \frac{E\,dt}{h}.
$$

Reduced/radian count:

$$
dN_{\hbar} = d\phi = \frac{E\,dt}{\hbar}.
$$

Since

$$
h=2\pi\hbar,
$$

we have

$$
dN_{\hbar}=2\pi dN_h.
$$

If the write footprint is written in both conventions, consistency requires

$$
A_h dN_h = A_{\hbar} dN_{\hbar},
$$

so

$$
A_h = 2\pi A_{\hbar}.
$$

V13.8 uses the reduced/radian convention unless otherwise stated.

---

## 4. R277O result: minimal exterior settlement kernel

The exterior compactness readout is

$$
C_A(E,r)=\frac{A_{\rm write}E}{\hbar c r}.
$$

This is naturally obtained if energy enters as write rate, not as extra per-write deposit.

Reduced write rate:

$$
\dot N_{\hbar}=\frac{E}{\hbar}.
$$

Minimal retarded settlement readout:

$$
C_A(x,t)
= A_{\rm write}\int
\frac{\rho_E(y,t-|x-y|/c)}{\hbar c |x-y|}\,d^3y.
$$

For a static point source of energy `E`, this gives

$$
C_A(r)=\frac{A_{\rm write}E}{\hbar c r}.
$$

With the G-root identification

$$
A_{\rm write}=\frac{G\hbar}{c^3},
$$

we get

$$
C_A(r)
=\frac{G\hbar}{c^3}\frac{E}{\hbar c r}
=\frac{GE}{c^4r}.
$$

For rest energy

$$
E=Mc^2,
$$

this becomes

$$
C_A(r)=\frac{GM}{c^2r}.
$$

The gravity readout is

$$
a=-c^2\nabla C_A.
$$

Thus

$$
|a|=c^2\frac{GM}{c^2r^2}=\frac{GM}{r^2}.
$$

So the static exterior kernel is fixed as

$$
K_{\rm static}(r)=\frac{1}{cr},
$$

up to normalization convention.

### Important bookkeeping result

Per write:

$$
\text{one universal write footprint is deposited.}
$$

Per unit time:

$$
\text{energy controls the number of writes.}
$$

Energy belongs in the write rate,

$$
\dot N \sim \frac{E}{\hbar},
$$

not as a second factor in the per-write deposit.

---

## 5. R278O result: tangent-lane exclusion and `P_dir = 3/4`

A locally real support cannot overwrite its own continuation lane. The tangent/continuation lane is already occupied by the next-write requirement.

Therefore settlement is projected off the continuation lane:

$$
\Pi_{\rm set}=I_4-\Pi_{\rm cont}.
$$

Taking traces:

$$
\operatorname{Tr}(\Pi_{\rm set})
=\operatorname{Tr}(I_4)-\operatorname{Tr}(\Pi_{\rm cont})
=4-1=3.
$$

Thus the directional settlement participation is

$$
P_{\rm dir}
=\frac{\operatorname{Tr}(\Pi_{\rm set})}{\operatorname{Tr}(I_4)}
=\frac34.
$$

Over one spinor closure,

$$
0\leq \phi<4\pi,
$$

so the closure gain is

$$
G_{\rm closure}
=\int_0^{4\pi}P_{\rm dir}\,d\phi
=\int_0^{4\pi}\frac34\,d\phi
=\frac34(4\pi)
=3\pi.
$$

This replaces the older semi-geometric route

$$
3\pi=\frac12(6\pi)
$$

with the operator-native route

$$
3\pi=\frac34(4\pi).
$$

---

## 6. R279O result: `kappa = P_dir` projector-class unification

The historical SFT constant `kappa = 3/4` is promoted internally to the same projector-class invariant as `P_dir`, subject to the claim boundary that historical uses must preserve the rank-one exclusion form.

The invariant form is

$$
\kappa=\frac{\operatorname{Tr}(\Pi_{\rm available})}{\operatorname{Tr}(I_4)}=\frac34.
$$

The complement is

$$
1-\kappa=\frac14.
$$

Cross-scale readout table:

| Readout | Full capacity | Excluded/locked lane | Available lanes | Ratio |
|---|---:|---|---:|---:|
| Particle closure / mass compounding | 4 | continuation/tangent lane | 3 | `P_dir = 3/4` |
| V12.7 binary no-overwrite slot capacity | 4 | occupied/base slot | 3 | `kappa = 3/4` |
| SPARC/disk morphology lane | 4 | support-locked lane | 3 | `kappa_disk = 3/4` |
| Expansion boundary capacity | 4 | continuation lane | 1 active continuation projection | `eta_I = 1/4` |

The safe unified statement is not that every application excludes the exact same physical direction in ordinary coordinates. The safe internal statement is

$$
\boxed{\text{each case realizes the same rank-one exclusion over 3+1 write capacity}.}
$$

---

## 7. R280O result: `eta_I = 1/4` as continuation complement

From the same projector partition,

$$
I_4=\Pi_{\rm set}+\Pi_{\rm cont}.
$$

The continuation fraction is

$$
\eta_I
=\frac{\operatorname{Tr}(\Pi_{\rm cont})}{\operatorname{Tr}(I_4)}
=\frac14.
$$

The settlement fraction is

$$
\kappa=P_{\rm dir}
=\frac{\operatorname{Tr}(\Pi_{\rm set})}{\operatorname{Tr}(I_4)}
=\frac34.
$$

Therefore

$$
\kappa+\eta_I=1.
$$

This gives the internal derivation of the V13.2 quarter-boundary factor:

$$
I_{\rm write}=\eta_I\frac{A_{\rm boundary}}{A_{\rm write}},
\qquad
\eta_I=\frac14.
$$

Key sentence:

> The same write that cannot settle its own continuation lane must grow the boundary through that lane.

So expansion is the continuation complement of settlement.

---

## 8. R281O result: projector-compressed write operator

The write operator is the irreversible update event. The projector table is its coordinate chart.

One write applies the 3+1 projector partition:

$$
W:
I_4\longrightarrow \Pi_{\rm set}\oplus\Pi_{\rm cont}.
$$

In readout language:

$$
W_{\rm set}=\Pi_{\rm set}W,
\qquad
W_{\rm cont}=\Pi_{\rm cont}W.
$$

Settlement readout:

$$
\frac{\operatorname{Tr}(W_{\rm set})}{\operatorname{Tr}(W)}=\frac34.
$$

Continuation/boundary readout:

$$
\frac{\operatorname{Tr}(W_{\rm cont})}{\operatorname{Tr}(W)}=\frac14.
$$

This is not an energy split. It is a lane/readout split.

One write remains one write. The split says how the write is projected into settlement and continuation readouts.

A schematic state update can be written as

$$
W_i[dN]:
(X_i,u_i,D_{\rm set},C_A,I_{\rm write})
\mapsto
(X_i',u_i',D_{\rm set}',C_A',I_{\rm write}').
$$

The update contains:

1. **Admissibility:**

$$
X_i'=\text{next legal no-overwrite address}.
$$

2. **One-speed continuation:**

$$
\text{support advancement respects the }c\text{-budget.}
$$

3. **Settlement projection:**

$$
D_{\rm set}'=D_{\rm set}+\Pi_{\rm set}K_{\rm set}\,dN-\Phi_{\rm relax}.
$$

4. **Continuation/capacity projection:**

$$
I_{\rm write}'=I_{\rm write}+\Pi_{\rm cont}\,dN
$$

in projected capacity units.

5. **Gravity readout:**

$$
a=-c^2\nabla C_A.
$$

6. **Mass/closure readout:**

$$
\Delta\ln D_{\rm set}=P_{\rm coh}L_{\rm eff}u-\Phi_{\rm relax}.
$$

The compressed operator core is

$$
\boxed{
W=\text{irreversible write}
+ (\Pi_{\rm set},\Pi_{\rm cont})
+ \text{no-overwrite admissibility}.
}
$$

---

## 9. R282O result: 3:2 sector accessibility tax and `25/13`

The settlement projector has rank three:

$$
\operatorname{rank}(\Pi_{\rm set})=3.
$$

These are the three spatial settlement channels.

The closure/particle program supplies two independent internal phase channels:

$$
\phi_C=\text{mass cadence / Compton closure phase},
$$

$$
\theta_g=\text{charge/framing holonomy phase}.
$$

Thus the participation structure is grouped as

$$
3:2.
$$

This means three settlement components and two phase components, not five spacetime dimensions.

The grouped weights are

$$
w_S=\frac35,
\qquad
w_\Phi=\frac25.
$$

The participation concentration is

$$
\chi=w_S^2+w_\Phi^2
=\left(\frac35\right)^2+\left(\frac25\right)^2
=\frac9{25}+\frac4{25}
=\frac{13}{25}.
$$

The effective participation number is

$$
N_{\rm eff}=\frac1\chi=\frac{25}{13}.
$$

The amplitude-level accessibility tax is

$$
T_{\rm amp}=\frac12\ln N_{\rm eff}
=\frac12\ln\left(\frac{25}{13}\right).
$$

Numerically,

$$
T_{\rm amp}=0.326963233703332\ldots
$$

### Uniqueness check

If the settlement rank is fixed at 3 and the internal phase count is `n`, then

$$
N_{\rm eff}(n)=\frac{(3+n)^2}{9+n^2}.
$$

Requiring

$$
N_{\rm eff}=\frac{25}{13}
$$

selects

$$
n=2
$$

as the relevant integer internal-channel count, matching `phi_C` and `theta_g`.

---

## 10. R283O bridge: internal `phi_C / theta_g` independence gate

R283O tests whether the two phase channels used in the 3:2 sector tax are genuinely independent, rather than two names for one hidden phase.

The target is

$$
\operatorname{rank}\{\phi_C,\theta_g\}=2.
$$

The internal proof uses two independent admissible variations.

### 10.1 Same charge, different mass

Leptons such as electron, muon, and tau share the same electric charge sign and magnitude but have different masses. In SFT language, this means the charge/framing holonomy label can remain fixed while the mass cadence changes:

$$
\delta\theta_g = 0,
\qquad
\delta\phi_C \neq 0.
$$

This proves that `phi_C` cannot be fully determined by `theta_g`.

### 10.2 Same mass, opposite charge

Particle-antiparticle pairs have equal rest mass but opposite charge. In SFT language, this means the mass cadence can remain fixed while the charge/framing orientation changes:

$$
\delta\phi_C = 0,
\qquad
\delta\theta_g \neq 0.
$$

This proves that `theta_g` cannot be fully determined by `phi_C`.

### 10.3 Rank result

Since the theory admits both variations

$$
(\delta\phi_C,\delta\theta_g)=(\neq0,0),
$$

and

$$
(\delta\phi_C,\delta\theta_g)=(0,\neq0),
$$

the two phase handles span a rank-two internal phase sector:

$$
\boxed{\operatorname{rank}\{\phi_C,\theta_g\}=2.}
$$

This supports the R282O sector split:

$$
\operatorname{rank}(\Pi_{\rm set}) : \operatorname{rank}\{\phi_C,\theta_g\}
=3:2.
$$

Thus the `2` in the 3:2 grouped participation is not decorative. It is the rank of the independent closure/phase sector.

---

## 11. R284O bridge: public-facing independence derivation

R284O converts the R283O internal gate into a public-facing derivation attempt.

The public claim is deliberately narrower than the full SFT phase-origin claim:

> The two labels `phi_C` and `theta_g` must be independent if the theory is to represent same-charge/different-mass particles and same-mass/opposite-charge particles without contradiction.

It does not yet claim to fully derive the microscopic origin of both phases.

### 11.1 Public proposition

Let `phi_C` be the phase/cadence variable controlling rest-mass clocking. Let `theta_g` be the phase/holonomy variable controlling charge orientation.

If `phi_C` and `theta_g` were the same variable, then changing mass would necessarily change charge, or changing charge would necessarily change mass.

But the physical particle inventory contains both independent variations:

1. same charge with different mass,
2. same mass with opposite charge.

Therefore one phase variable is insufficient.

### 11.2 Public proof by independent variations

Same charge / different mass:

$$
\delta q = 0,
\qquad
\delta m \neq 0.
$$

Native SFT translation:

$$
\delta\theta_g = 0,
\qquad
\delta\phi_C \neq 0.
$$

Same mass / opposite charge:

$$
\delta m = 0,
\qquad
\delta q \neq 0.
$$

Native SFT translation:

$$
\delta\phi_C = 0,
\qquad
\delta\theta_g \neq 0.
$$

Therefore the two-dimensional variation matrix has two independent directions:

$$
\begin{pmatrix}
\delta\phi_C & \delta\theta_g
\end{pmatrix}
\in
\operatorname{span}\{(1,0),(0,1)\}.
$$

So

$$
\operatorname{rank}\{\phi_C,\theta_g\}=2.
$$

### 11.3 How the public bridge supports the 3:2 tax

R282O needs

$$
3:2 = \operatorname{rank}(\Pi_{\rm set}) : \operatorname{rank}\{\phi_C,\theta_g\}.
$$

R278O-R281O derive

$$
\operatorname{rank}(\Pi_{\rm set})=3.
$$

R283O/R284O support

$$
\operatorname{rank}\{\phi_C,\theta_g\}=2.
$$

Therefore the sector participation space is

$$
3:2.
$$

Then

$$
N_{\rm eff} = \frac{1}{(3/5)^2+(2/5)^2}=\frac{25}{13}.
$$

This is the public-facing bridge from observed independent particle variations to the internal 3:2 accessibility tax.

### 11.4 Public status

R284O is a public-facing partial pass:

$$
\boxed{\text{PUBLIC PARTIAL PASS: independence shown; microscopic phase origins still open}.}
$$

The independence claim is cleaner than the origin claim. V13.8 therefore elevates the independence bridge but keeps the deeper phase-origin derivation open.

---

## 12. Full `L_eff` derivation

Start from the operator-native form:

$$
L_{\rm eff}=\kappa(4\pi)-T_{\rm amp}.
$$

Insert the projector result:

$$
\kappa=\frac34.
$$

Thus

$$
\kappa(4\pi)=\frac34(4\pi)=3\pi.
$$

Insert the sector tax:

$$
T_{\rm amp}=\frac12\ln\left(\frac{25}{13}\right).
$$

Therefore

$$
L_{\rm eff}=3\pi-\frac12\ln\left(\frac{25}{13}\right).
$$

Numerically,

$$
3\pi=9.42477796076938\ldots
$$

$$
\frac12\ln\left(\frac{25}{13}\right)=0.326963233703332\ldots
$$

so

$$
L_{\rm eff}=9.097814727066048\ldots
$$

This is the frozen V12.13 value recovered as a projector/sector result:

$$
\boxed{
L_{\rm eff}=\frac34(4\pi)-\frac12\ln\left(\frac{25}{13}\right).
}
$$

Every coefficient is traced:

| Piece | Value | Origin |
|---|---:|---|
| Settlement projector | `3/4` | tangent-lane exclusion in 3+1 write capacity |
| Closure phase | `4pi` | spinor closure |
| Sector participation | `25/13` | 3 settlement channels : 2 phase channels |
| Amplitude tax | `(1/2)ln` | amplitude-level grouped participation penalty |

---

## 13. Interpretation by readout

### 13.1 Mass compounding

The D-scale compounding law becomes

$$
\Delta\ln D_{\rm set}=P_{\rm coh}L_{\rm eff}u-\Phi_{\rm relax},
$$

with

$$
L_{\rm eff}=\frac34(4\pi)-\frac12\ln\left(\frac{25}{13}\right).
$$

The leading gain is settlement-available spinor closure phase. The tax is the amplitude-level penalty from the protected 3:2 grouped participation. R283O/R284O support the phase-sector rank used in that tax.

### 13.2 Gravity

Gravity is the gradient readout of accumulated settlement:

$$
a=-c^2\nabla C_A.
$$

With

$$
C_A(E,r)=\frac{A_{\rm write}E}{\hbar c r},
$$

and

$$
A_{\rm write}=\frac{G\hbar}{c^3},
$$

this recovers the Newtonian exterior limit.

### 13.3 Expansion

Expansion is the continuation-capacity readout:

$$
H=\frac{\dot N_{\rm write}}{I_{\rm write}}.
$$

The boundary-capacity convention is now internally read as

$$
I_{\rm write}=\eta_I\frac{A_{\rm boundary}}{A_{\rm write}},
\qquad
\eta_I=\frac14.
$$

Thus the expansion lane is the complement of the settlement lane.

### 13.4 Particle spectrum and galactic morphology

The historical `kappa = 3/4` appearances are internally reinterpreted as the same projector-class invariant:

$$
\kappa=\frac{\operatorname{Tr}(\Pi_{\rm available})}{\operatorname{Tr}(I_4)}=\frac34.
$$

This does not require claiming the same coordinate direction is excluded in every readout. It requires the same rank-one exclusion structure over 3+1 write capacity.

### 13.5 Force-sector bridge

The two-phase result also helps the force-sector language:

$$
\phi_C \longrightarrow \text{mass cadence / proper-time closure},
$$

$$
\theta_g \longrightarrow \text{charge/framing holonomy / EM phase handle}.
$$

R283O/R284O do not derive all force dynamics. They show that the mass-cadence and charge-holonomy handles cannot be collapsed into one phase without losing known particle distinctions.

---

## 14. The compressed physical picture

One irreversible write uses the full local 3+1 write capacity.

The write cannot settle the lane needed for its own continuation.

Therefore

$$
\text{settlement lanes}=3,
\qquad
\text{continuation lane}=1.
$$

The settlement projection produces mass, gravity, and cumulative structure.

The continuation projection produces future-address demand and boundary growth.

The same event has two complementary projections:

$$
\Pi_{\rm set}:\frac34,
\qquad
\Pi_{\rm cont}:\frac14.
$$

The closure orbit adds `4pi`. The available settlement projection of that closure is `3pi`. The internal phase bridge supplies two independent closure/phase channels, giving the 3:2 sector grouping. The grouped participation supplies the accessibility tax `(1/2)ln(25/13)`. The result is `L_eff`.

The operator is therefore not primarily a mysterious nonlinear functional. Its core is dimensional bookkeeping under no-overwrite:

$$
\boxed{\text{count lanes, project continuation out, group channels, tax unequal participation, compound.}}
$$

---

## 15. V13.8 verdict

### Internal verdict

$$
\boxed{\text{V13.8 STRONG INTERNAL PASS / PUBLIC PARTIAL}.}
$$

### Status string

```text
FROZEN_SFT_V13_8_PROJECTOR_COMPRESSED_WRITE_OPERATOR_TWO_PHASE_BRIDGE_KAPPA_PLUS_ETA_EQUALS_ONE_LEFF_FROM_3PLUS1_PROJECTOR_4PI_CLOSURE_3TO2_SECTOR_TAX_PHIC_THETAG_RANK2_INDEPENDENCE_INTERNAL_PASS_PUBLIC_PARTIAL_KSET_PCOH_PHIRELAX_OPEN
```

### What is elevated by V13.8

1. `P_dir = 3/4` from tangent-lane exclusion in 3+1 write capacity.
2. `eta_I = 1/4` as the complementary continuation projector.
3. `kappa = P_dir = 3/4` as a common projector-class invariant.
4. `N_eff = 25/13` from a 3:2 grouped participation space.
5. `rank{phi_C, theta_g} = 2` as internal support for the two-phase sector.
6. The public-facing independence bridge: same-charge/different-mass and same-mass/opposite-charge variations require two independent phase handles.
7. `L_eff = 3pi - (1/2)ln(25/13)` as the leading geometric mass-compounding coefficient.
8. The compressed operator core:

$$
I_4=\Pi_{\rm set}+\Pi_{\rm cont},
\qquad
\operatorname{Tr}(\Pi_{\rm set}):\operatorname{Tr}(\Pi_{\rm cont})=3:1.
$$

### What remains open

1. Full microscopic derivation of `phi_C` as native mass cadence.
2. Full microscopic derivation of `theta_g` as charge/framing holonomy.
3. Charge quantization and fractional quark winding.
4. Fine-structure constant `alpha` and running.
5. Microscopic `K_set`.
6. Microscopic `P_coh`.
7. Microscopic `Phi_relax`.
8. Public normalization of `A_write` across raw-lane and readout-normalized conventions.
9. Full paper-ready integration with V12.7, SPARC, V13.2, V13.4, and V13.7 source documents.

---

## 16. Suggested next gates

### R285O - Native origin of `phi_C`

Target:

$$
\phi_C = \text{mass cadence from closed support phase},
$$

not merely imported Compton timing.

### R286O - Native origin of `theta_g`

Target:

$$
\theta_g = \text{charge/framing holonomy from directional write orientation},
$$

not merely relabeled electric charge.

### R287O - Two-phase force-sector integration

Target:

Show how the rank-two phase sector supports the V13.4 force stack: mass/rigidity through `phi_C`, EM/charge through `theta_g`, and their coupling boundaries without adding new primitive fields.

---

## 17. Final V13.8 summary

R276O-R284O convert the settlement-operator problem from a broad unknown functional into a compact projector-and-phase problem.

The result is

$$
\boxed{
\text{The write operator is a 3+1 projector partition applied to irreversible writes, with a rank-two internal closure-phase bridge.}
}
$$

Three lanes settle. One lane continues. The settlement lanes generate mass/gravity/structure. The continuation lane generates boundary growth/expansion. The `4pi` spinor closure supplies the phase length. The `3:2` settlement/phase grouping supplies the accessibility tax. The rank-two phase bridge supplies the two in that `3:2` split. Together they give the frozen `L_eff` coefficient with no new adjustable number.

The deepest current sentence remains:

> The same write that cannot settle its own continuation lane must grow the boundary through that lane.

The V13.8 addition is:

> The three settlement lanes and two independent closure phases form the protected 3:2 participation space that taxes the spinor closure gain into the observed `L_eff`.

Things look like the geometry that created them.

---

## 18. Acknowledgments

This V13.8 elevation preserves the R276O-R282O projector-compressed operator sequence and adds the R283O/R284O two-phase bridge. The Rosetta Stone/operator framing, minimal kernel attack, tangent-lane projector proof, eta complement, sector-tax uniqueness check, and phase-independence bridge were developed in collaboration between Shaun Fosmark, 5.6 Sol / GPT-5.5 Thinking (OpenAI), and Claude/Opus (Anthropic). The mechanical reframing of the operator as "the write is the operator," the continuation-lane expansion interpretation, and the cross-scale projector identity were developed across the same three-musketeers derivation chain.
