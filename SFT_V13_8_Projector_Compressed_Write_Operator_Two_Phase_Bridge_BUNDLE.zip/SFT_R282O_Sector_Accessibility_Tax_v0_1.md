# SFT R282O — Sector Accessibility Tax Inside the Projector Partition, v0.1

**Status:** Working derivation / internal audit gate.  
**Relation:** Follows R277O–R281O.  
**Purpose:** Test whether the remaining mass-compounding tax

\[
T_{\rm amp}=\frac12\ln\left(\frac{25}{13}\right)
\]

is already fixed by the projector-compressed write operator, rather than being an independent fitted or imported number.

---

## 1. Question

R278O–R281O derived the leading settlement participation factor

\[
\kappa=P_{\rm dir}=\frac{3}{4}
\]

from the 3+1 projector partition

\[
I_4=\Pi_{\rm set}+\Pi_{\rm cont},
\]

with

\[
{\rm Tr}(\Pi_{\rm set})=3,\qquad
{\rm Tr}(\Pi_{\rm cont})=1,\qquad
{\rm Tr}(I_4)=4.
\]

This gives the leading closure gain

\[
G_{\rm closure}=\left(\frac34\right)(4\pi)=3\pi.
\]

The frozen V12.13 coefficient is

\[
L_{\rm eff}=3\pi-\frac12\ln\left(\frac{25}{13}\right).
\]

R282O asks whether the remaining factor \(25/13\) can be read as a sector-accessibility consequence inside the same projector-compressed operator.

---

## 2. Claim boundary

R282O does **not** claim that \(25/13\) follows from the 3+1 projector alone.

The 3+1 projector supplies the spatial/settlement rank:

\[
d_{\rm set}=3.
\]

The second ingredient is the already-established two-phase closure structure:

\[
d_{\rm phase}=2,
\]

read natively as

\[
\phi_C = \text{mass cadence / Compton closure phase},
\]

\[
\theta_g = \text{charge/framing holonomy phase}.
\]

Thus R282O tests the composite statement:

\[
\text{sector split} = d_{\rm set}:d_{\rm phase}=3:2.
\]

Important: this is **not** five spacetime dimensions. It is a five-component participation space made from three spatial settlement channels plus two internal closure/phase channels.

---

## 3. Sector participation space

Define the participation space

\[
\mathcal P=\mathcal S\oplus\mathcal \Phi,
\]

where

\[
\dim(\mathcal S)={\rm Tr}(\Pi_{\rm set})=3,
\]

and

\[
\dim(\mathcal \Phi)=2.
\]

The sector weights are fixed by relative multiplicity:

\[
w_S=\frac{3}{3+2}=\frac35,
\]

\[
w_\Phi=\frac{2}{3+2}=\frac25.
\]

The grouped participation concentration is

\[
\chi_{3:2}=w_S^2+w_\Phi^2
=\left(\frac35\right)^2+\left(\frac25\right)^2
=\frac9{25}+\frac4{25}
=\frac{13}{25}.
\]

Therefore the effective grouped participation number is

\[
N_{\rm eff}=\frac{1}{\chi_{3:2}}
=\frac{25}{13}.
\]

The amplitude-level accessibility tax is

\[
T_{\rm amp}=\ln\sqrt{N_{\rm eff}}
=\frac12\ln(N_{\rm eff})
=\frac12\ln\left(\frac{25}{13}\right).
\]

Numerically,

\[
T_{\rm amp}=0.3269632337\ldots
\]

and therefore

\[
L_{\rm eff}
=\left(\frac34\right)(4\pi)-\frac12\ln\left(\frac{25}{13}\right)
=9.0978147271\ldots
\]

This matches the frozen V12.13 value.

---

## 4. What R282O adds beyond V12.13

V12.13 already had the 3+2 grouped participation arithmetic.

R282O adds the projector identification:

\[
3 = {\rm Tr}(\Pi_{\rm set}).
\]

So the old V12.13 split is no longer a disconnected sector-counting rule. Its spatial-sector weight is now the same settlement projector rank derived in R278O–R281O.

The two pieces of \(L_{\rm eff}\) now share one operator stack:

\[
L_{\rm eff}
=\underbrace{\left(\frac{{\rm Tr}(\Pi_{\rm set})}{{\rm Tr}(I_4)}\right)(4\pi)}_{\text{settlement phase gain}}
-
\underbrace{\frac12\ln\left(N_{\rm eff}^{3:2}\right)}_{\text{sector accessibility tax}}.
\]

With

\[
\frac{{\rm Tr}(\Pi_{\rm set})}{{\rm Tr}(I_4)}=\frac34,
\]

and

\[
N_{\rm eff}^{3:2}=\frac{1}{(3/5)^2+(2/5)^2}=\frac{25}{13}.
\]

---

## 5. Uniqueness check

Let the settlement rank be fixed by the projector:

\[
d_S=3.
\]

Let the number of internal phase channels be \(n\). The grouped effective participation number would be

\[
N_{\rm eff}(n)=\frac{(3+n)^2}{3^2+n^2}.
\]

Requiring the frozen value

\[
N_{\rm eff}(n)=\frac{25}{13}
\]

gives

\[
13(3+n)^2=25(9+n^2),
\]

or

\[
2n^2-13n+18=0.
\]

The roots are

\[
n=2,\qquad n=\frac92.
\]

For an integer channel count, the admissible solution is

\[
n=2.
\]

Thus, once \(d_S=3\) is fixed by the projector and channels are discrete, the frozen \(25/13\) tax uniquely selects two internal phase channels. This is exactly the SFT two-phase structure \(\phi_C,\theta_g\).

---

## 6. Alternative-channel fail checks

If there were only one internal phase channel, the grouped split would be \(3:1\):

\[
N_{\rm eff}^{3:1}=\frac{1}{(3/4)^2+(1/4)^2}=\frac{8}{5}=1.6,
\]

with

\[
T_{\rm amp}=\frac12\ln(8/5)=0.2350\ldots
\]

This does not recover the frozen coefficient.

If there were three internal phase channels, the split would be \(3:3\):

\[
N_{\rm eff}^{3:3}=2,
\]

with

\[
T_{\rm amp}=\frac12\ln 2=0.3466\ldots
\]

This also does not recover the frozen coefficient.

So the frozen \(25/13\) value is not generic. It is specifically the grouped participation tax for three settlement channels and two phase channels.

---

## 7. Operator compression after R282O

The compressed write operator now has the following internal structure:

1. **Project:**

\[
I_4=\Pi_{\rm set}+\Pi_{\rm cont}.
\]

2. **Count settlement rank:**

\[
{\rm Tr}(\Pi_{\rm set})=3.
\]

3. **Count continuation rank:**

\[
{\rm Tr}(\Pi_{\rm cont})=1.
\]

4. **Compute settlement participation:**

\[
\kappa=P_{\rm dir}=\frac34.
\]

5. **Compute boundary continuation complement:**

\[
\eta_I=\frac14.
\]

6. **Add closure phase:**

\[
4\pi.
\]

7. **Group settlement and phase sectors:**

\[
3:2.
\]

8. **Compute grouped accessibility:**

\[
N_{\rm eff}=\frac{25}{13}.
\]

9. **Apply amplitude-level tax:**

\[
T_{\rm amp}=\frac12\ln\left(\frac{25}{13}\right).
\]

10. **Obtain compounding coefficient:**

\[
L_{\rm eff}
=\left(\frac34\right)(4\pi)-\frac12\ln\left(\frac{25}{13}\right).
\]

Native summary:

> The operator projects a write into three settlement lanes and one continuation lane. The three settlement lanes couple to two internal closure phases, producing a protected 3:2 sector split. The grouped participation tax of that split is \(\frac12\ln(25/13)\). Thus the frozen mass-compounding coefficient is projector phase gain minus sector-accessibility tax.

---

## 8. Pass/fail criteria

### PASS_INTERNAL

R282O passes internally if the following prerequisites are accepted:

1. R278O/R281O: \({\rm Tr}(\Pi_{\rm set})=3\).  
2. R261F/V13.4: two independent phase channels \(\phi_C,\theta_g\).  
3. V12.13: grouped amplitude participation tax uses \(N_{\rm eff}=1/\sum_a w_a^2\).  

Under those prerequisites, \(25/13\) is derived as the 3:2 grouped sector participation number.

### PARTIAL_PUBLIC

For public translation, R282O remains partial until the paper clearly explains why the two phase channels are independent and why the grouped participation tax has the inverse-concentration form.

### FAIL condition

R282O fails if either:

1. the three spatial settlement channels cannot be identified with \({\rm Tr}(\Pi_{\rm set})=3\), or  
2. \(\phi_C\) and \(\theta_g\) are not independent phase channels, or  
3. the amplitude tax is not justified as a grouped participation penalty.

---

## 9. Verdict

\[
\boxed{
\text{R282O\_V0\_1\_PASS\_INTERNAL\_SECTOR\_ACCESSIBILITY\_TAX\_25\_13\_DERIVED\_FROM\_RANK3\_SETTLEMENT\_PROJECTOR\_PLUS\_TWO\_CLOSURE\_PHASES\_PUBLIC\_PARTIAL\_PENDING\_PHASE\_INDEPENDENCE\_AND\_AMPLITUDE\_TAX\_EXPOSITION}
}
\]

Short form:

\[
\boxed{
L_{\rm eff}=\left(\frac34\right)(4\pi)-\frac12\ln\left(\frac{25}{13}\right)
}
\]

with every coefficient now internally traceable:

- \(3/4\): rank-three settlement projector over 3+1 write capacity.  
- \(4\pi\): spinor closure phase.  
- \(25/13\): grouped participation of three settlement channels and two phase channels.  
- \(1/2\ln\): amplitude-level tax from grouped accessibility.  

R282O therefore closes the main \(L_{\rm eff}\) coefficient internally, subject to the stated prerequisites.
