# SFT R283O — \(\phi_C/\theta_g\) Independence Gate, v0.1

**Status:** Internal proof gate / working preservation note.  
**Source stack:** V12.13, R261F/R261.5F, V13.4 force-sector phase split, R282O sector accessibility tax, Internal Note 04.  
**Purpose:** Test whether the two internal closure/phase channels used in the R282O `3:2` sector accessibility tax are genuinely independent, rather than two labels for one hidden phase.

---

## 0. One-line result

The two phase channels are independent in the internal SFT sense because there exist admissible physical variations that change mass cadence \(\phi_C\) while holding charge/framing holonomy \(\theta_g\) fixed, and admissible variations that reverse \(\theta_g\) while holding \(\phi_C\) fixed.

Therefore the internal phase sector has rank two:

\[
\operatorname{rank}\{\phi_C,\theta_g\}=2.
\]

This supports the R282O grouped participation split:

\[
\text{three settlement channels} : \text{two phase channels} = 3:2,
\]

and preserves

\[
N_{\rm eff}=\frac{1}{(3/5)^2+(2/5)^2}=\frac{25}{13}.
\]

---

## 1. Claim boundary

### Claimed internally

R283O claims that \(\phi_C\) and \(\theta_g\) are independent closure coordinates / phase handles.

- \(\phi_C\) is the scalar mass-cadence / Compton closure phase.
- \(\theta_g\) is the directional charge/framing holonomy phase.

They are not two names for one phase because their observable readouts can be varied independently.

### Not claimed here

R283O does **not** fully derive:

1. the numerical mass spectrum,
2. the value or running of \(\alpha\),
3. the full Maxwell action,
4. the full weak/strong sector,
5. the microscopic origin of all generation structure,
6. the detailed winding quantization of fractional quark charge.

Those remain in the force-sector / particle-inventory stack.

R283O only tests the rank-two independence needed by the R282O sector tax.

---

## 2. Definitions

Let the local internal closure phase state be represented as

\[
\Phi = (\phi_C,\theta_g).
\]

The two native readouts are:

\[
\omega_C \equiv \dot{\phi}_C = \frac{mc^2}{\hbar},
\]

for mass cadence / Compton phase rate, and

\[
q \propto \frac{1}{2\pi}\oint d\theta_g,
\]

for charge/framing holonomy winding.

In SFT language:

- \(\phi_C\) tells how fast the closed support writes its local clock.
- \(\theta_g\) tells the signed directional holonomy carried by the support.

The independence question is:

\[
\text{Is } \Phi \text{ a one-dimensional phase disguised as two labels, or a true two-dimensional phase torus?}
\]

The target is:

\[
\Phi \in S^1_C \times S^1_g,
\]

not

\[
\Phi \in S^1 \quad \text{with two aliases}.
\]

---

## 3. Proof strategy

A two-coordinate phase system is independent if there exist two admissible variations:

\[
\delta_1\phi_C \neq 0, \qquad \delta_1\theta_g = 0,
\]

and

\[
\delta_2\phi_C = 0, \qquad \delta_2\theta_g \neq 0.
\]

Equivalently, the local observable map

\[
F:(\phi_C,\theta_g)\mapsto(m,q)
\]

has rank two if the two independent variations map to independent observable changes:

\[
\delta_1(m,q)=(\delta m,0),
\]

and

\[
\delta_2(m,q)=(0,\delta q).
\]

R283O tests exactly these two variations.

---

## 4. Test A — same charge, different mass

### Native statement

Lepton generation changes mass cadence while preserving charge holonomy.

Electron, muon, and tau carry the same charge sign/magnitude but have different mass cadences. In SFT language:

\[
\theta_g(e)=\theta_g(\mu)=\theta_g(\tau),
\]

while

\[
\dot{\phi}_C(e)\neq \dot{\phi}_C(\mu)\neq \dot{\phi}_C(\tau).
\]

Because

\[
\dot{\phi}_C = \frac{mc^2}{\hbar},
\]

different masses mean different \(\phi_C\) cadence.

Therefore there exists a variation:

\[
\delta\phi_C\neq 0,\qquad \delta\theta_g=0.
\]

### Gate result

**PASS.**  
Mass cadence can vary while charge holonomy remains fixed.

---

## 5. Test B — same mass cadence, opposite charge

### Native statement

Charge conjugation reverses the directional holonomy while preserving the mass cadence.

For a particle/antiparticle pair such as electron/positron:

\[
\dot{\phi}_C(e^-)=\dot{\phi}_C(e^+),
\]

but

\[
\theta_g(e^+)=-\theta_g(e^-),
\]

or, equivalently,

\[
q(e^+)=-q(e^-).
\]

The Compton cadence is unchanged because the rest mass is unchanged. The charge/framing holonomy reverses orientation.

Therefore there exists a variation:

\[
\delta\phi_C=0,\qquad \delta\theta_g\neq 0.
\]

### Gate result

**PASS.**  
Charge holonomy can reverse while mass cadence remains fixed.

---

## 6. Test C — neutral massive support

### Native statement

A neutral massive system can retain mass cadence while carrying zero net charge holonomy.

For a neutral composite, charge holonomies cancel in the net readout while mass/energy cadence remains positive:

\[
\sum_i \theta_{g,i}=0,
\]

but

\[
\omega_C = \frac{E_{\rm rest}}{\hbar} > 0.
\]

This shows that the mass-cadence readout is not merely charge holonomy in disguise.

### Gate result

**PASS as composite/net-readout guardrail.**  
A net-zero \(\theta_g\) readout does not imply zero \(\phi_C\) cadence.

---

## 7. Test D — massless charged-directional propagation versus massive closure

### Native statement

Open photon-like support carries propagation/field phase without rest-mass closure. Massive charged support carries both mass cadence and charge holonomy.

The relevant distinction is:

\[
\text{open support: no rest } \phi_C \text{ closure, but field phase/holonomy can propagate},
\]

while

\[
\text{closed massive support: } \phi_C \text{ cadence is active, and } \theta_g \text{ may be charged, neutral, or canceled.}
\]

This prevents collapsing \(\theta_g\) into \(\phi_C\): field/holonomy behavior can exist in open propagation, while rest-mass cadence requires closed support.

### Gate result

**PASS as structural guardrail.**  
Open/closed support distinguishes propagation holonomy from rest-mass cadence.

---

## 8. Test E — transformation behavior

### Native statement

The two phases transform differently.

- \(\phi_C\) is a scalar cadence: it sets the local clock rate of closed support.
- \(\theta_g\) is a signed directional/framing holonomy: it changes sign under charge conjugation and supports gauge relabeling.

If they were one phase, then reversing charge would reverse mass cadence, or changing mass generation would change charge. Neither is allowed by the stable particle inventory.

The transformation table is:

| Operation | \(\phi_C\) | \(\theta_g\) | Meaning |
|---|---:|---:|---|
| generation/mass change at fixed charge | changes | fixed | \(\phi_C\) independent of \(\theta_g\) |
| charge conjugation | fixed | sign flips | \(\theta_g\) independent of \(\phi_C\) |
| neutralization/cancellation | net cadence remains | net holonomy cancels | mass not equal charge |
| gauge relabeling of charge frame | invariant cadence | relabeled holonomy | different symmetry action |

### Gate result

**PASS.**  
The two phases have different transformation behavior.

---

## 9. Algebraic rank proof

Let local physical readouts be approximated by

\[
M = M(\dot{\phi}_C),
\]

and

\[
Q = Q\left(\oint d\theta_g\right).
\]

To first order, the Jacobian of readouts with respect to phase coordinates has block form:

\[
J =
\begin{pmatrix}
\partial M/\partial \phi_C & \partial M/\partial \theta_g \\
\partial Q/\partial \phi_C & \partial Q/\partial \theta_g
\end{pmatrix}
\sim
\begin{pmatrix}
\ast & 0 \\
0 & \ast
\end{pmatrix}.
\]

The two nonzero diagonal entries are operationally established by Tests A and B. Therefore:

\[
\operatorname{rank}(J)=2.
\]

Hence:

\[
\operatorname{rank}\{\phi_C,\theta_g\}=2.
\]

This is exactly the channel count needed for the R282O tax.

---

## 10. Consequence for R282O

R282O required two independent closure/phase channels in addition to the three settlement channels:

\[
3:n.
\]

It showed:

\[
N_{\rm eff}(n)=\frac{(3+n)^2}{9+n^2}.
\]

Requiring the frozen value

\[
N_{\rm eff}=\frac{25}{13}
\]

selects

\[
n=2.
\]

R283O now supplies the internal reason for \(n=2\):

\[
n=\operatorname{rank}\{\phi_C,\theta_g\}=2.
\]

Therefore:

\[
N_{\rm eff}=\frac{1}{(3/5)^2+(2/5)^2}=\frac{25}{13},
\]

and

\[
T_{\rm amp}=\frac12\ln\left(\frac{25}{13}\right).
\]

The leading mass coefficient remains:

\[
L_{\rm eff}=\left(\frac34\right)(4\pi)-\frac12\ln\left(\frac{25}{13}\right).
\]

---

## 11. Contradiction test

Assume instead that \(\phi_C\) and \(\theta_g\) are one phase:

\[
\theta_g=f(\phi_C).
\]

Then any change in \(\phi_C\) must induce a change in \(\theta_g\), unless \(f\) is locally constant. But Test A requires different masses at fixed charge:

\[
\delta\phi_C\neq0,\qquad\delta\theta_g=0.
\]

If \(f\) is locally constant to satisfy Test A, then Test B cannot hold, because charge reversal at fixed mass requires

\[
\delta\phi_C=0,\qquad\delta\theta_g\neq0.
\]

No one-dimensional phase can satisfy both independent variations.

Therefore:

\[
\theta_g \neq f(\phi_C)
\]

as a single hidden phase. The phase space must be at least two-dimensional.

---

## 12. Updated operator compression

R277O–R282O compressed the operator core as:

\[
\text{project} \rightarrow \text{count} \rightarrow \text{group} \rightarrow \text{tax} \rightarrow \text{compound}.
\]

R283O strengthens the `group` step:

\[
\text{group} = \operatorname{rank}(\Pi_{\rm set}) : \operatorname{rank}\{\phi_C,\theta_g\}=3:2.
\]

So the compressed operator stack becomes:

\[
I_4=\Pi_{\rm set}+\Pi_{\rm cont},
\]

\[
\operatorname{Tr}(\Pi_{\rm set})=3,
\qquad
\operatorname{Tr}(\Pi_{\rm cont})=1,
\]

\[
\kappa=P_{\rm dir}=3/4,
\qquad
\eta_I=1/4,
\]

\[
\operatorname{rank}\{\phi_C,\theta_g\}=2,
\]

\[
N_{\rm eff}=\frac{25}{13},
\]

\[
L_{\rm eff}=3\pi-\frac12\ln\left(\frac{25}{13}\right).
\]

---

## 13. Remaining open debts

R283O closes the internal rank-two independence gate, but leaves these public-facing debts:

1. A polished public derivation of \(\theta_g\) as charge/framing holonomy.
2. A polished public derivation of \(\phi_C\) as mass cadence rather than imported Compton clock language.
3. The detailed relationship between \(\theta_g\), electromagnetic gauge freedom, and charge quantization.
4. The detailed relationship between \(\phi_C\), generation structure, and mass hierarchy beyond the leading \(L_{\rm eff}\) coefficient.
5. The microscopic form of \(P_{\rm coh}\) inside the closure compounding law.
6. The microscopic forms of \(K_{\rm set}\) and \(\Phi_{\rm relax}\).

---

## 14. Verdict

\[
\boxed{
\text{R283O\_V0\_1\_PASS\_INTERNAL\_PHIC\_THETAG\_INDEPENDENCE\_RANK2\_PHASE\_SECTOR\_SUPPORTED\_BY\_FIXED\_CHARGE\_MASS\_VARIATION\_AND\_FIXED\_MASS\_CHARGE\_CONJUGATION\_N_EFF\_25\_13\_SECTOR\_TAX\_NOW\_OPERATOR\_SUPPORTED\_PUBLIC\_DERIVATION\_OF\_PHASE\_ORIGINS\_REMAINS\_OPEN}
}
\]

Short verdict:

**PASS_INTERNAL.**  
The two-channel phase sector used in R282O is internally supported. \(\phi_C\) and \(\theta_g\) are independent phase handles, not duplicate labels.

---

## 15. Final summary

The settlement projector supplies three spatial settlement channels. The particle closure supplies two independent internal phases: mass cadence \(\phi_C\) and charge/framing holonomy \(\theta_g\). These two phases are operationally independent because mass can vary at fixed charge and charge can reverse at fixed mass.

Therefore the sector split used in the accessibility tax is not arbitrary:

\[
3:2 = \operatorname{rank}(\Pi_{\rm set}) : \operatorname{rank}\{\phi_C,\theta_g\}.
\]

This supports

\[
N_{\rm eff}=25/13,
\qquad
T_{\rm amp}=\frac12\ln(25/13),
\qquad
L_{\rm eff}=3\pi-\frac12\ln(25/13).
\]

R283O therefore strengthens Internal Note 04: the full leading \(L_{\rm eff}\) coefficient is now supported by projector rank, spinor closure, and rank-two internal phase independence.
