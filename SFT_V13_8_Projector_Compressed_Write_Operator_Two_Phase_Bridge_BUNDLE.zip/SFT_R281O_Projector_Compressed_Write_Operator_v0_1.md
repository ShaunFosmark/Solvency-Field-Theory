# SFT R281O — Projector-Compressed Write Operator, v0.1

**Status:** Working derivation gate / internal operator-compression attempt.  
**Inputs:** R277O minimal settlement kernel, R278O tangent-lane proof, R279O kappa projector audit, R280O eta_I boundary projector derivation.  
**Goal:** Test whether the microscopic settlement/continuation operator can be written as a single 3+1 projector partition applied to each irreversible write.

---

## 1. Central compression target

The candidate compression is:

```text
The operator is the write.
The write is a 3+1 projector partition.
```

One irreversible write carries one full local write-capacity identity:

```text
I_4 = Pi_set + Pi_cont
```

with:

```text
Tr(I_4)       = 4
Tr(Pi_set)    = 3
Tr(Pi_cont)   = 1
```

Therefore:

```text
kappa = P_dir = Tr(Pi_set)/Tr(I_4)  = 3/4
eta_I         = Tr(Pi_cont)/Tr(I_4) = 1/4
kappa + eta_I = 1
```

**Native interpretation:**  
The same write that cannot settle its own continuation lane must grow the boundary through that lane.

---

## 2. Operator object

Let a local write state contain:

```text
X_i        = current support/address state
u_i        = one-speed continuation/budget state
D_set      = accumulated settlement record
C_A        = compactness/settlement readout
I_write    = global continuation-capacity ledger
```

Let `dN` be a write-count increment, with full-cycle or reduced/radian convention stated explicitly.

The projector-compressed write operator is:

```text
W_i[dN] : (X_i, nu_i, D_set, C_A, I_write)
       -> (X_i', nu_i', D_set', C_A', I_write')
```

with the decomposition:

```text
W_i[dN] = NoOverwrite [ Pi_cont dN  +  Pi_set dN ]
```

where:

```text
Pi_cont dN  = continuation / fresh-address / boundary-capacity projection
Pi_set dN   = settlement / gravity / mass-compounding projection
```

This is not a split of energy into two independent substances. It is a split of the *readout lanes* of one irreversible write.

---

## 3. Lane-normalized update rules

### 3.1 Continuation-capacity update

The continuation projection is rank one:

```text
eta_I = Tr(Pi_cont)/Tr(I_4) = 1/4
```

So the active boundary-capacity convention becomes:

```text
I_write = eta_I A_boundary / A_write
```

and the global expansion readout remains:

```text
H = dotN_write / I_write
```

where:

```text
dotN_write = sum_a chi_a E_a/h
```

in full-cycle gauge, or:

```text
dotN_hbar = sum_a chi_a E_a/hbar
```

in reduced/radian gauge.

### 3.2 Settlement update

The settlement projection is rank three:

```text
kappa = Tr(Pi_set)/Tr(I_4) = 3/4
```

A generic local update may be written:

```text
D_set' = D_set + kappa K_set[X_i -> X_i'] dN - Phi_relax
```

or, with coherence made explicit:

```text
D_set' = D_set + P_coh kappa K_set[X_i -> X_i'] dN - Phi_relax
```

Here:

```text
K_set     = microscopic settlement-deposition kernel
P_coh     = coherence/admissibility participation factor
Phi_relax = relaxation/dilution term without erasure
```

The projector partition fixes the universal 3/4 lane factor. It does not yet define the detailed shape of `K_set`, `P_coh`, or `Phi_relax`.

---

## 4. Exterior gravity readout

R277O fixed the static exterior kernel:

```text
C_A(x,t) = A_write ∫ [rho_E(y,t-r/c)/(hbar c r)] d^3y
```

For a static point source:

```text
C_A(E,r) = A_write E/(hbar c r)
```

With:

```text
A_write = G hbar / c^3
```

this gives:

```text
C_A(M,r) = GM/(c^2 r)
```

and:

```text
a = -c^2 grad C_A
```

recovers Newtonian gravity.

### 4.1 A_write normalization audit

Projector compression exposes a convention choice.

**Readout-normalized convention:**  
`A_write` in the gravity equation is the already-settlement-normalized write footprint measured by the exterior gravity readout. Then no extra visible `kappa` multiplies the frozen G-root equation.

**Raw-lane convention:**  
Introduce an unprojected footprint `A_0`, with:

```text
A_set  = kappa A_0
A_cont = eta_I A_0
```

The gravity-measured footprint is:

```text
A_set = G hbar / c^3
```

so:

```text
A_0 = (4/3) G hbar/c^3
A_cont = (1/3) G hbar/c^3
```

Both conventions are algebraically equivalent if stated consistently. For continuity with V13.1, this gate keeps the readout-normalized convention and flags raw-lane normalization as an open public-translation issue.

---

## 5. Mass-compounding readout

For one full 4π spinor closure:

```text
G_closure = ∫_0^(4π) kappa dphi
          = (3/4)(4π)
          = 3π
```

The V12.13/V13 mass-compounding coefficient becomes:

```text
L_eff = kappa (4π) - 1/2 ln(25/13)
      = 3π - 1/2 ln(25/13)
      = 9.097814727066048...
```

Native readout:

```text
3/4        = 3+1 projector partition
4π         = spinor closure phase
25/13      = sector-accessibility ratio
1/2 ln     = amplitude-level tax
```

Thus the leading mass-hierarchy coefficient is no longer an isolated numeric closure load. It is a projector-weighted spinor-closure gain minus the sector-accessibility tax.

---

## 6. Expansion readout

The continuation lane is the complement of the settlement lanes:

```text
eta_I = 1 - kappa = 1/4
```

Therefore V13.2's quarter-boundary capacity can be written as the active continuation projection of the raw boundary ledger:

```text
I_write = eta_I A_boundary/A_write
```

The expansion readout is then:

```text
H = dotN_write/I_write
```

Native sentence:

```text
Expansion is the global readout of the continuation lane that local settlement cannot occupy.
```

---

## 7. Unified readout table

| Readout | Projector lane | Trace fraction | Equation / role |
|---|---:|---:|---|
| Settlement / gravity | `Pi_set` | `3/4` | local deposition, exterior `C_A`, gravity gradient |
| Mass compounding | `Pi_set` over 4π closure | `3/4` | `L_eff = (3/4)(4π) - 1/2 ln(25/13)` |
| Particle spectrum slot capacity | available 3+1 lanes | `3/4` | V12.7 `kappa` projector class |
| SPARC/disk morphology | admissible disk support lanes | `3/4` | `kappa_disk = 3/4` projector class |
| Expansion capacity | `Pi_cont` | `1/4` | `eta_I = 1/4`, `I_write = eta_I A_boundary/A_write` |
| Full write | `I_4` | `1` | `Pi_set + Pi_cont = I_4` |

---

## 8. What is now solved vs still open

### Solved internally by R277O-R281O

```text
1. Static exterior settlement kernel fixed by gravity.
2. P_dir = 3/4 derived from tangent-lane exclusion.
3. kappa = P_dir promoted to common projector-class invariant.
4. eta_I = 1/4 derived as continuation-projector complement.
5. L_eff leading term 3π derived as (3/4)(4π).
6. Operator core compressed to projector partition.
```

### Still open

```text
1. K_set microshape: exact local deposition kernel beyond exterior static limit.
2. P_coh microdefinition: coherence/admissibility projector inside Pi_set.
3. Phi_relax: exact relaxation/dilution law under expansion without erasure.
4. A_write raw-vs-readout normalization for public presentation.
5. Sector-ratio derivation of 25/13 from first principles inside the settlement subspace.
6. Explicit coarse-graining from discrete W_i[dN] to V13.7 action terms.
```

---

## 9. Pass / partial / fail criteria

**PASS if:**  
The operator core can be written as a 3+1 projector partition, and the projector partition consistently generates `kappa = 3/4`, `P_dir = 3/4`, `eta_I = 1/4`, and the leading `3π` part of `L_eff` without adding a new primitive.

**PARTIAL if:**  
The projector core works, but `K_set`, `P_coh`, `Phi_relax`, and raw `A_write` normalization remain unresolved.

**FAIL if:**  
Mass compounding, expansion, and gravity require unrelated projectors or independent constants rather than the single `I_4 = Pi_set + Pi_cont` partition.

---

## 10. Working verdict

```text
R281O_V0_1_STRONG_PARTIAL_PASS_PROJECTOR_COMPRESSED_WRITE_OPERATOR_CORE_DERIVED_KAPPA_PDIR_ETA_PARTITION_UNIFIES_MASS_EXPANSION_SETTLEMENT_READOUTS_KSET_PCOH_PHIRELAX_AWRITE_NORMALIZATION_REMAIN_OPEN
```

---

## 11. Clean one-line operator statement

```text
One irreversible write applies the 3+1 projector partition: three lanes deposit settlement, one lane preserves continuation; gravity and mass are the accumulated settlement projection, while expansion is the continuation projection required because no write can overwrite its own path.
```

