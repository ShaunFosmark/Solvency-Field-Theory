# SFT R284O — Public-Facing Derivation of \(\phi_C/\theta_g\) Independence, v0.1

**Status:** Public-facing derivation attempt / working note.  
**Depends on:** R261F/R261.5F, V13.4 phase split, R282O sector tax, R283O internal independence gate, Internal Note 04.  
**Purpose:** Convert the internal R283O gate into a public-facing argument that the mass-cadence phase \(\phi_C\) and charge/framing holonomy \(\theta_g\) are independent physical phase channels.

---

## 0. One-line result

A massive charged particle needs at least two independent phase handles:

\[
\phi_C \quad \text{for rest-energy / Compton mass cadence},
\]

and

\[
\theta_g \quad \text{for charge / electromagnetic holonomy}.
\]

They cannot be one hidden phase, because nature allows mass to vary while charge is held fixed, and charge orientation to reverse while mass is held fixed.

Therefore:

\[
\operatorname{rank}\{\phi_C,\theta_g\}=2.
\]

This supplies the public-facing support for the R282O sector split:

\[
3:2
=
\text{three settlement channels}:
\text{two independent phase channels}.
\]

---

## 1. Claim boundary

### Claimed here

R284O claims that the two SFT phase handles are independent in the public/operational sense:

1. \(\phi_C\) controls mass cadence / rest-energy phase.
2. \(\theta_g\) controls charge orientation / electromagnetic holonomy.
3. Physical variations exist that change one while holding the other fixed.

### Not claimed here

R284O does not claim to derive:

1. the full charged lepton mass spectrum,
2. the numerical value of electric charge,
3. the fine-structure constant \(\alpha\),
4. fractional quark charges,
5. electroweak mixing,
6. the full Maxwell or Standard Model action.

This note only proves the independence/rank-two claim needed for the public version of the R282O accessibility tax.

---

## 2. Public translation dictionary

| SFT term | Public-facing physics translation | Main readout |
|---|---|---|
| \(\phi_C\) | rest-energy / Compton phase cadence | mass/proper-time clock |
| \(\theta_g\) | charge/framing holonomy phase | electric charge / gauge coupling sign |
| \(\dot\phi_C\) | phase rate associated with rest energy | \(mc^2/\hbar\) |
| \(\oint d\theta_g\) | closed-loop charge/gauge winding | \(q\), up to normalization |

The public-facing statement is:

\[
\dot\phi_C = \frac{mc^2}{\hbar}
\]

and

\[
q \propto \frac{1}{2\pi}\oint d\theta_g.
\]

The first phase measures how fast a closed massive support writes its internal clock. The second phase measures the signed charge holonomy carried by that support.

---

## 3. What independence means

Let the internal phase state be:

\[
\Phi=(\phi_C,\theta_g).
\]

Let the observable readout map be:

\[
F:(\phi_C,\theta_g)\mapsto(m,q).
\]

The two coordinates are independent if there are two allowed variations:

\[
\delta_1\phi_C\ne0,
\qquad
\delta_1\theta_g=0,
\]

and

\[
\delta_2\phi_C=0,
\qquad
\delta_2\theta_g\ne0.
\]

Equivalently, the observable map has rank two:

\[
\operatorname{rank}\left(\frac{\partial(m,q)}{\partial(\phi_C,\theta_g)}\right)=2.
\]

---

## 4. Test A — same charge, different mass

Charged leptons provide the cleanest public guardrail.

The electron, muon, and tau have the same electric charge sign and magnitude, but different rest masses. In SFT language:

\[
\theta_g(e)=\theta_g(\mu)=\theta_g(\tau),
\]

while

\[
\dot\phi_C(e)\ne\dot\phi_C(\mu)\ne\dot\phi_C(\tau).
\]

Because:

\[
\dot\phi_C=\frac{mc^2}{\hbar},
\]

different masses require different mass cadence.

Therefore nature allows:

\[
\delta\phi_C\ne0,
\qquad
\delta\theta_g=0.
\]

So mass cadence can vary while charge holonomy remains fixed.

**Result:** \(\phi_C\) is not determined by \(\theta_g\).

---

## 5. Test B — same mass, opposite charge

Particle/antiparticle pairs provide the complementary guardrail.

The electron and positron have equal rest mass but opposite electric charge. In SFT language:

\[
\dot\phi_C(e^-)=\dot\phi_C(e^+),
\]

but

\[
\theta_g(e^+)=-\theta_g(e^-).
\]

The mass cadence is unchanged because the rest mass is unchanged. The charge holonomy reverses orientation.

Therefore nature allows:

\[
\delta\phi_C=0,
\qquad
\delta\theta_g\ne0.
\]

So charge holonomy can vary while mass cadence remains fixed.

**Result:** \(\theta_g\) is not determined by \(\phi_C\).

---

## 6. Test C — neutral massive matter

A neutral massive object has nonzero rest energy while its net charge is zero. In SFT language:

\[
\omega_C=\frac{E_{\rm rest}}{\hbar}>0,
\]

while

\[
\sum_i \theta_{g,i}=0
\]

at the net charge readout.

This does not mean the constituent charge holonomies vanish individually; rather, their signed readouts cancel. The key point is that mass cadence remains active even when net charge holonomy cancels.

**Result:** mass cadence is not charge in disguise.

---

## 7. Test D — different transformation behavior

The two phases also transform differently.

| Operation | \(\phi_C\) | \(\theta_g\) | Meaning |
|---|---:|---:|---|
| change lepton generation at fixed charge | changes | fixed | mass cadence independent of charge |
| charge conjugation | fixed | sign flips | charge orientation independent of mass |
| neutral composition | positive net rest cadence | net charge cancels | mass not equal charge |
| charge-frame relabeling | invariant scalar cadence | holonomy/gauge label changes | different symmetry action |

If \(\phi_C\) and \(\theta_g\) were one phase, these transformations would not be independently available.

---

## 8. Contradiction proof

Assume the two phases are actually one hidden phase. Then either:

\[
\theta_g=f(\phi_C),
\]

or

\[
\phi_C=g(\theta_g).
\]

Now apply Test A. Same charge but different mass requires:

\[
\delta\phi_C\ne0,
\qquad
\delta\theta_g=0.
\]

For \(\theta_g=f(\phi_C)\), this is only possible if \(f\) is locally constant along the variation.

But Test B requires the opposite variation:

\[
\delta\phi_C=0,
\qquad
\delta\theta_g\ne0.
\]

If \(f\) is locally constant, Test B is impossible. If \(f\) is not locally constant, Test A is impossible.

Therefore no one-dimensional hidden phase can satisfy both tests.

Thus:

\[
\Phi \ne S^1 \quad \text{with two labels}.
\]

The minimum phase space is:

\[
\Phi \in S^1_C\times S^1_g.
\]

So:

\[
\operatorname{rank}\{\phi_C,\theta_g\}=2.
\]

---

## 9. Jacobian form

At the readout level:

\[
M=M(\dot\phi_C),
\]

and

\[
Q=Q\left(\oint d\theta_g\right).
\]

The first-order readout Jacobian has block form:

\[
J
=
\begin{pmatrix}
\partial M/\partial \phi_C & \partial M/\partial \theta_g\\
\partial Q/\partial \phi_C & \partial Q/\partial \theta_g
\end{pmatrix}
\sim
\begin{pmatrix}
\ast & 0\\
0 & \ast
\end{pmatrix}.
\]

Tests A and B establish that both diagonal entries are nonzero while the cross-dependences are not required for the leading identity.

Therefore:

\[
\operatorname{rank}(J)=2.
\]

---

## 10. Consequence for the 3:2 sector tax

Internal Note 04 and R282O require a grouped participation split:

\[
\text{settlement sector} : \text{phase sector}=3:2.
\]

R278O supplies the settlement rank:

\[
\operatorname{rank}(\Pi_{\rm set})=3.
\]

R284O supplies the phase rank:

\[
\operatorname{rank}\{\phi_C,\theta_g\}=2.
\]

Therefore:

\[
\operatorname{rank}(\Pi_{\rm set}) : \operatorname{rank}\{\phi_C,\theta_g\}=3:2.
\]

The grouped weights are:

\[
w_S=\frac35,
\qquad
w_\Phi=\frac25.
\]

The participation concentration is:

\[
\chi=w_S^2+w_\Phi^2
=\left(\frac35\right)^2+
\left(\frac25\right)^2
=\frac{13}{25}.
\]

So the effective participation number is:

\[
N_{\rm eff}=\frac{1}{\chi}=\frac{25}{13}.
\]

The amplitude-level accessibility tax is:

\[
T_{\rm amp}=\frac12\ln N_{\rm eff}
=\frac12\ln\left(\frac{25}{13}\right).
\]

Then:

\[
L_{\rm eff}
=\left(\frac34\right)(4\pi)-\frac12\ln\left(\frac{25}{13}\right)
=3\pi-\frac12\ln\left(\frac{25}{13}\right)
=9.097814727066048\ldots
\]

---

## 11. Public-facing summary

The independence of \(\phi_C\) and \(\theta_g\) is not an extra assumption. It follows from two simple empirical facts expressed in SFT language:

1. Particles can have the same charge and different masses.
2. Particles can have the same mass and opposite charges.

The first fact requires mass cadence to vary independently of charge holonomy. The second fact requires charge holonomy to vary independently of mass cadence.

Therefore the phase sector has rank two.

Combined with the rank-three settlement projector, this gives the protected 3:2 split behind the sector accessibility tax:

\[
3:2
=
\operatorname{rank}(\Pi_{\rm set}) : \operatorname{rank}\{\phi_C,\theta_g\}.
\]

That is the public-facing closure of the 25/13 participation number:

\[
N_{\rm eff}=25/13.
\]

---

## 12. Remaining public debts

This derivation is enough to justify phase independence, but it does not yet complete the whole force-sector derivation. Remaining public debts:

1. derive \(\theta_g\) from local charge/framing holonomy without assuming electric charge as primitive,
2. derive \(\phi_C\) from native closure cadence without importing the Compton clock as a postulate,
3. derive charge quantization and fractional quark winding,
4. derive the fine-structure constant and its running,
5. show how the two-phase sector couples to the full force stack.

---

## 13. Verdict

\[
\boxed{
\text{R284O\_V0\_1\_PUBLIC\_PARTIAL\_PASS\_PHIC\_THETAG\_INDEPENDENCE\_DERIVED\_FROM\_FIXED\_CHARGE\_MASS\_VARIATION\_AND\_FIXED\_MASS\_CHARGE\_CONJUGATION\_RANK2\_PHASE\_SECTOR\_SUPPORTS\_3TO2\_TAX\_NEFF\_25\_13}
}
\]

Short verdict:

**PUBLIC_PARTIAL_PASS.**  
The public-facing independence proof works. It does not yet derive the microscopic origin of both phases, but it does show that the two-phase sector is required and that the R282O 3:2 tax is not arbitrary.

