# SFT R280O — η_I Boundary Projector Derivation, v0.1

**Status:** Internal operator-gate note.  
**Verdict:** `R280O_V0_1_PASS_INTERNAL_BOUNDARY_CAPACITY_ETA_I_DERIVED_AS_RANK_ONE_CONTINUATION_PROJECTOR_COMPLEMENT_TO_KAPPA_PDIR_IN_3PLUS1_WRITE_CAPACITY_PUBLIC_TRANSLATION_REQUIRES_BOUNDARY_LANE_NORMALIZATION_STATEMENT`

---

## 1. Purpose

R279O promoted the repeated `3/4` factors to a shared projector-class invariant:

```text
κ = P_dir = Tr(Π_available)/Tr(I_4) = 3/4
```

and identified the V13.2 expansion convention

```text
η_I = 1/4
```

as the likely complement:

```text
η_I = 1 - κ.
```

R280O asks whether the V13.2 quarter-boundary capacity convention can be derived from the same projector partition rather than left as an independent convention.

---

## 2. Inputs already earned

### 2.1 V13.2 expansion stack

V13.2 uses:

```text
Ndot_write = Σ_a χ_a E_a/h
I_write    = η_I A_boundary/A_write
H          = Ndot_write/I_write
```

with:

```text
η_I = 1/4
```

V13.2 described this as the quarter-boundary capacity convention: only one quarter of the raw boundary area counts as active writable capacity; the rest is structural overhead.

### 2.2 R278O projector result

R278O proved the local settlement participation factor:

```text
Π_set = I_4 - Π_T
P_dir = Tr(Π_set)/Tr(I_4) = 3/4
```

where:

```text
I_4  = full 3+1 write-address capacity identity
Π_T  = rank-one continuation/tangent projector
Π_set = rank-three settlement-available projector
```

The trace count is:

```text
Tr(I_4)   = 4
Tr(Π_T)   = 1
Tr(Π_set) = 3
```

Therefore:

```text
P_dir = 3/4.
```

---

## 3. R280O hypothesis

The expansion capacity factor `η_I` is not the same projector as local settlement participation. It is the complement.

Local settlement counts the rank-three projector:

```text
Π_set = I_4 - Π_T.
```

Global future-capacity accounting counts the rank-one continuation projector:

```text
Π_I = Π_T.
```

Therefore:

```text
η_I = Tr(Π_I)/Tr(I_4)
    = Tr(Π_T)/Tr(I_4)
    = 1/4.
```

This would mean:

```text
P_dir + η_I = 3/4 + 1/4 = 1.
```

Native sentence:

```text
The three lanes not used for continuation are available for settlement;
the one lane not available for settlement is the lane that supplies future continuation capacity.
```

---

## 4. Why expansion should count the complement, not the settlement projector

A local write has two simultaneous geometric roles:

```text
1. It deposits settlement into the directions not occupied by its own continuation.
2. It requires a fresh continuation address so the next write can occur.
```

The first role is local-settlement accounting.

The second role is global-capacity accounting.

Therefore the two projections are complementary:

```text
local settlement readout: Π_set = I_4 - Π_T, rank 3
boundary capacity readout: Π_I   = Π_T,       rank 1
```

This is the key distinction.

`P_dir = 3/4` answers:

```text
How much of the local 3+1 write capacity is available to receive settlement?
```

`η_I = 1/4` answers:

```text
How much of the raw boundary ledger is active fresh-address continuation capacity?
```

So V13.2's phrase “only one quarter of the boundary area is writable capacity; the rest is structural overhead” becomes operator-native:

```text
Only the rank-one continuation lane is globally writable as future capacity.
The rank-three complement is structural/settlement support of the already-written boundary geometry.
```

---

## 5. Formal derivation

Let the raw boundary capacity count before lane projection be:

```text
I_raw = A_boundary/A_write.
```

This counts the full unprojected local 3+1 write-address capacity associated with the boundary ledger.

Let active future-writable capacity be the projection of this raw ledger onto the continuation projector:

```text
I_write = [Tr(Π_T)/Tr(I_4)] I_raw.
```

Using the trace result:

```text
Tr(Π_T) = 1
Tr(I_4) = 4
```

we get:

```text
I_write = (1/4) A_boundary/A_write.
```

Therefore:

```text
η_I = 1/4.
```

This derives the V13.2 quarter-boundary factor from the same projector partition that produced `P_dir = 3/4`.

---

## 6. Consistency with the V13.2 equation

V13.2 writes:

```text
I_write = η_I A_boundary/A_write.
```

R280O now identifies:

```text
η_I = Tr(Π_continuation)/Tr(I_4) = 1/4.
```

Therefore:

```text
I_write = [Tr(Π_T)/Tr(I_4)] A_boundary/A_write.
```

The expansion rate remains:

```text
H = Ndot_write/I_write.
```

But the interpretation changes from convention to derived projector capacity:

```text
H = write demand / rank-one continuation capacity.
```

Native sentence:

```text
Expansion is the fractional turnover of the continuation-address lane of the boundary ledger.
```

---

## 7. Relation to κ and P_dir

The full projector partition is:

```text
I_4 = Π_T + Π_set
```

with:

```text
Tr(Π_T)   = 1
Tr(Π_set) = 3
```

Therefore:

```text
η_I  = Tr(Π_T)/Tr(I_4)   = 1/4
P_dir = Tr(Π_set)/Tr(I_4) = 3/4
```

So:

```text
η_I = 1 - P_dir
η_I = 1 - κ
```

if the V12.7/SPARC κ audit is accepted as the same projector-class invariant.

This gives the fourfold operator partition:

| Readout | Projector | Rank | Fraction |
|---|---:|---:|---:|
| Continuation / fresh boundary capacity | `Π_T` | 1 | `1/4` |
| Settlement / transverse support | `I_4 - Π_T` | 3 | `3/4` |
| Full write-address capacity | `I_4` | 4 | `1` |

---

## 8. Compatibility with R277O/R278O mass coefficient

R278O gave:

```text
G_closure = ∫_0^{4π} P_dir dφ
          = (3/4)(4π)
          = 3π.
```

R280O gives the complement:

```text
η_I = 1/4.
```

So the same 3+1 projector partition now controls:

```text
mass compounding:       rank-three settlement projector
cosmic boundary growth: rank-one continuation projector
```

This is the cleanest version of the one-write / multiple-readout rule:

```text
The write deposits settlement through the rank-three projector
and demands future capacity through the rank-one projector.
```

---

## 9. What this does and does not prove

### PASS

R280O derives:

```text
η_I = 1/4
```

from:

```text
1. full 3+1 write-address capacity,
2. rank-one continuation/tangent projector,
3. boundary capacity as future-continuation capacity,
4. no-overwrite requiring each next write to land on a fresh continuation address.
```

So the V13.2 quarter-boundary convention is no longer an isolated convention inside the internal operator stack.

### Claim boundary

This is an **internal/native derivation**. Public-facing translation still needs one sentence made explicit:

```text
A_boundary/A_write is the raw unprojected boundary ledger; active future-writable capacity is its rank-one continuation projection.
```

Without that sentence, an outside reader could object that a 2D boundary area is being divided by a 4D trace ratio without enough explanation.

### Not proven here

R280O does not prove:

```text
1. the full microscopic K_set kernel,
2. the exact relaxation term Φ_relax,
3. the SPARC κ identity beyond the projector-class audit,
4. the final public GR translation.
```

It only proves that `η_I = 1/4` is the projector complement of `P_dir = κ = 3/4`, given the native boundary-lane definition.

---

## 10. Revised V13.2 wording patch

Old V13.2 wording:

```text
η_I = 1/4 is the quarter-boundary capacity convention — only one quarter of the boundary area is writable capacity. The rest is structural overhead.
```

R280O patched wording:

```text
η_I = 1/4 is the rank-one continuation projection of the raw 3+1 boundary ledger. Only the continuation lane of the boundary address space is active fresh-write capacity; the three-lane complement is structural/settlement support. Thus I_write = [Tr(Π_T)/Tr(I_4)] A_boundary/A_write = (1/4)A_boundary/A_write.
```

---

## 11. Updated operator compression

The core projector partition is now:

```text
I_4 = Π_continuation + Π_settlement
```

```text
Tr(Π_continuation)/Tr(I_4) = 1/4
Tr(Π_settlement)/Tr(I_4)   = 3/4
```

Readouts:

```text
Expansion reads Π_continuation.
Gravity/mass settlement reads Π_settlement.
The full write event contains both.
```

Native summary:

```text
The same write that cannot settle its own continuation lane must grow the boundary through that lane.
```

This is the key R280O sentence.

---

## 12. Verdict

```text
R280O_V0_1_PASS_INTERNAL_BOUNDARY_CAPACITY_ETA_I_DERIVED_AS_RANK_ONE_CONTINUATION_PROJECTOR_COMPLEMENT_TO_KAPPA_PDIR_IN_3PLUS1_WRITE_CAPACITY_PUBLIC_TRANSLATION_REQUIRES_BOUNDARY_LANE_NORMALIZATION_STATEMENT
```

Short verdict:

```text
PASS_INTERNAL.
```

The V13.2 quarter-boundary capacity factor can be derived as the complement of the R278O settlement projector:

```text
η_I = 1 - P_dir = 1 - 3/4 = 1/4.
```

The operator compression is now stronger:

```text
3/4 is the settlement fraction.
1/4 is the continuation/future-capacity fraction.
Both are one projector partition of 3+1 write geometry.
```
