# SFT V10.7 Repro Pack

This lightweight repro pack contains the numerical checks that support the branch-selection and count-constraint story in **V10.7**.

## Included scripts

### 1. `head_to_head_twofield_vs_singlefield.py`
Compares:
- the two-field bridge-attractor branch
- the single-field branch with `Phi = 2π χ`

This is the branch-selection test. It shows that the two-field freely kinetic branch can reproduce the bridge ratio but tends to dominate the background energy budget, while the single-field branch improves the background behavior.

### 2. `constrained_slaved_single_field_test.py`
Scans the single-field model as the kinetic coefficient `K` is lowered, and then evaluates the quasi-static/slaved branch.

This is the key stress test showing:
- the runaway problem is mostly free kinetic scalar energy
- the slaved/constrained single-field branch is the live branch
- dust collapses to the exact background branch
- radiation stays order-unity instead of blowing up

### 3. `count_constrained_single_field_test.py`
Adds the count multiplier `β` to the slaved single-field branch and checks whether the SFT value

`β = 1 / (4π²)`

supplies the correct normalization.

This is the minisuperspace check that dust is exact and radiation lands very close to the target with the count multiplier doing almost all of the remaining normalization work.

### 4. `asymptotic_radiation_check.py`
Evaluates the exact reduced radiation equation for the count-constrained slaved branch and shows that the earlier few-percent radiation mismatch is a finite-range averaging artifact.

This script shows that with `β = 1 / (4π²)`, the radiation branch is **asymptotically exact**.

## How to run

Each script is standalone:

```bash
python head_to_head_twofield_vs_singlefield.py
python constrained_slaved_single_field_test.py
python count_constrained_single_field_test.py
python asymptotic_radiation_check.py
```

## Minimal requirements

- Python 3.10+
- `numpy`
- `scipy`

## Notes

- These scripts use reduced units and are intended to verify **structure**, branch behavior, and asymptotic normalization, not final physical units.
- They are the minimal numerical support for **V10.7**, not a full V11-grade covariant derivation pack.
