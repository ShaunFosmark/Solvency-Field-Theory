import numpy as np
from scipy.integrate import solve_ivp

# ============================================================
# 6B HEAD-TO-HEAD TEST
#
# Compare:
#   A) Two-field bridge-attractor model (Phi, chi)
#   B) Single-field simplification (chi only, Phi = 2π chi)
#
# Goal:
#   See whether the bridge ratio emerges robustly
#   AND whether the scalar sector remains subdominant
#   in the background Friedmann budget.
# ============================================================

h = 1.0
target_ratio = 1.0 / (2.0 * np.pi)

Kphi = 1.0
Kchi = 1.0
Ksingle = 1.0

V0 = 0.05
mu = 1.0
eta = 1.0
rho0 = 1.0

w_values = [0.0, 1.0 / 3.0]


def rho_of_a(a, rho0, w):
    return rho0 * a ** (-3.0 * (1.0 + w))


def divJ(a, H, rho, w, h=1.0):
    return -3.0 * H * w * (1.0 + 3.0 * w) * rho / h


# ---------------- Two-field model ----------------
def V_two(chi, Phi, V0, mu):
    return V0 * np.exp(-chi) + 0.5 * mu**2 * (chi - Phi / (2.0 * np.pi)) ** 2


def dV_dchi_two(chi, Phi, V0, mu):
    return -V0 * np.exp(-chi) + mu**2 * (chi - Phi / (2.0 * np.pi))


def dV_dPhi_two(chi, Phi, mu):
    return -mu**2 * (chi - Phi / (2.0 * np.pi)) / (2.0 * np.pi)


def H_two(a, Phi_dot, chi_dot, chi, Phi, rho0, w, Kphi, Kchi, V0, mu):
    rho = rho_of_a(a, rho0, w)
    H2 = rho + 0.5 * Kphi * Phi_dot**2 + 0.5 * Kchi * chi_dot**2 + V_two(chi, Phi, V0, mu)
    return np.sqrt(max(H2, 1e-12))


def rhs_twofield(t, y, pars):
    a, Phi, Phi_dot, chi, chi_dot = y
    rho0, w, Kphi, Kchi, V0, mu, eta = pars

    rho = rho_of_a(a, rho0, w)
    H = H_two(a, Phi_dot, chi_dot, chi, Phi, rho0, w, Kphi, Kchi, V0, mu)

    a_dot = H * a
    Phi_ddot = -3.0 * H * Phi_dot - dV_dPhi_two(chi, Phi, mu) / Kphi
    chi_ddot = (eta * divJ(a, H, rho, w, h=h) - dV_dchi_two(chi, Phi, V0, mu) - 3.0 * H * Kchi * chi_dot) / Kchi

    return [a_dot, Phi_dot, Phi_ddot, chi_dot, chi_ddot]


def summarize_twofield(sol, pars):
    rho0, w, Kphi, Kchi, V0, mu, eta = pars
    a = sol.y[0]
    Phi = sol.y[1]
    Phi_dot = sol.y[2]
    chi = sol.y[3]
    chi_dot = sol.y[4]

    ratio = np.divide(
        chi_dot, Phi_dot,
        out=np.full_like(chi_dot, np.nan),
        where=np.abs(Phi_dot) > 1e-12
    )

    H = np.array([
        H_two(a[i], Phi_dot[i], chi_dot[i], chi[i], Phi[i], rho0, w, Kphi, Kchi, V0, mu)
        for i in range(len(a))
    ])
    rho = rho_of_a(a, rho0, w)
    scalar_energy = 0.5 * Kphi * Phi_dot**2 + 0.5 * Kchi * chi_dot**2 + V_two(chi, Phi, V0, mu)

    n = len(a)
    late = slice(int(0.8 * n), n)

    return {
        "ratio_mean": np.nanmean(ratio[late]),
        "ratio_std": np.nanstd(ratio[late]),
        "H2_over_rho": np.nanmean((H[late] ** 2) / rho[late]),
        "scalar_fraction": np.nanmean(scalar_energy[late] / H[late] ** 2),
        "a_final": a[-1],
        "Phi_final": Phi[-1],
        "Phi_dot_final": Phi_dot[-1],
        "chi_final": chi[-1],
        "chi_dot_final": chi_dot[-1],
        "ratio_final": ratio[-1],
    }


# ---------------- Single-field model ----------------
def V_single(chi, V0):
    return V0 * np.exp(-chi)


def dV_dchi_single(chi, V0):
    return -V0 * np.exp(-chi)


def H_single(a, chi_dot, chi, rho0, w, Ksingle, V0):
    rho = rho_of_a(a, rho0, w)
    H2 = rho + 0.5 * Ksingle * chi_dot**2 + V_single(chi, V0)
    return np.sqrt(max(H2, 1e-12))


def rhs_singlefield(t, y, pars):
    a, chi, chi_dot = y
    rho0, w, Ksingle, V0, eta = pars

    rho = rho_of_a(a, rho0, w)
    H = H_single(a, chi_dot, chi, rho0, w, Ksingle, V0)

    a_dot = H * a
    chi_ddot = (eta * divJ(a, H, rho, w, h=h) - dV_dchi_single(chi, V0) - 3.0 * H * Ksingle * chi_dot) / Ksingle

    return [a_dot, chi_dot, chi_ddot]


def summarize_singlefield(sol, pars):
    rho0, w, Ksingle, V0, eta = pars
    a = sol.y[0]
    chi = sol.y[1]
    chi_dot = sol.y[2]

    H = np.array([
        H_single(a[i], chi_dot[i], chi[i], rho0, w, Ksingle, V0)
        for i in range(len(a))
    ])
    rho = rho_of_a(a, rho0, w)
    scalar_energy = 0.5 * Ksingle * chi_dot**2 + V_single(chi, V0)

    Phi_dot = 2.0 * np.pi * chi_dot
    ratio = np.divide(
        chi_dot, Phi_dot,
        out=np.full_like(chi_dot, np.nan),
        where=np.abs(Phi_dot) > 1e-12
    )

    n = len(a)
    late = slice(int(0.8 * n), n)

    return {
        "ratio_mean": np.nanmean(ratio[late]),
        "ratio_std": np.nanstd(ratio[late]),
        "H2_over_rho": np.nanmean((H[late] ** 2) / rho[late]),
        "scalar_fraction": np.nanmean(scalar_energy[late] / H[late] ** 2),
        "a_final": a[-1],
        "chi_final": chi[-1],
        "chi_dot_final": chi_dot[-1],
        "ratio_final": ratio[-1],
    }


def main():
    t_span = (0.0, 20.0)
    t_eval = np.linspace(t_span[0], t_span[1], 2000)

    for w in w_values:
        print("=" * 90)
        print(f"HEAD-TO-HEAD TEST | w = {w}")
        print("=" * 90)

        y0_two = [1.0, 0.0, 0.2, 0.0, 0.01]
        pars_two = (rho0, w, Kphi, Kchi, V0, mu, eta)

        sol_two = solve_ivp(
            lambda t, y: rhs_twofield(t, y, pars_two),
            t_span, y0_two, t_eval=t_eval, rtol=1e-8, atol=1e-10
        )
        summ_two = summarize_twofield(sol_two, pars_two)

        print("\n[TWO-FIELD MODEL]")
        print(f"target chi_dot/Phi_dot = 1/(2π) = {target_ratio:.6f}")
        print(f"late mean ratio        = {summ_two['ratio_mean']:.6f}")
        print(f"late std ratio         = {summ_two['ratio_std']:.6f}")
        print(f"late mean H^2/rho      = {summ_two['H2_over_rho']:.6f}")
        print(f"late scalar fraction   = {summ_two['scalar_fraction']:.6f}")
        print(f"final ratio            = {summ_two['ratio_final']:.6f}")
        print(f"a_final                = {summ_two['a_final']:.6f}")
        print(f"Phi_dot_final          = {summ_two['Phi_dot_final']:.6f}")
        print(f"chi_dot_final          = {summ_two['chi_dot_final']:.6f}")

        y0_single = [1.0, 0.0, 0.01]
        pars_single = (rho0, w, Ksingle, V0, eta)

        sol_single = solve_ivp(
            lambda t, y: rhs_singlefield(t, y, pars_single),
            t_span, y0_single, t_eval=t_eval, rtol=1e-8, atol=1e-10
        )
        summ_single = summarize_singlefield(sol_single, pars_single)

        print("\n[SINGLE-FIELD MODEL]")
        print(f"implied chi_dot/Phi_dot = 1/(2π) by construction = {target_ratio:.6f}")
        print(f"late mean ratio         = {summ_single['ratio_mean']:.6f}")
        print(f"late std ratio          = {summ_single['ratio_std']:.6f}")
        print(f"late mean H^2/rho       = {summ_single['H2_over_rho']:.6f}")
        print(f"late scalar fraction    = {summ_single['scalar_fraction']:.6f}")
        print(f"final ratio             = {summ_single['ratio_final']:.6f}")
        print(f"a_final                 = {summ_single['a_final']:.6f}")
        print(f"chi_dot_final           = {summ_single['chi_dot_final']:.6f}")

        print("\n[COMPARISON]")
        print(f"ratio error (two-field)   = {abs(summ_two['ratio_mean'] - target_ratio):.6f}")
        print(f"ratio error (single-field)= {abs(summ_single['ratio_mean'] - target_ratio):.6f}")
        print(f"H^2/rho improvement factor (two/single) = {summ_two['H2_over_rho'] / summ_single['H2_over_rho']:.6f}")
        print(f"scalar fraction improvement (two/single)= {summ_two['scalar_fraction'] / summ_single['scalar_fraction']:.6f}")
        print()

    print("=" * 90)
    print("LIGHT ETA SCAN (radiation only)")
    print("=" * 90)

    for eta_test in [0.1, 0.3, 1.0, 3.0]:
        w = 1.0 / 3.0

        pars_two = (rho0, w, Kphi, Kchi, V0, mu, eta_test)
        sol_two = solve_ivp(
            lambda t, y: rhs_twofield(t, y, pars_two),
            t_span, [1.0, 0.0, 0.2, 0.0, 0.01], t_eval=t_eval, rtol=1e-7, atol=1e-9
        )
        summ_two = summarize_twofield(sol_two, pars_two)

        pars_single = (rho0, w, Ksingle, V0, eta_test)
        sol_single = solve_ivp(
            lambda t, y: rhs_singlefield(t, y, pars_single),
            t_span, [1.0, 0.0, 0.01], t_eval=t_eval, rtol=1e-7, atol=1e-9
        )
        summ_single = summarize_singlefield(sol_single, pars_single)

        print(
            f"eta={eta_test:>4} | "
            f"two: ratio={summ_two['ratio_mean']:+.4f}, H2/rho={summ_two['H2_over_rho']:.3e}, sf={summ_two['scalar_fraction']:.3e} || "
            f"single: ratio={summ_single['ratio_mean']:+.4f}, H2/rho={summ_single['H2_over_rho']:.3e}, sf={summ_single['scalar_fraction']:.3e}"
        )


if __name__ == "__main__":
    main()
