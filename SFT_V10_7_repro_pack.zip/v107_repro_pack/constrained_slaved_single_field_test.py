import numpy as np
from scipy.integrate import solve_ivp

# ============================================================
# 6B CONSTRAINED / SLAVED SINGLE-FIELD TEST
# ============================================================

target_ratio = 1.0 / (2.0 * np.pi)
h = 1.0

V0 = 0.05
eta = 1.0
rho0 = 1.0
w_values = [0.0, 1.0 / 3.0]
K_values = [1.0, 0.3, 0.1, 0.03, 0.01, 1e-3, 1e-4]


def rho_of_a(a, rho0, w):
    return rho0 * a ** (-3.0 * (1.0 + w))


def divJ(a, H, rho, w, h=1.0):
    return -3.0 * H * w * (1.0 + 3.0 * w) * rho / h


def V_single(chi, V0):
    return V0 * np.exp(-chi)


def dV_dchi_single(chi, V0):
    return -V0 * np.exp(-chi)


def H_single(a, chi_dot, chi, rho0, w, K, V0):
    rho = rho_of_a(a, rho0, w)
    H2 = rho + 0.5 * K * chi_dot**2 + V_single(chi, V0)
    return np.sqrt(max(H2, 1e-12))


def rhs_singlefield(t, y, pars):
    a, chi, chi_dot = y
    rho0, w, K, V0, eta = pars

    rho = rho_of_a(a, rho0, w)
    H = H_single(a, chi_dot, chi, rho0, w, K, V0)

    a_dot = H * a
    chi_ddot = (eta * divJ(a, H, rho, w, h=h) - dV_dchi_single(chi, V0) - 3.0 * H * K * chi_dot) / K

    return [a_dot, chi_dot, chi_ddot]


def summarize_singlefield(sol, pars):
    rho0, w, K, V0, eta = pars
    a = sol.y[0]
    chi = sol.y[1]
    chi_dot = sol.y[2]

    H = np.array([
        H_single(a[i], chi_dot[i], chi[i], rho0, w, K, V0)
        for i in range(len(a))
    ])
    rho = rho_of_a(a, rho0, w)
    scalar_energy = 0.5 * K * chi_dot**2 + V_single(chi, V0)

    Phi_dot = 2.0 * np.pi * chi_dot
    ratio = np.divide(
        chi_dot, Phi_dot,
        out=np.full_like(chi_dot, np.nan),
        where=np.abs(Phi_dot) > 1e-14
    )

    n = len(a)
    late = slice(int(0.8 * n), n)

    return {
        "ratio_mean": np.nanmean(ratio[late]),
        "ratio_std": np.nanstd(ratio[late]),
        "H2_over_rho": np.nanmean((H[late] ** 2) / rho[late]),
        "scalar_fraction": np.nanmean(scalar_energy[late] / H[late] ** 2),
        "chi_final": chi[-1],
        "chi_dot_final": chi_dot[-1],
        "a_final": a[-1],
    }


def quasistatic_branch(a_arr, rho0, w, V0, eta, h=1.0):
    rho_arr = rho_of_a(a_arr, rho0, w)
    A = 3.0 * eta * w * (1.0 + 3.0 * w) / h

    H_arr = np.zeros_like(a_arr)
    V_arr = np.zeros_like(a_arr)
    chi_arr = np.zeros_like(a_arr)

    for i, rho in enumerate(rho_arr):
        if abs(A) < 1e-14:
            H = np.sqrt(rho)
            Veff = 0.0
            chi = np.inf
        else:
            H = 0.5 * (A * rho + np.sqrt(A * A * rho * rho + 4.0 * rho))
            Veff = A * H * rho
            chi = -np.log(max(Veff / V0, 1e-300))

        H_arr[i] = H
        V_arr[i] = Veff
        chi_arr[i] = chi

    H2_over_rho = np.nanmean((H_arr ** 2) / rho_arr)
    scalar_fraction = np.nanmean(V_arr / (H_arr ** 2))

    return {
        "A": A,
        "H2_over_rho": H2_over_rho,
        "scalar_fraction": scalar_fraction,
        "chi_final": chi_arr[-1],
        "Veff_final": V_arr[-1],
        "H_final": H_arr[-1],
    }


def main():
    t_span = (0.0, 20.0)
    t_eval = np.linspace(t_span[0], t_span[1], 2000)

    for w in w_values:
        print("=" * 94)
        print(f"CONSTRAINED / SLAVED SINGLE-FIELD TEST | w = {w}")
        print("=" * 94)
        print(f"target chi_dot/Phi_dot = 1/(2π) = {target_ratio:.6f}")
        print()

        print("[FREE SINGLE-FIELD K SCAN]")
        print(f"{'K':>10} {'ratio':>12} {'ratio_std':>12} {'H^2/rho':>14} {'scalar_frac':>14}")
        for K in K_values:
            pars = (rho0, w, K, V0, eta)
            y0 = [1.0, 0.0, 0.01]

            sol = solve_ivp(
                lambda t, y: rhs_singlefield(t, y, pars),
                t_span, y0, t_eval=t_eval, rtol=1e-8, atol=1e-10
            )

            summ = summarize_singlefield(sol, pars)
            print(
                f"{K:10.4e} "
                f"{summ['ratio_mean']:12.6f} "
                f"{summ['ratio_std']:12.6f} "
                f"{summ['H2_over_rho']:14.6e} "
                f"{summ['scalar_fraction']:14.6e}"
            )

        print()
        print("[QUASI-STATIC / SLAVED BRANCH]")
        a_probe = np.geomspace(1.0, 100.0, 500)
        qs = quasistatic_branch(a_probe, rho0, w, V0, eta, h=h)

        print(f"A = 3 η w (1+3w) / h = {qs['A']:.6f}")
        print(f"mean H^2/rho        = {qs['H2_over_rho']:.6e}")
        print(f"mean scalar fraction= {qs['scalar_fraction']:.6e}")
        print(f"final chi           = {qs['chi_final']}")
        print(f"final Veff          = {qs['Veff_final']:.6e}")
        print(f"final H             = {qs['H_final']:.6e}")
        print()

        if abs(w) < 1e-14:
            print("Dust note: quasi-static branch gives A = 0, so source driving vanishes.")
            print("This means the slaved branch collapses to H^2 = rho with no extra potential load.")
            print()

    print("=" * 94)
    print("INTERPRETATION GUIDE")
    print("=" * 94)
    print("1) If lowering K dramatically reduces H^2/rho and scalar_frac, then the")
    print("   runaway problem was mostly free kinetic energy, not source structure.")
    print("2) If the quasi-static branch gives H^2/rho ~ O(1), that strongly suggests")
    print("   χ should be constrained/slaved rather than freely propagating.")
    print("3) If even the quasi-static branch gives huge H^2/rho, then the missing")
    print("   object is not just slaving — it is the explicit count/constraint sector.")
    print("4) The ratio column in the free scan should remain exactly 1/(2π) here,")
    print("   because the single-field ansatz builds Phi = 2πχ by construction.")


if __name__ == "__main__":
    main()
