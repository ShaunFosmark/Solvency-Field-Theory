import numpy as np

# ============================================================
# 6B ASYMPTOTIC RADIATION CHECK
# ============================================================

beta = 1.0 / (4.0 * np.pi**2)
A = 2.0


def x_exact(rho, beta=beta, A=A):
    return 0.25 * (beta * A * np.sqrt(rho) + np.sqrt(beta**2 * A**2 * rho + 4.0 * beta))**2


def x_asymptotic(rho, beta=beta, A=A):
    return beta + A * beta**1.5 * np.sqrt(rho)


def rho_of_a(a):
    return a ** (-4.0)


def average_over_range(a_min, a_max, n=100000):
    a = np.geomspace(a_min, a_max, n)
    rho = rho_of_a(a)
    x = x_exact(rho)
    return {
        "a_min": a_min,
        "a_max": a_max,
        "mean_x": np.mean(x),
        "mean_dev": np.mean(x - beta),
        "final_x": x[-1],
        "final_dev": x[-1] - beta,
    }


def main():
    print("=" * 88)
    print("6B ASYMPTOTIC RADIATION CHECK")
    print("=" * 88)
    print(f"beta_target = 1/(4π²) = {beta:.10f}")
    print(f"A = {A:.6f}")
    print()

    rho_vals = [1.0, 1e-2, 1e-4, 1e-6, 1e-8, 1e-12]

    print("[POINTWISE VALUES]")
    print(f"{'rho':>12} {'x_exact=H^2/rho':>20} {'x-beta':>16} {'x_asymptotic':>20}")
    for rho in rho_vals:
        xe = x_exact(rho)
        xa = x_asymptotic(rho)
        print(f"{rho:12.1e} {xe:20.10f} {xe-beta:16.10e} {xa:20.10f}")
    print()

    ranges = [
        (1.0, 1e1),
        (1.0, 1e2),
        (1.0, 1e3),
        (1.0, 1e4),
        (1.0, 1e6),
        (10.0, 1e2),
        (10.0, 1e3),
        (10.0, 1e4),
        (100.0, 1e4),
    ]

    print("[AVERAGES OVER SCALE-FACTOR RANGES]")
    print(f"{'range':>18} {'mean(H^2/rho)':>18} {'mean_dev':>16} {'final_dev':>16}")
    for a_min, a_max in ranges:
        out = average_over_range(a_min, a_max)
        label = f"[{a_min:.0f},{a_max:.0e}]"
        print(f"{label:>18} {out['mean_x']:18.10f} {out['mean_dev']:16.10e} {out['final_dev']:16.10e}")
    print()

    out_100 = average_over_range(1.0, 100.0)
    print("[CHECK AGAINST PREVIOUS RESULT]")
    print(f"mean(H^2/rho) on [1,100] = {out_100['mean_x']:.10f}")
    print(f"target beta              = {beta:.10f}")
    print(f"fractional mismatch      = {(out_100['mean_x']/beta - 1.0):.6%}")
    print()

    print("INTERPRETATION")
    print("1) If x_exact -> beta as rho -> 0, the slaved branch asymptotically lands on the SFT target.")
    print("2) If the mean over [1,100] is above beta but ranges like [10,10^4] or [100,10^4] converge toward beta,")
    print("   then the earlier few-percent mismatch was just finite-range averaging.")
    print("3) If even late-time ranges do not converge toward beta, then some normalization is still missing.")


if __name__ == "__main__":
    main()
