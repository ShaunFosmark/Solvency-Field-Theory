import numpy as np

# ============================================================
# 6B COUNT-CONSTRAINED SINGLE-FIELD TEST
# ============================================================

h = 1.0
eta = 1.0
rho0 = 1.0
beta_target = 1.0 / (4.0 * np.pi**2)


def rho_of_a(a, rho0, w):
    return rho0 * a ** (-3.0 * (1.0 + w))


def A_coeff(eta, w, h=1.0):
    return 3.0 * eta * w * (1.0 + 3.0 * w) / h


def branch_solution(a_arr, rho0, w, eta, beta):
    rho_arr = rho_of_a(a_arr, rho0, w)
    A = A_coeff(eta, w, h=h)

    H_arr = np.zeros_like(a_arr)
    Veff_arr = np.zeros_like(a_arr)

    for i, rho in enumerate(rho_arr):
        H = 0.5 * (beta * A * rho + np.sqrt((beta * A * rho) ** 2 + 4.0 * beta * rho))
        Veff = A * H * rho
        H_arr[i] = H
        Veff_arr[i] = Veff

    H2_over_rho = np.mean((H_arr ** 2) / rho_arr)
    scalar_fraction = np.mean(Veff_arr / (H_arr ** 2))

    return {
        "A": A,
        "H2_over_rho": H2_over_rho,
        "scalar_fraction": scalar_fraction,
        "H_final": H_arr[-1],
        "Veff_final": Veff_arr[-1],
    }


def find_beta_required(a_arr, rho0, w, eta, target, lo=1e-6, hi=1.0, max_iter=100):
    def f(beta):
        out = branch_solution(a_arr, rho0, w, eta, beta)
        return out["H2_over_rho"] - target

    flo = f(lo)
    fhi = f(hi)

    if flo * fhi > 0:
        return None

    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        fmid = f(mid)
        if flo * fmid <= 0:
            hi = mid
            fhi = fmid
        else:
            lo = mid
            flo = fmid

    return 0.5 * (lo + hi)


def main():
    print("=" * 88)
    print("6B COUNT-CONSTRAINED SINGLE-FIELD TEST")
    print("=" * 88)
    print(f"SFT target beta = 1/(4π²) = {beta_target:.8f}")
    print()

    a_probe = np.geomspace(1.0, 100.0, 1000)

    for w in [0.0, 1.0 / 3.0]:
        print("-" * 88)
        print(f"Equation of state w = {w}")
        print("-" * 88)

        A = A_coeff(eta, w, h=h)
        print(f"A = 3 η w (1+3w) / h = {A:.8f}")
        print()

        out_gr = branch_solution(a_probe, rho0, w, eta, beta=1.0)
        out_sft = branch_solution(a_probe, rho0, w, eta, beta=beta_target)

        print("[Baseline unconstrained count  β = 1]")
        print(f"mean H^2/rho       = {out_gr['H2_over_rho']:.8f}")
        print(f"mean scalar frac   = {out_gr['scalar_fraction']:.8f}")
        print()

        print("[Fixed SFT count  β = 1/(4π²)]")
        print(f"mean H^2/rho       = {out_sft['H2_over_rho']:.8f}")
        print(f"mean scalar frac   = {out_sft['scalar_fraction']:.8f}")
        print(f"deviation from target = {out_sft['H2_over_rho'] - beta_target:+.8e}")
        print()

        beta_req = find_beta_required(a_probe, rho0, w, eta, beta_target)
        if beta_req is None:
            print("[Required beta]")
            print("Could not bracket a solution in [1e-6, 1.0]")
            print()
        else:
            out_req = branch_solution(a_probe, rho0, w, eta, beta=beta_req)
            print("[Required beta to hit target exactly]")
            print(f"beta_required      = {beta_req:.8f}")
            print(f"mean H^2/rho       = {out_req['H2_over_rho']:.8f}")
            print(f"mean scalar frac   = {out_req['scalar_fraction']:.8f}")
            print(f"beta_required / beta_target = {beta_req / beta_target:.8f}")
            print()

    print("=" * 88)
    print("RADIATION SCAN AROUND THE SFT TARGET")
    print("=" * 88)

    w = 1.0 / 3.0
    scan_factors = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]

    print(f"{'factor':>10} {'beta':>14} {'mean H^2/rho':>16} {'scalar frac':>14}")
    for f in scan_factors:
        beta = f * beta_target
        out = branch_solution(a_probe, rho0, w, eta, beta)
        print(
            f"{f:10.3f} {beta:14.8f} {out['H2_over_rho']:16.8f} {out['scalar_fraction']:14.8f}"
        )

    print()
    print("INTERPRETATION GUIDE")
    print("1) If beta = 1/(4π²) already brings mean H²/rho close to the target,")
    print("   then the missing normalization really is just the count multiplier.")
    print("2) If beta_required is simple and close to 1/(4π²), the count sector is")
    print("   probably doing almost all of the remaining work.")
    print("3) If beta_required is far from 1/(4π²), the count sector alone is not enough,")
    print("   and some of the normalization must still sit in the source/potential sector.")


if __name__ == "__main__":
    main()
