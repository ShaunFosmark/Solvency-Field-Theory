---
title: "Solvency Field Theory V13.1-V3"
subtitle: "From Locally Real Writes to the Selected Einstein-Form Gravity Branch"
author: "Shaun Fosmark"
date: "July 2026"
lang: en-US
---

> **CURRENT STATUS**  
> P1, P2, and P3 are discharged for the selected regular local gravity branch. SFT derives the coupling relation $G=a_\phi c^3/\hbar$ but not the absolute numerical write area. Numerical $G$ is open in the blind branch and calibrated from experiment only in the correspondence branch.

# 1. What this paper claims

Starting from the frozen locally real particle and irreversible-write ontology, V13.1-V3 constructs a minimal symmetric settlement carrier, a boundary-complete conserved write-momentum current, and a natural ordered update law. It derives a smooth capacity-normalized continuum representation, selects the regular local metric state, and closes the selected field equation

$$\boxed{G_{\mu\nu}[g(\Sigma)]=\frac{8\pi G_{\mathrm{eff}}}{c^4}\mathcal W_{\mu\nu}.}$$

The original equation was frozen before the hostile gravity program and was not retuned. The later microscopic audit discharged the three premises originally attached to that freeze for the selected branch.

This is not a claim that every exact write history is smooth, every possible gravity theory is excluded, or numerical $G$ is first-principles derived.

# 2. Native chain

1. Real support spends one invariant causal budget $c$.
2. Massive particles are persistent closed support with definite local orientation and cadence.
3. Completed writes are irreversible and permanently ordered.
4. The frozen scalar, mixed, trace, and STF gravity sectors uniquely assemble into a symmetric rank-two carrier under local frame changes.
5. Four-momentum transport through oriented support gives a rank-two source current.
6. Completed vertex momentum balance cancels internal endpoint defects in the worldline/edge-supported current.
7. Exact updates are natural on physical relabeling-equivalence classes.
8. Legal histories compose as exact ordered products with no external history tape.
9. Capacity normalization makes one complete event an $O(1/I)$ continuum update.
10. The selected regular local state closes on constrained metric Cauchy data and current source/matter state.
11. The selected local nonlinear completion is Einstein-form.
12. Weak matching fixes $G=a_\phi c^3/\hbar$.

# 3. P1 - composition and continuum

Exact histories are finite ordered products. They are not assumed to be exponentials. In a macroscopic capacity-normalized sector,

$$Y=Z/I,\qquad Y^+-Y=\frac{z_e-i_eY}{I+i_e}=O(I^{-1}).$$

For bounded convergent event ensembles this gives

$$U=\mathcal P\exp\left(\int X\,ds\right),$$

without subdividing one physical event.

# 4. P2 - address naturality

A physical write is relational. Coordinates, event names, raw phase zeros, and port labels are not physical inputs. Exact admissibility and update commute with relabeling. Tensor-valued distributions provide the coordinate-free continuum bridge, and the selected local kernel inherits covariance by descent.

# 5. P3 - sufficient local state

The selected regular local gravity state is constrained/gauge-reduced $(h_{ij},K_{ij})$, current source projections, complete current matter/carrier state, and physical topology/boundary metadata. Independent torsion, higher-rate, memory, and BCH registers are not present in this branch.

The gravity response is modular:

$$\Delta\Sigma_e=\kappa_\Sigma G^{\mathrm{ret}}_{g,B}\star\Delta\mathcal W_e,$$

followed by the regular metric congruence update.

# 6. Source-current repair

An isolated point tensor $A^{\mu\nu}\delta_x$ is not generally divergence-free. The conserved source is the complete oriented worldline/edge current. Completed vertices cancel internal endpoint defects; boundary terms remain until the full physical current is included. This repair supersedes the earlier point-atom conservation sentence.

# 7. What survived the hostile stack

Without changing the field equation, the original V3 program obtained or conditionally recovered:

- Newtonian exterior and interior limits;
- full weak light bending and Shapiro delay;
- Schwarzschild and local Birkhoff behavior;
- one-metric lensing and dynamics;
- frame dragging and exact Kerr existence;
- two TT wave modes at $c$;
- leading quadrupole radiation and pulsar regressions;
- TOV stars, binding, stability, and tidal response for external EOS models;
- homogeneous collapse, trapped surfaces, and linear Schwarzschild ringdown;
- FLRW compatibility and the trace-capacity bridge.

The full PN hierarchy, strong-field uniqueness/stability, matter microphysics, horizon mechanics, and cosmological write dynamics remain open.

# 8. The root-scale result

The structural relation is

$$G_{\mathrm{eff}}=\frac{a_\phi c^3}{\hbar}.$$

But the present equations are invariant under a common rescaling of the root length. Compactness, mass ratios, closure laws, capacity ratios, and horizon/Compton comparisons do not fix that scale. The current relaxation and rigidity targets also fail to break the orbit.

Therefore SFT presently derives gravity up to one universal absolute write-area modulus.

# 9. Blind and correspondence branches

**Blind branch:** $a_\phi$ remains symbolic. Measured $G$, Planck units, measured masses, cosmological rates, and hidden absolute cutoffs are prohibited during a native scale search.

**Correspondence branch:** measured $G$ calibrates

$$a_\phi^{\mathrm{cal}}=\frac{\hbar G_{\mathrm{obs}}}{c^3}$$

once. Clock lag, lensing, frame dragging, waves, binaries, and horizon response must then use that same normalization without retuning.

# 10. Claim boundary

SFT may claim that the selected structural gravity branch and P1-P3 discharge are receipt-backed. It may claim the root relation for $G$. It may not claim numerical $G$, absolute particle masses, full strong-field completion, or cosmological acceleration microdynamics as derived.

> **Matter models may fail. Gravity does not move to save them.**
