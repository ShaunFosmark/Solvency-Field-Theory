---
title: "Solvency Field Theory V13.1-V3 Gravity Derivation Canon"
subtitle: "Receipt-Backed Source of Truth: Structural Gravity Closure, Premise Discharge, and Root-Normalization Firewall"
author: "Originator / lead author: Shaun Fosmark; derivation and audit canon: GPT-5.6 SOL"
date: "2026-07-22"
lang: en-US
---

> **DOCUMENT STATUS**  
> Source-of-truth derivation canon v1.0, revised before public shipment. This document replaces the earlier conditional-premise draft while preserving its construction receipts, hostile failures, and no-retuning record. P1, P2, and P3 are now discharged for the selected gravity branch through the post-G-COV microscopic audit program. The absolute root normalization remains open in the blind branch and calibrated from measured $G$ only in the separate correspondence branch.

> **MASTER VERDICT**  
> **PASS - SELECTED GRAVITY BRANCH STRUCTURALLY CLOSED; P1-P3 DISCHARGED; NUMERICAL $G$ NOT FIRST-PRINCIPLES DERIVED.**

$$G_{\mu\nu}[g(\Sigma)] = \frac{8\pi G_{\mathrm{eff}}}{c^4}\,\mathcal W_{\mu\nu}$$

> **Canon sentence:** *Matter models may fail. Gravity does not move to save them.*

# Contents

1. Executive source-of-truth statement
2. Document control and receipt convention
3. Part I - Frozen native starting point
4. Part II - Chain audit from particle to field equation
5. Part III - Original V3 construction receipts
6. Part IV - P1-P3 premise-discharge and source-repair program
7. Part V - Original hostile gauntlet receipts
8. Part VI - What the combined stack establishes
9. Part VII - Alternative-operator and hidden-register audit
10. Part VIII - Cosmology and trace-capacity bridge
11. Part IX - Root-scale identifiability and prediction firewall
12. Part X - Public claim registry
13. Part XI - Final open-debt ledger
14. Final verdict and appendices

# Executive source-of-truth statement

V13.1-V3 now contains two historically distinct layers that must be read together.

The **original construction layer** begins with the frozen locally real particle and irreversible-write ontology, constructs the minimal symmetric settlement carrier and conserved write-momentum source, selects the linear stock-flow operator, freezes the Einstein-form local equation under three explicit premises, and subjects that equation to the G-H1 through G-H10 hostile program without retuning.

The **premise-discharge layer** then attacks those three premises microscopically rather than leaving them as permanent assumptions. The result is:

- **P1:** exact atomic write histories form a natural ordered legal-history cocycle with no external memory register; capacity-normalized many-write evolution supplies the near-identity continuum limit and product-integral flow for the selected smooth gravity branch;
- **P2:** exact write admissibility and update rules descend to the quotient by physical relabeling, and the selected local gravity kernel inherits finite coordinate covariance by naturality and compression;
- **P3:** the regular minimal local gravity state closes on constrained $h_{ij},K_{ij}$ data, current source and matter/carrier state, plus physical topology and boundary metadata; the selected response kernel is fiber-constant and contains no independent torsion, higher-rate, BCH, or memory register;
- **source conservation repair:** gravity is sourced by a boundary-complete worldline/edge-supported momentum current. Completed vertices cancel internal distributional defects; an isolated point tensor times a delta function is not independently conserved and is superseded;
- **normalization:** the relation

$$G_{\mathrm{eff}}=\frac{a_\phi c^3}{\hbar}$$

is derived structurally, but the absolute universal write area $a_\phi$ is not selected by the current scale-free canon. The frozen equations possess a one-parameter root-scale orbit. The settlement-relaxation and rigidity targets do not break it.

The current theory therefore derives the **form, state content, covariance, continuum limit, source interface, and one-constant location of gravitational coupling** for the selected branch. It does not derive the measured numerical value of $G$ from first principles.

Two normalization branches are frozen:

1. **Blind derivation branch:** $a_\phi$ remains symbolic; all absolute empirical anchors are prohibited.
2. **Gravity correspondence branch:** measured $G$ calibrates $a_\phi=\hbar G_{\mathrm{obs}}/c^3$ exactly once; all gravity channels must then use the same normalization without retuning.

> **Canon sentence:** *Matter models may fail. Gravity does not move to save them.*

> **Normalization sentence:** *The structural location of $G$ is derived. Its numerical value is calibrated unless a future blind scale-generation theorem fixes the root area.*

## Exact program count

- **Frozen antecedent:** composite V13.0 particle program, V13.2 expansion doctrine, and V13.1-V2 gravity canon.
- **Original V3 construction:** seven artifacts - G-COV-1, G-COV-2A, G-COV-2B, G-COV-2C, G-COV-3, G-COV-4, and G-COV-5.
- **Original hostile program:** ten numbered gates G-H1 through G-H10 plus G-H9B.
- **Microscopic audit spine:** G-MICRO-0A/0B; G-P2A0/A1/A2/B1/B2; G-P1A1/A2/B1/B2/C1/D1; G-P3A1/A2/A3/B1/B2/B2R.
- **Root-scale audit:** G-ROOT-A1, G-ROOT-A2, and G-ROOT-B1.
- **Equation changes after original hostile freeze:** zero.
- **Truth-status changes after microscopic audit:** P1-P3 discharged for the selected branch; the point-source conservation claim repaired; numerical $G$ reclassified as an open modulus in the blind branch and one-anchor calibration in correspondence work.

## What the celebratory summary may now say - and what remains prohibited

**1. "The three gravity premises are still open."**  
Superseded. P1-P3 are discharged for the selected gravity branch within their explicit regularity, locality, source-completeness, and continuum contracts.

**2. "SFT derives numerical $G$."**  
Not earned. SFT derives $G=a_\phi c^3/\hbar$ and the one-dimensional root-scale orbit. No current native operator fixes $a_\phi$ absolutely.

**3. "One point event is independently a conserved stress tensor."**  
Rejected. Conservation belongs to the boundary-complete worldline/edge current and completed-vertex network, or to the difference of complete conserved source states.

**4. "The exact atomic write is an exponential."**  
Not claimed. Exact histories compose as ordered finite products. The path-ordered exponential is the regular many-write continuum representation.

**5. "Every exact ledger history is smooth."**  
Not claimed. Singular or nonconvergent histories remain in the exact ordered/distributional theory and lie outside the selected smooth field branch.

**6. "The rigidity operator fixes the absolute mass and gravity scale."**  
Not currently. It may fix zero modes, dimensionless eigenvalues, and ratios; a common absolute unit remains open.

**7. "The gravity program is complete."**  
Accept only as: the selected local structural gravity branch, premise-discharge program, source repair, and normalization audit are complete. Strong-field dynamics, cosmological microdynamics, exact nonlinear atomic response, and native absolute-scale generation remain open.

# Document control and receipt convention

Every construction and hostile release is referenced by an artifact name, a release ZIP SHA-256, and where available a canonical result SHA-256 embedded in the release. Full exact reports are copied into the accompanying receipt pack. The main text uses short receipt labels; Appendix A gives the complete immutable ledger.

The governing claim hierarchy is:

1. **Native/frozen:** already earned in the particle or antecedent program.
2. **Foundational commitment:** explicit ontology input, not a downstream theorem.
3. **Derived for the selected branch:** established through construction plus the P1-P3 discharge contracts.
4. **Regression earned:** survived a specified hostile test within its boundary.
5. **Calibrated:** fixed by the single declared absolute anchor in the correspondence branch.
6. **Open debt:** not earned and prohibited from public promotion.
7. **Superseded or failed:** preserved for provenance but forbidden as current canon.

# Part I - The frozen native starting point

## 1. The locally real particle doctrine

The gravity program accepts the V12.12 particle program as frozen antecedent. Real support carries one invariant causal speed budget $c$. A massive particle is treated as persistent closed support with a $4\pi$ spinor closure cadence; the Compton cadence is the local clock of that closed support. A completed physical write is permanent history. No-overwrite means the same completed event cannot be written again, even though a later event can share a spatial projection.

This canon does **not** rederive the full particle doctrine. It records the point at which gravity inherits it.

> **Receipt P-01:** `SFT_V12_12_Particle_Program_Main-3.pdf`  \
> SHA-256: `eafbeb04017e2d5bb87270479eacc169e8024f66ef61576ede57127d758e7ebb`

## 2. Two foundational gravity commitments

Two links are deeper than the G-COV mathematics and must not be mislabeled as downstream theorems.

**Universal footprint class.** Each completed irreversible write contributes one species-independent root footprint class $a_\phi$ or $A_{\mathrm{write}}$ to the gravity normalization. Universality is a foundational physical commitment; its absolute numerical area is not derived. G-ROOT-A1 shows that the current canon leaves it as one positive normalization modulus rather than selecting its value.

**Write-geometry identity.** The active write ledger and retained geometry are two readouts of one physical history. Energy gravitates because four-momentum-carrying writes contribute to a boundary-complete conserved source current and leave retained settlement geometry. This ontology bridge is not replaced by the continuum Green response; the response is the selected gravity realization of that bridge.

These commitments are not arbitrary rescue clauses; they predate the covariant construction. They are nevertheless commitments and must be named as such.

## 3. V13.2 one-write / three-readouts rule

V13.2 freezes the global master

$$H=\frac{\dot N_{\mathrm{write}}}{I_{\mathrm{write}}},$$

and states that local time production, local settlement/gravity, and global capacity growth are three readouts of one irreversible write rather than three additive physical costs. This later becomes the no-double-counting firewall in G-H9B. Matter and radiation scaling rules $a^{-3}$ and $a^{-4}$ are also frozen, while $A_{\mathrm{write}}$, horizon accessibility, and the microscopic capacity operator remain open.

> **Receipt P-02:** `SFT_V13_2_Expansion_Time_production-1.pdf`  \
> SHA-256: `666daa7e8533652cabecf73b17e5caf0a330019143fa482f22a18744ee8328de`

## 4. V13.1-V2 gravity antecedent

V2 enters V3 with a Newtonian scalar projection, reciprocal weak metric closure with $\gamma=1$, the structural root-area relation $G_{\mathrm{eff}}=a_\phi c^3/\hbar$, and a bounded exact Schwarzschild exterior in the static spherical areal-capacity sector. It also identifies the scalar, mixed, and trace-free response sectors that the covariant carrier must contain.

V2 does not yet provide the covariant source, finite metric constitutive map, nonlinear field equation, full gravitational-wave theory, compact-body theorem, Kerr, or cosmological handoff. Those become original V3 construction gates. The later P1-P3 program then supplies the missing microscopic composition, naturality, state-closure, and source-current bridge rather than retroactively importing them into V2.

> **Receipt V2-PUB:** `SFT_V13_1_V2_Gravity-2.pdf`  \
> SHA-256: `9e0bd7af0138e15aed4d0e05936a7c909a9626ec69bfa81995a40ddce258fc25`  \
> Weak-field metric, G-root structure, bounded static spherical exterior, frontier map.

> **Receipt V2-CAN:** `SFT_V13_1_V2_Gravity_Canon_Derivation_Paper_v0_1-2.pdf`  \
> SHA-256: `347301ab25d103cc2d7c2d374fc34b75ff9f1b7c75b87d98fb00de63862b2420`  \
> Source-of-truth V2 derivation spine and claim boundaries.

> **Receipt V2-REP:** `SFT_V13_1_V2_GRAVITY_CANON_FULL_REPRO_PACK-2.zip`  \
> SHA-256: `fcc8842b890bbaccce8a0577d6963bb281e6614b2ec1327706f74cbb8a92c203`  \
> V2 scripts, tables, and audit artifacts.

# Part II - Chain audit from particle to field equation

## 5. Sixteen-link current grading

**Link 1 - One invariant causal speed budget $c$**  
Grade: **Frozen native axiom.**

**Link 2 - Persistent locally real closed support and $4\pi$ orientation**  
Grade: **Frozen particle result.**

**Link 3 - Irreversible no-overwrite event ledger**  
Grade: **Frozen native rule.**

**Link 4 - Universal write-footprint class**  
Grade: **Foundational commitment; absolute value open.**

**Link 5 - Settlement/history as geometric readout**  
Grade: **Foundational write-geometry identity.**

**Link 6 - Minimal symmetric rank-two settlement carrier $\Sigma_{\mu\nu}$**  
Grade: **Derived for the frozen response-sector and no-preferred-frame contract.** G-P2A0 confirms that the tensor was selected before the metric equation and is the unique minimal Lorentz representation containing the two scalars, mixed vector, and STF sector.

**Link 7 - Active write-momentum current $\mathcal W_{\mu\nu}$**  
Grade: **Native source construction, repaired distributionally.** The conserved source is a symmetric boundary-complete worldline/edge current, not an isolated point atom.

**Link 8 - Linear second-order divergence-compatible stock-flow operator**  
Grade: **Derived under the original linear address-relabelling and source contract.**

**Link 9 - Exact microscopic address naturality**  
Grade: **Derived for the frozen exact event/admissibility stack.** Physical states are relabeling-equivalence classes, and legal updates descend to that quotient.

**Link 10 - Continuum tensor/distribution naturality**  
Grade: **Derived structurally.** Tensor-valued distributions supply the exact continuum bridge without a fundamental smoothing window; smooth readouts require only natural regulator/transport choices.

**Link 11 - Exact ordered history composition**  
Grade: **Derived.** Legal histories form an associative category/evolution cocycle represented by exact ordered finite products with no external memory tape.

**Link 12 - Smooth many-write continuum flow**  
Grade: **Derived for the selected regular gravity continuum.** Capacity normalization makes one complete event an $O(I_{\mathrm{write}}^{-1})$ update on the retained continuum variable, yielding the product-integral limit without subdividing the event.

**Link 13 - Local sufficient gravity state**  
Grade: **Derived for the selected regular minimal branch.** The state is constrained/gauge-reduced $(h_{ij},K_{ij})$, current source projections, complete current matter/carrier state, and physical topology/boundary metadata, with no independent torsion, higher-rate, BCH, or memory register.

**Link 14 - Selected retarded settlement response and metric update**  
Grade: **Derived as a sufficient, natural selected kernel; not unique atomic dynamics.**

**Link 15 - Einstein-form local closure and unit nonlinear connection coefficient**  
Grade: **Derived for the selected zero-torsion, metric-compatible, regular local branch.** The BCH/connection program supplies the nonlinear $\mathcal A\wedge\mathcal A$ ancestry and fixes its relative coefficient to one.

**Link 16 - Absolute normalization**  
Grade: **Structural relation derived; numerical modulus open.**

$$G_{\mathrm{eff}}=\frac{a_\phi c^3}{\hbar},\qquad
\kappa_g=\frac{8\pi a_\phi}{\hbar c}.$$

G-ROOT-A1/A2 prove that the present scale-free canon does not select $a_\phi$. G-ROOT-B1 freezes blind and calibrated branches.

## 6. The current field equation term by term

The selected local equation is

$$\boxed{G_{\mu\nu}[g(\Sigma)] = \frac{8\pi G_{\mathrm{eff}}}{c^4}\mathcal W_{\mu\nu}.}$$

### $\mathcal W_{\mu\nu}$ - active conserved write-momentum current

The source is the symmetric continuum flux of four-momentum carried along oriented physical support. For an edge or worldline segment $\ell$,

$$\langle J_\ell^{\mu\nu},f_{\mu\nu}\rangle
=\int_\ell u_\ell^\mu p_\ell^\nu f_{\mu\nu}\,d\lambda.$$

Its distributional divergence produces endpoint and bulk-force terms. At a completed vertex, signed incoming and outgoing momentum balance cancels the internal vertex defect. Conservation therefore belongs to the complete current network or to the difference between two complete conserved source states. The earlier isolated point-atom conservation statement is superseded.

### $\Sigma_{\mu\nu}$ - retained settlement history

$\Sigma_{\mu\nu}$ is the minimal real symmetric carrier of the frozen scalar, mixed, trace, and STF response sectors. It is not a second independent metric state. Once the constitutive map is selected, propagating both $g$ and $\Sigma$ independently would double the geometric degrees of freedom.

### $g(\Sigma)$ - selected metric readout

For the selected smooth branch, one write contributes a retarded settlement increment,

$$\Delta\Sigma_e=\kappa_\Sigma G^{\mathrm{ret}}_{g,B}\star\Delta\mathcal W_e,$$

and the regular continuum flow acts by congruence,

$$S=g^{-1}\Delta\Sigma_e,\qquad E=e^S,\qquad g^+=E^TgE.$$

The exact atomic history remains an ordered finite product. The exponential is the identity-connected many-write continuum representation, not a claim that one indivisible event is uniquely exponential.

### $G_{\mu\nu}$ - selected local nonlinear response

Exact naturality, the regular metric-only state contract, source conservation, zero torsion, no extra propagating connection, and second-order closure select the Einstein-form response inside the frozen local branch. This does not exhaust singular, causal nonlocal, or unselected degenerate theories outside that branch.

### $8\pi G_{\mathrm{eff}}/c^4$ - weak-limit normalization and root modulus

Weak-field matching fixes

$$\kappa_g=\frac{8\pi G_{\mathrm{eff}}}{c^4}
=\frac{8\pi a_\phi}{\hbar c}.$$

The numerical value of $a_\phi$ is not supplied by $c$, $\hbar$, projector ratios, closure phases, mass ratios, compactness, or horizon/Compton equality. In the blind branch it remains symbolic. In the correspondence branch measured $G$ calibrates it once.

# Part III - Original V3 construction receipts

The V3 construction is seven release artifacts, not ten. The three G-COV-2 branches are separate because the source, geometry operator, and their convergence had to be tested independently.

## 7. GCOV1 - Minimal covariant settlement carrier

The frozen V2 sectors require one clock scalar, one mixed three-vector, one spatial trace scalar, and one five-component spatial STF shear. A symmetric rank-two carrier has exactly 1+3+1+5=10 components; scalar, vector, and antisymmetric two-form candidates fail sector completeness.

$$\Sigma_{\mu\nu}=\rho_\Sigma u_\mu u_\nu+p_\Sigma h_{\mu\nu}+2q_{(\mu}u_{\nu)}+\pi_{\mu\nu}.$$

**Boundary.** This selects a bookkeeping carrier, not a new propagating field, metric, curvature tensor, or field equation.

> **Receipt GCOV1:** `SFT_V13_1_V3_GCOV1_Minimal_Covariant_Settlement_Carrier_v0_1.zip`  
Status: `PASS_CONDITIONAL_MINIMAL_CARRIER_SELECTION`  
Result SHA-256: `not embedded; see release README/program ledger`  
ZIP SHA-256: `e1c769bb219e842b0df20d983acbf533e9ec597271b9c2ece56c2f3635d22678`

## 8. GCOV2A - Native write-momentum source and dual coupling

The active source is the covariant flux of four-momentum carried by real writes. Closed-ledger translation bookkeeping gives conservation; angular-momentum closure gives symmetry. The most general leading derivative-free scalar pairing has two terms, and frozen dust/radiation weights select the pure contraction.

$$\mathcal W^{\mu\nu}=dP^\nu/d\mathcal A_\mu,\qquad \nabla_\mu\mathcal W^{\mu\nu}=0,\qquad \mathcal L_{\mathrm{dual}}=\Sigma_{\mu\nu}\mathcal W^{\mu\nu}.$$

**Boundary.** The source matches the physical content of stress-energy because both encode energy density, momentum, pressure, and stress. The field equation and binding completion were still open.

> **Receipt GCOV2A:** `SFT_V13_1_V3_GCOV2A_Native_Write_Momentum_Source_and_Dual_Coupling_v0_1.zip`  
Status: `PASS_NATIVE_SOURCE_AND_UNIQUE_LEADING_DUAL_COUPLING`  
Result SHA-256: `8e8a47ce8170656be29c5257c2064811de9882bb8611dc8abac7a827e6dd16cc`  
ZIP SHA-256: `2ea1de1c23a0869ef76841f0fa244ee3dae27671a6e4e097970bc902389c5c6c`

## 9. GCOV2B - Write-geometry identity and linear stock-flow operator

The naive local identity dSigma/dtau=W was killed by static-age, null-support, and foliation tests. The surviving relation is causal and differential. A five-coefficient local linear second-order Lorentz operator is reduced by identical divergence freedom and linear write-address relabeling to one ray.

$$(a,b,c,d,e)\propto(1,-1,1,1,-1),\qquad \mathcal E^{(1)}_{\mu\nu}[\Sigma]=\kappa_\Sigma\mathcal W_{\mu\nu}.$$

**Boundary.** Linear relabeling is earned. Full finite nonlinear covariance is not; it becomes P2.

> **Receipt GCOV2B:** `SFT_V13_1_V3_GCOV2B_Write_Geometry_Identity_and_Linear_Stock_Flow_v0_1.zip`  
Status: `PASS_CONDITIONAL_LINEAR_STOCK_FLOW_OPERATOR`  
Result SHA-256: `3c36ef88eb00ecc9b733009715405445dc679c557891fde3b83b4009a37f20d7`  
ZIP SHA-256: `5983cf4b04ae12ffea9c11c195abdf14d4b028110edeed6252b87dcf53b1872c`

## 10. GCOV2C - Branch convergence: active flow versus retained history

The two G-COV-2 branches converge without identifying their tensors. W is the active current of the write ledger. Sigma is the retained geometric history. They are linked causally through the retarded inverse of the linear operator.

$$\mathcal E^{(1)}[\Sigma]=\kappa_\Sigma\mathcal W,\qquad \Sigma=\kappa_\Sigma(\mathcal E^{(1)}_{\mathrm{ret}})^{-1}\mathcal W.$$

**Boundary.** This earns the dual-aspect bookkeeping architecture, not a finite metric map or nonlinear equation.

> **Receipt GCOV2C:** `SFT_V13_1_V3_GCOV2C_Branch_Convergence_v0_1.zip`  
Status: `PASS_STRONG_CONVERGENCE_WITH_COMPLEMENTARY_ROLES`  
Result SHA-256: `f6a99f9ac8fa8e18e8adab85edc9662161f42bbadf5d65796546ad8fba8c6b94`  
ZIP SHA-256: `3f720fa5019b3c27df5669b36be1f579b3e1b441bee6396c31445d50dd9df971`

## 11. GCOV3 - Finite metric map and nonlinear closure entry

Settlement increments act as generators on the current metric. The exponential congruence preserves symmetry and Lorentz signature, reproduces delta g=2 delta Sigma, retains ordered-history information through path ordering/BCH structure, and yields the determinant trace identity. Under a metric-only, covariant, local curvature-linear second-order contract, the only conserved nonlinear tensor is the Einstein tensor plus a cosmological term; zero-write flatness sets the local term to zero.

$$g'=e^{S^T}ge^S,\qquad \sqrt{-g'}=e^{\operatorname{tr}S}\sqrt{-g},\qquad G_{\mu\nu}[g(\Sigma)]=\kappa_g\mathcal W_{\mu\nu}.$$

**Boundary.** The arbitrary ordered-write exponential law, full nonlinear covariance, and fundamental closure class were not microscopically proven.

> **Receipt GCOV3:** `SFT_V13_1_V3_GCOV3_Metric_Constitutive_Map_and_Nonlinear_Closure_Entry_v0_1.zip`  
Status: `PASS_CONDITIONAL_METRIC_MAP_AND_NONLINEAR_ENTRY`  
Result SHA-256: `fb8eab8eb515f4d4e2e6b522b53fa0f3dcb491a493e040ca936682df9fae601b`  
ZIP SHA-256: `ea00c92b4a689d5e0f7f4c316a6603cbb0caf7a59e3a3e062a8656b25297799d`

## 12. GCOV4 - Nonlinear self-coupling and binding ledger

Expanding the fixed nonlinear candidate around a background shows higher-order geometry acting as a background-split effective source. A free self-coupling multiplier leaves a residual unless it equals one. Static compact spheres satisfy TOV, and proper energy exceeds the exterior mass by negative binding energy with the correct weak limit.

$$\tau^g_{\mu\nu}=-(1/\kappa_g)\sum_{n\ge2}G^{(n)}_{\mu\nu},\qquad \lambda_{\mathrm{self}}=1,\qquad E_{\mathrm{bind}}\to-3M^2/(5R).$$

**Boundary.** The unit result is conditional reconstruction of the already selected candidate, not an independent derivation of the nonlinear equation.

> **Receipt GCOV4:** `SFT_V13_1_V3_GCOV4_Nonlinear_Self_Coupling_and_Total_Ledger_Conservation_v0_1.zip`  
Status: `PASS_CONDITIONAL_SELF_COUPLING_AND_BINDING_LEDGER`  
Result SHA-256: `0f800c301702f997d00be2614b89da4612d3627db49ef9abcba2448f3289ad6a`  
ZIP SHA-256: `fe09e07d3ae06d6e58c4392385d8dd552fc1d3a709daced881b1b353f6925974`

## 13. GCOV5 - Native assumption audit and conditional field-equation freeze

Sixteen load-bearing assumptions were audited. Thirteen were native, frozen, or mathematical consequences. Three remained explicit premises. Under those premises the equation was frozen before hostile testing, with no post-launch rescue allowed.

$$G_{\mu\nu}[g(\Sigma)]=\frac{8\pi G_{\mathrm{eff}}}{c^4}\mathcal W_{\mu\nu}=\frac{8\pi a_\phi}{\hbar c}\mathcal W_{\mu\nu}.$$

**Boundary.** The numerical root area a_phi and numerical G remain open. Full unconditional derivation was explicitly denied.

> **Receipt GCOV5:** `SFT_V13_1_V3_GCOV5_Native_Assumption_Audit_and_Conditional_Field_Equation_Freeze_v0_1.zip`  
Status: `PASS_CONDITIONAL_FIELD_EQUATION_FREEZE_WITH_THREE_EXPLICIT_PREMISES`  
Result SHA-256: `96d7ccf972a7fa1df73e4196d690ec9573a50395bd464ffebbe789fd588b642f`  
ZIP SHA-256: `5bf180385db4ec175f97718eb20e815b4c4e93b0c3575d3e949986e61f43ebbf`

# Part IV - P1-P3 premise-discharge and source-repair program

The original G-COV-5 freeze named P1, P2, and P3 honestly. That freeze remains part of the historical receipt chain. The later microscopic program did not erase it; it attacked each premise and replaced it with a theorem or bounded branch contract.

## G-MICRO-0A/0B - common root and state inventory

The audit showed that P1, P2, P3, and numerical $G$ all pointed toward the missing single-write update law. The smallest exact receipt-backed state candidate is

$$\mathscr S_n^{\mathrm{micro}}=(\mathcal L_n,\mathcal B_n,\mathcal C_n),$$

where $\mathcal L_n$ is the ordered permanent ledger, $\mathcal B_n$ the current writable boundary/support domain, and $\mathcal C_n$ the active carrier state. Apparent variables such as $D_{\mathrm{set}}$, $I_{\mathrm{write}}$, $\Lambda$, $P_{\mathrm{coh}}$, and $\Phi_{\mathrm{relax}}$ remain laws or readouts unless independent initial data are proven.

G-MICRO-0A also proved the dimensional no-go: $c$, $\hbar$, and dimensionless SFT constants cannot construct an area.

## P2 discharge - physical state quotient and naturality

### Native tensor necessity

G-P2A0 establishes that the frozen gravitational sectors transform together as the unique minimal real symmetric rank-two Lorentz representation under the one-carrier, no-preferred-frame contract. This is a native tensor-completeness result, not an import from the Einstein equation.

### Exact event naturality

G-P2A1/A2 formulate events and writable boundaries relationally. Attachment, causality, no-overwrite, closure, port completeness, momentum balance, Pauli exclusion, and one-event/one-count legality are invariant under physical relabeling. Raw phase windows, coordinate component tests, preferred slices, and private event names fail.

For every physical relabeling $f$,

$$f^+_*\mathfrak W_\epsilon(\mathscr S)
=\mathfrak W_{f_*\epsilon}(f_*\mathscr S).$$

### Continuum naturality

G-P2B1/B2 represent exact settlement and source as tensor-valued distributions. This requires no fundamental smoothing window or inter-event transport. Smooth finite-resolution readouts may use natural kernels and transport; covariance does not uniquely select a regulator. The physical state is the quotient $[\mathscr S]$ by relabeling, so an address-dependent update is not an alternative SFT law - it fails to define dynamics on physical state space.

**P2 status:** discharged structurally for the exact stack and locally for the selected factorizing gravity kernel.

## P1 discharge - ordered atomic histories and smooth continuum emergence

### Exact composition

G-P1A1 proves that legal write histories form an associative category and evolution cocycle. For a finite history,

$$U_n=F_{n-1}\cdots F_1F_0.$$

Order is physical on shared support, disjoint factors may commute, and no external history tape is allowed because the ordered ledger is part of the present exact state.

### BCH, holonomy, and nonlinear structure

G-P1A2/B1/B2 classify the regular generator as

$$X=\frac{\theta}{4}I+Q+A,$$

where the trace controls capacity/volume, $Q$ controls trace-free shape, and $A$ controls local frame transport. Commutators are trace-free and encode order-dependent shape/holonomy. When ordered transport is promoted to a natural connection, BCH supplies the $\mathcal A\wedge\mathcal A$ curvature term; local-frame covariance fixes its relative coefficient to one. Zero torsion and metric-only identification remain branch selections rather than universal theorems.

### Many-write continuum theorem

G-P1D1 supplies the final bridge. For an extensive retained quantity $Z$ and capacity $I$, define $Y=Z/I$. One complete write gives

$$Y^+-Y=\frac{z_e-i_eY}{I+i_e}=\frac{z_e-i_eY}{I}+O(I^{-2}).$$

Thus the event remains indivisible while its action on the capacity-normalized continuum state becomes $O(I^{-1})$. Under bounded marks, fiber-constant current-state dynamics, vanishing mesh, and convergent event ensembles, the exact ordered product tends to

$$U(s_f,s_i)=\mathcal P\exp\left(\int_{s_i}^{s_f}X(s)\,ds\right).$$

Singular or nonconvergent histories remain in the exact theory and are not claimed to possess this smooth limit.

**P1 status:** discharged for the selected smooth gravity continuum; a unique finite exponential law for one atomic write is neither required nor claimed.

## P3 discharge - state completeness, branch selection, and fiber constancy

### Sufficient-state criterion

G-P3A1 formalizes the exact test:

$$C(S_1)=C(S_2)\Longrightarrow C(F_e(S_1))=C(F_e(S_2)).$$

The spatial metric alone fails; current rate, current sources, matter/carrier state, field germ or slice data, topology, and physical boundary class are required.

### Hidden-register elimination

G-P3A2/A3 adjudicate the surviving forks. Within the current source-complete, regular, local, one-carrier contract:

- the selected connection is Levi-Civita;
- no independent propagating torsion register survives;
- dynamically distinct higher-order equations require extra state;
- fundamental continuum memory is either a current-state readout or an additional forbidden register;
- local holonomy is derived from current geometry; global holonomy belongs to topology/boundary metadata;
- lapse and shift are gauge/control variables, not physical gravitational modes.

### Selected local state

The selected continuum state is

$$Y_\Sigma=
\left[
 h_{ij},K_{ij},
 \mathcal W_{\perp\perp},
 \mathcal W_{\perp i},
 \mathcal W_{ij},
 \mathcal C_{\mathrm{matter,local}}
\right]_{\mathrm{constraints/gauge}},$$

plus global topology and physical boundary data.

### Selected kernel and exact fiber constancy

G-P3B2 constructs the selected modular response: the matter/source sector supplies a complete event descriptor and a conserved source-current increment; gravity applies the retarded response and metric update. Equal compressed state and event data produce equal compressed futures. Unknown universal normalization is a law constant, not hidden state.

### P3B2R distributional source repair

The first B2 formulation compressed a completed vertex into a point-supported symmetric tensor and claimed vertex momentum balance made that point atom divergence-free. G-P3B2R kills that statement. A point tensor times $\delta_x$ has a derivative-of-delta divergence in general.

The repaired source is an oriented worldline/edge current. Completed vertex momentum balance cancels the interior endpoint defect, while open-frontier terms remain until the boundary-complete current is included. The gravity interface therefore consumes a conserved complete source increment $\Delta\mathcal W_e$, not an isolated event point atom.

**P3 status:** discharged for the selected minimal gravity kernel after the source-current repair. The unique microscopic matter/source compounding law and unique exact nonlinear atomic gravity response remain open.

## Root normalization audit

G-ROOT-A1 proves a continuous scale orbit. Let $\ell_\phi=\sqrt{a_\phi}$. Under

$$\ell_\phi\to\lambda\ell_\phi,$$

areas and $G$ scale as $\lambda^2$, lengths and times as $\lambda$, and masses, energies, frequencies, and $H$ as $\lambda^{-1}$. Compactness, capacity ratios, mass ratios, closure laws, $Ht$, and horizon/Compton ratios remain unchanged.

G-ROOT-A2 shows that the current $\Phi_{\mathrm{relax}}$, $\mathcal H_{\mathrm{settle}}$, memory, rigidity-potential, and dimensional-transmutation targets do not independently break that orbit. They can determine relative spectra and zero/nonzero channels but not the common unit.

G-ROOT-B1 freezes two branches:

- **blind:** $a_\phi$ symbolic; no absolute empirical anchor;
- **correspondence:** measured $G$ calibrates $a_\phi=\hbar G_{\mathrm{obs}}/c^3$ once; all other absolute channels become holdouts if their dimensionless coefficients were frozen independently.

# Part V - Original hostile gauntlet receipts

The hostile program contains ten numbered gates plus H9B. A gate can be a partial pass even when a proposed submechanism fails. The governing question was not whether every ambition could be declared solved. It was whether the frozen equation survived without rescue while the claim boundary moved honestly.

## 14. GH1 - Birkhoff and constraint propagation

**Gate classification:** PASS.

**Earned:** Vacuum spherical equations force time-independent mass and remove the remaining lapse function by time relabeling. Linearized Hamiltonian and momentum constraints propagate on the null cone.

**Boundary/open debt:** Local spherical vacuum only; horizon chart/global topology and nonlinear constraint stability remain outside the gate.

> **Receipt GH1:** `SFT_V13_1_V3_GH1_Birkhoff_and_Constraint_Propagation_Hostile_Test_v0_1.zip`  
Status: `PASS_CONDITIONAL_BIRKHOFF_AND_CONSTRAINT_PROPAGATION`  
Result SHA-256: `b55607233889ef309b35840f27fd1681d39c8d8e8f74560745d68040c8626739`  
ZIP SHA-256: `978df1964b9e87655cd19b452b095c3118481343b56beba3f1eb258e406a2410`

## 15. GH2 - Compact-body sensitivity and strong-equivalence route

**Gate classification:** PARTIAL.

**Earned:** A spherical compact body has one exterior mass, equal active and asymptotic inertial monopole mass, geodesic leading coupling, and zero standard weak PPN Nordtvedt parameter. A 21-star EOS sweep retained one exterior charge.

**Boundary/open debt:** Full nonlinear two-body effacement, exact strong-field Nordtvedt zero, tides, radiation reaction, and black-hole sensitivities remain open.

> **Receipt GH2:** `SFT_V13_1_V3_GH2_Strong_Equivalence_and_Compact_Body_Sensitivity_Hostile_Test_v0_1.zip`  
Status: `PARTIAL_PASS_MONOPOLE_STRONG_EQUIVALENCE_AND_ZERO_NORDTVEDT`  
Result SHA-256: `e4db6523352333ffd567181cffec96dfc3b11f49dcd12a90dffdefbbddc0db02`  
ZIP SHA-256: `e063f77c31096ee9b300154c59f904ba9d55dea92b87122e7807bc2a5194e3fd`

## 16. GH3 - Lensing versus dynamics

**Gate classification:** PASS.

**Earned:** The same M controls slow-body dynamics, redshift, Shapiro delay, light deflection, photon sphere, ISCO, and exact null geodesics. Removing spatial response recreates the historical factor-of-two failure.

**Boundary/open debt:** Local spherical vacuum; rotating/cosmological/plasma lensing and astrophysical mass modeling remain outside.

> **Receipt GH3:** `SFT_V13_1_V3_GH3_Lensing_Versus_Dynamics_Hostile_Test_v0_1.zip`  
Status: `PASS_CONDITIONAL_LENSING_DYNAMICS_SINGLE_METRIC`  
Result SHA-256: `084a7c9671772cc17a6ebd10a6dbc24a65832360e1a8bdf1a113af211c693350`  
ZIP SHA-256: `9587b0c1a22f35e878c20be6a8914977bbe943aae41ef407ee4ce075d4db5634`

## 17. GH4 - Frame dragging and Kerr

**Gate classification:** PARTIAL.

**Earned:** The mixed source sector produces the correct far g0i coefficient without a new vector coupling. Kerr is Ricci-flat, reduces to Schwarzschild, and matches the weak spin coefficient, horizons, ZAMO dragging, and prograde/retrograde frequencies.

**Boundary/open debt:** Kerr uniqueness, rotating collapse, nonlinear stability, realistic rotating-star interiors, and Kerr ringdown remain open.

> **Receipt GH4:** `SFT_V13_1_V3_GH4_Frame_Dragging_and_Kerr_Hostile_Test_v0_1.zip`  
Status: `PARTIAL_PASS_FRAME_DRAGGING_AND_EXACT_KERR_EXISTENCE`  
Result SHA-256: `6f3ea29082bdb00654aa1d78fed2d7a9e4353893a13fee805d8c373f72ab90cb`  
ZIP SHA-256: `e9a18bb715b7ccc5c6bf16479b2c37f4a98841a99461dfe3d63bc998bdb84323`

## 18. GH5 - Wave speed and polarizations

**Gate classification:** PASS.

**Earned:** The harmonic trace-reversed carrier obeys a null wave equation. Ten amplitudes minus four constraints minus four residual relabelings leave exactly two TT modes. Exact Ricci-flat pp-waves carry arbitrary plus and cross profiles.

**Boundary/open debt:** Source generation, energy coefficient, tails, memory, and ringdown were not all in this gate.

> **Receipt GH5:** `SFT_V13_1_V3_GH5_Wave_Speed_and_Polarization_Hostile_Test_v0_1.zip`  
Status: `PASS_CONDITIONAL_TWO_TENSOR_MODES_AT_C`  
Result SHA-256: `3ca2a1329d31074c45b2885f8f7ba7d0807c2a4c24b9257db89035053a0ff53a`  
ZIP SHA-256: `239f8384b0a912d6f3837d3e36a803f6c63ab5b2cca73c41a33036f8c8e6790c`

## 19. GH6 - Quadrupole power and binary pulsars

**Gate classification:** PARTIAL.

**Earned:** The retarded source normalization gives hTT=2G Qddot/(c^4R); the quadratic wave ledger and TT angular projector give P=G<Q3Q3>/(5c^5). Conservation kills monopole and tensor dipole radiation. Leading pulsar regressions pass.

**Boundary/open debt:** The complete PN hierarchy, all timing corrections, merger phasing, memory, tails, and horizon absorption remain open.

> **Receipt GH6:** `SFT_V13_1_V3_GH6_Quadrupole_Power_and_Binary_Pulsar_Hostile_Test_v0_1.zip`  
Status: `PARTIAL_PASS_LEADING_QUADRUPOLE_AND_BINARY_PULSAR_REGRESSION`  
Result SHA-256: `c4531bcc7b780a36ff2a2f23d3c285e6db8ff9d6a19903004bf46cf49d4fdf87`  
ZIP SHA-256: `0d93ee61ecf1f3433f67af326049bd77fe4208d8234a69195ecb2035ddfabc14`

## 20. GH7 - Neutron-star structure, tides, and stability

**Gate classification:** PARTIAL.

**Earned:** Five untuned published EOS fits were integrated through TOV, binding, turning-point stability, causality, and Love response. MPA1 provided an untuned simple joint viability example; other matter models exposed tensions without gravity retuning.

**Boundary/open debt:** The EOS is external matter input. Radial eigenmodes, rotation, magnetism, temperature, superfluidity, phases, and mergers remain open.

> **Receipt GH7:** `SFT_V13_1_V3_GH7_Neutron_Star_Structure_Tidal_Response_and_Stability_Hostile_Test_v0_1.zip`  
Status: `PARTIAL_PASS_COLD_STATIC_NEUTRON_STAR_STRUCTURE_TIDES_AND_STABILITY`  
Result SHA-256: `c5ebbb542086d4cfaa195b73f1f8c1fbfbea3dbad1e4ba28caf819386913377a`  
ZIP SHA-256: `5ac9072081da9fc6457ac8f18019c9e0f9b640214594b93ae1365696d2212f98`

## 21. GH8 - Collapse, horizon, and ringdown

**Gate classification:** PARTIAL.

**Earned:** Homogeneous dust collapse keeps conserved shell mass, matches one Schwarzschild exterior, and crosses R=2M in finite proper time. Null expansions identify trapping. Independent RW/Zerilli pulses produce the canonical damped Schwarzschild mode at sub-percent accuracy.

**Boundary/open debt:** Realistic pressureful and rotating collapse, nonlinear stability, censorship, singularity resolution, thermodynamics, and information remain open.

> **Receipt GH8:** `SFT_V13_1_V3_GH8_Collapse_Horizon_and_Ringdown_Hostile_Test_v0_1.zip`  
Status: `PARTIAL_PASS_EXACT_DUST_COLLAPSE_HORIZON_AND_LINEAR_RINGDOWN`  
Result SHA-256: `1f1ea73c5077c0b301ef196ac798c82fff63a9c8ac7a610e885bb869a959c338`  
ZIP SHA-256: `4ed351c3b9dc0ab51b422cf4815c94f1e1b3518df738674fcc5de11c59e92234`

## 22. GH9 - Local gravity to cosmology handoff

**Gate classification:** PARTIAL WITH EXPLICIT FAIL.

**Earned:** FLRW reduction, matter/radiation dilution, exact dust vacuole matching, and the distinction between gravitational sourcing and global accessibility pass.

**Boundary/open debt:** The full covariant handoff fails: H=Ndot/I alone does not determine Hdot, acceleration, effective pressure, or the Friedmann constraint.

> **Receipt GH9:** `SFT_V13_1_V3_GH9_Local_Gravity_to_Cosmology_Handoff_Hostile_Test_v0_1.zip`  
Status: `PARTIAL_PASS_LOCAL_FLRW_COMPATIBILITY_FULL_COVARIANT_HANDOFF_OPEN`  
Result SHA-256: `637b52cb83757bb19d5630335cfb05ac9c989c7c3cea952eacd2a0fbd6dfb179`  
ZIP SHA-256: `dd8711d818cb836902af40f6b21b78a598a1a3d4e0ddc53300ac3f51eeaf579f`

## 23. GH9B - Trace-capacity bridge and horizon ledger

**Gate classification:** PARTIAL WITH EXPLICIT FAILS.

**Earned:** The determinant relation yields the exact kinematic bridge Theta=tr_perp Sdot=3H=3Ndot/I and a conserved effective capacity-stress reconstruction.

**Boundary/open debt:** Direct M^2 horizon-area amplification, unique ledger placement, additive area counting, cosmic use of local Lambda, and late acceleration are not earned.

> **Receipt GH9B:** `SFT_V13_1_V3_GH9B_Trace_Capacity_Constitutive_Bridge_Horizon_Ledger_and_No_Double_Counting_v0_1.zip`  
Status: `PARTIAL_PASS_KINEMATIC_TRACE_BRIDGE_HORIZON_MICRODYNAMICS_OPEN`  
Result SHA-256: `4f98f6a3713193d880a3b215f11f55cf4e7ab5c2f958e9ac4543eeb86d14d53f`  
ZIP SHA-256: `58f5ce404f09612417cca10f8ef7668913d6f885ed80aaec33fa0aa555af51bc`

## 24. GH10 - Alternative operators and final no-retuning audit

**Gate classification:** PASS.

**Earned:** The complete artifact chain and available result hashes were verified. The equation, source, metric map, local zero-write Lambda, modes, global master, and P1-P3 were unchanged. Common local alternatives fail or reduce within the contract.

**Boundary/open debt:** Causal nonlocal and specially degenerate higher-order completions remain unexcluded; all named debts remain active.

> **Receipt GH10:** `SFT_V13_1_V3_GH10_Alternative_Operator_and_No_Retuning_Final_Hostile_Audit_v0_1.zip`  
Status: `PASS_CONDITIONAL_GRAVITY_CANON_FREEZE_WITH_EXPLICIT_PREMISES_AND_OPEN_DEBTS`  
Result SHA-256: `04eb0b8c2dc7f848f6d70055ccb2c866d387223efe0f2b2ac532d3c5258bf77a`  
ZIP SHA-256: `f1e03a8f850fd69638e81f4431a18cf58f7aaf05f3ba3950eb1ef4ecaa61e070`

# Part VI - What the combined stack establishes

## 25. One equation across sectors

Under P1-P3, the same field equation supports the following receipt-backed stack:

- local Schwarzschild/Birkhoff and null-cone constraint propagation;
- universal spherical compact-body monopole and weak PPN $\eta_N=0$;
- one metric for dynamics, clocks, Shapiro delay, and lensing;
- weak frame dragging and exact Kerr vacuum existence;
- two TT gravitational-wave modes at $c$;
- leading quadrupole amplitude, power, eccentric enhancement, and selected pulsar regressions;
- cold TOV structure, binding, turning-point stability, and tidal Love response for external EOS inputs;
- exact homogeneous dust collapse, trapped surfaces, and linear Schwarzschild ringdown;
- FLRW compatibility, dust-vacuole matching, and the trace-capacity kinematic bridge.

This is a broad cross-sector regression stack. It is not a statement that every gravitational observation, environmental correction, or strong-field dynamical theorem has been reproduced.

## 26. The strongest no-retuning result

After G-COV-5, the equation form and original P1-P3 ledger were frozen before hostile testing. The later microscopic program did not retune the equation to pass the hostile gates; it investigated the premises independently and updated their truth status only through new receipts. H9 and H9B still do not close cosmology, and H7 still allows matter models to fail rather than changing gravity. P3B2R likewise repaired the source representation instead of hiding a distributional error.

This is the precise meaning of the canon sentence:

> **Matter models may fail. Gravity does not move to save them.**

A second sentence follows from the same record:

> **When a mechanism failed, the claim moved; the frozen equation did not.**

# Part VII - Alternative-operator and hidden-register audit

## 27. What was excluded inside the frozen local contract

- A primitive nonzero local $\Lambda$ changes zero-write vacuum and Schwarzschild.
- Massive spin two adds dispersion and increases the physical modes from two to five.
- Independent scalar and vector sectors add breathing/vector modes or compact-body sensitivities.
- Independent torsion and nonmetricity add connection state beyond $g(\Sigma)$.
- $R+\alpha R^2$ adds a scalar curvature pole for nonzero $\alpha$.
- Generic fourth-order metric operators add propagator poles and initial data.
- Four-dimensional Gauss-Bonnet is topological in the local bulk equation and is not a separate local competitor.

## 28. What was not exhaustively excluded

The selected-branch theorem is not a universal no-go against every mathematically conceivable gravity. Singular, causal nonlocal, topology-dependent, and specially degenerate higher-order completions remain outside the exhaustive result unless they are shown to introduce additional physical state or violate the frozen write contract. They require their own state-count, characteristic, causality, compact-body, wave, black-hole, cosmology, and no-retuning audits.

The P3 branch selection specifically does not claim that algebraic torsion or exotic degenerate formulations are impossible in all theories. It states that they are not independently present in the current source-complete minimal SFT gravity state.

# Part VIII - Cosmology and the trace-capacity bridge

## 29. What H9 earned and failed

The local equation admits FLRW and reproduces the frozen matter and radiation scalings. An exact dust vacuole shows a Schwarzschild local region coexisting with an expanding dust universe at $\Lambda_{\mathrm{local}}=0$. Horizon-inaccessible write stock remains gravitational mass in the local source ledger.

The full handoff failed because $H=\dot N/I$ does not by itself determine $\dot H$, acceleration, effective pressure, or the Hamiltonian constraint. The expansion program must pay a covariant bookkeeping bill.

## 30. What H9B closed

G-COV-3 already contained

$$\sqrt{-g'}=e^{\operatorname{tr}S}\sqrt{-g}.$$

Using $\sqrt{-g}=N\sqrt h$ separates lapse evolution from spatial volume. In cosmic time,

$$\Theta=\frac{d}{dt}\ln\sqrt h=\operatorname{tr}_{\perp}\dot S=3H=3\frac{\dot N_{\mathrm{write}}}{I_{\mathrm{write}}}.$$

This closes the **kinematic** geometry-to-capacity bridge. It also allows a conserved effective capacity stress to be reconstructed from $\Theta$ and $\dot\Theta$. It does not derive the microscopic history $\Theta(t)$.

## 31. What the black-hole area argument did not earn

Although $A_H\propto M^2$, the trace-like fractional rate is

$$\frac{d}{dt}\ln A_H=2\frac{\dot M}{M}.$$

Quadratic absolute area does not by itself prove an amplified logarithmic spatial trace. Numerator, denominator, and readout placements give different cosmological signs. Adding ordinary accretion writes and a horizon-area term can double-count the same irreversible event. A one-event yield law may be registered, but the horizon yield, two-area-to-three-volume averaging map, pressure sign, late acceleration, and DESI sign remain open.

# Part IX - Root-scale identifiability and prediction firewall

## 32. What is derived

The structural coupling is

$$G_{\mathrm{eff}}=\frac{a_\phi c^3}{\hbar}.$$

The root equivalence class relates

$$a_\phi,\quad \ell_\phi,\quad t_\phi,\quad m_\phi,\quad E_\phi,\quad G_{\mathrm{eff}}.$$

Supplying any one absolute member fixes the rest.

## 33. What is not identified

The current canon contains no equation with incompatible scale weight that selects the positive scale-orbit parameter. Dimensionless closure factors, event discreteness, mass ratios, compactness, horizon equality, and the current relaxation/rigidity scaffolds remain covariant under the orbit.

Therefore numerical $G$ is not first-principles derived.

## 34. Blind branch

The blind branch keeps $a_\phi$ symbolic and prohibits measured $G$, Planck units, measured absolute masses, cosmological rates, and hidden dimensionful cutoffs during model selection. Any future native scale breaker must be preregistered and hash-frozen before unblinding.

## 35. Correspondence branch

The correspondence branch uses

$$a_\phi^{\mathrm{cal}}=\frac{\hbar G_{\mathrm{obs}}}{c^3}$$

as one calibration identity. The same calibrated area must normalize acceleration, clock lag, lensing, frame dragging, waves, binaries, and horizons without sector-specific fitting.

A second absolute datum is a holdout only when its dimensionless coefficient was derived blind. Otherwise it is another fit.

# Part X - Public claim registry

## 36. Claims the Companion may make

- SFT derives a selected local Einstein-form gravity branch from the locally real particle/write ontology through a receipt-backed tensor, source, composition, naturality, state-closure, and continuum program.
- P1, P2, and P3 are discharged for that selected branch under their explicit regularity, locality, source-completeness, and boundary contracts.
- The exact microscopic theory remains an ordered event ledger; the path-ordered exponential is the many-write smooth representation.
- The conserved source is a boundary-complete worldline/edge-supported four-momentum current.
- The original equation survived the hostile stack without retuning.
- SFT derives $G=a_\phi c^3/\hbar$ and identifies $a_\phi$ as the universal write-area normalization modulus.
- In correspondence work, one measured $G$ calibrates that modulus once; all other gravity channels must agree without retuning.
- The trace-capacity bridge $\Theta=3H=3\dot N/I$ is kinematically earned.
- Strong-field, cosmological, source-microphysics, and absolute-scale debts remain named.

## 37. Claims the Companion may not make

- "SFT derives the measured numerical value of $G$ from its present scale-free primitives."
- "The isolated point event tensor is independently divergence-free."
- "Every atomic write is uniquely an exponential map."
- "Every exact ledger history possesses a smooth continuum limit."
- "The current rigidity operator derives the absolute W, Z, electron, or 125 GeV scales."
- "$\eta_N=0$ is an exact all-orders strong-field two-body theorem."
- "Kerr uniqueness, nonlinear stability, singularity resolution, or horizon thermodynamics are solved."
- "The full PN radiation hierarchy and every timing correction are derived."
- "SFT derives the nuclear EOS or the complete matter/source compounding law."
- "Black-hole area growth derives dark energy or the DESI sign."
- "Every conceivable alternative gravity theory has been excluded."
- "Measured $G$ and a second absolute datum may both be used to tune the same root scale and then called predictions."

# Part XI - Final open-debt ledger

## 38. Microscopic foundations

- unique microscopic matter/source completion law producing the conserved worldline-current increment;
- explicit $K_{\mathrm{set}}$, $\Gamma_{\mathrm{settle}}$, $\Phi_{\mathrm{relax}}$, and rigidity operator;
- native dimensionless particle and coupling spectrum;
- a future blind scale-generation theorem, or an explicit decision to promote one root face to a primitive;
- deeper derivation of the write-geometry dual-aspect identity.

## 39. Gravity dynamics

- unique exact nonlinear atomic gravity response rather than the selected sufficient retarded continuum branch;
- full nonlinear strong-equivalence and two-body effacement;
- complete PN conservative and radiative hierarchy;
- global Kerr uniqueness, mode stability, and nonlinear black-hole stability;
- realistic collapse, singularity resolution, horizon thermodynamics, information, and quantitative boundary-growth mechanics;
- native dense-matter microphysics and full rotating/magnetized/thermal stars.

## 40. Cosmology

- event-yield microdynamics for $\Theta(t)$ and the covariant Friedmann/pressure closure;
- horizon two-area to averaged spatial three-volume map;
- ledger placement and no-double-counting theorem for capacity stress;
- derived $\rho_{\mathrm{cap}}$ and $p_{\mathrm{cap}}$ rather than reverse reconstruction;
- late acceleration, epoch history, DESI/CMB/BAO/SN/$H_0$ compatibility.

# Final verdict

The most accurate one-paragraph statement is:

> **Starting from the frozen SFT locally real particle and irreversible-write ontology, V13.1-V3 constructs the minimal symmetric settlement carrier and a boundary-complete conserved write-momentum current, derives exact address naturality and ordered event composition, obtains a capacity-normalized many-write continuum flow, closes the selected regular local gravity state without independent torsion, higher-rate, BCH, or memory registers, and selects the Einstein-form equation $G_{\mu\nu}[g(\Sigma)]=(8\pi G_{\mathrm{eff}}/c^4)\mathcal W_{\mu\nu}$. The original equation survives the full hostile stack without retuning. SFT derives $G_{\mathrm{eff}}=a_\phi c^3/\hbar$ but the current scale-free canon does not determine the absolute universal write area. Numerical $G$ therefore remains open in the blind branch and is calibrated once from experiment in the correspondence branch.**

That is now the clean source of truth. The old conditional-premise wording is preserved only as historical construction provenance and is superseded as the current status of P1-P3.

# Appendix A - Immutable artifact ledger

## A.1 Antecedent receipts

**P-01 - SFT V12.12 Particle Program Main**  \
Artifact: `SFT_V12_12_Particle_Program_Main-3.pdf`  \
SHA-256: `eafbeb04017e2d5bb87270479eacc169e8024f66ef61576ede57127d758e7ebb`  \
Role: Frozen locally real particle doctrine: one-speed support, 4pi closure, no-overwrite, permanent writes.

**P-02 - SFT V13.2 Expansion and Time Production**  \
Artifact: `SFT_V13_2_Expansion_Time_production-1.pdf`  \
SHA-256: `666daa7e8533652cabecf73b17e5caf0a330019143fa482f22a18744ee8328de`  \
Role: Frozen global write/capacity master H=Ndot/I and one-write/three-readouts rule.

**V2-PUB - SFT V13.1-V2 Gravity public paper**  \
Artifact: `SFT_V13_1_V2_Gravity-2.pdf`  \
SHA-256: `9e0bd7af0138e15aed4d0e05936a7c909a9626ec69bfa81995a40ddce258fc25`  \
Role: Weak-field metric, G-root structure, bounded static spherical exterior, frontier map.

**V2-CAN - SFT V13.1-V2 Gravity derivation canon**  \
Artifact: `SFT_V13_1_V2_Gravity_Canon_Derivation_Paper_v0_1-2.pdf`  \
SHA-256: `347301ab25d103cc2d7c2d374fc34b75ff9f1b7c75b87d98fb00de63862b2420`  \
Role: Source-of-truth V2 derivation spine and claim boundaries.

**V2-REP - SFT V13.1-V2 full repro pack**  \
Artifact: `SFT_V13_1_V2_GRAVITY_CANON_FULL_REPRO_PACK-2.zip`  \
SHA-256: `fcc8842b890bbaccce8a0577d6963bb281e6614b2ec1327706f74cbb8a92c203`  \
Role: V2 scripts, tables, and audit artifacts.

## A.2 Construction and hostile releases

**GCOV1 - PASS_CONDITIONAL_MINIMAL_CARRIER_SELECTION**  \
Artifact: `SFT_V13_1_V3_GCOV1_Minimal_Covariant_Settlement_Carrier_v0_1.zip`  \
Result SHA-256: `not embedded; see report/README`  \
ZIP SHA-256: `e1c769bb219e842b0df20d983acbf533e9ec597271b9c2ece56c2f3635d22678`

**GCOV2A - PASS_NATIVE_SOURCE_AND_UNIQUE_LEADING_DUAL_COUPLING**  \
Artifact: `SFT_V13_1_V3_GCOV2A_Native_Write_Momentum_Source_and_Dual_Coupling_v0_1.zip`  \
Result SHA-256: `8e8a47ce8170656be29c5257c2064811de9882bb8611dc8abac7a827e6dd16cc`  \
ZIP SHA-256: `2ea1de1c23a0869ef76841f0fa244ee3dae27671a6e4e097970bc902389c5c6c`

**GCOV2B - PASS_CONDITIONAL_LINEAR_STOCK_FLOW_OPERATOR**  \
Artifact: `SFT_V13_1_V3_GCOV2B_Write_Geometry_Identity_and_Linear_Stock_Flow_v0_1.zip`  \
Result SHA-256: `3c36ef88eb00ecc9b733009715405445dc679c557891fde3b83b4009a37f20d7`  \
ZIP SHA-256: `5983cf4b04ae12ffea9c11c195abdf14d4b028110edeed6252b87dcf53b1872c`

**GCOV2C - PASS_STRONG_CONVERGENCE_WITH_COMPLEMENTARY_ROLES**  \
Artifact: `SFT_V13_1_V3_GCOV2C_Branch_Convergence_v0_1.zip`  \
Result SHA-256: `f6a99f9ac8fa8e18e8adab85edc9662161f42bbadf5d65796546ad8fba8c6b94`  \
ZIP SHA-256: `3f720fa5019b3c27df5669b36be1f579b3e1b441bee6396c31445d50dd9df971`

**GCOV3 - PASS_CONDITIONAL_METRIC_MAP_AND_NONLINEAR_ENTRY**  \
Artifact: `SFT_V13_1_V3_GCOV3_Metric_Constitutive_Map_and_Nonlinear_Closure_Entry_v0_1.zip`  \
Result SHA-256: `fb8eab8eb515f4d4e2e6b522b53fa0f3dcb491a493e040ca936682df9fae601b`  \
ZIP SHA-256: `ea00c92b4a689d5e0f7f4c316a6603cbb0caf7a59e3a3e062a8656b25297799d`

**GCOV4 - PASS_CONDITIONAL_SELF_COUPLING_AND_BINDING_LEDGER**  \
Artifact: `SFT_V13_1_V3_GCOV4_Nonlinear_Self_Coupling_and_Total_Ledger_Conservation_v0_1.zip`  \
Result SHA-256: `0f800c301702f997d00be2614b89da4612d3627db49ef9abcba2448f3289ad6a`  \
ZIP SHA-256: `fe09e07d3ae06d6e58c4392385d8dd552fc1d3a709daced881b1b353f6925974`

**GCOV5 - PASS_CONDITIONAL_FIELD_EQUATION_FREEZE_WITH_THREE_EXPLICIT_PREMISES**  \
Artifact: `SFT_V13_1_V3_GCOV5_Native_Assumption_Audit_and_Conditional_Field_Equation_Freeze_v0_1.zip`  \
Result SHA-256: `96d7ccf972a7fa1df73e4196d690ec9573a50395bd464ffebbe789fd588b642f`  \
ZIP SHA-256: `5bf180385db4ec175f97718eb20e815b4c4e93b0c3575d3e949986e61f43ebbf`

**GH1 - PASS_CONDITIONAL_BIRKHOFF_AND_CONSTRAINT_PROPAGATION**  \
Artifact: `SFT_V13_1_V3_GH1_Birkhoff_and_Constraint_Propagation_Hostile_Test_v0_1.zip`  \
Result SHA-256: `b55607233889ef309b35840f27fd1681d39c8d8e8f74560745d68040c8626739`  \
ZIP SHA-256: `978df1964b9e87655cd19b452b095c3118481343b56beba3f1eb258e406a2410`

**GH2 - PARTIAL_PASS_MONOPOLE_STRONG_EQUIVALENCE_AND_ZERO_NORDTVEDT**  \
Artifact: `SFT_V13_1_V3_GH2_Strong_Equivalence_and_Compact_Body_Sensitivity_Hostile_Test_v0_1.zip`  \
Result SHA-256: `e4db6523352333ffd567181cffec96dfc3b11f49dcd12a90dffdefbbddc0db02`  \
ZIP SHA-256: `e063f77c31096ee9b300154c59f904ba9d55dea92b87122e7807bc2a5194e3fd`

**GH3 - PASS_CONDITIONAL_LENSING_DYNAMICS_SINGLE_METRIC**  \
Artifact: `SFT_V13_1_V3_GH3_Lensing_Versus_Dynamics_Hostile_Test_v0_1.zip`  \
Result SHA-256: `084a7c9671772cc17a6ebd10a6dbc24a65832360e1a8bdf1a113af211c693350`  \
ZIP SHA-256: `9587b0c1a22f35e878c20be6a8914977bbe943aae41ef407ee4ce075d4db5634`

**GH4 - PARTIAL_PASS_FRAME_DRAGGING_AND_EXACT_KERR_EXISTENCE**  \
Artifact: `SFT_V13_1_V3_GH4_Frame_Dragging_and_Kerr_Hostile_Test_v0_1.zip`  \
Result SHA-256: `6f3ea29082bdb00654aa1d78fed2d7a9e4353893a13fee805d8c373f72ab90cb`  \
ZIP SHA-256: `e9a18bb715b7ccc5c6bf16479b2c37f4a98841a99461dfe3d63bc998bdb84323`

**GH5 - PASS_CONDITIONAL_TWO_TENSOR_MODES_AT_C**  \
Artifact: `SFT_V13_1_V3_GH5_Wave_Speed_and_Polarization_Hostile_Test_v0_1.zip`  \
Result SHA-256: `3ca2a1329d31074c45b2885f8f7ba7d0807c2a4c24b9257db89035053a0ff53a`  \
ZIP SHA-256: `239f8384b0a912d6f3837d3e36a803f6c63ab5b2cca73c41a33036f8c8e6790c`

**GH6 - PARTIAL_PASS_LEADING_QUADRUPOLE_AND_BINARY_PULSAR_REGRESSION**  \
Artifact: `SFT_V13_1_V3_GH6_Quadrupole_Power_and_Binary_Pulsar_Hostile_Test_v0_1.zip`  \
Result SHA-256: `c4531bcc7b780a36ff2a2f23d3c285e6db8ff9d6a19903004bf46cf49d4fdf87`  \
ZIP SHA-256: `0d93ee61ecf1f3433f67af326049bd77fe4208d8234a69195ecb2035ddfabc14`

**GH7 - PARTIAL_PASS_COLD_STATIC_NEUTRON_STAR_STRUCTURE_TIDES_AND_STABILITY**  \
Artifact: `SFT_V13_1_V3_GH7_Neutron_Star_Structure_Tidal_Response_and_Stability_Hostile_Test_v0_1.zip`  \
Result SHA-256: `c5ebbb542086d4cfaa195b73f1f8c1fbfbea3dbad1e4ba28caf819386913377a`  \
ZIP SHA-256: `5ac9072081da9fc6457ac8f18019c9e0f9b640214594b93ae1365696d2212f98`

**GH8 - PARTIAL_PASS_EXACT_DUST_COLLAPSE_HORIZON_AND_LINEAR_RINGDOWN**  \
Artifact: `SFT_V13_1_V3_GH8_Collapse_Horizon_and_Ringdown_Hostile_Test_v0_1.zip`  \
Result SHA-256: `1f1ea73c5077c0b301ef196ac798c82fff63a9c8ac7a610e885bb869a959c338`  \
ZIP SHA-256: `4ed351c3b9dc0ab51b422cf4815c94f1e1b3518df738674fcc5de11c59e92234`

**GH9 - PARTIAL_PASS_LOCAL_FLRW_COMPATIBILITY_FULL_COVARIANT_HANDOFF_OPEN**  \
Artifact: `SFT_V13_1_V3_GH9_Local_Gravity_to_Cosmology_Handoff_Hostile_Test_v0_1.zip`  \
Result SHA-256: `637b52cb83757bb19d5630335cfb05ac9c989c7c3cea952eacd2a0fbd6dfb179`  \
ZIP SHA-256: `dd8711d818cb836902af40f6b21b78a598a1a3d4e0ddc53300ac3f51eeaf579f`

**GH9B - PARTIAL_PASS_KINEMATIC_TRACE_BRIDGE_HORIZON_MICRODYNAMICS_OPEN**  \
Artifact: `SFT_V13_1_V3_GH9B_Trace_Capacity_Constitutive_Bridge_Horizon_Ledger_and_No_Double_Counting_v0_1.zip`  \
Result SHA-256: `4f98f6a3713193d880a3b215f11f55cf4e7ab5c2f958e9ac4543eeb86d14d53f`  \
ZIP SHA-256: `58f5ce404f09612417cca10f8ef7668913d6f885ed80aaec33fa0aa555af51bc`

**GH10 - PASS_CONDITIONAL_GRAVITY_CANON_FREEZE_WITH_EXPLICIT_PREMISES_AND_OPEN_DEBTS**  \
Artifact: `SFT_V13_1_V3_GH10_Alternative_Operator_and_No_Retuning_Final_Hostile_Audit_v0_1.zip`  \
Result SHA-256: `04eb0b8c2dc7f848f6d70055ccb2c866d387223efe0f2b2ac532d3c5258bf77a`  \
ZIP SHA-256: `f1e03a8f850fd69638e81f4431a18cf58f7aaf05f3ba3950eb1ef4ecaa61e070`

# Appendix B - Current branch and no-retuning contract

1. The selected local gravity equation and original hostile-test predictions remain frozen.
2. P1-P3 status changes are supported only by the post-G-COV microscopic audit receipts.
3. The P3B2 point-source conservation sentence is superseded by P3B2R; the original report remains in the archive for provenance.
4. The blind branch may not access any numerical absolute anchor during scale-breaker construction.
5. The correspondence branch may use measured $G$ exactly once to calibrate $a_\phi$.
6. No gravity channel receives an independent normalization.
7. Any second absolute quantity is a holdout only when its dimensionless coefficient was frozen independently.
8. Failed mechanisms, nonconvergent continuum histories, and unselected branches remain visible in the archive.

# Appendix C - New premise-discharge and root-scale receipt map

The reproduction pack contains the complete post-G-COV sequence:

```text
G-MICRO-0A / 0B
G-P2A0 / A1 / A2 / B1 / B2
G-P1A1 / A2 / B1 / B2 / C1 / D1
G-P3A1 / A2 / A3 / B1 / B2 / B2R
G-ROOT-A1 / A2 / B1
```

The original G-COV and G-H receipts remain unchanged under `receipts/original_v3/`. The premise-discharge reports are under `receipts/premise_discharge/`. Root-scale reports and branch configurations are under `receipts/root_scale/`.

# Appendix D - Supersession ledger

**P1 finite exponential composition remains an open premise.**  
Superseded by the exact ordered-history theorem plus capacity-normalized continuum emergence.

**P2 finite covariance remains an open premise.**  
Superseded by the physical-state quotient, exact event naturality, and local descent theorem.

**P3 local second-order closure remains an open premise.**  
Superseded for the selected minimal gravity kernel by state-count, branch adjudication, and fiber constancy.

**A point-supported completed event is independently conserved.**  
Failed and repaired by the worldline/edge-current construction.

**Numerical $G$ is simply an unspecified future number.**  
Sharpened to a one-parameter root-scale non-identifiability theorem and blind/calibrated branch contract.

**Rigidity or relaxation may already contain the absolute scale.**  
The hostile audit finds no current native scale breaker.
