#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
STEM="SFT_V13_1_V3_Gravity_Derivation_Canon_Receipts_v1_0"
subprocess.run(["pandoc",str(ROOT/f"{STEM}.md"),"-o",str(ROOT/f"{STEM}.docx"),"--from=markdown+tex_math_dollars","--to=docx",f"--reference-doc={ROOT/'source_context'/'reference_styles.docx'}"],check=True)
subprocess.run([sys.executable,str(ROOT/'scripts'/'postprocess_docx.py'),str(ROOT/f"{STEM}.docx")],check=True)
print(ROOT/f"{STEM}.docx")
