#!/usr/bin/env python3
from pathlib import Path
import argparse
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


def postprocess(path: Path) -> None:
    doc = Document(path)
    for sec in doc.sections:
        sec.top_margin = Inches(.72)
        sec.bottom_margin = Inches(.68)
        sec.left_margin = Inches(.78)
        sec.right_margin = Inches(.72)
        sec.header_distance = Inches(.3)
        sec.footer_distance = Inches(.35)
        hp = sec.header.paragraphs[0]
        hp.text = 'SFT V13.1-V3 GRAVITY DERIVATION CANON  |  RECEIPT-BACKED SOURCE OF TRUTH'
        hp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in hp.runs:
            r.font.name = 'Aptos'; r.font.size = Pt(7.5); r.font.color.rgb = RGBColor(95,104,112)
        fp = sec.footer.paragraphs[0]
        fp.clear(); fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = fp.add_run('SFT V13.1-V3  |  Page ')
        r.font.name = 'Aptos'; r.font.size = Pt(8); r.font.color.rgb = RGBColor(95,104,112)
        fld = OxmlElement('w:fldSimple'); fld.set(qn('w:instr'), 'PAGE'); fp._p.append(fld)

    styles = doc.styles
    normal = styles['Normal']
    normal.font.name = 'Aptos'; normal.font.size = Pt(10.3); normal.font.color.rgb = RGBColor(30,36,42)
    normal.paragraph_format.line_spacing = 1.08; normal.paragraph_format.space_after = Pt(5)
    for name,size,color in [
        ('Title',27,RGBColor(25,50,75)), ('Subtitle',14.5,RGBColor(79,89,99)),
        ('Heading 1',18,RGBColor(25,50,75)), ('Heading 2',13.5,RGBColor(33,79,115)),
        ('Heading 3',11.3,RGBColor(52,72,88))]:
        st = styles[name]; st.font.name = 'Aptos Display'; st.font.size = Pt(size); st.font.color.rgb = color
        st.paragraph_format.keep_with_next = True
    styles['Heading 1'].paragraph_format.page_break_before = False
    styles['Heading 1'].paragraph_format.space_before = Pt(0); styles['Heading 1'].paragraph_format.space_after = Pt(8)
    styles['Heading 2'].paragraph_format.space_before = Pt(10); styles['Heading 2'].paragraph_format.space_after = Pt(4)
    styles['Heading 3'].paragraph_format.space_before = Pt(7); styles['Heading 3'].paragraph_format.space_after = Pt(3)
    if 'Block Text' in styles:
        st = styles['Block Text']; st.font.name = 'Aptos'; st.font.size = Pt(9.2); st.font.color.rgb = RGBColor(42,52,62)
        st.paragraph_format.left_indent = Inches(.25); st.paragraph_format.right_indent = Inches(.15)
        st.paragraph_format.space_before = Pt(5); st.paragraph_format.space_after = Pt(6)
    if 'Source Code' in styles:
        st = styles['Source Code']; st.font.name = 'Consolas'; st.font.size = Pt(7.8); st.font.color.rgb = RGBColor(35,43,50)

    for para in doc.paragraphs:
        txt = para.text.strip()
        if para.style.name == 'Title':
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.paragraph_format.space_before = Pt(70); para.paragraph_format.space_after = Pt(14)
        elif para.style.name == 'Subtitle':
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER; para.paragraph_format.space_after = Pt(24)
        elif para.style.name in ('Author','Date'):
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if para.style.name == 'Block Text':
            pPr = para._p.get_or_add_pPr()
            shd = pPr.find(qn('w:shd'))
            if shd is None:
                shd = OxmlElement('w:shd'); pPr.append(shd)
            shd.set(qn('w:fill'), 'EEF3F7')
            pBdr = pPr.find(qn('w:pBdr'))
            if pBdr is None:
                pBdr = OxmlElement('w:pBdr'); pPr.append(pBdr)
            left = OxmlElement('w:left'); left.set(qn('w:val'),'single'); left.set(qn('w:sz'),'12')
            left.set(qn('w:space'),'6'); left.set(qn('w:color'),'2F6B91'); pBdr.append(left)
        if para._p.xpath('.//*[local-name()="oMathPara"]') or (para._p.xpath('.//*[local-name()="oMath"]') and len(txt) < 4):
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.paragraph_format.space_before = Pt(5); para.paragraph_format.space_after = Pt(6)
        if 'SHA-256:' in txt or txt.startswith('Artifact:'):
            for run in para.runs:
                run.font.name = 'Consolas'; run.font.size = Pt(7.7)

    for table in doc.tables:
        table.alignment = WD_TABLE_ALIGNMENT.CENTER; table.style = 'Table Grid'; table.autofit = True
        for ri,row in enumerate(table.rows):
            for cell in row.cells:
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                tcPr = cell._tc.get_or_add_tcPr()
                mar = tcPr.first_child_found_in('w:tcMar')
                if mar is None:
                    mar = OxmlElement('w:tcMar'); tcPr.append(mar)
                    for side,val in [('top',60),('left',70),('bottom',60),('right',70)]:
                        e = OxmlElement(f'w:{side}'); e.set(qn('w:w'),str(val)); e.set(qn('w:type'),'dxa'); mar.append(e)
                if ri == 0:
                    shd = tcPr.find(qn('w:shd'))
                    if shd is None: shd = OxmlElement('w:shd'); tcPr.append(shd)
                    shd.set(qn('w:fill'),'2F6B91')
                for p in cell.paragraphs:
                    p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.0
                    for run in p.runs:
                        run.font.name = 'Aptos'; run.font.size = Pt(8.0 if len(table.columns)>3 else 8.5)
                        if ri == 0:
                            run.font.bold = True; run.font.color.rgb = RGBColor(255,255,255)
            if ri == 0:
                trPr = row._tr.get_or_add_trPr(); tblHeader = OxmlElement('w:tblHeader')
                tblHeader.set(qn('w:val'),'true'); trPr.append(tblHeader)

    major_breaks = {
        'Contents','Executive source-of-truth statement',
        'Part I - The frozen native starting point',
        'Part II - Chain audit from particle to field equation',
        'Part III - Construction receipts',
        'Part IV - P1-P3 premise-discharge and source-repair program','Part V - Original hostile gauntlet receipts',
        'Part VII - Alternative-operator and hidden-register audit',
        'Part IX - Root-scale identifiability and prediction firewall','Part X - Public claim registry','Part XI - Final open-debt ledger',
        'Final verdict','Appendix A - Immutable artifact ledger'
    }
    for para in doc.paragraphs:
        if para.style.name == 'Heading 1':
            para.paragraph_format.page_break_before = para.text.strip() in major_breaks

    for para in doc.paragraphs[:14]:
        if para.style.name == 'Date' or para.text.strip() == '2026-07-21':
            p2 = para.insert_paragraph_before('REVISED STRUCTURAL CLOSURE CANON  |  RECEIPTS v1.0')
            p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for r in p2.runs:
                r.font.name = 'Aptos'; r.font.size = Pt(9); r.font.bold = True; r.font.color.rgb = RGBColor(34,110,74)
            break
    doc.save(path)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('docx', type=Path)
    args = ap.parse_args()
    postprocess(args.docx)
    print(args.docx)

if __name__ == '__main__':
    main()
