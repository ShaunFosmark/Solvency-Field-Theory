#!/usr/bin/env python3
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
subprocess.run(["pandoc",str(ROOT/"SFT_V13_1_V3_Gravity.md"),"-o",str(ROOT/"SFT_V13_1_V3_Gravity.docx"),"--from=markdown+tex_math_dollars","--to=docx",f"--reference-doc={ROOT/'source_context'/'reference_styles.docx'}"],check=True)
print(ROOT/"SFT_V13_1_V3_Gravity.docx")
