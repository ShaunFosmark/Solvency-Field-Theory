# SFT V13.1-V3 Gravity Derivation Canon - Revised Before Shipment

Canonical status:

`PASS_SELECTED_GRAVITY_BRANCH_STRUCTURAL_CLOSURE_P1_P2_P3_DISCHARGED_NUMERICAL_G_OPEN_BLIND_AND_CALIBRATED_IN_CORRESPONDENCE`

This release replaces the earlier unshipped conditional-premise draft while preserving every original construction and hostile receipt.

Key equation:

`G_mn[g(Sigma)] = (8 pi G_eff / c^4) W_mn`

Root relation:

`G_eff = a_phi c^3 / hbar`

Build:

`python scripts/build_document.py`

The pack contains Markdown, DOCX, PDF, original V3 receipts, all premise-discharge reports, root-scale audits, branch configurations, claim ledgers, scripts, and SHA-256 manifests.
