#!/usr/bin/env python3
"""
G-ROOT-B1 audit.

Formalizes:
1. One nonzero-weight absolute anchor fixes the one-dimensional root-scale orbit.
2. A claim depending on that anchor is calibrated, not first-principles absolute.
3. A second absolute datum is a holdout test if it was not used to select the model.
4. Multiple anchors used to select coefficients violate the prediction firewall.

No measured numerical value is required.
"""

from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "g_root_b1_results.json"

# Root weights under ell_phi -> lambda ell_phi.
ROOT_WEIGHTS = {
    "ell_phi": 1,
    "a_phi": 2,
    "G": 2,
    "length": 1,
    "time": 1,
    "mass": -1,
    "energy": -1,
    "frequency": -1,
    "H": -1,
    "dimensionless": 0,
}

def one_anchor_theorem(weight: int) -> bool:
    """Any observable with nonzero root weight fixes lambda uniquely for positive scales."""
    return weight != 0

def classify_claim(*, uses_anchor: bool, target_is_anchor: bool, coefficient_prederived: bool, extra_absolute_fit: bool) -> str:
    if extra_absolute_fit:
        return "FORBIDDEN_MULTI_ANCHOR_OR_RETUNED"
    if target_is_anchor:
        return "CALIBRATION_IDENTITY_NOT_PREDICTION"
    if uses_anchor and coefficient_prederived:
        return "ONE_ANCHOR_ABSOLUTE_PREDICTION"
    if uses_anchor and not coefficient_prederived:
        return "UNDERDETERMINED_OR_RETROFIT"
    if not uses_anchor and coefficient_prederived:
        return "BLIND_DERIVED_STRUCTURE_OR_DIMENSIONLESS_PREDICTION"
    return "OPEN"

def dependency_taint(graph, anchors):
    """Propagate anchor dependence through a directed dependency graph."""
    tainted = set(anchors)
    changed = True
    while changed:
        changed = False
        for node, deps in graph.items():
            if node not in tainted and any(dep in tainted for dep in deps):
                tainted.add(node)
                changed = True
    return sorted(tainted)

def main():
    anchors = {name: one_anchor_theorem(weight) for name, weight in ROOT_WEIGHTS.items()}
    graph = {
        "a_phi_cal": ["G_anchor"],
        "ell_phi_cal": ["a_phi_cal"],
        "root_mass_cal": ["ell_phi_cal"],
        "clock_lag_prediction": ["a_phi_cal", "dimensionless_clock_kernel"],
        "lensing_prediction": ["a_phi_cal", "dimensionless_lensing_kernel"],
        "wave_prediction": ["a_phi_cal", "dimensionless_wave_kernel"],
        "particle_mass_prediction": ["root_mass_cal", "dimensionless_particle_eigenvalue"],
        "dimensionless_mass_ratio": ["dimensionless_particle_eigenvalue"],
        "G_anchor": [],
        "dimensionless_clock_kernel": [],
        "dimensionless_lensing_kernel": [],
        "dimensionless_wave_kernel": [],
        "dimensionless_particle_eigenvalue": [],
    }
    tainted = dependency_taint(graph, {"G_anchor"})

    examples = {
        "G_after_using_G_anchor": classify_claim(
            uses_anchor=True, target_is_anchor=True, coefficient_prederived=True, extra_absolute_fit=False
        ),
        "lensing_after_G_anchor_and_frozen_kernel": classify_claim(
            uses_anchor=True, target_is_anchor=False, coefficient_prederived=True, extra_absolute_fit=False
        ),
        "particle_mass_after_G_anchor_but_open_eigenvalue": classify_claim(
            uses_anchor=True, target_is_anchor=False, coefficient_prederived=False, extra_absolute_fit=False
        ),
        "mass_ratio_blind": classify_claim(
            uses_anchor=False, target_is_anchor=False, coefficient_prederived=True, extra_absolute_fit=False
        ),
        "G_and_electron_both_used_to_tune": classify_claim(
            uses_anchor=True, target_is_anchor=False, coefficient_prederived=True, extra_absolute_fit=True
        ),
    }

    result = {
        "gate": "G-ROOT-B1",
        "root_orbit_dimension": 1,
        "one_anchor_theorem": anchors,
        "anchor_tainted_outputs_for_G_calibration": tainted,
        "claim_classification_examples": examples,
        "selected_canonical_policy": {
            "blind_branch": "Keep a_phi symbolic and prohibit all absolute empirical anchors.",
            "correspondence_branch": "Use measured G once to set a_phi = hbar G/c^3; label G calibrated.",
            "future_native_breaker_branch": "Develop and preregister independently; compare to G only after freeze.",
            "primitive_status": "Do not promote a_phi to a permanently irreducible primitive yet; retain it as an open universal normalization modulus.",
        },
        "measured_numerical_value_used": False,
    }
    OUT.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
