# Solvency Field Theory

## G-ROOT-B1 — Final Root-Scale Adjudication, One-Anchor Contract, and Prediction Firewall v0.1

Generated: 2026-07-22

```text
G_ROOT_B1_VERDICT =

PASS_UPSTREAM_G_ROOT_A_ONE_AND_G_ROOT_A_TWO_NO_GO_FREEZE;

PASS_ONE_DIMENSIONAL_ROOT_ORBIT_THEOREM;

ANY_ONE_INDEPENDENT_ABSOLUTE_OBSERVABLE_WITH_NONZERO_ROOT_WEIGHT_FIXES_THE_SINGLE_POSITIVE_SCALE_MODULUS;

PASS_CANONICAL_TWO_BRANCH_ADJUDICATION;

THE_BLIND_DERIVATION_BRANCH_RETAINS_A_PHI_AS_A_SYMBOLIC_POSITIVE_UNIVERSAL_NORMALIZATION_MODULUS_AND_PROHIBITS_ALL_ABSOLUTE_EMPIRICAL_ANCHORS;

THE_GRAVITY_CORRESPONDENCE_BRANCH_MAY_USE_MEASURED_G_EXACTLY_ONCE_TO_CALIBRATE_A_PHI_EQUALS_HBAR_G_OBS_OVER_C_CUBED;

PASS_NUMERICAL_G_CLAIM_FIREWALL;

NUMERICAL_G_IS_CALIBRATED_NOT_PREDICTED_IN_THE_G_ANCHORED_BRANCH;

PASS_ONE_ANCHOR_CROSS_CHANNEL_PREDICTION_CONTRACT;

AFTER_G_CALIBRATION_CLOCK_LAG_LENSING_FRAME_DRAGGING_WAVES_BINARY_DYNAMICS_AND_HORIZON_RESPONSE_MUST_USE_THE_SAME_A_PHI_WITH_NO_CHANNEL_SPECIFIC_RETUNING;

PASS_SECOND_ABSOLUTE_DATUM_RECLASSIFICATION;

ANY_SECOND_ABSOLUTE_OBSERVABLE_IS_A_HOLDOUT_TEST_IF_ITS_DIMENSIONLESS_COEFFICIENT_WAS_FROZEN_BLIND_AND_IS_A_RETROFIT_IF_USED_TO_SELECT_OR_RETUNE_THE_MODEL;

PASS_PARTICLE_MASS_ANCHOR_REJECTION_AT_THE_CURRENT_STAGE;

THE_CURRENT MASS_OPERATOR_DOES_NOT YET DERIVE THE DIMENSIONLESS ELECTRON_W_Z_OR_RIGIDITY_RESONANCE COEFFICIENTS NEEDED TO USE THOSE MASSES AS CLEAN ROOT ANCHORS;

PASS_COSMOLOGICAL_H_ANCHOR_REJECTION;

A_STATE_AND_EPOCH_DEPENDENT_RATE_IS_NOT_ACCEPTED_AS_THE_UNIVERSAL_LOCAL_ROOT_NORMALIZATION_WITHOUT_AN_INVARIANT_ATTRACTOR_THEOREM;

PASS_PRIMITIVE_FALLBACK_CLASSIFICATION;

A_PHI_COULD_BE_PROMOTED_TO_ONE_NEW_FUNDAMENTAL_CONSTANT_BUT_THIS IS_NOT_SELECTED YET BECAUSE IT WOULD END RATHER THAN SOLVE THE NATIVE SCALE_GENERATION PROGRAM;

PASS_FUTURE_NATIVE_BREAKER_BLIND_PROTOCOL;

ALL_CANDIDATE_FAMILIES_ALLOWED CONSTANTS COMPLEXITY CEILINGS AND HOLDOUTS MUST BE HASH_FROZEN BEFORE ACCESS TO MEASURED_G;

PASS_G_ROOT_FINAL_ADJUDICATION;

THE_CURRENT_CANON DERIVES THE GRAVITY STRUCTURE AND ROOT RELATION BUT NOT NUMERICAL_G;

G_CLOSE_ONE_UPDATED_GRAVITY_CANON_AND_PREMISE_NORMALIZATION_LEDGER_ROLLUP_READY.
```

## 1. Adjudication question

G-ROOT-A1 proved that the current frozen equations possess a continuous one-parameter root-scale orbit. G-ROOT-A2 showed that the current settlement-relaxation, rigidity, memory, and transmutation targets do not break that orbit.

The remaining task is not another formula search. It is to decide:

1. what \(a_\phi\) is allowed to mean in the current canon;
2. how correspondence calculations may use measured \(G\);
3. which later outputs count as predictions;
4. how a future native scale-generation attempt remains blind.

## 2. One-anchor theorem

Let an absolute observable \(Q\) have root weight \(w_Q\neq0\):

\[
Q=\widehat Q\,\ell_\phi^{\,w_Q}
\]

after all powers of \(c\) and \(\hbar\) are restored, where \(\widehat Q\) is dimensionless and independently derived.

One measured value fixes:

\[
\ell_\phi
=
\left(\frac{Q_{\rm obs}}{\widehat Q}\right)^{1/w_Q}.
\]

Because the root orbit has one positive parameter, one valid nonzero-weight anchor is sufficient.

A second absolute datum must therefore be one of two things:

- a **holdout test**, if its dimensionless coefficient was fixed independently;
- an **additional fit**, if it changes the model, coefficients, branch, or selector.

This is the central prediction-accounting theorem.

## 3. Selected canonical policy

The gate selects two explicitly separated branches.

### 3.1 Blind derivation branch

\[
\boxed{
a_\phi>0\quad\text{remains symbolic and universal.}
}
\]

No numerical absolute anchor is permitted.

The branch may derive:

```text
dimensionless coefficients
mass and coupling ratios
root-weight relations
symbolic formulas involving a_phi
native scale-breaker candidates
```

It may not use:

```text
measured G
Planck units
measured particle masses
H0 or an epoch-dependent H
black-hole radii defined through G
any hidden numerical length, time, mass, area, or cutoff
```

This branch preserves the possibility of a genuine future numerical-\(G\) derivation.

### 3.2 Gravity correspondence branch

For comparison with experiment and practical gravity calculations, measured \(G\) may be used exactly once:

\[
\boxed{
a_\phi^{\rm cal}
=
\frac{\hbar G_{\rm obs}}{c^3}.
}
\]

This is a calibration identity.

It is not a prediction of \(G\), \(a_\phi\), or the Planck-scale equivalent.

After that calibration, the same \(a_\phi^{\rm cal}\) must normalize every gravity channel without retuning.

## 4. Why measured G is the selected correspondence anchor

Measured \(G\) is the cleanest operational anchor for the present gravity canon because it:

- directly fixes the only unresolved gravity normalization;
- does not consume particle masses as fits;
- does not consume a cosmological epoch as a universal constant;
- leaves force-sector masses and cosmological dynamics available as future holdouts;
- makes channel universality immediately testable.

This choice does not assert that \(G\) is fundamentally more primitive than particle mass. It is an accounting decision for the current gravity branch.

## 5. Why other anchors are not authorized now

### Electron mass

An electron anchor would require a frozen dimensionless prediction:

\[
m_e=\epsilon_e\frac{\hbar}{c\ell_\phi}.
\]

The current operator program has not derived \(\epsilon_e\) independently of mass data. Using \(m_e\) now would therefore be calibration plus an unearned coefficient, not a prediction of \(G\).

### W, Z, or rigidity resonance

These remain correspondence targets of an unfinished rigidity operator. Using them as anchors would erase the intended force-sector test.

### Cosmological \(H\)

A local root constant cannot be calibrated from an epoch-dependent rate unless SFT derives a universal invariant combination. That theorem is absent.

### Primitive \(a_\phi\)

Promoting \(a_\phi\) to a fundamental constant is mathematically coherent and would complete the theory with one additional dimensionful primitive. It is retained as a fallback but not selected now, because the native scale-generation program remains open.

## 6. Claim-status firewall

### Derived now

SFT may claim:

\[
G_{\rm eff}=\frac{a_\phi c^3}{\hbar}.
\]

It may claim the selected tensor, covariance, composition, continuum, state-closure, and source-conservation structure under their frozen branch contracts.

It may claim the root-scale orbit and the A1/A2 no-go.

### Open now

SFT must state:

```text
the absolute value of a_phi is open in the blind branch
numerical G is not first-principles derived
the native settlement-relaxation operator does not yet fix the root
```

### Calibrated now

In the correspondence branch:

\[
a_\phi^{\rm cal}=\frac{\hbar G_{\rm obs}}{c^3}
\]

is calibrated.

Any restatement of measured \(G\) through this identity remains calibration.

### Predictions after one anchor

Once \(G\) is the sole anchor, these can be genuine cross-channel predictions if their dimensionless equations were frozen independently:

```text
clock lag
light deflection
lensing
frame dragging
wave speed and polarization
binary dynamics and radiation
horizon response
future absolute particle masses
future absolute cosmological rates
```

The last two remain future predictions because their dimensionless operators are not yet complete.

### Forbidden claims

The following are prohibited:

```text
"SFT derives numerical G" in the G-calibrated branch
using measured G to select an integer, exponent, winding, or projector combination
using G and a particle mass jointly to retune the same root scale
using Planck units as independent evidence
claiming a second fitted absolute quantity as a prediction
switching anchors between sectors
channel-specific gravity normalization
```

## 7. Taint and holdout rule

Any quantity downstream of the selected anchor is **anchor-dependent**.

Anchor dependence does not automatically make it nonpredictive. The correct distinction is:

\[
\boxed{
\text{anchor dependence}
+
\text{independently frozen dimensionless coefficient}
=
\text{one-anchor absolute prediction}.
}
\]

But:

\[
\boxed{
\text{anchor dependence}
+
\text{coefficient selected using the same target}
=
\text{retrofit}.
}
\]

Thus, after \(G\) calibration:

- lensing is a prediction if its kernel was fixed without lensing data;
- an electron mass is a prediction only if \(\epsilon_e\) was derived without electron-mass data;
- \(G\) itself is never a prediction in that branch.

## 8. Future native scale-breaker protocol

A future attempt to derive numerical \(G\) must run only in the blind branch.

Before any unblinding, freeze:

```text
permitted primitives
candidate operator family
boundary-condition family
allowed integers and topology labels
complexity ceiling
selection criterion
species-universality tests
environment-independence tests
cross-channel holdouts
failure conditions
code and data hashes
```

The candidate must output \(a_\phi\) or an equivalent root quantity without access to measured \(G\).

Only after the prediction is frozen may it be compared with experiment.

A failed prediction remains frozen. The candidate family may not be edited after unblinding and presented as the same derivation.

## 9. Canonical status of a_phi

The selected status is:

\[
\boxed{
a_\phi
=
\text{one universal unresolved normalization modulus in the blind canon.}
}
\]

It is not currently classified as:

```text
derived
dimensionless
species-dependent
environment-dependent
a measured quantity
a permanently irreducible primitive
```

In the correspondence branch it becomes one empirically calibrated universal constant.

This status is deliberately reversible: a future native scale theorem may promote it from OPEN to DERIVED without rewriting the structural gravity program.

## 10. Updated gravity truth hierarchy

```text
DERIVED / EARNED WITHIN FROZEN BRANCH:
P1 smooth continuum composition
P2 address naturality and local covariance
P3 selected state sufficiency
worldline-supported source conservation
tensor carrier and source structure
Einstein-form selected closure
G = a_phi c^3 / hbar
root-scale equivalence class
absolute-scale no-go for current primitives

OPEN:
native exact absolute-scale selector
numerical a_phi in the blind branch
first-principles numerical G
absolute rigidity and particle-mass unit
quantitative horizon-area increment

CALIBRATED IN CORRESPONDENCE BRANCH:
a_phi from measured G
the common gravity normalization

FUTURE HOLDOUTS:
cross-channel gravity consistency
absolute masses after a blind dimensionless operator derivation
cosmological absolute rates after blind dynamics
any future native a_phi prediction
```

## 11. Final adjudication

The current SFT gravity program has earned a much stronger result than merely fitting \(G\):

> It derives the structural location and physical meaning of the gravitational coupling as the universal footprint of one irreversible write.

But it has not earned the number.

The proper current statement is:

\[
\boxed{
\text{SFT derives }G\text{ up to one universal absolute write-area modulus.}
}
\]

For practical gravity work, one measured \(G\) calibrates that modulus once. For foundational work, the blind branch keeps it symbolic until a genuine scale-generating theorem is found.

## 12. Next gate

\[
\boxed{
\text{G-CLOSE-1 — Updated Gravity Canon, Premise Discharge,}
}
\]

\[
\boxed{
\text{Source-Current Repair, Continuum Closure, and Root-Normalization Ledger Rollup.}
}
\]

G-CLOSE-1 should now rewrite the V13.1-V3 truth hierarchy without the obsolete P1-P3 premise language and with the explicit blind-versus-calibrated root branches.
