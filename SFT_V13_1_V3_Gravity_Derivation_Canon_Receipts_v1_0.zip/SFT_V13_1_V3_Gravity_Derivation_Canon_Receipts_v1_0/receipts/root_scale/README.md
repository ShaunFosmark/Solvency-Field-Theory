# G-ROOT-B1 pack

This gate freezes the root-scale truth status and prediction firewall.

Run:

```bash
python g_root_b1_prediction_firewall_audit.py
```

The pack contains:

- blind branch configuration;
- measured-G correspondence branch configuration;
- anchor adjudication matrix;
- claim-status ledger;
- reproducibility script;
- full report.

No measured numerical value is included.
