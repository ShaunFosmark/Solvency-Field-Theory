#!/usr/bin/env python3
from __future__ import annotations
import json, math, random
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "g_root_a2_results.json"

def relerr(a, b):
    return abs(a - b) / max(1.0, abs(a), abs(b))

def relaxation_orbit_test(trials=5000, seed=22072026):
    rng = random.Random(seed)
    max_err = 0.0
    for _ in range(trials):
        lam = 10 ** rng.uniform(-8, 8)
        p = rng.random()
        u = rng.random()
        leff = 9.097814727066048
        H = 10 ** rng.uniform(-8, 8)
        tau = 10 ** rng.uniform(-8, 8)
        Awrite = 10 ** rng.uniform(-8, 8)
        Abound = 10 ** rng.uniform(-8, 8)
        gamma = 10 ** rng.uniform(-8, 8)
        phi = p*leff*u + math.tanh(H*tau) + math.log1p(Awrite/Abound) + 0.25*math.atan(gamma*tau)
        phi2 = p*leff*u + math.tanh((H/lam)*(tau*lam)) + math.log1p((Awrite*lam**2)/(Abound*lam**2)) + 0.25*math.atan((gamma/lam)*(tau*lam))
        max_err = max(max_err, relerr(phi, phi2))
    return max_err

def rigidity_potential_orbit_test(trials=3000, seed=2662026):
    rng = random.Random(seed)
    max_v_err = 0.0
    max_V_err = 0.0
    for _ in range(trials):
        scale = 10 ** rng.uniform(-8, 8)
        mu = 10 ** rng.uniform(-6, 6)
        quartic = 10 ** rng.uniform(-4, 2)
        H = rng.uniform(-5, 5) * mu / math.sqrt(quartic)
        v = mu / math.sqrt(quartic)
        V = -0.5*mu**2*H**2 + 0.25*quartic*H**4
        mu2, H2 = mu/scale, H/scale
        v2 = mu2 / math.sqrt(quartic)
        V2 = -0.5*mu2**2*H2**2 + 0.25*quartic*H2**4
        max_v_err = max(max_v_err, relerr(v2, v/scale))
        max_V_err = max(max_V_err, relerr(V2, V/scale**4))
    return {"minimum_scale_covariance": max_v_err, "potential_scale_covariance": max_V_err}

def spectral_gap_orbit_test(trials=2000, seed=13072026):
    rng = np.random.default_rng(seed)
    max_mass_cov = 0.0
    max_ratio_inv = 0.0
    for _ in range(trials):
        n = int(rng.integers(3, 9))
        A = rng.normal(size=(n, n))
        op = A.T @ A + 0.1*np.eye(n)
        eps = np.linalg.eigvalsh(op)
        ell = 10 ** rng.uniform(-8, 8)
        scale = 10 ** rng.uniform(-8, 8)
        masses = eps/ell
        masses2 = eps/(scale*ell)
        denom = np.maximum.reduce([np.ones_like(masses), np.abs(masses2), np.abs(masses/scale)])
        max_mass_cov = max(max_mass_cov, float(np.max(np.abs(masses2 - masses/scale)/denom)))
        max_ratio_inv = max(max_ratio_inv, float(np.max(np.abs(masses2/masses2[0] - masses/masses[0]))))
    return {"mass_covariance": max_mass_cov, "ratio_invariance": max_ratio_inv}

def transmutation_orbit_test(trials=5000, seed=4252026):
    rng = random.Random(seed)
    max_err = 0.0
    for _ in range(trials):
        mu0 = 10 ** rng.uniform(-8, 8)
        b = 10 ** rng.uniform(-2, 1)
        g0 = rng.uniform(0.15, 1.2)
        scale = 10 ** rng.uniform(-8, 8)
        L1 = mu0 * math.exp(-1.0/(b*g0*g0))
        L2 = (mu0/scale) * math.exp(-1.0/(b*g0*g0))
        max_err = max(max_err, relerr(L2, L1/scale))
    return max_err

def cycle_test():
    graph = {
        "A_write": ["Phi_relax", "G"],
        "Phi_relax": ["absolute_mass", "rigidity_masses"],
        "absolute_mass": ["A_write"],
        "rigidity_masses": [],
        "G": [],
    }
    cycles, visited, active = [], set(), []
    def dfs(node):
        if node in active:
            i = active.index(node)
            cycles.append(active[i:] + [node])
            return
        if node in visited:
            return
        active.append(node)
        for nxt in graph.get(node, []):
            dfs(nxt)
        active.pop()
        visited.add(node)
    for node in graph:
        dfs(node)
    return cycles

def main():
    out = {
        "gate": "G-ROOT-A2",
        "measured_absolute_scale_used": False,
        "relaxation_orbit_max_relative_error": relaxation_orbit_test(),
        "rigidity_potential": rigidity_potential_orbit_test(),
        "quartic_only": {
            "positive_quartic_stable_minimum": 0.0,
            "positive_quartic_generates_nonzero_scale": False,
            "negative_quartic_stable": False
        },
        "spectral_gap": spectral_gap_orbit_test(),
        "transmutation_orbit_max_relative_error": transmutation_orbit_test(),
        "memory_rate_classification": {
            "root_frequency": "circular",
            "particle_frequency": "species-dependent and circular",
            "cosmological_H": "epoch/environment dependent",
            "independent_universal_rate": "new primitive unless independently derived",
            "dimensionless_per_cycle_rate": "cannot set an absolute scale"
        },
        "dependency_cycles": cycle_test(),
        "native_scale_breaker_found": False,
        "conclusion": "The current Phi_relax/H_settle program determines relative structure but not the common absolute root scale."
    }
    RESULTS.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
