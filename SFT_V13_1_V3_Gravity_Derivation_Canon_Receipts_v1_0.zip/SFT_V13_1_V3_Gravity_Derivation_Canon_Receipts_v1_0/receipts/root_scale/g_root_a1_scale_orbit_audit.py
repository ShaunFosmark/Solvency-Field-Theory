#!/usr/bin/env python3
"""
G-ROOT-A1 reproducibility script.

Purpose
-------
1. Reproduce the dimensional no-go for an area from c, hbar, and
   dimensionless constants.
2. Verify the one-parameter root-scale symmetry of the frozen SFT
   gravity and particle relations.
3. Demonstrate why a species mass anchor is not universal.
4. Detect the circular dependency produced by using an absolute mass
   that is itself set by A_write to derive A_write.
5. Write a machine-readable result file.

No measured value of G, Planck length, particle mass, H0, or any other
absolute empirical scale is used.
"""

from __future__ import annotations

import json
import math
import random
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "g_root_a1_results.json"


def dims_mul(coeffs, vectors):
    """Return M,L,T dimension vector for a monomial."""
    return tuple(
        sum(c * v[i] for c, v in zip(coeffs, vectors))
        for i in range(3)
    )


def solve_two_primitives_for_area():
    """
    Test whether c^a hbar^b can have dimensions of area.

    c:     M^0 L^1 T^-1
    hbar:  M^1 L^2 T^-1
    area:  M^0 L^2 T^0
    """
    # From mass: b=0. From time: -a-b=0 -> a=0.
    # Then length exponent is zero, not two.
    return {
        "solution_exists": False,
        "reason": "Mass neutrality forces b=0; time neutrality then forces a=0; length exponent is 0, not 2.",
    }


def root_scale_transform(x, lam):
    """
    Root-scale weights under ell_* -> lam ell_*.

    a_phi,G,A0,area: +2
    length,time: +1
    mass,energy,H,frequency,acceleration: -1
    dimensionless,count,capacity: 0
    density: -4
    force_or_tension: -2
    """
    weights = {
        "a_phi": 2,
        "G": 2,
        "A0": 2,
        "area": 2,
        "length": 1,
        "time": 1,
        "mass": -1,
        "energy": -1,
        "H": -1,
        "frequency": -1,
        "acceleration": -1,
        "dimensionless": 0,
        "count": 0,
        "capacity": 0,
        "density": -4,
        "force_or_tension": -2,
    }
    return x * lam ** weights


def invariant_regression(trials=5000, seed=7142026):
    rng = random.Random(seed)
    max_err = {
        "C_A": 0.0,
        "newton_compactness": 0.0,
        "compton_length_covariance": 0.0,
        "horizon_compton_ratio": 0.0,
        "capacity_ratio": 0.0,
        "mass_ratio": 0.0,
        "Ht": 0.0,
    }

    # Work in arbitrary consistent units with c=hbar=1.
    c = 1.0
    hbar = 1.0

    for _ in range(trials):
        lam = 10 ** rng.uniform(-6, 6)
        a = 10 ** rng.uniform(-6, 6)
        E = 10 ** rng.uniform(-6, 6)
        r = 10 ** rng.uniform(-6, 6)
        M = 10 ** rng.uniform(-6, 6)
        m1 = 10 ** rng.uniform(-6, 6)
        m2 = 10 ** rng.uniform(-6, 6)
        A_b = 10 ** rng.uniform(-6, 6)
        eta = rng.uniform(0.05, 0.95)
        H = 10 ** rng.uniform(-6, 6)
        t = 10 ** rng.uniform(-6, 6)

        G = a * c**3 / hbar

        CA = a * E / (hbar * c * r)
        comp = G * M / (c**2 * r)
        lc = hbar / (m1 * c)
        rs = 2 * G * M / c**2
        cap = eta * A_b / a
        mr = m1 / m2
        ht = H * t

        a2 = a * lam**2
        G2 = G * lam**2
        E2 = E / lam
        r2 = r * lam
        M2 = M / lam
        m12 = m1 / lam
        m22 = m2 / lam
        A_b2 = A_b * lam**2
        H2 = H / lam
        t2 = t * lam

        CA2 = a2 * E2 / (hbar * c * r2)
        comp2 = G2 * M2 / (c**2 * r2)
        lc2 = hbar / (m12 * c)
        rs2 = 2 * G2 * M2 / c**2
        cap2 = eta * A_b2 / a2
        mr2 = m12 / m22
        ht2 = H2 * t2

        def rel(a_, b_):
            return abs(a_ - b_) / max(1.0, abs(a_), abs(b_))

        max_err["C_A"] = max(max_err["C_A"], rel(CA, CA2))
        max_err["newton_compactness"] = max(max_err["newton_compactness"], rel(comp, comp2))
        max_err["compton_length_covariance"] = max(max_err["compton_length_covariance"], rel(lc2, lam * lc))
        max_err["horizon_compton_ratio"] = max(max_err["horizon_compton_ratio"], rel(rs / lc, rs2 / lc2))
        max_err["capacity_ratio"] = max(max_err["capacity_ratio"], rel(cap, cap2))
        max_err["mass_ratio"] = max(max_err["mass_ratio"], rel(mr, mr2))
        max_err["Ht"] = max(max_err["Ht"], rel(ht, ht2))

    return max_err


def species_anchor_test():
    # Arbitrary masses; constants cancel. A(m) ∝ 1/m^2.
    masses = [1.0, 2.0, 10.0, 100.0]
    areas = [1.0 / (m*m) for m in masses]
    return {
        "arbitrary_masses": masses,
        "relative_compton_areas": areas,
        "max_to_min_area_ratio": max(areas) / min(areas),
        "universal": len(set(round(x, 14) for x in areas)) == 1,
    }


def dependency_cycle_test():
    # Frozen direction: A_write -> Phi_relax -> absolute mass.
    # Candidate inversion: absolute mass -> A_write.
    graph = {
        "A_write": ["G", "Phi_relax"],
        "Phi_relax": ["absolute_mass"],
        "absolute_mass": ["A_write"],
        "G": [],
    }

    seen = set()
    stack = []
    cycles = []

    def dfs(node):
        if node in stack:
            idx = stack.index(node)
            cycles.append(stack[idx:] + [node])
            return
        if node in seen:
            return
        stack.append(node)
        for nxt in graph.get(node, []):
            dfs(nxt)
        stack.pop()
        seen.add(node)

    for node in graph:
        dfs(node)
    return cycles


def main():
    dim = solve_two_primitives_for_area()
    inv = invariant_regression()
    species = species_anchor_test()
    cycles = dependency_cycle_test()

    result = {
        "gate": "G-ROOT-A1",
        "measured_G_used": False,
        "dimensional_no_go": dim,
        "scale_orbit_regression_max_relative_errors": inv,
        "scale_orbit_pass": max(inv.values()) < 1e-12,
        "species_anchor_test": species,
        "mass_to_Awrite_cycle": cycles,
        "conclusion": (
            "The frozen scale-free primitive set and dimensionless SFT structure do not identify "
            "the absolute root scale. A_write is a one-parameter normalization modulus unless a "
            "new native scale-breaking equation, boundary condition, or explicit empirical anchor is supplied."
        ),
    }
    OUT.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
