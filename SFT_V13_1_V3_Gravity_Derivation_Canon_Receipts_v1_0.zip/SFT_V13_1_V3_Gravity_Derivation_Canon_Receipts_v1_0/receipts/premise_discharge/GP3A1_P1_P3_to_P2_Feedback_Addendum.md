# P1/P3 Feedback into P2 — G-P3A1 Addendum

The feedback result is conditional but exact:

\[
\text{Exact P2 naturality}
+
\text{equivariant compression}
+
\text{P3 sufficient-state factorization}
\Longrightarrow
\text{local continuum P2 naturality}.
\]

This means P3 is not merely downstream of P2. Once P3 closes, it feeds back and compresses P2: the naturality of the local continuum law follows from the exact write law instead of being postulated independently.

P1 strengthens that feedback by eliminating any legitimate external history argument. The only remaining obstruction is whether the proposed local state actually captures all exact information that can affect future local writes.

Current verdict:

```text
PASS feedback theorem
FAIL unconditional upgrade because P3 factorization is not yet earned
```
