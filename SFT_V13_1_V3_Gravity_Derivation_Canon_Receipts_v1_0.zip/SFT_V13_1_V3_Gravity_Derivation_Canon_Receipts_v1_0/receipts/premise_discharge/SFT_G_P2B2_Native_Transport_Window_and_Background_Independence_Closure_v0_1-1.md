# Solvency Field Theory
## G-P2B2 — Native Transport, Window, and Background-Independence Closure v0.1

Generated: 2026-07-22 01:11:35

```text
G_P2B2_VERDICT =
PASS_UPSTREAM_G_P_TWO_B_ONE_G_P_TWO_A_TWO_G_P_TWO_A_ONE_AND_G_P_TWO_A_ZERO_HASH_FREEZE;
PASS_PHYSICAL_STATE_QUOTIENT_AND_DESCENT_THEOREM;
AN_SFT_UPDATE_IS_A_WELL_DEFINED_PHYSICAL_LAW_ONLY_IF_IT_MAPS_ISOMORPHIC_RELABELINGS_TO_ISOMORPHIC_OUTPUTS;
NON_NATURAL_LABEL_COORDINATE_FRAME_PHASE_OR_BACKGROUND_DEPENDENT_KERNELS_DO_NOT_DESCEND_TO_THE_PHYSICAL_STATE_SPACE_AND_ARE_NOT_ADMISSIBLE_SFT_COMPLETIONS;
PASS_TENSOR_VALUED_DISTRIBUTIONAL_CONTINUUM_AS_THE_FUNDAMENTAL_P_TWO_BRIDGE;
EXACT_SETTLEMENT_AND_SOURCE_RECORDS_PAIR_WITH_TEST_TENSORS_IN_THE_SAME_FIBER_AND_REQUIRE_NO_INTER_EVENT_PARALLEL_TRANSPORT_OR_SMOOTHING_WINDOW;
PASS_WINDOW_NONUNIQUENESS_NO_GO;
COVARIANCE_LOCALITY_POSITIVITY_NORMALIZATION_ISOTROPY_COMPACT_SUPPORT_AND_APPROXIMATE_IDENTITY_CONVERGENCE_DO_NOT_SELECT_A_UNIQUE_WINDOW;
FAIL_UNIQUE_NATIVE_WINDOW_DERIVATION;
PASS_RECLASSIFICATION_OF_THE_WINDOW_AS_A_DERIVED_REGULATOR_OR_OPERATIONAL_READOUT_NOT_A_FUNDAMENTAL_P_TWO_OBJECT;
PASS_CONDITIONAL_LEVI_CIVITA_TRANSPORT_UNIQUENESS;
GIVEN_THE_CURRENT_DYNAMIC_METRIC_METRIC_COMPATIBILITY_ZERO_TORSION_AND_NO_INDEPENDENT_CONNECTION_THE_CONNECTION_IS_UNIQUE;
FAIL_MICROSCOPIC_DERIVATION_OF_METRIC_COMPATIBILITY_AND_ZERO_TORSION_AT_THIS_GATE;
LEVI_CIVITA_TRANSPORT_MAY_SUPPORT_A_DERIVED_SMOOTH_READOUT_BUT_MAY_NOT_BE_USED_CIRCULARLY_AS_THE_MICROSCOPIC_PROOF_OF_P_TWO;
PASS_DYNAMIC_METRIC_NOT_BACKGROUND_FIREWALL;
PASS_MULTIPATH_HOLONOMY_RECLASSIFICATION;
GLOBAL_OR_DISCRETE_PATH_DEPENDENCE_IS_PHYSICAL_ORDER_AND_CURVATURE_INFORMATION_AND_IS_DEFERRED_TO_P_ONE_AND_THE_BCH_SELF_INTERACTION_GATE;
PASS_P_TWO_STRUCTURAL_SYMMETRY_CONTRACT_FREEZE;
ANY_FUTURE_K_SET_GAMMA_SETTLE_H_SETTLE_V_COMPOUND_OR_RELAXATION_KERNEL_MUST_PASS_THE_FROZEN_DESCENT_NATURALITY_ACCEPTANCE_CONTRACT;
FAIL_ACTUAL_OPEN_KERNEL_FUNCTIONAL_DERIVATION;
THIS_IS_A_DYNAMICS_AND_EXISTENCE_DEBT_NOT_A_REMAINING_LICENSE_FOR_NONCOVARIANT_COMPLETIONS;
PASS_P_TWO_AS_AN_INPUT_SYMMETRY_CONTRACT_FOR_P_ONE_AND_P_THREE;
P_TWO_NO_LONGER_BLOCKS_THE_COMPOSITION_PROGRAM;
G_P_ONE_A_ONE_SINGLE_WRITE_SEMIGROUP_AND_NO_EXTERNAL_MEMORY_COMPOSITION_GATE_READY
```

## 1. Gate question

G-P2B1 proved a natural class of continuum maps but left an apparent debt: which transport and smoothing window does the ledger uniquely select?

This gate finds that the question mixed fundamental physics with finite-resolution readout machinery. The exact continuum representation is distributional and needs neither a smoothing window nor transport between separate events. Smooth fields require both, but covariance does not select a unique profile.

## 2. Address covariance as a descent theorem

The physical state is an isomorphism class

\[
[\mathscr S]=\{{\mathscr S'\mid \mathscr S'\cong\mathscr S}}\}.
\]

A labeled update defines a physical map only when it descends to those classes:

\[
\mathscr S'\cong\mathscr S
\Longrightarrow
\widetilde{{\mathfrak W}}(\mathscr S')\cong\widetilde{{\mathfrak W}}(\mathscr S).
\]

The stronger event naturality square is

\[
f^+_*\mathfrak W_\epsilon(\mathscr S)
=
\mathfrak W_{{f_*\epsilon}}(f_*\mathscr S).
\]

Without this property, the update is not a function on physical SFT states. Coordinate, label, raw-component, raw-phase, or fixed-background dependence is therefore not an alternative completion. It fails to define an SFT law.

## 3. Fundamental continuum without smoothing

Settlement and active source can be represented as tensor-valued measures

\[
\boldsymbol\mu_\Sigma=\sum_e s_e\,\delta_{{r(e)}},
\qquad
\boldsymbol\mu_W=\sum_e w_e\,\delta_{{r(e)}}.
\]

For a compactly supported test tensor \(F\),

\[
\langle\boldsymbol\mu_\Sigma,F\rangle
=
\sum_e s_e:F(r(e)).
\]

Each contraction occurs within one tangent-space fiber. No tensor at one event is directly added to a tensor at another event. Consequently, the fundamental distributional continuum requires no inter-event parallel transport and no smoothing window.

The release verifies this pairing under 500 random basis transformations.

## 4. Unique-window no-go theorem

A covariant radial family may be written

\[
K_{{\ell,\psi}}(x,y)
=
\ell^{{-4}}\psi\!\left(\frac{{\sigma(x,y)}}{{\ell^2}}\right),
\]

where \(\sigma\) is a geometric biscalar. Infinitely many positive, normalized, local and isotropic profiles \(\psi\) exist.

For

\[
K_q(r/\ell)=e^{{-(r/\ell)^q}},
\]

the normalized second radial moment in four dimensions is

\[
\langle r^2\rangle_q
=
\ell^2\frac{{\Gamma(6/q)}}{{\Gamma(4/q)}}.
\]

Thus

\[
q=1:\ \langle r^2\rangle=20\ell^2,
\qquad
q=2:\ \langle r^2\rangle=2\ell^2.
\]

A uniform geodesic four-ball gives

\[
\langle r^2\rangle=\frac23\ell^2.
\]

All are natural and differ at finite resolution. All can converge to the same smooth field as \(\ell\to0\).

Therefore covariance, locality, positivity, normalization, isotropy, compact support and approximate-identity convergence do not select one profile.

\[
\boxed{{\text{{A unique smoothing window is not derivable from P2.}}}}
\]

This is not a covariance failure. A window is an operational resolution choice or a regulator that must disappear from exact claims.

## 5. Transport and conditional Levi-Civita uniqueness

The exact distribution requires no transport. A finite smooth average does.

If the current metric is supplied and the connection is metric-compatible, torsion-free and not an independent state, the transport is uniquely Levi-Civita.

Let \(C^a{}_{{bc}}\) be the difference between two such connections. Torsion freedom makes the lower pair symmetric. Metric compatibility gives

\[
C^d{}_{{ab}}g_{{dc}}+C^d{}_{{ac}}g_{{bd}}=0.
\]

In four dimensions there are forty independent torsion-free difference components. The release builds the forty linear compatibility equations and finds rank forty, forcing

\[
C^a{}_{{bc}}=0.
\]

This is conditional. The gate does not claim that microscopic SFT has already derived zero torsion and metric compatibility.

## 6. Avoiding a P2/P3 circle

Using metric-only closure to select Levi-Civita transport and then using that transport to prove P2 would be circular, because metric-only closure is part of P3.

The route here avoids the circle:

- exact P2 is relational and distributional;
- no connection is needed for the proof;
- Levi-Civita is only an optional smooth-readout branch;
- torsion and nonmetricity remain explicit downstream questions.

## 7. Dynamic geometry versus background

The current pre-write metric \(g_n\) is retained physical state. It transforms with the entire state under an active diffeomorphism.

The release tests 500 generic transformations. Transforming \(g_n\) with the vectors preserves intervals. Holding a fixed reference metric unchanged fails generically.

Thus

\[
\boxed{{g_n\text{{ is dynamical state, not an external background.}}}}
\]

This supports the noncircular inductive readout branch

\[
g_n\rightarrow\text{{smoothed next increment}}\rightarrow g_{{n+1}}.
\]

## 8. Paths, holonomy and BCH

Within a convex normal neighborhood, sufficiently close points have a unique geodesic and a local smooth readout has no path ambiguity.

At larger scales, distinct paths may produce distinct transport. That difference is holonomy. In the ledger, distinct ordered paths may similarly differ through noncommuting products and BCH commutators.

This is physical order and curvature information, not a coordinate defect. The multipath problem therefore belongs to P1 and the BCH self-interaction gate.

A label-selected path is forbidden. An average over paths requires a separately derived physical weight.

## 9. Frozen open-kernel acceptance contract

The forms of \(K_{{\rm set}}\), \(\Gamma_{{\rm settle}}\), \(H_{{\rm settle}}\), \(V_{{\rm compound}}\) and \(\Phi_{{\rm relax}}\) remain open.

Their covariance class is now fixed. Every candidate must obey

\[
K[f_*\mathscr S,f_*\epsilon]=f_*K[\mathscr S,\epsilon].
\]

Allowed ingredients include relational incidence, tensor products and contractions, exterior algebra, gauge-invariant winding and holonomy, natural integration, dynamical geometry transformed with the state, and path-ordered products along physical ledger paths.

Forbidden ingredients include coordinate names, fixed component axes, raw phase origins, untransformed backgrounds, presentation order and external memory not retained in the physical state.

A violating kernel is rejected before empirical testing.

## 10. Updated P2 status

P2 entered G-COV-5 as the premise of full nonlinear write-address covariance.

The audit now separates symmetry from dynamics.

**Structural P2 passes.** The state is defined modulo relabeling, the frozen event layer descends, the distributional continuum is natural, the metric map is tensor-natural, and the Einstein-form equation passed a finite-diffeomorphism regression.

**Dynamic kernel forms remain open.** Their existence and numerical form are separate microscopic dynamics debts, but they are not allowed to violate the frozen symmetry contract.

The receipt-safe status is

\[
\boxed{{\text{{P2 is frozen as a structural symmetry theorem and acceptance contract; open kernel forms remain dynamics.}}}}
\]

This is sufficient to supply P2 as an input to P1 and later P3.

## 11. Next gate

\[
\boxed{{\text{{G-P1A1 — Single-Write Semigroup and No-External-Memory Composition}}}}
\]

The next kill question is whether the current physical state contains everything required to compose the next write, or whether the update secretly depends on an external history register.
