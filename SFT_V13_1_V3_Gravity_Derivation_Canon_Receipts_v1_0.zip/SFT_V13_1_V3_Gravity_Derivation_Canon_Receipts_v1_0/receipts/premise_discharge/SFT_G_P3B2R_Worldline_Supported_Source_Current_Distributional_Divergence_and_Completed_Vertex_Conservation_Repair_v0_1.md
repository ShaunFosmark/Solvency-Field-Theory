# Solvency Field Theory
## G-P3B2R — Worldline-Supported Source Current, Distributional Divergence, and Completed-Vertex Conservation Repair v0.1

Generated: 2026-07-21 (America/Los_Angeles)

```text
G_P3B2R_VERDICT =
PASS_UPSTREAM_G_P3B1_AND_G_P3B2_SOURCE_REVIEW;
FAIL_THE_ORIGINAL_POINT_SUPPORTED_SOURCE_ATOM_CONSERVATION_STEP;
FOUR_MOMENTUM_VERTEX_CLOSURE_DOES_NOT_BY_ITSELF_IMPLY_THAT_A_RANK_TWO_COEFFICIENT_MULTIPLIED_BY_A_POINT_DELTA_HAS_ZERO_DISTRIBUTIONAL_DIVERGENCE;
PASS_ORIENTED_EDGE_AND_WORLDLINE_SUPPORTED_MOMENTUM_CURRENT_CONSTRUCTION;
PASS_EXACT_DISTRIBUTIONAL_DIVERGENCE_FORMULA_WITH_ENDPOINT_AND_BULK_FORCE_TERMS;
PASS_COMPLETED_VERTEX_INTERIOR_DEFECT_CANCELLATION;
PASS_OPEN_FRONTIER_FIREWALL;
A_COMPLETED_LOCAL_VERTEX_REMOVES_THE_INTERIOR_DELTA_DEFECT_BUT_DOES_NOT_ERASE_THE_BOUNDARY_OR_ACTIVE_FRONTIER_CURRENT;
PASS_CONSERVED_TOTAL_SOURCE_INCREMENT_CONSTRUCTION;
THE_GRAVITY_KERNEL_MUST_CONSUME_A_BOUNDARY_COMPLETE_CONSERVED_SOURCE_CURRENT_INCREMENT_OR_AN_EQUIVALENT_CURRENT_PLUS_FRONTIER_PAIR;
PASS_SYMMETRY_FIREWALL;
A_CANONICAL_MOMENTUM_CURRENT_IS_NOT_MADE_SIMULTANEOUSLY_SYMMETRIC_AND_CONSERVED_BY_NAIVE_POINTWISE_SYMMETRIZATION;
THE_SOURCE_SECTOR_MUST_SUPPLY_A_SYMMETRIC_CONSERVED_COMPLETED_SOURCE_OR_EARN_SYMMETRY_FROM_COLLINEAR_CARRIER_MOMENTUM_AND_TANGENT_OR_FROM_THE_FROZEN_ANGULAR_MOMENTUM_CLOSURE;
PASS_REVISED_SINGLE_WRITE_GRAVITY_INTERFACE;
PASS_REVISED_FIBER_CONSTANCY_FOR_THE_SELECTED_GRAVITY_KERNEL;
PASS_EVENT_LEVEL_CONSTRAINT_COMPATIBILITY_FOR_A_CONSERVED_TOTAL_SOURCE_INCREMENT;
PASS_LOCAL_P_TWO_NATURALITY_FOR_THE_EDGE_CURRENT_AND_REVISED_KERNEL_INTERFACE;
PASS_P_THREE_DISCHARGE_PRESERVED_FOR_THE_SELECTED_GRAVITY_KERNEL_AFTER_SOURCE_INTERFACE_REPAIR;
THE_DISCHARGE_REMAINS_MODULAR_AND_DOES_NOT_DERIVE_THE_SOURCE_SECTOR_COMPOUNDING_LAWS_OR_A_UNIQUE_ATOMIC_GRAVITY_KERNEL;
FAIL_UNIQUE_MICROSCOPIC_SOURCE_COMPLETION_LAW;
FAIL_UNCONDITIONAL_NONLINEAR_GREEN_OPERATOR_IDENTIFICATION;
FAIL_NUMERICAL_G_AND_ABSOLUTE_WRITE_AREA;
PASS_G_P3B2R_REPAIR;
THE_POINT_ATOM_FORMULA_AND_EVENTWISE_POINT_ATOM_CONSERVATION_CLAIM_IN_G_P3B2_ARE_SUPERSEDED_BY_THIS_RELEASE;
G_CLOSE_ONE_MAY_PROCEED_ONLY_WITH_THE_REVISED_SOURCE_CURRENT_LANGUAGE.
```

## 1. Gate question

G-P3B2 defined a completed event source by

\[
\left\langle
\Delta\boldsymbol\mu_{W,e},f
\right\rangle
=
\Pi_{\rm Adm}
\sum_{\ell\in e}
\Delta P_\ell^{(\nu}n_\ell^{\mu)}
 f_{\mu\nu}(x_e),
\]

and inferred from

\[
\sum_{\ell\in e}\Delta P_\ell^\nu=0
\]

that

\[
\nabla_\mu\Delta\boldsymbol\mu_{W,e}^{\mu\nu}=0.
\]

The question is whether that implication is valid, and if not, whether the source construction can be repaired without reopening the selected P3 gravity branch.

The answer is:

\[
\boxed{
\text{the point-atom implication fails, but the edge/current construction repairs it.}
}
\]

The repair preserves the selected gravity-kernel fiber-constancy result, with a more exact source interface.

## 2. Why the point-supported atom does not pass

Let

\[
T^{\mu\nu}=A^{\mu\nu}\delta_x
\]

with constant tensor coefficient \(A^{\mu\nu}\) at the support point. For a compactly supported test covector \(\xi_\nu\), the distributional divergence is defined by

\[
\left\langle
\nabla_\mu T^{\mu\nu},\xi_\nu
\right\rangle
=
-
\left\langle
T^{\mu\nu},\nabla_\mu\xi_\nu
\right\rangle.
\]

Therefore

\[
\boxed{
\left\langle
\nabla_\mu T^{\mu\nu},\xi_\nu
\right\rangle
=
-A^{\mu\nu}\nabla_\mu\xi_\nu(x).
}
\]

This is not zero for arbitrary test fields unless the source coefficient is trivial or additional derivative-supported terms cancel it.

The condition

\[
\sum_\ell \Delta P_\ell^\nu=0
\]

constrains a vector sum. It does not force

\[
A^{\mu\nu}
=
\sum_\ell
\Delta P_\ell^{(\nu}n_\ell^{\mu)}
\]

to vanish, and it does not remove the derivative of the delta distribution.

The constructive hostile test used three momenta satisfying exact vector closure and independent support normals. It then chose a test-field gradient equal to the resulting \(A^{\mu\nu}\). In all 1,000 trials:

```text
momentum-balance maximum norm: 0
nonzero point-atom divergence pairings: 1000 / 1000
minimum absolute divergence pairing: 1.3978869783478443
```

Thus the original implication is rejected.

## 3. The correct native object: an oriented momentum current

Let an oriented carrier edge or worldline segment \(\ell\) be represented by a smooth causal curve

\[
z_\ell:[a_\ell,b_\ell]\rightarrow M
\]

with tangent \(u_\ell^\mu=dz_\ell^\mu/d\lambda\) and transported four-momentum \(p_\ell^\nu(\lambda)\).

Define the momentum-valued current by its action on a test tensor:

\[
\boxed{
\left\langle
J_\ell^{\mu\nu},f_{\mu\nu}
\right\rangle
=
\int_{a_\ell}^{b_\ell}
 u_\ell^\mu p_\ell^\nu
 f_{\mu\nu}(z_\ell(\lambda))\,d\lambda.
}
\]

Equivalently, the first index is the directed support current and the second is the four-momentum transported by that current.

For a test covector \(\xi_\nu\), integration by parts along the curve gives

\[
\begin{aligned}
\left\langle
\nabla_\mu J_\ell^{\mu\nu},\xi_\nu
\right\rangle
&=
-\int_{a_\ell}^{b_\ell}
 p_\ell^\nu
 \frac{D\xi_\nu}{d\lambda}
 \,d\lambda\\[3pt]
&=
 p_\ell^\nu(a_\ell)\xi_\nu(z_\ell(a_\ell))
-
 p_\ell^\nu(b_\ell)\xi_\nu(z_\ell(b_\ell))
+
\int_{a_\ell}^{b_\ell}
 \frac{Dp_\ell^\nu}{d\lambda}
 \xi_\nu(z_\ell(\lambda))\,d\lambda.
\end{aligned}
\]

Hence the exact distributional source law is

\[
\boxed{
\nabla_\mu J_\ell^{\mu\nu}
=
p_\ell^\nu(a_\ell)\delta_{v_-}
-
p_\ell^\nu(b_\ell)\delta_{v_+}
+
F_\ell^\nu,
}
\]

where \(F_\ell^\nu\) is the bulk force/exchange term associated with \(Dp_\ell^\nu/d\lambda\).

The 1,000-trial integration-by-parts regression passed with maximum error

```text
3.552713678800501e-15
```

for both constant-momentum and varying-momentum edges with the bulk term retained.

## 4. Completed vertices cancel interior defects

For a source graph \(\Gamma\), sum the edge currents:

\[
J_\Gamma^{\mu\nu}=\sum_{\ell\in\Gamma}J_\ell^{\mu\nu}.
\]

At a vertex \(v\), define the signed momentum defect

\[
\boxed{
\mathcal V_v^\nu
=
\sum_{\ell\in{\rm Out}(v)}p_{\ell,v}^\nu
-
\sum_{\ell\in{\rm In}(v)}p_{\ell,v}^\nu.
}
\]

The distributional divergence becomes

\[
\boxed{
\nabla_\mu J_\Gamma^{\mu\nu}
=
\sum_{v\in\Gamma}\mathcal V_v^\nu\delta_v
+
F_{\rm bulk}^\nu.
}
\]

A completed legal vertex satisfies

\[
\mathcal V_v^\nu=0.
\]

Thus the vertex produces no interior delta defect.

This is the correct form of the event-level momentum-closure theorem.

The constructive vertex test used two incoming and three outgoing edges with exact four-vector balance. Across 1,000 trials:

```text
maximum internal vertex defect: 1.005373653455784e-15
```

The vertex closure passed.

## 5. The frontier cannot be erased

A local star containing a completed vertex normally has open incoming and outgoing support at the edge of the chosen neighborhood. Those frontier endpoints remain in the current boundary.

Therefore

\[
\boxed{
\text{completed vertex closure}
\neq
\text{isolated local-star divergence-free current}.
}
\]

The correct statement is

\[
\boxed{
\nabla_\mu J_{\Gamma_e}^{\mu\nu}
=
Q_{e,{\rm in}}^\nu
-
Q_{e,{\rm out}}^\nu
+
F_{e,{\rm bulk}}^\nu,
}
\]

where the frontier terms are part of the active carrier/boundary state.

In the hostile test, every completed internal vertex had zero defect while the open frontier remained nonzero:

```text
minimum open-frontier defect norm: 1.0141101006154183
```

This is not a failure. It is the physical statement that momentum has entered and exited the local neighborhood.

Any source construction that deletes those terms is incomplete.

## 6. The conserved gravity input

The selected gravity kernel must not consume an isolated point event. It must consume a complete source update.

Let

\[
W_n^{\mu\nu}
\]

be the complete conserved source current associated with the selected pre-write state, including the active carrier/frontier contribution required by the local continuity law.

A legal write produces

\[
W_{n+1}^{\mu\nu}
=
W_n^{\mu\nu}
+
\Delta W_e^{\mu\nu}.
\]

The source-sector legality contract is

\[
\boxed{
\nabla_\mu W_n^{\mu\nu}=0,
\qquad
\nabla_\mu W_{n+1}^{\mu\nu}=0.
}
\]

Therefore

\[
\boxed{
\nabla_\mu\Delta W_e^{\mu\nu}=0.
}
\]

The same statement may be expressed locally as a current-plus-frontier equation, but the gravity operator must receive the complete conserved combination.

The constructive refinement test compared a conserved edge current with the same current after a legal local vertex insertion. Both complete currents and their difference had exactly zero incidence defect in all 1,000 trials.

This gives the revised source chain:

\[
\boxed{
\text{completed source-sector write}
\rightarrow
\text{boundary-complete conserved current increment}
\rightarrow
\text{gravity response}.
}
\]

## 7. Symmetry is a separate source-sector condition

The edge momentum current

\[
J^{\mu\nu}=u^\mu p^\nu
\]

is symmetric when the transported momentum is collinear with the carrier tangent, as in the standard locally real point-carrier branch:

\[
p^\mu=\mathcal E u^\mu.
\]

Then

\[
J^{\mu\nu}=\mathcal E u^\mu u^\nu.
\]

The audit confirmed symmetry to numerical precision for 1,000 collinear trials.

For a generic independent \(p^\mu\) and \(u^\mu\), the canonical current is not symmetric.

Therefore the source sector must not obtain the gravitational source by merely replacing

\[
J^{\mu\nu}
\]

with

\[
J^{(\mu\nu)}
\]

after the fact. Naive symmetrization does not automatically preserve the divergence theorem.

The accepted source interface is:

\[
\boxed{
\Delta W_e^{\mu\nu}
\text{ is both symmetric and conserved by the completed source-sector law.}
}
\]

That may be earned directly from collinear carrier momentum/tangent structure or from the frozen completed angular-momentum closure. If internal spin or stress requires an improvement term, that term must be included in the source-sector construction and audited; gravity does not manufacture it.

## 8. Revised event descriptor

The P3B2 event descriptor is repaired from a point source atom to a complete source-current update:

\[
\boxed{
\eta_e^{R}
=
\left[
U_e,
\Gamma_e^{\rm inc/out},
\{z_\ell,p_\ell,\epsilon_{v\ell}\},
\Delta W_e^{\mu\nu},
\Pi_{\rm Adm},
\mathcal R_{\rm cap},
\mathcal C_{e,{\rm active}},
B
\right].
}
\]

The descriptor retains:

```text
physical support incidence and orientation
incident and outgoing carrier-current data
completed vertex balance
active frontier update
symmetric conserved total source increment
admissibility and compactness route
current source-sector invariants
physical boundary class
```

It excludes private names and inaccessible ancestry.

The descriptor may be compressed further only after the source sector proves that the smaller representation determines the same conserved current increment.

## 9. Revised selected gravity kernel

The selected gravity branch now reads

\[
\boxed{
\Delta\Sigma_e
=
\kappa_\Sigma
G^{\rm ret}_{g,B}
\star
\Delta W_e,
\qquad
\nabla_\mu\Delta W_e^{\mu\nu}=0,
}
\]

followed by

\[
\Sigma^+=\Sigma+\Delta\Sigma_e
\]

and the frozen natural metric update

\[
S=g^{-1}\Delta\Sigma_e,
\qquad
E=e^S,
\qquad
g^+=E^TgE.
\]

This formula is receipt-safe in the selected linearized or local tangent-response branch at the current geometry.

For the nonlinear iterative branch, the stronger wording is

\[
\boxed{
\Sigma^+
=
\mathcal R_{g,B}[W+\Delta W_e],
\qquad
\Delta\Sigma_e
=
\Sigma^+-\Sigma,
}
\]

where \(\mathcal R_{g,B}\) is the selected causal response map.

The linear Green-operator expression is then the local response representation of that map. This release does not claim that a single convolution is the unique exact nonlinear atomic gravity law.

## 10. Fiber constancy after repair

Let two exact states and events satisfy

\[
C(S_1)=C(S_2)=Y
\]

and

\[
C_e^R(e_1)=C_e^R(e_2)=\eta^R.
\]

The revised event descriptor determines the same:

```text
source-current topology and incidence
completed vertex balances
frontier update
conserved symmetric total source increment
boundary class
compactness route
```

Therefore the selected response map produces the same settlement increment and the same compressed future:

\[
\boxed{
C(F_{e_1}(S_1))
=
C(F_{e_2}(S_2)).
}
\]

The P3 fiber-constancy theorem is preserved.

The content of the theorem is now properly modular:

> Once the source sector supplies the same certified conserved symmetric source-current increment, private source ancestry cannot alter the gravity response.

The theorem does not derive the source-sector compounding law that generates that increment.

## 11. Constraint preservation after repair

For the selected linear carrier equation, the constraint propagation equation has the form

\[
\Box C_\nu
=
\kappa_\Sigma
\nabla^\mu\Delta W_{e,\mu\nu}.
\]

The revised source interface gives

\[
\nabla^\mu\Delta W_{e,\mu\nu}=0.
\]

Hence zero initial constraint data remain zero.

The statement is now stronger and narrower than the original P3B2 wording:

```text
completed vertex balance:
    removes the interior vertex defect

complete source-current update:
    includes frontier and bulk-exchange bookkeeping

conserved total increment:
    supplies the source required by the carrier constraint
```

An incomplete star or a point-supported atom is not admitted to the Green operator as though it were a conserved source.

For the nonlinear candidate branch, the usual Bianchi/tangency argument remains conditional on the selected field equation and the same conserved total source.

## 12. P2 naturality after repair

The oriented edge current is defined geometrically from curves, momenta, incidence, and the current metric/bundle structure.

Under a physical relabeling \(f\),

\[
J_\Gamma
\mapsto
f_*J_\Gamma,
\qquad
\nabla'\!\cdot(f_*J_\Gamma)
=
f_*(\nabla\!\cdot J_\Gamma).
\]

The constructive audit applied 1,000 random proper Lorentz transformations and 1,000 ledger relabelings:

```text
maximum Lorentz covariance error: 2.673771110915334e-15
maximum relabeling error: 0
```

Thus the repaired source interface remains natural.

With the natural retarded/causal response map and the frozen natural metric update, the local P2 corollary remains discharged for the selected gravity kernel.

## 13. P3 status after repair

The repair changes the source interface but does not add a gravitational state register.

The selected gravity state remains

\[
Y_\Sigma=
\left[
 h_{ij},K_{ij},
 \mathcal W_{\perp\perp},
 \mathcal W_{\perp i},
 \mathcal W_{ij},
 \mathcal C_{\rm matter,local}
\right]_{\rm constraints/gauge}
\]

with global topology and physical boundary metadata.

The source-sector output is now a certified boundary-complete current increment rather than a point atom.

Therefore:

\[
\boxed{
\text{P3 remains discharged for the selected modular gravity kernel.}
}
\]

The boundary is explicit:

```text
P3 discharge:
    the selected gravity state and certified source-current event descriptor
    determine the gravity future

not discharged here:
    the unique microscopic source-completion law
    all compounding and relaxation dynamics
    the unique exact nonlinear atomic gravity response
    numerical G
```

## 14. Supersession statement

The following G-P3B2 claims are superseded:

```text
“completed source atom” as a rank-2 coefficient times a point delta
vertex momentum closure directly implying zero divergence of that atom
isolated eventwise point-atom conservation
```

They are replaced by:

```text
oriented edge/worldline-supported momentum current
completed-vertex cancellation of the interior incidence defect
explicit active-frontier and bulk-exchange bookkeeping
boundary-complete conserved symmetric total source increment
```

All other P3B2 conclusions survive subject to this repaired interface and the pre-existing selected-kernel boundaries.

## 15. Constructive audit summary

```text
Point-atom counterexample:
    1000 / 1000 balanced-momentum trials produced nonzero divergence pairing

Edge integration-by-parts theorem:
    1000 / 1000 passed
    maximum error = 3.552713678800501e-15

Completed-vertex closure:
    1000 / 1000 passed
    maximum internal defect = 1.005373653455784e-15

Frontier firewall:
    1000 / 1000 retained nonzero boundary terms

Conserved local refinement increment:
    1000 / 1000 passed
    maximum increment defect = 0

Relabeling and Lorentz naturality:
    1000 / 1000 passed

Symmetry firewall:
    collinear p/u branch symmetric
    generic noncollinear branch not symmetric in 1000 / 1000 trials
```

## 16. Final receipt-safe statement

> **A legal SFT gravity event is not a conserved rank-two point atom. The native microscopic source is an oriented momentum current supported on the carrier edges or worldlines. Completed four-momentum closure removes the interior divergence defect at the interaction vertex, while the active frontier and any bulk exchange terms remain in the source ledger. The selected gravity kernel therefore consumes a boundary-complete symmetric conserved source-current increment. With that repaired interface, the selected kernel remains fiber-constant, constraint-compatible, and natural, so the P3 and local P2 gravity-sector discharge survive.**

## 17. Next step

No new gravity gate is opened here.

The program should stop and evaluate the complete premise ledger before G-CLOSE-1.
