# G-P3A3 Feedback Addendum
## P1/P3 compression of P2 after native branch selection

P3A3 selects the minimal regular gravity branch inside explicit boundaries:

```text
connection: zero-torsion metric branch
differential order: regular second-order branch
memory: current-state local memory-free branch
```

Exact P2 already gives naturality on the full write state. The sole missing step is the concrete factorization

\[
C\circ F_e=\bar F_e\circ C.
\]

When this is proven for the selected state, equivariance of \(C\) immediately yields

\[
\boxed{\bar F_{f_*e}f_Y=f_Y\bar F_e.}
\]

No fourth premise called local covariance after compression is allowed.

Current status:

```text
branch selection: PASS within explicit boundaries
concrete factorization: OPEN
actual local P2 corollary: READY, not triggered
```
