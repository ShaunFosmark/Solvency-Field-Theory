# SFT V13.1-V3 — G-COV-2C
## Independent Branch Convergence v0.1

Generated: 2026-07-20 20:16:24

```text
G_COV_2C_VERDICT =
PASS_BRANCH_ISOLATION_AND_HASH_FREEZE;
G_COV_2A_AND_G_COV_2B_WERE_CONSTRUCTED_WITHOUT_MECHANISM_TRANSFER;
STRONG_CONVERGENCE_ON_A_SYMMETRIC_CONSERVED_WRITE_MOMENTUM_FLUX_SOURCE_W_MUNU;
STRONG_CONVERGENCE_ON_NULL_SUPPORT_COMPATIBILITY_WITHOUT_PROPER_TIME;
STRONG_CONVERGENCE_ON_THE_V2_ACTIVE_DUST_TO_RADIATION_WEIGHT_ONE_TO_TWO;
BRANCH_A_DERIVES_THE_SOURCE_ONTOLOGY_AND_UNIQUE_LEADING_PURE_DUAL_CONTRACTION;
BRANCH_B_DERIVES_THE_CONDITIONAL_LINEAR_CAUSAL_STOCK_FLOW_OPERATOR;
THE_NAIVE_D_SIGMA_D_TAU_EQUALS_W_IDENTITY_IS_JOINTLY_REJECTED;
THE_DUAL_ASPECT_ONTOLOGY_SURVIVES_IN_REFINED_FORM;
W_MUNU_IS_THE_ACTIVE_CURRENT_READOUT_OF_THE_WRITE_LEDGER;
SIGMA_MUNU_IS_THE_RETAINED_SETTLEMENT_HISTORY_READOUT_OF_THE_SAME_LEDGER;
THEY_ARE_NOT_TWO_UNRELATED_SUBSTANCES_AND_ARE_NOT_ALGEBRAICALLY_THE_SAME_TENSOR;
THE_PROVISIONAL_COMMON_LINEAR_SKELETON_IS_E_ONE_MUNU_OF_SIGMA_EQUALS_KAPPA_W_MUNU;
IN_THE_HARMONIC_REPRESENTATIVE_IT_IS_BOX_BAR_SIGMA_MUNU_EQUALS_KAPPA_W_MUNU;
THE_RETARDED_GREEN_RELATION_REPLACES_POINTWISE_PROPER_TIME_ACCUMULATION;
THE_COMMON_SKELETON_RECOVERS_ONE_OVER_R_STATIC_HISTORY_CAUSAL_PROPAGATION_DUST_GAMMA_ONE_EMBEDDING_AND_RADIATION_DOUBLE_WEIGHT;
NO_NONLINEAR_EINSTEIN_EQUATION_METRIC_IDENTITY_SELF_COUPLING_OR_NUMERICAL_G_DERIVED;
G_COV_3_METRIC_CONSTITUTIVE_MAP_AND_NONLINEAR_CLOSURE_ENTRY_READY
```

G-COV-2A independently derived the source-side object

\[
{\cal W}^{\mu\nu}=\frac{dP^\nu}{d\Sigma_\mu},
\qquad
\nabla_\mu{\cal W}^{\mu\nu}=0,
\]

and the unique leading dual pairing

\[
\Sigma_{\mu\nu}{\cal W}^{\mu\nu}.
\]

G-COV-2B independently killed the pointwise proper-time identity and derived the conditional linear stock–flow equation

\[
{\cal E}^{(1)}_{\mu\nu}[\Sigma]
=
\kappa_\Sigma{\cal W}_{\mu\nu}.
\]

In the harmonic representative:

\[
\boxed{\square\bar\Sigma_{\mu\nu}
=
\kappa_\Sigma{\cal W}_{\mu\nu}}.
\]

The branches agree that the source is symmetric and conserved, null energy requires no proper time, dust and radiation have active weights one and two, and a stationary source establishes a causal \(1/r\) history rather than accumulating indefinitely.

The refined ontology is:

```text
W_munu:
the write ledger viewed as active energy-momentum current

Sigma_munu:
the same ledger viewed as retained settlement history
```

They are not separate substances, but they are not algebraically identical. They are linked by a causal differential/Green operator.

No nonlinear completion, metric identity, self-coupling, binding-energy theorem, physical polarization count, or numerical gravitational normalization is claimed.
