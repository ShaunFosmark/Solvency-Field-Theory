# SFT V13.1-V3 — G-COV-2A
## Native Write-Momentum Source and Dual Coupling v0.1

Generated: 2026-07-20 20:14:34

```text
G_COV_2A_VERDICT =
PASS_COMMON_FREEZE_AND_BRANCH_ISOLATION;
PASS_NATIVE_WRITE_MOMENTUM_FLUX_SOURCE_TENSOR;
W_MUNU_EQUALS_D_P_NU_PER_D_SIGMA_MU_IS_THE_MINIMAL_COVARIANT_CONTINUUM_SOURCE_OBJECT;
TOTAL_LOCAL_TRANSLATION_AND_NO_OVERWRITE_BOOKKEEPING_REQUIRE_NABLA_MU_W_MUNU_EQUALS_ZERO_FOR_A_CLOSED_COMPLETE_LEDGER;
TOTAL_LOCAL_ANGULAR_MOMENTUM_CLOSURE_REQUIRES_THE_COMPLETED_W_MUNU_TO_BE_SYMMETRIC;
W_MUNU_CONTAINS_ENERGY_DENSITY_MOMENTUM_FLUX_PRESSURE_RADIATION_AND_ANISOTROPIC_STRESS;
NULL_SUPPORT_SOURCES_W_MUNU_WITHOUT_A_PROPER_TIME_PARAMETER;
THE_GENERAL_LEADING_DERIVATIVE_FREE_DUAL_SCALAR_HAS_TWO_TERMS;
THE_FROZEN_V2_DUST_WEIGHT_ONE_AND_ISOTROPIC_RADIATION_WEIGHT_TWO_UNIQUELY_FORCE_ALPHA_ONE_BETA_ZERO_UP_TO_OVERALL_NORMALIZATION;
THE_PURE_CONTRACTION_SIGMA_MUNU_W_UPPER_MUNU_PRODUCES_EPSILON_PLUS_THREE_P;
NO_SEPARATE_GRAVITATIONAL_CHARGE_IS_REQUIRED_AT_THE_SOURCE_LEVEL;
BINDING_ENERGY_GRAVITATIONAL_SELF_ENERGY_AND_TOTAL_LEDGER_COMPLETION_REMAIN_OPEN;
NO_FIELD_EQUATION_PROPAGATION_LAW_METRIC_MAP_OR_NUMERICAL_COUPLING_DERIVED;
G_COV_2B_INDEPENDENT_BRANCH_AND_G_COV_2C_COMPARISON_AUTHORIZED
```

The source-side object is the covariant flux of the four-momentum carried by real writes:

\[
\boxed{{\cal W}^{\mu\nu}=\frac{dP^\nu}{d\Sigma_\mu}}
\]

For a complete closed ledger:

\[
\nabla_\mu{\cal W}^{\mu\nu}=0.
\]

The leading derivative-free scalar pairing with the G-COV-1 carrier is:

\[
{\cal L}_{dual}
=
\alpha\Sigma_{\mu\nu}{\cal W}^{\mu\nu}
+
\beta\Sigma{\cal W}.
\]

In the frozen V2 scalar embedding, the first contraction gives \(\phi(\epsilon+3p)\), while the trace product gives \(2\phi(-\epsilon+3p)\). Requiring dust weight one and radiation weight two forces:

\[
\boxed{\alpha=1,\qquad\beta=0}.
\]

Thus the pure contraction is uniquely selected within the tested family. Null energy is included through \({\cal W}^{\mu\nu}=\rho k^\mu k^\nu\), with no proper-time parameter.

This branch earns the native source tensor and its leading dual pairing. It does not yet earn a field equation or prove the binding/self-energy completion.
