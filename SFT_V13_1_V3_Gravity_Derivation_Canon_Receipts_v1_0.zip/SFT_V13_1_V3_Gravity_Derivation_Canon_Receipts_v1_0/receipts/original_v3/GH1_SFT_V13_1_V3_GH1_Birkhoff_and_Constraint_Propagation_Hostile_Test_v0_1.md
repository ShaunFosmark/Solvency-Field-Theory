# SFT V13.1-V3 Gravity Hostile Program
## G-H1 — Birkhoff and Constraint-Propagation Hostile Test v0.1

Generated: 2026-07-20 23:00:07

```text
G_H1_VERDICT =
PASS_FROZEN_EQUATION_HASH_AND_NO_RETUNING_CONTRACT;
PASS_LOCAL_BIRKHOFF_HOSTILE_TEST_CONDITIONALLY_ON_P_ONE_P_TWO_P_THREE;
FOR_THE_GENERAL_LOCAL_POLAR_AREAL_SPHERICAL_METRIC_A_EQUALS_ONE_MINUS_TWO_M_OF_T_R_OVER_R;
THE_VACUUM_T_R_EQUATION_FORCES_PARTIAL_T_M_EQUALS_ZERO;
THE_VACUUM_T_T_EQUATION_FORCES_PARTIAL_R_M_EQUALS_ZERO;
THE_VACUUM_R_R_EQUATION_THEN_FORCES_PARTIAL_R_PHI_EQUALS_ZERO;
THE_REMAINING_PHI_OF_T_IS_REMOVED_BY_A_TIME_ADDRESS_RELABELING;
THE_UNIQUE_REGULAR_LOCAL_SPHERICAL_VACUUM_IS_SCHWARZSCHILD_WITH_CONSTANT_M;
NO_PHYSICAL_SPHERICAL_VACUUM_RADIATION_OR_TIME_DEPENDENT_MONOPOLE_DEGREE_SURVIVES;
A_TIME_DEPENDENT_SPHERICAL_MASS_REQUIRES_NONZERO_WRITE_MOMENTUM_FLUX_AND_IS_NOT_VACUUM;
PASS_EXACT_CONSTRAINT_COMPATIBILITY_FROM_GEOMETRIC_AND_SOURCE_CONSERVATION;
PASS_LINEARIZED_CONSTRAINT_PROPAGATION;
ZERO_INITIAL_HAMILTONIAN_AND_MOMENTUM_CONSTRAINTS_REMAIN_ZERO;
SMALL_CONSTRAINT_ERRORS_PROPAGATE_ON_THE_ONE_SPEED_LIGHT_CONE_IN_THE_LINEARIZED_SYSTEM;
AN_EXPLICITLY_NONCONSERVED_SOURCE_GENERATES_CONSTRAINT_VIOLATION;
NO_HORIZON_CENTER_GLOBAL_TOPOLOGY_OR_COSMOLOGICAL_BOUNDARY_OVERCLAIM;
P_ONE_P_TWO_AND_P_THREE_REMAIN_EXPLICIT_PREMISES_AND_ARE_NOT_UPGRADED_BY_THIS_GATE;
NO_EQUATION_COEFFICIENT_SOURCE_OR_METRIC_MAP_WAS_CHANGED;
G_H2_STRONG_EQUIVALENCE_AND_COMPACT_BODY_SENSITIVITY_HOSTILE_TEST_READY
```

## 1. Frozen entry

The conditionally frozen equation was held unchanged:

\[
G_{\mu\nu}[g(\Sigma)]
=
\frac{8\pi G_{\rm eff}}{c^4}
{\cal W}_{\mu\nu}.
\]

P1, P2, and P3 were held fixed. No coefficient, source definition, constitutive map, cosmological term, or higher-curvature correction was added.

The kill questions were:

```text
Can a time-dependent spherical vacuum survive?

Can a physical monopole gravitational wave survive?

Can the evolution equations fail to preserve initially satisfied constraints?

Can a nonconserved source be tolerated without consequence?
```

## 2. Spherical vacuum attack

Use the local polar-areal form

\[
ds^2
=
-e^{2\Phi(t,r)}A(t,r)\,dt^2
+
A(t,r)^{-1}dr^2
+
r^2d\Omega^2,
\]

with

\[
A(t,r)=1-\frac{2m(t,r)}r.
\]

The relevant geometric components are

\[
G_{tr}
=
\frac{2\dot m}
{r(r-2m)},
\]

\[
G_{tt}
=
\frac{2(r-2m)e^{2\Phi}m'}
{r^3},
\]

and

\[
G_{rr}
=
\frac{2[(r-2m)\Phi'-m']}
{r(r-2m)}.
\]

In vacuum, \({\cal W}_{\mu\nu}=0\).

First,

\[
G_{tr}=0
\quad\Longrightarrow\quad
\dot m=0.
\]

Second,

\[
G_{tt}=0
\quad\Longrightarrow\quad
m'=0.
\]

Therefore,

\[
m(t,r)=M
\]

is constant.

Third,

\[
G_{rr}=0
\quad\Longrightarrow\quad
\Phi'=0.
\]

Thus,

\[
\Phi(t,r)=\Phi_0(t).
\]

The remaining factor is removed by

\[
dT=e^{\Phi_0(t)}dt.
\]

The resulting metric is

\[
\boxed{
ds^2
=
-\left(1-\frac{2M}{r}\right)dT^2
+
\left(1-\frac{2M}{r}\right)^{-1}dr^2
+
r^2d\Omega^2.
}
\]

The regular local spherical vacuum is therefore Schwarzschild.

## 3. What time dependence would require

A time-dependent mass gives

\[
\dot m\ne0
\quad\Longrightarrow\quad
G_{tr}\ne0.
\]

Through the frozen equation,

\[
{\cal W}_{tr}\ne0.
\]

A varying spherical mass is therefore an energy-flux spacetime, not a vacuum spacetime.

This correctly leaves room for spherical null-flux solutions while forbidding spherical vacuum radiation.

The conclusion is:

\[
\boxed{
\text{no physical monopole gravitational radiation in vacuum}.
}
\]

## 4. Constraint propagation

The exact geometric identity is

\[
\nabla_\mu G^{\mu\nu}=0.
\]

With the frozen equation, this requires

\[
\nabla_\mu{\cal W}^{\mu\nu}=0.
\]

In a hypersurface decomposition, let \({\cal H}\) denote the Hamiltonian constraint and \({\cal M}_i\) the momentum constraints.

When the evolution equations hold, the constraint subsystem is homogeneous. Around flat geometry its principal part is

\[
\partial_t{\cal H}
=
-2\partial_i{\cal M}^i,
\]

\[
\partial_t{\cal M}_i
=
-\frac12\partial_i{\cal H}.
\]

Therefore,

\[
\partial_t^2{\cal H}
=
\nabla^2{\cal H}.
\]

Exactly zero initial constraints remain zero. Small numerical or preparation errors propagate on the one-speed cone rather than representing a new physical source.

The numerical pulse test obtained a relative constraint-energy drift below \(10^{-10}\) and equation residuals below \(10^{-7}\).

An explicitly nonconserved forcing term generated a nonzero constraint immediately. Source conservation is therefore load-bearing rather than decorative.

## 5. Guardrails

This is a local Birkhoff result.

The polar-areal chart is singular at \(r=2M\), but the Schwarzschild geometry can be continued through the horizon in regular coordinates. The derivation does not claim that division by \(r-2M\) is valid exactly on the chart singularity.

The gate does not address:

```text
a material or singular center
arbitrary global topology
Kerr
cosmological boundary-capacity geometry
compact-body sensitivity
or nonlinear gravitational radiation
```

## 6. Result

G-H1 finds no spherical vacuum dynamics hidden in the frozen model and no inconsistency in continuum constraint propagation.

The result remains conditional on P1–P3. It does not upgrade those premises into microscopic theorems.
