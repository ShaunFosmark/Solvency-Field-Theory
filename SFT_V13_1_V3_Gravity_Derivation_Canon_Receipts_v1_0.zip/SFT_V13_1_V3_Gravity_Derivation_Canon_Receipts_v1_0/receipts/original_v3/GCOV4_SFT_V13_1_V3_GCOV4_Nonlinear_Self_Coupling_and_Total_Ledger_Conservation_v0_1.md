# SFT V13.1-V3 Gravity Dynamics Completion
## G-COV-4 — Nonlinear Self-Coupling and Total-Ledger Conservation v0.1

Generated: 2026-07-20 21:53:29

```text
G_COV_4_VERDICT =
PASS_UPSTREAM_FREEZE_AND_ENTRY_CONTRACT;
PASS_CONDITIONAL_NONLINEAR_SELF_COUPLING_CLOSURE_FOR_THE_G_COV_3_CANDIDATE;
EXPANDING_G_MUNU_OF_G_EQUALS_KAPPA_G_W_MUNU_ABOUT_A_BACKGROUND_GIVES_G_ONE_MUNU_EQUALS_KAPPA_G_TIMES_W_MUNU_PLUS_TAU_G_MUNU;
TAU_G_MUNU_EQUALS_MINUS_ONE_OVER_KAPPA_G_TIMES_THE_SUM_OF_ALL_SECOND_AND_HIGHER_ORDER_GEOMETRIC_TERMS;
THE_EFFECTIVE_GRAVITATIONAL_LEDGER_TAU_G_IS_BACKGROUND_SPLIT_BOOKKEEPING_NOT_A_NEW_COVARIANT_LOCAL_SUBSTANCE;
THE_LINEAR_BIANCHI_IDENTITY_GIVES_PARTIAL_MU_OF_W_UPPER_MU_NU_PLUS_TAU_G_UPPER_MU_NU_EQUALS_ZERO;
THE_EXACT_GEOMETRIC_IDENTITY_GIVES_NABLA_MU_W_UPPER_MU_NU_EQUALS_ZERO;
GENERIC_NONLINEAR_CLOSURE_UNIQUELY_FIXES_THE_SELF_COUPLING_COEFFICIENT_TO_ONE;
NO_SECOND_GRAVITATIONAL_CHARGE_OR_RESCUE_CONSTANT_IS_ALLOWED;
PASS_EXACT_CONSTANT_DENSITY_TOV_AND_INTERIOR_EXTERIOR_BOUNDARY_REGRESSION;
PRESSURE_ENTERS_THE_CLOCK_AND_ACCELERATION_GEOMETRY_THROUGH_M_PLUS_FOUR_PI_R_CUBED_P;
THE_EXTERIOR_MASS_PARAMETER_IS_SMALLER_THAN_THE_INTEGRATED_PROPER_MATTER_ENERGY;
THE_DIFFERENCE_IS_A_NEGATIVE_BINDING_LEDGER;
ITS_WEAK_UNIFORM_SPHERE_LIMIT_IS_MINUS_THREE_M_SQUARED_OVER_FIVE_R;
THE_NEWTONIAN_SOURCE_POTENTIAL_AND_FIELD_GRADIENT_BINDING_LEDGERS_AGREE_EXACTLY;
AT_WEAK_BINDING_ORDER_UNIVERSAL_WRITE_CHARGE_APPLIED_TO_TOTAL_MASS_ENERGY_SUPPRESSES_THE_CENTER_OF_MASS_DIPOLE;
A_NONUNIVERSAL_BINDING_SENSITIVITY_REOPENS_THE_DIPOLE_CHANNEL;
FULL_STRONG_EQUIVALENCE_FOR_ARBITRARY_COMPACT_BODIES_IS_NOT_EARNED;
NO_OBSERVER_INDEPENDENT_LOCAL_GRAVITATIONAL_ENERGY_DENSITY_IS_CLAIMED;
BINARY_PULSAR_POWER_RADIATION_REACTION_BLACK_HOLE_SENSITIVITY_AND_NUMERICAL_G_REMAIN_OPEN;
THE_FIELD_EQUATION_REMAINS_CONDITIONAL_PENDING_NATIVE_AUDIT_OF_THE_G_COV_3_M_AND_N_ASSUMPTIONS;
G_COV_5_NATIVE_CLOSURE_ASSUMPTION_AUDIT_AND_FIELD_EQUATION_FREEZE_READY
```

## Exact and background ledgers

Hold the G-COV-3 candidate fixed:

\[
G_{\mu\nu}[g]=\kappa_g{\cal W}_{\mu\nu}.
\]

Around a bookkeeping background,

\[
g_{\mu\nu}=\bar g_{\mu\nu}+h_{\mu\nu},
\]

expand

\[
G_{\mu\nu}
=
G^{(1)}_{\mu\nu}
+
G^{(2)}_{\mu\nu}
+
G^{(3)}_{\mu\nu}
+\cdots.
\]

This rearranges exactly to

\[
\boxed{
G^{(1)}_{\mu\nu}[h]
=
\kappa_g
\left(
{\cal W}_{\mu\nu}
+
\tau^g_{\mu\nu}[h]
\right)
}
\]

with

\[
\boxed{
\tau^g_{\mu\nu}
=
-\frac1{\kappa_g}
\sum_{n\ge2}
G^{(n)}_{\mu\nu}[h].
}
\]

The nonlinear geometry therefore appears as an effective source to the linear carrier. The split object \(\tau^g_{\mu\nu}\) is bookkeeping relative to a background, not an independent covariant substance.

The linear identity gives

\[
\partial_\mu({\cal W}^{\mu\nu}+\tau_g^{\mu\nu})=0,
\]

while the exact identity gives

\[
\boxed{\nabla_\mu{\cal W}^{\mu\nu}=0}.
\]

A free self-coupling multiplier leaves a residual proportional to \(1-\lambda_{\rm self}\), so generic closure requires

\[
\boxed{\lambda_{\rm self}=1}.
\]

## Compact-sphere conservation

For a static spherical perfect fluid,

\[
\frac{dm}{dr}=4\pi r^2\epsilon,
\]

\[
\frac{d\nu}{dr}
=
\frac{m+4\pi r^3p}{r(r-2m)},
\]

and

\[
\boxed{
\frac{dp}{dr}
=
-\frac{(\epsilon+p)(m+4\pi r^3p)}
{r(r-2m)}
}.
\]

The constant-density interior passed this equation and the exterior boundary match. Pressure contributes directly through \(m+4\pi r^3p\).

## Binding energy

The proper matter energy is

\[
M_{\rm proper}
=
4\pi
\int_0^R
\frac{\epsilon r^2\,dr}{\sqrt{1-2m(r)/r}}.
\]

The exterior geometry is labeled by \(M=m(R)\). The regression gives

\[
M_{\rm proper}>M,
\qquad
E_{\rm bind}=M-M_{\rm proper}<0.
\]

For weak compactness,

\[
\boxed{
E_{\rm bind}
=
-\frac{3M^2}{5R}
+
O(C^2M).
}
\]

The same result follows from

\[
\frac12\int\rho\Phi\,d^3x
=
-\frac1{8\pi G}
\int|\nabla\Phi|^2d^3x.
\]

Thus the source-potential and field-gradient descriptions are two ledgers for the same binding contribution.

## Equivalence boundary

If universal write charge applies to total mass-energy including binding,

\[
q_i=\kappa m_i,
\]

then in the center-of-mass frame,

\[
\sum_i q_i\mathbf x_i=0.
\]

A nonuniversal compact-body sensitivity reopens the dipole. This earns only the weak/static route, not full strong equivalence or binary-pulsar safety.

## Boundary

G-COV-4 shows that the conditional nonlinear candidate closes on its own geometry with one coupling and accounts correctly for weak binding and static compact-sphere conservation.

It does not yet earn a background-independent local gravitational-energy density, full strong equivalence, arbitrary compact-body sensitivities, black-hole self-energy, radiation reaction, quadrupole power, binary-pulsar agreement, or numerical \(G\).

The field equation remains conditional until the native status of the G-COV-3 constitutive and closure assumptions is audited.
