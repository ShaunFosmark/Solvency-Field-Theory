# SFT V13.1-V3 Gravity Hostile Program
## G-H2 — Strong Equivalence and Compact-Body Sensitivity Hostile Test v0.1

Generated: 2026-07-20 23:13:44

```text
G_H2_VERDICT =
PASS_FROZEN_EQUATION_HASH_AND_NO_RETUNING_CONTRACT;
PASS_SPHERICAL_COMPACT_BODY_ACTIVE_MONOPOLE_UNIVERSALITY_CONDITIONALLY_ON_P_ONE_P_TWO_P_THREE;
THE_UNIQUE_SPHERICAL_VACUUM_EXTERIOR_CARRIES_ONE_ASYMPTOTIC_MASS_PARAMETER_M;
THE_EXTERIOR_MONOPOLE_HAS_NO_INDEPENDENT_EQUATION_OF_STATE_PROPER_ENERGY_OR_BINDING_CHARGE;
PASS_ASYMPTOTIC_INERTIAL_MASS_EQUALITY;
THE_CONSERVED_ASYMPTOTIC_FOUR_MOMENTUM_HAS_INVARIANT_MASS_M_EQUAL_TO_THE_EXTERIOR_GRAVITATIONAL_MASS;
PASS_UNIQUE_LEADING_METRIC_MONOPOLE_COUPLING_MINUS_M_C_INTEGRAL_D_S;
THE_BODY_MASS_CANCELS_FROM_THE_GEODESIC_EQUATION;
NO_COMPACTNESS_DEPENDENT_MONOPOLE_SENSITIVITY_OPERATOR_EXISTS_INSIDE_THE_FROZEN_METRIC_ONLY_NO_EXTRA_FIELD_CONTRACT;
PASS_STANDARD_WEAK_NORDTVEDT_PARAMETER_ETA_N_EQUALS_ZERO;
PASS_THREE_FAMILY_TOV_EQUATION_OF_STATE_SWEEP;
THE_SWEEP_SPANS_WEAK_COMPACTNESS_TO_ABOUT_ZERO_POINT_THREE_ONE_AND_PROPER_ENERGY_BINDING_TO_ABOUT_ZERO_POINT_TWO_SEVEN;
ALL_MODELS_RETAIN_ONE_EXTERIOR_MASS_PARAMETER_WITHOUT_A_SECOND_GRAVITATIONAL_CHARGE;
NEGATIVE_BINDING_ENERGY_IS_INCLUDED_IN_THE_TOTAL_ASYMPTOTIC_MASS_LEDGER;
THE_NEUTRON_STAR_CLOSURE_CONTINUITY_CONJECTURE_IS_SUPPORTED_AT_THE_MONOPOLE_LEDGER_LEVEL_BUT_NOT_MICROSCOPICALLY_PROVEN;
PARTIAL_PASS_STRONG_EQUIVALENCE;
FULL_NONLINEAR_TWO_BODY_EFFACEMENT_DYNAMICAL_COMPACT_BODY_MATCHING_TIDAL_RESPONSE_RADIATION_REACTION_AND_BLACK_HOLE_SPIN_REMAIN_OPEN;
TIDAL_AND_MULTIPOLE_COEFFICIENTS_MAY_DEPEND_ON_INTERNAL_STRUCTURE_WITHOUT_CREATING_A_NORDTVEDT_MONOPOLE_CHARGE;
ABSENCE_OF_ALL_RADIATIVE_DIPOLE_CHANNELS_IS_NOT_CLAIMED_BEFORE_G_H5_AND_G_H6;
P_ONE_P_TWO_AND_P_THREE_REMAIN_EXPLICIT_PREMISES;
NO_EQUATION_COEFFICIENT_SOURCE_METRIC_MAP_OR_COMPACTNESS_SENSITIVITY_WAS_RETUNED;
G_H3_LENSING_VERSUS_DYNAMICS_HOSTILE_TEST_READY
```

## 1. Question

The hostile question was whether a self-gravitating body acquires an additional compactness-dependent gravitational charge beyond its total inertial mass.

Such a charge would take the schematic form

\[
Q_A=M_A(1+s_A),
\]

with \(s_A\) depending on binding energy, compactness, or equation of state.

If present, unequal compact bodies could fall differently and generate a Nordtvedt dipole.

## 2. Active gravitational mass

G-H1 established that every regular local spherical vacuum exterior is Schwarzschild:

\[
ds^2
=
-\left(1-\frac{2M}{r}\right)dt^2
+
\left(1-\frac{2M}{r}\right)^{-1}dr^2
+
r^2d\Omega^2.
\]

The exterior contains one monopole parameter \(M\).

It does not contain separate labels for

\[
M_{\rm proper},
\qquad
E_{\rm bind},
\qquad
\text{EOS},
\qquad
\text{central density}.
\]

Those quantities affect the value of \(M\), but do not survive as an independent exterior charge.

Thus the active spherical gravitational monopole is the total asymptotic mass \(M\).

## 3. Inertial mass

An isolated body carries one conserved asymptotic four-momentum \(P^\mu\).

Its invariant mass is

\[
M_{\rm inert}
=
\frac1c\sqrt{-P_\mu P^\mu}.
\]

In the rest frame,

\[
P^\mu=(Mc,0,0,0),
\]

so

\[
\boxed{
M_{\rm inert}=M_{\rm active}=M.
}
\]

The numerical boost audit preserved the invariant mass to better than \(10^{-12}\).

## 4. External monopole coupling

Inside the frozen metric-only contract, the unique structureless worldline action is

\[
\boxed{
S_{\rm mono}
=
-Mc\int ds.
}
\]

Variation gives

\[
u^\nu\nabla_\nu u^\mu=0.
\]

The overall \(M\) cancels. Therefore the leading acceleration does not depend on total mass, binding fraction, compactness, or equation of state.

An independent term such as

\[
q_A\int\Phi_{\rm scalar}\,ds
\]

would require an additional scalar or absolute potential. That is forbidden by the frozen no-extra-field contract.

Structure dependence can re-enter through tidal and spin operators involving curvature. Those are finite-size effects, not an independent gravitational monopole charge.

## 5. TOV equation-of-state sweep

Three relativistic polytropic EOS families were integrated through their stable branch:

```text
Gamma = 2.0
Gamma = 2.5
Gamma = 3.0
```

The sweep covered:

```text
compactness:
approximately 2e-7 through 0.31

proper-energy binding fraction:
approximately 1e-7 through 0.27
```

Each star possessed:

- a different pressure profile;
- a different proper-energy inventory;
- a different binding fraction;
- a different radius and compactness.

Yet every exterior was labeled only by the same type of asymptotic parameter \(M\).

No second charge or sensitivity fit was introduced.

## 6. Nordtvedt parameter

The weak Nordtvedt combination is

\[
\eta_N
=
4\beta-\gamma-3
-\frac{10}{3}\xi
-\alpha_1
+\frac23\alpha_2
-\frac23\zeta_1
-\frac13\zeta_2.
\]

The frozen model has

\[
\beta=\gamma=1
\]

and no preferred-frame, preferred-location, or nonconservative parameters inside P2 and the conserved write ledger.

Therefore

\[
\boxed{\eta_N=0}
\]

at the standard weak-field PPN level.

## 7. Dipole boundary

For compact objects whose monopole charge equals total mass,

\[
Q_A=M_A,
\]

the center-of-mass dipole is

\[
\mathbf D
=
\sum_A M_A\mathbf x_A
=
0.
\]

Randomized systems gave a maximum residual near \(10^{-13}\).

Artificial nonuniversal sensitivities immediately generated a nonzero dipole.

This supports monopole universality. It does not yet derive the complete radiative sector.

## 8. Closure-continuity conjecture

The neutron-star closure idea receives partial support:

> gravitational binding participates in the total asymptotic mass ledger and does not emerge as a separately charged substance.

That is consistent with a continuous self-maintaining settlement picture from weak bodies through neutron stars.

The gate does not prove that particle topological closure and stellar gravitational closure are microscopically the same operator.

## 9. Boundary

G-H2 passes the active/inertial monopole equality and the weak Nordtvedt test.

It does not yet prove:

```text
full nonlinear two-body effacement
strong-field motion in a dynamical companion geometry
EOS-independent tidal response
absence of every radiative dipole mode
spinning black-hole universality
horizon absorption
or radiation reaction
```

The correct verdict is therefore a partial strong-equivalence pass rather than an unconditional SEP proof.
