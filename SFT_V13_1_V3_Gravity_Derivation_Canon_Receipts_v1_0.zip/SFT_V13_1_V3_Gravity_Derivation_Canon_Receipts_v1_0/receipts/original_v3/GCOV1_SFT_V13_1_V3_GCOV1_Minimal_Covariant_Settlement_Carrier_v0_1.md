# SFT V13.1-V3 Gravity Dynamics Completion
## G-COV-1 — Minimal Covariant Settlement Carrier v0.1

Generated: 2026-07-20 19:18:25

```text
G_COV_1_VERDICT =
PASS_V13_1_V2_FREEZE_AND_ENTRY_CONTRACT;
NO_V13_1_V2_MECHANISM_REOPENED;
PASS_MINIMAL_COVARIANT_CARRIER_SELECTION_CONDITIONALLY_ON_A1_THROUGH_A7;
SCALAR_VECTOR_AND_ANTISYMMETRIC_TWO_FORM_CARRIERS_FAIL_FROZEN_SECTOR_COMPLETENESS;
A_SYMMETRIC_RANK_TWO_SETTLEMENT_RESPONSE_TENSOR_SIGMA_MUNU_IS_THE_UNIQUE_MINIMAL_STANDARD_LORENTZ_TENSOR_CARRIER_UNDER_THE_FROZEN_ASSUMPTIONS;
ITS_LOCAL_THREE_PLUS_ONE_DECOMPOSITION_IS_ONE_CLOCK_SCALAR_PLUS_ONE_MIXED_THREE_VECTOR_PLUS_ONE_SPATIAL_TRACE_SCALAR_PLUS_ONE_FIVE_COMPONENT_SPATIAL_TRACE_FREE_SHEAR;
THE_ONE_PLUS_THREE_PLUS_ONE_PLUS_FIVE_COMPONENT_COUNT_EXACTLY_MATCHES_THE_V2_SCALAR_MIXED_AND_TRACE_FREE_LANE_REQUIREMENTS;
STATIC_WEAK_SCALAR_FRAME_DRAGGING_AND_TT_WAVE_SKELETONS_EMBED_WITHOUT_LINEAR_SECTOR_CONTAMINATION;
THE_DECOMPOSITION_IS_LORENTZ_COVARIANT_WHEN_SIGMA_MUNU_AND_THE_LOCAL_CONTINUATION_FOUR_VELOCITY_TRANSFORM_TOGETHER;
NO_PREFERRED_GLOBAL_FRAME_OR_AETHER_IS_INTRODUCED;
NO_NEW_PHYSICAL_FIELD_OR_PROPAGATING_DEGREE_OF_FREEDOM_IS_EARNED;
SIGMA_MUNU_IS_A_COVARIANT_BOOKKEEPING_CARRIER_FOR_EXISTING_ACCUMULATED_SETTLEMENT_GEOMETRY;
SIGMA_MUNU_IS_NOT_YET_IDENTIFIED_WITH_THE_METRIC_RICCI_TENSOR_EINSTEIN_TENSOR_OR_STRESS_ENERGY_TENSOR;
THE_METRIC_CONSTITUTIVE_MAP_SOURCE_TENSOR_GAUGE_STRUCTURE_ACTION_AND_NONLINEAR_FIELD_EQUATION_REMAIN_OPEN;
NO_EINSTEIN_EQUATION_OR_EINSTEIN_HILBERT_ACTION_IMPORTED;
G_COV_2_SOURCE_AND_DUAL_COUPLING_GATE_READY
```

## 1. Why this gate exists

V13.1-V2 already earned the Newtonian scalar projection, weak-field reciprocal metric response, the structure of the gravitational normalization, and the bounded static spherical Schwarzschild exterior. It also located three non-scalar gravitational sectors:

```text
scalar/trace settlement
mixed continuation-settlement circulation
spatial trace-free shear
```

The missing question is not whether these sectors exist. The missing question is how they fit inside one covariant object without importing the Einstein equation.

G-COV-1 asks only:

```text
What is the minimal local Lorentz-tensor carrier capable of containing every frozen V2 sector?
```

It does not derive the field equation.

## 2. Frozen entry contract

The following V2 artifacts are frozen:

```text
public gravity PDF:
9e0bd7af0138e15aed4d0e05936a7c909a9626ec69bfa81995a40ddce258fc25

derivation canon PDF:
347301ab25d103cc2d7c2d374fc34b75ff9f1b7c75b87d98fb00de63862b2420

full repro pack:
fcc8842b890bbaccce8a0577d6963bb281e6614b2ec1327706f74cbb8a92c203
```

No V2 mechanism may be altered to make the covariant program work.

Forbidden at this gate:

```text
Einstein equation insertion
Einstein-Hilbert action insertion
metric-first selection
new physical field
preferred global foliation
target-derived coefficient
```

## 3. Required rotational content

Relative to any local future-directed unit timelike continuation vector \(u^\mu\), the frozen V2 sectors require:

```text
one clock/continuation scalar                  1
one mixed continuation-settlement vector      3
one isotropic spatial settlement trace        1
one symmetric spatial trace-free shear        5
                                               --
                                               10
```

This is exactly the rotational decomposition of a symmetric rank-two spacetime tensor.

Introduce the provisional carrier:

\[
\boxed{\Sigma_{\mu\nu}=\Sigma_{\nu\mu}}
\]

called the **covariant settlement response tensor**.

The name is bookkeeping only. No independent propagating field is introduced.

## 4. Covariant decomposition

With metric \(g_{\mu\nu}\), local continuation vector \(u^\mu\), and spatial projector

\[
h_{\mu\nu}=g_{\mu\nu}+u_\mu u_\nu,
\]

define:

\[
\rho_\Sigma=\Sigma_{\mu\nu}u^\mu u^\nu,
\]

\[
q_\mu=-h_\mu{}^\alpha\Sigma_{\alpha\beta}u^\beta,
\qquad q_\mu u^\mu=0,
\]

\[
p_\Sigma=\frac13h^{\mu\nu}\Sigma_{\mu\nu},
\]

\[
\pi_{\mu\nu}
=
h_\mu{}^\alpha h_\nu{}^\beta\Sigma_{\alpha\beta}
-p_\Sigma h_{\mu\nu}.
\]

The trace-free spatial sector satisfies:

\[
\pi_{\mu\nu}u^\nu=0,
\qquad
h^{\mu\nu}\pi_{\mu\nu}=0.
\]

The full object reconstructs as:

\[
\boxed{
\Sigma_{\mu\nu}
=
\rho_\Sigma u_\mu u_\nu
+
p_\Sigma h_{\mu\nu}
+
2q_{(\mu}u_{\nu)}
+
\pi_{\mu\nu}
}
\]

with component count:

\[
1+3+1+5=10.
\]

The numerical audit reconstructed 20,000 random symmetric tensors with maximum error below \(10^{-11}\).

## 5. Why lower-rank candidates fail

### Scalar

A scalar can carry compactness or clock depth, but cannot carry mixed circulation or shear. It reproduces the exact failure V2 was built to avoid.

### Four-vector

A four-vector decomposes into one scalar and one three-vector. It has no spatial trace sector independent of the clock scalar and no five-component STF shear.

### Antisymmetric two-form

A two-form decomposes into two three-vectors, like electric and magnetic sectors. Antisymmetry forbids both an isotropic spatial trace and symmetric shear.

### Symmetric rank-two tensor

A symmetric rank-two tensor has exactly the required content and no surplus component under A1-A7.

Tetrads, connections, and curvature tensors can represent richer geometry, but they are overcomplete or derivative objects and are not selected as the primary accumulated settlement carrier at this gate.

## 6. V2 regression embeddings

### Static weak scalar sector

Set:

\[
\Sigma_{00}=\phi,
\qquad
\Sigma_{0i}=0,
\qquad
\Sigma_{ij}=\phi\delta_{ij}.
\]

Then:

\[
\rho_\Sigma=p_\Sigma=\phi,
\qquad
q_i=0,
\qquad
\pi_{ij}=0.
\]

The provisional linear readout constraint

\[
g_{\mu\nu}
=
\eta_{\mu\nu}+2\Sigma_{\mu\nu}+O(\Sigma^2)
\]

would reproduce:

\[
g_{00}=-1+2\phi,
\qquad
g_{ij}=(1+2\phi)\delta_{ij},
\]

and therefore the V2 \(\gamma=1\) relation.

This does **not** yet derive the constitutive map. It proves only that the carrier can contain the frozen scalar metric sector without adding another object.

### Mixed rotating sector

Set only \(\Sigma_{0i}=A_i\).

Then only \(q_i\) is nonzero. The frame-dragging candidate sector is algebraically isolated from scalar depth and TT shear.

### TT wave sector

For propagation along \(\mathbf n\), set the spatial block to a transverse traceless matrix:

\[
\Sigma_{ij}=\Pi^{TT}_{ij},
\qquad
\Pi^{TT}_{ij}n^j=0,
\qquad
\delta^{ij}\Pi^{TT}_{ij}=0.
\]

Then only \(\pi_{ij}\) is nonzero.

The V2 TT skeleton therefore occupies the correct five-component carrier sector before dynamical constraints reduce it to two radiative polarizations.

## 7. No preferred frame

The 3+1 split depends on a local timelike continuation/observer vector \(u^\mu\), but the full \(\Sigma_{\mu\nu}\) does not depend on one global frame.

The audit Lorentz-boosted both \(\Sigma_{\mu\nu}\) and \(u^\mu\), decomposed again, and recovered the same scalar sectors and the transformed full tensor to numerical precision.

Thus:

```text
observer-relative decomposition:
yes

preferred universal frame:
no
```

## 8. What was selected

Under the frozen assumptions:

\[
\boxed{
\text{minimal covariant settlement carrier}
=
\Sigma_{\mu\nu}
=
\Sigma_{\nu\mu}
}
\]

This is a representation theorem, not yet a gravity equation.

It does not say:

\[
\Sigma_{\mu\nu}=g_{\mu\nu},
\]

\[
\Sigma_{\mu\nu}=R_{\mu\nu},
\]

\[
\Sigma_{\mu\nu}=G_{\mu\nu},
\]

or

\[
\Sigma_{\mu\nu}=T_{\mu\nu}.
\]

Any of those identifications must be earned by later gates.

## 9. The next gate

```text
G-COV-2 —
Native source tensor and dual coupling
```

G-COV-2 must determine what source object couples to \(\Sigma_{\mu\nu}\), whether the minimal scalar interaction is of the form

\[
\Sigma_{\mu\nu}\mathcal W^{\mu\nu},
\]

how rest energy, momentum, pressure, radiation, binding energy, and gravitational self-energy enter \(\mathcal W^{\mu\nu}\), and whether its conservation law is derived from no-overwrite and translation symmetry rather than imported.
