# SFT V13.1-V3 Gravity Hostile Program
## G-H3 — Lensing Versus Dynamics Hostile Test v0.1

Generated: 2026-07-20 23:50:34

```text
G_H3_VERDICT =
PASS_FROZEN_EQUATION_HASH_AND_NO_RETUNING_CONTRACT;
PASS_LENSING_VERSUS_DYNAMICS_HOSTILE_TEST_CONDITIONALLY_ON_P_ONE_P_TWO_P_THREE;
THE_FROZEN_WEAK_METRIC_HAS_BETA_EQUALS_ONE_AND_GAMMA_EQUALS_ONE;
SLOW_BODY_DYNAMICS_LIGHT_DEFLECTION_SHAPIRO_DELAY_GRAVITATIONAL_REDSHIFT_AND_PERICENTER_ADVANCE_USE_ONE_MONOPOLE_MASS_M;
THE_WEAK_LIGHT_DEFLECTION_IS_FOUR_G_EFF_M_OVER_B_C_SQUARED;
THE_ONE_WAY_SHAPIRO_DELAY_COEFFICIENT_IS_TWO_G_EFF_M_OVER_C_CUBED_TIMES_THE_PATH_LOGARITHM;
REMOVING_THE_SPATIAL_SETTLEMENT_RESPONSE_SETS_GAMMA_TO_ZERO_AND_REINTRODUCES_THE_HISTORICAL_FACTOR_OF_TWO_FAILURE;
THAT_CLOCK_ONLY_ROUTE_IS KILLED;
NO_INDEPENDENT_PHOTON_GRAVITATIONAL_CHARGE_OR_OPTICAL_METRIC_IS_ALLOWED;
PASS_EXACT_SCHWARZSCHILD_NULL_AND_TIMELIKE_LANDMARKS;
THE_PHOTON_SPHERE_IS_R_EQUALS_THREE_M;
THE_CRITICAL_IMPACT_PARAMETER_IS_THREE_SQRT_THREE_M;
THE_TIMELIKE_ISCO_IS_R_EQUALS_SIX_M;
THE_EXACT_CIRCULAR_ORBIT_FREQUENCY_IS_OMEGA_SQUARED_EQUALS_M_OVER_R_CUBED;
PASS_EXACT_NULL_GEODESIC_NUMERICAL_INTEGRATION;
THE_WEAK_DEFLECTION_APPROACHES_FOUR_M_OVER_B_AND_THE_DEFLECTION_GROWS_WITHOUT_BOUND_TOWARD_THE_CRITICAL_ORBIT;
PASS_WEAK_PERICENTER_NUMERICAL_REGRESSION;
FOUR_INDEPENDENT_MASS_INFERENCE_CHANNELS_AGREE_TO NUMERICAL_PRECISION;
NO_FACTOR_COEFFICIENT_SOURCE_METRIC_MAP_OR_PHOTON_RULE_WAS_RETUNED;
ROTATING_LENSES_COSMOLOGICAL_DISTANCE_RELATIONS_PLASMA_ENVIRONMENTS_AND_DARK_MATTER_PHENOMENOLOGY_ARE_OUTSIDE_THIS_LOCAL_VACUUM_GATE;
P_ONE_P_TWO_AND_P_THREE_REMAIN_EXPLICIT_PREMISES;
G_H4_FRAME_DRAGGING_AND_KERR_HOSTILE_TEST_READY
```

## 1. Frozen entry

The field equation, source tensor, metric map, and three explicit premises were held unchanged:

\[
G_{\mu\nu}[g(\Sigma)]
=
\frac{8\pi G_{\rm eff}}{c^4}
{\cal W}_{\mu\nu}.
\]

The hostile question was whether photons and massive bodies infer the same gravitational mass without adding a photon-specific coupling.

## 2. Weak geometry and the factor of two

The frozen weak metric is

\[
ds^2
=
-\left(1-\frac{2U}{c^2}\right)c^2dt^2
+
\left(1+\frac{2\gamma U}{c^2}\right)d\mathbf x^2,
\]

with

\[
U=\frac{G_{\rm eff}M}{r},
\qquad
\gamma=1.
\]

The clock sector fixes slow-body acceleration:

\[
\mathbf a=-\nabla\Phi.
\]

The light-deflection angle is

\[
\alpha
=
2(1+\gamma)
\frac{G_{\rm eff}M}{bc^2}.
\]

Therefore,

\[
\boxed{
\alpha
=
\frac{4G_{\rm eff}M}{bc^2}.
}
\]

A clock-only geometry would have \(\gamma=0\) and predict only

\[
\alpha_{\rm clock}
=
\frac{2G_{\rm eff}M}{bc^2}.
\]

That route is killed. The equal spatial response supplies the second half of the bending.

## 3. Shapiro delay

For an unperturbed path with closest distance \(b\), the one-way delay is

\[
\Delta t
=
(1+\gamma)
\frac{G_{\rm eff}M}{c^3}
\int\frac{dl}{r}.
\]

With \(\gamma=1\),

\[
\boxed{
\Delta t
=
\frac{2G_{\rm eff}M}{c^3}
\left[
\operatorname{asinh}\left(\frac{z_1}{b}\right)
+
\operatorname{asinh}\left(\frac{z_2}{b}\right)
\right].
}
\]

The same spatial response that doubles light bending doubles the clock-only Shapiro result.

No separate photon charge was introduced.

## 4. Single-mass inference

The same \(M\) is inferred from:

\[
M_{\rm dyn}
=
\frac{\Omega^2r^3}{G_{\rm eff}},
\]

\[
M_{\rm lens}
=
\frac{\alpha bc^2}{4G_{\rm eff}},
\]

\[
M_{\rm Shapiro}
=
\frac{\Delta t\,c^3}{2G_{\rm eff}I},
\]

and

\[
M_{\rm strong}
=
\frac{b_{\rm crit}c^2}{3\sqrt3\,G_{\rm eff}}.
\]

A 20,000-case randomized audit found no fractional mismatch above \(10^{-12}\).

## 5. Exact null and timelike geometry

For Schwarzschild,

\[
F(r)=1-\frac{2M}{r}.
\]

The null effective potential is

\[
V_{\rm null}
=
L^2\frac{F(r)}{r^2}.
\]

Its circular extremum is

\[
\boxed{r_{\rm ph}=3M}.
\]

The corresponding critical impact parameter is

\[
\boxed{b_{\rm crit}=3\sqrt3\,M}.
\]

For timelike circular motion,

\[
\boxed{\Omega^2=\frac{M}{r^3}},
\]

and the stability boundary is

\[
\boxed{r_{\rm ISCO}=6M}.
\]

The strong null and timelike landmarks are therefore fixed by the same exact metric parameter.

## 6. Exact deflection attack

The null-scattering integral was evaluated directly for closest approaches from the weak field down toward the photon sphere.

In the weak limit,

\[
\frac{\alpha}{4M/b}\rightarrow1.
\]

As the closest approach tends toward \(3M\), the impact parameter tends toward \(3\sqrt3 M\) and the deflection grows without bound.

No alternative strong-lensing coefficient appeared.

## 7. Pericenter dynamics

The Schwarzschild orbit equation is

\[
u''+u
=
\frac{M}{L^2}
+
3Mu^2.
\]

For weak eccentric motion with \(p=L^2/M\),

\[
\boxed{
\Delta\varpi
=
\frac{6\pi M}{p}
+
O\left(\frac{M^2}{p^2}\right).
}
\]

Numerical integration recovered the same mass to the expected weak-order accuracy.

## 8. Meaning in SFT

The result is not that photons receive a special bending rule.

It is:

```text
the clock settlement controls slow-body dynamics

the reciprocal spatial settlement supplies equal curvature

both are read through one metric

null and massive continuation therefore probe the same retained write history
```

The historical factor-of-two problem returns immediately if the spatial settlement sector is removed.

## 9. Boundary

G-H3 does not test rotating lenses, Kerr shadows, cosmological distance relations, plasma propagation, environmental matter, or dark-matter phenomenology.

It is a local vacuum single-metric test. P1, P2, and P3 remain explicit premises.
