# SFT V13.1-V3 Gravity Hostile Program
## G-H6 — Quadrupole Power and Binary-Pulsar Hostile Test v0.1

Generated: 2026-07-21 00:31:19

```text
G_H6_VERDICT =
PASS_FROZEN_EQUATION_HASH_AND_NO_RETUNING_CONTRACT;
PASS_LEADING_QUADRUPOLE_WAVEFORM_AND_POWER_COEFFICIENT_CONDITIONALLY_ON_P_ONE_P_TWO_P_THREE;
THE_RETARDED_FAR_WAVE_IS_H_TT_IJ_EQUALS_TWO_G_EFF_OVER_C_TO_THE_FOUR_R_TIMES_Q_DOUBLE_DOT_TT_IJ;
THE_QUADRATIC_WAVE_LEDGER_IS_C_CUBED_OVER_THIRTY_TWO_PI_G_EFF_TIMES_H_DOT_TT_IJ_H_DOT_TT_IJ;
THE_ANGULAR_TT_PROJECTOR_IDENTITY_FIXES_THE_TOTAL_POWER_TO_G_EFF_OVER_FIVE_C_TO_THE_FIVE_TIMES_THE_AVERAGE_OF_Q_TRIPLE_DOT_IJ_Q_TRIPLE_DOT_IJ;
NO_FREE_RADIATION_AMPLITUDE_OR_POWER_COEFFICIENT_SURVIVES;
TOTAL_WRITE_ENERGY_CONSERVATION_KILLS_MONOPOLE_RADIATION;
CENTER_OF_MASS_CONSERVATION_KILLS_TENSOR_DIPOLE_RADIATION;
G_H5_KILLS_SCALAR_AND_VECTOR_RADIATIVE_DIPOLE_CHANNELS;
G_H2_KILLS_A_COMPACTNESS_DEPENDENT_MONOPOLE_CHARGE_INSIDE_THE_FROZEN_CONTRACT;
PASS_CIRCULAR_BINARY_POWER_AND_ENERGY_BALANCE;
PASS_ECCENTRIC_KEPLER_QUADRUPOLE_ENHANCEMENT;
THE_ENHANCEMENT_IS_ONE_PLUS_SEVENTY_THREE_OVER_TWENTY_FOUR_E_SQUARED_PLUS_THIRTY_SEVEN_OVER_NINETY_SIX_E_TO_THE_FOUR_DIVIDED_BY_ONE_MINUS_E_SQUARED_TO_THE_SEVEN_HALVES;
PASS_BINARY_PULSAR_LEADING_FORMULA_REGRESSION;
THE_FROZEN_FORMULA_GIVES_MINUS_TWO_POINT_FOUR_ZERO_TWO_ONE_E_MINUS_TWELVE_FOR_PSR_B1913_PLUS_SIXTEEN;
THE_FROZEN_FORMULA_GIVES_MINUS_ONE_POINT_TWO_FOUR_SEVEN_EIGHT_E_MINUS_TWELVE_FOR_THE_DOUBLE_PULSAR_AT_LEADING_ORDER;
THE_FROZEN_FORMULA_GIVES_MINUS_TWO_POINT_SEVEN_FIVE_FOUR_E_MINUS_FOURTEEN_FOR_PSR_J1738_PLUS_ZERO_THREE_THREE_THREE;
PUBLISHED_CORRECTED_TIMING_OF_B1913_PLUS_SIXTEEN_AGREES_WITH_THE_QUADRUPOLE_PREDICTION_AT_THE_REPORTED_ZERO_POINT_NINE_NINE_EIGHT_THREE_PLUS_OR_MINUS_ZERO_POINT_ZERO_ZERO_ONE_SIX_RATIO;
PUBLISHED_DOUBLE_PULSAR_TIMING_VALIDATES_THE_QUADRUPOLAR_DESCRIPTION_AT_ONE_POINT_THREE_E_MINUS_FOUR_NINETY_FIVE_PERCENT_CONFIDENCE_AFTER_REQUIRED_HIGHER_ORDER_AND_KINEMATIC_CORRECTIONS;
THE_ASYMMETRIC_PSR_J1738_PLUS_ZERO_THREE_THREE_THREE_SYSTEM_IS_CONSISTENT_WITH_THE_QUADRUPOLE_PREDICTION_AND_SHOWS_NO_REQUIRED_DIPOLE_EXCESS;
PARTIAL_PASS_FULL_BINARY_PULSAR_HOSTILE_TEST;
THE_LEADING_QUADRUPOLE_COEFFICIENT_NO_DIPOLE_STRUCTURE_AND_PRIMARY_TIMING_REGRESSIONS_ARE_EARNED;
THE_FULL_POST_NEWTONIAN_RADIATIVE_HIERARCHY_TIMING_MODEL_SPIN_DOWN_MASS_LOSS_GALACTIC_CORRECTIONS_MEMORY_TAILS_MERGER_AND_RINGDOWN_ARE_NOT_INDEPENDENTLY_DERIVED;
NO_COEFFICIENT_SOURCE_CHARGE_WAVE_MODE_OR_ECCENTRICITY_FUNCTION_WAS_RETUNED;
P_ONE_P_TWO_AND_P_THREE_REMAIN_EXPLICIT_PREMISES;
G_H7_NEUTRON_STAR_STRUCTURE_TIDAL_RESPONSE_AND_STABILITY_HOSTILE_TEST_READY
```

## Frozen entry

The frozen field equation remained unchanged:

\[
G_{\mu\nu}[g(\Sigma)]
=
\frac{8\pi G_{\rm eff}}{c^4}\mathcal W_{\mu\nu}.
\]

No radiation coefficient, dipole charge, eccentricity function, or binary-specific coupling was added.

## Far waveform and power

Source conservation converts the retarded stress integral into the second mass moment:

\[
\boxed{
h_{ij}^{\rm TT}
=
\frac{2G_{\rm eff}}{c^4R}
\ddot Q_{ij}^{\rm TT}
}.
\]

The quadratic wave ledger is

\[
F=
\frac{c^3}{32\pi G_{\rm eff}}
\left\langle \dot h_{ij}^{\rm TT}\dot h_{ij}^{\rm TT}\right\rangle.
\]

The angular TT projector identity fixes

\[
\boxed{
P_{\rm GW}
=
\frac{G_{\rm eff}}{5c^5}
\left\langle
\dddot Q_{ij}\dddot Q_{ij}
\right\rangle
}.
\]

No free luminosity coefficient survives.

## Multipole hierarchy

For an isolated source,

\[
\dot M=0,
\qquad
\ddot D_i=M\ddot X_i^{\rm CM}=0.
\]

Therefore tensor radiation has no monopole or dipole channel. G-H5 excluded independent scalar and vector radiation, and G-H2 excluded a compactness-dependent monopole charge. The leading radiative moment is quadrupolar.

## Binary formula

For \(M=m_1+m_2\) and \(\mu=m_1m_2/M\),

\[
\langle P\rangle
=
\frac{32}{5}
\frac{G_{\rm eff}^4\mu^2M^3}{c^5a^5}
f(e),
\]

with

\[
f(e)=
\frac{
1+\frac{73}{24}e^2+\frac{37}{96}e^4
}{
(1-e^2)^{7/2}
}.
\]

Direct Fourier differentiation of eccentric Kepler orbits reproduced this function through \(e=0.8\).

Energy balance gives

\[
\dot P_b
=
-\frac{192\pi}{5}
T_\odot^{5/3}
\left(\frac{P_b}{2\pi}\right)^{-5/3}
\frac{m_1m_2}{(m_1+m_2)^{1/3}}
f(e).
\]

## Binary-pulsar regressions

- **PSR B1913+16:** leading frozen prediction \(-2.4021\times10^{-12}\). The published corrected observed/predicted ratio is \(0.9983\pm0.0016\).
- **Double Pulsar J0737-3039A/B:** leading frozen prediction \(-1.24781\times10^{-12}\). The published analysis, including corrections beyond this gate, validates the quadrupolar description at \(1.3\times10^{-4}\) at 95% confidence.
- **PSR J1738+0333:** leading frozen prediction \(-2.754\times10^{-14}\). The published intrinsic value \((-25.9\pm3.2)\times10^{-15}\) is consistent with the published prediction \((-27.7^{+1.5}_{-1.9})\times10^{-15}\), with no required dipole excess.

## Boundary

The leading quadrupole amplitude, luminosity coefficient, eccentric enhancement, and no-dipole structure pass.

The full post-Newtonian radiation hierarchy, observational timing corrections, nonlinear memory, tails, merger phasing, horizon absorption, and ringdown remain open.
