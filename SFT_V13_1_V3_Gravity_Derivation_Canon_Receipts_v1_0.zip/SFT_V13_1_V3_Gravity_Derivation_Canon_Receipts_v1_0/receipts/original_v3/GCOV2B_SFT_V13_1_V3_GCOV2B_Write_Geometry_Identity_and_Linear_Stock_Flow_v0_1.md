# SFT V13.1-V3 — G-COV-2B
## Write–Geometry Identity and Linear Stock–Flow v0.1

Generated: 2026-07-20 20:15:30

```text
G_COV_2B_VERDICT =
PASS_COMMON_FREEZE_AND_INDEPENDENT_BRANCH_ISOLATION;
THE_NAIVE_LOCAL_D_SIGMA_MUNU_D_TAU_EQUALS_W_MUNU_IDENTITY_IS_KILLED;
IT_FAILS_STATIC_SOURCE_AGE_NULL_SUPPORT_AND_NO_PREFERRED_FOLIATION_GUARDRAILS;
WRITE_GEOMETRY_IDENTITY_SURVIVES_AS_A_CAUSAL_SPACETIME_HISTORY_RELATION;
THE_GENERAL_LOCAL_LINEAR_SECOND_ORDER_LORENTZ_OPERATOR_ON_A_SYMMETRIC_RANK_TWO_CARRIER_HAS_FIVE_COEFFICIENTS;
IDENTICAL_DIVERGENCE_FREEDOM_REDUCES_THE_COEFFICIENTS_TO_A_TWO_PARAMETER_FAMILY;
LINEAR_WRITE_ADDRESS_RELABELING_INVARIANCE_REDUCES_THE_FAMILY_TO_ONE_COEFFICIENT_RAY;
THE_UNIQUE_RAY_IS_ONE_MINUS_ONE_ONE_ONE_MINUS_ONE_UP_TO_OVERALL_SCALE;
THE_PROVISIONAL_LINEAR_EQUATION_IS_E_ONE_MUNU_OF_SIGMA_EQUALS_KAPPA_W_MUNU;
IN_THE_HARMONIC_REPRESENTATIVE_IT_REDUCES_TO_BOX_BAR_SIGMA_MUNU_EQUALS_KAPPA_W_MUNU;
THE_RETARDED_SOLUTION_PROPAGATES_ON_THE_ONE_SPEED_LIGHT_CONE;
A_STATIC_POINT_SOURCE_PRODUCES_A_ONE_OVER_R_FIELD_AFTER_CAUSAL_ARRIVAL_WITH_NO_SOURCE_AGE_GROWTH;
NULL_WRITE_SUPPORT_SOURCES_THE_EQUATION_WITHOUT_PROPER_TIME;
TRACE_REVERSAL_OF_DUST_PRODUCES_EQUAL_WEAK_STATIC_CLOCK_AND_SPATIAL_RESPONSES;
TRACE_REVERSAL_OF_ISOTROPIC_RADIATION_PRODUCES_DOUBLE_THE_DUST_CLOCK_SOURCE_WEIGHT;
THE_LINEAR_RELABELING_SYMMETRY_REMAINS_A_CONDITIONAL_MICROSCOPIC_DEBT;
NO_NONLINEAR_COMPLETION_METRIC_MAP_SELF_COUPLING_OR_PHYSICAL_DEGREE_COUNT_EARNED;
G_COV_2C_BRANCH_COMPARISON_READY
```

The dual-aspect ontology survives, but the naive equation

\[
\frac{d\Sigma_{\mu\nu}}{d\tau}={\cal W}_{\mu\nu}
\]

does not. It makes stationary gravity grow with source age, excludes null support, and risks a preferred time slicing.

For a symmetric carrier, the most general local linear second-order Lorentz operator has five coefficients. Requiring identical divergence freedom and invariance under

\[
\delta\Sigma_{\mu\nu}
=
\partial_\mu\xi_\nu+\partial_\nu\xi_\mu
\]

fixes the unique coefficient ray

\[
\boxed{(a,b,c,d,e)\propto(1,-1,1,1,-1)}.
\]

The provisional weak-field stock–flow equation is

\[
\boxed{{\cal E}^{(1)}_{\mu\nu}[\Sigma]=\kappa_\Sigma{\cal W}_{\mu\nu}}.
\]

With

\[
\bar\Sigma_{\mu\nu}
=
\Sigma_{\mu\nu}-\frac12\eta_{\mu\nu}\Sigma
\]

and \(\partial^\mu\bar\Sigma_{\mu\nu}=0\), it reduces to

\[
\boxed{\square\bar\Sigma_{\mu\nu}=\kappa_\Sigma{\cal W}_{\mu\nu}}.
\]

The retarded solution is a causal spacetime history integral. A switched-on static source establishes a \(1/r\) field after the causal front arrives, without later growth. Dust produces equal weak clock and spatial responses, while isotropic radiation has twice the dust clock-source weight.

The result remains conditional on the microscopic write-address relabeling symmetry. No nonlinear equation or metric constitutive map has been derived.
