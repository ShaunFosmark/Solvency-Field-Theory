# SFT V13.1-V3 Gravity Hostile Program
## G-H7 — Neutron-Star Structure, Tidal Response, and Stability Hostile Test v0.1

Generated: 2026-07-21 00:42:01

```text
G_H7_VERDICT =
PASS_FROZEN_EQUATION_HASH_AND_NO_RETUNING_CONTRACT;
PASS_COLD_NEUTRON_STAR_STRUCTURE_AND_TOV_LEDGER_CONDITIONALLY_ON_P_ONE_P_TWO_P_THREE;
REST_ENERGY_INTERNAL_ENERGY_PRESSURE_AND_GRAVITATIONAL_BINDING_ENTER_ONE_TOTAL_SOURCE_AND_ONE_ASYMPTOTIC_MASS;
PASS_ONE_PARAMETER_TURNING_POINT_STABILITY_REGRESSION;
THE_FIRST_MAXIMUM_OF_M_OF_RHO_C_SEPARATES_THE_AUDITED_STABLE_AND_UNSTABLE_BRANCHES;
PASS_RELATIVISTIC_L_TWO_TIDAL_LOVE_RESPONSE;
K_TWO_AND_LAMBDA_ARE_FIXED_BY_THE_SAME_METRIC_EQUATION_AND_EQUATION_OF_STATE_WITH_NO_NEW_GRAVITY_COEFFICIENT;
PASS_FIVE_FAMILY_UNTUNED_PUBLISHED_PIECEWISE_POLYTROPE_SWEEP;
THE_SWEEP_INCLUDES_SLY_AP4_MPA1_H4_AND_MS1;
PASS_EXISTENCE_OF_AN_UNTUNED_OBSERVATIONALLY_VIABLE_MATTER_MODEL;
THE_PUBLISHED_MPA1_FIT_SUPPORTS_A_MAXIMUM_MASS_NEAR_TWO_POINT_FOUR_SEVEN_SOLAR_MASSES;
ITS_ONE_POINT_FOUR_SOLAR_MASS_RADIUS_IS_NEAR_TWELVE_POINT_ONE_KILOMETERS;
ITS_ONE_POINT_FOUR_SOLAR_MASS_TIDAL_DEFORMABILITY_IS_NEAR_FIVE_POINT_ONE_EIGHT_E_TWO;
ITS_TWO_POINT_ZERO_EIGHT_SOLAR_MASS_RADIUS_IS_NEAR_TWELVE_POINT_TWO_KILOMETERS;
THESE_VALUES_PASS_THE_SIMPLE_J0740_MASS_UPDATED_NICER_RADIUS_AND_GW170817_DERIVED_CANONICAL_LAMBDA_PROXY_USED_BY_THIS_GATE;
PASS_OBSERVATIONAL_DISCRIMINATION_WITHOUT_RESCUE;
THE_OTHER_AUDITED_EOS_FITS_EXPOSE_HIGH_MASS_RADIUS_TIDAL_OR_CAUSALITY_TENSIONS_RATHER_THAN_TRIGGERING_GRAVITY_RETUNING;
PASS_SINGLE_MONOPOLE_EFFACEMENT_ACROSS_EOS_AND_TIDAL_STRUCTURE;
EOS_DEPENDENT_BINDING_AND_TIDAL_RESPONSE_CHANGE_M_R_AND_LAMBDA_BUT_DO_NOT_CREATE_A_SECOND_GRAVITATIONAL_CHARGE;
PARTIAL_PASS_NEUTRON_STAR_CLOSURE_CONTINUITY;
THE_MONOPOLE_LEDGER_SUPPORTS_SELF_MAINTAINING_GRAVITATIONAL_CLOSURE_BUT_DOES_NOT_PROVE_IDENTITY_WITH_PARTICLE_FOUR_PI_TOPOLOGICAL_CLOSURE;
PARTIAL_PASS_FULL_NEUTRON_STAR_HOSTILE_TEST;
THE_COLD_STATIC_STRUCTURE_STABILITY_TIDAL_AND_BROAD_OBSERVATIONAL_REGRESSIONS_ARE_EARNED;
A_NATIVE_SFT_NUCLEAR_EOS_DIRECT_RADIAL_MODE_SPECTRUM_ROTATION_MAGNETISM_TEMPERATURE_SUPERFLUIDITY_PHASE_TRANSITIONS_AND_MERGER_DYNAMICS_REMAIN_OPEN;
NO_EQUATION_COEFFICIENT_SOURCE_CHARGE_TIDAL_RULE_OR_EOS_PARAMETER_WAS_RETUNED;
P_ONE_P_TWO_AND_P_THREE_REMAIN_EXPLICIT_PREMISES;
G_H8_COLLAPSE_HORIZON_AND_RINGDOWN_HOSTILE_TEST_READY
```

## Frozen entry

The gravity equation remained unchanged:

\[
G_{\mu\nu}[g(\Sigma)]
=
\frac{8\pi G_{\rm eff}}{c^4}
\mathcal W_{\mu\nu}.
\]

Five published Read-et-al. piecewise-polytropic EOS fits were used without changing their parameters:

```text
SLy
AP4
MPA1
H4
MS1
```

The EOS is matter input. No EOS was fitted to the H7 observational targets.

## Cold equilibrium ledger

The structure equations are

\[
\frac{dm}{dr}=4\pi r^2\epsilon,
\]

\[
\boxed{
\frac{dp}{dr}
=
-
\frac{(\epsilon+p)(m+4\pi r^3p)}
{r(r-2m)}
},
\]

and

\[
\frac{dM_b}{dr}
=
\frac{4\pi r^2\rho_0}
{\sqrt{1-2m/r}}.
\]

Pressure therefore enters twice: in the inertial factor \(\epsilon+p\) and in the active geometric factor \(m+4\pi r^3p\).

The asymptotic exterior still carries one mass \(M\), even though the internal baryon, proper-energy, pressure, and binding inventories differ.

## Stability

Each cold EOS defines a one-parameter sequence labeled by central density.

The first maximum of

\[
M(\rho_c)
\]

is the turning point. The audited branches show

```text
dM/d rho_c > 0 before the first maximum
dM/d rho_c < 0 after the first maximum
```

to the numerical sequence tolerance.

This earns the standard turning-point stability regression. It is not a substitute for a direct radial-mode eigenvalue calculation.

## Tidal response

The static \(l=2\) perturbation obeys

\[
r y'+y^2+yF+r^2Q=0,
\]

with the same background metric and EOS.

At the surface,

\[
k_2=k_2(C,y_R),
\qquad
\boxed{
\Lambda=\frac{2k_2}{3C^5}
}.
\]

No tidal gravity coefficient was added.

Tidal deformability varies strongly with compactness and EOS, while the exterior monopole remains the same type of single mass charge.

## Untuned EOS results

The published MPA1 fit gives approximately

\[
M_{\max}=2.4700\,M_\odot,
\]

\[
R_{1.4}=12.129\,\mathrm{km},
\qquad
\Lambda_{1.4}=509.0,
\]

and

\[
R_{2.08}=12.228\,\mathrm{km}.
\]

It passes this gate's transparent simple joint regression:

```text
J0740 reliable high-mass lower bound
updated NICER high-mass radius interval
GW170817-derived canonical Lambda_1.4 proxy
```

The result is an existence proof that the frozen gravity equation admits an untuned published dense-matter model compatible with those broad constraints.

## Discrimination rather than rescue

The other fits are not forcibly accepted:

- very soft fits can struggle with the high-mass radius or maximum mass;
- very stiff fits can overshoot the tidal-deformability band;
- some high-density fit extensions reach superluminal sound speed near their formal maximum;
- marginal fits remain explicitly marginal.

These are EOS failures or tensions, not reasons to alter gravity.

## Closure-continuity interpretation

The sequences support the monopole-level closure picture:

```text
material and internal energy
plus pressure-supported structure
plus negative gravitational binding
equals one total asymptotic mass
```

Increasing compactness makes the settlement feedback structurally load-bearing, but it does not generate a second gravity charge.

That supports neutron-star gravitational closure as a self-maintaining fixed point at the ledger level.

It does not prove that stellar gravitational closure and particle four-pi topological closure are microscopically the same operator.

## Boundary

H7 earns:

```text
cold relativistic stellar structure
pressure and binding in one source ledger
turning-point stability
relativistic tidal Love response
untuned EOS observational viability
EOS discrimination without gravity retuning
```

It does not earn:

```text
a native SFT nuclear EOS
direct radial eigenfrequencies
rapid rotation
magnetic fields
thermal evolution
superfluidity
phase-transition microphysics
crust failure
or merger dynamics
```
