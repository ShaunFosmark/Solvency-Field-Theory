# SFT V13.1-V3 Gravity Hostile Program
## G-H4 — Frame Dragging and Kerr Hostile Test v0.1

Generated: 2026-07-21 00:02:52

```text
G_H4_VERDICT =
PASS_FROZEN_EQUATION_HASH_AND_NO_RETUNING_CONTRACT;
PASS_WEAK_FRAME_DRAGGING_COEFFICIENT_CONDITIONALLY_ON_P_ONE_P_TWO_P_THREE;
THE_LOCALIZED_ROTATING_WRITE_MOMENTUM_CURRENT_PRODUCES_G_ZERO_I_EQUALS_MINUS_TWO_TIMES_J_CROSS_R_OVER_R_CUBED_IN_GEOMETRIZED_UNITS;
NO_INDEPENDENT_GRAVITOMAGNETIC_COUPLING_OR_VECTOR_FIELD_IS_REQUIRED;
THE_AXISYMMETRIC_FAR_COMPONENT_IS_G_T_PHI_EQUALS_MINUS_TWO_J_SIN_SQUARED_THETA_OVER_R;
PASS_EXACT_KERR_VACUUM_EXISTENCE_AND_WEAK_TO_STRONG_MATCHING;
THE_KERR_METRIC_WITH_J_EQUALS_M_A SATISFIES_THE_FROZEN_VACUUM_EQUATION_AT_ALL_SAMPLED_REGULAR_EXTERIOR_POINTS_TO_AUTOMATIC_DIFFERENTIATION_PRECISION;
THE_A_EQUALS_ZERO_LIMIT_IS_EXACTLY_SCHWARZSCHILD;
THE_EXACT_ZERO_ANGULAR_MOMENTUM_OBSERVER_DRAGGING_RATE_IS_MINUS_G_T_PHI_OVER_G_PHI_PHI;
ITS_FAR_LIMIT_IS_TWO_J_OVER_R_CUBED;
ITS_HORIZON_LIMIT_IS_A_OVER_R_PLUS_SQUARED_PLUS_A_SQUARED;
PASS_KERR_HORIZON_ERGOSURFACE_AND_DETERMINANT_REGRESSIONS;
PASS_PROGRADE_AND_RETROGRADE_EQUATORIAL_CIRCULAR_FREQUENCY_REGRESSIONS;
BOTH_ORBIT_BRANCHES_USE_THE_SAME_MASS_M_AND_SPIN_PARAMETER_A;
PASS_WEAK_GYROSCOPE_LENSE_THIRRING_VECTOR;
NO_METRIC_COEFFICIENT_SOURCE_SPIN_PARAMETER_OR_FRAME_DRAGGING_RULE_WAS_RETUNED;
PARTIAL_PASS_KERR_HOSTILE_TEST;
EXACT_KERR_EXISTENCE_AND_MATCHING_ARE_EARNED;
AN_INDEPENDENT_GLOBAL_KERR_UNIQUENESS_DERIVATION_IS_NOT_EARNED;
ROTATING_COLLAPSE_NONLINEAR_STABILITY_RINGDOWN_HORIZON_THERMODYNAMICS_COSMIC_CENSORSHIP_AND_REALISTIC_ROTATING_STAR_INTERIORS_REMAIN_OPEN;
P_ONE_P_TWO_AND_P_THREE_REMAIN_EXPLICIT_PREMISES;
G_H5_WAVE_SPEED_AND_POLARIZATION_HOSTILE_TEST_READY
```

## 1. Frozen entry

The conditionally frozen equation was held unchanged:

\[
G_{\mu\nu}[g(\Sigma)]
=
\frac{8\pi G_{\rm eff}}{c^4}
{\cal W}_{\mu\nu}.
\]

The source, metric map, normalization, and premises P1–P3 were not altered.

The hostile questions were:

```text
Does rotating write-momentum produce the correct mixed metric coefficient?

Does that weak field continue into an exact rotating vacuum?

Does exact Kerr return to both Schwarzschild and the weak frame-dragging field?

Do null/timelike rotating landmarks use the same M and J?
```

## 2. Native mixed-sector route

Angular momentum appears in the active write-momentum flux through \({\cal W}_{0i}\).

The G-COV-1 decomposition already reserved a mixed three-vector sector:

\[
q_i
\longleftrightarrow
\Sigma_{0i}.
\]

In the weak metric map,

\[
g_{0i}=2\Sigma_{0i}+O(\Sigma^2).
\]

Thus frame dragging is not a new vector field. It is the clock-space cross readout of directional settlement history.

For a localized stationary rotating source, the weak equation gives

\[
\bar h_{0i}(\mathbf x)
=
-4\int
\frac{j_i(\mathbf x')}{|\mathbf x-\mathbf x'|}
\,d^3x'.
\]

The leading angular-momentum term is

\[
\boxed{
g_{0i}
=
-2\frac{(\mathbf J\times\mathbf r)_i}{r^3}
}
\]

in geometrized units.

For \(\mathbf J\) along the symmetry axis,

\[
\boxed{
g_{t\phi}
=
-\frac{2J}{r}\sin^2\theta
+
O(r^{-2}).
}
\]

A direct rotating-ring current integration converged to this coefficient without fitting it.

## 3. Gyroscope and inertial-frame dragging

Define

\[
\mathbf A_J
=
\frac{\mathbf J\times\mathbf r}{r^3}.
\]

Since \(\mathbf g_0=-2\mathbf A_J\), weak gyroscope precession is

\[
\boxed{
\boldsymbol\Omega_{\rm LT}
=
\frac{3\mathbf n(\mathbf J\cdot\mathbf n)-\mathbf J}{r^3}
}
\]

in geometrized units, or

\[
\boxed{
\boldsymbol\Omega_{\rm LT}
=
\frac{G_{\rm eff}}{c^2r^3}
\left[
3\mathbf n(\mathbf J\cdot\mathbf n)-\mathbf J
\right]
}
\]

in SI units.

The far angular velocity of dragged zero-angular-momentum frames is

\[
\boxed{
\omega_{\rm drag}
=
\frac{2G_{\rm eff}J}{c^2r^3}
}
\]

on the equatorial far field.

These are different operational frame-dragging observables derived from the same mixed metric component.

## 4. Exact Kerr continuation

In geometrized units, define

\[
\Sigma_K=r^2+a^2\cos^2\theta,
\qquad
\Delta=r^2-2Mr+a^2,
\qquad
J=Ma.
\]

The Boyer–Lindquist metric is

\[
\begin{aligned}
ds^2={}&
-\left(1-\frac{2Mr}{\Sigma_K}\right)dt^2
-\frac{4Mar\sin^2\theta}{\Sigma_K}dt\,d\phi\\
&+\frac{\Sigma_K}{\Delta}dr^2
+\Sigma_K d\theta^2\\
&+
\left(
r^2+a^2
+\frac{2Ma^2r\sin^2\theta}{\Sigma_K}
\right)
\sin^2\theta\,d\phi^2.
\end{aligned}
\]

No new coefficient appears. Its far cross component is

\[
g_{t\phi}
=
-\frac{2J}{r}\sin^2\theta
+
O(r^{-2}),
\]

exactly matching the independently derived weak rotating-current field.

Automatic differentiation of the full metric produced Ricci residuals below the gate tolerance at every sampled exterior point, including rapidly rotating cases.

## 5. Schwarzschild and determinant regressions

At

\[
a=0,
\]

the metric reduces exactly to Schwarzschild.

The determinant identity is

\[
\boxed{
\det g
=
-\Sigma_K^2\sin^2\theta.
}
\]

That identity passed throughout the sampled exterior.

## 6. Horizon and ergoregion

The horizon roots satisfy

\[
\Delta=0,
\]

so

\[
r_\pm
=
M\pm\sqrt{M^2-a^2}.
\]

A Kerr black-hole horizon exists for

\[
|a|\le M.
\]

The outer stationary-limit surface is

\[
r_E(\theta)
=
M+
\sqrt{M^2-a^2\cos^2\theta}.
\]

It lies outside or on the horizon and is the surface where \(g_{tt}=0\).

For a zero-angular-momentum observer,

\[
\omega
=
-\frac{g_{t\phi}}{g_{\phi\phi}}
=
\frac{2Mar}{A_K},
\]

where

\[
A_K
=
(r^2+a^2)^2
-
a^2\Delta\sin^2\theta.
\]

Far from the source,

\[
\omega
\rightarrow
\frac{2J}{r^3}.
\]

At the outer horizon,

\[
\boxed{
\Omega_H
=
\frac{a}{r_+^2+a^2}
=
\frac{a}{2Mr_+}.
}
\]

The weak, exact exterior, and horizon rotation rates are therefore different limits of one metric cross term.

## 7. Rotating circular geodesics

For equatorial circular motion, the exact branches are

\[
\boxed{
\Omega_+
=
\frac{\sqrt M}
{r^{3/2}+a\sqrt M}
}
\]

for prograde motion, and

\[
\boxed{
\Omega_-
=
-\frac{\sqrt M}
{r^{3/2}-a\sqrt M}
}
\]

for retrograde motion.

Both use the same \(M\) and \(a\).

At \(a=0\),

\[
\Omega_\pm
=
\pm\sqrt{\frac{M}{r^3}},
\]

recovering the G-H3 circular-orbit result.

Frame dragging therefore appears as a direction-dependent continuation in one rotating geometry, not as separate prograde and retrograde gravity laws.

## 8. What passed and what did not

The gate earns:

```text
the weak mixed-sector coefficient

the absence of a second gravitomagnetic coupling

exact Kerr as a vacuum solution of the frozen equation

Schwarzschild and far-field regressions

the horizon and ergosurface relations

the exact ZAMO frame-dragging rate

the prograde/retrograde circular-frequency split
```

It does not independently rederive the full global Kerr uniqueness theorem.

It also does not yet establish:

```text
formation from rotating collapse

nonlinear stability

quasinormal ringdown

horizon thermodynamics

cosmic censorship

or realistic rotating-neutron-star interiors
```

The correct verdict is therefore a partial hostile pass: frame dragging and exact Kerr existence close, while uniqueness and dynamics remain open.
