# SFT V13.1-V3 Gravity Hostile Program
## G-H5 — Wave Speed and Polarization Hostile Test v0.1

Generated: 2026-07-21 00:19:59

```text
G_H5_VERDICT =
PASS_FROZEN_EQUATION_HASH_AND_NO_RETUNING_CONTRACT;
PASS_WAVE_SPEED_AND_POLARIZATION_HOSTILE_TEST_CONDITIONALLY_ON_P_ONE_P_TWO_P_THREE;
IN_VACUUM_THE_HARMONIC_TRACE_REVERSED_CARRIER_OBEYS_BOX_BAR_H_MUNU_EQUALS_ZERO;
THE_CHARACTERISTIC_COVECTOR_IS NULL;
THE_PHASE_AND_GROUP_SPEEDS_EQUAL_THE_ONE_SPEED_C;
THE_TEN_COMPONENT_SYMMETRIC_AMPLITUDE_IS_REDUCED_BY_FOUR_HARMONIC_CONSTRAINTS_AND_FOUR_RESIDUAL_ADDRESS_RELABELINGS;
THE_PHYSICAL_RADIATIVE_QUOTIENT_HAS_DIMENSION_TWO;
THE_TWO SURVIVING CURVATURE POLARIZATIONS_ARE_PLUS_AND_CROSS;
BOTH_ARE_TRANSVERSE_AND_TRACE_FREE;
AN_INDEPENDENT_SCALAR_BREATHING_MODE_DOES_NOT_SURVIVE;
LONGITUDINAL_SCALAR_AND_VECTOR_POLARIZATIONS_DO_NOT_SURVIVE;
NO_HIDDEN_SETTLEMENT_POLARIZATION_IS_ALLOWED_INSIDE_THE_NO_EXTRA_STATE_PREMISE;
PASS_ONE_SPEED_LOCALIZED_WAVE_PACKET_REGRESSION;
PASS_EXACT_RICCI_FLAT_PP_WAVE_REGRESSION;
THE_EXACT_PROFILE_H_EQUALS_A_OF_U_TIMES_X_SQUARED_MINUS_Y_SQUARED_PLUS_TWO_B_OF_U_X_Y_CARRIES_ARBITRARY_PLUS_AND_CROSS_WAVEFORMS;
ITS_WAVEFRONTS_U_EQUALS_CONSTANT_ARE NULL;
NO_ADDED_FIELD_MASS_TERM_PROPAGATION_COEFFICIENT_OR_POLARIZATION_RULE_WAS_INTRODUCED;
THE_QUADRUPOLE_POWER_COEFFICIENT_BINARY_ORBITAL_DECAY_RADIATION_REACTION_MEMORY_TAILS_AND_RINGDOWN_REMAIN OPEN;
P_ONE_P_TWO_AND_P_THREE_REMAIN_EXPLICIT_PREMISES;
G_H6_QUADRUPOLE_POWER_AND_BINARY_PULSAR_HOSTILE_TEST_READY
```

## 1. Frozen entry

The conditionally frozen equation remained unchanged:

\[
G_{\mu\nu}[g(\Sigma)]
=
\frac{8\pi G_{\rm eff}}{c^4}
{\cal W}_{\mu\nu}.
\]

No wave-speed coefficient, mass term, scalar field, vector field, or polarization rule was added.

The hostile questions were:

```text
Do vacuum disturbances propagate exactly at c?

How many physical radiative degrees survive?

Does scalar breathing survive?

Do longitudinal or vector modes survive?

Can the same equation support an exact nonlinear vacuum wave?
```

## 2. Vacuum wave equation

Write

\[
g_{\mu\nu}
=
\eta_{\mu\nu}
+
h_{\mu\nu}
\]

and define the trace-reversed perturbation

\[
\bar h_{\mu\nu}
=
h_{\mu\nu}
-\frac12\eta_{\mu\nu}h.
\]

In the harmonic representative,

\[
\partial^\mu\bar h_{\mu\nu}=0.
\]

The frozen vacuum equation becomes

\[
\boxed{
\Box\bar h_{\mu\nu}=0.
}
\]

For a plane wave,

\[
\bar h_{\mu\nu}
=
A_{\mu\nu}e^{ik_\alpha x^\alpha},
\]

a nonzero amplitude requires

\[
\boxed{
k_\mu k^\mu=0.
}
\]

Therefore,

\[
\boxed{
\omega^2=c^2|\mathbf k|^2
}
\]

and both phase and group velocities are \(c\).

## 3. Physical mode count

A symmetric metric perturbation has ten components.

The harmonic conditions impose four independent relations.

Residual coordinate/address relabelings satisfying

\[
\Box\xi_\mu=0
\]

remove four further directions.

Thus,

\[
\boxed{
10-4-4=2.
}
\]

For a wave moving along \(+z\), the full harmonic solution space was explicitly decomposed into:

```text
four residual gauge directions
plus polarization
cross polarization
```

No additional physical quotient direction remained.

## 4. Tidal polarizations

The observable wave effect is the transverse tidal matrix

\[
R_{0i0j}
=
-\frac12\ddot h^{\rm TT}_{ij}.
\]

The surviving bases are

\[
e^+_{ij}
=
\begin{pmatrix}
1&0&0\\
0&-1&0\\
0&0&0
\end{pmatrix},
\]

and

\[
e^\times_{ij}
=
\begin{pmatrix}
0&1&0\\
1&0&0\\
0&0&0
\end{pmatrix}.
\]

Both are transverse:

\[
e_{iz}=0,
\]

and trace-free:

\[
e^i{}_i=0.
\]

A rotation about the propagation direction mixes them with angle \(2\psi\), confirming their spin-two character.

The breathing, vector, and longitudinal tidal bases have zero projection into the physical TT plane.

## 5. Meaning of the excluded components

Near a source, constrained metric components may look scalar or longitudinal. That does not make them independent radiation.

The hostile question concerns freely propagating vacuum curvature.

Inside the frozen metric-only no-extra-state theory:

```text
breathing scalar:
no physical vacuum quotient direction

longitudinal scalar:
constraint/gauge, not radiation

vector-x and vector-y:
constraint/gauge, not radiation

plus and cross:
physical curvature
```

A new breathing mode would require a separate scalar state. A new vector mode would require additional vector state. Both violate P3.

## 6. Numerical one-speed packet

A localized right-moving packet

\[
h(z,t)=f(z-ct)
\]

was propagated and tested directly.

The packet centroid moved at

\[
v=c
\]

to numerical precision, and the wave-equation residual remained below the gate tolerance.

No dispersion or additional propagation speed appeared.

## 7. Exact vacuum pp-wave

The gate also tested the exact metric

\[
ds^2
=
-2\,du\,dv
+
dx^2+dy^2
+
H(u,x,y)du^2.
\]

Its only possible Ricci component is

\[
R_{uu}
=
-\frac12(H_{,xx}+H_{,yy}).
\]

Choose

\[
\boxed{
H
=
A(u)(x^2-y^2)
+
2B(u)xy.
}
\]

Then

\[
H_{,xx}+H_{,yy}=0,
\]

so the metric is exactly Ricci-flat for arbitrary waveforms \(A(u)\) and \(B(u)\).

Its physical curvature components are

\[
R_{uxux}=-A(u),
\]

\[
R_{uyuy}=+A(u),
\]

\[
R_{uxuy}=-B(u).
\]

These are exactly the plus and cross tidal patterns.

Since

\[
u=\frac{ct-z}{\sqrt2},
\]

the exact wavefronts \(u=\text{constant}\) are null and propagate at \(c\).

## 8. Result boundary

G-H5 earns:

```text
one-speed null propagation

exactly two physical radiative degrees

plus and cross polarization only

no scalar breathing mode

no longitudinal or vector vacuum modes

an exact nonlinear Ricci-flat wave with arbitrary plus/cross profiles
```

It does not yet earn:

```text
the quadrupole luminosity coefficient

binary-pulsar orbital decay

radiation reaction

nonlinear memory

curved-background tail structure

or complete black-hole ringdown
```

Those require the source-generation and strong-field radiative gates.
