# SFT V11.2 v2 - Retarded Dent Field Program

**Status:** Finalized sector snapshot for archival upload.  
**Date:** 2026-05-10  
**Scope:** V11.2A through V11.2N2 computational ledger and claim calibration.

## Abstract

V11.2 v2 consolidates the Retarded Dent Field / quantum-foundations sector of Solvency Field Theory (SFT). The program tests whether interference, trajectory guidance, decoherence, uncertainty scaling, Born equivariance, de Broglie action phase, quantum-potential force geometry, Bell/no-signaling boundary grammar, spin-holonomy entanglement, Born-relaxation mechanism seeds, and the action-phase current bridge can be represented in a coherent SFT-compatible architecture.

The central calibrated result is: V11.2 has a coherent single-particle plus boundary-correlation architecture at representation/toy level. It does not yet derive the maintained action phase from the V11.1B lag-settlement equation, does not close Born origin, and does not provide full detector microphysics or full relativistic boundary-update dynamics.

## Core architecture

The V11.2 stack now supports the following bridge:

```text
Compton/action clock phase S
    -> grad S
    -> v_Q = Im(Psi* grad Psi)/|Psi|^2
    -> Born-equivariant guidance
    -> interference, decoherence, uncertainty, and Bell-channel structure
```

The native V11.1B settlement-to-action-phase bridge remains open:

```text
V11.1B settlement residual Lambda
    -> maintained action phase S
    -> grad S
    -> quantum current / Born-equivariant flow
```

## Claim levels

- **Closed at representation/toy level:** interference, guided trajectories, decoherence channels, uncertainty scale, Born equivariance, de Broglie carrier, pure-state quantum-potential force reconstruction, Bell/no-signaling boundary grammar, spin-holonomy Bell bridge, and action-phase current bridge.
- **Seeded but not derived:** Born relaxation mechanism through mixing-linked coarse-grained H decrease; boundary measurement channel consistency; native current via maintained action phase.
- **Open:** Born-rule origin, V11.1B settlement residual -> action phase S, detector microphysics, full relativistic covariance/update dynamics, and physical creation/update of boundary singlets.

## Result ledger

| Script | Gate | Status | Result | Guardrail |
|---|---|---|---|---|
| V11.2A | Quantitative double-slit kernel | PASS | Correlated two-path dent phase kernel reproduces Fraunhofer double-slit law; local/aperture-only guardrails fail. | Kernel grammar pass; parent derivation not closed. |
| V11.2B | Settlement parent support | PASS | Clocked/coherent settlement residual can support the correlated two-path kernel and de Broglie phase slope. | Carrier/Born rule not derived in B. |
| V11.2C | Localized shot-building | PASS | Localized detections sampled from V11.2 density build the interference pattern statistically. | Sampling visualization, not mechanism derivation. |
| V11.2D | Trajectory dent guidance | PASS | Guided trajectories populate propagated coherent field density; free/local-force guardrails do not reproduce it. | Architecture/guidance toy, not full native dynamics. |
| V11.2E | Which-path decoherence | PASS | Detector distinguishability suppresses fringes continuously; physical-kick guardrails separate scattering from phase decoherence. | Measurement microphysics remains open. |
| V11.2F | Single-slit uncertainty | PASS | Single-slit diffraction/momentum spread reproduces the uncertainty scale. | Scale/gate result, not a full uncertainty theorem. |
| V11.2G | Born equivariance pressure test | PASS | Born-initialized guided ensembles remain distributed like propagated densities; non-Born guardrail remains distinguishable. | Born origin/relaxation not derived. |
| V11.2H | de Broglie/action carrier | PASS | Lorentz-projected Compton/action phase selects k=p/hbar and the double-slit carrier Delta phi=k Delta ell. | Full momentum dynamics not derived. |
| V11.2I | Quantum-potential force reconstruction | PASS | Pure-state material acceleration matches -(1/k) grad Q[rho] away from nodes. | Pure-state only; density-matrix measurement dynamics open. |
| V11.2J | Bell/no-signaling boundary grammar | PASS | Boundary singlet kernel reaches Tsirelson and preserves no-signaling; local shared-variable guardrail obeys CHSH <= 2. | Boundary kernel inserted, not derived in J. |
| V11.2K | Spin-holonomy Bell bridge | PASS | V11.9 singlet spinor/projector machinery generates the V11.2J Bell kernel for random 3D axes. | Physical creation/update of singlet remains open. |
| V11.2L | Boundary measurement channels | PASS | Zero-total spin selection, measurement order invariance, local detector no-signaling, and Bell guardrails pass. | Representation/channel level only; dynamics open. |
| V11.2M | Naive Born relaxation attempt | FAIL/CHECK | Naive multimode flow failed Born-control preflight; relaxation result invalid. | Kept as diagnostic/cautionary failure. |
| V11.2M2 | Equivariance-safe Born relaxation retest | PASS/CHECK | Adaptive unclipped torus preflight preserves Born; non-Born relaxation is mild and interpretable but not closed. | Born origin remains open. |
| V11.2M3 | Mixing-rate Born relaxation scan | PASS_MECHANISM | Among preflight-valid modes, Hf/H0 decreases systematically with mixing; best ratio about 0.39. | Mechanism seed, not Born-rule derivation. |
| V11.2N | Native lag-current cascade | PARTIAL/CHECK | Density-only lag correctly fails to reproduce quantum current; action bridge failed due to phase extraction/scoring issue. | Superseded by N2 for action-current bridge. |
| V11.2N2 | Action-phase current bridge audit | PASS | v_Q = Im(Psi*grad Psi)//Psi/^2 = grad S validated for controlled and node-masked domains. | Settlement-to-action dynamics still open. |

## Document hierarchy

- **Original V11.2 seed:** Retarded Dent Field Program. Historical concept document.
- **Toy Program Addendum:** Early V11.2 qualitative and numerical toy extension. Historical/supporting document.
- **V11.2 v2 Final:** This integrated sector snapshot, A through N2.
- **V11.2 Results Ledger A-to-N2:** Companion table for script status, claim levels, and guardrails.
- **V11.2 v2 Scripts Repro Pack:** Reproducibility pack containing the scripts used in the A-to-N2 development sequence.

## Recommended Zenodo archive contents

- `SFT_V11_2_Retarded_Dent_Field_Program_v2_Final.pdf`
- `SFT_V11_2_Retarded_Dent_Field_Program_v2_Final.md`
- `SFT_V11_2_Results_Ledger_A_to_N2.pdf`
- `SFT_V11_2_Results_Ledger_A_to_N2.md`
- `SFT_V11_2_v2_Scripts_Repro_Pack.zip`
- `SFT_V11_2_v2_Zenodo_README.md`
- `SFT_V11_2_v2_manifest.csv`
- `SFT_V11_2_v2_zenodo_metadata_draft.json`

## Script manifest

| ID | Filename | Role |
|---|---|---|
| A | `sft_v11_2a_quantitative_double_slit_dent_gate.py` | primary |
| B | `sft_v11_2b_settlement_residual_parent_kernel_test.py` | primary |
| C | `sft_v11_2c_shot_building_particle_firing_visualization_no_tabulate.py` | primary fixed no-tabulate |
| C-original | `sft_v11_2c_shot_building_particle_firing_visualization.py` | historical; may require tabulate |
| D | `sft_v11_2d_trajectory_dent_guidance_toy.py` | primary |
| E | `sft_v11_2e_which_path_decoherence_trajectory_gate.py` | primary |
| F | `sft_v11_2f_single_slit_uncertainty_gate.py` | primary |
| G | `sft_v11_2g_born_equivariance_pressure_test.py` | primary |
| H | `sft_v11_2h_debroglie_carrier_action_phase_origin.py` | primary |
| I | `sft_v11_2i_quantum_potential_dent_force_reconstruction.py` | primary |
| J | `sft_v11_2j_bell_no_signaling_boundary_correlation_toy.py` | primary |
| K | `sft_v11_2k_singlet_spin_holonomy_boundary_kernel_bridge.py` | primary |
| L | `sft_v11_2l_boundary_singlet_measurement_no_signaling_suite.py` | primary |
| M | `sft_v11_2m_born_relaxation_h_theorem_stress_test.py` | diagnostic failed-control script |
| M2 | `sft_v11_2m2_equivariance_safe_born_relaxation_retest.py` | primary preflight retest |
| M3 | `sft_v11_2m3_mixing_rate_born_relaxation_scan_v2.py` | primary patched |
| M3-original | `sft_v11_2m3_mixing_rate_born_relaxation_scan.py` | historical; plotting bug |
| N | `sft_v11_2n_native_lag_current_bridge_cascade.py` | diagnostic; density guardrail plus failed action bridge |
| N2 | `sft_v11_2n2_action_phase_current_bridge_audit_v2.py` | primary patched |
| N2-original | `sft_v11_2n2_action_phase_current_bridge_audit.py` | historical; plane-wave scoring bug |

## Final calibrated statement

V11.2 v2 establishes a coherent representation-level SFT quantum-foundations architecture: retarded dent/settlement support for two-path phase structure, action-phase current guidance, Born-equivariant flow, decoherence and uncertainty gates, and boundary spin-holonomy entanglement grammar. The sector should now be parked as a successful v2 snapshot. Its next true step is V12-level theory work: deriving the maintained action phase S from native lag-settlement dynamics.