# SFT V11.2 v2 - Zenodo Staging README

Date: 2026-05-10

This package is a staging bundle for uploading the SFT V11.2 v2 Retarded Dent Field Program to Zenodo.

## Contents

- `SFT_V11_2_Retarded_Dent_Field_Program_v2_Final.pdf` - finalized sector snapshot.
- `SFT_V11_2_Retarded_Dent_Field_Program_v2_Final.md` - editable source for the final snapshot.
- `SFT_V11_2_Results_Ledger_A_to_N2.pdf` - results ledger companion.
- `SFT_V11_2_Results_Ledger_A_to_N2.md` - editable source for the ledger.
- `SFT_V11_2_v2_Scripts_Repro_Pack.zip` - scripts-only reproducibility bundle.
- `SFT_V11_2_v2_manifest.csv` - manifest of included files and roles.
- `SFT_V11_2_v2_zenodo_metadata_draft.json` - draft metadata to copy into Zenodo.

## Claim calibration

This archive supports the following calibrated claim:

V11.2 v2 establishes a coherent representation-level SFT quantum-foundations architecture, including interference, trajectory guidance, decoherence, uncertainty scale, Born equivariance, action-phase carrier/current bridge, quantum-potential reconstruction, Bell/no-signaling boundary grammar, spin-holonomy Bell bridge, and a Born-relaxation mechanism seed.

It does not claim a full Born-rule derivation, a V11.1B derivation of the maintained action phase S, full detector microphysics, or full relativistic boundary-update dynamics.

## Recommended Zenodo upload notes

- Upload `SFT_V11_2_v2_Zenodo_Package.zip` as the main archive file.
- Choose a license before public release. The package leaves license as `TBD`.
- Suggested title: `Solvency Field Theory V11.2 v2: Retarded Dent Field Program and Quantum-Foundations Results Ledger`.
- Suggested resource type: `Other` or `Software` plus documents, depending on how the repository is organized.

## Reproducibility

The scripts are intended to be run locally with Python, NumPy, pandas, and matplotlib. Some stronger runs are compute-heavy. Failed or diagnostic historical scripts are retained where they are important to the audit trail.
