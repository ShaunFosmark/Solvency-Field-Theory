# SFT V11.2 Results Ledger - A to N2

Generated 2026-05-10 for Shaun Fosmark.

## Primary calibration

Born equilibrium preservation: passed. Born relaxation mechanism: seeded. Born-rule derivation: still open.

## Master ledger

| ID | Question / sector | Outcome | Key result | Claim level | Guardrail / open item |
|---|---|---|---|---|---|
| A | Quantitative double-slit dent kernel | PASS | Two-path correlated dent phase kernel reproduces modulation, fringe spacing, scaling, and beta=2pi/lambda; aperture/local guardrails fail. | QUANTITATIVE_KERNEL_PASS_NOT_PARENT_DERIVATION | Kernel grammar pass; V11.1B parent derivation remains open. |
| B | Settlement parent support for kernel | PASS + CHECK | Clocked settlement Green residual carrying de Broglie/action phase reproduces target modulation (corr 0.999645). Short-memory/decoherence behavior remains a check. | PARENT_KERNEL_SUPPORT_PASS_CARRIER_NOT_DERIVED | Settlement can support phase kernel; carrier and Born rule not derived here. |
| C | Localized shots build density | PASS | 10,000 localized screen events generated; ensemble histogram corr 0.998351 to sampled V11.2 density. | SHOT_BUILDING_VISUALIZATION_NOT_BORN_DERIVATION | Sampling from density is not a Born derivation. |
| D | Trajectory dent guidance | PASS | Deterministic settlement-guided trajectories populate coherent field density (corr 0.994644); free/local guardrails worse. | TRAJECTORY_GUIDANCE_PASS_NOT_BORN_OR_CARRIER_DERIVATION | Does not derive Born rule or carrier. |
| E | Which-path decoherence trajectory gate | PASS | Detector overlap continuously suppresses cross-term; visibility/complementarity errors ~1e-5; trajectory histograms follow partial coherence densities. | TRAJECTORY_DECOHERENCE_PASS_NOT_BORN_OR_MEASUREMENT_DERIVATION | Detector microphysics and Born rule remain open. |
| F | Single-slit uncertainty scale | PASS | Spectrum satisfies Delta x Delta p >= hbar/2 (1.161483); inverse-width scaling slope -1.0; guided trajectories follow density. | UNCERTAINTY_SCALE_PASS_NOT_BORN_OR_CARRIER_DERIVATION | Uncertainty-scale behavior only; lambda=h/p and Born rule remain open. |
| G | Born equivariance pressure test | PASS + GUARDRAIL | Born-initialized ensembles remain Born-like (min corr 0.992065); non-Born does not instantly become Born. | EQUIVARIANCE_PASS_BORN_ORIGIN_NOT_DERIVED | Born equilibrium preservation passed; origin/relaxation open. |
| H | de Broglie carrier/action phase origin | PASS | Lorentz-projected Compton/action phase selects k=p/hbar; worldline phase and dispersion/group velocity gates pass to roundoff. | CARRIER_ORIGIN_ACTION_PHASE_PASS_NOT_FULL_DYNAMICAL_DERIVATION | Kinematic/action-phase selection; deeper momentum dynamics and Born open. |
| I | Quantum potential / dent-force reconstruction | PASS (pure states) | Pure single/double slit material acceleration matches -(1/k) grad Q[rho]; decohered global-Q case diagnostic only. | QUANTUM_POTENTIAL_FORCE_RECONSTRUCTION_PASS_PURE_STATE_ONLY | Mixed/density-matrix measurement dynamics not solved. |
| J | Bell/no-signaling boundary grammar | PASS + GUARDRAIL | Boundary singlet kernel gives CHSH=2sqrt(2), no-signaling, Werner threshold; local dent guardrail stays at CHSH<=2. | BELL_BOUNDARY_GRAMMAR_PASS_NOT_DERIVED_DYNAMICS | Boundary kernel represented, not dynamically derived. |
| K | Singlet spin-holonomy bridge | PASS | V11.9 singlet spinor/projectors generate V11.2J Bell kernel with rotational invariance and no-signaling. | SINGLET_HOLONOMY_BRIDGE_PASS_NOT_BOUNDARY_DYNAMICS_DERIVED | Physical singlet creation/update dynamics remain open. |
| L | Boundary measurement/no-signaling channels | PASS | Zero-total spin projector selects singlet; measurement order invariance and local detector no-signaling pass to roundoff. | BOUNDARY_MEASUREMENT_CHANNELS_PASS_DYNAMICS_NOT_DERIVED | Representation/channel consistency only; physical dynamics open. |
| M | Naive Born relaxation attempt | FAILED CONTROL / INCONCLUSIVE | Stationary guardrail passed, but multimode Born-control failed (corr 0.180934), invalidating relaxation interpretation. | BORN_RELAXATION_MECHANISM_SEED_NOT_DERIVATION (superseded) | Superseded by M2/M3; lesson: no relaxation claim without Born preflight. |
| M2 | Equivariance-safe Born relaxation retest | PASS PREFLIGHT + DIAGNOSTIC | Adaptive unclipped torus flow fixed Born preflight (corr 0.980289); non-Born H decrease mild and diagnostic. | BORN_PREFLIGHT_PASS_RELAXATION_DIAGNOSTIC_INTERPRETABLE | Relaxation not closed; only interpretable after preflight. |
| M3 | Mixing-linked Born relaxation scan | PASS_MECHANISM | Preflight pass fraction 0.833333; Hf/H0 decreases monotonically with mixing proxy (Spearman -1.0); best ratio 0.390791. | MIXING_LINKED_BORN_RELAXATION_MECHANISM_SEED | Mechanism seed, not Born-rule derivation. |
| N | Native lag-current bridge cascade | USEFUL FAILURE | Density-only lag guardrail passed (corr 0.0); action-phase bridge initially failed due to phase-extraction/scoring issues; cascade stopped. | NATIVE_LAG_CURRENT_BRIDGE_NOT_CLOSED (superseded by N2) | Shows density dents alone are insufficient; superseded by N2 audit. |
| N2 | Action-phase / quantum-current bridge audit | PASS | v_Q = Im(psi* grad psi)//psi/^2 matches grad S in controlled and node-masked domains; errors 2.6e-13 to 1.6e-5. | ACTION_PHASE_CURRENT_BRIDGE_VALIDATED_CONTROLLED_AND_NODE_MASKED | Still does not derive S from V11.1B settlement dynamics. |

## Detailed verdict rows

### V11.2A

| Gate | Status | Meaning | Value |
|---|---|---|---|
| correlated_kernel_matches_target_modulation | PASS | two-path correlated dent phase kernel reproduces target modulation | 1 |
| correlated_kernel_fringe_spacing | PASS | main config fringe spacing matches Delta y = lambda L / d | 0.019 |
| scaling_sweep_fringe_spacing | PASS | correlated kernel preserves Delta y scaling over d, L, lambda, and a sweeps | 0.0373214 |
| aperture_and_local_guardrails | PASS_GUARDRAIL | aperture-only and local-slit dents do not pass the fringe-train spacing gate | 0 |
| beta_fit_recovers_debroglie_phase | PASS | best-fit beta recovers beta = 2pi/lambda | 1 |
| claim_level | QUANTITATIVE_KERNEL_PASS_NOT_PARENT_DERIVATION | correlated dent phase grammar can reproduce double-slit law; V11.1B settlement parent derivation remains open |  |

### V11.2B

| Gate | Status | Meaning | Value |
|---|---|---|---|
| clocked_settlement_green_matches_target | PASS | coherent settlement residual carrying de Broglie/action phase reproduces target modulation and spacing | 0.999645 |
| phase_slope_recovers_debroglie_beta | PASS | parent phase carrier has beta = 2pi/lambda with correct path-difference slope | 1 |
| dc_and_incoherent_guardrails | PASS_GUARDRAIL | DC settlement residual and incoherent power sum do not generate the fringe train | 0 |
| short_memory_suppresses_visibility | CHECK | short residual memory/decoherence suppresses the coherent fringe visibility | 0.999965 |
| coherence_memory_threshold | PASS | scan identifies memory time needed for high-correlation two-path residual | 1.61268 |
| claim_level | PARENT_KERNEL_SUPPORT_PASS_CARRIER_NOT_DERIVED | settlement residual can support the correlated phase kernel, but de Broglie carrier and Born rule remain open |  |

### V11.2C

| Gate | Status | Meaning | Value |
|---|---|---|---|
| localized_hits_generated | PASS | script generated localized screen events | 1.000e+04 |
| ensemble_converges_toward_density | PASS | final histogram correlates with the sampled V11.2 density; low nshots are noisy by design | 0.998351 |
| claim_level | SHOT_BUILDING_VISUALIZATION_NOT_BORN_DERIVATION | localized hits build the predicted fringe density, but sampling from density is not a Born-rule derivation |  |

### V11.2D

| Gate | Status | Meaning | Value |
|---|---|---|---|
| trajectory_guidance_populates_field_density | PASS | deterministic settlement-guided trajectories populate the propagated coherent field density | 0.994644 |
| free_and_local_guardrails_worse | PASS_GUARDRAIL | free rays and local-only edge forces do not match the coherent density as well as settlement guidance | 0.405795 |
| field_density_near_fraunhofer_target | PASS_SCALE | guided detections are also broadly correlated with the far-field double-slit target | 0.77154 |
| claim_level | TRAJECTORY_GUIDANCE_PASS_NOT_BORN_OR_CARRIER_DERIVATION | localized trajectories guided by coherent dent phase-current build the field density; de Broglie carrier and Born rule remain open |  |

### V11.2E

| Gate | Status | Meaning | Value |
|---|---|---|---|
| coherent_gamma1_trajectory_density | PASS | gamma=1 guided trajectories populate the coherent two-path density | 0.99078 |
| which_path_gamma0_suppresses_cross_term | PASS | gamma=0 removes the coherent cross-term / fringe visibility in the field density | 0 |
| visibility_tracks_detector_overlap | PASS | field visibility cross-fraction tracks detector overlap gamma | 1.326e-05 |
| complementarity_relation | PASS | V^2 + D^2 remains near one using V from dent cross-term and D=sqrt(1-gamma^2) | 1.492e-05 |
| trajectory_histograms_follow_partial_coherence | PASS | guided trajectory histograms follow their corresponding partially coherent densities across gamma sweep | 0.99078 |
| claim_level | TRAJECTORY_DECOHERENCE_PASS_NOT_BORN_OR_MEASUREMENT_DERIVATION | which-path overlap suppresses dent-guided interference continuously; Born rule and detector dynamics remain open |  |

### V11.2F

| Gate | Status | Meaning | Value |
|---|---|---|---|
| uncertainty_bound_spectrum | PASS | single-slit aperture spectrum satisfies Delta x Delta p >= hbar/2 within numerical tolerance | 1.16148 |
| inverse_width_scaling | PASS | momentum spread scales approximately as Delta p proportional to 1/Delta x | -1 |
| trajectory_guidance_follows_single_slit_density | PASS | guided trajectory screen histograms follow propagated single-slit field densities across width sweep | 0.915086 |
| trajectory_momentum_scale | PASS_SCALE | trajectory slopes carry a nonzero momentum-spread scale; exact spectral equality is not required in this toy | 0.976578 |
| claim_level | UNCERTAINTY_SCALE_PASS_NOT_BORN_OR_CARRIER_DERIVATION | single-slit dent/current architecture reproduces uncertainty-scale spread; Born rule and lambda=h/p remain open |  |

### V11.2G

| Gate | Status | Meaning | Value |
|---|---|---|---|
| born_equivariance_across_fields | PASS | Born-initialized guided ensembles remain distributed like their propagated dent/current densities | 0.992065 |
| born_H_function_stays_low | PASS | Born-initialized ensembles keep low coarse-grained H relative to /Psi/^2 | 0.0111347 |
| double_slit_coherent_equivariance | PASS | coherent double-slit Born ensemble follows the propagated coherent two-path density | 0.992279 |
| nonborn_does_not_instantly_become_born | PASS_GUARDRAIL | biased non-Born two-slit ensemble remains statistically distinguishable from Born at the screen | 0.277941 |
| coarse_grained_relaxation_diagnostic | DIAGNOSTIC_OPEN | median H_final/H_initial for non-Born cases; relaxation is not claimed closed in this toy | 1.31759 |
| claim_level | EQUIVARIANCE_PASS_BORN_ORIGIN_NOT_DERIVED | dent guidance preserves Born equilibrium and respects non-Born guardrail; origin/relaxation of Born rule remains open |  |

### V11.2H

| Gate | Status | Meaning | Value |
|---|---|---|---|
| lorentz_projected_compton_clock_selects_debroglie_k | PASS | Lorentz projection of maintained Compton/action phase gives k=p/hbar, the V11.2 kernel slope | 0 |
| worldline_phase_matches_proper_compton_clock | PASS | omega t - k x along x=vt equals omega_C tau | 1.019e-15 |
| relativistic_dispersion_and_group_velocity | PASS | omega^2-c^2k^2=omega_C^2 and d omega/dk = v | 8.882e-16 |
| double_slit_phase_kernel_matches_v11_2a | PASS | Delta phi = k Delta ell uses k=p/hbar, yielding lambda=h/p | 0 |
| alternative_carriers_fail_guardrails | PASS_GUARDRAIL | raw Compton/lab Compton/no-spatial/nonrel carriers fail the required V11.2 phase slope somewhere in sweep | 0.56411 |
| claim_level | CARRIER_ORIGIN_ACTION_PHASE_PASS_NOT_FULL_DYNAMICAL_DERIVATION | de Broglie carrier is selected by Lorentz-projected Compton/action phase; Born rule and deeper momentum dynamics remain open |  |

### V11.2I

| Gate | Status | Meaning | Value |
|---|---|---|---|
| single_slit_pure_qforce_reconstruction | PASS | single-slit material acceleration matches -(1/k) grad Q[rho] | 0.968634 |
| double_slit_pure_qforce_reconstruction | PASS | coherent double-slit material acceleration matches quantum-potential force away from nodes | 0.97414 |
| pure_state_linear_force_fit | PASS | pure-state a_material vs a_Q fit has near-unit slope and high explanatory power | 0.938253 |
| decohered_globalQ_guardrail | DIAGNOSTIC | partially/incoherent cases are density-matrix/branch problems; simple global scalar Q is not overclaimed | 0.715431 |
| claim_level | QUANTUM_POTENTIAL_FORCE_RECONSTRUCTION_PASS_PURE_STATE_ONLY | dent guidance is compatible with Q[rho] force geometry for pure states; Born origin, Bell, and full measurement dynamics remain open |  |

### V11.2J

| Gate | Status | Meaning | Value |
|---|---|---|---|
| boundary_kernel_reproduces_singlet_correlations | PASS | boundary singlet kernel gives CHSH=2sqrt(2) at canonical settings | 2.82843 |
| local_dent_guardrail_obeys_bell_bound | PASS_GUARDRAIL | local shared-variable dent model does not violate CHSH | 2 |
| no_signaling_marginals | PASS | boundary correlations change joint outcomes but keep local marginals independent of distant setting | 0 |
| noise_threshold_matches_werner_limit | PASS_SCALE | Bell violation threshold occurs near eta=1/sqrt(2) | 0.705 |
| claim_level | BELL_BOUNDARY_GRAMMAR_PASS_NOT_DERIVED_DYNAMICS | SFT needs boundary-level correlation grammar for Bell while preserving no-signaling; local dent propagation is insufficient |  |

### V11.2K

| Gate | Status | Meaning | Value |
|---|---|---|---|
| spinor_projectors_generate_boundary_kernel | PASS | singlet state plus SU(2) projectors gives P(s,t)=1/4[1-st(a dot b)] over angle grid | 5.551e-17 |
| random_3d_axis_rotational_invariance | PASS | singlet holonomy result holds for random 3D measurement axes, not only planar angles | 6.661e-16 |
| chsh_tsirelson_from_singlet_holonomy | PASS | singlet spinor/projector bridge gives CHSH=2sqrt(2) | 2.82843 |
| separable_and_local_guardrails_do_not_fake_bell | PASS_GUARDRAIL | product, classical mixture, and local shared-variable guardrails stay at or below CHSH=2 | 2 |
| no_signaling_marginals_from_singlet_projectors | PASS | local marginals remain 1/2 independent of distant measurement axis | 1.110e-16 |
| claim_level | SINGLET_HOLONOMY_BRIDGE_PASS_NOT_BOUNDARY_DYNAMICS_DERIVED | V11.9 spin-holonomy machinery generates the V11.2J boundary Bell kernel; physical creation/dynamics of the boundary singlet remain open |  |

### V11.2L

| Gate | Status | Meaning | Value |
|---|---|---|---|
| zero_total_spin_projector_selects_singlet | PASS | boundary zero-total spin-holonomy selection outputs singlet with S_total^2=0 when branch has nonzero overlap | 2.220e-16 |
| measurement_order_invariance | PASS | Alice-first, Bob-first, and simultaneous spacelike projectors give same singlet joint probabilities | 4.441e-16 |
| local_detector_channel_no_signaling | PASS | local Alice/Bob detector-dephasing channel does not alter remote reduced state or remote outcome marginal | 3.290e-16 |
| singlet_chsh_and_guardrails | PASS | singlet reaches Tsirelson while product/classical/local guardrails do not fake Bell violation | 4.441e-16 |
| claim_level | BOUNDARY_MEASUREMENT_CHANNELS_PASS_DYNAMICS_NOT_DERIVED | boundary singlet and local measurement-channel grammar are internally consistent and no-signaling; physical creation/update dynamics remain open |  |

### V11.2M

| Gate | Status | Meaning | Value |
|---|---|---|---|
| integrable_nonborn_guardrail_no_magic_relaxation | PASS_GUARDRAIL | stationary/integrable non-Born ensemble does not magically relax to Born | 1 |
| born_equivariance_control_in_mixing_field | CHECK | Born-initialized ensemble remains close to Born density in multimode dent flow | 0.180934 |
| coarse_grained_relaxation_in_multimode_flow | DIAGNOSTIC_OPEN | non-Born ensemble shows coarse-grained H decrease and correlation improvement only in mixing dent field | 9.89862 |
| strong_nonborn_relaxation_stress | DIAGNOSTIC_OPEN | stronger non-Born bias stress test; relaxation may be partial or absent | 3.07947 |
| born_origin_claim_level | BORN_RELAXATION_MECHANISM_SEED_NOT_DERIVATION | coarse-grained relaxation can be tested as a mixing mechanism; Born origin is not closed by this toy | 6.48905 |

### V11.2M2

| Gate | Status | Meaning | Value |
|---|---|---|---|
| integrable_nonborn_guardrail_no_magic_relaxation | PASS_GUARDRAIL | periodic stationary/integrable non-Born ensemble does not magically relax to Born | 0.995991 |
| born_equivariance_preflight_multimode | PASS | Born-initialized ensemble remains close to /Psi/^2 under adaptive unclipped multimode torus flow | 0.980289 |
| adaptive_node_handling_diagnostics | PASS_DIAGNOSTIC | adaptive substepping replaced velocity clipping; node-risk/speed diagnostics recorded | 4 |
| coarse_grained_relaxation_if_preflight_passes | DIAGNOSTIC_OPEN | non-Born H decrease is interpreted only if Born equivariance preflight passes | 0.894258 |
| strong_nonborn_relaxation_if_preflight_passes | DIAGNOSTIC_OPEN | strong non-Born stress interpreted only if Born equivariance preflight passes | 0.908832 |
| claim_level | BORN_PREFLIGHT_PASS_RELAXATION_DIAGNOSTIC_INTERPRETABLE | M2 separates numerical equivariance preflight from Born-origin relaxation; no Born-rule derivation is claimed |  |

### V11.2M3

| Gate | Status | Meaning | Value |
|---|---|---|---|
| stationary_nonborn_guardrail_no_magic_relaxation | PASS_GUARDRAIL | mode_count=1 non-Born distribution should not magically relax under simple torus flow | 0.995429 |
| born_preflight_pass_fraction | PASS | fraction of mode scans whose Born-control passes before interpreting relaxation | 0.833333 |
| mixing_relaxation_trend | PASS_MECHANISM | among preflight-passed modes, Hf/H0 should decrease as mixing proxy increases | -1 |
| best_relaxation_ratio | PASS_MECHANISM | best preflight-valid non-Born Hf/H0 ratio in scan | 0.390791 |
| claim_level | MIXING_LINKED_BORN_RELAXATION_MECHANISM_SEED | M3 tests whether Born relaxation strengthens with mixing; no Born-rule derivation is claimed |  |

### V11.2N

| Gate | Status | Meaning | Value |
|---|---|---|---|
| density_only_lag_does_not_fake_quantum_current | PASS_GUARDRAIL | density residual -grad Lambda_rho should not reproduce the phase/current guidance field | 0 |
| action_phase_lag_reconstructs_quantum_current | CHECK | maintained action/clock phase lag gives -grad(-S)=grad S=v_Q at representation level | 0.18597 |
| settlement_residual_direct_velocity | DIAGNOSTIC_OPEN | finite lag residual of action phase is diagnostic; direct equality to v_Q is not expected and remains V12 theory work | 0 |
| claim_level | NATIVE_LAG_CURRENT_BRIDGE_NOT_CLOSED | V11.2 current bridge must run through maintained action phase/clock holonomy; density dents alone are insufficient; V11.1B settlement derivation remains open |  |

### V11.2N2

| Gate | Status | Meaning | Value |
|---|---|---|---|
| plane_wave_phase_current_identity | PASS | phase-gradient extraction reproduces v_Q for exact plane wave | 2.638e-13 |
| no_node_two_mode_phase_current_identity | PASS | phase-gradient extraction reproduces v_Q in controlled no-node interference state | 1.755e-06 |
| weak_node_multimode_masked_bridge | PASS | action-phase bridge works in weak multimode case after excluding invalid node neighborhoods | 4.302e-06 |
| strong_node_multimode_masked_bridge | PASS | gnarly multimode case is interpretable only on node-masked phase-valid domains | 1.618e-05 |
| claim_level | ACTION_PHASE_CURRENT_BRIDGE_VALIDATED_CONTROLLED_AND_NODE_MASKED | N2 audits action-phase current extraction only; V11.1B settlement-to-action dynamics remain open |  |
