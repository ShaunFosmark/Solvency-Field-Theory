# SFT V11.7 Scripts Repro Pack

Scripts-only pack for the V11.7 fluid stress validation runs.

Generated CSVs, plots, and PDFs are intentionally excluded. Run the scripts locally to regenerate outputs.

Requirements:

```bash
pip install numpy pandas matplotlib
```

Included:
- sft_v117_big_validation_runner.py
- sft_v117_2d_robustness_runner.py

Suggested run:

```bash
python sft_v117_big_validation_runner.py
python sft_v117_2d_robustness_runner.py
```

Claim guardrail: this pack supports the V11.7 scalar/tensor fluid stress computational sector. It does not include baked outputs from the earlier full v6 repro pack.
