#!/usr/bin/env python3
"""
SFT V11.7 Big Validation Runner
================================

Purpose
-------
Validate the candidate lag-memory control parameter

    Lambda = epsilon * alpha * tau_chi / D_chi

for the SFT lag-stress fluid toy.

This script tests whether the Lambda-organized regime behavior survives:
  1. higher resolution,
  2. multiple initial conditions,
  3. ordinary-viscosity changes,
  4. different tau/epsilon combinations giving the same Lambda.

Key upgrade from the in-chat explicit toy:
-----------------------------------------
The lag field chi is updated with a semi-implicit spectral step for
diffusion + relaxation:

    chi_hat_new = (chi_hat + dt * source_hat) /
                  (1 + dt * (D_chi*k^2 + 1/tau_chi))

This removes the brutal explicit dt ~ dx^2/D_chi limit and makes N=512/1024
practical while preserving the lag-source/lag-memory structure.

This is still a toy, not a production CFD solver.
"""

import argparse
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_float_list(s):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_int_list(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def parse_str_list(s):
    return [x.strip() for x in s.split(",") if x.strip()]


def make_initial_conditions(x, ic="smooth", seed=1234):
    rng = np.random.default_rng(seed)
    L = x[-1] + (x[1] - x[0])

    if ic == "smooth":
        rho = 1.0 + 0.20*np.cos(x - 0.5) + 0.08*np.cos(2*x + 1.1)
        u = 0.85*np.sin(x) + 0.18*np.sin(3*x + 0.25)

    elif ic == "gaussian":
        # Smooth compressive density bump with counterflow.
        center = 0.52 * L
        dist = np.minimum(np.abs(x-center), L-np.abs(x-center))
        rho = 1.0 + 0.45*np.exp(-(dist/0.45)**2) - 0.08*np.cos(x + 0.3)
        u = 0.55*np.sin(x - 0.4) - 0.40*np.exp(-(dist/0.65)**2)*np.tanh((x-center)/0.25)

    elif ic == "shear_layer":
        # Periodic smoothed shear/compression layer.
        center1 = 0.30 * L
        center2 = 0.72 * L
        u = 0.55*np.tanh((x-center1)/0.10) - 0.55*np.tanh((x-center2)/0.10)
        u += 0.10*np.sin(4*x + 0.2)
        rho = 1.0 + 0.18*np.cos(x - 0.7) + 0.10*np.sin(2*x)

    elif ic == "random_smooth":
        # Low-k random smooth initial condition.
        rho = np.ones_like(x)
        u = np.zeros_like(x)
        for k in range(1, 7):
            a_r = rng.normal(scale=0.08/k)
            b_r = rng.normal(scale=0.08/k)
            a_u = rng.normal(scale=0.30/k)
            b_u = rng.normal(scale=0.30/k)
            rho += a_r*np.cos(k*x) + b_r*np.sin(k*x)
            u += a_u*np.cos(k*x) + b_u*np.sin(k*x)
        u += 0.55*np.sin(x + 0.15)

    else:
        raise ValueError(f"Unknown initial condition: {ic}")

    rho = np.maximum(rho, 0.2)
    m = rho*u
    return rho, m


def run_case(
    N,
    nu,
    Lambda,
    tau_chi,
    ic,
    seed,
    T,
    CFL,
    cs,
    D_rho,
    alpha,
    D_chi,
    Lbox,
    instability_rho_max,
    instability_grad_max,
):
    x = np.linspace(0, Lbox, N, endpoint=False)
    dx = Lbox / N
    rho, m = make_initial_conditions(x, ic=ic, seed=seed)
    chi = np.zeros_like(x)

    cs2 = cs**2
    eps = 0.0 if Lambda == 0 else Lambda * D_chi / (alpha * tau_chi)

    # Spectral k for semi-implicit chi diffusion.
    k = np.fft.rfftfreq(N, d=dx) * 2*np.pi
    chi_denominator = None  # depends on dt, so constructed inside loop

    t = 0.0
    steps = 0
    unstable = False
    max_grad_seen = 0.0
    min_dt_seen = np.inf
    max_dt_seen = 0.0

    def ddx(f):
        return (np.roll(f, -1) - np.roll(f, 1)) / (2*dx)

    def d2(f):
        return (np.roll(f, -1) - 2*f + np.roll(f, 1)) / (dx*dx)

    def high_k_fraction(field, kthresh_frac=0.22):
        F = np.fft.rfft(field - np.mean(field))
        P = np.abs(F)**2
        kmax = np.max(k)
        return float(P[k > kthresh_frac*kmax].sum() / max(P.sum(), 1e-30))

    def euler_flux(rho_arr, m_arr):
        rho_safe = np.maximum(rho_arr, 1e-8)
        u_arr = m_arr / rho_safe
        p = cs2 * rho_safe
        return np.array([m_arr, m_arr*u_arr + p])

    while t < T:
        rho_safe = np.maximum(rho, 1e-8)
        u = m / rho_safe
        max_speed = float(np.max(np.abs(u) + cs))

        # Explicit stability limits for hyperbolic step and explicitly handled
        # ordinary diffusion. Chi diffusion is semi-implicit, so D_chi is not in dt.
        dt_adv = dx / max(max_speed, 1e-12)
        dt_nu = dx*dx / max(nu, 1e-12)
        dt_Drho = dx*dx / max(D_rho, 1e-12)
        dt = CFL * min(dt_adv, dt_nu, dt_Drho)

        if t + dt > T:
            dt = T - t

        min_dt_seen = min(min_dt_seen, dt)
        max_dt_seen = max(max_dt_seen, dt)

        # Rusanov compressible step.
        rho_R = np.roll(rho, -1)
        m_R = np.roll(m, -1)
        rho_R_safe = np.maximum(rho_R, 1e-8)
        u_R = m_R / rho_R_safe

        F = euler_flux(rho, m)
        F_R = euler_flux(rho_R, m_R)
        a = np.maximum(np.abs(u) + cs, np.abs(u_R) + cs)

        U = np.array([rho, m])
        U_R = np.array([rho_R, m_R])
        flux_ip = 0.5*(F + F_R) - 0.5*a*(U_R - U)
        flux_im = np.roll(flux_ip, 1, axis=1)
        dUdt = -(flux_ip - flux_im) / dx

        visc_m = rho_safe * nu * d2(u)
        diff_rho = D_rho * d2(rho)
        lag_force = -eps * rho_safe * ddx(chi)

        rho = rho + dt*(dUdt[0] + diff_rho)
        m = m + dt*(dUdt[1] + visc_m + lag_force)
        rho = np.maximum(rho, 1e-7)

        # Semi-implicit chi update:
        # chi_t = D_chi chi_xx + alpha(rho-rhobar) - chi/tau
        source = alpha * (rho - rho.mean())
        chi_hat = np.fft.rfft(chi)
        source_hat = np.fft.rfft(source)
        denom = 1.0 + dt*(D_chi*k*k + 1.0/tau_chi)
        chi = np.fft.irfft((chi_hat + dt*source_hat) / denom, n=N)

        t += dt
        steps += 1

        u = m / np.maximum(rho, 1e-8)
        ux = ddx(u)
        max_grad_seen = max(max_grad_seen, float(np.max(np.abs(ux))))

        if (not np.all(np.isfinite(rho))) or (not np.all(np.isfinite(m))) or (not np.all(np.isfinite(chi))):
            unstable = True
            break
        if rho.max() > instability_rho_max or rho.min() < 1e-7 or max_grad_seen > instability_grad_max:
            unstable = True
            break

    u = m / np.maximum(rho, 1e-8)
    ux = ddx(u)

    return {
        "N": N,
        "nu": nu,
        "Lambda": Lambda,
        "tau_chi": tau_chi,
        "eps": eps,
        "alpha": alpha,
        "D_chi": D_chi,
        "ic": ic,
        "seed": seed,
        "T": T,
        "steps": steps,
        "min_dt_seen": float(min_dt_seen),
        "max_dt_seen": float(max_dt_seen),
        "rho_min": float(rho.min()),
        "rho_max": float(rho.max()),
        "rho_std": float(rho.std()),
        "u_energy": float(0.5*np.mean(u*u)),
        "max_abs_du_dx": float(np.max(np.abs(ux))),
        "grad_energy": float(np.mean(ux*ux)),
        "u_high_k_fraction": high_k_fraction(u),
        "chi_std": float(np.std(chi)),
        "chi_max_abs": float(np.max(np.abs(chi))),
        "unstable_flag": bool(unstable),
        "max_grad_seen": float(max_grad_seen),
    }


def classify(row):
    if row["unstable_flag"] or row["grad_ratio"] > 2.0 or row["highk_ratio"] > 4.0:
        return "amplifying_or_unstable"
    if row["rho_std_ratio"] < 0.96 and row["grad_ratio"] <= 1.10 and row["highk_ratio"] <= 1.5:
        return "pressure_like_smoothing"
    if row["rho_std_ratio"] < 0.96 and row["grad_ratio"] > 1.10:
        return "elastic_memory"
    if row["grad_ratio"] > 1.10 or row["highk_ratio"] > 1.5:
        return "shear_enhancing"
    return "near_baseline"


def plot_outputs(df, summary, outdir):
    outdir = Path(outdir)

    # Aggregate mean by Lambda across everything.
    agg = df.groupby("Lambda").agg(
        grad_ratio_mean=("grad_ratio", "mean"),
        grad_ratio_std=("grad_ratio", "std"),
        rho_ratio_mean=("rho_std_ratio", "mean"),
        rho_ratio_std=("rho_std_ratio", "std"),
        highk_ratio_mean=("highk_ratio", "mean"),
        highk_ratio_std=("highk_ratio", "std"),
        energy_ratio_mean=("energy_ratio", "mean"),
        energy_ratio_std=("energy_ratio", "std"),
    ).reset_index()
    agg.to_csv(outdir / "aggregate_by_lambda.csv", index=False)

    plt.figure(figsize=(8, 5.5))
    plt.errorbar(agg["Lambda"], agg["grad_ratio_mean"], yerr=agg["grad_ratio_std"], marker="o", capsize=4, label="gradient ratio")
    plt.errorbar(agg["Lambda"], agg["rho_ratio_mean"], yerr=agg["rho_ratio_std"], marker="o", capsize=4, label="density ratio")
    plt.xscale("log")
    plt.xlabel("Lambda")
    plt.ylabel("ratio to baseline")
    plt.title("Aggregate response by Lambda")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir / "aggregate_response_by_lambda.png", dpi=180)
    plt.close()

    plt.figure(figsize=(8, 5.5))
    plt.errorbar(agg["Lambda"], agg["highk_ratio_mean"], yerr=agg["highk_ratio_std"], marker="o", capsize=4)
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("Lambda")
    plt.ylabel("high-k ratio")
    plt.title("Aggregate small-scale amplification by Lambda")
    plt.tight_layout()
    plt.savefig(outdir / "aggregate_highk_by_lambda.png", dpi=180)
    plt.close()

    # Resolution plot per IC if possible.
    for ic, sub_ic in summary.groupby("ic"):
        plt.figure(figsize=(8, 5.5))
        for N, sub in sub_ic.groupby("N"):
            sub = sub.sort_values("Lambda")
            plt.errorbar(sub["Lambda"], sub["grad_ratio_mean"], yerr=sub["grad_ratio_std"], marker="o", capsize=3, label=f"N={N}")
        plt.xscale("log")
        plt.xlabel("Lambda")
        plt.ylabel("gradient ratio")
        plt.title(f"Resolution shear response: {ic}")
        plt.legend()
        plt.tight_layout()
        plt.savefig(outdir / f"resolution_gradient_ratio_{ic}.png", dpi=180)
        plt.close()

        plt.figure(figsize=(8, 5.5))
        for N, sub in sub_ic.groupby("N"):
            sub = sub.sort_values("Lambda")
            plt.errorbar(sub["Lambda"], sub["rho_ratio_mean"], yerr=sub["rho_ratio_std"], marker="o", capsize=3, label=f"N={N}")
        plt.xscale("log")
        plt.xlabel("Lambda")
        plt.ylabel("density contrast ratio")
        plt.title(f"Resolution density response: {ic}")
        plt.legend()
        plt.tight_layout()
        plt.savefig(outdir / f"resolution_density_ratio_{ic}.png", dpi=180)
        plt.close()

    # Regime counts.
    regime_counts = df["regime"].value_counts().rename_axis("regime").reset_index(name="count")
    regime_counts.to_csv(outdir / "regime_counts.csv", index=False)

    plt.figure(figsize=(8, 5))
    plt.bar(regime_counts["regime"], regime_counts["count"])
    plt.ylabel("number of runs")
    plt.title("Regime counts")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(outdir / "regime_counts.png", dpi=180)
    plt.close()


def main():
    parser = argparse.ArgumentParser(description="SFT V11.7 big Lambda validation runner")

    parser.add_argument("--preset", default="big", choices=["pilot", "big", "hero", "custom"],
                        help="pilot=quick, big=good local run, hero=overnight-ish broad run, custom=use lists")
    parser.add_argument("--outdir", default="sft_v117_big_validation_output")
    parser.add_argument("--T", type=float, default=1.6)
    parser.add_argument("--CFL", type=float, default=0.20)
    parser.add_argument("--cs", type=float, default=0.75)
    parser.add_argument("--D-rho", type=float, default=0.0006)
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument("--D-chi", type=float, default=0.10)
    parser.add_argument("--Lbox", type=float, default=2*math.pi)
    parser.add_argument("--seed", type=int, default=20260501)

    parser.add_argument("--N-list", default="")
    parser.add_argument("--nu-list", default="")
    parser.add_argument("--lambda-list", default="")
    parser.add_argument("--tau-list", default="")
    parser.add_argument("--ic-list", default="")

    parser.add_argument("--instability-rho-max", type=float, default=8.0)
    parser.add_argument("--instability-grad-max", type=float, default=120.0)
    parser.add_argument("--checkpoint-every", type=int, default=1,
                        help="write results CSV after this many completed runs")
    args = parser.parse_args()

    if args.preset == "pilot":
        N_list = [128, 256]
        nu_list = [0.004]
        lambda_list = [0.25, 0.75, 1.15, 1.70]
        tau_list = [0.25, 0.50]
        ic_list = ["smooth"]

    elif args.preset == "big":
        N_list = [256, 512, 1024]
        nu_list = [0.004]
        lambda_list = [0.25, 0.75, 1.15, 1.70, 2.40]
        tau_list = [0.25, 0.50]
        ic_list = ["smooth", "gaussian", "random_smooth"]

    elif args.preset == "hero":
        N_list = [256, 512, 1024]
        nu_list = [0.0025, 0.004, 0.008]
        lambda_list = [0.12, 0.25, 0.45, 0.75, 1.15, 1.70, 2.40]
        tau_list = [0.25, 0.50]
        ic_list = ["smooth", "gaussian", "shear_layer", "random_smooth"]

    else:
        N_list = parse_int_list(args.N_list)
        nu_list = parse_float_list(args.nu_list)
        lambda_list = parse_float_list(args.lambda_list)
        tau_list = parse_float_list(args.tau_list)
        ic_list = parse_str_list(args.ic_list)
        if not (N_list and nu_list and lambda_list and tau_list and ic_list):
            raise ValueError("For --preset custom, provide --N-list, --nu-list, --lambda-list, --tau-list, --ic-list")

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    config = {
        "preset": args.preset,
        "N_list": N_list,
        "nu_list": nu_list,
        "lambda_list": lambda_list,
        "tau_list": tau_list,
        "ic_list": ic_list,
        "T": args.T,
        "CFL": args.CFL,
        "cs": args.cs,
        "D_rho": args.D_rho,
        "alpha": args.alpha,
        "D_chi": args.D_chi,
        "Lbox": args.Lbox,
        "seed": args.seed,
        "instability_rho_max": args.instability_rho_max,
        "instability_grad_max": args.instability_grad_max,
    }
    (outdir / "config.json").write_text(json.dumps(config, indent=2))

    rows = []
    baselines = []
    total_runs = len(N_list) * len(nu_list) * len(ic_list) * (1 + len(lambda_list)*len(tau_list))
    completed = 0
    start = time.time()

    results_path = outdir / "runs.csv"
    baseline_path = outdir / "baselines.csv"

    for ic in ic_list:
        for N in N_list:
            for nu in nu_list:
                print(f"\n[baseline] ic={ic} N={N} nu={nu}", flush=True)
                baseline = run_case(
                    N=N, nu=nu, Lambda=0.0, tau_chi=0.25, ic=ic, seed=args.seed,
                    T=args.T, CFL=args.CFL, cs=args.cs, D_rho=args.D_rho,
                    alpha=args.alpha, D_chi=args.D_chi, Lbox=args.Lbox,
                    instability_rho_max=args.instability_rho_max,
                    instability_grad_max=args.instability_grad_max,
                )
                baselines.append(baseline)
                completed += 1

                for Lambda in lambda_list:
                    for tau_chi in tau_list:
                        print(f"[run {completed+1}/{total_runs}] ic={ic} N={N} nu={nu} Lambda={Lambda} tau={tau_chi}", flush=True)
                        row = run_case(
                            N=N, nu=nu, Lambda=Lambda, tau_chi=tau_chi, ic=ic, seed=args.seed,
                            T=args.T, CFL=args.CFL, cs=args.cs, D_rho=args.D_rho,
                            alpha=args.alpha, D_chi=args.D_chi, Lbox=args.Lbox,
                            instability_rho_max=args.instability_rho_max,
                            instability_grad_max=args.instability_grad_max,
                        )

                        row["rho_std_baseline"] = baseline["rho_std"]
                        row["u_energy_baseline"] = baseline["u_energy"]
                        row["max_abs_du_dx_baseline"] = baseline["max_abs_du_dx"]
                        row["u_high_k_fraction_baseline"] = baseline["u_high_k_fraction"]

                        row["rho_std_ratio"] = row["rho_std"] / baseline["rho_std"]
                        row["energy_ratio"] = row["u_energy"] / baseline["u_energy"]
                        row["grad_ratio"] = row["max_abs_du_dx"] / baseline["max_abs_du_dx"]
                        row["highk_ratio"] = row["u_high_k_fraction"] / max(baseline["u_high_k_fraction"], 1e-30)

                        row["regime"] = classify(row)
                        rows.append(row)
                        completed += 1

                        if completed % args.checkpoint_every == 0:
                            pd.DataFrame(rows).to_csv(results_path, index=False)
                            pd.DataFrame(baselines).to_csv(baseline_path, index=False)

                        elapsed = time.time() - start
                        print(f"  done in {elapsed/60:.1f} min elapsed; regime={row['regime']}", flush=True)

    df = pd.DataFrame(rows)
    bdf = pd.DataFrame(baselines)
    df.to_csv(results_path, index=False)
    bdf.to_csv(baseline_path, index=False)

    summary = df.groupby(["ic", "N", "nu", "Lambda"]).agg(
        grad_ratio_mean=("grad_ratio", "mean"),
        grad_ratio_std=("grad_ratio", "std"),
        rho_ratio_mean=("rho_std_ratio", "mean"),
        rho_ratio_std=("rho_std_ratio", "std"),
        highk_ratio_mean=("highk_ratio", "mean"),
        highk_ratio_std=("highk_ratio", "std"),
        energy_ratio_mean=("energy_ratio", "mean"),
        energy_ratio_std=("energy_ratio", "std"),
        unstable_count=("unstable_flag", "sum"),
        mean_steps=("steps", "mean"),
        min_dt=("min_dt_seen", "min"),
    ).reset_index()
    summary.to_csv(outdir / "summary_by_ic_N_nu_lambda.csv", index=False)

    corr_rows = []
    for keys, sub in df.groupby(["ic", "N", "nu"]):
        ic, N, nu = keys
        for metric in ["rho_std_ratio", "grad_ratio", "highk_ratio", "energy_ratio"]:
            corr = np.corrcoef(np.log(sub["Lambda"]), sub[metric])[0, 1]
            corr_rows.append({
                "ic": ic,
                "N": N,
                "nu": nu,
                "metric": metric,
                "corr_logLambda": float(corr),
            })
    corr_df = pd.DataFrame(corr_rows)
    corr_df.to_csv(outdir / "correlations_by_ic_N_nu.csv", index=False)

    plot_outputs(df, summary, outdir)

    print("\nDone.")
    print(f"Output directory: {outdir.resolve()}")
    print(f"Runs CSV: {results_path.resolve()}")
    print(f"Baselines CSV: {baseline_path.resolve()}")


if __name__ == "__main__":
    main()
