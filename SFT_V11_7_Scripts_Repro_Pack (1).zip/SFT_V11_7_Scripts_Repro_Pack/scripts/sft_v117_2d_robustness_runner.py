#!/usr/bin/env python3
"""
SFT V11.7 2D Robustness Runner
==============================

Purpose
-------
Test the 2D scalar/tensor SFT lag-stress architecture:

    sigma_SFT = -chi I + Q_chi

where:
    chi   = scalar/compressive lag pressure
    Q_chi = symmetric traceless tensor shear-memory lag stress

Model
-----
Compressible 2D vector-flow toy:

    rho_t + div(rho u) = D_rho lap rho

    u_t + u.grad u =
        - cs^2 grad(log rho)
        + nu lap u
        - eps_chi grad chi
        + eps_Q div Q

    chi_t = D_chi lap chi + alpha_chi (rho - <rho>) - chi/tau_chi

    Q_t = D_Q lap Q + alpha_Q S - Q/tau_Q

where S is the traceless strain tensor.

The lag updates are semi-implicit spectral updates:
    field_hat_new = (field_hat + dt source_hat) / (1 + dt*(D*k^2 + 1/tau))

This keeps high-N runs practical.

What to check
-------------
1. Scalar-only channel:
   - density/compression/divergence response
   - little direct vorticity generation

2. Tensor-only channel:
   - shear/vorticity/enstrophy response
   - high-k vorticity response

3. Combined channel:
   - scalar + tensor stress splitting

Presets
-------
pilot:
    quick shakedown, N=64,96

big:
    serious local pass, N=128,256,512, fixed nu, 3 IC families

hero:
    broader pass, N=128,256,512, 3 nu values, 4 IC families

Outputs
-------
runs.csv
baselines.csv
summary_by_group.csv
correlations.csv
aggregate plots
mode-specific plots
"""

import argparse
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_float_list(s):
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_int_list(s):
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def parse_str_list(s):
    return [x.strip() for x in s.split(",") if x.strip()]


def make_initial_conditions(X, Y, ic="mixed", seed=1234):
    rng = np.random.default_rng(seed)
    L = X.shape[0] * (X[1, 0] - X[0, 0]) if X.shape[0] > 1 else 2*np.pi
    # More reliable L from max coordinate spacing:
    dx = X[1, 0] - X[0, 0]
    L = X.shape[0] * dx

    if ic == "mixed":
        rho = 1.0 + 0.12*np.cos(X - 0.4)*np.cos(Y + 0.2) + 0.08*np.sin(2*X + Y)
        u = 0.42*np.sin(Y) + 0.18*np.sin(X + 2*Y)
        v = 0.42*np.sin(X) - 0.18*np.cos(2*X - Y)

    elif ic == "vortex_pair":
        rho = 1.0 + 0.10*np.cos(X - Y) + 0.06*np.sin(2*X + 0.5)
        # Streamfunction psi gives incompressible-ish vortex pair.
        psi = 0.55*np.sin(X)*np.sin(Y) + 0.20*np.sin(2*X - Y)
        u =  np.gradient(psi, axis=1) / dx
        v = -np.gradient(psi, axis=0) / dx
        u += 0.08*np.sin(X + 2*Y)
        v += 0.08*np.cos(2*X - Y)

    elif ic == "shear_layer":
        rho = 1.0 + 0.10*np.sin(X + 0.3)*np.cos(Y - 0.1)
        y1 = 0.30*L
        y2 = 0.70*L
        # periodic-ish double shear layer
        u = 0.45*np.tanh((Y-y1)/0.12) - 0.45*np.tanh((Y-y2)/0.12)
        u += 0.08*np.sin(3*X)
        v = 0.08*np.sin(X + 2*Y)

    elif ic == "random_smooth":
        rho = np.ones_like(X)
        u = np.zeros_like(X)
        v = np.zeros_like(X)
        for kx in range(1, 5):
            for ky in range(1, 5):
                amp_r = rng.normal(scale=0.025/(kx+ky))
                amp_u = rng.normal(scale=0.12/(kx+ky))
                amp_v = rng.normal(scale=0.12/(kx+ky))
                phase_r = rng.uniform(0, 2*np.pi)
                phase_u = rng.uniform(0, 2*np.pi)
                phase_v = rng.uniform(0, 2*np.pi)
                rho += amp_r*np.cos(kx*X + ky*Y + phase_r)
                u += amp_u*np.sin(kx*X + ky*Y + phase_u)
                v += amp_v*np.cos(kx*X - ky*Y + phase_v)
        u += 0.35*np.sin(Y)
        v += 0.35*np.sin(X)

    else:
        raise ValueError(f"Unknown initial condition: {ic}")

    rho = np.maximum(rho, 0.2)
    return rho, u, v


def classify(row):
    """Conservative labels based on ratios to baseline."""
    if row["unstable_flag"]:
        return "unstable"

    mode = row["mode"]
    if mode == "scalar_only":
        if row["rho_std_ratio"] < 0.96 and row["vorticity_rms_ratio"] < 1.03:
            return "compressive_smoothing"
        if row["div_rms_ratio"] > 1.05:
            return "compressive_feedback"
        return "near_baseline"

    if mode == "tensor_only":
        if row["vorticity_rms_ratio"] < 0.96 and row["enstrophy_ratio"] < 0.93:
            return "shear_memory_damping"
        if row["vorticity_rms_ratio"] > 1.05 or row["vort_high_k_ratio"] > 1.3:
            return "shear_amplifying"
        return "near_baseline"

    if mode == "combined":
        if row["rho_std_ratio"] < 0.96 and row["vorticity_rms_ratio"] < 0.97:
            return "combined_smoothing"
        if row["vorticity_rms_ratio"] > 1.05 or row["vort_high_k_ratio"] > 1.3:
            return "combined_amplifying"
        return "near_baseline"

    return "baseline"


def run_case(
    N,
    nu,
    mode,
    Lambda_chi,
    Lambda_Q,
    tau_chi,
    tau_Q,
    ic,
    seed,
    T,
    CFL,
    cs,
    D_rho,
    alpha_chi,
    D_chi,
    alpha_Q,
    D_Q,
    Lbox,
    instability_rho_max,
    instability_speed_max,
):
    x = np.linspace(0, Lbox, N, endpoint=False)
    y = np.linspace(0, Lbox, N, endpoint=False)
    X, Y = np.meshgrid(x, y, indexing="ij")
    dx = Lbox / N

    rho, u, v = make_initial_conditions(X, Y, ic=ic, seed=seed)
    chi = np.zeros_like(rho)
    Qxx = np.zeros_like(rho)
    Qxy = np.zeros_like(rho)

    use_scalar = mode in ["scalar_only", "combined"]
    use_tensor = mode in ["tensor_only", "combined"]

    eps_chi = 0.0
    eps_Q = 0.0
    if use_scalar and Lambda_chi > 0:
        eps_chi = Lambda_chi * D_chi / (alpha_chi * tau_chi)
    if use_tensor and Lambda_Q > 0:
        eps_Q = Lambda_Q * D_Q / (alpha_Q * tau_Q)

    # Spectral arrays
    kx = np.fft.fftfreq(N, d=dx) * 2*np.pi
    ky = np.fft.fftfreq(N, d=dx) * 2*np.pi
    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    K2 = KX*KX + KY*KY

    def ddx(f):
        return (np.roll(f, -1, axis=0) - np.roll(f, 1, axis=0)) / (2*dx)

    def ddy(f):
        return (np.roll(f, -1, axis=1) - np.roll(f, 1, axis=1)) / (2*dx)

    def lap(f):
        return (
            np.roll(f, -1, axis=0) + np.roll(f, 1, axis=0) +
            np.roll(f, -1, axis=1) + np.roll(f, 1, axis=1) -
            4*f
        ) / (dx*dx)

    def upwind_advect(q, u_, v_):
        qx_b = (q - np.roll(q, 1, axis=0)) / dx
        qx_f = (np.roll(q, -1, axis=0) - q) / dx
        qy_b = (q - np.roll(q, 1, axis=1)) / dx
        qy_f = (np.roll(q, -1, axis=1) - q) / dx
        qx = np.where(u_ >= 0, qx_b, qx_f)
        qy = np.where(v_ >= 0, qy_b, qy_f)
        return u_*qx + v_*qy

    def div_rho_flux(rho_, u_, v_):
        return ddx(rho_*u_) + ddy(rho_*v_)

    def divergence(u_, v_):
        return ddx(u_) + ddy(v_)

    def vorticity(u_, v_):
        return ddx(v_) - ddy(u_)

    def strain_components(u_, v_):
        ux, uy = ddx(u_), ddy(u_)
        vx, vy = ddx(v_), ddy(v_)
        div = ux + vy
        Sxx = ux - 0.5*div
        Sxy = 0.5*(uy + vx)
        return Sxx, Sxy

    def strain_mag(u_, v_):
        Sxx, Sxy = strain_components(u_, v_)
        return np.sqrt(2*Sxx*Sxx + 2*Sxy*Sxy)

    def high_k_fraction_2d(f, kthresh_frac=0.35):
        F = np.fft.fft2(f - np.mean(f))
        P = np.abs(F)**2
        kmag = np.sqrt(K2)
        kmax = np.max(kmag)
        return float(P[kmag > kthresh_frac*kmax].sum() / max(P.sum(), 1e-30))

    def update_chi(chi_, rho_, dt):
        source = alpha_chi * (rho_ - rho_.mean())
        chi_hat = np.fft.fft2(chi_)
        src_hat = np.fft.fft2(source)
        denom = 1.0 + dt*(D_chi*K2 + 1.0/tau_chi)
        return np.fft.ifft2((chi_hat + dt*src_hat) / denom).real

    def update_Q(Qxx_, Qxy_, u_, v_, dt):
        Sxx, Sxy = strain_components(u_, v_)
        Qxx_hat = np.fft.fft2(Qxx_)
        Qxy_hat = np.fft.fft2(Qxy_)
        Sxx_hat = np.fft.fft2(alpha_Q*Sxx)
        Sxy_hat = np.fft.fft2(alpha_Q*Sxy)
        denom = 1.0 + dt*(D_Q*K2 + 1.0/tau_Q)
        Qxx_new = np.fft.ifft2((Qxx_hat + dt*Sxx_hat) / denom).real
        Qxy_new = np.fft.ifft2((Qxy_hat + dt*Sxy_hat) / denom).real
        return Qxx_new, Qxy_new

    t = 0.0
    steps = 0
    unstable = False
    min_dt_seen = np.inf
    max_dt_seen = 0.0

    while t < T:
        speed = np.sqrt(u*u + v*v)
        max_speed = float(np.max(speed) + cs)
        dt_adv = dx / max(max_speed, 1e-12)
        dt_nu = dx*dx / max(nu, 1e-12)
        dt_Drho = dx*dx / max(D_rho, 1e-12)

        # chi and Q diffusion are semi-implicit, so they do not constrain dt.
        dt = CFL * min(dt_adv, dt_nu, dt_Drho)
        if t + dt > T:
            dt = T - t

        min_dt_seen = min(min_dt_seen, dt)
        max_dt_seen = max(max_dt_seen, dt)

        # Density update
        rho = rho + dt*(-div_rho_flux(rho, u, v) + D_rho*lap(rho))
        rho = np.maximum(rho, 1e-7)

        # Ordinary pressure
        log_rho = np.log(np.maximum(rho, 1e-8))
        press_x = -cs*cs*ddx(log_rho)
        press_y = -cs*cs*ddy(log_rho)

        # Velocity advection
        adv_u = upwind_advect(u, u, v)
        adv_v = upwind_advect(v, u, v)

        # Scalar lag force
        f_chi_x = -eps_chi * ddx(chi)
        f_chi_y = -eps_chi * ddy(chi)

        # Tensor lag force: div Q where Qyy=-Qxx
        f_Q_x = eps_Q * (ddx(Qxx) + ddy(Qxy))
        f_Q_y = eps_Q * (ddx(Qxy) - ddy(Qxx))

        u = u + dt*(-adv_u + press_x + nu*lap(u) + f_chi_x + f_Q_x)
        v = v + dt*(-adv_v + press_y + nu*lap(v) + f_chi_y + f_Q_y)

        if use_scalar:
            chi = update_chi(chi, rho, dt)
        if use_tensor:
            Qxx, Qxy = update_Q(Qxx, Qxy, u, v, dt)

        t += dt
        steps += 1

        if not (np.all(np.isfinite(rho)) and np.all(np.isfinite(u)) and np.all(np.isfinite(v)) and
                np.all(np.isfinite(chi)) and np.all(np.isfinite(Qxx)) and np.all(np.isfinite(Qxy))):
            unstable = True
            break
        if rho.max() > instability_rho_max or np.max(np.sqrt(u*u + v*v)) > instability_speed_max:
            unstable = True
            break

    div = divergence(u, v)
    vort = vorticity(u, v)
    S = strain_mag(u, v)
    Qmag = np.sqrt(2*Qxx*Qxx + 2*Qxy*Qxy)
    speed2 = u*u + v*v

    return {
        "N": N,
        "nu": nu,
        "mode": mode,
        "Lambda_chi": Lambda_chi,
        "Lambda_Q": Lambda_Q,
        "tau_chi": tau_chi,
        "tau_Q": tau_Q,
        "eps_chi": eps_chi,
        "eps_Q": eps_Q,
        "alpha_chi": alpha_chi,
        "D_chi": D_chi,
        "alpha_Q": alpha_Q,
        "D_Q": D_Q,
        "ic": ic,
        "seed": seed,
        "T": T,
        "steps": steps,
        "min_dt_seen": float(min_dt_seen),
        "max_dt_seen": float(max_dt_seen),
        "rho_std": float(np.std(rho)),
        "rho_min": float(np.min(rho)),
        "rho_max": float(np.max(rho)),
        "kinetic_energy": float(0.5*np.mean(speed2)),
        "div_rms": float(np.sqrt(np.mean(div*div))),
        "vorticity_rms": float(np.sqrt(np.mean(vort*vort))),
        "enstrophy": float(0.5*np.mean(vort*vort)),
        "strain_rms": float(np.sqrt(np.mean(S*S))),
        "rho_high_k": high_k_fraction_2d(rho),
        "vort_high_k": high_k_fraction_2d(vort),
        "strain_high_k": high_k_fraction_2d(S),
        "chi_std": float(np.std(chi)),
        "Q_rms": float(np.sqrt(np.mean(Qmag*Qmag))),
        "Q_high_k": high_k_fraction_2d(Qmag),
        "unstable_flag": bool(unstable),
    }


def add_ratios(row, baseline):
    ratio_keys = [
        "rho_std", "kinetic_energy", "div_rms", "vorticity_rms", "enstrophy",
        "strain_rms", "rho_high_k", "vort_high_k", "strain_high_k"
    ]
    for key in ratio_keys:
        row[key + "_baseline"] = baseline[key]
        row[key + "_ratio"] = row[key] / max(baseline[key], 1e-30)
    return row


def plot_outputs(df, summary, outdir):
    outdir = Path(outdir)

    # Mode aggregate by Lambda
    for mode, xcol in [("scalar_only", "Lambda_chi"), ("tensor_only", "Lambda_Q"), ("combined", "Lambda_Q")]:
        sub = df[df["mode"] == mode].copy()
        sub = sub[sub[xcol] > 0]
        if sub.empty:
            continue

        agg = sub.groupby(xcol).agg(
            rho_ratio_mean=("rho_std_ratio", "mean"),
            rho_ratio_std=("rho_std_ratio", "std"),
            div_ratio_mean=("div_rms_ratio", "mean"),
            div_ratio_std=("div_rms_ratio", "std"),
            vort_ratio_mean=("vorticity_rms_ratio", "mean"),
            vort_ratio_std=("vorticity_rms_ratio", "std"),
            enstrophy_ratio_mean=("enstrophy_ratio", "mean"),
            enstrophy_ratio_std=("enstrophy_ratio", "std"),
            strain_ratio_mean=("strain_rms_ratio", "mean"),
            strain_ratio_std=("strain_rms_ratio", "std"),
            vort_highk_ratio_mean=("vort_high_k_ratio", "mean"),
            vort_highk_ratio_std=("vort_high_k_ratio", "std"),
        ).reset_index()
        agg.to_csv(outdir / f"aggregate_{mode}.csv", index=False)

        plt.figure(figsize=(8, 5.5))
        plt.errorbar(agg[xcol], agg["rho_ratio_mean"], yerr=agg["rho_ratio_std"], marker="o", capsize=4, label="density")
        plt.errorbar(agg[xcol], agg["div_ratio_mean"], yerr=agg["div_ratio_std"], marker="o", capsize=4, label="divergence")
        plt.errorbar(agg[xcol], agg["vort_ratio_mean"], yerr=agg["vort_ratio_std"], marker="o", capsize=4, label="vorticity")
        plt.errorbar(agg[xcol], agg["strain_ratio_mean"], yerr=agg["strain_ratio_std"], marker="o", capsize=4, label="strain")
        plt.xscale("log")
        plt.xlabel(xcol)
        plt.ylabel("ratio to baseline")
        plt.title(f"2D robustness aggregate response: {mode}")
        plt.legend()
        plt.tight_layout()
        plt.savefig(outdir / f"aggregate_response_{mode}.png", dpi=180)
        plt.close()

        plt.figure(figsize=(8, 5.5))
        plt.errorbar(agg[xcol], agg["vort_highk_ratio_mean"], yerr=agg["vort_highk_ratio_std"], marker="o", capsize=4)
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel(xcol)
        plt.ylabel("vorticity high-k ratio")
        plt.title(f"2D robustness vorticity high-k: {mode}")
        plt.tight_layout()
        plt.savefig(outdir / f"aggregate_vort_highk_{mode}.png", dpi=180)
        plt.close()

    # Regime counts
    regime_counts = df["regime"].value_counts().rename_axis("regime").reset_index(name="count")
    regime_counts.to_csv(outdir / "regime_counts.csv", index=False)
    plt.figure(figsize=(9, 5))
    plt.bar(regime_counts["regime"], regime_counts["count"])
    plt.ylabel("number of runs")
    plt.title("2D robustness regime counts")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(outdir / "regime_counts.png", dpi=180)
    plt.close()


def main():
    parser = argparse.ArgumentParser(description="SFT V11.7 2D scalar/tensor robustness runner")

    parser.add_argument("--preset", default="big", choices=["pilot", "big", "hero", "custom"])
    parser.add_argument("--outdir", default="sft_v117_2d_robustness_output")
    parser.add_argument("--T", type=float, default=1.2)
    parser.add_argument("--CFL", type=float, default=0.12)
    parser.add_argument("--cs", type=float, default=0.75)
    parser.add_argument("--D-rho", type=float, default=0.0006)
    parser.add_argument("--alpha-chi", type=float, default=1.0)
    parser.add_argument("--D-chi", type=float, default=0.08)
    parser.add_argument("--alpha-Q", type=float, default=0.55)
    parser.add_argument("--D-Q", type=float, default=0.06)
    parser.add_argument("--tau-chi", type=float, default=0.40)
    parser.add_argument("--tau-Q-list", default="")
    parser.add_argument("--Lbox", type=float, default=2*math.pi)
    parser.add_argument("--seed", type=int, default=20260501)

    parser.add_argument("--N-list", default="")
    parser.add_argument("--nu-list", default="")
    parser.add_argument("--lambda-chi-list", default="")
    parser.add_argument("--lambda-Q-list", default="")
    parser.add_argument("--ic-list", default="")

    parser.add_argument("--instability-rho-max", type=float, default=8.0)
    parser.add_argument("--instability-speed-max", type=float, default=8.0)
    parser.add_argument("--checkpoint-every", type=int, default=1)

    args = parser.parse_args()

    if args.preset == "pilot":
        N_list = [64, 96]
        nu_list = [0.0025]
        lambda_chi_list = [0.25, 0.75, 1.15]
        lambda_Q_list = [0.25, 0.75, 1.15]
        tau_Q_list = [0.30]
        ic_list = ["mixed"]

    elif args.preset == "big":
        N_list = [128, 256, 512]
        nu_list = [0.0025]
        lambda_chi_list = [0.25, 0.75, 1.15, 1.70]
        lambda_Q_list = [0.25, 0.75, 1.15, 1.70]
        tau_Q_list = [0.30, 0.60]
        ic_list = ["mixed", "vortex_pair", "random_smooth"]

    elif args.preset == "hero":
        N_list = [128, 256, 512]
        nu_list = [0.0015, 0.0025, 0.005]
        lambda_chi_list = [0.25, 0.75, 1.15, 1.70]
        lambda_Q_list = [0.25, 0.75, 1.15, 1.70]
        tau_Q_list = [0.30, 0.60]
        ic_list = ["mixed", "vortex_pair", "shear_layer", "random_smooth"]

    else:
        N_list = parse_int_list(args.N_list)
        nu_list = parse_float_list(args.nu_list)
        lambda_chi_list = parse_float_list(args.lambda_chi_list)
        lambda_Q_list = parse_float_list(args.lambda_Q_list)
        tau_Q_list = parse_float_list(args.tau_Q_list)
        ic_list = parse_str_list(args.ic_list)
        if not (N_list and nu_list and lambda_chi_list and lambda_Q_list and tau_Q_list and ic_list):
            raise ValueError("For custom, provide all list args.")

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    config = {
        "preset": args.preset,
        "N_list": N_list,
        "nu_list": nu_list,
        "lambda_chi_list": lambda_chi_list,
        "lambda_Q_list": lambda_Q_list,
        "tau_Q_list": tau_Q_list,
        "ic_list": ic_list,
        "T": args.T,
        "CFL": args.CFL,
        "cs": args.cs,
        "D_rho": args.D_rho,
        "alpha_chi": args.alpha_chi,
        "D_chi": args.D_chi,
        "alpha_Q": args.alpha_Q,
        "D_Q": args.D_Q,
        "tau_chi": args.tau_chi,
        "Lbox": args.Lbox,
        "seed": args.seed,
    }
    (outdir / "config.json").write_text(json.dumps(config, indent=2))

    rows = []
    baselines = []
    results_path = outdir / "runs.csv"
    baseline_path = outdir / "baselines.csv"

    total_per_group = 1 + len(lambda_chi_list) + len(lambda_Q_list)*len(tau_Q_list) + len(lambda_Q_list)*len(tau_Q_list)
    total_runs = len(ic_list)*len(N_list)*len(nu_list)*total_per_group
    completed = 0
    start = time.time()

    for ic in ic_list:
        for N in N_list:
            for nu in nu_list:
                print(f"\n[baseline] ic={ic} N={N} nu={nu}", flush=True)
                baseline = run_case(
                    N=N, nu=nu, mode="baseline", Lambda_chi=0.0, Lambda_Q=0.0,
                    tau_chi=args.tau_chi, tau_Q=0.30, ic=ic, seed=args.seed,
                    T=args.T, CFL=args.CFL, cs=args.cs, D_rho=args.D_rho,
                    alpha_chi=args.alpha_chi, D_chi=args.D_chi,
                    alpha_Q=args.alpha_Q, D_Q=args.D_Q,
                    Lbox=args.Lbox,
                    instability_rho_max=args.instability_rho_max,
                    instability_speed_max=args.instability_speed_max,
                )
                baselines.append(baseline)
                completed += 1

                # Scalar-only sweep
                for Lchi in lambda_chi_list:
                    print(f"[run {completed+1}/{total_runs}] scalar ic={ic} N={N} nu={nu} Lchi={Lchi}", flush=True)
                    row = run_case(
                        N=N, nu=nu, mode="scalar_only", Lambda_chi=Lchi, Lambda_Q=0.0,
                        tau_chi=args.tau_chi, tau_Q=0.30, ic=ic, seed=args.seed,
                        T=args.T, CFL=args.CFL, cs=args.cs, D_rho=args.D_rho,
                        alpha_chi=args.alpha_chi, D_chi=args.D_chi,
                        alpha_Q=args.alpha_Q, D_Q=args.D_Q,
                        Lbox=args.Lbox,
                        instability_rho_max=args.instability_rho_max,
                        instability_speed_max=args.instability_speed_max,
                    )
                    row = add_ratios(row, baseline)
                    row["regime"] = classify(row)
                    rows.append(row)
                    completed += 1
                    if completed % args.checkpoint_every == 0:
                        pd.DataFrame(rows).to_csv(results_path, index=False)
                        pd.DataFrame(baselines).to_csv(baseline_path, index=False)

                # Tensor-only and combined sweeps
                for mode in ["tensor_only", "combined"]:
                    for LQ in lambda_Q_list:
                        for tau_Q in tau_Q_list:
                            Lchi = 0.75 if mode == "combined" else 0.0
                            print(f"[run {completed+1}/{total_runs}] {mode} ic={ic} N={N} nu={nu} LQ={LQ} tauQ={tau_Q}", flush=True)
                            row = run_case(
                                N=N, nu=nu, mode=mode, Lambda_chi=Lchi, Lambda_Q=LQ,
                                tau_chi=args.tau_chi, tau_Q=tau_Q, ic=ic, seed=args.seed,
                                T=args.T, CFL=args.CFL, cs=args.cs, D_rho=args.D_rho,
                                alpha_chi=args.alpha_chi, D_chi=args.D_chi,
                                alpha_Q=args.alpha_Q, D_Q=args.D_Q,
                                Lbox=args.Lbox,
                                instability_rho_max=args.instability_rho_max,
                                instability_speed_max=args.instability_speed_max,
                            )
                            row = add_ratios(row, baseline)
                            row["regime"] = classify(row)
                            rows.append(row)
                            completed += 1
                            if completed % args.checkpoint_every == 0:
                                pd.DataFrame(rows).to_csv(results_path, index=False)
                                pd.DataFrame(baselines).to_csv(baseline_path, index=False)

                            elapsed = (time.time() - start)/60
                            print(f"  done; regime={row['regime']}; elapsed={elapsed:.1f} min", flush=True)

    df = pd.DataFrame(rows)
    bdf = pd.DataFrame(baselines)
    df.to_csv(results_path, index=False)
    bdf.to_csv(baseline_path, index=False)

    summary = df.groupby(["ic", "N", "nu", "mode", "Lambda_chi", "Lambda_Q"]).agg(
        rho_ratio_mean=("rho_std_ratio", "mean"),
        rho_ratio_std=("rho_std_ratio", "std"),
        div_ratio_mean=("div_rms_ratio", "mean"),
        div_ratio_std=("div_rms_ratio", "std"),
        vort_ratio_mean=("vorticity_rms_ratio", "mean"),
        vort_ratio_std=("vorticity_rms_ratio", "std"),
        enstrophy_ratio_mean=("enstrophy_ratio", "mean"),
        strain_ratio_mean=("strain_rms_ratio", "mean"),
        vort_highk_ratio_mean=("vort_high_k_ratio", "mean"),
        strain_highk_ratio_mean=("strain_high_k_ratio", "mean"),
        unstable_count=("unstable_flag", "sum"),
        mean_steps=("steps", "mean"),
    ).reset_index()
    summary.to_csv(outdir / "summary_by_group.csv", index=False)

    corr_rows = []
    # Scalar correlations by ic/N/nu
    scalar = df[df["mode"] == "scalar_only"].copy()
    if not scalar.empty:
        for keys, sub in scalar.groupby(["ic", "N", "nu"]):
            ic, N, nu = keys
            for metric in ["rho_std_ratio", "div_rms_ratio", "vorticity_rms_ratio", "enstrophy_ratio"]:
                corr = np.corrcoef(np.log(sub["Lambda_chi"]), sub[metric])[0, 1]
                corr_rows.append({"mode": "scalar_only", "ic": ic, "N": N, "nu": nu, "metric": metric, "corr_logLambda": float(corr)})

    for mode in ["tensor_only", "combined"]:
        submode = df[df["mode"] == mode].copy()
        if not submode.empty:
            for keys, sub in submode.groupby(["ic", "N", "nu"]):
                ic, N, nu = keys
                for metric in ["rho_std_ratio", "div_rms_ratio", "vorticity_rms_ratio", "enstrophy_ratio", "vort_high_k_ratio"]:
                    corr = np.corrcoef(np.log(sub["Lambda_Q"]), sub[metric])[0, 1]
                    corr_rows.append({"mode": mode, "ic": ic, "N": N, "nu": nu, "metric": metric, "corr_logLambda": float(corr)})

    corr_df = pd.DataFrame(corr_rows)
    corr_df.to_csv(outdir / "correlations.csv", index=False)

    plot_outputs(df, summary, outdir)

    print("\nDone.")
    print(f"Output directory: {outdir.resolve()}")
    print(f"Runs CSV: {results_path.resolve()}")
    print(f"Baselines CSV: {baseline_path.resolve()}")


if __name__ == "__main__":
    main()
