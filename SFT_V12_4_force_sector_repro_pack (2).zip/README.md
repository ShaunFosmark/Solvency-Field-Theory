# SFT V12.4 Force-Sector and Electroweak Bridge Repro Pack

Created UTC: 2026-06-02T00:40:47Z

## Canonical public artifact

`PUBLIC_NOTE/SFT_V12_4_Force_Sector.pdf`

This is the public-facing V12.4 force-sector bridge. Internal V12.5/V12.6/V12.7 working notes are not part of the public version history. Provenance is tracked by FORCE audit gates.

## What this pack contains

- The final public PDF.
- FORCE audit ZIP packs used as provenance/evidence trail.
- `MANIFEST.json` with SHA256 checksums and claim boundary.

## Claim boundary

Safe architectural claims include mass-as-cadence, charge-as-worldline-framing holonomy, weak branch access by closure handedness, conditional Coulomb kernel recovery, non-Abelian branch-curvature bridge, and budget-loading mass map.

Not claimed: alpha, Higgs vev, Weinberg angle, gauge couplings, Yukawas, CKM/PMNS, precision electroweak constants, or full native Standard Model derivation.
