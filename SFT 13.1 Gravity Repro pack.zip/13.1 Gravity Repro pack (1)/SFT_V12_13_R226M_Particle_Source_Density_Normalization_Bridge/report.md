
# SFT V12.13 R226M — Particle Source Density Normalization Bridge

Generated: 2026-06-23T17:17:16Z

Verdict:
PARTIAL_PASS_PARTICLE_SOURCE_DENSITY_NORMALIZATION_BRIDGE_TESTED_QI_DEFINED_AS_NORMALIZED_MAINTAINED_CLOSURE_DEMAND_RHO_SET_EQUALS_SUM_QI_DELTA_COARSE_GRAINS_TO_CONTINUUM_SOURCE_ADDITIVITY_AND_COARSE_GRAINING_PASS_EXTERIOR_FIELD_DEPENDS_ON_TOTAL_Q_ROOT_NORMALIZATION_CHANGES_AMPLITUDE_NOT_SHAPE_OPERATION_DENSITY_PRESSURE_CHANNEL_COMPATIBLE_DIRECTIONAL_RANDOM_CANCELLATION_PRESERVED_G_DERIVATION_SPECIES_MAP_REAL_STELLAR_STRUCTURE_AND_VALIDATION_OPEN

## Purpose

R226M defines the bridge from particle settlement demand q_i to continuum rho_set without deriving G.

## Source dictionary

                       level        source_symbol                                  definition                                                                                    cold_limit                    status                     absolute_G_status
single locally real particle                  q_i normalized maintained closure-demand source q_i proportional to particle energy divided by c^2, expressed in normalized mass-weight units         DEFINITION_BRIDGE                           not derived
              many particles           rho_set(x)                    sum_i q_i delta(x - x_i)                                    coarse-grains to matter-energy density in normalized units TESTED_BY_COARSE_GRAINING                           not derived
            continuum matter              rho_ops                                rho + 3p/c^2                                                              rho_ops -> rho when p negligible     COMPATIBLE_WITH_V12_3                           not derived
            absolute gravity kappa_root * rho_set             root-normalized physical source                                                             requires root-state normalization                      OPEN root invariant / G normalization open

## Additivity tests

 N_particles  sum_q_i  target_total_q    abs_error    min_q    max_q  q_dynamic_range status
          10      1.0             1.0 0.000000e+00 0.015912 0.532935        33.492186   PASS
         100      1.0             1.0 2.220446e-16 0.000702 0.045009        64.093300   PASS
        1000      1.0             1.0 0.000000e+00 0.000054 0.009413       175.297183   PASS
       10000      1.0             1.0 0.000000e+00 0.000003 0.001362       541.782290   PASS

## Radial coarse-graining tests

 N_particles  expected_uniform_density  shell_density_rel_rms_error_excluding_inner_bins  shell_density_rel_mean_error               status
         300                  0.238732                                          0.336121                      0.102536           DIAGNOSTIC
        1000                  0.238732                                          0.271845                      0.054528           DIAGNOSTIC
        3000                  0.238732                                          0.092028                      0.016325 PASS_COARSE_GRAINING
       10000                  0.238732                                          0.078754                      0.017823 PASS_COARSE_GRAINING
       30000                  0.238732                                          0.034187                      0.013774 PASS_COARSE_GRAINING

## Exterior distribution invariance tests

          distribution  total_q  phi_slope   g_slope  phi_rel_rms_vs_total_q_exterior  g_rel_rms_vs_total_q_exterior
               uniform      1.0  -1.000606 -2.001520                         0.000483                       0.001180
centrally_concentrated      1.0  -0.998041 -1.995264                         0.001847                       0.004115

## Root normalization scaling tests

 kappa_root  phi_slope  g_slope  phi_amplitude_at_r2  g_amplitude_at_r2               status
        0.1       -1.0     -2.0             0.050006           0.025009 PASS_SHAPE_INVARIANT
        0.3       -1.0     -2.0             0.150017           0.075026 PASS_SHAPE_INVARIANT
        1.0       -1.0     -2.0             0.500058           0.250086 PASS_SHAPE_INVARIANT
        3.0       -1.0     -2.0             1.500174           0.750258 PASS_SHAPE_INVARIANT
       10.0       -1.0     -2.0             5.000581           2.500861 PASS_SHAPE_INVARIANT
      100.0       -1.0     -2.0            50.005807          25.008614 PASS_SHAPE_INVARIANT

## Operation-density pressure-channel tests

 central_w0_p_over_rhoc2  analytic_Q_ops_over_Q_cold  numeric_Q_ops_over_Q_cold    abs_error status
                0.000000                      1.0000                     1.0000 0.000000e+00   PASS
                0.001000                      1.0012                     1.0012 5.250023e-12   PASS
                0.010000                      1.0120                     1.0120 5.249978e-11   PASS
                0.050000                      1.0600                     1.0600 2.625000e-10   PASS
                0.100000                      1.1200                     1.1200 5.250000e-10   PASS
                0.333333                      1.4000                     1.4000 1.750000e-09   PASS

## Directional source tests

 N_particles  equal_q_random_direction_fraction  weighted_q_random_direction_fraction  expected_equal_q_order  coherent_direction_fraction status
          30                           0.166489                              0.231411                0.182574                          1.0   PASS
         100                           0.088776                              0.118588                0.100000                          1.0   PASS
         300                           0.053313                              0.071867                0.057735                          1.0   PASS
        1000                           0.029204                              0.041874                0.031623                          1.0   PASS
        3000                           0.016987                              0.023903                0.018257                          1.0   PASS
       10000                           0.008909                              0.012070                0.010000                          1.0   PASS

## Forbidden derivation guardrails

                                      candidate_move  uses_G  uses_Planck_area  uses_observed_star_data  uses_species_mass_table           ruling                                                        reason
          q_i = normalized maintained closure demand   False             False                    False                    False          ALLOWED                    Defines normalized source dictionary only.
                    rho_set = sum_i q_i delta(x-x_i)   False             False                    False                    False          ALLOWED                                       Coarse-graining bridge.
               kappa_root chosen to match measured G    True             False                    False                    False CALIBRATION_ONLY Allowed only after structural derivation; not a G derivation.
q_i defined from Planck area or G before calibration    True              True                    False                    False  REJECT_CIRCULAR                Smuggles absolute gravitational normalization.
          q_i adjusted per species to fit mass table   False             False                    False                     True  REJECT_FOR_R226                                         Species map deferred.
           rho_set tuned to observed stellar gravity   False             False                     True                    False  REJECT_FOR_R226                No empirical validation or tuning in this run.

## Claim boundary

                                                                       claim  status                      safe_wording
           R226M defines q_i as normalized maintained closure-demand source. ALLOWED      normalized source dictionary
             rho_set = sum_i q_i delta(x-x_i) is the coarse-graining bridge. ALLOWED   synthetic source-density bridge
Root normalization controls absolute amplitude but not exterior field shape. ALLOWED shape invariance under kappa_root
                                                   R226M derives Newton's G. BLOCKED G/root normalization remains open
                   R226M derives species-specific particle source strengths. BLOCKED          species map remains open
                                     R226M validates against observed stars. BLOCKED             no observed data used
                                        R226M solves real stellar structure. BLOCKED          toy source profiles only

## Open claims

                          open_item status                                                                               description
        absolute root normalization   OPEN q_i is normalized; physical G-scale coupling still requires root invariant / calibration.
                 species source map   OPEN                                            No electron/proton/neutron source map derived.
nuclear binding and internal energy   OPEN                     Real stellar matter must include binding/internal energy bookkeeping.
     relativistic pressure profiles   OPEN                                                        Only toy pressure profiles tested.
         tensor settlement dynamics   OPEN                       Directional cancellation tested; full tensor equations not derived.
           observational validation   OPEN                                                       No data-facing validation in R226M.

## Interpretation

R226M supports the normalized source-density dictionary:

    q_i = normalized maintained closure-demand source

and

    rho_set(x) = sum_i q_i delta(x - x_i).

The cold continuum limit is matter-energy density in normalized units. Pressure/radiation support enters through the operation-density correction rho + 3p/c^2.

The absolute amplitude remains separated as kappa_root. Scaling kappa_root changes the field amplitude but preserves the exterior shape. Therefore R226M does not derive G and does not smuggle Planck/root normalization.

The bridge is now:

    V12.13 particle closure support
    -> normalized q_i
    -> rho_set
    -> accumulated settlement gravity skeleton

## Ruling

Source-density normalization bridge passes as a structural dictionary.
G normalization, species q_i, real stellar structure, and validation remain open.
