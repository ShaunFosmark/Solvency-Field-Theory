#!/usr/bin/env python3
"""
SFT V13.1 / R228M — Binding/Internal-Energy Source Accounting

Branch:
    SFT V13.1 — Particle-to-Star Gravity Accumulation Unification

Purpose:
    Extend the R225M-R227M particle-to-star bridge by separating the components
    of a synthetic stellar source ledger:

        rest-mass particle source
        internal thermal energy
        radiation energy
        pressure trace contribution
        negative binding energy

Prior locked chain:
    R225M:
        particle closure support -> q_i -> rho_set -> Lambda_00 -> star gravity

    R226M:
        q_i = normalized maintained closure-demand source
        rho_set(x) = sum_i q_i delta(x-x_i)
        absolute amplitude = kappa_root * rho_set, with G/root normalization open

    R227M:
        rho_ops = rho_set + 3p/c^2
        Q_ops(r) drives interior field
        exterior field depends on total Q_ops
        whole-star 6pi rejected as category error

R228M question:
    Can the toy stellar source be decomposed into rest mass, internal energy,
    radiation, pressure trace, and negative binding energy while preserving
    additivity, exterior total-source behavior, root-normalization shape
    invariance, and claim boundaries?

Dimensionless units:
    c = 1
    R = 1
    normalized rest-mass source Q_rest = 1

Source accounting:
    rho_rest     = cold particle settlement source
    u_int        = internal thermal energy density / c^2
    rho_rad      = radiation energy density / c^2
    p_gas        = (gamma - 1) u_int c^2
    p_rad        = rho_rad c^2 / 3
    rho_pressure = 3(p_gas + p_rad)/c^2
    rho_bind     = negative binding-energy density / c^2, synthetic proxy

    rho_active =
        rho_rest + u_int + rho_rad + rho_pressure + rho_bind

Important identities:
    gas active internal contribution:
        u_int + 3p_gas/c^2 = u_int * (1 + 3(gamma - 1))
        for gamma = 5/3 -> 3 u_int

    radiation active contribution:
        rho_rad + 3p_rad/c^2 = 2 rho_rad

    binding contribution:
        rho_bind < 0
        reduces total active source but does not replace rest mass.

Tests:
    1. Component ledger additivity.
    2. Gas pressure active-source identity.
    3. Radiation pressure active-source identity.
    4. Binding term is negative and reduces active source.
    5. Total active source remains positive for physical toy cases.
    6. Enclosed Q_active drives interior field.
    7. Exterior phi ~ Q_active/r and g ~ Q_active/r^2.
    8. Root normalization changes amplitude, not slopes.
    9. Whole-star 6pi rejected as category error.
    10. G/Planck/species/observed-star fitting rejected by guardrail.

Claim boundary:
    - synthetic source ledger only
    - no observed star data
    - no Newton G derivation
    - no species source map
    - no real equation of state
    - no nuclear burning / stellar evolution
    - no compact-star/TOV claim
    - no top/e closure claim

Outputs:
    SFT_V13_1_R228M_Binding_Internal_Energy_Source_Accounting/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        figures/*.png
        scripts/run_R228M.py

    SFT_V13_1_R228M_Binding_Internal_Energy_Source_Accounting_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V13_1_R228M_Binding_Internal_Energy_Source_Accounting"

RADIUS = 1.0
TOTAL_Q_REST = 1.0
GAMMA_GAS = 5.0 / 3.0

TWO_PI = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

# V12.13 / V13.1 context only.
N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = 3.0 * math.pi - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "file_count_excluding_manifest": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def trapz(y: np.ndarray, x: np.ndarray) -> float:
    if hasattr(np, "trapezoid"):
        return float(np.trapezoid(y, x))
    return float(np.trapz(y, x))


def cumulative_trapz(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    out = np.zeros_like(y, dtype=float)
    dx = np.diff(x)
    out[1:] = np.cumsum(0.5 * (y[1:] + y[:-1]) * dx)
    return out


def log_slope(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (x > 0) & (y > 0)
    coeff = np.polyfit(np.log(x[mask]), np.log(y[mask]), 1)
    return float(coeff[0])


def volume_integral(r: np.ndarray, density: np.ndarray) -> float:
    return trapz(4.0 * math.pi * r**2 * density, r)


def density_profile(profile: str, r: np.ndarray, R: float = RADIUS) -> np.ndarray:
    x = r / R

    if profile == "uniform":
        raw = np.ones_like(r)
    elif profile == "quadratic":
        raw = np.maximum(1.0 - x**2, 0.0)
    elif profile == "concentrated":
        raw = 1.0 / (1.0 + (x / 0.35) ** 2) ** 2
        raw[x > 1.0] = 0.0
    elif profile == "shell_weighted":
        raw = np.maximum(x * (1.0 - x), 0.0)
    else:
        raise ValueError(f"Unknown profile: {profile}")

    return raw


def normalize_density_to_rest_mass(r: np.ndarray, rho_raw: np.ndarray, target: float = TOTAL_Q_REST) -> np.ndarray:
    mass_raw = volume_integral(r, rho_raw)
    if mass_raw <= 0:
        raise ValueError("Raw density integrates to zero.")
    return rho_raw * (target / mass_raw)


def enclosed_source(r: np.ndarray, rho: np.ndarray) -> np.ndarray:
    return cumulative_trapz(4.0 * math.pi * r**2 * rho, r)


def gravity_from_enclosed(r: np.ndarray, Q_enclosed: np.ndarray) -> np.ndarray:
    g = np.zeros_like(r)
    mask = r > 0
    g[mask] = Q_enclosed[mask] / r[mask] ** 2
    return g


def potential_from_g(r: np.ndarray, g: np.ndarray, Q_total: float, R: float = RADIUS) -> np.ndarray:
    phi = np.zeros_like(r)
    phi[-1] = Q_total / R
    for i in range(len(r) - 2, -1, -1):
        dr = r[i + 1] - r[i]
        phi[i] = phi[i + 1] + 0.5 * (g[i + 1] + g[i]) * dr
    return phi


def temperature_shape(shape: str, r: np.ndarray) -> np.ndarray:
    x = r / RADIUS
    if shape == "core_hot":
        return np.maximum(1.0 - x**2, 0.0)
    if shape == "flat":
        return np.ones_like(r)
    if shape == "steep_core":
        return np.maximum(1.0 - x**2, 0.0) ** 2
    raise ValueError(f"Unknown temperature shape: {shape}")


def make_component_ledger(
    case_name: str,
    profile: str,
    theta_c: float,
    rad_c: float,
    binding_fraction: float,
    temp_shape_name: str,
    n_grid: int = 2501,
) -> dict:
    """
    theta_c:
        u_int(0) / rho_rest(0)

    rad_c:
        rho_rad(0) / rho_rest(0)

    binding_fraction:
        requested magnitude of total binding contribution as a fraction of
        positive pre-binding active source.

        Q_bind = -binding_fraction * Q_positive_prebind

    Binding density shape:
        computed from synthetic self-settlement energy proxy:
        rho_bind_raw = -0.5 rho_prebind phi_prebind
        then scaled to requested Q_bind.
    """
    r = np.linspace(0.0, RADIUS, n_grid)

    rho_raw = density_profile(profile, r)
    rho_rest = normalize_density_to_rest_mass(r, rho_raw)

    T_shape = temperature_shape(temp_shape_name, r)

    rho0 = rho_rest[0] if rho_rest[0] > 0 else float(np.max(rho_rest))

    u_int = theta_c * rho0 * T_shape * (rho_rest / max(rho0, 1e-30))
    rho_rad = rad_c * rho0 * (T_shape ** 4)

    p_gas = (GAMMA_GAS - 1.0) * u_int
    p_rad = rho_rad / 3.0
    p_total = p_gas + p_rad

    rho_pressure = 3.0 * p_total

    rho_positive_prebind = rho_rest + u_int + rho_rad + rho_pressure
    Q_positive_prebind = volume_integral(r, rho_positive_prebind)

    Q_pre = enclosed_source(r, rho_rest + u_int + rho_rad)
    g_pre = gravity_from_enclosed(r, Q_pre)
    phi_pre = potential_from_g(r, g_pre, Q_total=float(Q_pre[-1]))

    rho_bind_raw = -0.5 * (rho_rest + u_int + rho_rad) * phi_pre
    Q_bind_raw = volume_integral(r, rho_bind_raw)

    if binding_fraction > 0 and abs(Q_bind_raw) > 0:
        bind_scale = binding_fraction * Q_positive_prebind / abs(Q_bind_raw)
    else:
        bind_scale = 0.0

    rho_bind = bind_scale * rho_bind_raw
    rho_active = rho_positive_prebind + rho_bind

    Q_active = enclosed_source(r, rho_active)
    g_active = gravity_from_enclosed(r, Q_active)
    phi_active = potential_from_g(r, g_active, Q_total=float(Q_active[-1]))

    return {
        "case_name": case_name,
        "profile": profile,
        "theta_c": theta_c,
        "rad_c": rad_c,
        "binding_fraction": binding_fraction,
        "temp_shape": temp_shape_name,
        "r": r,
        "rho_rest": rho_rest,
        "u_int": u_int,
        "rho_rad": rho_rad,
        "p_gas": p_gas,
        "p_rad": p_rad,
        "p_total": p_total,
        "rho_pressure": rho_pressure,
        "rho_bind": rho_bind,
        "rho_active": rho_active,
        "Q_active": Q_active,
        "g_active": g_active,
        "phi_active": phi_active,
        "rho_positive_prebind": rho_positive_prebind,
        "Q_positive_prebind": Q_positive_prebind,
        "bind_scale": bind_scale,
    }


def exterior_law(Q_total: float, r_min: float = 1.25, r_max: float = 8.0) -> dict:
    r_ext = np.linspace(r_min, r_max, 100)
    phi_ext = Q_total / r_ext
    g_ext = Q_total / r_ext**2
    return {
        "r_ext": r_ext,
        "phi_ext": phi_ext,
        "g_ext": g_ext,
        "phi_slope": log_slope(r_ext, phi_ext),
        "g_slope": log_slope(r_ext, g_ext),
    }


def run_component_cases() -> tuple[pd.DataFrame, dict, dict]:
    cases = [
        {
            "case_name": "cold_uniform_reference",
            "profile": "uniform",
            "theta_c": 0.0,
            "rad_c": 0.0,
            "binding_fraction": 0.0,
            "temp_shape": "flat",
        },
        {
            "case_name": "thermal_quadratic",
            "profile": "quadratic",
            "theta_c": 0.01,
            "rad_c": 0.0,
            "binding_fraction": 0.0,
            "temp_shape": "core_hot",
        },
        {
            "case_name": "radiation_supported",
            "profile": "quadratic",
            "theta_c": 0.005,
            "rad_c": 0.01,
            "binding_fraction": 0.0,
            "temp_shape": "core_hot",
        },
        {
            "case_name": "bound_thermal",
            "profile": "quadratic",
            "theta_c": 0.01,
            "rad_c": 0.002,
            "binding_fraction": 0.02,
            "temp_shape": "core_hot",
        },
        {
            "case_name": "compact_synthetic",
            "profile": "concentrated",
            "theta_c": 0.05,
            "rad_c": 0.02,
            "binding_fraction": 0.08,
            "temp_shape": "steep_core",
        },
        {
            "case_name": "shell_weighted_control",
            "profile": "shell_weighted",
            "theta_c": 0.01,
            "rad_c": 0.005,
            "binding_fraction": 0.03,
            "temp_shape": "core_hot",
        },
    ]

    ledgers = {}
    rows = []

    for spec in cases:
        ledger = make_component_ledger(**spec)
        ledgers[spec["case_name"]] = ledger

        r = ledger["r"]

        Q_rest = volume_integral(r, ledger["rho_rest"])
        Q_int = volume_integral(r, ledger["u_int"])
        Q_rad = volume_integral(r, ledger["rho_rad"])
        Q_pgas = volume_integral(r, 3.0 * ledger["p_gas"])
        Q_prad = volume_integral(r, 3.0 * ledger["p_rad"])
        Q_pressure = volume_integral(r, ledger["rho_pressure"])
        Q_bind = volume_integral(r, ledger["rho_bind"])
        Q_active = volume_integral(r, ledger["rho_active"])
        Q_component_sum = Q_rest + Q_int + Q_rad + Q_pressure + Q_bind

        gas_active_ratio = None
        if Q_int > 1e-14:
            gas_active_ratio = (Q_int + Q_pgas) / Q_int

        rad_active_ratio = None
        if Q_rad > 1e-14:
            rad_active_ratio = (Q_rad + Q_prad) / Q_rad

        ext = exterior_law(Q_active)

        surface_g_inside = float(ledger["g_active"][-1])
        surface_g_ext = Q_active / RADIUS**2
        surface_phi_inside = float(ledger["phi_active"][-1])
        surface_phi_ext = Q_active / RADIUS

        rows.append({
            "case_name": spec["case_name"],
            "profile": spec["profile"],
            "theta_c": spec["theta_c"],
            "rad_c": spec["rad_c"],
            "binding_fraction_requested": spec["binding_fraction"],
            "Q_rest": Q_rest,
            "Q_internal_energy": Q_int,
            "Q_radiation_energy": Q_rad,
            "Q_gas_pressure_trace": Q_pgas,
            "Q_radiation_pressure_trace": Q_prad,
            "Q_pressure_trace_total": Q_pressure,
            "Q_binding": Q_bind,
            "Q_active_total": Q_active,
            "Q_component_sum": Q_component_sum,
            "component_identity_error": abs(Q_active - Q_component_sum),
            "active_boost_over_rest": Q_active / Q_rest,
            "binding_reduction_fraction_of_prebind": abs(Q_bind) / ledger["Q_positive_prebind"] if ledger["Q_positive_prebind"] > 0 else 0.0,
            "gas_active_ratio_expected": 3.0 if Q_int > 1e-14 else None,
            "gas_active_ratio_observed": gas_active_ratio,
            "radiation_active_ratio_expected": 2.0 if Q_rad > 1e-14 else None,
            "radiation_active_ratio_observed": rad_active_ratio,
            "exterior_phi_slope": ext["phi_slope"],
            "exterior_g_slope": ext["g_slope"],
            "surface_g_error": abs(surface_g_inside - surface_g_ext),
            "surface_phi_error": abs(surface_phi_inside - surface_phi_ext),
            "positive_active_source": Q_active > 0,
            "status": "PASS" if (
                abs(Q_active - Q_component_sum) < 1e-10
                and abs(ext["phi_slope"] + 1.0) < 1e-12
                and abs(ext["g_slope"] + 2.0) < 1e-12
                and abs(surface_g_inside - surface_g_ext) < 1e-10
                and abs(surface_phi_inside - surface_phi_ext) < 1e-10
                and Q_active > 0
            ) else "CHECK",
        })

    df = pd.DataFrame(rows)

    # Ratios only where component exists.
    gas_rows = df["gas_active_ratio_observed"].dropna()
    rad_rows = df["radiation_active_ratio_observed"].dropna()

    summary = {
        "cases_tested": [c["case_name"] for c in cases],
        "max_component_identity_error": float(df["component_identity_error"].max()),
        "active_boost_range_over_rest": [float(df["active_boost_over_rest"].min()), float(df["active_boost_over_rest"].max())],
        "binding_reduction_fraction_range": [
            float(df["binding_reduction_fraction_of_prebind"].min()),
            float(df["binding_reduction_fraction_of_prebind"].max()),
        ],
        "gas_active_ratio_range": [float(gas_rows.min()), float(gas_rows.max())] if len(gas_rows) else None,
        "radiation_active_ratio_range": [float(rad_rows.min()), float(rad_rows.max())] if len(rad_rows) else None,
        "exterior_phi_slope_range": [float(df["exterior_phi_slope"].min()), float(df["exterior_phi_slope"].max())],
        "exterior_g_slope_range": [float(df["exterior_g_slope"].min()), float(df["exterior_g_slope"].max())],
        "max_surface_g_error": float(df["surface_g_error"].max()),
        "max_surface_phi_error": float(df["surface_phi_error"].max()),
        "all_status_pass": bool(all(df["status"] == "PASS")),
    }

    return df, summary, ledgers


def representative_radial_table(ledgers: dict) -> pd.DataFrame:
    sample_cases = ["cold_uniform_reference", "bound_thermal", "compact_synthetic"]
    sample_r = [0.05, 0.10, 0.25, 0.50, 0.75, 1.00]

    rows = []
    for case in sample_cases:
        ledger = ledgers[case]
        r = ledger["r"]
        for rr in sample_r:
            rows.append({
                "case_name": case,
                "r_over_R": rr,
                "rho_rest": float(np.interp(rr, r, ledger["rho_rest"])),
                "u_int": float(np.interp(rr, r, ledger["u_int"])),
                "rho_rad": float(np.interp(rr, r, ledger["rho_rad"])),
                "rho_pressure_trace": float(np.interp(rr, r, ledger["rho_pressure"])),
                "rho_bind": float(np.interp(rr, r, ledger["rho_bind"])),
                "rho_active": float(np.interp(rr, r, ledger["rho_active"])),
                "Q_active_enclosed": float(np.interp(rr, r, ledger["Q_active"])),
                "g_active": float(np.interp(rr, r, ledger["g_active"])),
            })

    return pd.DataFrame(rows)


def root_normalization_shape_tests(component_df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    Q_active = float(component_df.loc[component_df["case_name"] == "compact_synthetic", "Q_active_total"].iloc[0])

    rows = []
    for kappa in [0.01, 0.1, 1.0, 10.0, 100.0]:
        ext = exterior_law(kappa * Q_active)
        rows.append({
            "kappa_root": kappa,
            "Q_physical_proxy": kappa * Q_active,
            "exterior_phi_slope": ext["phi_slope"],
            "exterior_g_slope": ext["g_slope"],
            "phi_at_r2": kappa * Q_active / 2.0,
            "g_at_r2": kappa * Q_active / 4.0,
            "status": "PASS_SHAPE_INVARIANT" if abs(ext["phi_slope"] + 1.0) < 1e-12 and abs(ext["g_slope"] + 2.0) < 1e-12 else "CHECK",
        })

    df = pd.DataFrame(rows)
    summary = {
        "phi_slope_range": [float(df["exterior_phi_slope"].min()), float(df["exterior_phi_slope"].max())],
        "g_slope_range": [float(df["exterior_g_slope"].min()), float(df["exterior_g_slope"].max())],
        "status": "PASS" if all(df["status"] == "PASS_SHAPE_INVARIANT") else "CHECK",
    }
    return df, summary


def overbinding_control() -> tuple[pd.DataFrame, dict]:
    """
    This is a deliberate guardrail control. Excess negative binding can drive
    the active source toward zero/negative. That is not used as a physical case;
    it marks the permitted domain.
    """
    rows = []
    for binding_fraction in [0.0, 0.1, 0.3, 0.6, 0.9, 1.1]:
        ledger = make_component_ledger(
            case_name=f"overbinding_{binding_fraction:g}",
            profile="concentrated",
            theta_c=0.02,
            rad_c=0.005,
            binding_fraction=binding_fraction,
            temp_shape_name="steep_core",
        )
        r = ledger["r"]
        Q_active = volume_integral(r, ledger["rho_active"])
        Q_pre = ledger["Q_positive_prebind"]
        rows.append({
            "binding_fraction_requested": binding_fraction,
            "Q_positive_prebind": Q_pre,
            "Q_active_total": Q_active,
            "Q_active_over_prebind": Q_active / Q_pre if Q_pre > 0 else None,
            "ruling": "PHYSICAL_TOY_DOMAIN" if Q_active > 0 else "REJECT_OVERBOUND_CONTROL",
        })

    df = pd.DataFrame(rows)
    summary = {
        "first_nonpositive_binding_fraction": (
            float(df[df["Q_active_total"] <= 0]["binding_fraction_requested"].iloc[0])
            if any(df["Q_active_total"] <= 0)
            else None
        ),
        "status": "PASS_DOMAIN_GUARDRAIL",
    }
    return df, summary


def category_guardrail_tests() -> tuple[pd.DataFrame, dict]:
    rows = [
        {
            "candidate_move": "rho_active = rho_rest + u_int + rho_rad + 3p/c^2 + rho_bind",
            "ruling": "ALLOWED",
            "reason": "Component source ledger; normalized units only.",
        },
        {
            "candidate_move": "gas internal active ratio with gamma=5/3 equals 3*u_int",
            "ruling": "ALLOWED",
            "reason": "Trace identity u + 3p, with p=(gamma-1)u.",
        },
        {
            "candidate_move": "radiation active ratio equals 2*rho_rad",
            "ruling": "ALLOWED",
            "reason": "Trace identity rho_rad + 3(rho_rad/3).",
        },
        {
            "candidate_move": "negative binding reduces active source",
            "ruling": "ALLOWED_WITH_DOMAIN_GUARDRAIL",
            "reason": "Allowed as synthetic component if total active source remains positive.",
        },
        {
            "candidate_move": "derive Newton G from this ledger",
            "ruling": "REJECT",
            "reason": "Absolute kappa_root/G normalization remains open.",
        },
        {
            "candidate_move": "use Planck area or measured G before normalization boundary",
            "ruling": "REJECT_CIRCULAR",
            "reason": "Would smuggle root normalization.",
        },
        {
            "candidate_move": "fit component fractions to observed stars",
            "ruling": "REJECT_FOR_R228",
            "reason": "No observed data or tuning in this run.",
        },
        {
            "candidate_move": "multiply whole star by 6pi",
            "ruling": "REJECT_CATEGORY_ERROR",
            "reason": "K_top is particle/top-sector terminal closure, not whole-star gravity multiplier.",
        },
    ]

    summary = {
        "wrong_whole_star_multiplier": SIX_PI,
        "wrong_whole_star_overboost_percent": 100.0 * (SIX_PI - 1.0),
        "status": "PASS_GUARDRAILS",
    }

    return pd.DataFrame(rows), summary


def claim_boundary_matrix() -> pd.DataFrame:
    rows = [
        {
            "claim": "R228M separates rest mass, thermal energy, radiation, pressure trace, and negative binding in a normalized source ledger.",
            "status": "ALLOWED",
            "safe_wording": "synthetic component source accounting",
        },
        {
            "claim": "Gas active internal source follows u + 3p with gamma=5/3.",
            "status": "ALLOWED",
            "safe_wording": "gas trace identity tested",
        },
        {
            "claim": "Radiation active source follows rho_rad + 3p_rad = 2rho_rad.",
            "status": "ALLOWED",
            "safe_wording": "radiation trace identity tested",
        },
        {
            "claim": "Binding energy can reduce the active source.",
            "status": "ALLOWED_WITH_GUARDRAIL",
            "safe_wording": "negative binding component in toy domain",
        },
        {
            "claim": "R228M derives Newton's G.",
            "status": "BLOCKED",
            "safe_wording": "root/G normalization remains open",
        },
        {
            "claim": "R228M solves a real stellar equation of state.",
            "status": "BLOCKED",
            "safe_wording": "toy component profiles only",
        },
        {
            "claim": "R228M validates against observed stars.",
            "status": "BLOCKED",
            "safe_wording": "no observed data used",
        },
        {
            "claim": "R228M derives species-specific q_i.",
            "status": "BLOCKED",
            "safe_wording": "species map remains open",
        },
        {
            "claim": "R228M applies a 6pi whole-star multiplier.",
            "status": "BLOCKED",
            "safe_wording": "whole-star 6pi rejected",
        },
    ]
    return pd.DataFrame(rows)


def open_claims_ledger() -> pd.DataFrame:
    rows = [
        {
            "open_item": "absolute root/G normalization",
            "status": "OPEN",
            "description": "Component ledger remains normalized; kappa_root/G not derived.",
        },
        {
            "open_item": "real equation of state",
            "status": "OPEN",
            "description": "Toy gamma gas and radiation components only.",
        },
        {
            "open_item": "binding energy theorem",
            "status": "OPEN",
            "description": "Negative binding proxy is synthetic, not a full variational theorem.",
        },
        {
            "open_item": "species/binding source map",
            "status": "OPEN",
            "description": "No electron/proton/neutron/nuclear binding map.",
        },
        {
            "open_item": "stellar evolution",
            "status": "OPEN",
            "description": "No nuclear burning, transport, opacity, or evolutionary sequence.",
        },
        {
            "open_item": "compact-star/TOV sector",
            "status": "OPEN",
            "description": "No relativistic compact-star equations.",
        },
        {
            "open_item": "observational validation",
            "status": "OPEN",
            "description": "No observed data or retuning.",
        },
    ]
    return pd.DataFrame(rows)


def write_optional_figures(root: Path, ledgers: dict, component_df: pd.DataFrame, overbind_df: pd.DataFrame) -> dict:
    figs = {}
    figdir = root / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    try:
        import matplotlib.pyplot as plt

        p1 = figdir / "component_source_breakdown.png"
        plot_cols = [
            "Q_rest",
            "Q_internal_energy",
            "Q_radiation_energy",
            "Q_pressure_trace_total",
            "Q_binding",
        ]
        x = np.arange(len(component_df))
        bottom_pos = np.zeros(len(component_df))
        bottom_neg = np.zeros(len(component_df))

        plt.figure(figsize=(10, 5))
        for col in plot_cols:
            vals = component_df[col].values
            pos = np.where(vals > 0, vals, 0)
            neg = np.where(vals < 0, vals, 0)
            plt.bar(x, pos, bottom=bottom_pos, label=col)
            plt.bar(x, neg, bottom=bottom_neg, label=col if np.any(pos == 0) else None)
            bottom_pos += pos
            bottom_neg += neg

        plt.xticks(x, component_df["case_name"].values, rotation=35, ha="right")
        plt.ylabel("integrated source component")
        plt.title("R228M component source ledger")
        plt.legend(fontsize=7)
        plt.tight_layout()
        plt.savefig(p1, dpi=180)
        plt.close()
        figs["component_source_breakdown"] = str(p1)

        p2 = figdir / "active_source_profiles.png"
        plt.figure()
        for case in ["cold_uniform_reference", "bound_thermal", "compact_synthetic"]:
            ledger = ledgers[case]
            plt.plot(ledger["r"], ledger["rho_active"], label=case)
        plt.xlabel("r/R")
        plt.ylabel("rho_active")
        plt.title("Active source density profiles")
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(p2, dpi=180)
        plt.close()
        figs["active_source_profiles"] = str(p2)

        p3 = figdir / "binding_domain_guardrail.png"
        plt.figure()
        plt.plot(overbind_df["binding_fraction_requested"], overbind_df["Q_active_over_prebind"], marker="o")
        plt.axhline(0.0, linestyle="--")
        plt.xlabel("requested binding fraction")
        plt.ylabel("Q_active / Q_positive_prebind")
        plt.title("Overbinding domain guardrail")
        plt.tight_layout()
        plt.savefig(p3, dpi=180)
        plt.close()
        figs["binding_domain_guardrail"] = str(p3)

    except Exception as e:
        figs["figure_error"] = repr(e)

    return figs


def build_report(
    created_utc: str,
    verdict: str,
    component_df: pd.DataFrame,
    radial_df: pd.DataFrame,
    root_df: pd.DataFrame,
    overbind_df: pd.DataFrame,
    guardrail_df: pd.DataFrame,
    claims_df: pd.DataFrame,
    open_df: pd.DataFrame,
) -> str:
    return f"""
# SFT V13.1 / R228M — Binding/Internal-Energy Source Accounting

Generated: {created_utc}

Verdict:
{verdict}

## Purpose

R228M extends the V13.1 particle-to-star chain by separating a synthetic stellar source into:

    rest mass
    internal thermal energy
    radiation energy
    pressure trace
    negative binding energy

The active source ledger is:

    rho_active = rho_rest + u_int + rho_rad + 3p/c^2 + rho_bind

with c=1 in the toy units.

## Component ledger tests

{component_df.to_string(index=False)}

## Representative radial component table

{radial_df.to_string(index=False)}

## Root-normalization shape tests

{root_df.to_string(index=False)}

## Overbinding domain guardrail

{overbind_df.to_string(index=False)}

## Category guardrails

{guardrail_df.to_string(index=False)}

## Claim boundary

{claims_df.to_string(index=False)}

## Open claims

{open_df.to_string(index=False)}

## Interpretation

R228M shows that the stellar source skeleton can be component-decomposed without breaking the normalized gravity accumulation chain.

The gas identity follows:

    u_int + 3p_gas = 3u_int

for gamma=5/3.

The radiation identity follows:

    rho_rad + 3p_rad = 2rho_rad.

The binding term is negative and reduces total active source, but remains inside a domain guardrail: overbinding that drives total active source nonpositive is rejected as a control.

Exterior fields continue to depend only on total Q_active:

    phi_ext = Q_active/r
    g_ext = Q_active/r^2

Root normalization changes amplitude, not shape.

Whole-star 6pi remains rejected as a category error.

## Ruling

The component source ledger passes at synthetic structural level.
G/root normalization, real EOS, binding theorem, species map, stellar evolution, compact stars, and validation remain open.
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    component_df, component_summary, ledgers = run_component_cases()
    radial_df = representative_radial_table(ledgers)
    root_df, root_summary = root_normalization_shape_tests(component_df)
    overbind_df, overbind_summary = overbinding_control()
    guardrail_df, guardrail_summary = category_guardrail_tests()
    claims_df = claim_boundary_matrix()
    open_df = open_claims_ledger()

    figs = write_optional_figures(root, ledgers, component_df, overbind_df)

    verdict = (
        "PARTIAL_PASS_BINDING_INTERNAL_ENERGY_SOURCE_ACCOUNTING_TESTED_"
        "REST_MASS_INTERNAL_ENERGY_RADIATION_PRESSURE_TRACE_AND_NEGATIVE_BINDING_SEPARATED_"
        "COMPONENT_LEDGER_ADDITIVITY_PASSES_GAS_TRACE_IDENTITY_U_PLUS_3P_EQUALS_3U_FOR_GAMMA_5_3_"
        "RADIATION_TRACE_IDENTITY_RHO_PLUS_3P_EQUALS_2RHO_PASSES_"
        "BINDING_COMPONENT_NEGATIVE_AND_REDUCES_ACTIVE_SOURCE_WITH_OVERBINDING_GUARDRAIL_"
        "EXTERIOR_TOTAL_Q_ACTIVE_PHI_MINUS1_AND_G_MINUS2_SLOPES_PRESERVED_"
        "ROOT_NORMALIZATION_CHANGES_AMPLITUDE_NOT_SHAPE_WHOLE_STAR_6PI_REJECTED_AS_CATEGORY_ERROR_"
        "G_NORMALIZATION_REAL_EOS_BINDING_THEOREM_SPECIES_MAP_STELLAR_EVOLUTION_COMPACT_STAR_AND_VALIDATION_OPEN"
    )

    component_df.to_csv(tables / "R228M_component_ledger_tests.csv", index=False)
    radial_df.to_csv(tables / "R228M_representative_radial_components.csv", index=False)
    root_df.to_csv(tables / "R228M_root_normalization_shape_tests.csv", index=False)
    overbind_df.to_csv(tables / "R228M_overbinding_domain_guardrail.csv", index=False)
    guardrail_df.to_csv(tables / "R228M_category_guardrails.csv", index=False)
    claims_df.to_csv(tables / "R228M_claim_boundary_matrix.csv", index=False)
    open_df.to_csv(tables / "R228M_open_claims_ledger.csv", index=False)

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "branch": "SFT V13.1 — Particle-to-Star Gravity Accumulation Unification",
        "active_source_ledger": {
            "rho_active": "rho_rest + u_int + rho_rad + 3p/c^2 + rho_bind",
            "gas_pressure": "p_gas=(gamma-1)u_int with gamma=5/3",
            "radiation_pressure": "p_rad=rho_rad/3",
            "binding": "rho_bind negative synthetic self-settlement energy proxy",
            "absolute_amplitude": "kappa_root remains separate; G/root normalization open",
        },
        "component_summary": component_summary,
        "root_normalization_summary": root_summary,
        "overbinding_summary": overbind_summary,
        "guardrail_summary": guardrail_summary,
        "V12_13_context": {
            "L_eff": L_EFF,
            "N_eff": N_EFF,
            "amplitude_tax": AMP_TAX,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "K_top": SIX_PI,
            "K_top_category": "particle/top-sector terminal closure, not whole-star multiplier",
        },
        "figures": figs,
        "ruling": "Component source ledger passes at synthetic structural level; G/root normalization, real EOS, binding theorem, species map, compact-star physics, and validation remain open.",
        "next_recommended": "R229M - Compactness/Relativistic-Pressure Guardrail: test where weak-field stellar source skeleton must hand off to compact-star/TOV-like sector without claiming a solution.",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R228M_component_ledger_tests.csv",
            "tables/R228M_overbinding_domain_guardrail.csv",
            "tables/R228M_category_guardrails.csv",
            "Any traceback if failed.",
        ],
    }

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        component_df=component_df,
        radial_df=radial_df,
        root_df=root_df,
        overbind_df=overbind_df,
        guardrail_df=guardrail_df,
        claims_df=claims_df,
        open_df=open_df,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    manifest = make_manifest(root, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary_path": str((root / "summary.json").resolve()),
        "report_path": str((root / "report.md").resolve()),
        "manifest_file_count_excluding_manifest": manifest["file_count_excluding_manifest"],
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
