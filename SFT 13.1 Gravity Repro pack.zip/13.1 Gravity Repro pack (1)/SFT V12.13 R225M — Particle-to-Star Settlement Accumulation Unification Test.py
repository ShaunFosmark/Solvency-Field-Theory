#!/usr/bin/env python3
"""
SFT V12.13 R225M — Particle-to-Star Settlement Accumulation Unification Test

Purpose:
    Test the bridge between:

        V12.13 particle-scale closure/support architecture

    and:

        V11.13/V12.3 macroscopic settlement gravity.

Question:
    Can one mechanism map continuously from local particle closure demand to
    star-scale exterior gravity?

Unification chain:
    locally real particle closure
        -> maintained settlement demand q_i
        -> accumulated settlement source density rho_set(x)
        -> scalar/tensor settlement field Lambda_00(x)
        -> clock lag F = exp(-phi)
        -> reciprocal spatial closure B = exp(+phi)
        -> attraction g = -grad phi
        -> star exterior 1/r potential and 1/r^2 acceleration

Tests:
    1. Continuum uniform sphere recovers exterior 1/r potential and 1/r^2 attraction.
    2. Continuum uniform sphere recovers interior g ~ r.
    3. Monte Carlo particle cloud converges toward continuum exterior field.
    4. Directional settlement channels cancel statistically for random orientations.
    5. Coherent orientation leaves directional settlement channel nonzero.
    6. Operation-density pressure channel rho + 3p/c^2 behaves as expected.
    7. One-speed reciprocal closure FB=1 is preserved.
    8. Whole-star 6pi multiplier is rejected as wrong category.

Rules:
    - synthetic structural test only
    - no observed star data
    - no species map
    - no G derivation
    - no top/e fitting
    - no whole-star 6pi multiplication

Outputs:
    SFT_V12_13_R225M_Particle_to_Star_Settlement_Accumulation_Test/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        figures/*.png
        scripts/run_R225M.py

    SFT_V12_13_R225M_Particle_to_Star_Settlement_Accumulation_Test_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_13_R225M_Particle_to_Star_Settlement_Accumulation_Test"

RNG_SEED = 225013
RADIUS = 1.0
TOTAL_SOURCE = 1.0

TWO_PI = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

D_TARGET = 17877.208689571427
TOP_E_CONTEXT = 339000.0
N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = 3.0 * math.pi - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "file_count_excluding_manifest": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def log_slope(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (x > 0) & (y > 0)
    coeff = np.polyfit(np.log(x[mask]), np.log(y[mask]), 1)
    return float(coeff[0])


def continuum_uniform_sphere(r: np.ndarray, R: float = RADIUS, Q: float = TOTAL_SOURCE) -> tuple[np.ndarray, np.ndarray]:
    """
    Dimensionless settlement potential and inward acceleration magnitude for a uniform sphere.

    Potential convention:
        outside: phi = Q/r
        inside:  phi = Q(3R^2 - r^2)/(2R^3)

    Acceleration magnitude:
        outside: g = Q/r^2
        inside:  g = Q r/R^3
    """
    r = np.asarray(r, dtype=float)
    phi = np.empty_like(r)
    g = np.empty_like(r)

    inside = r <= R
    outside = ~inside

    phi[inside] = Q * (3.0 * R * R - r[inside] ** 2) / (2.0 * R ** 3)
    g[inside] = Q * r[inside] / (R ** 3)

    phi[outside] = Q / r[outside]
    g[outside] = Q / (r[outside] ** 2)

    return phi, g


def sample_uniform_sphere(n: int, rng: np.random.Generator, R: float = RADIUS) -> np.ndarray:
    dirs = rng.normal(size=(n, 3))
    dirs /= np.linalg.norm(dirs, axis=1)[:, None]
    radii = R * rng.random(n) ** (1.0 / 3.0)
    return dirs * radii[:, None]


def direct_cloud_field(points: np.ndarray, positions: np.ndarray, q_each: float, softening: float = 1e-3) -> tuple[np.ndarray, np.ndarray]:
    """
    Direct particle-cloud settlement potential and inward radial acceleration.

    Evaluation points are assumed to lie on +x axis.

    phi = sum q / sqrt(|x-x_i|^2 + eps^2)
    vector g = sum q (x_i - x_eval) / (|x-x_i|^2 + eps^2)^(3/2)
    inward radial magnitude on +x axis is -g_x.
    """
    phi_values = []
    g_values = []

    for p in points:
        d = positions - p[None, :]
        r2 = np.sum(d * d, axis=1) + softening ** 2
        inv_r = 1.0 / np.sqrt(r2)
        inv_r3 = inv_r ** 3

        phi = np.sum(q_each * inv_r)
        g_vec = np.sum(q_each * d * inv_r3[:, None], axis=0)
        inward = -g_vec[0]

        phi_values.append(phi)
        g_values.append(inward)

    return np.array(phi_values), np.array(g_values)


def continuum_sphere_tests() -> tuple[pd.DataFrame, dict]:
    r_inside = np.linspace(0.05, 0.95, 40)
    r_outside = np.linspace(1.25, 8.0, 60)

    phi_in, g_in = continuum_uniform_sphere(r_inside)
    phi_out, g_out = continuum_uniform_sphere(r_outside)

    rows = []

    rows.append({
        "test": "continuum_exterior_phi_slope",
        "target": -1.0,
        "observed": log_slope(r_outside, phi_out),
        "abs_error": abs(log_slope(r_outside, phi_out) + 1.0),
        "status": "PASS" if abs(log_slope(r_outside, phi_out) + 1.0) < 1e-12 else "CHECK",
    })

    rows.append({
        "test": "continuum_exterior_g_slope",
        "target": -2.0,
        "observed": log_slope(r_outside, g_out),
        "abs_error": abs(log_slope(r_outside, g_out) + 2.0),
        "status": "PASS" if abs(log_slope(r_outside, g_out) + 2.0) < 1e-12 else "CHECK",
    })

    rows.append({
        "test": "continuum_interior_g_slope",
        "target": 1.0,
        "observed": log_slope(r_inside, g_in),
        "abs_error": abs(log_slope(r_inside, g_in) - 1.0),
        "status": "PASS" if abs(log_slope(r_inside, g_in) - 1.0) < 1e-12 else "CHECK",
    })

    df = pd.DataFrame(rows)
    summary = {
        "exterior_phi_slope": float(df.loc[df["test"] == "continuum_exterior_phi_slope", "observed"].iloc[0]),
        "exterior_g_slope": float(df.loc[df["test"] == "continuum_exterior_g_slope", "observed"].iloc[0]),
        "interior_g_slope": float(df.loc[df["test"] == "continuum_interior_g_slope", "observed"].iloc[0]),
    }
    return df, summary


def particle_cloud_convergence_tests() -> tuple[pd.DataFrame, dict]:
    rng = np.random.default_rng(RNG_SEED)

    r_eval = np.linspace(1.5, 6.0, 36)
    points = np.column_stack([r_eval, np.zeros_like(r_eval), np.zeros_like(r_eval)])

    phi_exact, g_exact = continuum_uniform_sphere(r_eval)

    rows = []
    for n in [100, 300, 1000, 3000, 8000]:
        positions = sample_uniform_sphere(n, rng)
        q_each = TOTAL_SOURCE / n
        phi_mc, g_mc = direct_cloud_field(points, positions, q_each, softening=2e-3)

        phi_rel_rms = float(np.sqrt(np.mean(((phi_mc - phi_exact) / phi_exact) ** 2)))
        g_rel_rms = float(np.sqrt(np.mean(((g_mc - g_exact) / g_exact) ** 2)))

        rows.append({
            "N_particles": n,
            "phi_rel_rms_error_exterior": phi_rel_rms,
            "g_rel_rms_error_exterior": g_rel_rms,
            "phi_slope_exterior": log_slope(r_eval, phi_mc),
            "g_slope_exterior": log_slope(r_eval, np.abs(g_mc)),
            "status": "PASS_CONVERGENCE_SAMPLE" if n >= 1000 and phi_rel_rms < 0.08 and g_rel_rms < 0.20 else "DIAGNOSTIC",
        })

    df = pd.DataFrame(rows)
    best = df.iloc[-1].to_dict()
    summary = {
        "best_N": int(best["N_particles"]),
        "best_phi_rel_rms_error": float(best["phi_rel_rms_error_exterior"]),
        "best_g_rel_rms_error": float(best["g_rel_rms_error_exterior"]),
        "best_phi_slope": float(best["phi_slope_exterior"]),
        "best_g_slope": float(best["g_slope_exterior"]),
    }
    return df, summary


def random_unit_vectors(n: int, rng: np.random.Generator) -> np.ndarray:
    v = rng.normal(size=(n, 3))
    v /= np.linalg.norm(v, axis=1)[:, None]
    return v


def directional_cancellation_tests() -> tuple[pd.DataFrame, dict]:
    rng = np.random.default_rng(RNG_SEED + 1)
    rows = []

    for n in [10, 30, 100, 300, 1000, 3000, 10000]:
        reps = 200 if n <= 1000 else 60
        fractions = []

        for _ in range(reps):
            ori = random_unit_vectors(n, rng)
            q = 1.0 / n
            directional = np.linalg.norm(np.sum(q * ori, axis=0))
            fractions.append(directional)

        rows.append({
            "N_particles": n,
            "random_orientation_mean_directional_fraction": float(np.mean(fractions)),
            "random_orientation_std": float(np.std(fractions)),
            "expected_order": 1.0 / math.sqrt(n),
            "coherent_directional_fraction": 1.0,
            "status": "PASS_RANDOM_CANCELLATION" if np.mean(fractions) < 3.0 / math.sqrt(n) else "CHECK",
        })

    df = pd.DataFrame(rows)
    slope = log_slope(df["N_particles"].values, df["random_orientation_mean_directional_fraction"].values)
    summary = {
        "random_directional_cancellation_slope": slope,
        "target_slope": -0.5,
        "slope_error": abs(slope + 0.5),
        "large_N_random_fraction": float(df.iloc[-1]["random_orientation_mean_directional_fraction"]),
        "coherent_fraction": 1.0,
    }
    return df, summary


def operation_density_pressure_tests() -> tuple[pd.DataFrame, dict]:
    """
    Toy stellar pressure profile:
        rho = constant
        w(r) = p/(rho c^2) = w0(1 - r^2/R^2)

    Volume average of w over sphere is:
        <w> = (2/5)w0

    Therefore operation-density source ratio:
        Q_ops/Q_cold = 1 + 3<w> = 1 + 6w0/5 = 1 + 1.2w0
    """
    rows = []
    for w0 in [0.0, 0.001, 0.01, 0.05, 0.10, 1.0 / 3.0]:
        analytic_ratio = 1.0 + 1.2 * w0

        # numerical integration check
        r = np.linspace(0.0, 1.0, 10001)
        w = w0 * (1.0 - r ** 2)
        numerator = np.trapezoid((1.0 + 3.0 * w) * r ** 2, r)
        denominator = np.trapezoid(1.0 * r ** 2, r)
        numeric_ratio = numerator / denominator

        rows.append({
            "central_w0_p_over_rhoc2": w0,
            "analytic_Q_ops_over_Q_cold": analytic_ratio,
            "numeric_Q_ops_over_Q_cold": float(numeric_ratio),
            "abs_error": abs(numeric_ratio - analytic_ratio),
            "status": "PASS" if abs(numeric_ratio - analytic_ratio) < 1e-8 else "CHECK",
        })

    df = pd.DataFrame(rows)
    summary = {
        "max_abs_error": float(df["abs_error"].max()),
        "radiation_like_central_w0_ratio": float(df.iloc[-1]["numeric_Q_ops_over_Q_cold"]),
    }
    return df, summary


def one_speed_closure_tests() -> tuple[pd.DataFrame, dict]:
    phi_values = np.array([1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 5e-2])
    F = np.exp(-phi_values)
    B = np.exp(phi_values)
    FB = F * B

    rows = []
    for phi, f, b, fb in zip(phi_values, F, B, FB):
        rows.append({
            "phi": float(phi),
            "F_exp_minus_phi": float(f),
            "B_exp_plus_phi": float(b),
            "F_times_B": float(fb),
            "abs_FB_minus_1": abs(float(fb) - 1.0),
        })

    df = pd.DataFrame(rows)
    summary = {
        "max_abs_FB_minus_1": float(df["abs_FB_minus_1"].max()),
        "status": "PASS" if float(df["abs_FB_minus_1"].max()) < 1e-15 else "CHECK",
    }
    return df, summary


def category_guardrail_tests() -> tuple[pd.DataFrame, dict]:
    correct_star_factor = 1.0
    wrong_star_6pi_factor = SIX_PI

    rows = [
        {
            "case": "correct_star_accumulation",
            "description": "Star source is accumulated maintained settlement demand of constituents.",
            "body_level_multiplier": correct_star_factor,
            "ruling": "PASS",
            "reason": "Particle masses/support demands already include their local closure accounting.",
        },
        {
            "case": "wrong_whole_star_6pi_multiplier",
            "description": "Apply V12.13 top-sector K_top to entire star as a new body-level multiplier.",
            "body_level_multiplier": wrong_star_6pi_factor,
            "ruling": "REJECT_CATEGORY_ERROR",
            "reason": "K_top is a particle/top-sector terminal closure rule, not a macroscopic star multiplier.",
        },
    ]

    summary = {
        "wrong_whole_star_multiplier": SIX_PI,
        "wrong_whole_star_overboost_percent": 100.0 * (SIX_PI - 1.0),
        "status": "PASS_GUARDRAIL" if SIX_PI > 10.0 else "CHECK",
    }

    return pd.DataFrame(rows), summary


def claim_boundary_matrix() -> pd.DataFrame:
    rows = [
        {
            "claim": "R225M unifies particle closure demand with macroscopic settlement accumulation in a synthetic structural test.",
            "status": "ALLOWED",
            "safe_wording": "Synthetic unification skeleton tested.",
        },
        {
            "claim": "Continuum accumulation recovers exterior 1/r potential, 1/r^2 attraction, and interior g~r.",
            "status": "ALLOWED",
            "safe_wording": "Within normalized uniform-sphere settlement model.",
        },
        {
            "claim": "Random directional settlement channels cancel statistically in neutral/disordered matter.",
            "status": "ALLOWED",
            "safe_wording": "Monte Carlo directional cancellation test.",
        },
        {
            "claim": "A star receives a whole-body 6π multiplier.",
            "status": "BLOCKED",
            "safe_wording": "K_top is particle/top-sector closure, not a star-level multiplier.",
        },
        {
            "claim": "Newton's G is derived.",
            "status": "BLOCKED",
            "safe_wording": "Absolute normalization remains root-state/open.",
        },
        {
            "claim": "Species map is derived.",
            "status": "BLOCKED",
            "safe_wording": "No species map.",
        },
        {
            "claim": "Full stellar structure equation is solved.",
            "status": "BLOCKED",
            "safe_wording": "Only a synthetic accumulation skeleton.",
        },
        {
            "claim": "Observed star data validates the mechanism.",
            "status": "BLOCKED",
            "safe_wording": "No observed data used.",
        },
    ]
    return pd.DataFrame(rows)


def open_claims_ledger() -> pd.DataFrame:
    rows = [
        {
            "open_item": "particle q_i normalization",
            "status": "OPEN",
            "description": "R225M uses normalized q_i. Mapping q_i to absolute G-scale source remains tied to root-state normalization.",
        },
        {
            "open_item": "species-specific q_i",
            "status": "OPEN",
            "description": "No electron/proton/neutron species map included.",
        },
        {
            "open_item": "real stellar pressure profile",
            "status": "OPEN",
            "description": "R225M uses a toy pressure profile; real hydrostatic stellar structure not solved.",
        },
        {
            "open_item": "tensor settlement dynamics",
            "status": "OPEN",
            "description": "Directional channel cancellation tested, but full tensor dynamics remain future work.",
        },
        {
            "open_item": "root-state G normalization",
            "status": "OPEN",
            "description": "Absolute gravitational coupling remains the V11.13 root-invariant problem.",
        },
        {
            "open_item": "far-field environmental handoff",
            "status": "OPEN",
            "description": "R225M protects local accumulation; V12.3 far-field E handoff is separate.",
        },
    ]
    return pd.DataFrame(rows)


def write_optional_figures(root: Path, continuum_df: pd.DataFrame, cloud_df: pd.DataFrame, direction_df: pd.DataFrame) -> dict:
    """
    Create simple diagnostic figures if matplotlib is available.
    """
    figs = {}
    figdir = root / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    try:
        import matplotlib.pyplot as plt

        # Figure 1: particle convergence errors
        p1 = figdir / "particle_cloud_convergence.png"
        plt.figure()
        plt.loglog(cloud_df["N_particles"], cloud_df["phi_rel_rms_error_exterior"], marker="o", label="phi RMS")
        plt.loglog(cloud_df["N_particles"], cloud_df["g_rel_rms_error_exterior"], marker="o", label="g RMS")
        plt.xlabel("N particles")
        plt.ylabel("relative RMS error")
        plt.title("Particle cloud convergence to continuum exterior field")
        plt.legend()
        plt.tight_layout()
        plt.savefig(p1, dpi=180)
        plt.close()
        figs["particle_cloud_convergence"] = str(p1)

        # Figure 2: directional cancellation
        p2 = figdir / "directional_cancellation.png"
        plt.figure()
        plt.loglog(direction_df["N_particles"], direction_df["random_orientation_mean_directional_fraction"], marker="o", label="random orientation")
        plt.loglog(direction_df["N_particles"], direction_df["expected_order"], marker="o", label="1/sqrt(N)")
        plt.xlabel("N particles")
        plt.ylabel("directional fraction")
        plt.title("Directional settlement cancellation")
        plt.legend()
        plt.tight_layout()
        plt.savefig(p2, dpi=180)
        plt.close()
        figs["directional_cancellation"] = str(p2)

    except Exception as e:
        figs["figure_error"] = repr(e)

    return figs


def build_report(
    created_utc: str,
    verdict: str,
    continuum_df: pd.DataFrame,
    cloud_df: pd.DataFrame,
    direction_df: pd.DataFrame,
    pressure_df: pd.DataFrame,
    closure_df: pd.DataFrame,
    guardrail_df: pd.DataFrame,
    claims_df: pd.DataFrame,
    open_df: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.13 R225M — Particle-to-Star Settlement Accumulation Unification Test

Generated: {created_utc}

Verdict:
{verdict}

## Purpose

R225M tests whether the V12.13 particle-scale closure/support picture can be mapped into the V11.13/V12.3 macroscopic gravity scaffold using one mechanism:

    particle closure support
    -> maintained settlement demand
    -> accumulated source density
    -> settlement field
    -> clock lag / attraction / reciprocal spatial closure
    -> star-scale exterior gravity

## Key distinction

The star is not multiplied by 6π as a whole body.

The 6π top-sector rule belongs to particle/top-sector terminal closure. Star-scale gravity is accumulated settlement demand from the constituents.

## Continuum sphere tests

{continuum_df.to_string(index=False)}

## Particle-cloud convergence tests

{cloud_df.to_string(index=False)}

## Directional settlement cancellation tests

{direction_df.to_string(index=False)}

## Operation-density pressure-channel tests

{pressure_df.to_string(index=False)}

## One-speed closure tests

{closure_df.to_string(index=False)}

## Category guardrail tests

{guardrail_df.to_string(index=False)}

## Claim boundary

{claims_df.to_string(index=False)}

## Open claims

{open_df.to_string(index=False)}

## Interpretation

R225M supports the unification skeleton. A continuum source generated by accumulated maintained settlement demand recovers the expected weak-field sphere behavior: exterior potential ~1/r, exterior attraction ~1/r², and interior attraction ~r.

A Monte Carlo cloud of particle settlement sources converges toward the continuum exterior field as particle number increases.

Directional settlement channels cancel statistically when orientations are random, which is the expected neutral/disordered matter behavior. Coherent orientation remains nonzero, preserving the physical role of the directional settlement bridge without forcing every neutral star to carry a large net directional field.

The operation-density toy pressure channel is compatible with the V12.3 rho + 3p/c² source continuity idea.

The one-speed closure guardrail FB=1 is preserved.

The whole-star 6π multiplier is rejected as a category error.

## Ruling

Particle-to-star gravity accumulation is unified at synthetic skeleton level.

Still open:
    absolute G normalization
    species-specific q_i mapping
    real stellar structure
    full tensor settlement dynamics
    observed validation
"""


def main() -> None:
    created_utc = utc_now_iso()
    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    continuum_df, continuum_summary = continuum_sphere_tests()
    cloud_df, cloud_summary = particle_cloud_convergence_tests()
    direction_df, direction_summary = directional_cancellation_tests()
    pressure_df, pressure_summary = operation_density_pressure_tests()
    closure_df, closure_summary = one_speed_closure_tests()
    guardrail_df, guardrail_summary = category_guardrail_tests()
    claims_df = claim_boundary_matrix()
    open_df = open_claims_ledger()

    verdict = (
        "PARTIAL_PASS_PARTICLE_TO_STAR_SETTLEMENT_ACCUMULATION_UNIFICATION_SKELETON_TESTED_"
        "CONTINUUM_ACCUMULATION_RECOVERS_WEAK_FIELD_SPHERE_BEHAVIOR_"
        "PARTICLE_CLOUD_CONVERGES_TO_CONTINUUM_EXTERIOR_FIELD_"
        "RANDOM_DIRECTIONAL_SETTLEMENT_CANCELS_WHILE_COHERENT_DIRECTION_SURVIVES_"
        "ONE_SPEED_CLOSURE_PRESERVED_OPERATION_DENSITY_PRESSURE_CHANNEL_COMPATIBLE_"
        "WHOLE_STAR_6PI_MULTIPLIER_REJECTED_AS_CATEGORY_ERROR_"
        "G_NORMALIZATION_SPECIES_MAP_REAL_STELLAR_STRUCTURE_AND_VALIDATION_OPEN"
    )

    continuum_df.to_csv(tables / "R225M_continuum_sphere_tests.csv", index=False)
    cloud_df.to_csv(tables / "R225M_particle_cloud_convergence.csv", index=False)
    direction_df.to_csv(tables / "R225M_directional_cancellation.csv", index=False)
    pressure_df.to_csv(tables / "R225M_operation_density_pressure_channel.csv", index=False)
    closure_df.to_csv(tables / "R225M_one_speed_closure.csv", index=False)
    guardrail_df.to_csv(tables / "R225M_category_guardrails.csv", index=False)
    claims_df.to_csv(tables / "R225M_claim_boundary_matrix.csv", index=False)
    open_df.to_csv(tables / "R225M_open_claims_ledger.csv", index=False)

    figs = write_optional_figures(root, continuum_df, cloud_df, direction_df)

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "unification_chain": [
            "particle closure support",
            "maintained settlement demand q_i",
            "accumulated settlement source density rho_set",
            "settlement field Lambda_00",
            "clock lag F=exp(-phi)",
            "reciprocal spatial closure B=exp(phi)",
            "attraction g=-grad phi",
            "star-scale exterior gravity",
        ],
        "V12_13_particle_inputs": {
            "L_eff": L_EFF,
            "N_eff": N_EFF,
            "amplitude_tax": AMP_TAX,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "K_top": SIX_PI,
            "K_top_category": "particle/top-sector terminal closure, not whole-star multiplier",
        },
        "continuum_summary": continuum_summary,
        "particle_cloud_summary": cloud_summary,
        "directional_summary": direction_summary,
        "pressure_summary": pressure_summary,
        "one_speed_closure_summary": closure_summary,
        "category_guardrail_summary": guardrail_summary,
        "figures": figs,
        "ruling": "Particle-to-star gravity accumulation skeleton passes synthetic structural tests; major physical normalization and species/stellar modeling remain open.",
        "next_recommended": "R226M - Particle Source Density Normalization Bridge: q_i to rho_set without deriving G.",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R225M_continuum_sphere_tests.csv",
            "tables/R225M_particle_cloud_convergence.csv",
            "tables/R225M_directional_cancellation.csv",
            "tables/R225M_category_guardrails.csv",
            "Any traceback if failed.",
        ],
    }

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        continuum_df=continuum_df,
        cloud_df=cloud_df,
        direction_df=direction_df,
        pressure_df=pressure_df,
        closure_df=closure_df,
        guardrail_df=guardrail_df,
        claims_df=claims_df,
        open_df=open_df,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    manifest = make_manifest(root, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary_path": str((root / "summary.json").resolve()),
        "report_path": str((root / "report.md").resolve()),
        "manifest_file_count_excluding_manifest": manifest["file_count_excluding_manifest"],
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
