
# SFT V12.13 R225M — Particle-to-Star Settlement Accumulation Unification Test

Generated: 2026-06-23T17:16:11Z

Verdict:
PARTIAL_PASS_PARTICLE_TO_STAR_SETTLEMENT_ACCUMULATION_UNIFICATION_SKELETON_TESTED_CONTINUUM_ACCUMULATION_RECOVERS_WEAK_FIELD_SPHERE_BEHAVIOR_PARTICLE_CLOUD_CONVERGES_TO_CONTINUUM_EXTERIOR_FIELD_RANDOM_DIRECTIONAL_SETTLEMENT_CANCELS_WHILE_COHERENT_DIRECTION_SURVIVES_ONE_SPEED_CLOSURE_PRESERVED_OPERATION_DENSITY_PRESSURE_CHANNEL_COMPATIBLE_WHOLE_STAR_6PI_MULTIPLIER_REJECTED_AS_CATEGORY_ERROR_G_NORMALIZATION_SPECIES_MAP_REAL_STELLAR_STRUCTURE_AND_VALIDATION_OPEN

## Purpose

R225M tests whether the V12.13 particle-scale closure/support picture can be mapped into the V11.13/V12.3 macroscopic gravity scaffold using one mechanism:

    particle closure support
    -> maintained settlement demand
    -> accumulated source density
    -> settlement field
    -> clock lag / attraction / reciprocal spatial closure
    -> star-scale exterior gravity

## Key distinction

The star is not multiplied by 6π as a whole body.

The 6π top-sector rule belongs to particle/top-sector terminal closure. Star-scale gravity is accumulated settlement demand from the constituents.

## Continuum sphere tests

                        test  target  observed    abs_error status
continuum_exterior_phi_slope    -1.0      -1.0 1.110223e-16   PASS
  continuum_exterior_g_slope    -2.0      -2.0 6.661338e-16   PASS
  continuum_interior_g_slope     1.0       1.0 2.220446e-16   PASS

## Particle-cloud convergence tests

 N_particles  phi_rel_rms_error_exterior  g_rel_rms_error_exterior  phi_slope_exterior  g_slope_exterior                  status
         100                    0.005835                  0.022184           -1.012169         -2.040324              DIAGNOSTIC
         300                    0.008049                  0.017461           -1.008810         -2.019372              DIAGNOSTIC
        1000                    0.001017                  0.005131           -1.001847         -2.009018 PASS_CONVERGENCE_SAMPLE
        3000                    0.003885                  0.007999           -1.003919         -2.008245 PASS_CONVERGENCE_SAMPLE
        8000                    0.001787                  0.004473           -1.002296         -2.006042 PASS_CONVERGENCE_SAMPLE

## Directional settlement cancellation tests

 N_particles  random_orientation_mean_directional_fraction  random_orientation_std  expected_order  coherent_directional_fraction                   status
          10                                      0.293397                0.119827        0.316228                            1.0 PASS_RANDOM_CANCELLATION
          30                                      0.173542                0.065799        0.182574                            1.0 PASS_RANDOM_CANCELLATION
         100                                      0.095588                0.038427        0.100000                            1.0 PASS_RANDOM_CANCELLATION
         300                                      0.052185                0.022153        0.057735                            1.0 PASS_RANDOM_CANCELLATION
        1000                                      0.029002                0.011310        0.031623                            1.0 PASS_RANDOM_CANCELLATION
        3000                                      0.017064                0.005905        0.018257                            1.0 PASS_RANDOM_CANCELLATION
       10000                                      0.010747                0.004129        0.010000                            1.0 PASS_RANDOM_CANCELLATION

## Operation-density pressure-channel tests

 central_w0_p_over_rhoc2  analytic_Q_ops_over_Q_cold  numeric_Q_ops_over_Q_cold    abs_error status
                0.000000                      1.0000                     1.0000 0.000000e+00   PASS
                0.001000                      1.0012                     1.0012 2.099987e-11   PASS
                0.010000                      1.0120                     1.0120 2.100000e-10   PASS
                0.050000                      1.0600                     1.0600 1.050000e-09   PASS
                0.100000                      1.1200                     1.1200 2.100000e-09   PASS
                0.333333                      1.4000                     1.4000 7.000000e-09   PASS

## One-speed closure tests

     phi  F_exp_minus_phi  B_exp_plus_phi  F_times_B  abs_FB_minus_1
0.000001         0.999999        1.000001        1.0    0.000000e+00
0.000010         0.999990        1.000010        1.0    1.110223e-16
0.000100         0.999900        1.000100        1.0    0.000000e+00
0.001000         0.999000        1.001001        1.0    0.000000e+00
0.010000         0.990050        1.010050        1.0    0.000000e+00
0.050000         0.951229        1.051271        1.0    0.000000e+00

## Category guardrail tests

                           case                                                                  description  body_level_multiplier                ruling                                                                                   reason
      correct_star_accumulation     Star source is accumulated maintained settlement demand of constituents.               1.000000                  PASS          Particle masses/support demands already include their local closure accounting.
wrong_whole_star_6pi_multiplier Apply V12.13 top-sector K_top to entire star as a new body-level multiplier.              18.849556 REJECT_CATEGORY_ERROR K_top is a particle/top-sector terminal closure rule, not a macroscopic star multiplier.

## Claim boundary

                                                                                                         claim  status                                                       safe_wording
R225M unifies particle closure demand with macroscopic settlement accumulation in a synthetic structural test. ALLOWED                             Synthetic unification skeleton tested.
                   Continuum accumulation recovers exterior 1/r potential, 1/r^2 attraction, and interior g~r. ALLOWED                 Within normalized uniform-sphere settlement model.
                     Random directional settlement channels cancel statistically in neutral/disordered matter. ALLOWED                         Monte Carlo directional cancellation test.
                                                                   A star receives a whole-body 6π multiplier. BLOCKED K_top is particle/top-sector closure, not a star-level multiplier.
                                                                                        Newton's G is derived. BLOCKED                    Absolute normalization remains root-state/open.
                                                                                       Species map is derived. BLOCKED                                                    No species map.
                                                                    Full stellar structure equation is solved. BLOCKED                            Only a synthetic accumulation skeleton.
                                                                   Observed star data validates the mechanism. BLOCKED                                             No observed data used.

## Open claims

                      open_item status                                                                                                 description
     particle q_i normalization   OPEN R225M uses normalized q_i. Mapping q_i to absolute G-scale source remains tied to root-state normalization.
           species-specific q_i   OPEN                                                            No electron/proton/neutron species map included.
  real stellar pressure profile   OPEN                           R225M uses a toy pressure profile; real hydrostatic stellar structure not solved.
     tensor settlement dynamics   OPEN                       Directional channel cancellation tested, but full tensor dynamics remain future work.
     root-state G normalization   OPEN                                  Absolute gravitational coupling remains the V11.13 root-invariant problem.
far-field environmental handoff   OPEN                                   R225M protects local accumulation; V12.3 far-field E handoff is separate.

## Interpretation

R225M supports the unification skeleton. A continuum source generated by accumulated maintained settlement demand recovers the expected weak-field sphere behavior: exterior potential ~1/r, exterior attraction ~1/r², and interior attraction ~r.

A Monte Carlo cloud of particle settlement sources converges toward the continuum exterior field as particle number increases.

Directional settlement channels cancel statistically when orientations are random, which is the expected neutral/disordered matter behavior. Coherent orientation remains nonzero, preserving the physical role of the directional settlement bridge without forcing every neutral star to carry a large net directional field.

The operation-density toy pressure channel is compatible with the V12.3 rho + 3p/c² source continuity idea.

The one-speed closure guardrail FB=1 is preserved.

The whole-star 6π multiplier is rejected as a category error.

## Ruling

Particle-to-star gravity accumulation is unified at synthetic skeleton level.

Still open:
    absolute G normalization
    species-specific q_i mapping
    real stellar structure
    full tensor settlement dynamics
    observed validation
