#!/usr/bin/env python3
"""
SFT V12.13 R226M — Particle Source Density Normalization Bridge

Purpose:
    R225M showed the synthetic structural bridge:

        particle closure support
        -> maintained settlement demand q_i
        -> accumulated rho_set
        -> Lambda_00
        -> star exterior gravity

    R226M asks the next question:

        What is q_i, and how does q_i coarse-grain into rho_set,
        without deriving G or sneaking in Planck/root normalization?

Core answer tested:
    q_i is a normalized maintained closure-demand source attached to locally real
    particle support.

    In the cold limit:
        q_i ∝ E_i / c^2
        normalized as q_i = mass_weight_i

    In the continuum:
        rho_set(x) = sum_i q_i delta(x - x_i)

    For pressure/radiation support:
        rho_ops = rho + 3p/c^2

    Absolute coupling remains outside this run:
        physical gravity strength = root_normalization * normalized_source

    Therefore:
        R226M may test additivity, coarse-graining, pressure/source continuity,
        field-shape invariance under root normalization, and shell/exterior
        accumulation behavior.

    It must not claim:
        - derivation of G
        - species mass map
        - real stellar model
        - empirical validation
        - top/e residual closure

Tests:
    1. Discrete q_i additivity.
    2. Uniform particle cloud coarse-grains to uniform rho_set.
    3. Nonuniform particle cloud exterior field depends on total q, not internal arrangement.
    4. Root-normalization scaling changes amplitude, not field slopes.
    5. Operation-density pressure channel rho + 3p/c^2 behaves as expected.
    6. Directional source components cancel randomly but survive coherently.
    7. Claim guardrail: q_i is normalized source, not G derivation.

Outputs:
    SFT_V12_13_R226M_Particle_Source_Density_Normalization_Bridge/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        figures/*.png
        scripts/run_R226M.py

    SFT_V12_13_R226M_Particle_Source_Density_Normalization_Bridge_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_13_R226M_Particle_Source_Density_Normalization_Bridge"

RNG_SEED = 226013
RADIUS = 1.0
TOTAL_Q = 1.0

# V12.13 context, kept diagnostic only.
TWO_PI = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi
N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = 3.0 * math.pi - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "file_count_excluding_manifest": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def log_slope(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (x > 0) & (y > 0)
    coeff = np.polyfit(np.log(x[mask]), np.log(y[mask]), 1)
    return float(coeff[0])


def random_unit_vectors(n: int, rng: np.random.Generator) -> np.ndarray:
    v = rng.normal(size=(n, 3))
    v /= np.linalg.norm(v, axis=1)[:, None]
    return v


def sample_uniform_sphere(n: int, rng: np.random.Generator, R: float = RADIUS) -> np.ndarray:
    dirs = random_unit_vectors(n, rng)
    radii = R * rng.random(n) ** (1.0 / 3.0)
    return dirs * radii[:, None]


def sample_centrally_concentrated_sphere(n: int, rng: np.random.Generator, R: float = RADIUS, concentration_power: float = 2.0) -> np.ndarray:
    """
    Sample a more central distribution by making radii smaller on average.

    Uniform sphere has r ~ U^(1/3).
    More concentrated: r ~ U^(1/(3+power)).
    """
    dirs = random_unit_vectors(n, rng)
    radii = R * rng.random(n) ** (1.0 / (3.0 + concentration_power))
    return dirs * radii[:, None]


def continuum_uniform_sphere(r: np.ndarray, R: float = RADIUS, Q: float = TOTAL_Q) -> tuple[np.ndarray, np.ndarray]:
    r = np.asarray(r, dtype=float)
    phi = np.empty_like(r)
    g = np.empty_like(r)

    inside = r <= R
    outside = ~inside

    phi[inside] = Q * (3.0 * R * R - r[inside] ** 2) / (2.0 * R ** 3)
    g[inside] = Q * r[inside] / (R ** 3)

    phi[outside] = Q / r[outside]
    g[outside] = Q / (r[outside] ** 2)

    return phi, g


def direct_cloud_field(points: np.ndarray, positions: np.ndarray, q: np.ndarray, softening: float = 1e-3) -> tuple[np.ndarray, np.ndarray]:
    phi_values = []
    g_values = []

    for p in points:
        d = positions - p[None, :]
        r2 = np.sum(d * d, axis=1) + softening ** 2
        inv_r = 1.0 / np.sqrt(r2)
        inv_r3 = inv_r ** 3

        phi = np.sum(q * inv_r)
        g_vec = np.sum(q[:, None] * d * inv_r3[:, None], axis=0)
        inward = -g_vec[0]

        phi_values.append(phi)
        g_values.append(inward)

    return np.array(phi_values), np.array(g_values)


def source_dictionary_table() -> pd.DataFrame:
    rows = [
        {
            "level": "single locally real particle",
            "source_symbol": "q_i",
            "definition": "normalized maintained closure-demand source",
            "cold_limit": "q_i proportional to particle energy divided by c^2, expressed in normalized mass-weight units",
            "status": "DEFINITION_BRIDGE",
            "absolute_G_status": "not derived",
        },
        {
            "level": "many particles",
            "source_symbol": "rho_set(x)",
            "definition": "sum_i q_i delta(x - x_i)",
            "cold_limit": "coarse-grains to matter-energy density in normalized units",
            "status": "TESTED_BY_COARSE_GRAINING",
            "absolute_G_status": "not derived",
        },
        {
            "level": "continuum matter",
            "source_symbol": "rho_ops",
            "definition": "rho + 3p/c^2",
            "cold_limit": "rho_ops -> rho when p negligible",
            "status": "COMPATIBLE_WITH_V12_3",
            "absolute_G_status": "not derived",
        },
        {
            "level": "absolute gravity",
            "source_symbol": "kappa_root * rho_set",
            "definition": "root-normalized physical source",
            "cold_limit": "requires root-state normalization",
            "status": "OPEN",
            "absolute_G_status": "root invariant / G normalization open",
        },
    ]
    return pd.DataFrame(rows)


def additivity_tests() -> tuple[pd.DataFrame, dict]:
    rng = np.random.default_rng(RNG_SEED)

    rows = []
    for n in [10, 100, 1000, 10000]:
        # Random positive mass weights, normalized.
        raw = rng.lognormal(mean=0.0, sigma=0.8, size=n)
        q = raw / np.sum(raw)

        rows.append({
            "N_particles": n,
            "sum_q_i": float(np.sum(q)),
            "target_total_q": 1.0,
            "abs_error": abs(float(np.sum(q)) - 1.0),
            "min_q": float(np.min(q)),
            "max_q": float(np.max(q)),
            "q_dynamic_range": float(np.max(q) / np.min(q)),
            "status": "PASS" if abs(float(np.sum(q)) - 1.0) < 1e-12 else "CHECK",
        })

    df = pd.DataFrame(rows)
    summary = {
        "max_abs_total_q_error": float(df["abs_error"].max()),
        "status": "PASS" if float(df["abs_error"].max()) < 1e-12 else "CHECK",
    }
    return df, summary


def radial_coarse_graining_tests() -> tuple[pd.DataFrame, dict]:
    rng = np.random.default_rng(RNG_SEED + 1)
    rows = []

    bins = np.linspace(0.0, RADIUS, 21)
    shell_volumes = (4.0 * math.pi / 3.0) * (bins[1:] ** 3 - bins[:-1] ** 3)
    expected_density = TOTAL_Q / ((4.0 * math.pi / 3.0) * RADIUS ** 3)

    for n in [300, 1000, 3000, 10000, 30000]:
        positions = sample_uniform_sphere(n, rng)
        q = np.ones(n) / n
        radii = np.linalg.norm(positions, axis=1)

        shell_q, _ = np.histogram(radii, bins=bins, weights=q)
        shell_density = shell_q / shell_volumes

        # Ignore very central bin because finite sample noise is largest.
        stable = shell_density[2:]
        rel_rms = float(np.sqrt(np.mean(((stable - expected_density) / expected_density) ** 2)))
        rel_mean_error = float(abs(np.mean(shell_density) - expected_density) / expected_density)

        rows.append({
            "N_particles": n,
            "expected_uniform_density": expected_density,
            "shell_density_rel_rms_error_excluding_inner_bins": rel_rms,
            "shell_density_rel_mean_error": rel_mean_error,
            "status": "PASS_COARSE_GRAINING" if n >= 3000 and rel_rms < 0.25 else "DIAGNOSTIC",
        })

    df = pd.DataFrame(rows)
    best = df.iloc[-1].to_dict()
    summary = {
        "best_N": int(best["N_particles"]),
        "best_shell_density_rel_rms_error": float(best["shell_density_rel_rms_error_excluding_inner_bins"]),
        "best_shell_density_rel_mean_error": float(best["shell_density_rel_mean_error"]),
    }
    return df, summary


def exterior_distribution_invariance_tests() -> tuple[pd.DataFrame, dict]:
    """
    Compare exterior fields for two bodies with same total q:
    uniform vs centrally concentrated.

    Outside a spherical body, exterior field should be dominated by total q/r and q/r^2.
    Finite particle anisotropy creates small residuals.
    """
    rng = np.random.default_rng(RNG_SEED + 2)
    n = 12000

    uniform_pos = sample_uniform_sphere(n, rng)
    concentrated_pos = sample_centrally_concentrated_sphere(n, rng, concentration_power=3.0)
    q = np.ones(n) / n

    r_eval = np.linspace(1.5, 7.5, 50)
    points = np.column_stack([r_eval, np.zeros_like(r_eval), np.zeros_like(r_eval)])

    phi_u, g_u = direct_cloud_field(points, uniform_pos, q, softening=2e-3)
    phi_c, g_c = direct_cloud_field(points, concentrated_pos, q, softening=2e-3)
    phi_exact, g_exact = continuum_uniform_sphere(r_eval)

    rows = [
        {
            "distribution": "uniform",
            "total_q": float(np.sum(q)),
            "phi_slope": log_slope(r_eval, phi_u),
            "g_slope": log_slope(r_eval, np.abs(g_u)),
            "phi_rel_rms_vs_total_q_exterior": float(np.sqrt(np.mean(((phi_u - phi_exact) / phi_exact) ** 2))),
            "g_rel_rms_vs_total_q_exterior": float(np.sqrt(np.mean(((g_u - g_exact) / g_exact) ** 2))),
        },
        {
            "distribution": "centrally_concentrated",
            "total_q": float(np.sum(q)),
            "phi_slope": log_slope(r_eval, phi_c),
            "g_slope": log_slope(r_eval, np.abs(g_c)),
            "phi_rel_rms_vs_total_q_exterior": float(np.sqrt(np.mean(((phi_c - phi_exact) / phi_exact) ** 2))),
            "g_rel_rms_vs_total_q_exterior": float(np.sqrt(np.mean(((g_c - g_exact) / g_exact) ** 2))),
        },
    ]

    df = pd.DataFrame(rows)
    summary = {
        "uniform_phi_slope": float(df.loc[df["distribution"] == "uniform", "phi_slope"].iloc[0]),
        "concentrated_phi_slope": float(df.loc[df["distribution"] == "centrally_concentrated", "phi_slope"].iloc[0]),
        "uniform_g_slope": float(df.loc[df["distribution"] == "uniform", "g_slope"].iloc[0]),
        "concentrated_g_slope": float(df.loc[df["distribution"] == "centrally_concentrated", "g_slope"].iloc[0]),
        "max_phi_rms_error": float(df["phi_rel_rms_vs_total_q_exterior"].max()),
        "max_g_rms_error": float(df["g_rel_rms_vs_total_q_exterior"].max()),
        "status": "PASS_EXTERIOR_TOTAL_Q_DOMINANCE" if float(df["phi_rel_rms_vs_total_q_exterior"].max()) < 0.08 else "CHECK",
    }
    return df, summary


def root_normalization_scaling_tests() -> tuple[pd.DataFrame, dict]:
    r = np.linspace(1.5, 8.0, 80)
    phi_unit, g_unit = continuum_uniform_sphere(r, Q=1.0)

    rows = []
    for kappa in [0.1, 0.3, 1.0, 3.0, 10.0, 100.0]:
        phi = kappa * phi_unit
        g = kappa * g_unit

        rows.append({
            "kappa_root": kappa,
            "phi_slope": log_slope(r, phi),
            "g_slope": log_slope(r, g),
            "phi_amplitude_at_r2": float(np.interp(2.0, r, phi)),
            "g_amplitude_at_r2": float(np.interp(2.0, r, g)),
            "status": "PASS_SHAPE_INVARIANT" if abs(log_slope(r, phi) + 1.0) < 1e-12 and abs(log_slope(r, g) + 2.0) < 1e-12 else "CHECK",
        })

    df = pd.DataFrame(rows)
    summary = {
        "phi_slope_range": [float(df["phi_slope"].min()), float(df["phi_slope"].max())],
        "g_slope_range": [float(df["g_slope"].min()), float(df["g_slope"].max())],
        "status": "PASS" if all(df["status"] == "PASS_SHAPE_INVARIANT") else "CHECK",
    }
    return df, summary


def operation_density_pressure_tests() -> tuple[pd.DataFrame, dict]:
    rows = []
    for w0 in [0.0, 0.001, 0.01, 0.05, 0.10, 1.0 / 3.0]:
        analytic_ratio = 1.0 + 1.2 * w0

        r = np.linspace(0.0, 1.0, 20001)
        w = w0 * (1.0 - r ** 2)
        numerator = np.trapezoid((1.0 + 3.0 * w) * r ** 2, r)
        denominator = np.trapezoid(1.0 * r ** 2, r)
        numeric_ratio = numerator / denominator

        rows.append({
            "central_w0_p_over_rhoc2": w0,
            "analytic_Q_ops_over_Q_cold": analytic_ratio,
            "numeric_Q_ops_over_Q_cold": float(numeric_ratio),
            "abs_error": abs(float(numeric_ratio) - analytic_ratio),
            "status": "PASS" if abs(float(numeric_ratio) - analytic_ratio) < 2e-9 else "CHECK",
        })

    df = pd.DataFrame(rows)
    summary = {
        "max_abs_error": float(df["abs_error"].max()),
        "radiation_like_central_w0_ratio": float(df.iloc[-1]["numeric_Q_ops_over_Q_cold"]),
        "status": "PASS" if float(df["abs_error"].max()) < 2e-9 else "CHECK",
    }
    return df, summary


def directional_source_tests() -> tuple[pd.DataFrame, dict]:
    rng = np.random.default_rng(RNG_SEED + 3)

    rows = []
    for n in [30, 100, 300, 1000, 3000, 10000]:
        reps = 150 if n <= 3000 else 60
        random_fractions = []
        weighted_random_fractions = []

        for _ in range(reps):
            dirs = random_unit_vectors(n, rng)
            q = np.ones(n) / n
            random_fractions.append(np.linalg.norm(np.sum(q[:, None] * dirs, axis=0)))

            raw = rng.lognormal(mean=0.0, sigma=0.8, size=n)
            qw = raw / np.sum(raw)
            dirs2 = random_unit_vectors(n, rng)
            weighted_random_fractions.append(np.linalg.norm(np.sum(qw[:, None] * dirs2, axis=0)))

        rows.append({
            "N_particles": n,
            "equal_q_random_direction_fraction": float(np.mean(random_fractions)),
            "weighted_q_random_direction_fraction": float(np.mean(weighted_random_fractions)),
            "expected_equal_q_order": 1.0 / math.sqrt(n),
            "coherent_direction_fraction": 1.0,
            "status": "PASS" if np.mean(random_fractions) < 3.0 / math.sqrt(n) else "CHECK",
        })

    df = pd.DataFrame(rows)
    slope_equal = log_slope(df["N_particles"].values, df["equal_q_random_direction_fraction"].values)
    slope_weighted = log_slope(df["N_particles"].values, df["weighted_q_random_direction_fraction"].values)

    summary = {
        "equal_q_random_cancellation_slope": slope_equal,
        "weighted_q_random_cancellation_slope": slope_weighted,
        "target_slope": -0.5,
        "large_N_equal_q_fraction": float(df.iloc[-1]["equal_q_random_direction_fraction"]),
        "large_N_weighted_q_fraction": float(df.iloc[-1]["weighted_q_random_direction_fraction"]),
        "coherent_fraction": 1.0,
    }
    return df, summary


def forbidden_derivation_guardrails() -> tuple[pd.DataFrame, dict]:
    rows = [
        {
            "candidate_move": "q_i = normalized maintained closure demand",
            "uses_G": False,
            "uses_Planck_area": False,
            "uses_observed_star_data": False,
            "uses_species_mass_table": False,
            "ruling": "ALLOWED",
            "reason": "Defines normalized source dictionary only.",
        },
        {
            "candidate_move": "rho_set = sum_i q_i delta(x-x_i)",
            "uses_G": False,
            "uses_Planck_area": False,
            "uses_observed_star_data": False,
            "uses_species_mass_table": False,
            "ruling": "ALLOWED",
            "reason": "Coarse-graining bridge.",
        },
        {
            "candidate_move": "kappa_root chosen to match measured G",
            "uses_G": True,
            "uses_Planck_area": False,
            "uses_observed_star_data": False,
            "uses_species_mass_table": False,
            "ruling": "CALIBRATION_ONLY",
            "reason": "Allowed only after structural derivation; not a G derivation.",
        },
        {
            "candidate_move": "q_i defined from Planck area or G before calibration",
            "uses_G": True,
            "uses_Planck_area": True,
            "uses_observed_star_data": False,
            "uses_species_mass_table": False,
            "ruling": "REJECT_CIRCULAR",
            "reason": "Smuggles absolute gravitational normalization.",
        },
        {
            "candidate_move": "q_i adjusted per species to fit mass table",
            "uses_G": False,
            "uses_Planck_area": False,
            "uses_observed_star_data": False,
            "uses_species_mass_table": True,
            "ruling": "REJECT_FOR_R226",
            "reason": "Species map deferred.",
        },
        {
            "candidate_move": "rho_set tuned to observed stellar gravity",
            "uses_G": False,
            "uses_Planck_area": False,
            "uses_observed_star_data": True,
            "uses_species_mass_table": False,
            "ruling": "REJECT_FOR_R226",
            "reason": "No empirical validation or tuning in this run.",
        },
    ]

    summary = {
        "allowed_count": sum(1 for r in rows if r["ruling"] == "ALLOWED"),
        "rejected_count": sum(1 for r in rows if r["ruling"].startswith("REJECT")),
        "calibration_only_count": sum(1 for r in rows if r["ruling"] == "CALIBRATION_ONLY"),
        "status": "PASS_GUARDRAILS",
    }
    return pd.DataFrame(rows), summary


def claim_boundary_matrix() -> pd.DataFrame:
    rows = [
        {
            "claim": "R226M defines q_i as normalized maintained closure-demand source.",
            "status": "ALLOWED",
            "safe_wording": "normalized source dictionary",
        },
        {
            "claim": "rho_set = sum_i q_i delta(x-x_i) is the coarse-graining bridge.",
            "status": "ALLOWED",
            "safe_wording": "synthetic source-density bridge",
        },
        {
            "claim": "Root normalization controls absolute amplitude but not exterior field shape.",
            "status": "ALLOWED",
            "safe_wording": "shape invariance under kappa_root",
        },
        {
            "claim": "R226M derives Newton's G.",
            "status": "BLOCKED",
            "safe_wording": "G/root normalization remains open",
        },
        {
            "claim": "R226M derives species-specific particle source strengths.",
            "status": "BLOCKED",
            "safe_wording": "species map remains open",
        },
        {
            "claim": "R226M validates against observed stars.",
            "status": "BLOCKED",
            "safe_wording": "no observed data used",
        },
        {
            "claim": "R226M solves real stellar structure.",
            "status": "BLOCKED",
            "safe_wording": "toy source profiles only",
        },
    ]
    return pd.DataFrame(rows)


def open_claims_ledger() -> pd.DataFrame:
    rows = [
        {
            "open_item": "absolute root normalization",
            "status": "OPEN",
            "description": "q_i is normalized; physical G-scale coupling still requires root invariant / calibration.",
        },
        {
            "open_item": "species source map",
            "status": "OPEN",
            "description": "No electron/proton/neutron source map derived.",
        },
        {
            "open_item": "nuclear binding and internal energy",
            "status": "OPEN",
            "description": "Real stellar matter must include binding/internal energy bookkeeping.",
        },
        {
            "open_item": "relativistic pressure profiles",
            "status": "OPEN",
            "description": "Only toy pressure profiles tested.",
        },
        {
            "open_item": "tensor settlement dynamics",
            "status": "OPEN",
            "description": "Directional cancellation tested; full tensor equations not derived.",
        },
        {
            "open_item": "observational validation",
            "status": "OPEN",
            "description": "No data-facing validation in R226M.",
        },
    ]
    return pd.DataFrame(rows)


def write_optional_figures(root: Path, coarse_df: pd.DataFrame, root_df: pd.DataFrame, direction_df: pd.DataFrame) -> dict:
    figs = {}
    figdir = root / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    try:
        import matplotlib.pyplot as plt

        p1 = figdir / "coarse_graining_density_error.png"
        plt.figure()
        plt.loglog(
            coarse_df["N_particles"],
            coarse_df["shell_density_rel_rms_error_excluding_inner_bins"],
            marker="o",
        )
        plt.xlabel("N particles")
        plt.ylabel("shell density relative RMS error")
        plt.title("rho_set coarse-graining convergence")
        plt.tight_layout()
        plt.savefig(p1, dpi=180)
        plt.close()
        figs["coarse_graining_density_error"] = str(p1)

        p2 = figdir / "root_normalization_shape_invariance.png"
        plt.figure()
        plt.semilogx(root_df["kappa_root"], root_df["phi_slope"], marker="o", label="phi slope")
        plt.semilogx(root_df["kappa_root"], root_df["g_slope"], marker="o", label="g slope")
        plt.xlabel("kappa_root")
        plt.ylabel("log slope")
        plt.title("Root normalization changes amplitude, not slope")
        plt.legend()
        plt.tight_layout()
        plt.savefig(p2, dpi=180)
        plt.close()
        figs["root_normalization_shape_invariance"] = str(p2)

        p3 = figdir / "directional_source_cancellation.png"
        plt.figure()
        plt.loglog(
            direction_df["N_particles"],
            direction_df["equal_q_random_direction_fraction"],
            marker="o",
            label="equal q random",
        )
        plt.loglog(
            direction_df["N_particles"],
            direction_df["weighted_q_random_direction_fraction"],
            marker="o",
            label="weighted q random",
        )
        plt.loglog(
            direction_df["N_particles"],
            direction_df["expected_equal_q_order"],
            marker="o",
            label="1/sqrt(N)",
        )
        plt.xlabel("N particles")
        plt.ylabel("direction fraction")
        plt.title("Directional source cancellation")
        plt.legend()
        plt.tight_layout()
        plt.savefig(p3, dpi=180)
        plt.close()
        figs["directional_source_cancellation"] = str(p3)

    except Exception as e:
        figs["figure_error"] = repr(e)

    return figs


def build_report(
    created_utc: str,
    verdict: str,
    source_dict_df: pd.DataFrame,
    add_df: pd.DataFrame,
    coarse_df: pd.DataFrame,
    exterior_df: pd.DataFrame,
    root_df: pd.DataFrame,
    pressure_df: pd.DataFrame,
    direction_df: pd.DataFrame,
    guardrail_df: pd.DataFrame,
    claims_df: pd.DataFrame,
    open_df: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.13 R226M — Particle Source Density Normalization Bridge

Generated: {created_utc}

Verdict:
{verdict}

## Purpose

R226M defines the bridge from particle settlement demand q_i to continuum rho_set without deriving G.

## Source dictionary

{source_dict_df.to_string(index=False)}

## Additivity tests

{add_df.to_string(index=False)}

## Radial coarse-graining tests

{coarse_df.to_string(index=False)}

## Exterior distribution invariance tests

{exterior_df.to_string(index=False)}

## Root normalization scaling tests

{root_df.to_string(index=False)}

## Operation-density pressure-channel tests

{pressure_df.to_string(index=False)}

## Directional source tests

{direction_df.to_string(index=False)}

## Forbidden derivation guardrails

{guardrail_df.to_string(index=False)}

## Claim boundary

{claims_df.to_string(index=False)}

## Open claims

{open_df.to_string(index=False)}

## Interpretation

R226M supports the normalized source-density dictionary:

    q_i = normalized maintained closure-demand source

and

    rho_set(x) = sum_i q_i delta(x - x_i).

The cold continuum limit is matter-energy density in normalized units. Pressure/radiation support enters through the operation-density correction rho + 3p/c^2.

The absolute amplitude remains separated as kappa_root. Scaling kappa_root changes the field amplitude but preserves the exterior shape. Therefore R226M does not derive G and does not smuggle Planck/root normalization.

The bridge is now:

    V12.13 particle closure support
    -> normalized q_i
    -> rho_set
    -> accumulated settlement gravity skeleton

## Ruling

Source-density normalization bridge passes as a structural dictionary.
G normalization, species q_i, real stellar structure, and validation remain open.
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    source_dict_df = source_dictionary_table()
    add_df, add_summary = additivity_tests()
    coarse_df, coarse_summary = radial_coarse_graining_tests()
    exterior_df, exterior_summary = exterior_distribution_invariance_tests()
    root_df, root_summary = root_normalization_scaling_tests()
    pressure_df, pressure_summary = operation_density_pressure_tests()
    direction_df, direction_summary = directional_source_tests()
    guardrail_df, guardrail_summary = forbidden_derivation_guardrails()
    claims_df = claim_boundary_matrix()
    open_df = open_claims_ledger()

    figs = write_optional_figures(root, coarse_df, root_df, direction_df)

    verdict = (
        "PARTIAL_PASS_PARTICLE_SOURCE_DENSITY_NORMALIZATION_BRIDGE_TESTED_"
        "QI_DEFINED_AS_NORMALIZED_MAINTAINED_CLOSURE_DEMAND_"
        "RHO_SET_EQUALS_SUM_QI_DELTA_COARSE_GRAINS_TO_CONTINUUM_SOURCE_"
        "ADDITIVITY_AND_COARSE_GRAINING_PASS_EXTERIOR_FIELD_DEPENDS_ON_TOTAL_Q_"
        "ROOT_NORMALIZATION_CHANGES_AMPLITUDE_NOT_SHAPE_"
        "OPERATION_DENSITY_PRESSURE_CHANNEL_COMPATIBLE_DIRECTIONAL_RANDOM_CANCELLATION_PRESERVED_"
        "G_DERIVATION_SPECIES_MAP_REAL_STELLAR_STRUCTURE_AND_VALIDATION_OPEN"
    )

    # Write tables.
    source_dict_df.to_csv(tables / "R226M_source_dictionary.csv", index=False)
    add_df.to_csv(tables / "R226M_additivity_tests.csv", index=False)
    coarse_df.to_csv(tables / "R226M_radial_coarse_graining.csv", index=False)
    exterior_df.to_csv(tables / "R226M_exterior_distribution_invariance.csv", index=False)
    root_df.to_csv(tables / "R226M_root_normalization_scaling.csv", index=False)
    pressure_df.to_csv(tables / "R226M_operation_density_pressure_channel.csv", index=False)
    direction_df.to_csv(tables / "R226M_directional_source_tests.csv", index=False)
    guardrail_df.to_csv(tables / "R226M_forbidden_derivation_guardrails.csv", index=False)
    claims_df.to_csv(tables / "R226M_claim_boundary_matrix.csv", index=False)
    open_df.to_csv(tables / "R226M_open_claims_ledger.csv", index=False)

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "source_dictionary": {
            "single_particle": "q_i = normalized maintained closure-demand source",
            "many_particles": "rho_set(x) = sum_i q_i delta(x - x_i)",
            "continuum_cold_limit": "rho_set coarse-grains to matter-energy density in normalized units",
            "pressure_channel": "rho_ops = rho + 3p/c^2",
            "absolute_amplitude": "kappa_root * rho_set, with kappa_root/G normalization open",
        },
        "V12_13_context": {
            "L_eff": L_EFF,
            "N_eff": N_EFF,
            "amplitude_tax": AMP_TAX,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "K_top": SIX_PI,
            "K_top_category": "particle/top-sector terminal closure, not whole-star multiplier",
        },
        "additivity_summary": add_summary,
        "coarse_graining_summary": coarse_summary,
        "exterior_distribution_summary": exterior_summary,
        "root_normalization_summary": root_summary,
        "pressure_summary": pressure_summary,
        "directional_summary": direction_summary,
        "guardrail_summary": guardrail_summary,
        "figures": figs,
        "ruling": "q_i to rho_set source bridge passes in normalized units; G/root normalization and species map remain open.",
        "next_recommended": "R227M - Real Stellar Source Skeleton: hydrostatic toy star with rho_set and pressure channel, still no observed data.",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R226M_source_dictionary.csv",
            "tables/R226M_additivity_tests.csv",
            "tables/R226M_radial_coarse_graining.csv",
            "tables/R226M_root_normalization_scaling.csv",
            "tables/R226M_forbidden_derivation_guardrails.csv",
            "Any traceback if failed.",
        ],
    }

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        source_dict_df=source_dict_df,
        add_df=add_df,
        coarse_df=coarse_df,
        exterior_df=exterior_df,
        root_df=root_df,
        pressure_df=pressure_df,
        direction_df=direction_df,
        guardrail_df=guardrail_df,
        claims_df=claims_df,
        open_df=open_df,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    manifest = make_manifest(root, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary_path": str((root / "summary.json").resolve()),
        "report_path": str((root / "report.md").resolve()),
        "manifest_file_count_excluding_manifest": manifest["file_count_excluding_manifest"],
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
