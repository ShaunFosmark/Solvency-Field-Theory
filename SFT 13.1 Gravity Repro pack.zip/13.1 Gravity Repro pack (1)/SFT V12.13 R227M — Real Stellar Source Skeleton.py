#!/usr/bin/env python3
"""
SFT V12.13 R227M — Real Stellar Source Skeleton

Purpose:
    Extend R225M/R226M from a generic particle-to-continuum source bridge into
    a toy stellar interior skeleton.

Prior chain:
    R225M:
        particle closure support
        -> maintained settlement demand q_i
        -> accumulated rho_set
        -> Lambda_00
        -> star-scale exterior gravity

    R226M:
        q_i = normalized maintained closure-demand source
        rho_set(x) = sum_i q_i delta(x - x_i)
        rho_ops = rho + 3p/c^2
        kappa_root / G normalization remains open

R227M question:
    Can a synthetic hydrostatic toy star use rho_set and rho + 3p/c^2
    source weighting to produce the expected enclosed-source interior field,
    exterior total-source law, pressure correction, and root-normalization
    shape invariance?

Tests:
    1. Build synthetic star profiles: uniform, quadratic, concentrated.
    2. Normalize cold matter source to Q_mass = 1.
    3. Build hydrostatic pressure-shape p(r) from dp/dr = -rho g_mass,
       with p(R)=0, then scale to selected central w0 = p_c/(rho_c c^2).
    4. Construct operation source rho_ops = rho + 3p/c^2.
    5. Compute enclosed Q_ops(r), interior g(r), potential phi(r).
    6. Verify exterior phi ~ Q_ops/r and g ~ Q_ops/r^2.
    7. Verify surface continuity.
    8. Verify pressure increases source by exactly 3∫p dV.
    9. Verify root normalization changes amplitude, not shape.
    10. Verify whole-star 6pi multiplier is rejected as category error.

Claim boundary:
    - synthetic structural stellar-source skeleton only
    - no observed star data
    - no final stellar structure equations
    - no Newton G derivation
    - no species source map
    - no real equation-of-state claim
    - no top/e closure claim

Outputs:
    SFT_V12_13_R227M_Real_Stellar_Source_Skeleton/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        figures/*.png
        scripts/run_R227M.py

    SFT_V12_13_R227M_Real_Stellar_Source_Skeleton_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V12_13_R227M_Real_Stellar_Source_Skeleton"

RADIUS = 1.0
TOTAL_Q_MASS = 1.0
RNG_SEED = 227013

TWO_PI = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = 3.0 * math.pi - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "file_count_excluding_manifest": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def trapz(y: np.ndarray, x: np.ndarray) -> float:
    if hasattr(np, "trapezoid"):
        return float(np.trapezoid(y, x))
    return float(np.trapz(y, x))


def cumulative_trapz(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    out = np.zeros_like(y, dtype=float)
    dx = np.diff(x)
    out[1:] = np.cumsum(0.5 * (y[1:] + y[:-1]) * dx)
    return out


def log_slope(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (x > 0) & (y > 0)
    coeff = np.polyfit(np.log(x[mask]), np.log(y[mask]), 1)
    return float(coeff[0])


def density_profile(profile: str, r: np.ndarray, R: float = RADIUS) -> np.ndarray:
    x = r / R

    if profile == "uniform":
        raw = np.ones_like(r)
    elif profile == "quadratic":
        raw = np.maximum(1.0 - x**2, 0.0)
    elif profile == "concentrated":
        raw = 1.0 / (1.0 + (x / 0.35) ** 2) ** 2
        raw[x > 1.0] = 0.0
    else:
        raise ValueError(f"Unknown profile: {profile}")

    return raw


def normalize_density_to_mass(r: np.ndarray, rho_raw: np.ndarray, target_mass: float = TOTAL_Q_MASS) -> np.ndarray:
    volume_weight = 4.0 * math.pi * r**2
    mass_raw = trapz(rho_raw * volume_weight, r)
    if mass_raw <= 0:
        raise ValueError("Raw density has zero mass.")
    return rho_raw * (target_mass / mass_raw)


def enclosed_source(r: np.ndarray, rho: np.ndarray) -> np.ndarray:
    return cumulative_trapz(4.0 * math.pi * r**2 * rho, r)


def gravity_from_enclosed(r: np.ndarray, Q_enclosed: np.ndarray) -> np.ndarray:
    g = np.zeros_like(r, dtype=float)
    mask = r > 0
    g[mask] = Q_enclosed[mask] / (r[mask] ** 2)
    g[~mask] = 0.0
    return g


def potential_from_g(r: np.ndarray, g: np.ndarray, Q_total: float, R: float = RADIUS) -> np.ndarray:
    """
    Positive potential convention:
        outside phi = Q_total/r
        g magnitude = -dphi/dr

    Inside:
        phi(r) = phi(R) + integral_r^R g(s) ds
    """
    phi = np.zeros_like(r, dtype=float)
    phi[-1] = Q_total / R
    for i in range(len(r) - 2, -1, -1):
        dr = r[i + 1] - r[i]
        phi[i] = phi[i + 1] + 0.5 * (g[i + 1] + g[i]) * dr
    return phi


def hydrostatic_pressure_shape(r: np.ndarray, rho: np.ndarray, g_mass: np.ndarray) -> np.ndarray:
    """
    Hydrostatic toy shape:
        dp/dr = -rho g_mass
        p(R) = 0

    Therefore:
        p(r) = integral_r^R rho(s) g_mass(s) ds
    """
    integrand = rho * g_mass
    p = np.zeros_like(r, dtype=float)

    # Reverse cumulative trapezoid.
    for i in range(len(r) - 2, -1, -1):
        dr = r[i + 1] - r[i]
        p[i] = p[i + 1] + 0.5 * (integrand[i + 1] + integrand[i]) * dr

    return p


def build_toy_star(profile: str, central_w0: float, n_grid: int = 2001) -> dict:
    """
    Dimensionless units:
        c = 1
        R = 1
        cold Q_mass = 1

    central_w0 means:
        w0 = p_c / rho_c c^2
    """
    r = np.linspace(0.0, RADIUS, n_grid)

    rho_raw = density_profile(profile, r)
    rho = normalize_density_to_mass(r, rho_raw, target_mass=TOTAL_Q_MASS)

    Q_mass = enclosed_source(r, rho)
    g_mass = gravity_from_enclosed(r, Q_mass)

    p_shape = hydrostatic_pressure_shape(r, rho, g_mass)

    if p_shape[0] > 0 and rho[0] > 0:
        scale = central_w0 * rho[0] / p_shape[0]
    else:
        scale = 0.0

    p = scale * p_shape

    rho_ops = rho + 3.0 * p
    Q_ops = enclosed_source(r, rho_ops)
    g_ops = gravity_from_enclosed(r, Q_ops)
    phi_ops = potential_from_g(r, g_ops, Q_total=float(Q_ops[-1]))

    return {
        "profile": profile,
        "central_w0": central_w0,
        "r": r,
        "rho": rho,
        "Q_mass": Q_mass,
        "g_mass": g_mass,
        "p_shape": p_shape,
        "pressure_scale": scale,
        "p": p,
        "rho_ops": rho_ops,
        "Q_ops": Q_ops,
        "g_ops": g_ops,
        "phi_ops": phi_ops,
    }


def exterior_law_for_total_q(Q_total: float, r_min: float = 1.25, r_max: float = 8.0) -> dict:
    r_ext = np.linspace(r_min, r_max, 100)
    phi_ext = Q_total / r_ext
    g_ext = Q_total / (r_ext ** 2)
    return {
        "r_ext": r_ext,
        "phi_ext": phi_ext,
        "g_ext": g_ext,
        "phi_slope": log_slope(r_ext, phi_ext),
        "g_slope": log_slope(r_ext, g_ext),
    }


def star_profile_tests() -> tuple[pd.DataFrame, dict, dict]:
    profiles = ["uniform", "quadratic", "concentrated"]
    central_w0_values = [0.0, 0.001, 0.01, 0.05, 0.10]

    rows = []
    stars = {}

    for profile in profiles:
        for w0 in central_w0_values:
            star = build_toy_star(profile, w0)
            key = f"{profile}_w0_{w0:g}"
            stars[key] = star

            r = star["r"]
            rho = star["rho"]
            p = star["p"]
            rho_ops = star["rho_ops"]
            Q_mass = star["Q_mass"]
            Q_ops = star["Q_ops"]
            g_ops = star["g_ops"]
            phi_ops = star["phi_ops"]

            Q_mass_total = float(Q_mass[-1])
            Q_pressure = float(trapz(3.0 * p * 4.0 * math.pi * r**2, r))
            Q_ops_total = float(Q_ops[-1])
            source_boost = Q_ops_total / Q_mass_total

            ext = exterior_law_for_total_q(Q_ops_total)
            g_surface_inside = float(g_ops[-1])
            g_surface_exterior = Q_ops_total / (RADIUS ** 2)
            phi_surface_inside = float(phi_ops[-1])
            phi_surface_exterior = Q_ops_total / RADIUS

            # Pressure shape diagnostics.
            p_surface = float(p[-1])
            p_center_over_rho_center = float(p[0] / rho[0]) if rho[0] > 0 else 0.0
            dp_dr = np.gradient(p, r)
            hydro_residual = dp_dr + star["pressure_scale"] * rho * star["g_mass"]
            interior = (r > 0.02) & (r < 0.98)
            denom = np.sqrt(np.mean((star["pressure_scale"] * rho[interior] * star["g_mass"][interior]) ** 2)) + 1e-30
            hydro_resid_rms = float(np.sqrt(np.mean(hydro_residual[interior] ** 2)) / denom) if denom > 0 else 0.0

            rows.append({
                "profile": profile,
                "central_w0_target": w0,
                "central_w0_observed": p_center_over_rho_center,
                "Q_mass_total": Q_mass_total,
                "Q_pressure_contribution": Q_pressure,
                "Q_ops_total": Q_ops_total,
                "source_boost_Qops_over_Qmass": source_boost,
                "pressure_identity_error": abs(Q_ops_total - (Q_mass_total + Q_pressure)),
                "p_surface": p_surface,
                "hydrostatic_shape_resid_rms": hydro_resid_rms,
                "surface_g_abs_error": abs(g_surface_inside - g_surface_exterior),
                "surface_phi_abs_error": abs(phi_surface_inside - phi_surface_exterior),
                "exterior_phi_slope": ext["phi_slope"],
                "exterior_g_slope": ext["g_slope"],
                "status": "PASS" if (
                    abs(Q_mass_total - 1.0) < 5e-5
                    and abs(Q_ops_total - (Q_mass_total + Q_pressure)) < 5e-8
                    and abs(ext["phi_slope"] + 1.0) < 1e-12
                    and abs(ext["g_slope"] + 2.0) < 1e-12
                    and abs(g_surface_inside - g_surface_exterior) < 5e-5
                    and abs(phi_surface_inside - phi_surface_exterior) < 5e-5
                ) else "CHECK",
            })

    df = pd.DataFrame(rows)
    summary = {
        "profiles_tested": profiles,
        "central_w0_values": central_w0_values,
        "max_Q_mass_error": float(np.max(np.abs(df["Q_mass_total"] - 1.0))),
        "max_pressure_identity_error": float(df["pressure_identity_error"].max()),
        "max_surface_g_error": float(df["surface_g_abs_error"].max()),
        "max_surface_phi_error": float(df["surface_phi_abs_error"].max()),
        "exterior_phi_slope_range": [float(df["exterior_phi_slope"].min()), float(df["exterior_phi_slope"].max())],
        "exterior_g_slope_range": [float(df["exterior_g_slope"].min()), float(df["exterior_g_slope"].max())],
        "max_source_boost": float(df["source_boost_Qops_over_Qmass"].max()),
        "all_status_pass": bool(all(df["status"] == "PASS")),
    }

    return df, summary, stars


def enclosed_law_table(stars: dict) -> pd.DataFrame:
    """
    Representative interior samples for one low-pressure and one pressure-corrected star.
    """
    selected_keys = [
        "uniform_w0_0",
        "quadratic_w0_0.05",
        "concentrated_w0_0.1",
    ]

    rows = []
    sample_radii = [0.05, 0.10, 0.25, 0.50, 0.75, 1.00]

    for key in selected_keys:
        star = stars[key]
        r = star["r"]

        for rr in sample_radii:
            rows.append({
                "star_case": key,
                "r_over_R": rr,
                "rho_set": float(np.interp(rr, r, star["rho"])),
                "pressure_p_over_c2": float(np.interp(rr, r, star["p"])),
                "rho_ops": float(np.interp(rr, r, star["rho_ops"])),
                "Q_ops_enclosed": float(np.interp(rr, r, star["Q_ops"])),
                "g_ops": float(np.interp(rr, r, star["g_ops"])),
                "phi_ops": float(np.interp(rr, r, star["phi_ops"])),
            })

    return pd.DataFrame(rows)


def pressure_boost_law_tests(profile_df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    rows = []
    for profile in sorted(profile_df["profile"].unique()):
        sub = profile_df[profile_df["profile"] == profile].copy()
        slope = np.polyfit(sub["central_w0_target"], sub["source_boost_Qops_over_Qmass"] - 1.0, 1)[0]
        intercept = np.polyfit(sub["central_w0_target"], sub["source_boost_Qops_over_Qmass"] - 1.0, 1)[1]

        rows.append({
            "profile": profile,
            "linear_slope_d_boost_minus1_over_d_w0": float(slope),
            "linear_intercept": float(intercept),
            "boost_at_w0_0p1": float(sub[sub["central_w0_target"] == 0.10]["source_boost_Qops_over_Qmass"].iloc[0]),
            "status": "PASS_MONOTONIC_PRESSURE_BOOST" if all(np.diff(sub["source_boost_Qops_over_Qmass"].values) >= -1e-12) else "CHECK",
        })

    df = pd.DataFrame(rows)
    summary = {
        "all_profiles_monotonic": bool(all(df["status"] == "PASS_MONOTONIC_PRESSURE_BOOST")),
        "boost_slope_range": [float(df["linear_slope_d_boost_minus1_over_d_w0"].min()), float(df["linear_slope_d_boost_minus1_over_d_w0"].max())],
    }
    return df, summary


def root_normalization_shape_tests(stars: dict) -> tuple[pd.DataFrame, dict]:
    star = stars["quadratic_w0_0.05"]
    Q_total = float(star["Q_ops"][-1])

    rows = []
    for kappa in [0.01, 0.1, 1.0, 10.0, 100.0]:
        ext = exterior_law_for_total_q(kappa * Q_total)
        rows.append({
            "kappa_root": kappa,
            "Q_physical_proxy": kappa * Q_total,
            "exterior_phi_slope": ext["phi_slope"],
            "exterior_g_slope": ext["g_slope"],
            "phi_at_r2": float(kappa * Q_total / 2.0),
            "g_at_r2": float(kappa * Q_total / 4.0),
            "status": "PASS_SHAPE_INVARIANT" if abs(ext["phi_slope"] + 1.0) < 1e-12 and abs(ext["g_slope"] + 2.0) < 1e-12 else "CHECK",
        })

    df = pd.DataFrame(rows)
    summary = {
        "phi_slope_range": [float(df["exterior_phi_slope"].min()), float(df["exterior_phi_slope"].max())],
        "g_slope_range": [float(df["exterior_g_slope"].min()), float(df["exterior_g_slope"].max())],
        "status": "PASS" if all(df["status"] == "PASS_SHAPE_INVARIANT") else "CHECK",
    }
    return df, summary


def category_guardrail_tests() -> tuple[pd.DataFrame, dict]:
    rows = [
        {
            "case": "stellar_source_from_rho_ops",
            "description": "Star source is Q_ops = integral (rho + 3p/c^2) dV.",
            "body_level_multiplier": 1.0,
            "ruling": "PASS",
            "reason": "Uses accumulated source density.",
        },
        {
            "case": "whole_star_6pi_multiplier",
            "description": "Multiply star by V12.13 K_top = 6pi as a whole-body gravity factor.",
            "body_level_multiplier": SIX_PI,
            "ruling": "REJECT_CATEGORY_ERROR",
            "reason": "K_top is particle/top-sector terminal closure, not a macroscopic stellar multiplier.",
        },
        {
            "case": "choose_kappa_root_to_match_measured_G",
            "description": "Use measured G to set absolute root normalization after the structural source law.",
            "body_level_multiplier": None,
            "ruling": "CALIBRATION_ONLY",
            "reason": "Calibration allowed only after structural bridge; not a derivation of G.",
        },
        {
            "case": "insert_planck_area_before_source_law",
            "description": "Define the source law using Planck area/G before deriving source accumulation.",
            "body_level_multiplier": None,
            "ruling": "REJECT_CIRCULAR",
            "reason": "Would smuggle absolute gravity normalization.",
        },
    ]

    summary = {
        "wrong_whole_star_multiplier": SIX_PI,
        "wrong_whole_star_overboost_percent": 100.0 * (SIX_PI - 1.0),
        "status": "PASS_GUARDRAILS",
    }

    return pd.DataFrame(rows), summary


def claim_boundary_matrix() -> pd.DataFrame:
    rows = [
        {
            "claim": "R227M builds a synthetic stellar interior source skeleton using rho_set and rho + 3p/c^2.",
            "status": "ALLOWED",
            "safe_wording": "toy stellar source skeleton",
        },
        {
            "claim": "Exterior field depends on total Q_ops and retains phi~1/r, g~1/r^2.",
            "status": "ALLOWED",
            "safe_wording": "normalized exterior source law",
        },
        {
            "claim": "Pressure contributes as 3p/c^2 to operation source.",
            "status": "ALLOWED",
            "safe_wording": "pressure-channel compatibility",
        },
        {
            "claim": "R227M derives Newton's G.",
            "status": "BLOCKED",
            "safe_wording": "root/G normalization remains open",
        },
        {
            "claim": "R227M solves real stellar structure.",
            "status": "BLOCKED",
            "safe_wording": "synthetic hydrostatic toy profiles only",
        },
        {
            "claim": "R227M validates against real stars.",
            "status": "BLOCKED",
            "safe_wording": "no observed star data used",
        },
        {
            "claim": "R227M derives a species map.",
            "status": "BLOCKED",
            "safe_wording": "species-specific q_i remains open",
        },
        {
            "claim": "R227M applies 6pi as a whole-star multiplier.",
            "status": "BLOCKED",
            "safe_wording": "whole-star 6pi rejected as category error",
        },
    ]
    return pd.DataFrame(rows)


def open_claims_ledger() -> pd.DataFrame:
    rows = [
        {
            "open_item": "absolute root/G normalization",
            "status": "OPEN",
            "description": "R227M keeps kappa_root separate; G is not derived.",
        },
        {
            "open_item": "real equation of state",
            "status": "OPEN",
            "description": "Pressure profiles are synthetic hydrostatic shapes, not real stellar EOS.",
        },
        {
            "open_item": "full stellar structure equations",
            "status": "OPEN",
            "description": "No energy transport, opacity, nuclear burning, or stellar evolution.",
        },
        {
            "open_item": "species q_i and binding energy",
            "status": "OPEN",
            "description": "No electron/proton/neutron/binding source map.",
        },
        {
            "open_item": "relativistic compact-star corrections",
            "status": "OPEN",
            "description": "Toy weak-field skeleton only; no TOV solution.",
        },
        {
            "open_item": "observational validation",
            "status": "OPEN",
            "description": "No observed star data or fitted parameters.",
        },
    ]
    return pd.DataFrame(rows)


def write_optional_figures(root: Path, stars: dict, profile_df: pd.DataFrame, pressure_df: pd.DataFrame) -> dict:
    figs = {}
    figdir = root / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    try:
        import matplotlib.pyplot as plt

        # Figure 1: representative rho and rho_ops.
        p1 = figdir / "representative_stellar_sources.png"
        plt.figure()
        for key in ["uniform_w0_0", "quadratic_w0_0.05", "concentrated_w0_0.1"]:
            star = stars[key]
            plt.plot(star["r"], star["rho"], label=f"{key} rho")
            plt.plot(star["r"], star["rho_ops"], linestyle="--", label=f"{key} rho_ops")
        plt.xlabel("r/R")
        plt.ylabel("source density")
        plt.title("Toy stellar source densities")
        plt.legend(fontsize=7)
        plt.tight_layout()
        plt.savefig(p1, dpi=180)
        plt.close()
        figs["representative_stellar_sources"] = str(p1)

        # Figure 2: enclosed source.
        p2 = figdir / "enclosed_source_profiles.png"
        plt.figure()
        for key in ["uniform_w0_0", "quadratic_w0_0.05", "concentrated_w0_0.1"]:
            star = stars[key]
            plt.plot(star["r"], star["Q_ops"], label=key)
        plt.xlabel("r/R")
        plt.ylabel("Q_ops enclosed")
        plt.title("Enclosed stellar operation source")
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(p2, dpi=180)
        plt.close()
        figs["enclosed_source_profiles"] = str(p2)

        # Figure 3: interior gravity.
        p3 = figdir / "interior_gravity_profiles.png"
        plt.figure()
        for key in ["uniform_w0_0", "quadratic_w0_0.05", "concentrated_w0_0.1"]:
            star = stars[key]
            plt.plot(star["r"], star["g_ops"], label=key)
        plt.xlabel("r/R")
        plt.ylabel("g_ops")
        plt.title("Interior settlement gravity skeleton")
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(p3, dpi=180)
        plt.close()
        figs["interior_gravity_profiles"] = str(p3)

        # Figure 4: pressure boost law.
        p4 = figdir / "pressure_boost_law.png"
        plt.figure()
        for profile in sorted(profile_df["profile"].unique()):
            sub = profile_df[profile_df["profile"] == profile]
            plt.plot(sub["central_w0_target"], sub["source_boost_Qops_over_Qmass"], marker="o", label=profile)
        plt.xlabel("central w0 = p_c/(rho_c c^2)")
        plt.ylabel("Q_ops / Q_mass")
        plt.title("Pressure contribution to operation source")
        plt.legend()
        plt.tight_layout()
        plt.savefig(p4, dpi=180)
        plt.close()
        figs["pressure_boost_law"] = str(p4)

    except Exception as e:
        figs["figure_error"] = repr(e)

    return figs


def build_report(
    created_utc: str,
    verdict: str,
    profile_df: pd.DataFrame,
    enclosed_df: pd.DataFrame,
    pressure_df: pd.DataFrame,
    root_df: pd.DataFrame,
    guardrail_df: pd.DataFrame,
    claims_df: pd.DataFrame,
    open_df: pd.DataFrame,
) -> str:
    return f"""
# SFT V12.13 R227M — Real Stellar Source Skeleton

Generated: {created_utc}

Verdict:
{verdict}

## Purpose

R227M tests the next bridge after R225M and R226M:

    q_i
    -> rho_set
    -> rho_ops = rho + 3p/c^2
    -> enclosed source Q_ops(r)
    -> stellar interior field
    -> exterior total-source gravity law

This is a synthetic stellar-source skeleton only.

## Star profile tests

{profile_df.to_string(index=False)}

## Representative enclosed-source table

{enclosed_df.to_string(index=False)}

## Pressure boost law tests

{pressure_df.to_string(index=False)}

## Root-normalization shape tests

{root_df.to_string(index=False)}

## Category guardrails

{guardrail_df.to_string(index=False)}

## Claim boundary

{claims_df.to_string(index=False)}

## Open claims

{open_df.to_string(index=False)}

## Interpretation

R227M supports the stellar-source skeleton:

    rho_set is the cold matter-energy source in normalized units.
    rho_ops = rho_set + 3p/c^2 is the pressure-aware operation source.
    Q_ops(r) = integral_0^r 4pi r'^2 rho_ops(r') dr'
    g(r) = Q_ops(r)/r^2
    phi_ext(r) = Q_ops_total/r
    g_ext(r) = Q_ops_total/r^2

The exterior law depends on total Q_ops and preserves the weak-field slopes.
Root normalization changes amplitude, not shape.
Whole-star 6pi is rejected as a category error.

## Ruling

The q_i -> rho_set -> rho_ops -> stellar-source chain passes at synthetic skeleton level.
Absolute G/root normalization, real stellar structure, species/binding source map, compact-star corrections, and observational validation remain open.
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    profile_df, profile_summary, stars = star_profile_tests()
    enclosed_df = enclosed_law_table(stars)
    pressure_df, pressure_summary = pressure_boost_law_tests(profile_df)
    root_df, root_summary = root_normalization_shape_tests(stars)
    guardrail_df, guardrail_summary = category_guardrail_tests()
    claims_df = claim_boundary_matrix()
    open_df = open_claims_ledger()

    figs = write_optional_figures(root, stars, profile_df, pressure_df)

    verdict = (
        "PARTIAL_PASS_REAL_STELLAR_SOURCE_SKELETON_TESTED_"
        "RHO_SET_TO_RHO_OPS_EQUALS_RHO_PLUS_3P_OVER_C2_CHAIN_PRESERVED_"
        "HYDROSTATIC_TOY_PRESSURE_SHAPES_GENERATE_MONOTONIC_PRESSURE_SOURCE_BOOST_"
        "ENCLOSED_Q_OPS_DRIVES_INTERIOR_FIELD_EXTERIOR_FIELD_DEPENDS_ON_TOTAL_Q_OPS_"
        "EXTERIOR_PHI_MINUS1_AND_G_MINUS2_SLOPES_PRESERVED_SURFACE_CONTINUITY_PASSES_"
        "ROOT_NORMALIZATION_CHANGES_AMPLITUDE_NOT_SHAPE_WHOLE_STAR_6PI_REJECTED_AS_CATEGORY_ERROR_"
        "G_NORMALIZATION_REAL_STELLAR_STRUCTURE_SPECIES_BINDING_MAP_COMPACT_STAR_CORRECTIONS_AND_VALIDATION_OPEN"
    )

    # Write tables.
    profile_df.to_csv(tables / "R227M_star_profile_tests.csv", index=False)
    enclosed_df.to_csv(tables / "R227M_representative_enclosed_source.csv", index=False)
    pressure_df.to_csv(tables / "R227M_pressure_boost_law.csv", index=False)
    root_df.to_csv(tables / "R227M_root_normalization_shape_tests.csv", index=False)
    guardrail_df.to_csv(tables / "R227M_category_guardrails.csv", index=False)
    claims_df.to_csv(tables / "R227M_claim_boundary_matrix.csv", index=False)
    open_df.to_csv(tables / "R227M_open_claims_ledger.csv", index=False)

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "stellar_source_chain": [
            "q_i normalized maintained closure demand",
            "rho_set(x)=sum_i q_i delta(x-x_i)",
            "rho_ops=rho_set+3p/c^2",
            "Q_ops(r)=integral 4pi r^2 rho_ops dr",
            "g(r)=Q_ops(r)/r^2",
            "phi_ext=Q_ops_total/r",
            "g_ext=Q_ops_total/r^2",
        ],
        "V12_13_context": {
            "L_eff": L_EFF,
            "N_eff": N_EFF,
            "amplitude_tax": AMP_TAX,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "K_top": SIX_PI,
            "K_top_category": "particle/top-sector terminal closure, not whole-star multiplier",
        },
        "profile_summary": profile_summary,
        "pressure_boost_summary": pressure_summary,
        "root_normalization_summary": root_summary,
        "guardrail_summary": guardrail_summary,
        "figures": figs,
        "ruling": "q_i -> rho_set -> rho_ops -> stellar-source chain passes at synthetic skeleton level; real stellar physics and G normalization remain open.",
        "next_recommended": "R228M - Binding/Internal-Energy Source Accounting: separate rest-mass q_i, pressure, radiation, and negative binding energy without observed data.",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R227M_star_profile_tests.csv",
            "tables/R227M_pressure_boost_law.csv",
            "tables/R227M_root_normalization_shape_tests.csv",
            "tables/R227M_category_guardrails.csv",
            "Any traceback if failed.",
        ],
    }

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        profile_df=profile_df,
        enclosed_df=enclosed_df,
        pressure_df=pressure_df,
        root_df=root_df,
        guardrail_df=guardrail_df,
        claims_df=claims_df,
        open_df=open_df,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    manifest = make_manifest(root, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary_path": str((root / "summary.json").resolve()),
        "report_path": str((root / "report.md").resolve()),
        "manifest_file_count_excluding_manifest": manifest["file_count_excluding_manifest"],
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
