#!/usr/bin/env python3
"""
SFT V13.1 / R231M — Gravity Program Source Inventory and Claim Migration Map

Branch:
    SFT V13.1 — Particle-to-Star/Cosmos Gravity Accumulation Unification

Purpose:
    Prepare the full V13.1 gravity monograph by migrating the older SFT gravity
    program into one coherent V13.1 gravity picture.

    This is not a new physical derivation. It is a source inventory, claim
    migration, equation-support, guardrail, and manuscript-planning checkpoint.

Inputs:
    Optional local files/packs:
        - SFT V11.13 Gravity Initial Draft PDF
        - SFT V12.3 Gravity Trajectory Prevalidation Draft PDF
        - SFT V12.13 final PDF / pack
        - R225M-R230M run packs or folders

    If files are present, the script inventories them. If summaries are missing,
    it uses locked fallback claim summaries from the current SFT thread.

Outputs:
    SFT_V13_1_R231M_Gravity_Program_Source_Inventory_Claim_Migration_Map/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R231M.py

    SFT_V13_1_R231M_Gravity_Program_Source_Inventory_Claim_Migration_Map_Pack.zip

Migration statuses:
    PROMOTE:
        Core V13.1 claim.

    PRESERVE:
        Still valid as older gravity scaffold.

    RESTATE:
        Keep, but rewrite in new particle-source language.

    DEFER:
        Carry forward, but not solved in V13.1 gravity monograph.

    GUARDRAIL:
        Allowed only inside boundary.

    REJECT:
        Blocked, circular, overclaim, or category error.

Core intended V13.1 chain:
    locally-real particle closure
    -> q_i
    -> rho_set
    -> rho_active
    -> Q_active
    -> weak-field geometry
    -> star gravity
    -> compactness handoff
    -> far-field/cosmic continuation with guardrails
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile
from typing import Any

import pandas as pd


RUN_ID = "SFT_V13_1_R231M_Gravity_Program_Source_Inventory_Claim_Migration_Map"
BRANCH = "SFT V13.1 — Particle-to-Star/Cosmos Gravity Accumulation Unification"

TWO_PI = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = 3.0 * math.pi - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)

EXPECTED_RUN_KEYS = ["R225M", "R226M", "R227M", "R228M", "R229M", "R230M"]


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "file_count_excluding_manifest": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def load_json_file(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def try_extract_pdf_text(path: Path, max_pages: int = 4) -> str:
    """
    Best-effort PDF text extraction for inventory only.
    Does not fail the run if PDF libraries are absent.
    """
    # Try pypdf first.
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        pages = []
        for page in reader.pages[:max_pages]:
            pages.append(page.extract_text() or "")
        return "\n".join(pages)
    except Exception:
        pass

    # Try PyPDF2 fallback.
    try:
        import PyPDF2
        reader = PyPDF2.PdfReader(str(path))
        pages = []
        for page in reader.pages[:max_pages]:
            pages.append(page.extract_text() or "")
        return "\n".join(pages)
    except Exception:
        return ""


def inventory_local_sources(search_root: Path) -> pd.DataFrame:
    """
    Inventory likely relevant local files.
    """
    rows = []

    suffixes = {".pdf", ".md", ".txt", ".json", ".csv", ".zip"}
    keywords = [
        "SFT",
        "V11",
        "V12",
        "V13",
        "Gravity",
        "gravity",
        "R225",
        "R226",
        "R227",
        "R228",
        "R229",
        "R230",
        "R231",
    ]

    for p in sorted(search_root.rglob("*")):
        if not p.is_file():
            continue
        if p.suffix not in suffixes:
            continue
        name = p.name
        if not any(k in str(p) for k in keywords):
            continue

        source_guess = "unknown"
        sp = str(p)
        if "V11_13" in sp or "11_13" in sp:
            source_guess = "V11.13 gravity draft"
        elif "V12" in sp and "Gravity" in sp:
            source_guess = "V12 gravity document"
        elif "V12_13" in sp:
            source_guess = "V12.13 particle framework"
        elif "R225" in sp:
            source_guess = "R225M particle-to-star accumulation"
        elif "R226" in sp:
            source_guess = "R226M source normalization"
        elif "R227" in sp:
            source_guess = "R227M stellar source skeleton"
        elif "R228" in sp:
            source_guess = "R228M active-source ledger"
        elif "R229" in sp:
            source_guess = "R229M compactness guardrail"
        elif "R230" in sp:
            source_guess = "R230M rollup"
        elif "R231" in sp:
            source_guess = "R231M migration map"

        text_probe = ""
        if p.suffix == ".pdf":
            text_probe = try_extract_pdf_text(p, max_pages=2)[:500].replace("\n", " ")
        elif p.suffix in {".md", ".txt", ".json"}:
            try:
                text_probe = p.read_text(encoding="utf-8", errors="ignore")[:500].replace("\n", " ")
            except Exception:
                text_probe = ""

        rows.append({
            "path": str(p),
            "file": p.name,
            "suffix": p.suffix,
            "bytes": p.stat().st_size,
            "source_guess": source_guess,
            "text_probe": text_probe,
        })

    return pd.DataFrame(rows)


def find_summary_jsons(search_root: Path) -> dict[str, dict]:
    found: dict[str, dict] = {}

    # Directory summaries.
    for path in search_root.rglob("summary.json"):
        data = load_json_file(path)
        if not isinstance(data, dict):
            continue
        run_id = str(data.get("run_id", ""))
        for key in EXPECTED_RUN_KEYS:
            if key in run_id and key not in found:
                data["_source_path"] = str(path)
                found[key] = data

    # ZIP summaries.
    for zip_path in search_root.rglob("*.zip"):
        try:
            with zipfile.ZipFile(zip_path, "r") as z:
                names = [n for n in z.namelist() if n.endswith("summary.json")]
                for name in names:
                    try:
                        data = json.loads(z.read(name).decode("utf-8"))
                    except Exception:
                        continue
                    if not isinstance(data, dict):
                        continue
                    run_id = str(data.get("run_id", ""))
                    for key in EXPECTED_RUN_KEYS:
                        if key in run_id and key not in found:
                            data["_source_path"] = f"{zip_path}::{name}"
                            found[key] = data
        except Exception:
            continue

    return found


def fallback_summaries() -> dict[str, dict]:
    return {
        "R225M": {
            "run_id": "SFT_V12_13_R225M_Particle_to_Star_Settlement_Accumulation_Test",
            "ruling": "Particle-to-star gravity accumulation skeleton passes synthetic structural tests; normalization and real stellar modeling open.",
            "status": "PARTIAL_PASS",
        },
        "R226M": {
            "run_id": "SFT_V12_13_R226M_Particle_Source_Density_Normalization_Bridge",
            "ruling": "q_i to rho_set source bridge passes in normalized units; G/root normalization and species map remain open.",
            "status": "PARTIAL_PASS",
        },
        "R227M": {
            "run_id": "SFT_V12_13_R227M_Real_Stellar_Source_Skeleton",
            "ruling": "q_i -> rho_set -> rho_ops -> stellar-source chain passes at synthetic skeleton level.",
            "status": "PARTIAL_PASS",
        },
        "R228M": {
            "run_id": "SFT_V13_1_R228M_Binding_Internal_Energy_Source_Accounting",
            "ruling": "Component source ledger passes at synthetic structural level.",
            "status": "PARTIAL_PASS",
        },
        "R229M": {
            "run_id": "SFT_V13_1_R229M_Compactness_Relativistic_Pressure_Guardrail",
            "ruling": "Compactness/pressure handoff guardrail passes.",
            "status": "PARTIAL_PASS",
        },
        "R230M": {
            "run_id": "SFT_V13_1_R230M_Gravity_Accumulation_Unification_Rollup",
            "ruling": "Gravity accumulation unification rollup frozen.",
            "status": "PASS",
        },
    }


def merge_found_with_fallback(found: dict[str, dict]) -> dict[str, dict]:
    fallback = fallback_summaries()
    merged = {}
    for key in EXPECTED_RUN_KEYS:
        merged[key] = found.get(key, fallback[key])
        if key not in found:
            merged[key]["_source_path"] = "fallback_locked_from_chat"
            merged[key]["_used_fallback"] = True
        else:
            merged[key]["_used_fallback"] = False
    return merged


def build_legacy_gravity_inheritance_table() -> pd.DataFrame:
    rows = [
        {
            "source": "V11.13 Gravity Addendum",
            "legacy_claim": "Gravity is coarse-grained settlement geometry of maintained one-speed structures.",
            "V13_1_migration": "PROMOTE",
            "V13_1_restatement": "Gravity is accumulated settlement geometry sourced by locally-real particle closure maintenance.",
            "equation_support": "q_i -> rho_set -> Q_active -> phi,g",
            "guardrail": "Structural weak-field unification, not G derivation.",
        },
        {
            "source": "V11.13 Gravity Addendum",
            "legacy_claim": "Exterior potential behaves as phi~1/r and acceleration as g~1/r^2.",
            "V13_1_migration": "PROMOTE",
            "V13_1_restatement": "Exterior weak-field shape laws follow from total accumulated Q_active.",
            "equation_support": "phi_ext=Q_active,total/r; g_ext=Q_active,total/r^2",
            "guardrail": "Shape law only; amplitude requires kappa_root.",
        },
        {
            "source": "V11.13 Gravity Addendum",
            "legacy_claim": "Interior uniform-source acceleration scales as g~r.",
            "V13_1_migration": "PRESERVE",
            "V13_1_restatement": "Uniform enclosed-source skeleton retains interior g~r behavior.",
            "equation_support": "g(r)=Q(r)/r^2 with Q(r)~r^3",
            "guardrail": "Toy source profile only.",
        },
        {
            "source": "V11.13 Gravity Addendum",
            "legacy_claim": "Metric closure uses reciprocal one-speed faces F=e^{-phi}, B=e^{+phi}, FB=1.",
            "V13_1_migration": "PROMOTE",
            "V13_1_restatement": "Local weak-field closure is sourced by accumulated Q_active and preserves FB=1.",
            "equation_support": "F=exp(-phi); B=exp(phi); FB=1",
            "guardrail": "FB=1 does not imply weak expansion remains valid at high compactness.",
        },
        {
            "source": "V11.13 Gravity Addendum",
            "legacy_claim": "Scalar gravity is weak-field 00 projection of deeper tensor settlement.",
            "V13_1_migration": "PRESERVE",
            "V13_1_restatement": "V13.1 treats Lambda_00 / scalar gravity as the weak-field projection of accumulated active source.",
            "equation_support": "rho_active -> Q_active -> phi",
            "guardrail": "Full tensor equations remain open.",
        },
        {
            "source": "V11.13 Gravity Addendum",
            "legacy_claim": "Absolute G/root-state normalization is unresolved.",
            "V13_1_migration": "PRESERVE",
            "V13_1_restatement": "kappa_root/G normalization remains open.",
            "equation_support": "physical amplitude = kappa_root * normalized source",
            "guardrail": "No Planck/G smuggling.",
        },
        {
            "source": "V12.3 Gravity Trajectory Prevalidation",
            "legacy_claim": "rho_set/rho_ops source channel includes pressure term rho+3p/c^2.",
            "V13_1_migration": "PROMOTE",
            "V13_1_restatement": "rho_ops=rho_set+3p/c^2 and rho_active includes pressure trace.",
            "equation_support": "rho_ops=rho_set+3p/c^2; rho_active=...+3p/c^2+...",
            "guardrail": "Toy pressure profiles only; real EOS open.",
        },
        {
            "source": "V12.3 Gravity Trajectory Prevalidation",
            "legacy_claim": "Far-field handoff uses a_S=cH/2pi.",
            "V13_1_migration": "PRESERVE",
            "V13_1_restatement": "a_S=cH/2pi is carried forward as far-field/cosmic settlement handoff context.",
            "equation_support": "a_S=cH/(2pi)",
            "guardrail": "Not retested in R225-R230; must be V13 galaxy/cosmos sector.",
        },
        {
            "source": "V12.3 Gravity Trajectory Prevalidation",
            "legacy_claim": "Environment factor E=sqrt(DB) modifies far-field handoff radius.",
            "V13_1_migration": "PRESERVE_WITH_RETEST",
            "V13_1_restatement": "E=sqrt(DB) remains a far-field sector candidate to retest against rho_active.",
            "equation_support": "r_t=r_0/sqrt(E)",
            "guardrail": "Cannot modify local metric/source sector.",
        },
        {
            "source": "V12.3 Gravity Trajectory Prevalidation",
            "legacy_claim": "Local FB=1 metric closure remains protected from far-field environmental factors.",
            "V13_1_migration": "PROMOTE",
            "V13_1_restatement": "Local source geometry is protected; far-field modifiers must not retune local closure.",
            "equation_support": "F=exp(-phi), B=exp(phi), FB=1",
            "guardrail": "E belongs to far-field handoff only.",
        },
        {
            "source": "V12.13 Particle Framework",
            "legacy_claim": "Particles are locally real support structures, not abstract labels.",
            "V13_1_migration": "PROMOTE",
            "V13_1_restatement": "Gravity source begins with locally-real particle closure maintenance.",
            "equation_support": "particle closure -> q_i",
            "guardrail": "No species mass map derived.",
        },
        {
            "source": "V12.13 Particle Framework",
            "legacy_claim": "4pi curvature and 2pi frame/gauge closure combine as 6pi top-sector closure.",
            "V13_1_migration": "RESTATE_AND_GUARDRAIL",
            "V13_1_restatement": "6pi remains particle/top-sector terminal closure, not whole-star multiplier.",
            "equation_support": "K_top=4pi+2pi=6pi",
            "guardrail": "Whole-star 6pi rejected.",
        },
    ]
    return pd.DataFrame(rows)


def build_R225_R230_migration_table(summaries: dict[str, dict]) -> pd.DataFrame:
    rows = [
        {
            "run": "R225M",
            "claim": "Particle closure support accumulates into star-scale settlement gravity.",
            "migration": "PROMOTE",
            "V13_1_placement": "Core particle-to-star bridge.",
            "math_support": "q_i accumulation -> continuum sphere phi~1/r, g~1/r^2",
            "guardrail": "Synthetic skeleton; no G/species/real star validation.",
        },
        {
            "run": "R226M",
            "claim": "q_i is normalized maintained closure-demand source.",
            "migration": "PROMOTE",
            "V13_1_placement": "Particle source dictionary.",
            "math_support": "rho_set(x)=sum_i q_i delta(x-x_i)",
            "guardrail": "Normalized only; G/root normalization open.",
        },
        {
            "run": "R226M",
            "claim": "Root normalization changes amplitude, not shape.",
            "migration": "PROMOTE",
            "V13_1_placement": "G/root boundary.",
            "math_support": "kappa_root*rho_set preserves phi/g slopes",
            "guardrail": "No G derivation.",
        },
        {
            "run": "R227M",
            "claim": "rho_ops=rho_set+3p/c^2 drives stellar source skeleton.",
            "migration": "PROMOTE",
            "V13_1_placement": "Stellar active-source section.",
            "math_support": "Q_ops(r)=int 4pi r^2 rho_ops dr",
            "guardrail": "Toy hydrostatic profiles only.",
        },
        {
            "run": "R228M",
            "claim": "rho_active separates rest, internal, radiation, pressure trace, and binding.",
            "migration": "PROMOTE",
            "V13_1_placement": "Active source ledger.",
            "math_support": "rho_active=rho_rest+u_int+rho_rad+3p/c^2+rho_bind",
            "guardrail": "Real EOS/binding theorem/species map open.",
        },
        {
            "run": "R228M",
            "claim": "Gas active internal contribution is 3u for gamma=5/3; radiation is 2rho_rad.",
            "migration": "PROMOTE",
            "V13_1_placement": "Component identities subsection.",
            "math_support": "u+3p=3u; rho_rad+3p_rad=2rho_rad",
            "guardrail": "Toy component identities, not full EOS.",
        },
        {
            "run": "R229M",
            "claim": "Weak-field skeleton requires compactness/pressure handoff.",
            "migration": "PROMOTE",
            "V13_1_placement": "Compactness guardrail section.",
            "math_support": "C=kappa_root Q_active/R",
            "guardrail": "No TOV solution.",
        },
        {
            "run": "R230M",
            "claim": "V13.1 gravity accumulation rollup is frozen.",
            "migration": "PROMOTE",
            "V13_1_placement": "Monograph foundation.",
            "math_support": "R225-R229 consolidated chain",
            "guardrail": "Rollup only; source inventory still required.",
        },
    ]

    # Attach source path/fallback info.
    source_map = {
        k: {
            "source_path": summaries[k].get("_source_path", ""),
            "used_fallback": summaries[k].get("_used_fallback", False),
        }
        for k in EXPECTED_RUN_KEYS
    }

    for row in rows:
        src = source_map.get(row["run"], {})
        row["source_path"] = src.get("source_path", "")
        row["used_fallback"] = src.get("used_fallback", False)

    return pd.DataFrame(rows)


def build_equation_support_matrix() -> pd.DataFrame:
    rows = [
        {
            "equation": "q_i = normalized maintained closure-demand source",
            "role": "particle source dictionary",
            "source_lineage": "V12.13 + R226M",
            "V13_1_status": "CORE",
            "guardrail": "not species-specific; not G",
        },
        {
            "equation": "rho_set(x)=sum_i q_i delta(x-x_i)",
            "role": "coarse-grained source density",
            "source_lineage": "R226M",
            "V13_1_status": "CORE",
            "guardrail": "normalized continuum source",
        },
        {
            "equation": "rho_ops=rho_set+3p/c^2",
            "role": "pressure-aware operation source",
            "source_lineage": "V12.3 + R227M",
            "V13_1_status": "CORE",
            "guardrail": "toy pressure profile; real EOS open",
        },
        {
            "equation": "rho_active=rho_rest+u_int+rho_rad+3p/c^2+rho_bind",
            "role": "component active source",
            "source_lineage": "R228M",
            "V13_1_status": "CORE",
            "guardrail": "binding theorem/species map open",
        },
        {
            "equation": "Q_active(r)=int_0^r 4pi r'^2 rho_active(r') dr'",
            "role": "enclosed stellar source",
            "source_lineage": "R227M/R228M",
            "V13_1_status": "CORE",
            "guardrail": "weak-field skeleton",
        },
        {
            "equation": "g(r)=Q_active(r)/r^2",
            "role": "interior field skeleton",
            "source_lineage": "R225M/R227M",
            "V13_1_status": "CORE",
            "guardrail": "normalized units; amplitude open",
        },
        {
            "equation": "phi_ext=Q_active,total/r",
            "role": "exterior potential shape",
            "source_lineage": "V11.13 + R225M-R229M",
            "V13_1_status": "CORE",
            "guardrail": "shape law only",
        },
        {
            "equation": "g_ext=Q_active,total/r^2",
            "role": "exterior acceleration shape",
            "source_lineage": "V11.13 + R225M-R229M",
            "V13_1_status": "CORE",
            "guardrail": "shape law only",
        },
        {
            "equation": "F=exp(-phi), B=exp(phi), FB=1",
            "role": "one-speed reciprocal metric closure",
            "source_lineage": "V11.13/V12.3 + R229M",
            "V13_1_status": "CORE",
            "guardrail": "exact closure not equal to weak-field validity at high C",
        },
        {
            "equation": "C=kappa_root Q_active/R",
            "role": "compactness handoff proxy",
            "source_lineage": "R229M",
            "V13_1_status": "CORE_GUARDRAIL",
            "guardrail": "not physical threshold calibration",
        },
        {
            "equation": "a_S=cH/(2pi)",
            "role": "far-field/cosmic settlement handoff",
            "source_lineage": "V12.3",
            "V13_1_status": "CARRIED_FORWARD",
            "guardrail": "must be retested in galaxy/cosmos sector",
        },
        {
            "equation": "E=sqrt(DB)",
            "role": "far-field environment factor",
            "source_lineage": "V12.3",
            "V13_1_status": "CARRIED_FORWARD_WITH_RETEST",
            "guardrail": "not allowed to modify local source sector",
        },
        {
            "equation": "K_top=4pi+2pi=6pi",
            "role": "particle/top-sector terminal closure",
            "source_lineage": "V12.13",
            "V13_1_status": "GUARDRAILED",
            "guardrail": "not a whole-star multiplier",
        },
    ]
    return pd.DataFrame(rows)


def build_monograph_outline_table() -> pd.DataFrame:
    rows = [
        {
            "section": 1,
            "title": "Executive Claim and Claim Boundary",
            "purpose": "State V13.1 gravity unification and blocked claims.",
            "key_content": "Frozen claim, no-G/no-TOV/no-validation/no-whole-star-6pi ledger.",
        },
        {
            "section": 2,
            "title": "Inherited Gravity Program",
            "purpose": "Pull V11.13 and V12.3 forward.",
            "key_content": "Gravity as settlement geometry; FB=1; phi~1/r; g~1/r^2; far-field handoff.",
        },
        {
            "section": 3,
            "title": "Locally-Real Particle Source",
            "purpose": "Connect V12.13 particle ontology to gravity source.",
            "key_content": "particle closure -> q_i; q_i source dictionary.",
        },
        {
            "section": 4,
            "title": "Continuum and Active Source Ledger",
            "purpose": "Build rho_set, rho_ops, rho_active.",
            "key_content": "pressure, internal energy, radiation, binding.",
        },
        {
            "section": 5,
            "title": "Star Interior and Exterior Weak-Field Skeleton",
            "purpose": "Show Q_active accumulation into stellar gravity.",
            "key_content": "Q_active(r), g(r), phi_ext, g_ext, continuity.",
        },
        {
            "section": 6,
            "title": "One-Speed Metric Closure",
            "purpose": "Integrate F=exp(-phi), B=exp(phi), FB=1.",
            "key_content": "clock lag, spatial closure, attraction as gradient face.",
        },
        {
            "section": 7,
            "title": "Compactness and Relativistic-Pressure Handoff",
            "purpose": "State weak-field validity guardrail.",
            "key_content": "C, w_max, weak expansion error, compact-sector required.",
        },
        {
            "section": 8,
            "title": "Galaxy/Far-Field and Cosmological Continuation",
            "purpose": "Carry V12.3 far-field/cosmic context forward carefully.",
            "key_content": "a_S=cH/2pi, E=sqrt(DB), H(t)=c/R(t), no-overwrite context.",
        },
        {
            "section": 9,
            "title": "Run Evidence Catalog",
            "purpose": "Summarize R225M-R230M.",
            "key_content": "run table, metrics, verdicts.",
        },
        {
            "section": 10,
            "title": "Final Ledger",
            "purpose": "Close with solved/conditional/open/rejected claims.",
            "key_content": "claim migration map, open problems, next V13 sectors.",
        },
    ]
    return pd.DataFrame(rows)


def build_guardrail_matrix() -> pd.DataFrame:
    rows = [
        {
            "guardrail": "No G derivation",
            "rule": "kappa_root/G normalization remains open.",
            "reason": "Avoids Planck/G circularity from V11.13 root-invariant problem.",
            "status": "BLOCKING",
        },
        {
            "guardrail": "No species map",
            "rule": "q_i is normalized; no electron/proton/neutron source map.",
            "reason": "Particle species/source strengths not derived.",
            "status": "BLOCKING",
        },
        {
            "guardrail": "No real EOS",
            "rule": "Pressure/component profiles are synthetic.",
            "reason": "R227/R228 do not model real stellar matter.",
            "status": "BLOCKING",
        },
        {
            "guardrail": "Compactness handoff",
            "rule": "High C or high pressure requires compact-star sector.",
            "reason": "FB=1 can hold while weak expansion fails.",
            "status": "HANDOFF",
        },
        {
            "guardrail": "No observed validation",
            "rule": "No fitted stellar/galaxy data in V13.1 gravity rollup.",
            "reason": "Theory freeze before validation.",
            "status": "BLOCKING",
        },
        {
            "guardrail": "No whole-star 6pi",
            "rule": "6pi is particle/top-sector terminal closure, not star multiplier.",
            "reason": "R225-R230 repeatedly reject category error.",
            "status": "REJECTED",
        },
        {
            "guardrail": "Far-field E=sqrt(DB) locality",
            "rule": "E can only affect far-field handoff, not local source/metric closure.",
            "reason": "Preserves V12.3 local FB=1 and V13.1 source chain.",
            "status": "CARRIED_FORWARD",
        },
        {
            "guardrail": "Cosmos context not fully solved",
            "rule": "H(t), a_S, no-overwrite expansion are context for later sector work.",
            "reason": "V13.1 gravity monograph may include but not overclaim cosmic closure.",
            "status": "DEFER",
        },
    ]
    return pd.DataFrame(rows)


def build_claim_status_counts(*dfs: pd.DataFrame) -> dict:
    counts = {}
    for df in dfs:
        for col in ["V13_1_migration", "migration"]:
            if col in df.columns:
                for val in df[col].value_counts().to_dict().items():
                    counts[val[0]] = counts.get(val[0], 0) + int(val[1])
    return counts


def build_report(
    created_utc: str,
    verdict: str,
    source_inventory: pd.DataFrame,
    legacy_table: pd.DataFrame,
    migration_table: pd.DataFrame,
    equation_matrix: pd.DataFrame,
    outline_table: pd.DataFrame,
    guardrail_matrix: pd.DataFrame,
) -> str:
    return f"""
# SFT V13.1 / R231M — Gravity Program Source Inventory and Claim Migration Map

Generated: {created_utc}

Verdict:
{verdict}

## Branch

{BRANCH}

## Purpose

R231M prepares the full V13.1 gravity monograph by migrating the entire gravity program into one coherent picture from particle to cosmos, with guardrails.

## Local source inventory

{source_inventory.to_string(index=False) if len(source_inventory) else "No local sources detected by inventory scan."}

## Legacy gravity inheritance map

{legacy_table.to_string(index=False)}

## R225M-R230M migration map

{migration_table.to_string(index=False)}

## Equation support matrix

{equation_matrix.to_string(index=False)}

## Monograph outline map

{outline_table.to_string(index=False)}

## Guardrail matrix

{guardrail_matrix.to_string(index=False)}

## V13.1 gravity picture

The unified statement is:

    Gravity is the accumulated settlement geometry of locally-real particle support.

The chain is:

    particle closure
    -> q_i
    -> rho_set
    -> rho_active
    -> Q_active
    -> weak-field geometry
    -> stars
    -> guarded compactness handoff
    -> far-field/cosmic continuation

## Manuscript ruling

R231M clears the source migration needed for a full V13.1 gravity unification document. The final manuscript should promote the particle-to-star chain, preserve V11.13/V12.3 weak-field and far-field scaffolds, restate older source claims in q_i/rho_active language, defer galaxy/cosmos/compact-star/root-G sectors where needed, and reject whole-star 6pi or G-smuggling moves.
"""


def main() -> None:
    created_utc = utc_now_iso()
    search_root = Path.cwd()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    source_inventory = inventory_local_sources(search_root)
    found = find_summary_jsons(search_root)
    summaries = merge_found_with_fallback(found)

    legacy_table = build_legacy_gravity_inheritance_table()
    migration_table = build_R225_R230_migration_table(summaries)
    equation_matrix = build_equation_support_matrix()
    outline_table = build_monograph_outline_table()
    guardrail_matrix = build_guardrail_matrix()

    claim_counts = build_claim_status_counts(legacy_table, migration_table)

    found_count = sum(1 for k in EXPECTED_RUN_KEYS if not summaries[k].get("_used_fallback", False))
    fallback_count = sum(1 for k in EXPECTED_RUN_KEYS if summaries[k].get("_used_fallback", False))

    verdict = (
        "PASS_V13_1_R231M_GRAVITY_PROGRAM_SOURCE_INVENTORY_AND_CLAIM_MIGRATION_MAP_READY_"
        "V11_13_V12_3_V12_13_R225_TO_R230_CLAIMS_MIGRATED_INTO_PARTICLE_TO_COSMOS_GRAVITY_PICTURE_"
        "PROMOTE_PRESERVE_RESTATE_DEFER_GUARDRAIL_REJECT_LEDGER_BUILT_"
        "EQUATION_SUPPORT_MATRIX_AND_MONOGRAPH_OUTLINE_READY_"
        "G_ROOT_SPECIES_REAL_EOS_COMPACT_STAR_TOV_COLLAPSE_GALAXY_COSMOS_VALIDATION_GUARDRAILS_PRESERVED"
    )

    source_inventory.to_csv(tables / "R231M_local_source_inventory.csv", index=False)
    legacy_table.to_csv(tables / "R231M_legacy_gravity_inheritance_map.csv", index=False)
    migration_table.to_csv(tables / "R231M_R225_R230_claim_migration_map.csv", index=False)
    equation_matrix.to_csv(tables / "R231M_equation_support_matrix.csv", index=False)
    outline_table.to_csv(tables / "R231M_monograph_outline_map.csv", index=False)
    guardrail_matrix.to_csv(tables / "R231M_guardrail_matrix.csv", index=False)

    source_summary = {
        key: {
            "run_id": summaries[key].get("run_id"),
            "source_path": summaries[key].get("_source_path"),
            "used_fallback": summaries[key].get("_used_fallback", False),
            "ruling": summaries[key].get("ruling"),
            "status": summaries[key].get("status"),
            "verdict": summaries[key].get("verdict"),
        }
        for key in EXPECTED_RUN_KEYS
    }

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "branch": BRANCH,
        "verdict": verdict,
        "source_ingestion": {
            "search_root": str(search_root),
            "local_inventory_count": int(len(source_inventory)),
            "found_summary_count": found_count,
            "fallback_summary_count": fallback_count,
            "sources": source_summary,
        },
        "claim_migration_counts": claim_counts,
        "V13_1_unified_gravity_picture": (
            "Gravity is the accumulated settlement geometry of locally-real particle support: "
            "particle closure maps to q_i, q_i coarse-grains to rho_set, rho_set extends to rho_active, "
            "Q_active sources weak-field geometry, stars accumulate Q_active, compact/high-pressure regimes require handoff, "
            "and galaxy/cosmic gravity scaffolds are carried forward for later V13 retesting."
        ),
        "core_math_spine": [
            "q_i = normalized maintained closure-demand source",
            "rho_set(x)=sum_i q_i delta(x-x_i)",
            "rho_ops=rho_set+3p/c^2",
            "rho_active=rho_rest+u_int+rho_rad+3p/c^2+rho_bind",
            "Q_active(r)=int_0^r 4pi r'^2 rho_active(r')dr'",
            "g(r)=Q_active(r)/r^2",
            "phi_ext=Q_active,total/r",
            "g_ext=Q_active,total/r^2",
            "F=exp(-phi), B=exp(phi), FB=1",
            "C=kappa_root Q_active/R",
            "a_S=cH/(2pi) carried forward",
            "E=sqrt(DB) carried forward for far-field retest",
            "K_top=4pi+2pi=6pi guardrailed as particle/top-sector closure only",
        ],
        "manuscript_readiness": {
            "outline_ready": True,
            "equation_matrix_ready": True,
            "claim_migration_ready": True,
            "guardrail_matrix_ready": True,
            "recommended_next": "R232M — Draft V13.1 Gravity Unification Manuscript Source",
        },
        "claim_boundary": {
            "promote": [
                "gravity as accumulated settlement geometry of locally-real particle support",
                "q_i source dictionary",
                "rho_set/rho_active active-source chain",
                "weak-field phi~1/r and g~1/r^2 shape law",
                "FB=1 reciprocal closure",
                "compactness handoff guardrail",
            ],
            "preserve_or_carry_forward": [
                "V11.13 gravity settlement geometry",
                "V12.3 far-field a_S=cH/2pi",
                "V12.3 E=sqrt(DB) with retest",
                "cosmic no-overwrite expansion context",
            ],
            "defer_or_block": [
                "G/root normalization",
                "species q_i map",
                "real EOS",
                "stellar evolution",
                "compact-star/TOV solution",
                "collapse/horizon sector",
                "galaxy/cosmos validation",
                "observed validation",
            ],
            "reject": [
                "whole-star 6pi multiplier",
                "Planck/G circular derivation",
                "observed-data tuning inside source definition",
            ],
        },
        "next_recommended": (
            "R232M — build the V13.1 gravity unification manuscript source with V12.8/V12.9-style visuals, "
            "then R233M PDF/source pack freeze."
        ),
        "paste_back_to_chat": [
            "summary.json",
            "tables/R231M_legacy_gravity_inheritance_map.csv",
            "tables/R231M_R225_R230_claim_migration_map.csv",
            "tables/R231M_equation_support_matrix.csv",
            "tables/R231M_monograph_outline_map.csv",
            "tables/R231M_guardrail_matrix.csv",
            "Any traceback if failed.",
        ],
    }

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        source_inventory=source_inventory,
        legacy_table=legacy_table,
        migration_table=migration_table,
        equation_matrix=equation_matrix,
        outline_table=outline_table,
        guardrail_matrix=guardrail_matrix,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    manifest = make_manifest(root, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary_path": str((root / "summary.json").resolve()),
        "report_path": str((root / "report.md").resolve()),
        "manifest_file_count_excluding_manifest": manifest["file_count_excluding_manifest"],
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
