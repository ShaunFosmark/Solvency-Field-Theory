
# SFT V12.13 R227M — Real Stellar Source Skeleton

Generated: 2026-06-23T17:18:21Z

Verdict:
PARTIAL_PASS_REAL_STELLAR_SOURCE_SKELETON_TESTED_RHO_SET_TO_RHO_OPS_EQUALS_RHO_PLUS_3P_OVER_C2_CHAIN_PRESERVED_HYDROSTATIC_TOY_PRESSURE_SHAPES_GENERATE_MONOTONIC_PRESSURE_SOURCE_BOOST_ENCLOSED_Q_OPS_DRIVES_INTERIOR_FIELD_EXTERIOR_FIELD_DEPENDS_ON_TOTAL_Q_OPS_EXTERIOR_PHI_MINUS1_AND_G_MINUS2_SLOPES_PRESERVED_SURFACE_CONTINUITY_PASSES_ROOT_NORMALIZATION_CHANGES_AMPLITUDE_NOT_SHAPE_WHOLE_STAR_6PI_REJECTED_AS_CATEGORY_ERROR_G_NORMALIZATION_REAL_STELLAR_STRUCTURE_SPECIES_BINDING_MAP_COMPACT_STAR_CORRECTIONS_AND_VALIDATION_OPEN

## Purpose

R227M tests the next bridge after R225M and R226M:

    q_i
    -> rho_set
    -> rho_ops = rho + 3p/c^2
    -> enclosed source Q_ops(r)
    -> stellar interior field
    -> exterior total-source gravity law

This is a synthetic stellar-source skeleton only.

## Star profile tests

     profile  central_w0_target  central_w0_observed  Q_mass_total  Q_pressure_contribution  Q_ops_total  source_boost_Qops_over_Qmass  pressure_identity_error  p_surface  hydrostatic_shape_resid_rms  surface_g_abs_error  surface_phi_abs_error  exterior_phi_slope  exterior_g_slope status
     uniform              0.000                0.000           1.0                 0.000000     1.000000                      1.000000             0.000000e+00        0.0                 0.000000e+00                  0.0                    0.0                -1.0              -2.0   PASS
     uniform              0.001                0.001           1.0                 0.001200     1.001200                      1.001200             2.220446e-16        0.0                 2.138860e-10                  0.0                    0.0                -1.0              -2.0   PASS
     uniform              0.010                0.010           1.0                 0.012000     1.012000                      1.012000             6.661338e-16        0.0                 2.138849e-10                  0.0                    0.0                -1.0              -2.0   PASS
     uniform              0.050                0.050           1.0                 0.060000     1.060000                      1.060000             2.220446e-16        0.0                 2.138862e-10                  0.0                    0.0                -1.0              -2.0   PASS
     uniform              0.100                0.100           1.0                 0.120000     1.120000                      1.120000             4.440892e-16        0.0                 2.138862e-10                  0.0                    0.0                -1.0              -2.0   PASS
   quadratic              0.000                0.000           1.0                 0.000000     1.000000                      1.000000             0.000000e+00        0.0                 0.000000e+00                  0.0                    0.0                -1.0              -2.0   PASS
   quadratic              0.001                0.001           1.0                 0.001429     1.001429                      1.001429             1.110223e-15        0.0                 6.331811e-07                  0.0                    0.0                -1.0              -2.0   PASS
   quadratic              0.010                0.010           1.0                 0.014286     1.014286                      1.014286             1.554312e-15        0.0                 6.331811e-07                  0.0                    0.0                -1.0              -2.0   PASS
   quadratic              0.050                0.050           1.0                 0.071428     1.071428                      1.071428             4.440892e-16        0.0                 6.331811e-07                  0.0                    0.0                -1.0              -2.0   PASS
   quadratic              0.100                0.100           1.0                 0.142857     1.142857                      1.142857             1.998401e-15        0.0                 6.331811e-07                  0.0                    0.0                -1.0              -2.0   PASS
concentrated              0.000                0.000           1.0                 0.000000     1.000000                      1.000000             0.000000e+00        0.0                 0.000000e+00                  0.0                    0.0                -1.0              -2.0   PASS
concentrated              0.001                0.001           1.0                 0.001962     1.001962                      1.001962             8.881784e-16        0.0                 4.693072e-06                  0.0                    0.0                -1.0              -2.0   PASS
concentrated              0.010                0.010           1.0                 0.019621     1.019621                      1.019621             0.000000e+00        0.0                 4.693072e-06                  0.0                    0.0                -1.0              -2.0   PASS
concentrated              0.050                0.050           1.0                 0.098106     1.098106                      1.098106             1.110223e-15        0.0                 4.693072e-06                  0.0                    0.0                -1.0              -2.0   PASS
concentrated              0.100                0.100           1.0                 0.196211     1.196211                      1.196211             1.110223e-15        0.0                 4.693072e-06                  0.0                    0.0                -1.0              -2.0   PASS

## Representative enclosed-source table

          star_case  r_over_R  rho_set  pressure_p_over_c2  rho_ops  Q_ops_enclosed    g_ops  phi_ops
       uniform_w0_0      0.05 0.238732            0.000000 0.238732        0.000125 0.050002 1.498750
       uniform_w0_0      0.10 0.238732            0.000000 0.238732        0.001000 0.100001 1.495000
       uniform_w0_0      0.25 0.238732            0.000000 0.238732        0.015625 0.250000 1.468750
       uniform_w0_0      0.50 0.238732            0.000000 0.238732        0.125000 0.500000 1.375000
       uniform_w0_0      0.75 0.238732            0.000000 0.238732        0.421875 0.750000 1.218750
       uniform_w0_0      1.00 0.238732            0.000000 0.238732        1.000000 1.000000 1.000000
  quadratic_w0_0.05      0.05 0.595339            0.029655 0.684305        0.000359 0.143499 2.035472
  quadratic_w0_0.05      0.10 0.590863            0.029101 0.678167        0.002854 0.285444 2.024739
  quadratic_w0_0.05      0.25 0.559529            0.025408 0.635754        0.042927 0.686835 1.951220
  quadratic_w0_0.05      0.50 0.447623            0.014688 0.491686        0.297311 1.189244 1.711107
  quadratic_w0_0.05      0.75 0.261114            0.004105 0.273430        0.761662 1.354066 1.384863
  quadratic_w0_0.05      1.00 0.000000            0.000000 0.000000        1.071428 1.071428 1.071428
concentrated_w0_0.1      0.05 3.865340            0.384616 5.019187        0.002672 1.068869 3.379745
concentrated_w0_0.1      0.10 3.440139            0.337374 4.452260        0.019890 1.988983 3.302429
concentrated_w0_0.1      0.25 1.764673            0.158061 2.238855        0.204725 3.275598 2.880239
concentrated_w0_0.1      0.50 0.435266            0.030047 0.525406        0.665613 2.662453 2.109430
concentrated_w0_0.1      0.75 0.128714            0.005430 0.145004        0.996848 1.772175 1.561456
concentrated_w0_0.1      1.00 0.047933            0.000000 0.047933        1.196211 1.196211 1.196211

## Pressure boost law tests

     profile  linear_slope_d_boost_minus1_over_d_w0  linear_intercept  boost_at_w0_0p1                        status
concentrated                               1.962111      3.108719e-16         1.196211 PASS_MONOTONIC_PRESSURE_BOOST
   quadratic                               1.428566      3.578238e-16         1.142857 PASS_MONOTONIC_PRESSURE_BOOST
     uniform                               1.199997      1.474357e-16         1.120000 PASS_MONOTONIC_PRESSURE_BOOST

## Root-normalization shape tests

 kappa_root  Q_physical_proxy  exterior_phi_slope  exterior_g_slope  phi_at_r2   g_at_r2               status
       0.01          0.010714                -1.0              -2.0   0.005357  0.002679 PASS_SHAPE_INVARIANT
       0.10          0.107143                -1.0              -2.0   0.053571  0.026786 PASS_SHAPE_INVARIANT
       1.00          1.071428                -1.0              -2.0   0.535714  0.267857 PASS_SHAPE_INVARIANT
      10.00         10.714283                -1.0              -2.0   5.357141  2.678571 PASS_SHAPE_INVARIANT
     100.00        107.142828                -1.0              -2.0  53.571414 26.785707 PASS_SHAPE_INVARIANT

## Category guardrails

                                 case                                                                        description  body_level_multiplier                ruling                                                                               reason
          stellar_source_from_rho_ops                                 Star source is Q_ops = integral (rho + 3p/c^2) dV.               1.000000                  PASS                                                     Uses accumulated source density.
            whole_star_6pi_multiplier                Multiply star by V12.13 K_top = 6pi as a whole-body gravity factor.              18.849556 REJECT_CATEGORY_ERROR K_top is particle/top-sector terminal closure, not a macroscopic stellar multiplier.
choose_kappa_root_to_match_measured_G Use measured G to set absolute root normalization after the structural source law.                    NaN      CALIBRATION_ONLY             Calibration allowed only after structural bridge; not a derivation of G.
 insert_planck_area_before_source_law     Define the source law using Planck area/G before deriving source accumulation.                    NaN       REJECT_CIRCULAR                                        Would smuggle absolute gravity normalization.

## Claim boundary

                                                                                    claim  status                              safe_wording
R227M builds a synthetic stellar interior source skeleton using rho_set and rho + 3p/c^2. ALLOWED               toy stellar source skeleton
                      Exterior field depends on total Q_ops and retains phi~1/r, g~1/r^2. ALLOWED            normalized exterior source law
                                      Pressure contributes as 3p/c^2 to operation source. ALLOWED            pressure-channel compatibility
                                                                R227M derives Newton's G. BLOCKED         root/G normalization remains open
                                                     R227M solves real stellar structure. BLOCKED   synthetic hydrostatic toy profiles only
                                                      R227M validates against real stars. BLOCKED                no observed star data used
                                                             R227M derives a species map. BLOCKED         species-specific q_i remains open
                                            R227M applies 6pi as a whole-star multiplier. BLOCKED whole-star 6pi rejected as category error

## Open claims

                            open_item status                                                               description
        absolute root/G normalization   OPEN                        R227M keeps kappa_root separate; G is not derived.
               real equation of state   OPEN Pressure profiles are synthetic hydrostatic shapes, not real stellar EOS.
     full stellar structure equations   OPEN      No energy transport, opacity, nuclear burning, or stellar evolution.
       species q_i and binding energy   OPEN                            No electron/proton/neutron/binding source map.
relativistic compact-star corrections   OPEN                            Toy weak-field skeleton only; no TOV solution.
             observational validation   OPEN                               No observed star data or fitted parameters.

## Interpretation

R227M supports the stellar-source skeleton:

    rho_set is the cold matter-energy source in normalized units.
    rho_ops = rho_set + 3p/c^2 is the pressure-aware operation source.
    Q_ops(r) = integral_0^r 4pi r'^2 rho_ops(r') dr'
    g(r) = Q_ops(r)/r^2
    phi_ext(r) = Q_ops_total/r
    g_ext(r) = Q_ops_total/r^2

The exterior law depends on total Q_ops and preserves the weak-field slopes.
Root normalization changes amplitude, not shape.
Whole-star 6pi is rejected as a category error.

## Ruling

The q_i -> rho_set -> rho_ops -> stellar-source chain passes at synthetic skeleton level.
Absolute G/root normalization, real stellar structure, species/binding source map, compact-star corrections, and observational validation remain open.
