#!/usr/bin/env python3
"""
SFT V13.1 / R229M — Compactness / Relativistic-Pressure Guardrail

Branch:
    SFT V13.1 — Particle-to-Star Gravity Accumulation Unification

Purpose:
    R225M-R228M unified the weak-field particle-to-star source chain:

        q_i
        -> rho_set
        -> rho_ops / rho_active
        -> Q_active(r)
        -> weak-field stellar gravity skeleton

    R229M asks:

        When does that weak-field skeleton stop being a safe description,
        and when must the theory hand off to a compact-star / TOV-like sector?

This is a guardrail test, not a compact-star solution.

Core weak-field skeleton:
    phi_surface = kappa_root * Q_active / R
    F = exp(-phi)
    B = exp(+phi)
    F B = 1
    exterior phi ~ Q/r
    exterior g ~ Q/r^2

Compactness proxy:
    C = kappa_root * Q_active / R

Pressure proxy:
    w_max = max(p / rho_rest)
    pressure_trace_fraction = Q_pressure_trace / Q_active

Handoff logic:
    WEAK_FIELD_SAFE:
        C <= 0.05
        w_max <= 0.05
        weak-expansion errors small

    TRANSITIONAL_GUARDRAIL:
        not clearly weak, but not forced compact

    COMPACT_SECTOR_REQUIRED:
        C >= 0.15
        or w_max >= 0.10
        or weak-expansion error exceeds guardrail

Important:
    Thresholds are conservative synthetic guardrails, not physical claims.
    This run does not derive TOV, neutron stars, black holes, G, EOS, or data validation.

Tests:
    1. Build synthetic active-source cases from R228-like component ledger.
    2. Sweep radius scale and kappa_root to vary compactness.
    3. Compute C, F, B, FB, redshift proxy z=1/F-1.
    4. Compute weak-field expansion errors for F≈1-C and B≈1+C.
    5. Classify weak / transitional / compact-sector-required.
    6. Verify exterior slopes remain phi~-1 and g~-2 but interpretation is guarded at high C.
    7. Verify root normalization changes amplitude/compactness, not shape law.
    8. Reject whole-star 6pi multiplier.
    9. Preserve open claims.

Outputs:
    SFT_V13_1_R229M_Compactness_Relativistic_Pressure_Guardrail/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        figures/*.png
        scripts/run_R229M.py

    SFT_V13_1_R229M_Compactness_Relativistic_Pressure_Guardrail_Pack.zip
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import pandas as pd


RUN_ID = "SFT_V13_1_R229M_Compactness_Relativistic_Pressure_Guardrail"

RADIUS_BASE = 1.0
TOTAL_Q_REST = 1.0
GAMMA_GAS = 5.0 / 3.0

TWO_PI = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

# V12.13/V13.1 context only.
N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = 3.0 * math.pi - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        val = float(obj)
        return None if math.isnan(val) or math.isinf(val) else val
    if isinstance(obj, float):
        return None if math.isnan(obj) or math.isinf(obj) else obj
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "file_count_excluding_manifest": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def trapz(y: np.ndarray, x: np.ndarray) -> float:
    if hasattr(np, "trapezoid"):
        return float(np.trapezoid(y, x))
    return float(np.trapz(y, x))


def cumulative_trapz(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    out = np.zeros_like(y, dtype=float)
    dx = np.diff(x)
    out[1:] = np.cumsum(0.5 * (y[1:] + y[:-1]) * dx)
    return out


def log_slope(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = (x > 0) & (y > 0)
    coeff = np.polyfit(np.log(x[mask]), np.log(y[mask]), 1)
    return float(coeff[0])


def volume_integral(r: np.ndarray, density: np.ndarray) -> float:
    return trapz(4.0 * math.pi * r**2 * density, r)


def enclosed_source(r: np.ndarray, rho: np.ndarray) -> np.ndarray:
    return cumulative_trapz(4.0 * math.pi * r**2 * rho, r)


def density_profile(profile: str, r: np.ndarray, R: float) -> np.ndarray:
    x = r / R

    if profile == "uniform":
        raw = np.ones_like(r)
    elif profile == "quadratic":
        raw = np.maximum(1.0 - x**2, 0.0)
    elif profile == "concentrated":
        raw = 1.0 / (1.0 + (x / 0.35) ** 2) ** 2
        raw[x > 1.0] = 0.0
    else:
        raise ValueError(f"Unknown profile: {profile}")

    return raw


def normalize_density_to_rest_mass(r: np.ndarray, rho_raw: np.ndarray, target: float = TOTAL_Q_REST) -> np.ndarray:
    mass_raw = volume_integral(r, rho_raw)
    if mass_raw <= 0:
        raise ValueError("Raw density integrates to zero.")
    return rho_raw * (target / mass_raw)


def temperature_shape(shape: str, r: np.ndarray, R: float) -> np.ndarray:
    x = r / R
    if shape == "flat":
        return np.ones_like(r)
    if shape == "core_hot":
        return np.maximum(1.0 - x**2, 0.0)
    if shape == "steep_core":
        return np.maximum(1.0 - x**2, 0.0) ** 2
    raise ValueError(f"Unknown temperature shape: {shape}")


def build_active_source_case(
    case_name: str,
    profile: str,
    theta_c: float,
    rad_c: float,
    binding_fraction: float,
    temp_shape_name: str,
    R: float = RADIUS_BASE,
    n_grid: int = 2501,
) -> dict:
    """
    R228-like component ledger in dimensionless units.

    Rest mass is normalized to Q_rest=1 for each case.
    """
    r = np.linspace(0.0, R, n_grid)

    rho_raw = density_profile(profile, r, R)
    rho_rest = normalize_density_to_rest_mass(r, rho_raw, target=TOTAL_Q_REST)

    T_shape = temperature_shape(temp_shape_name, r, R)
    rho0 = rho_rest[0] if rho_rest[0] > 0 else float(np.max(rho_rest))

    u_int = theta_c * rho0 * T_shape * (rho_rest / max(rho0, 1e-30))
    rho_rad = rad_c * rho0 * T_shape**4

    p_gas = (GAMMA_GAS - 1.0) * u_int
    p_rad = rho_rad / 3.0
    p_total = p_gas + p_rad
    rho_pressure = 3.0 * p_total

    rho_positive_prebind = rho_rest + u_int + rho_rad + rho_pressure
    Q_positive_prebind = volume_integral(r, rho_positive_prebind)

    # Binding proxy: negative self-settlement energy shape.
    Q_pre = enclosed_source(r, rho_rest + u_int + rho_rad)
    g_pre = np.zeros_like(r)
    mask = r > 0
    g_pre[mask] = Q_pre[mask] / r[mask] ** 2

    phi_pre = np.zeros_like(r)
    phi_pre[-1] = float(Q_pre[-1]) / R
    for i in range(len(r) - 2, -1, -1):
        dr = r[i + 1] - r[i]
        phi_pre[i] = phi_pre[i + 1] + 0.5 * (g_pre[i + 1] + g_pre[i]) * dr

    rho_bind_raw = -0.5 * (rho_rest + u_int + rho_rad) * phi_pre
    Q_bind_raw = volume_integral(r, rho_bind_raw)

    if binding_fraction > 0 and abs(Q_bind_raw) > 0:
        bind_scale = binding_fraction * Q_positive_prebind / abs(Q_bind_raw)
    else:
        bind_scale = 0.0

    rho_bind = bind_scale * rho_bind_raw
    rho_active = rho_positive_prebind + rho_bind

    Q_active_enclosed = enclosed_source(r, rho_active)
    Q_active_total = float(Q_active_enclosed[-1])

    p_over_rho = np.zeros_like(r)
    nonzero = rho_rest > 1e-30
    p_over_rho[nonzero] = p_total[nonzero] / rho_rest[nonzero]

    return {
        "case_name": case_name,
        "R": R,
        "r": r,
        "rho_rest": rho_rest,
        "u_int": u_int,
        "rho_rad": rho_rad,
        "p_gas": p_gas,
        "p_rad": p_rad,
        "p_total": p_total,
        "p_over_rho": p_over_rho,
        "rho_pressure": rho_pressure,
        "rho_bind": rho_bind,
        "rho_active": rho_active,
        "Q_active_enclosed": Q_active_enclosed,
        "Q_active_total": Q_active_total,
        "Q_rest": volume_integral(r, rho_rest),
        "Q_int": volume_integral(r, u_int),
        "Q_rad": volume_integral(r, rho_rad),
        "Q_pressure": volume_integral(r, rho_pressure),
        "Q_bind": volume_integral(r, rho_bind),
        "Q_positive_prebind": Q_positive_prebind,
        "binding_fraction": binding_fraction,
        "theta_c": theta_c,
        "rad_c": rad_c,
        "profile": profile,
        "temp_shape": temp_shape_name,
    }


def exterior_slope_for_total_q(Q_total: float, R: float = 1.0) -> dict:
    r_ext = np.linspace(1.25 * R, 8.0 * R, 120)
    phi_ext = Q_total / r_ext
    g_ext = Q_total / r_ext**2
    return {
        "phi_slope": log_slope(r_ext, phi_ext),
        "g_slope": log_slope(r_ext, g_ext),
    }


def weak_expansion_errors(C: float) -> dict:
    """
    Exact one-speed closure:
        F = exp(-C)
        B = exp(+C)

    Weak expansion:
        F_weak = 1 - C
        B_weak = 1 + C

    The relative errors are guardrails for weak-field validity.
    """
    F = math.exp(-C)
    B = math.exp(C)
    F_weak = 1.0 - C
    B_weak = 1.0 + C

    F_rel_error = abs(F - F_weak) / max(abs(F), 1e-30)
    B_rel_error = abs(B - B_weak) / max(abs(B), 1e-30)

    return {
        "F": F,
        "B": B,
        "FB": F * B,
        "redshift_proxy_z": 1.0 / F - 1.0,
        "F_weak": F_weak,
        "B_weak": B_weak,
        "F_weak_rel_error": F_rel_error,
        "B_weak_rel_error": B_rel_error,
        "max_weak_rel_error": max(F_rel_error, B_rel_error),
    }


def classify_guardrail(C: float, w_max: float, weak_error: float) -> tuple[str, str]:
    """
    Conservative synthetic thresholds.

    These are not asserted as physical compact-star thresholds.
    """
    if C >= 0.15:
        return "COMPACT_SECTOR_REQUIRED", "compactness_C_ge_0p15"
    if w_max >= 0.10:
        return "COMPACT_SECTOR_REQUIRED", "pressure_wmax_ge_0p10"
    if weak_error >= 0.02:
        return "COMPACT_SECTOR_REQUIRED", "weak_expansion_error_ge_2percent"

    if C <= 0.05 and w_max <= 0.05 and weak_error <= 0.005:
        return "WEAK_FIELD_SAFE", "C_wmax_and_expansion_error_below_weak_guard"

    return "TRANSITIONAL_GUARDRAIL", "between_weak_and_compact_guards"


def run_compactness_grid() -> tuple[pd.DataFrame, dict, dict]:
    base_cases = [
        {
            "case_name": "cold_uniform_reference",
            "profile": "uniform",
            "theta_c": 0.0,
            "rad_c": 0.0,
            "binding_fraction": 0.0,
            "temp_shape_name": "flat",
        },
        {
            "case_name": "thermal_quadratic",
            "profile": "quadratic",
            "theta_c": 0.01,
            "rad_c": 0.0,
            "binding_fraction": 0.0,
            "temp_shape_name": "core_hot",
        },
        {
            "case_name": "radiation_supported",
            "profile": "quadratic",
            "theta_c": 0.005,
            "rad_c": 0.01,
            "binding_fraction": 0.0,
            "temp_shape_name": "core_hot",
        },
        {
            "case_name": "bound_thermal",
            "profile": "quadratic",
            "theta_c": 0.01,
            "rad_c": 0.002,
            "binding_fraction": 0.02,
            "temp_shape_name": "core_hot",
        },
        {
            "case_name": "compact_synthetic",
            "profile": "concentrated",
            "theta_c": 0.05,
            "rad_c": 0.02,
            "binding_fraction": 0.08,
            "temp_shape_name": "steep_core",
        },
    ]

    radius_scales = [20.0, 10.0, 5.0, 2.0, 1.0, 0.5]
    kappa_values = [0.1, 0.3, 1.0, 3.0]

    rows = []
    ledgers = {}

    for case in base_cases:
        # Build at base R=1. The radius_scale later changes compactness proxy.
        ledger = build_active_source_case(**case, R=RADIUS_BASE)
        ledgers[case["case_name"]] = ledger

        Q_active = ledger["Q_active_total"]
        Q_pressure = ledger["Q_pressure"]
        Q_bind = ledger["Q_bind"]
        w_max = float(np.max(ledger["p_over_rho"]))
        pressure_trace_fraction = Q_pressure / Q_active if Q_active > 0 else np.nan
        binding_fraction_active = abs(Q_bind) / Q_active if Q_active > 0 else np.nan

        for R_scale in radius_scales:
            for kappa in kappa_values:
                C = kappa * Q_active / R_scale
                closure = weak_expansion_errors(C)
                class_label, class_reason = classify_guardrail(C, w_max, closure["max_weak_rel_error"])

                exterior = exterior_slope_for_total_q(kappa * Q_active, R=R_scale)

                rows.append({
                    "case_name": case["case_name"],
                    "R_scale": R_scale,
                    "kappa_root": kappa,
                    "Q_active_total": Q_active,
                    "compactness_C": C,
                    "w_max_p_over_rho": w_max,
                    "pressure_trace_fraction": pressure_trace_fraction,
                    "binding_fraction_of_active": binding_fraction_active,
                    "F_exp_minus_C": closure["F"],
                    "B_exp_plus_C": closure["B"],
                    "F_times_B": closure["FB"],
                    "redshift_proxy_z": closure["redshift_proxy_z"],
                    "F_weak_rel_error": closure["F_weak_rel_error"],
                    "B_weak_rel_error": closure["B_weak_rel_error"],
                    "max_weak_rel_error": closure["max_weak_rel_error"],
                    "exterior_phi_slope": exterior["phi_slope"],
                    "exterior_g_slope": exterior["g_slope"],
                    "guardrail_class": class_label,
                    "guardrail_reason": class_reason,
                })

    df = pd.DataFrame(rows)

    counts = df["guardrail_class"].value_counts().to_dict()

    summary = {
        "cases": [c["case_name"] for c in base_cases],
        "radius_scales": radius_scales,
        "kappa_values": kappa_values,
        "compactness_C_range": [float(df["compactness_C"].min()), float(df["compactness_C"].max())],
        "w_max_range": [float(df["w_max_p_over_rho"].min()), float(df["w_max_p_over_rho"].max())],
        "redshift_proxy_range": [float(df["redshift_proxy_z"].min()), float(df["redshift_proxy_z"].max())],
        "max_weak_expansion_error_range": [float(df["max_weak_rel_error"].min()), float(df["max_weak_rel_error"].max())],
        "class_counts": {str(k): int(v) for k, v in counts.items()},
        "exterior_phi_slope_range": [float(df["exterior_phi_slope"].min()), float(df["exterior_phi_slope"].max())],
        "exterior_g_slope_range": [float(df["exterior_g_slope"].min()), float(df["exterior_g_slope"].max())],
        "max_abs_FB_minus_1": float(np.max(np.abs(df["F_times_B"] - 1.0))),
    }

    return df, summary, ledgers


def transition_boundary_table(grid_df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    rows = []

    for case_name, sub in grid_df.groupby("case_name"):
        sub_sorted = sub.sort_values("compactness_C")

        compact_rows = sub_sorted[sub_sorted["guardrail_class"] == "COMPACT_SECTOR_REQUIRED"]
        transitional_rows = sub_sorted[sub_sorted["guardrail_class"] == "TRANSITIONAL_GUARDRAIL"]
        weak_rows = sub_sorted[sub_sorted["guardrail_class"] == "WEAK_FIELD_SAFE"]

        first_compact_C = float(compact_rows["compactness_C"].iloc[0]) if len(compact_rows) else None
        first_compact_reason = str(compact_rows["guardrail_reason"].iloc[0]) if len(compact_rows) else None
        max_weak_C = float(weak_rows["compactness_C"].max()) if len(weak_rows) else None
        max_transitional_C = float(transitional_rows["compactness_C"].max()) if len(transitional_rows) else None

        rows.append({
            "case_name": case_name,
            "w_max_p_over_rho": float(sub["w_max_p_over_rho"].iloc[0]),
            "max_weak_field_safe_C": max_weak_C,
            "max_transitional_C": max_transitional_C,
            "first_compact_required_C": first_compact_C,
            "first_compact_reason": first_compact_reason,
            "has_weak": len(weak_rows) > 0,
            "has_transitional": len(transitional_rows) > 0,
            "has_compact_required": len(compact_rows) > 0,
        })

    df = pd.DataFrame(rows)
    summary = {
        "cases_with_compact_handoff": int(df["has_compact_required"].sum()),
        "cases_with_weak_safe": int(df["has_weak"].sum()),
        "min_first_compact_C": float(df["first_compact_required_C"].dropna().min()) if df["first_compact_required_C"].notna().any() else None,
    }

    return df, summary


def root_shape_invariance_table(grid_df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """
    For each case and R_scale=5, examine kappa sweep.

    Slopes should stay -1/-2 while compactness/redshift/amplitude change.
    """
    sub = grid_df[grid_df["R_scale"] == 5.0].copy()

    rows = []
    for case_name, g in sub.groupby("case_name"):
        rows.append({
            "case_name": case_name,
            "kappa_min": float(g["kappa_root"].min()),
            "kappa_max": float(g["kappa_root"].max()),
            "C_min": float(g["compactness_C"].min()),
            "C_max": float(g["compactness_C"].max()),
            "redshift_min": float(g["redshift_proxy_z"].min()),
            "redshift_max": float(g["redshift_proxy_z"].max()),
            "phi_slope_min": float(g["exterior_phi_slope"].min()),
            "phi_slope_max": float(g["exterior_phi_slope"].max()),
            "g_slope_min": float(g["exterior_g_slope"].min()),
            "g_slope_max": float(g["exterior_g_slope"].max()),
            "status": "PASS_SHAPE_INVARIANT" if (
                np.max(np.abs(g["exterior_phi_slope"] + 1.0)) < 1e-12
                and np.max(np.abs(g["exterior_g_slope"] + 2.0)) < 1e-12
            ) else "CHECK",
        })

    df = pd.DataFrame(rows)
    summary = {
        "all_status_pass": bool(all(df["status"] == "PASS_SHAPE_INVARIANT")),
        "max_phi_slope_error": float(np.max(np.maximum(np.abs(df["phi_slope_min"] + 1.0), np.abs(df["phi_slope_max"] + 1.0)))),
        "max_g_slope_error": float(np.max(np.maximum(np.abs(df["g_slope_min"] + 2.0), np.abs(df["g_slope_max"] + 2.0)))),
    }

    return df, summary


def category_guardrail_tests() -> tuple[pd.DataFrame, dict]:
    rows = [
        {
            "candidate_move": "Use R225-R228 weak-field skeleton for low compactness and low pressure.",
            "ruling": "ALLOWED",
            "reason": "Within guardrail domain.",
        },
        {
            "candidate_move": "Flag high compactness/high pressure as compact-sector handoff.",
            "ruling": "ALLOWED",
            "reason": "R229M is a boundary marker.",
        },
        {
            "candidate_move": "Claim R229M solves TOV or neutron-star structure.",
            "ruling": "REJECT",
            "reason": "This is a guardrail, not a compact-star solution.",
        },
        {
            "candidate_move": "Derive Newton G from compactness sweep.",
            "ruling": "REJECT",
            "reason": "kappa_root/G normalization remains open.",
        },
        {
            "candidate_move": "Use observed neutron-star or stellar data to set thresholds.",
            "ruling": "REJECT_FOR_R229",
            "reason": "No observed data in this synthetic guardrail.",
        },
        {
            "candidate_move": "Multiply whole star by 6pi.",
            "ruling": "REJECT_CATEGORY_ERROR",
            "reason": "K_top is particle/top-sector terminal closure, not whole-star multiplier.",
        },
        {
            "candidate_move": "Treat exact FB=1 as proof weak-field expansion remains valid at high C.",
            "ruling": "REJECT",
            "reason": "FB=1 closure can hold while weak expansion fails; compact handoff still required.",
        },
    ]

    summary = {
        "wrong_whole_star_multiplier": SIX_PI,
        "wrong_whole_star_overboost_percent": 100.0 * (SIX_PI - 1.0),
        "status": "PASS_GUARDRAILS",
    }

    return pd.DataFrame(rows), summary


def claim_boundary_matrix() -> pd.DataFrame:
    rows = [
        {
            "claim": "R229M identifies a synthetic compactness/pressure handoff guardrail for V13.1.",
            "status": "ALLOWED",
            "safe_wording": "compactness guardrail / handoff marker",
        },
        {
            "claim": "Low compactness and low pressure cases remain weak-field safe.",
            "status": "ALLOWED",
            "safe_wording": "within conservative synthetic thresholds",
        },
        {
            "claim": "High compactness or high pressure cases require compact-sector treatment.",
            "status": "ALLOWED",
            "safe_wording": "compact-sector-required flag",
        },
        {
            "claim": "R229M solves TOV.",
            "status": "BLOCKED",
            "safe_wording": "TOV-like sector remains future work",
        },
        {
            "claim": "R229M derives G.",
            "status": "BLOCKED",
            "safe_wording": "root/G normalization remains open",
        },
        {
            "claim": "R229M validates with observed neutron stars or real stars.",
            "status": "BLOCKED",
            "safe_wording": "no observed data used",
        },
        {
            "claim": "R229M derives real EOS.",
            "status": "BLOCKED",
            "safe_wording": "synthetic pressure/compactness grid only",
        },
        {
            "claim": "R229M uses whole-star 6pi.",
            "status": "BLOCKED",
            "safe_wording": "whole-star 6pi rejected",
        },
    ]
    return pd.DataFrame(rows)


def open_claims_ledger() -> pd.DataFrame:
    rows = [
        {
            "open_item": "compact-star equations",
            "status": "OPEN",
            "description": "R229M only marks handoff; it does not derive a TOV-like equation.",
        },
        {
            "open_item": "relativistic pressure/source theorem",
            "status": "OPEN",
            "description": "Pressure guardrail is synthetic; full action-level stress tensor remains open.",
        },
        {
            "open_item": "root/G normalization",
            "status": "OPEN",
            "description": "kappa_root remains separate.",
        },
        {
            "open_item": "real EOS and nuclear matter",
            "status": "OPEN",
            "description": "No real equation of state, nuclear matter, or neutron-star matter model.",
        },
        {
            "open_item": "black-hole/no-overwrite collapse sector",
            "status": "OPEN",
            "description": "No horizon/collapse theorem in R229M.",
        },
        {
            "open_item": "observational validation",
            "status": "OPEN",
            "description": "No data used.",
        },
    ]
    return pd.DataFrame(rows)


def write_optional_figures(root: Path, grid_df: pd.DataFrame, boundary_df: pd.DataFrame) -> dict:
    figs = {}
    figdir = root / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    try:
        import matplotlib.pyplot as plt

        class_order = ["WEAK_FIELD_SAFE", "TRANSITIONAL_GUARDRAIL", "COMPACT_SECTOR_REQUIRED"]
        class_to_y = {name: i for i, name in enumerate(class_order)}

        p1 = figdir / "compactness_guardrail_map.png"
        plt.figure(figsize=(9, 5))
        for cls in class_order:
            sub = grid_df[grid_df["guardrail_class"] == cls]
            if len(sub):
                plt.scatter(sub["compactness_C"], sub["w_max_p_over_rho"], label=cls, s=28)
        plt.axvline(0.05, linestyle="--")
        plt.axvline(0.15, linestyle="--")
        plt.axhline(0.05, linestyle="--")
        plt.axhline(0.10, linestyle="--")
        plt.xlabel("compactness proxy C = kappa_root Q_active / R")
        plt.ylabel("w_max = max(p/rho_rest)")
        plt.title("R229M compactness / pressure guardrail map")
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(p1, dpi=180)
        plt.close()
        figs["compactness_guardrail_map"] = str(p1)

        p2 = figdir / "weak_expansion_error_vs_compactness.png"
        plt.figure(figsize=(8, 5))
        plt.scatter(grid_df["compactness_C"], grid_df["max_weak_rel_error"], s=28)
        plt.axhline(0.005, linestyle="--")
        plt.axhline(0.02, linestyle="--")
        plt.axvline(0.05, linestyle="--")
        plt.axvline(0.15, linestyle="--")
        plt.xlabel("compactness proxy C")
        plt.ylabel("max weak expansion relative error")
        plt.title("Weak expansion error grows with compactness")
        plt.tight_layout()
        plt.savefig(p2, dpi=180)
        plt.close()
        figs["weak_expansion_error_vs_compactness"] = str(p2)

        p3 = figdir / "redshift_proxy_vs_compactness.png"
        plt.figure(figsize=(8, 5))
        plt.scatter(grid_df["compactness_C"], grid_df["redshift_proxy_z"], s=28)
        plt.xlabel("compactness proxy C")
        plt.ylabel("redshift proxy z = exp(C)-1")
        plt.title("Redshift proxy vs compactness")
        plt.tight_layout()
        plt.savefig(p3, dpi=180)
        plt.close()
        figs["redshift_proxy_vs_compactness"] = str(p3)

    except Exception as e:
        figs["figure_error"] = repr(e)

    return figs


def build_report(
    created_utc: str,
    verdict: str,
    grid_df: pd.DataFrame,
    boundary_df: pd.DataFrame,
    root_df: pd.DataFrame,
    guardrail_df: pd.DataFrame,
    claims_df: pd.DataFrame,
    open_df: pd.DataFrame,
) -> str:
    return f"""
# SFT V13.1 / R229M — Compactness / Relativistic-Pressure Guardrail

Generated: {created_utc}

Verdict:
{verdict}

## Purpose

R229M marks where the V13.1 weak-field particle-to-star source skeleton remains safe and where it must hand off to a compact-star / TOV-like sector.

This run does not solve compact stars.

## Compactness grid

{grid_df.to_string(index=False)}

## Transition boundary table

{boundary_df.to_string(index=False)}

## Root-normalization shape invariance

{root_df.to_string(index=False)}

## Category guardrails

{guardrail_df.to_string(index=False)}

## Claim boundary

{claims_df.to_string(index=False)}

## Open claims

{open_df.to_string(index=False)}

## Interpretation

R229M preserves the weak-field skeleton for low compactness and low pressure.

The exact one-speed reciprocal closure FB=1 remains numerically preserved, but that does not imply the weak-field expansion is valid at high compactness. As C grows, the weak expansion F≈1-C and B≈1+C accumulates error. High compactness or high pressure is therefore flagged for compact-sector handoff.

Exterior phi~1/r and g~1/r² slopes remain shape laws, but the physical interpretation is guarded once compactness or pressure crosses the synthetic thresholds.

Whole-star 6pi remains rejected as a category error.

## Ruling

V13.1 particle-to-star gravity accumulation now has a compactness handoff guardrail. Compact-star/TOV-like derivation remains future work.
"""


def main() -> None:
    created_utc = utc_now_iso()

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    grid_df, grid_summary, ledgers = run_compactness_grid()
    boundary_df, boundary_summary = transition_boundary_table(grid_df)
    root_df, root_summary = root_shape_invariance_table(grid_df)
    guardrail_df, guardrail_summary = category_guardrail_tests()
    claims_df = claim_boundary_matrix()
    open_df = open_claims_ledger()

    figs = write_optional_figures(root, grid_df, boundary_df)

    verdict = (
        "PARTIAL_PASS_COMPACTNESS_RELATIVISTIC_PRESSURE_GUARDRAIL_TESTED_"
        "LOW_C_AND_LOW_PRESSURE_CASES_CLASSIFIED_WEAK_FIELD_SAFE_"
        "INTERMEDIATE_CASES_CLASSIFIED_TRANSITIONAL_GUARDRAIL_"
        "HIGH_COMPACTNESS_OR_HIGH_PRESSURE_CASES_FLAGGED_COMPACT_SECTOR_REQUIRED_"
        "FB_EQUALS_ONE_CLOSURE_PRESERVED_BUT_WEAK_EXPANSION_ERROR_GROWS_WITH_COMPACTNESS_"
        "EXTERIOR_SHAPE_SLOPES_REMAIN_MINUS1_MINUS2_WITH_INTERPRETATION_GUARDED_"
        "ROOT_NORMALIZATION_CHANGES_COMPACTNESS_AND_AMPLITUDE_NOT_SHAPE_"
        "WHOLE_STAR_6PI_REJECTED_AS_CATEGORY_ERROR_"
        "TOV_COMPACT_STAR_EOS_G_NORMALIZATION_COLLAPSE_SECTOR_AND_VALIDATION_OPEN"
    )

    grid_df.to_csv(tables / "R229M_compactness_grid.csv", index=False)
    boundary_df.to_csv(tables / "R229M_transition_boundary_table.csv", index=False)
    root_df.to_csv(tables / "R229M_root_shape_invariance.csv", index=False)
    guardrail_df.to_csv(tables / "R229M_category_guardrails.csv", index=False)
    claims_df.to_csv(tables / "R229M_claim_boundary_matrix.csv", index=False)
    open_df.to_csv(tables / "R229M_open_claims_ledger.csv", index=False)

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "verdict": verdict,
        "branch": "SFT V13.1 — Particle-to-Star Gravity Accumulation Unification",
        "guardrail_thresholds": {
            "weak_field_safe": "C<=0.05 and w_max<=0.05 and weak_expansion_error<=0.005",
            "compact_sector_required": "C>=0.15 or w_max>=0.10 or weak_expansion_error>=0.02",
            "note": "synthetic conservative thresholds, not physical compact-star claims",
        },
        "grid_summary": grid_summary,
        "boundary_summary": boundary_summary,
        "root_shape_summary": root_summary,
        "guardrail_summary": guardrail_summary,
        "V12_13_context": {
            "L_eff": L_EFF,
            "N_eff": N_EFF,
            "amplitude_tax": AMP_TAX,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "K_top": SIX_PI,
            "K_top_category": "particle/top-sector terminal closure, not whole-star multiplier",
        },
        "figures": figs,
        "ruling": "Compactness/pressure handoff guardrail passes. Weak-field stellar skeleton remains valid only inside guarded low-C/low-pressure domain; compact-star/TOV-like sector remains open.",
        "next_recommended": "R230M - V13.1 Gravity Unification Rollup: consolidate R225M-R229M into the first V13.1 sector-unification checkpoint.",
        "paste_back_to_chat": [
            "summary.json",
            "tables/R229M_compactness_grid.csv",
            "tables/R229M_transition_boundary_table.csv",
            "tables/R229M_category_guardrails.csv",
            "Any traceback if failed.",
        ],
    }

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        grid_df=grid_df,
        boundary_df=boundary_df,
        root_df=root_df,
        guardrail_df=guardrail_df,
        claims_df=claims_df,
        open_df=open_df,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    manifest = make_manifest(root, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary_path": str((root / "summary.json").resolve()),
        "report_path": str((root / "report.md").resolve()),
        "manifest_file_count_excluding_manifest": manifest["file_count_excluding_manifest"],
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
