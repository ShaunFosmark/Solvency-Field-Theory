#!/usr/bin/env python3
"""
SFT V13.1 / R230M — Gravity Accumulation Unification Rollup

Branch:
    SFT V13.1 — Particle-to-Star Gravity Accumulation Unification

Purpose:
    Consolidate R225M-R229M into the first V13.1 sector-unification checkpoint.

This is a rollup / freeze checkpoint, not a new derivation.

Inputs:
    Optional local run packs or directories for:

        R225M Particle-to-Star Settlement Accumulation
        R226M Particle Source Density Normalization Bridge
        R227M Real Stellar Source Skeleton
        R228M Binding/Internal-Energy Source Accounting
        R229M Compactness/Relativistic-Pressure Guardrail

    If matching summary.json files are present in folders or ZIP packs, this script
    ingests them. If not, it uses the locked pasted summary values as fallback.

Outputs:
    SFT_V13_1_R230M_Gravity_Accumulation_Unification_Rollup/
        report.md
        summary.json
        manifest.json
        tables/*.csv
        scripts/run_R230M.py

    SFT_V13_1_R230M_Gravity_Accumulation_Unification_Rollup_Pack.zip

Claim boundary:
    - V13.1 unifies the particle-to-star gravity accumulation sector structurally.
    - It does not derive G.
    - It does not solve compact stars / TOV.
    - It does not derive real EOS.
    - It does not derive species-specific q_i.
    - It does not validate against observed stars.
    - It does not apply 6π as a whole-star multiplier.
"""

from __future__ import annotations

from pathlib import Path
import datetime as dt
import hashlib
import json
import math
import shutil
import zipfile
from typing import Any

import pandas as pd


RUN_ID = "SFT_V13_1_R230M_Gravity_Accumulation_Unification_Rollup"
BRANCH = "SFT V13.1 — Particle-to-Star Gravity Accumulation Unification"

TWO_PI = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = 3.0 * math.pi - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)

EXPECTED_RUN_KEYS = ["R225M", "R226M", "R227M", "R228M", "R229M"]


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "file_count_excluding_manifest": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def load_json_file(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def find_summary_jsons(search_root: Path) -> dict[str, dict]:
    """
    Find summary.json files in directories and ZIP packs.

    Search strategy:
        1. recursive summary.json files
        2. ZIP files containing */summary.json

    Returns:
        dict keyed by R225M/R226M/... when recognized.
    """
    found: dict[str, dict] = {}

    # Directory summaries.
    for path in search_root.rglob("summary.json"):
        data = load_json_file(path)
        if not isinstance(data, dict):
            continue
        run_id = str(data.get("run_id", ""))
        for key in EXPECTED_RUN_KEYS:
            if key in run_id and key not in found:
                data["_source_path"] = str(path)
                found[key] = data

    # ZIP summaries.
    for zip_path in search_root.rglob("*.zip"):
        try:
            with zipfile.ZipFile(zip_path, "r") as z:
                names = [n for n in z.namelist() if n.endswith("summary.json")]
                for name in names:
                    try:
                        data = json.loads(z.read(name).decode("utf-8"))
                    except Exception:
                        continue
                    if not isinstance(data, dict):
                        continue
                    run_id = str(data.get("run_id", ""))
                    for key in EXPECTED_RUN_KEYS:
                        if key in run_id and key not in found:
                            data["_source_path"] = f"{zip_path}::{name}"
                            found[key] = data
        except Exception:
            continue

    return found


def fallback_summaries() -> dict[str, dict]:
    """
    Locked fallback from pasted R225M-R229M summaries.
    Used only if local summaries are not present.
    """
    return {
        "R225M": {
            "run_id": "SFT_V12_13_R225M_Particle_to_Star_Settlement_Accumulation_Test",
            "verdict": "PARTIAL_PASS_PARTICLE_TO_STAR_SETTLEMENT_ACCUMULATION_UNIFICATION_SKELETON_TESTED_CONTINUUM_ACCUMULATION_RECOVERS_WEAK_FIELD_SPHERE_BEHAVIOR_PARTICLE_CLOUD_CONVERGES_TO_CONTINUUM_EXTERIOR_FIELD_RANDOM_DIRECTIONAL_SETTLEMENT_CANCELS_WHILE_COHERENT_DIRECTION_SURVIVES_ONE_SPEED_CLOSURE_PRESERVED_OPERATION_DENSITY_PRESSURE_CHANNEL_COMPATIBLE_WHOLE_STAR_6PI_MULTIPLIER_REJECTED_AS_CATEGORY_ERROR_G_NORMALIZATION_SPECIES_MAP_REAL_STELLAR_STRUCTURE_AND_VALIDATION_OPEN",
            "ruling": "Particle-to-star gravity accumulation skeleton passes synthetic structural tests; major physical normalization and species/stellar modeling remain open.",
            "key_results": {
                "continuum_exterior_phi_slope": -1.0,
                "continuum_exterior_g_slope": -2.0,
                "continuum_interior_g_slope": 1.0,
                "particle_cloud_N": 8000,
                "particle_cloud_phi_rms": 0.0017872121975177169,
                "particle_cloud_g_rms": 0.004472888658953605,
                "directional_cancellation_slope": -0.4885574516632885,
                "max_FB_error": 1.1102230246251565e-16,
                "whole_star_6pi_overboost_percent": 1784.9555921538758,
            },
            "_source_path": "fallback_locked_from_chat",
        },
        "R226M": {
            "run_id": "SFT_V12_13_R226M_Particle_Source_Density_Normalization_Bridge",
            "verdict": "PARTIAL_PASS_PARTICLE_SOURCE_DENSITY_NORMALIZATION_BRIDGE_TESTED_QI_DEFINED_AS_NORMALIZED_MAINTAINED_CLOSURE_DEMAND_RHO_SET_EQUALS_SUM_QI_DELTA_COARSE_GRAINS_TO_CONTINUUM_SOURCE_ADDITIVITY_AND_COARSE_GRAINING_PASS_EXTERIOR_FIELD_DEPENDS_ON_TOTAL_Q_ROOT_NORMALIZATION_CHANGES_AMPLITUDE_NOT_SHAPE_OPERATION_DENSITY_PRESSURE_CHANNEL_COMPATIBLE_DIRECTIONAL_RANDOM_CANCELLATION_PRESERVED_G_DERIVATION_SPECIES_MAP_REAL_STELLAR_STRUCTURE_AND_VALIDATION_OPEN",
            "ruling": "q_i to rho_set source bridge passes in normalized units; G/root normalization and species map remain open.",
            "key_results": {
                "max_total_q_error": 2.220446049250313e-16,
                "coarse_graining_N": 30000,
                "shell_density_rms_error": 0.034186973439244456,
                "uniform_phi_slope": -1.0006059609943383,
                "uniform_g_slope": -2.0015198501911455,
                "concentrated_phi_slope": -0.9980414994525572,
                "concentrated_g_slope": -1.9952637973113767,
                "root_shape_invariance": "PASS",
                "directional_equal_q_slope": -0.4994754033806399,
                "directional_weighted_q_slope": -0.4972898801320751,
            },
            "_source_path": "fallback_locked_from_chat",
        },
        "R227M": {
            "run_id": "SFT_V12_13_R227M_Real_Stellar_Source_Skeleton",
            "verdict": "PARTIAL_PASS_REAL_STELLAR_SOURCE_SKELETON_TESTED_RHO_SET_TO_RHO_OPS_EQUALS_RHO_PLUS_3P_OVER_C2_CHAIN_PRESERVED_HYDROSTATIC_TOY_PRESSURE_SHAPES_GENERATE_MONOTONIC_PRESSURE_SOURCE_BOOST_ENCLOSED_Q_OPS_DRIVES_INTERIOR_FIELD_EXTERIOR_FIELD_DEPENDS_ON_TOTAL_Q_OPS_EXTERIOR_PHI_MINUS1_AND_G_MINUS2_SLOPES_PRESERVED_SURFACE_CONTINUITY_PASSES_ROOT_NORMALIZATION_CHANGES_AMPLITUDE_NOT_SHAPE_WHOLE_STAR_6PI_REJECTED_AS_CATEGORY_ERROR_G_NORMALIZATION_REAL_STELLAR_STRUCTURE_SPECIES_BINDING_MAP_COMPACT_STAR_CORRECTIONS_AND_VALIDATION_OPEN",
            "ruling": "q_i -> rho_set -> rho_ops -> stellar-source chain passes at synthetic skeleton level; real stellar physics and G normalization remain open.",
            "key_results": {
                "profiles": ["uniform", "quadratic", "concentrated"],
                "max_Q_mass_error": 6.661338147750939e-16,
                "max_pressure_identity_error": 1.9984014443252818e-15,
                "max_surface_g_error": 0.0,
                "max_surface_phi_error": 0.0,
                "exterior_phi_slope_range": [-1.0000000000000002, -1.0],
                "exterior_g_slope_range": [-2.0000000000000004, -2.0],
                "max_source_boost": 1.1962111021763993,
                "pressure_boost_monotonic": True,
            },
            "_source_path": "fallback_locked_from_chat",
        },
        "R228M": {
            "run_id": "SFT_V13_1_R228M_Binding_Internal_Energy_Source_Accounting",
            "verdict": "PARTIAL_PASS_BINDING_INTERNAL_ENERGY_SOURCE_ACCOUNTING_TESTED_REST_MASS_INTERNAL_ENERGY_RADIATION_PRESSURE_TRACE_AND_NEGATIVE_BINDING_SEPARATED_COMPONENT_LEDGER_ADDITIVITY_PASSES_GAS_TRACE_IDENTITY_U_PLUS_3P_EQUALS_3U_FOR_GAMMA_5_3_RADIATION_TRACE_IDENTITY_RHO_PLUS_3P_EQUALS_2RHO_PASSES_BINDING_COMPONENT_NEGATIVE_AND_REDUCES_ACTIVE_SOURCE_WITH_OVERBINDING_GUARDRAIL_EXTERIOR_TOTAL_Q_ACTIVE_PHI_MINUS1_AND_G_MINUS2_SLOPES_PRESERVED_ROOT_NORMALIZATION_CHANGES_AMPLITUDE_NOT_SHAPE_WHOLE_STAR_6PI_REJECTED_AS_CATEGORY_ERROR_G_NORMALIZATION_REAL_EOS_BINDING_THEORY_SPECIES_MAP_STELLAR_EVOLUTION_COMPACT_STAR_AND_VALIDATION_OPEN",
            "ruling": "Component source ledger passes at synthetic structural level; G/root normalization, real EOS, binding theorem, species map, compact-star physics, and validation remain open.",
            "key_results": {
                "max_component_identity_error": 2.220446049250313e-16,
                "active_boost_range_over_rest": [0.9870344922770179, 1.0245661955753993],
                "binding_reduction_fraction_range": [0.0, 0.08000000000000002],
                "gas_active_ratio_range": [3.0, 3.000000000000001],
                "radiation_active_ratio_range": [2.0, 2.0],
                "exterior_phi_slope_range": [-1.0000000000000002, -1.0],
                "exterior_g_slope_range": [-2.0000000000000004, -2.0],
                "first_nonpositive_binding_fraction": 1.1,
            },
            "_source_path": "fallback_locked_from_chat",
        },
        "R229M": {
            "run_id": "SFT_V13_1_R229M_Compactness_Relativistic_Pressure_Guardrail",
            "verdict": "PARTIAL_PASS_COMPACTNESS_RELATIVISTIC_PRESSURE_GUARDRAIL_TESTED_LOW_C_AND_LOW_PRESSURE_CASES_CLASSIFIED_WEAK_FIELD_SAFE_INTERMEDIATE_CASES_CLASSIFIED_TRANSITIONAL_GUARDRAIL_HIGH_COMPACTNESS_OR_HIGH_PRESSURE_CASES_FLAGGED_COMPACT_SECTOR_REQUIRED_FB_EQUALS_ONE_CLOSURE_PRESERVED_BUT_WEAK_EXPANSION_ERROR_GROWS_WITH_COMPACTNESS_EXTERIOR_SHAPE_SLOPES_REMAIN_MINUS1_MINUS2_WITH_INTERPRETATION_GUARDED_ROOT_NORMALIZATION_CHANGES_COMPACTNESS_AND_AMPLITUDE_NOT_SHAPE_WHOLE_STAR_6PI_REJECTED_AS_CATEGORY_ERROR_TOV_COMPACT_STAR_EOS_G_NORMALIZATION_COLLAPSE_SECTOR_AND_VALIDATION_OPEN",
            "ruling": "Compactness/pressure handoff guardrail passes. Weak-field stellar skeleton remains valid only inside guarded low-C/low-pressure domain; compact-star/TOV-like sector remains open.",
            "key_results": {
                "compactness_C_range": [0.004989430320916361, 6.147397173452395],
                "w_max_range": [0.0, 0.04000000000000001],
                "class_counts": {
                    "COMPACT_SECTOR_REQUIRED": 68,
                    "WEAK_FIELD_SAFE": 29,
                    "TRANSITIONAL_GUARDRAIL": 23,
                },
                "min_first_compact_C": 0.15,
                "max_abs_FB_minus_1": 2.220446049250313e-16,
                "root_shape_invariance": "PASS",
            },
            "_source_path": "fallback_locked_from_chat",
        },
    }


def merge_found_with_fallback(found: dict[str, dict]) -> dict[str, dict]:
    fallback = fallback_summaries()
    merged = {}
    for key in EXPECTED_RUN_KEYS:
        merged[key] = found.get(key, fallback[key])
        if key not in found:
            merged[key]["_used_fallback"] = True
        else:
            merged[key]["_used_fallback"] = False
    return merged


def get_nested(summary: dict, *keys: str, default=None):
    cur = summary
    for key in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(key, default)
    return cur


def build_run_rollup_table(summaries: dict[str, dict]) -> pd.DataFrame:
    rows = []

    run_purpose = {
        "R225M": "particle closure to star gravity accumulation",
        "R226M": "q_i to rho_set source dictionary",
        "R227M": "rho_set to rho_ops stellar interior skeleton",
        "R228M": "rest/internal/radiation/pressure/binding source ledger",
        "R229M": "compactness / relativistic-pressure handoff guardrail",
    }

    main_result = {
        "R225M": "Discrete particle settlement demand converges to continuum exterior gravity; whole-star 6π rejected.",
        "R226M": "q_i defined as normalized maintained closure demand; rho_set coarse-grains correctly.",
        "R227M": "Toy stellar rho_ops source produces enclosed-source interior field and exterior total-source law.",
        "R228M": "Component active-source ledger passes: rest, internal, radiation, pressure trace, negative binding.",
        "R229M": "Weak-field domain guarded by compactness/pressure thresholds; compact-sector handoff flagged.",
    }

    open_boundary = {
        "R225M": "G normalization, species map, real stellar model, validation.",
        "R226M": "G/root normalization, species q_i.",
        "R227M": "Real EOS, stellar structure, compact-star correction.",
        "R228M": "Real EOS, binding theorem, species map, stellar evolution.",
        "R229M": "TOV/compact-star equations, collapse sector, validation.",
    }

    for key in EXPECTED_RUN_KEYS:
        s = summaries[key]
        rows.append({
            "run": key,
            "run_id": s.get("run_id"),
            "purpose": run_purpose[key],
            "verdict_prefix": str(s.get("verdict", ""))[:120],
            "main_result": main_result[key],
            "open_boundary": open_boundary[key],
            "source_path": s.get("_source_path", ""),
            "used_fallback": bool(s.get("_used_fallback", False)),
        })

    return pd.DataFrame(rows)


def build_equation_chain_table() -> pd.DataFrame:
    rows = [
        {
            "step": 1,
            "name": "particle closure support",
            "expression": "V12.13 locally-real particle closure support",
            "status": "upstream framework",
            "claim_boundary": "not a species map",
        },
        {
            "step": 2,
            "name": "particle source",
            "expression": "q_i = normalized maintained closure-demand source",
            "status": "R226M bridge",
            "claim_boundary": "normalized source only; no G",
        },
        {
            "step": 3,
            "name": "continuum source",
            "expression": "rho_set(x) = sum_i q_i delta(x-x_i)",
            "status": "R226M pass",
            "claim_boundary": "coarse-grained source dictionary",
        },
        {
            "step": 4,
            "name": "pressure-aware source",
            "expression": "rho_ops = rho_set + 3p/c^2",
            "status": "R227M pass",
            "claim_boundary": "toy pressure channel, not real EOS",
        },
        {
            "step": 5,
            "name": "component active source",
            "expression": "rho_active = rho_rest + u_int + rho_rad + 3p/c^2 + rho_bind",
            "status": "R228M pass",
            "claim_boundary": "synthetic component ledger",
        },
        {
            "step": 6,
            "name": "enclosed active source",
            "expression": "Q_active(r) = integral_0^r 4*pi*r'^2*rho_active(r') dr'",
            "status": "R227M/R228M pass",
            "claim_boundary": "normalized source integral",
        },
        {
            "step": 7,
            "name": "interior gravity skeleton",
            "expression": "g(r) = Q_active(r)/r^2",
            "status": "synthetic weak-field skeleton",
            "claim_boundary": "weak-field only",
        },
        {
            "step": 8,
            "name": "exterior gravity skeleton",
            "expression": "phi_ext = Q_active,total/r ; g_ext = Q_active,total/r^2",
            "status": "R225M-R229M preserved",
            "claim_boundary": "shape law; amplitude needs kappa_root",
        },
        {
            "step": 9,
            "name": "one-speed closure",
            "expression": "F = exp(-phi), B = exp(+phi), F*B = 1",
            "status": "preserved",
            "claim_boundary": "exact closure does not mean weak expansion remains valid at high C",
        },
        {
            "step": 10,
            "name": "compactness guardrail",
            "expression": "C = kappa_root * Q_active / R",
            "status": "R229M pass",
            "claim_boundary": "handoff marker, not compact-star solution",
        },
    ]
    return pd.DataFrame(rows)


def build_claim_boundary_table() -> pd.DataFrame:
    rows = [
        {
            "claim": "V13.1 structurally unifies V12.13 particle closure with V11.13/V12.3 gravity accumulation.",
            "status": "ALLOWED",
            "safe_wording": "first sector-unification checkpoint",
        },
        {
            "claim": "Stellar gravity is the continuum settlement field of accumulated particle-scale closure maintenance.",
            "status": "ALLOWED",
            "safe_wording": "synthetic/structural gravity accumulation reading",
        },
        {
            "claim": "q_i is a normalized maintained closure-demand source.",
            "status": "ALLOWED",
            "safe_wording": "normalized source dictionary",
        },
        {
            "claim": "rho_active includes rest, internal, radiation, pressure trace, and negative binding components.",
            "status": "ALLOWED",
            "safe_wording": "component source ledger",
        },
        {
            "claim": "Exterior shape laws phi~1/r and g~1/r^2 are preserved in the synthetic skeleton.",
            "status": "ALLOWED",
            "safe_wording": "normalized exterior shape law",
        },
        {
            "claim": "Weak-field stellar skeleton remains valid for all compactness.",
            "status": "BLOCKED",
            "safe_wording": "R229M imposes compactness/pressure handoff guardrail",
        },
        {
            "claim": "V13.1 derives Newton's G.",
            "status": "BLOCKED",
            "safe_wording": "kappa_root/G normalization remains open",
        },
        {
            "claim": "V13.1 solves real stellar structure.",
            "status": "BLOCKED",
            "safe_wording": "toy profiles only",
        },
        {
            "claim": "V13.1 solves compact stars / TOV.",
            "status": "BLOCKED",
            "safe_wording": "future compact-sector work",
        },
        {
            "claim": "V13.1 derives a species map.",
            "status": "BLOCKED",
            "safe_wording": "species-specific q_i remains open",
        },
        {
            "claim": "V13.1 validates against observed stars.",
            "status": "BLOCKED",
            "safe_wording": "no observed data used",
        },
        {
            "claim": "A star receives a whole-body 6π multiplier.",
            "status": "BLOCKED",
            "safe_wording": "whole-star 6π rejected as category error",
        },
    ]
    return pd.DataFrame(rows)


def build_open_ledger_table() -> pd.DataFrame:
    rows = [
        {
            "open_item": "absolute root / G normalization",
            "status": "OPEN",
            "description": "kappa_root remains separate; V13.1 does not derive measured G.",
            "next_route": "root-state / V11.13 Gate 07-10 continuation",
        },
        {
            "open_item": "species-specific q_i map",
            "status": "OPEN",
            "description": "No electron/proton/neutron/nuclear source map.",
            "next_route": "particle-sector unification branch",
        },
        {
            "open_item": "real equation of state",
            "status": "OPEN",
            "description": "R227/R228 use toy pressure and component profiles.",
            "next_route": "stellar EOS / thermodynamic sector",
        },
        {
            "open_item": "binding theorem",
            "status": "OPEN",
            "description": "R228 uses negative synthetic binding proxy, not a variational binding theorem.",
            "next_route": "binding / internal energy theorem branch",
        },
        {
            "open_item": "stellar evolution",
            "status": "OPEN",
            "description": "No nuclear burning, opacity, transport, or time evolution.",
            "next_route": "stellar evolution compatibility branch",
        },
        {
            "open_item": "compact stars / TOV-like sector",
            "status": "OPEN",
            "description": "R229 flags handoff but does not solve compact stars.",
            "next_route": "compact-sector branch",
        },
        {
            "open_item": "collapse / horizon / black-hole no-overwrite sector",
            "status": "OPEN",
            "description": "Not treated in V13.1 R225-R229.",
            "next_route": "collapse/no-overwrite sector",
        },
        {
            "open_item": "observational validation",
            "status": "OPEN",
            "description": "No observed stars or fitted parameters used.",
            "next_route": "validation after theory freeze",
        },
    ]
    return pd.DataFrame(rows)


def build_next_sector_route_table() -> pd.DataFrame:
    rows = [
        {
            "sector": "gravity accumulation",
            "status_after_V13_1": "first unification checkpoint frozen",
            "next_action": "paper/rollup note or compact-sector branch",
        },
        {
            "sector": "compact stars",
            "status_after_V13_1": "handoff flagged, unsolved",
            "next_action": "derive TOV-like settlement equations without claiming solution",
        },
        {
            "sector": "force / charge",
            "status_after_V13_1": "next V13 sector candidate",
            "next_action": "test V12.13 particle against V11/V12 force and directional settlement results",
        },
        {
            "sector": "cosmology / expansion",
            "status_after_V13_1": "future V13 sector candidate",
            "next_action": "test locally-real particle/no-overwrite architecture against expansion and CMB branches",
        },
        {
            "sector": "galaxy / far-field handoff",
            "status_after_V13_1": "V12.3 guardrail preserved",
            "next_action": "retest E=DB far-field handoff against particle source dictionary",
        },
        {
            "sector": "root-state / G",
            "status_after_V13_1": "still open",
            "next_action": "continue root-invariant derivation without Planck/G smuggling",
        },
    ]
    return pd.DataFrame(rows)


def build_metrics_table(summaries: dict[str, dict]) -> pd.DataFrame:
    rows = []

    # Pull from found summaries when possible; fallback summaries have key_results.
    for key in EXPECTED_RUN_KEYS:
        s = summaries[key]
        kr = s.get("key_results", {})

        if key == "R225M":
            continuum = s.get("continuum_summary", {})
            cloud = s.get("particle_cloud_summary", {})
            direction = s.get("directional_summary", {})
            one_speed = s.get("one_speed_closure_summary", {})
            rows.extend([
                {"run": key, "metric": "continuum exterior phi slope", "value": continuum.get("exterior_phi_slope", kr.get("continuum_exterior_phi_slope"))},
                {"run": key, "metric": "continuum exterior g slope", "value": continuum.get("exterior_g_slope", kr.get("continuum_exterior_g_slope"))},
                {"run": key, "metric": "continuum interior g slope", "value": continuum.get("interior_g_slope", kr.get("continuum_interior_g_slope"))},
                {"run": key, "metric": "best particle cloud phi RMS", "value": cloud.get("best_phi_rel_rms_error", kr.get("particle_cloud_phi_rms"))},
                {"run": key, "metric": "best particle cloud g RMS", "value": cloud.get("best_g_rel_rms_error", kr.get("particle_cloud_g_rms"))},
                {"run": key, "metric": "directional cancellation slope", "value": direction.get("random_directional_cancellation_slope", kr.get("directional_cancellation_slope"))},
                {"run": key, "metric": "max |FB-1|", "value": one_speed.get("max_abs_FB_minus_1", kr.get("max_FB_error"))},
            ])

        elif key == "R226M":
            add = s.get("additivity_summary", {})
            coarse = s.get("coarse_graining_summary", {})
            exterior = s.get("exterior_distribution_summary", {})
            direction = s.get("directional_summary", {})
            rows.extend([
                {"run": key, "metric": "max total q error", "value": add.get("max_abs_total_q_error", kr.get("max_total_q_error"))},
                {"run": key, "metric": "coarse N", "value": coarse.get("best_N", kr.get("coarse_graining_N"))},
                {"run": key, "metric": "shell density RMS error", "value": coarse.get("best_shell_density_rel_rms_error", kr.get("shell_density_rms_error"))},
                {"run": key, "metric": "max exterior phi RMS error", "value": exterior.get("max_phi_rms_error")},
                {"run": key, "metric": "max exterior g RMS error", "value": exterior.get("max_g_rms_error")},
                {"run": key, "metric": "equal-q directional slope", "value": direction.get("equal_q_random_cancellation_slope", kr.get("directional_equal_q_slope"))},
            ])

        elif key == "R227M":
            profile = s.get("profile_summary", {})
            pressure = s.get("pressure_boost_summary", {})
            rows.extend([
                {"run": key, "metric": "max Q mass error", "value": profile.get("max_Q_mass_error", kr.get("max_Q_mass_error"))},
                {"run": key, "metric": "max pressure identity error", "value": profile.get("max_pressure_identity_error", kr.get("max_pressure_identity_error"))},
                {"run": key, "metric": "max surface g error", "value": profile.get("max_surface_g_error", kr.get("max_surface_g_error"))},
                {"run": key, "metric": "max surface phi error", "value": profile.get("max_surface_phi_error", kr.get("max_surface_phi_error"))},
                {"run": key, "metric": "max source boost", "value": profile.get("max_source_boost", kr.get("max_source_boost"))},
                {"run": key, "metric": "pressure boost monotonic", "value": pressure.get("all_profiles_monotonic", kr.get("pressure_boost_monotonic"))},
            ])

        elif key == "R228M":
            comp = s.get("component_summary", {})
            overbind = s.get("overbinding_summary", {})
            rows.extend([
                {"run": key, "metric": "max component identity error", "value": comp.get("max_component_identity_error", kr.get("max_component_identity_error"))},
                {"run": key, "metric": "active boost range over rest", "value": comp.get("active_boost_range_over_rest", kr.get("active_boost_range_over_rest"))},
                {"run": key, "metric": "binding reduction fraction range", "value": comp.get("binding_reduction_fraction_range", kr.get("binding_reduction_fraction_range"))},
                {"run": key, "metric": "gas active ratio range", "value": comp.get("gas_active_ratio_range", kr.get("gas_active_ratio_range"))},
                {"run": key, "metric": "radiation active ratio range", "value": comp.get("radiation_active_ratio_range", kr.get("radiation_active_ratio_range"))},
                {"run": key, "metric": "first nonpositive binding fraction", "value": overbind.get("first_nonpositive_binding_fraction", kr.get("first_nonpositive_binding_fraction"))},
            ])

        elif key == "R229M":
            grid = s.get("grid_summary", {})
            boundary = s.get("boundary_summary", {})
            root = s.get("root_shape_summary", {})
            rows.extend([
                {"run": key, "metric": "compactness C range", "value": grid.get("compactness_C_range", kr.get("compactness_C_range"))},
                {"run": key, "metric": "w max range", "value": grid.get("w_max_range", kr.get("w_max_range"))},
                {"run": key, "metric": "class counts", "value": grid.get("class_counts", kr.get("class_counts"))},
                {"run": key, "metric": "min first compact C", "value": boundary.get("min_first_compact_C", kr.get("min_first_compact_C"))},
                {"run": key, "metric": "max |FB-1|", "value": grid.get("max_abs_FB_minus_1", kr.get("max_abs_FB_minus_1"))},
                {"run": key, "metric": "root shape invariance", "value": root.get("all_status_pass", kr.get("root_shape_invariance"))},
            ])

    return pd.DataFrame(rows)


def build_report(
    created_utc: str,
    verdict: str,
    run_rollup: pd.DataFrame,
    equation_chain: pd.DataFrame,
    metrics: pd.DataFrame,
    claim_boundary: pd.DataFrame,
    open_ledger: pd.DataFrame,
    next_routes: pd.DataFrame,
) -> str:
    return f"""
# SFT V13.1 / R230M — Gravity Accumulation Unification Rollup

Generated: {created_utc}

Verdict:
{verdict}

## Branch

{BRANCH}

## One-line result

V13.1 establishes the first SFT sector unification checkpoint: V12.13 locally-real particle closure can be mapped into the V11.13/V12.3 gravity scaffold through particle source q_i, continuum source rho_set, active source rho_active, accumulated Q_active, and weak-field stellar gravity, with compact/high-pressure cases explicitly handed off to a future compact-star sector.

## Core equation chain

{equation_chain.to_string(index=False)}

## Run rollup

{run_rollup.to_string(index=False)}

## Key metrics

{metrics.to_string(index=False)}

## Claim boundary

{claim_boundary.to_string(index=False)}

## Open ledger

{open_ledger.to_string(index=False)}

## Next-sector routing

{next_routes.to_string(index=False)}

## Frozen V13.1 gravity claim

SFT V13.1 structurally unifies the particle-to-star gravity accumulation sector. The maintained closure of locally-real particles is represented by normalized q_i source; q_i coarse-grains into rho_set; rho_set extends to pressure-aware and component-aware active source rho_active; Q_active accumulates into interior and exterior weak-field gravity; exterior phi~1/r and g~1/r^2 shape laws are preserved; root normalization changes amplitude/compactness but not the shape law; and high compactness or high pressure triggers a compact-sector handoff guardrail.

## What V13.1 does not claim

V13.1 does not derive Newton's G, does not derive a species map, does not solve real stellar structure, does not solve compact stars or TOV, does not provide a real EOS, does not validate against observed stars, and does not apply 6pi as a whole-star multiplier.

## Status

This rollup is ready to serve as the first V13.1 sector-unification checkpoint.
"""


def main() -> None:
    created_utc = utc_now_iso()
    search_root = Path.cwd()

    found = find_summary_jsons(search_root)
    summaries = merge_found_with_fallback(found)

    root = Path(RUN_ID)
    if root.exists():
        shutil.rmtree(root)

    tables = root / "tables"
    scripts = root / "scripts"
    tables.mkdir(parents=True)
    scripts.mkdir(parents=True)

    run_rollup = build_run_rollup_table(summaries)
    equation_chain = build_equation_chain_table()
    metrics = build_metrics_table(summaries)
    claim_boundary = build_claim_boundary_table()
    open_ledger = build_open_ledger_table()
    next_routes = build_next_sector_route_table()

    found_count = sum(1 for k in EXPECTED_RUN_KEYS if not summaries[k].get("_used_fallback", False))
    fallback_count = sum(1 for k in EXPECTED_RUN_KEYS if summaries[k].get("_used_fallback", False))

    verdict = (
        "PASS_V13_1_GRAVITY_ACCUMULATION_UNIFICATION_ROLLUP_FROZEN_"
        "R225_TO_R229_CHAIN_CONSOLIDATED_PARTICLE_CLOSURE_TO_QI_TO_RHO_SET_TO_RHO_ACTIVE_TO_STELLAR_Q_ACTIVE_"
        "WEAK_FIELD_EXTERIOR_PHI_MINUS1_G_MINUS2_SHAPE_LAW_PRESERVED_"
        "COMPACTNESS_PRESSURE_HANDOFF_GUARDRAIL_PRESERVED_"
        "WHOLE_STAR_6PI_REJECTED_G_NORMALIZATION_SPECIES_MAP_REAL_EOS_STELLAR_EVOLUTION_COMPACT_STAR_TOV_COLLAPSE_AND_VALIDATION_OPEN"
    )

    run_rollup.to_csv(tables / "R230M_run_rollup.csv", index=False)
    equation_chain.to_csv(tables / "R230M_equation_chain.csv", index=False)
    metrics.to_csv(tables / "R230M_key_metrics.csv", index=False)
    claim_boundary.to_csv(tables / "R230M_claim_boundary_matrix.csv", index=False)
    open_ledger.to_csv(tables / "R230M_open_ledger.csv", index=False)
    next_routes.to_csv(tables / "R230M_next_sector_routing.csv", index=False)

    source_summary = {
        key: {
            "run_id": summaries[key].get("run_id"),
            "source_path": summaries[key].get("_source_path"),
            "used_fallback": summaries[key].get("_used_fallback", False),
            "verdict": summaries[key].get("verdict"),
            "ruling": summaries[key].get("ruling"),
        }
        for key in EXPECTED_RUN_KEYS
    }

    summary = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "branch": BRANCH,
        "verdict": verdict,
        "source_ingestion": {
            "search_root": str(search_root),
            "found_count": found_count,
            "fallback_count": fallback_count,
            "sources": source_summary,
        },
        "V13_1_frozen_claim": (
            "Particle closure maintenance maps to normalized q_i source; q_i coarse-grains to rho_set; "
            "rho_set extends to rho_active including pressure/internal/radiation/binding components; "
            "Q_active accumulates into weak-field stellar gravity with exterior phi~1/r and g~1/r^2; "
            "compact/high-pressure regimes require handoff to a future compact-star/TOV-like sector."
        ),
        "core_equation_chain": [
            "q_i = normalized maintained closure-demand source",
            "rho_set(x) = sum_i q_i delta(x-x_i)",
            "rho_ops = rho_set + 3p/c^2",
            "rho_active = rho_rest + u_int + rho_rad + 3p/c^2 + rho_bind",
            "Q_active(r) = integral_0^r 4*pi*r'^2*rho_active(r')dr'",
            "g(r) = Q_active(r)/r^2",
            "phi_ext = Q_active,total/r",
            "g_ext = Q_active,total/r^2",
            "F=exp(-phi), B=exp(+phi), FB=1",
            "C = kappa_root*Q_active/R",
        ],
        "claim_boundary": {
            "allowed": [
                "first V13.1 gravity accumulation sector-unification checkpoint",
                "synthetic particle-to-star accumulation chain",
                "normalized source and active-source ledger",
                "weak-field exterior shape preservation inside guardrail",
                "compactness/pressure handoff marker",
            ],
            "blocked": [
                "Newton G derivation",
                "species q_i map",
                "real stellar EOS",
                "stellar evolution",
                "compact-star/TOV solution",
                "black-hole/collapse solution",
                "observed validation",
                "whole-star 6pi multiplier",
            ],
        },
        "V12_13_context": {
            "L_eff": L_EFF,
            "N_eff": N_EFF,
            "amplitude_tax": AMP_TAX,
            "D_scale_endpoint": D_SCALE_ENDPOINT,
            "K_top": SIX_PI,
            "K_top_category": "particle/top-sector terminal closure, not whole-star multiplier",
        },
        "next_recommended": (
            "Freeze V13.1 gravity rollup as a checkpoint note, then choose next V13 sector: "
            "compact-star handoff, force/charge unification, galaxy far-field E=DB retest, or root/G normalization."
        ),
        "paste_back_to_chat": [
            "summary.json",
            "tables/R230M_run_rollup.csv",
            "tables/R230M_equation_chain.csv",
            "tables/R230M_claim_boundary_matrix.csv",
            "tables/R230M_open_ledger.csv",
            "Any traceback if failed.",
        ],
    }

    report = build_report(
        created_utc=created_utc,
        verdict=verdict,
        run_rollup=run_rollup,
        equation_chain=equation_chain,
        metrics=metrics,
        claim_boundary=claim_boundary,
        open_ledger=open_ledger,
        next_routes=next_routes,
    )

    (root / "report.md").write_text(report, encoding="utf-8")
    (root / "summary.json").write_text(json.dumps(json_safe(summary), indent=2), encoding="utf-8")

    if "__file__" in globals():
        try:
            this_file = Path(__file__).resolve()
            if this_file.exists():
                shutil.copy2(this_file, scripts / this_file.name)
        except Exception:
            pass

    manifest = make_manifest(root, created_utc)

    zip_path = Path(f"{RUN_ID}_Pack.zip")
    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent))

    final_payload = {
        "run_id": RUN_ID,
        "zip_path": str(zip_path.resolve()),
        "summary_path": str((root / "summary.json").resolve()),
        "report_path": str((root / "report.md").resolve()),
        "manifest_file_count_excluding_manifest": manifest["file_count_excluding_manifest"],
        "summary": summary,
    }

    print(json.dumps(json_safe(final_payload), indent=2))


if __name__ == "__main__":
    main()
