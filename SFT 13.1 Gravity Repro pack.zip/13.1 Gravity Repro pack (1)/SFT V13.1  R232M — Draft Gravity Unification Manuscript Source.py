#!/usr/bin/env python3
"""
SFT V13.1 / R232M — Draft Gravity Unification Manuscript Source

Branch:
    SFT V13.1 — Particle-to-Star/Cosmos Gravity Accumulation Unification

Purpose:
    Build the first full V13.1 gravity-unification manuscript source.

    This is the manuscript source build, not the final PDF freeze.

Inputs:
    Optional local source packs/summaries from:
        V11.13 Gravity Addendum
        V12.3 Gravity Trajectory Prevalidation
        V12.13 particle framework
        R225M-R231M

    If local summaries/tables are absent, the script uses the locked V13.1
    migration-map content from the current run chain.

Outputs:
    SFT_V13_1_R232M_Draft_Gravity_Unification_Manuscript_Source/
        README.md
        SFT_V13_1_Gravity_Unification_Manuscript.md
        SFT_V13_1_Gravity_Unification_Manuscript.tex
        summary.json
        manifest.json
        tables/*.csv
        source_fragments/*.md
        scripts/run_R232M.py

    SFT_V13_1_R232M_Draft_Gravity_Unification_Manuscript_Source_Pack.zip

Claim boundary:
    V13.1 may say:
        - Gravity is accumulated settlement geometry of locally-real particle support.
        - Particle closure maps to normalized q_i.
        - q_i coarse-grains to rho_set.
        - rho_set extends to rho_active.
        - Q_active sources weak-field stellar gravity.
        - Compact/high-pressure regimes require handoff.
        - V12.3 far-field/cosmic scaffolds are carried forward for later retest.

    V13.1 may not say:
        - G is derived.
        - species q_i map is derived.
        - real EOS/stellar evolution is solved.
        - compact stars/TOV are solved.
        - black-hole/collapse sector is solved.
        - observed validation is complete.
        - whole-star 6pi multiplier is valid.
"""

from __future__ import annotations

from pathlib import Path
import csv
import datetime as dt
import hashlib
import json
import math
import shutil
import textwrap
import zipfile
from typing import Any


RUN_ID = "SFT_V13_1_R232M_Draft_Gravity_Unification_Manuscript_Source"
BRANCH = "SFT V13.1 — Particle-to-Star/Cosmos Gravity Accumulation Unification"

TITLE = "Solvency Field Theory V13.1: Gravity as Accumulated Settlement of Locally Real Particle Support"
SUBTITLE = "Particle-to-Star/Cosmos Gravity Unification, Source Ledger, and Compactness Guardrails"

TWO_PI = 2.0 * math.pi
FOUR_PI = 4.0 * math.pi
SIX_PI = 6.0 * math.pi

N_EFF = 25.0 / 13.0
AMP_TAX = 0.5 * math.log(N_EFF)
L_EFF = 3.0 * math.pi - AMP_TAX
D_SCALE_ENDPOINT = 2.0 * math.exp(L_EFF)


def utc_now_iso() -> str:
    return dt.datetime.now(dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def json_safe(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [json_safe(v) for v in obj]
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
    return obj


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def make_manifest(root: Path, created_utc: str) -> dict:
    files = []
    for p in sorted(root.rglob("*")):
        if p.is_file():
            files.append({
                "path": p.relative_to(root).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            })
    manifest = {
        "run_id": RUN_ID,
        "created_utc": created_utc,
        "file_count_excluding_manifest": len(files),
        "files": files,
    }
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def tex_escape(s: str) -> str:
    repl = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(repl.get(ch, ch) for ch in s)


def equation_spine_rows() -> list[dict[str, str]]:
    return [
        {
            "step": "1",
            "name": "Locally-real particle source",
            "equation": r"q_i := \text{normalized maintained closure-demand source}",
            "meaning": "A particle is not a bookkeeping label; it is a maintained local support process with normalized settlement demand.",
            "status": "core V13.1",
        },
        {
            "step": "2",
            "name": "Continuum source density",
            "equation": r"\rho_{\rm set}(x)=\sum_i q_i\delta(x-x_i)",
            "meaning": "Many particle sources coarse-grain into a settlement source density.",
            "status": "core V13.1",
        },
        {
            "step": "3",
            "name": "Pressure-aware operation source",
            "equation": r"\rho_{\rm ops}=\rho_{\rm set}+\frac{3p}{c^2}",
            "meaning": "Pressure contributes as active operation density.",
            "status": "core V13.1",
        },
        {
            "step": "4",
            "name": "Component active-source ledger",
            "equation": r"\rho_{\rm active}=\rho_{\rm rest}+u_{\rm int}+\rho_{\rm rad}+\frac{3p}{c^2}+\rho_{\rm bind}",
            "meaning": "Rest mass, internal energy, radiation, pressure trace, and negative binding are separated.",
            "status": "core V13.1",
        },
        {
            "step": "5",
            "name": "Enclosed active source",
            "equation": r"Q_{\rm active}(r)=\int_0^r4\pi r'^2\rho_{\rm active}(r')\,dr'",
            "meaning": "Interior gravity is sourced by accumulated active source.",
            "status": "core V13.1",
        },
        {
            "step": "6",
            "name": "Interior weak-field skeleton",
            "equation": r"g(r)=\frac{Q_{\rm active}(r)}{r^2}",
            "meaning": "The local acceleration skeleton follows from enclosed source.",
            "status": "weak-field only",
        },
        {
            "step": "7",
            "name": "Exterior potential",
            "equation": r"\phi_{\rm ext}(r)=\frac{Q_{\rm active,total}}{r}",
            "meaning": "Outside the source, only total accumulated active source appears in the shape law.",
            "status": "weak-field shape law",
        },
        {
            "step": "8",
            "name": "Exterior acceleration",
            "equation": r"g_{\rm ext}(r)=\frac{Q_{\rm active,total}}{r^2}",
            "meaning": "The inverse-square shape is preserved in normalized units.",
            "status": "weak-field shape law",
        },
        {
            "step": "9",
            "name": "One-speed reciprocal closure",
            "equation": r"F=e^{-\phi},\quad B=e^{+\phi},\quad FB=1",
            "meaning": "Clock lag and spatial closure are reciprocal faces of one-speed settlement geometry.",
            "status": "core V13.1 with compactness guardrail",
        },
        {
            "step": "10",
            "name": "Compactness handoff",
            "equation": r"C=\frac{\kappa_{\rm root}Q_{\rm active}}{R}",
            "meaning": "High compactness or high pressure requires compact-sector treatment.",
            "status": "guardrail",
        },
        {
            "step": "11",
            "name": "Far-field settlement scale",
            "equation": r"a_S=\frac{cH}{2\pi}",
            "meaning": "Carried forward from V12.3 as galaxy/cosmic handoff context.",
            "status": "carried forward, not retested here",
        },
        {
            "step": "12",
            "name": "Far-field environment factor",
            "equation": r"E=\sqrt{DB}",
            "meaning": "Carried forward for later V13 galaxy-sector retest.",
            "status": "preserve with retest",
        },
        {
            "step": "13",
            "name": "Particle top-sector closure",
            "equation": r"K_{\rm top}=4\pi+2\pi=6\pi",
            "meaning": "Particle/top-sector terminal closure only.",
            "status": "guardrailed; not a whole-star multiplier",
        },
    ]


def claim_boundary_rows() -> list[dict[str, str]]:
    return [
        {"claim": "Gravity is accumulated settlement geometry of locally-real particle support.", "status": "PROMOTE", "boundary": "Structural V13.1 gravity statement."},
        {"claim": "Particle closure maps to normalized q_i source.", "status": "PROMOTE", "boundary": "No species-specific q_i map yet."},
        {"claim": "q_i coarse-grains to rho_set.", "status": "PROMOTE", "boundary": "Normalized source density only."},
        {"claim": "rho_active includes rest, internal, radiation, pressure trace, and binding components.", "status": "PROMOTE", "boundary": "Toy component ledger; real EOS open."},
        {"claim": "Q_active sources weak-field stellar gravity.", "status": "PROMOTE", "boundary": "Weak-field skeleton only."},
        {"claim": "Exterior phi~1/r and g~1/r^2 are preserved.", "status": "PROMOTE", "boundary": "Shape law; amplitude requires kappa_root."},
        {"claim": "F=exp(-phi), B=exp(phi), FB=1.", "status": "PROMOTE", "boundary": "Exact reciprocal closure; not a proof of weak-field validity at high C."},
        {"claim": "Compact/high-pressure regimes require handoff.", "status": "PROMOTE", "boundary": "No TOV solution here."},
        {"claim": "V12.3 a_S=cH/2pi is carried forward.", "status": "PRESERVE", "boundary": "Galaxy/cosmic sector retest required."},
        {"claim": "V12.3 E=sqrt(DB) is carried forward.", "status": "PRESERVE_WITH_RETEST", "boundary": "Must not modify local source/metric sector."},
        {"claim": "Cosmic no-overwrite expansion context belongs in gravity picture.", "status": "PRESERVE", "boundary": "Full cosmic-sector unification deferred."},
        {"claim": "Newton G is derived.", "status": "BLOCK", "boundary": "kappa_root/G normalization remains open."},
        {"claim": "Real stellar EOS is solved.", "status": "BLOCK", "boundary": "Toy source profiles only."},
        {"claim": "Compact stars/TOV are solved.", "status": "BLOCK", "boundary": "R229 only marks handoff."},
        {"claim": "Observed validation is complete.", "status": "BLOCK", "boundary": "No observed data in V13.1 source build."},
        {"claim": "Whole-star 6pi multiplier is valid.", "status": "REJECT", "boundary": "6pi is particle/top-sector terminal closure only."},
        {"claim": "Planck/G circular derivation is allowed.", "status": "REJECT", "boundary": "Root normalization must not be smuggled."},
    ]


def run_catalog_rows() -> list[dict[str, str]]:
    return [
        {
            "run": "R225M",
            "title": "Particle-to-Star Settlement Accumulation",
            "role": "Established the synthetic particle-to-star accumulation skeleton.",
            "result": "Continuum sphere behavior, particle cloud convergence, directional cancellation, one-speed closure, and whole-star 6pi rejection.",
        },
        {
            "run": "R226M",
            "title": "Particle Source Density Normalization Bridge",
            "role": "Defined q_i and rho_set.",
            "result": "q_i additivity, coarse-graining, exterior total-q dominance, and root-normalization shape invariance passed.",
        },
        {
            "run": "R227M",
            "title": "Real Stellar Source Skeleton",
            "role": "Extended rho_set into pressure-aware stellar source.",
            "result": "rho_ops, enclosed Q_ops, interior field, exterior total-source law, and surface continuity passed.",
        },
        {
            "run": "R228M",
            "title": "Binding/Internal-Energy Source Accounting",
            "role": "Separated active-source components.",
            "result": "Rest/internal/radiation/pressure/binding ledger passed; gas and radiation trace identities passed.",
        },
        {
            "run": "R229M",
            "title": "Compactness/Relativistic-Pressure Guardrail",
            "role": "Marked weak-field validity boundary.",
            "result": "Weak, transitional, and compact-sector-required regimes separated; FB=1 distinguished from weak expansion validity.",
        },
        {
            "run": "R230M",
            "title": "Gravity Accumulation Unification Rollup",
            "role": "Froze first V13.1 gravity-sector checkpoint.",
            "result": "R225-R229 chain consolidated into one rollup.",
        },
        {
            "run": "R231M",
            "title": "Gravity Program Source Inventory and Claim Migration Map",
            "role": "Prepared monograph claim migration.",
            "result": "Legacy gravity program, equation support, guardrails, and manuscript outline mapped.",
        },
    ]


def open_problem_rows() -> list[dict[str, str]]:
    return [
        {"open_problem": "Root/G normalization", "why_open": "kappa_root is separated from normalized source; measured G not derived.", "next_route": "root-state sector"},
        {"open_problem": "Species-specific q_i", "why_open": "q_i is normalized but not mapped to electron/proton/neutron species.", "next_route": "particle/force sector"},
        {"open_problem": "Real stellar EOS", "why_open": "R227/R228 use toy profiles and component identities.", "next_route": "stellar matter sector"},
        {"open_problem": "Binding theorem", "why_open": "R228 uses synthetic negative binding proxy.", "next_route": "action-level binding derivation"},
        {"open_problem": "Compact-star/TOV sector", "why_open": "R229 only marks handoff.", "next_route": "compact-sector derivation"},
        {"open_problem": "Collapse/horizon/no-overwrite black-hole sector", "why_open": "Not treated in R225-R231.", "next_route": "collapse/no-overwrite sector"},
        {"open_problem": "Galaxy far-field E=sqrt(DB) retest", "why_open": "V12.3 far-field scaffold not retested against rho_active.", "next_route": "galaxy/far-field V13 branch"},
        {"open_problem": "Cosmic-sector unification", "why_open": "H(t), a_S, no-overwrite context carried forward only.", "next_route": "cosmology V13 branch"},
        {"open_problem": "Observed validation", "why_open": "No data tuning or validation in V13.1 manuscript source.", "next_route": "post-freeze validation protocol"},
    ]


def migration_rows() -> list[dict[str, str]]:
    return [
        {"source": "V11.13", "old_claim": "Gravity is settlement geometry.", "V13_1_action": "PROMOTE", "new_form": "Gravity is accumulated settlement geometry of locally-real particle support."},
        {"source": "V11.13", "old_claim": "Exterior phi~1/r, g~1/r^2.", "V13_1_action": "PROMOTE", "new_form": "Exterior shape follows from total Q_active."},
        {"source": "V11.13", "old_claim": "FB=1 reciprocal closure.", "V13_1_action": "PROMOTE", "new_form": "F=exp(-phi), B=exp(phi), FB=1 with compactness guardrail."},
        {"source": "V11.13", "old_claim": "Root invariant/G unresolved.", "V13_1_action": "PRESERVE", "new_form": "kappa_root/G normalization remains open."},
        {"source": "V12.3", "old_claim": "rho+3p/c^2 operation-density source.", "V13_1_action": "PROMOTE", "new_form": "rho_ops=rho_set+3p/c^2 and rho_active ledger."},
        {"source": "V12.3", "old_claim": "a_S=cH/2pi far-field scale.", "V13_1_action": "PRESERVE", "new_form": "Carried forward as galaxy/cosmic handoff context."},
        {"source": "V12.3", "old_claim": "E=sqrt(DB) environment factor.", "V13_1_action": "PRESERVE_WITH_RETEST", "new_form": "Retest against rho_active in later far-field sector."},
        {"source": "V12.13", "old_claim": "Particle is locally-real support.", "V13_1_action": "PROMOTE", "new_form": "Gravity source begins with maintained local particle closure."},
        {"source": "V12.13", "old_claim": "K_top=6pi.", "V13_1_action": "RESTATE_AND_GUARDRAIL", "new_form": "Particle/top-sector closure only; not whole-star multiplier."},
        {"source": "R225-R230", "old_claim": "Particle-to-star chain tested.", "V13_1_action": "PROMOTE", "new_form": "Core V13.1 gravity accumulation unification."},
    ]


def visual_ladder_md() -> str:
    return """
```text
┌────────────────────────────────────────────────────────────┐
│ SFT V13.1 GRAVITY UNIFICATION LADDER                       │
└────────────────────────────────────────────────────────────┘

  LOCALLY-REAL PARTICLE
        │
        │ maintained closure demand
        ▼
  q_i
        │
        │ coarse grain
        ▼
  ρ_set(x) = Σ_i q_i δ(x − x_i)
        │
        │ pressure / internal / radiation / binding ledger
        ▼
  ρ_active = ρ_rest + u_int + ρ_rad + 3p/c² + ρ_bind
        │
        │ enclosed source
        ▼
  Q_active(r) = ∫₀ʳ 4πr'²ρ_active(r')dr'
        │
        │ weak-field skeleton
        ▼
  g(r)=Q_active(r)/r²
  φ_ext=Q_total/r
  g_ext=Q_total/r²
        │
        │ one-speed reciprocal closure
        ▼
  F=e^(−φ), B=e^(+φ), FB=1
        │
        │ compactness guardrail
        ▼
  C=κ_root Q_active/R
        │
        ├── low C / low pressure → weak-field stellar sector
        │
        └── high C / high pressure → compact-star handoff
