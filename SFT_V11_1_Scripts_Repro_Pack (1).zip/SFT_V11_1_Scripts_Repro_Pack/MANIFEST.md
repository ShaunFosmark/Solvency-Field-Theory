# MANIFEST

- scripts/sft_v11_1b_2d_scalar_lag_toy.py
- scripts/sft_v11_1b_2d_tensor_lag_toy.py
- scripts/sft_v11_1d_multipole_tensor_diagnostic.py
- scripts/sft_v11_1e_coefficient_map_probe.py