# SFT V11.1 / V11.1B V2 Scripts Repro Pack

Scripts-only pack for the V11.1B V2 lag-stress bridge and coefficient-map diagnostics.

Generated CSVs and plots are intentionally excluded.

Included:
- V11.1B 2D scalar lag toy
- V11.1B 2D tensor lag toy
- V11.1D multipole/tensor diagnostic
- V11.1E coefficient map probe

Requirements:

```bash
pip install numpy pandas matplotlib
```

Suggested run:

```bash
python sft_v11_1b_2d_scalar_lag_toy.py
python sft_v11_1b_2d_tensor_lag_toy.py
python sft_v11_1d_multipole_tensor_diagnostic.py
```

For V11.1E, first generate or provide V11.7 2D aggregate outputs, then run:

```bash
python sft_v11_1e_coefficient_map_probe.py --v117_2d_dir path/to/2d_hero
```

Claim guardrail: this pack supports the bridge from Planck-area write demand to lag residuals, tensor/quadrupole diagnostics, and coefficient-map probes. It does not contain baked result outputs.
