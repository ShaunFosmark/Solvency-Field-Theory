#!/usr/bin/env python3
"""
SFT V11.1E — Coefficient Map Probe

Scripts-only helper for regenerating the V11.1E coefficient-map diagnostics
from V11.7 2D aggregate outputs.

Expected input:
  A directory containing:
    aggregate_scalar_only.csv
    aggregate_tensor_only.csv
    aggregate_combined.csv

For example, after running/extracting the V11.7 scripts:
  python sft_v11_1e_coefficient_map_probe.py --v117_2d_dir path/to/2d_hero

Outputs:
  v11_1e_coefficient_map_probe/
    v11_1e_response_slopes.csv
    v11_1e_highk_preference_diagnostics.csv
    v11_1e_combined_additivity_summary.csv
    v11_1e_verdict.csv

This script intentionally expects users to generate or provide their own V11.7
aggregate outputs. It does not include baked data.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--v117_2d_dir", default="sft_v117_output/2d_hero",
                   help="Directory with aggregate_scalar_only.csv, aggregate_tensor_only.csv, aggregate_combined.csv")
    p.add_argument("--outdir", default="v11_1e_coefficient_map_probe")
    return p.parse_args()

def slope(df, x, y):
    c = np.polyfit(df[x].to_numpy(float), df[y].to_numpy(float), 1)
    return float(c[0]), float(c[1])

def main():
    args = parse_args()
    src = Path(args.v117_2d_dir)
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)

    scalar = pd.read_csv(src / "aggregate_scalar_only.csv")
    tensor = pd.read_csv(src / "aggregate_tensor_only.csv")
    combined = pd.read_csv(src / "aggregate_combined.csv")

    rows = []
    for metric in ["rho_ratio_mean","div_ratio_mean","vort_ratio_mean","enstrophy_ratio_mean","strain_ratio_mean","vort_highk_ratio_mean"]:
        if metric in scalar:
            m,b = slope(scalar, "Lambda_chi", metric)
            rows.append({"sector":"scalar","x":"Lambda_chi","metric":metric,"slope":m,"intercept":b})
        if metric in tensor:
            m,b = slope(tensor, "Lambda_Q", metric)
            rows.append({"sector":"tensor","x":"Lambda_Q","metric":metric,"slope":m,"intercept":b})
    slopes = pd.DataFrame(rows)
    slopes.to_csv(out / "v11_1e_response_slopes.csv", index=False)

    # High-k preference: tensor should suppress high-k vorticity more than total vorticity.
    highk_rows = []
    if "vort_highk_ratio_mean" in tensor and "vort_ratio_mean" in tensor:
        for _, r in tensor.iterrows():
            highk_rows.append({
                "Lambda_Q": r["Lambda_Q"],
                "vort_ratio_mean": r["vort_ratio_mean"],
                "vort_highk_ratio_mean": r["vort_highk_ratio_mean"],
                "highk_minus_total": r["vort_highk_ratio_mean"] - r["vort_ratio_mean"],
                "highk_over_total": r["vort_highk_ratio_mean"] / r["vort_ratio_mean"] if r["vort_ratio_mean"] else np.nan
            })
    highk = pd.DataFrame(highk_rows)
    highk.to_csv(out / "v11_1e_highk_preference_diagnostics.csv", index=False)

    # Multiplicative separability approximation using nearest scalar/tensor lambdas when grids match length.
    add_rows = []
    metrics = ["rho_ratio_mean","div_ratio_mean","vort_ratio_mean","enstrophy_ratio_mean","strain_ratio_mean","vort_highk_ratio_mean"]
    n = min(len(scalar), len(tensor), len(combined))
    for metric in metrics:
        if metric in scalar and metric in tensor and metric in combined:
            pred = scalar[metric].iloc[:n].to_numpy(float) * tensor[metric].iloc[:n].to_numpy(float)
            obs = combined[metric].iloc[:n].to_numpy(float)
            add_rows.append({
                "metric": metric,
                "mean_abs_multiplicative_residual": float(np.mean(np.abs(obs - pred))),
                "max_abs_multiplicative_residual": float(np.max(np.abs(obs - pred)))
            })
    add = pd.DataFrame(add_rows)
    add.to_csv(out / "v11_1e_combined_additivity_summary.csv", index=False)

    verdict = pd.DataFrame([
        {
            "gate":"scalar_density_compression_response",
            "status":"PASS" if ((slopes.sector=="scalar") & (slopes.metric=="rho_ratio_mean")).any() else "CHECK",
            "meaning":"scalar channel slopes were computed"
        },
        {
            "gate":"tensor_highk_preference",
            "status":"PASS" if len(highk) and (highk["highk_minus_total"] < 0).any() else "CHECK",
            "meaning":"tensor high-k vorticity suppression diagnostics computed"
        },
        {
            "gate":"combined_separability",
            "status":"PASS" if len(add) else "CHECK",
            "meaning":"combined response compared to scalar*tensor multiplicative approximation"
        },
    ])
    verdict.to_csv(out / "v11_1e_verdict.csv", index=False)

    # Plots
    if len(slopes):
        plt.figure(figsize=(9,5.5))
        for sector, x in [("scalar","Lambda_chi"),("tensor","Lambda_Q")]:
            sub = scalar if sector=="scalar" else tensor
            if x in sub and "vort_ratio_mean" in sub:
                plt.plot(sub[x], sub["vort_ratio_mean"], marker="o", label=f"{sector} vort_ratio")
        plt.xlabel("effective Lambda")
        plt.ylabel("ratio")
        plt.title("V11.1E response diagnostic")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / "v11_1e_response_diagnostic.png", dpi=170)
        plt.close()

    print("V11.1E coefficient map probe complete.")
    print(verdict.to_string(index=False))
    print(out)

if __name__ == "__main__":
    main()
