#!/usr/bin/env python3
"""
SFT V11.1B — 2D Scalar Lag Sign/Shape Toy

Purpose
-------
Promote the 1D V11.1B sign/shape toy to 2D.

Equation:
    dLambda/dt = S(x,y,t) - Lambda/tau + D * Laplacian(Lambda)

Lag force proxy:
    f_Lambda = -grad(Lambda)

Tests:
    A. single_blob: one moving Gaussian operation-demand pulse
    B. rotated_single_blob: same speed, rotated direction
    C. crossing_blobs: two crossing Gaussian demand pulses

Gates:
    1. 2D memory trail: Lambda trails demand along the velocity vector.
    2. vanishing-lag: |grad Lambda| collapses as tau -> 0.
    3. rotational sanity: rotated trajectory gives comparable scalar metrics.
    4. crossing-history distinction: crossing lag field differs from instantaneous source.
    5. force direction sanity: -grad Lambda is shifted relative to -grad S.

Outputs:
    CSV summaries and PNG plots in output directory.

Run:
    python sft_v11_1b_2d_scalar_lag_toy.py
or:
    python sft_v11_1b_2d_scalar_lag_toy.py --N 160 --steps 1800 --outdir ./v11_1b_2d_output
"""

from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--N", type=int, default=128, help="Grid size NxN.")
    p.add_argument("--L", type=float, default=1.0, help="Periodic box size.")
    p.add_argument("--dt", type=float, default=5.0e-4, help="Time step.")
    p.add_argument("--steps", type=int, default=1600, help="Number of time steps.")
    p.add_argument("--sigma", type=float, default=0.055, help="Gaussian pulse width.")
    p.add_argument("--speed", type=float, default=0.42, help="Pulse speed.")
    p.add_argument("--outdir", type=str, default="sft_v11_1b_2d_scalar_lag_toy_output")
    p.add_argument("--dpi", type=int, default=170)
    return p.parse_args()


def periodic_delta(a: np.ndarray, b: float, L: float) -> np.ndarray:
    return ((a - b + 0.5 * L) % L) - 0.5 * L


def gaussian2d(X: np.ndarray, Y: np.ndarray, xc: float, yc: float, sigma: float, L: float, amp: float = 1.0) -> np.ndarray:
    dx = periodic_delta(X, xc, L)
    dy = periodic_delta(Y, yc, L)
    return amp * np.exp(-0.5 * (dx * dx + dy * dy) / (sigma * sigma))


def laplacian(A: np.ndarray, dx: float) -> np.ndarray:
    return (
        np.roll(A, 1, axis=0) + np.roll(A, -1, axis=0)
        + np.roll(A, 1, axis=1) + np.roll(A, -1, axis=1)
        - 4.0 * A
    ) / (dx * dx)


def gradient(A: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray]:
    # axis 1 is x, axis 0 is y
    dAdx = (np.roll(A, -1, axis=1) - np.roll(A, 1, axis=1)) / (2.0 * dx)
    dAdy = (np.roll(A, -1, axis=0) - np.roll(A, 1, axis=0)) / (2.0 * dx)
    return dAdx, dAdy


def circular_mean_1d(weights: np.ndarray, coords: np.ndarray, L: float) -> float:
    weights = np.maximum(weights, 0.0)
    total = float(np.sum(weights))
    if total <= 0:
        return float("nan")
    theta = 2.0 * np.pi * coords / L
    z = np.sum(weights * np.exp(1j * theta)) / total
    return float((np.angle(z) % (2.0 * np.pi)) * L / (2.0 * np.pi))


def center2d(A: np.ndarray, xvals: np.ndarray, yvals: np.ndarray, L: float) -> tuple[float, float]:
    # Marginalize for circular centers.
    wx = np.sum(np.maximum(A, 0.0), axis=0)
    wy = np.sum(np.maximum(A, 0.0), axis=1)
    return circular_mean_1d(wx, xvals, L), circular_mean_1d(wy, yvals, L)


def signed_periodic_offset(a: float, b: float, L: float) -> float:
    return float(((a - b + 0.5 * L) % L) - 0.5 * L)


def unit_vec(vx: float, vy: float) -> tuple[float, float]:
    n = float(np.sqrt(vx * vx + vy * vy))
    return vx / n, vy / n


def source_single(t: float, X: np.ndarray, Y: np.ndarray, sigma: float, L: float, x0: float, y0: float, vx: float, vy: float) -> np.ndarray:
    xc = (x0 + vx * t) % L
    yc = (y0 + vy * t) % L
    return gaussian2d(X, Y, xc, yc, sigma, L)


def source_crossing(t: float, X: np.ndarray, Y: np.ndarray, sigma: float, L: float, speed: float) -> np.ndarray:
    # Two pulses crossing near the center on diagonal and anti-diagonal paths.
    v = speed / np.sqrt(2.0)
    s1 = source_single(t, X, Y, sigma, L, 0.18, 0.22, v, v)
    s2 = source_single(t, X, Y, sigma, L, 0.82, 0.22, -v, v)
    return s1 + s2


def corr2(A: np.ndarray, B: np.ndarray) -> float:
    a = A.ravel()
    b = B.ravel()
    if np.std(a) <= 0 or np.std(b) <= 0:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def rms(A: np.ndarray) -> float:
    return float(np.sqrt(np.mean(A * A)))


def run_case(
    test_type: str,
    tau: float,
    D: float,
    X: np.ndarray,
    Y: np.ndarray,
    xvals: np.ndarray,
    yvals: np.ndarray,
    L: float,
    dx: float,
    dt: float,
    steps: int,
    sigma: float,
    speed: float,
    angle_rad: float,
    snapshot_at_frac: float = 0.62,
) -> tuple[dict, dict]:
    Lam = np.zeros_like(X)
    T_total = dt * steps
    warmup_time = 0.35 * T_total
    snapshot_step = int(snapshot_at_frac * steps)
    snapshot = {}

    # For single-blob metrics, define motion vector.
    vx = speed * np.cos(angle_rad)
    vy = speed * np.sin(angle_rad)
    ux, uy = unit_vec(vx, vy)
    # perpendicular right-handed: (-uy, ux)
    px, py = -uy, ux

    offsets_x, offsets_y = [], []
    offsets_parallel, offsets_perp = [], []
    force_rms, inst_force_rms, shape_corr = [], [], []
    force_cosines = []

    for n in range(steps):
        t = n * dt

        if test_type in ("single_blob", "rotated_single_blob"):
            S = source_single(t, X, Y, sigma, L, 0.18, 0.22, vx, vy)
        elif test_type == "crossing_blobs":
            S = source_crossing(t, X, Y, sigma, L, speed)
        else:
            raise ValueError(f"Unknown test_type={test_type}")

        Lam += dt * (S - Lam / tau + D * laplacian(Lam, dx))

        if n % 20 == 0 and t > warmup_time:
            dLdx, dLdy = gradient(Lam, dx)
            dSdx, dSdy = gradient(S, dx)
            fLx, fLy = -dLdx, -dLdy
            fSx, fSy = -dSdx, -dSdy

            if test_type in ("single_blob", "rotated_single_blob"):
                cxS, cyS = center2d(S, xvals, yvals, L)
                cxL, cyL = center2d(Lam, xvals, yvals, L)
                ox = signed_periodic_offset(cxL, cxS, L)
                oy = signed_periodic_offset(cyL, cyS, L)
                offsets_x.append(ox)
                offsets_y.append(oy)
                offsets_parallel.append(ox * ux + oy * uy)
                offsets_perp.append(ox * px + oy * py)
            else:
                offsets_x.append(np.nan)
                offsets_y.append(np.nan)
                offsets_parallel.append(np.nan)
                offsets_perp.append(np.nan)

            force_rms.append(np.sqrt(np.mean(fLx * fLx + fLy * fLy)))
            inst_force_rms.append(np.sqrt(np.mean(fSx * fSx + fSy * fSy)))
            shape_corr.append(corr2(S, Lam))

            dot = np.mean(fLx * fSx + fLy * fSy)
            mag = np.sqrt(np.mean(fLx*fLx+fLy*fLy) * np.mean(fSx*fSx+fSy*fSy))
            force_cosines.append(float(dot / mag) if mag > 0 else np.nan)

        if n == snapshot_step:
            dLdx, dLdy = gradient(Lam, dx)
            dSdx, dSdy = gradient(S, dx)
            snapshot = {
                "t": t,
                "S": S.copy(),
                "Lambda": Lam.copy(),
                "fLx": (-dLdx).copy(),
                "fLy": (-dLdy).copy(),
                "fSx": (-dSdx).copy(),
                "fSy": (-dSdy).copy(),
            }

    # Gate labels are assigned later relative to sweep, but store raw metrics here.
    row = {
        "test_type": test_type,
        "tau_lag": tau,
        "D_lag": D,
        "angle_deg": float(np.degrees(angle_rad)),
        "mean_trailing_offset_x": float(np.nanmean(offsets_x)),
        "mean_trailing_offset_y": float(np.nanmean(offsets_y)),
        "mean_trailing_offset_parallel": float(np.nanmean(offsets_parallel)),
        "mean_abs_trailing_offset_parallel": float(np.nanmean(np.abs(offsets_parallel))),
        "mean_trailing_offset_perp": float(np.nanmean(offsets_perp)),
        "mean_abs_trailing_offset_perp": float(np.nanmean(np.abs(offsets_perp))),
        "mean_force_rms": float(np.nanmean(force_rms)),
        "mean_instant_force_rms": float(np.nanmean(inst_force_rms)),
        "force_rms_ratio_lag_to_instant": float(np.nanmean(force_rms) / np.nanmean(inst_force_rms)),
        "mean_shape_correlation": float(np.nanmean(shape_corr)),
        "mean_force_cosine_with_instant": float(np.nanmean(force_cosines)),
    }
    return row, snapshot


def save_heatmap(path: Path, A: np.ndarray, title: str, cmap: str = "viridis", dpi: int = 170) -> None:
    plt.figure(figsize=(6.2, 5.2))
    plt.imshow(A, origin="lower", extent=[0, 1, 0, 1], cmap=cmap)
    plt.colorbar()
    plt.title(title)
    plt.xlabel("x")
    plt.ylabel("y")
    plt.tight_layout()
    plt.savefig(path, dpi=dpi)
    plt.close()


def save_quiver_snapshot(path: Path, X: np.ndarray, Y: np.ndarray, snap: dict, title: str, dpi: int = 170) -> None:
    S = snap["S"]
    Lam = snap["Lambda"]
    fLx, fLy = snap["fLx"], snap["fLy"]

    stride = max(1, X.shape[0] // 24)
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2), constrained_layout=True)

    im0 = axes[0].imshow(S, origin="lower", extent=[0, 1, 0, 1])
    axes[0].set_title("instant demand S")
    fig.colorbar(im0, ax=axes[0], fraction=0.046)

    im1 = axes[1].imshow(Lam, origin="lower", extent=[0, 1, 0, 1])
    axes[1].set_title("lag residual Lambda")
    fig.colorbar(im1, ax=axes[1], fraction=0.046)

    axes[2].imshow(Lam, origin="lower", extent=[0, 1, 0, 1], alpha=0.75)
    axes[2].quiver(
        X[::stride, ::stride], Y[::stride, ::stride],
        fLx[::stride, ::stride], fLy[::stride, ::stride],
        angles="xy", scale_units="xy", scale=None, width=0.003
    )
    axes[2].set_title("-grad Lambda force proxy")

    for ax in axes:
        ax.set_xlabel("x")
        ax.set_ylabel("y")

    fig.suptitle(title)
    plt.savefig(path, dpi=dpi)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    N, L = args.N, args.L
    xvals = np.linspace(0, L, N, endpoint=False)
    yvals = np.linspace(0, L, N, endpoint=False)
    X, Y = np.meshgrid(xvals, yvals)
    dx = L / N

    taus = [0.005, 0.015, 0.04, 0.08, 0.16]
    D_values = [0.0, 2.5e-4, 1.0e-3]

    # Tests:
    #   single_blob: diagonal at 45°
    #   rotated_single_blob: same speed at 120°
    #   crossing_blobs: two crossing pulses
    test_specs = [
        ("single_blob", np.deg2rad(45.0)),
        ("rotated_single_blob", np.deg2rad(120.0)),
        ("crossing_blobs", np.deg2rad(45.0)),
    ]

    rows = []
    snapshots_to_save = {}
    for test_type, angle in test_specs:
        for D in D_values:
            for tau in taus:
                row, snap = run_case(
                    test_type=test_type,
                    tau=tau,
                    D=D,
                    X=X,
                    Y=Y,
                    xvals=xvals,
                    yvals=yvals,
                    L=L,
                    dx=dx,
                    dt=args.dt,
                    steps=args.steps,
                    sigma=args.sigma,
                    speed=args.speed,
                    angle_rad=angle,
                )
                rows.append(row)

                if D == 2.5e-4 and tau in (0.015, 0.08, 0.16):
                    snapshots_to_save[(test_type, tau)] = snap

    summary = pd.DataFrame(rows)

    # Status labels based on expected behavior. For memory, parallel offset should be negative:
    # Lambda center trails behind demand along motion direction.
    summary["status_memory"] = np.where(
        (summary["test_type"].isin(["single_blob", "rotated_single_blob"])) &
        (summary["mean_trailing_offset_parallel"] < 0),
        "pass", "n/a"
    )

    # Vanishing lag status by monotonic small-tau force check, assigned per test and D.
    summary["status_vanishing"] = "pending"
    for (test_type, D), sub in summary.groupby(["test_type", "D_lag"]):
        sub_sorted = sub.sort_values("tau_lag")
        # The first tau should have the smallest or near-smallest force.
        smallest_at_first = sub_sorted["mean_force_rms"].iloc[0] <= 1.05 * sub_sorted["mean_force_rms"].min()
        idx = sub_sorted.index
        summary.loc[idx, "status_vanishing"] = "pass" if smallest_at_first else "check"

    # Rotational sanity: compare single_blob vs rotated_single_blob scalar metrics for same tau,D.
    rotation_rows = []
    for D in D_values:
        for tau in taus:
            a = summary[(summary.test_type == "single_blob") & (summary.D_lag == D) & (summary.tau_lag == tau)].iloc[0]
            b = summary[(summary.test_type == "rotated_single_blob") & (summary.D_lag == D) & (summary.tau_lag == tau)].iloc[0]
            force_rel_diff = abs(a.mean_force_rms - b.mean_force_rms) / max(a.mean_force_rms, b.mean_force_rms)
            corr_diff = abs(a.mean_shape_correlation - b.mean_shape_correlation)
            offset_rel_diff = abs(a.mean_abs_trailing_offset_parallel - b.mean_abs_trailing_offset_parallel) / max(a.mean_abs_trailing_offset_parallel, b.mean_abs_trailing_offset_parallel)
            rotation_rows.append({
                "tau_lag": tau,
                "D_lag": D,
                "force_rms_rel_diff": float(force_rel_diff),
                "shape_corr_abs_diff": float(corr_diff),
                "parallel_offset_rel_diff": float(offset_rel_diff),
                "status_rotation": "pass" if force_rel_diff < 0.08 and offset_rel_diff < 0.15 else "check",
            })

    rotation = pd.DataFrame(rotation_rows)
    summary = summary.merge(rotation, on=["tau_lag", "D_lag"], how="left")

    # Crossing-history distinction: shape correlation should drop as tau grows; force cosine should differ from 1.
    summary["status_crossing_history"] = np.where(
        (summary["test_type"] == "crossing_blobs") &
        (summary["mean_shape_correlation"] < 0.98),
        "pass", np.where(summary["test_type"] == "crossing_blobs", "weak_or_small_tau", "n/a")
    )

    summary_path = outdir / "v11_1b_2d_scalar_lag_summary.csv"
    summary.to_csv(summary_path, index=False)

    # Compact verdict table
    verdict_rows = []
    for test_type in ["single_blob", "rotated_single_blob", "crossing_blobs"]:
        sub = summary[(summary.test_type == test_type) & (summary.D_lag == 2.5e-4)]
        verdict_rows.append({
            "test_type": test_type,
            "memory_parallel_offset_tau_0p16": float(sub[sub.tau_lag == 0.16]["mean_trailing_offset_parallel"].iloc[0]) if test_type != "crossing_blobs" else np.nan,
            "force_rms_tau_0p005": float(sub[sub.tau_lag == 0.005]["mean_force_rms"].iloc[0]),
            "force_rms_tau_0p16": float(sub[sub.tau_lag == 0.16]["mean_force_rms"].iloc[0]),
            "corr_tau_0p005": float(sub[sub.tau_lag == 0.005]["mean_shape_correlation"].iloc[0]),
            "corr_tau_0p16": float(sub[sub.tau_lag == 0.16]["mean_shape_correlation"].iloc[0]),
        })
    verdict = pd.DataFrame(verdict_rows)
    verdict_path = outdir / "v11_1b_2d_scalar_lag_verdict.csv"
    verdict.to_csv(verdict_path, index=False)

    print("\nV11.1B 2D scalar lag summary:")
    print(summary.sort_values(["test_type", "D_lag", "tau_lag"]).to_string(index=False))

    print("\nCompact verdict:")
    print(verdict.to_string(index=False))

    # Plot 1: parallel trailing offset vs tau for single and rotated.
    plt.figure(figsize=(8.8, 5.8))
    for test_type in ["single_blob", "rotated_single_blob"]:
        for D in D_values:
            sub = summary[(summary.test_type == test_type) & (summary.D_lag == D)].sort_values("tau_lag")
            plt.plot(sub.tau_lag, np.abs(sub.mean_trailing_offset_parallel), marker="o", label=f"{test_type}, D={D:g}")
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("|parallel trailing offset|")
    plt.title("V11.1B 2D memory gate: lag trails moving demand")
    plt.legend(fontsize=7)
    plt.tight_layout()
    p_offset = outdir / "v11_1b_2d_parallel_offset_vs_tau.png"
    plt.savefig(p_offset, dpi=args.dpi)
    plt.close()

    # Plot 2: force RMS vs tau.
    plt.figure(figsize=(8.8, 5.8))
    for test_type in ["single_blob", "crossing_blobs"]:
        sub = summary[(summary.test_type == test_type) & (summary.D_lag == 2.5e-4)].sort_values("tau_lag")
        plt.plot(sub.tau_lag, sub.mean_force_rms, marker="o", label=f"{test_type}")
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("RMS |grad Lambda|")
    plt.title("V11.1B 2D vanishing-lag gate")
    plt.legend()
    plt.tight_layout()
    p_force = outdir / "v11_1b_2d_force_rms_vs_tau.png"
    plt.savefig(p_force, dpi=args.dpi)
    plt.close()

    # Plot 3: correlation vs tau.
    plt.figure(figsize=(8.8, 5.8))
    for test_type in ["single_blob", "rotated_single_blob", "crossing_blobs"]:
        sub = summary[(summary.test_type == test_type) & (summary.D_lag == 2.5e-4)].sort_values("tau_lag")
        plt.plot(sub.tau_lag, sub.mean_shape_correlation, marker="o", label=f"{test_type}")
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("corr(S, Lambda)")
    plt.title("V11.1B 2D history distinction: lag departs from instant demand")
    plt.legend()
    plt.tight_layout()
    p_corr = outdir / "v11_1b_2d_shape_correlation_vs_tau.png"
    plt.savefig(p_corr, dpi=args.dpi)
    plt.close()

    # Plot 4: rotation sanity metrics.
    plt.figure(figsize=(8.8, 5.8))
    for D in D_values:
        sub = rotation[rotation.D_lag == D].sort_values("tau_lag")
        plt.plot(sub.tau_lag, sub.force_rms_rel_diff, marker="o", label=f"force RMS rel diff, D={D:g}")
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("single vs rotated relative difference")
    plt.title("V11.1B 2D rotational sanity")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_rot = outdir / "v11_1b_2d_rotation_sanity.png"
    plt.savefig(p_rot, dpi=args.dpi)
    plt.close()

    # Save representative snapshots.
    snap_paths = []
    for (test_type, tau), snap in snapshots_to_save.items():
        p = outdir / f"v11_1b_2d_snapshot_{test_type}_tau_{tau:g}.png"
        save_quiver_snapshot(
            p, X, Y, snap,
            title=f"V11.1B 2D {test_type}, tau={tau:g}, D=2.5e-4, t={snap['t']:.3f}",
            dpi=args.dpi,
        )
        snap_paths.append(p)

    # Crossing-pulse heatmaps for the strongest memory case.
    key = ("crossing_blobs", 0.16)
    if key in snapshots_to_save:
        snap = snapshots_to_save[key]
        save_heatmap(outdir / "v11_1b_2d_crossing_demand_tau_0p16.png", snap["S"], "Crossing pulses: instantaneous demand S", dpi=args.dpi)
        save_heatmap(outdir / "v11_1b_2d_crossing_lag_tau_0p16.png", snap["Lambda"], "Crossing pulses: lag residual Lambda", dpi=args.dpi)

    print("\nSaved files:")
    for p in [summary_path, verdict_path, p_offset, p_force, p_corr, p_rot] + snap_paths:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
