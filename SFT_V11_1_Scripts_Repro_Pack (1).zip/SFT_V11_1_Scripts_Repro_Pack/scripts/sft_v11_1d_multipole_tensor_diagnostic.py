#!/usr/bin/env python3
"""
SFT V11.1D — Angular Multipole + Tensor/Scalar Lag Diagnostic

Purpose
-------
V11.1C showed that simple radial subtraction is not a clean way to isolate
shear excess. V11.1D replaces that diagnostic with two cleaner tests:

Part B, fast and robust:
    Compare tensor-to-scalar loading across shapes:
        R_shape = RMS |div Q| / RMS |grad Lambda|
    and then compare R_shape / R_round at matched tau, D.

Part A, rigorous:
    Decompose the lag residual Lambda(r, theta) around its weighted centroid:
        Lambda(r,theta) = a0(r) + sum_m [a_m(r) cos(m theta) + b_m(r) sin(m theta)]
    and measure angular-mode powers P_m.

Interpretation:
    m=0: monopole / isotropic radial profile
    m=1: dipole / trailing memory
    m=2: quadrupole / shear-like anisotropic lag
    m>=3: higher angular structure

Main gates
----------
1. Elongated residuals should have larger P2 than round residuals.
2. Rotated elongated residuals should have similar P2 magnitude to elongated residuals.
3. The m=2 phase should rotate with the source orientation.
4. Tensor/scalar loading should be higher for elongated residuals than round residuals.

Run
---
    python sft_v11_1d_multipole_tensor_diagnostic.py

Sharper local run:
    python sft_v11_1d_multipole_tensor_diagnostic.py --N 160 --steps 1800 --outdir ./v11_1d_output
"""

from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--N", type=int, default=128)
    p.add_argument("--L", type=float, default=1.0)
    p.add_argument("--dt", type=float, default=5.0e-4)
    p.add_argument("--steps", type=int, default=1600)
    p.add_argument("--sigma", type=float, default=0.055)
    p.add_argument("--sigma_parallel", type=float, default=0.095)
    p.add_argument("--sigma_perp", type=float, default=0.040)
    p.add_argument("--speed", type=float, default=0.42)
    p.add_argument("--outdir", type=str, default="sft_v11_1d_multipole_tensor_output")
    p.add_argument("--dpi", type=int, default=170)
    p.add_argument("--sample_every", type=int, default=40, help="Sample cadence after warmup.")
    p.add_argument("--nbins", type=int, default=72, help="Radial bins for angular decomposition.")
    p.add_argument("--mmax", type=int, default=6, help="Maximum angular mode.")
    return p.parse_args()


def periodic_delta(a: np.ndarray, b: float, L: float) -> np.ndarray:
    return ((a - b + 0.5 * L) % L) - 0.5 * L


def gaussian_round(X: np.ndarray, Y: np.ndarray, xc: float, yc: float, sigma: float, L: float) -> np.ndarray:
    dx = periodic_delta(X, xc, L)
    dy = periodic_delta(Y, yc, L)
    return np.exp(-0.5 * (dx*dx + dy*dy) / (sigma*sigma))


def gaussian_elongated(
    X: np.ndarray,
    Y: np.ndarray,
    xc: float,
    yc: float,
    sigma_parallel: float,
    sigma_perp: float,
    theta: float,
    L: float,
) -> np.ndarray:
    dx = periodic_delta(X, xc, L)
    dy = periodic_delta(Y, yc, L)
    c, s = np.cos(theta), np.sin(theta)
    u = c*dx + s*dy
    v = -s*dx + c*dy
    return np.exp(-0.5 * ((u/sigma_parallel)**2 + (v/sigma_perp)**2))


def laplacian(A: np.ndarray, dx: float) -> np.ndarray:
    return (
        np.roll(A, 1, axis=0) + np.roll(A, -1, axis=0)
        + np.roll(A, 1, axis=1) + np.roll(A, -1, axis=1)
        - 4.0*A
    ) / (dx*dx)


def gradient(A: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray]:
    dAdx = (np.roll(A, -1, axis=1) - np.roll(A, 1, axis=1)) / (2.0*dx)
    dAdy = (np.roll(A, -1, axis=0) - np.roll(A, 1, axis=0)) / (2.0*dx)
    return dAdx, dAdy


def second_derivatives(A: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    Axx = (np.roll(A, -1, axis=1) - 2.0*A + np.roll(A, 1, axis=1)) / (dx*dx)
    Ayy = (np.roll(A, -1, axis=0) - 2.0*A + np.roll(A, 1, axis=0)) / (dx*dx)
    Axy = (
        np.roll(np.roll(A, -1, axis=0), -1, axis=1)
        - np.roll(np.roll(A, -1, axis=0), 1, axis=1)
        - np.roll(np.roll(A, 1, axis=0), -1, axis=1)
        + np.roll(np.roll(A, 1, axis=0), 1, axis=1)
    ) / (4.0*dx*dx)
    return Axx, Ayy, Axy, Axx + Ayy


def tensor_Q_and_force(Lam: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    Lxx, Lyy, Lxy, lap = second_derivatives(Lam, dx)
    Qxx = Lxx - 0.5*lap
    Qyy = Lyy - 0.5*lap
    Qxy = Lxy

    dQxx_dx, dQxx_dy = gradient(Qxx, dx)
    dQxy_dx, dQxy_dy = gradient(Qxy, dx)
    dQyy_dx, dQyy_dy = gradient(Qyy, dx)

    fQx = dQxx_dx + dQxy_dy
    fQy = dQxy_dx + dQyy_dy
    Qnorm = np.sqrt(Qxx*Qxx + Qyy*Qyy + 2.0*Qxy*Qxy)
    return Qxx, Qyy, Qxy, fQx, fQy, Qnorm


def rms_vec(vx: np.ndarray, vy: np.ndarray) -> float:
    return float(np.sqrt(np.mean(vx*vx + vy*vy)))


def rms_scalar(A: np.ndarray) -> float:
    return float(np.sqrt(np.mean(A*A)))


def circular_mean_1d(weights: np.ndarray, coords: np.ndarray, L: float) -> float:
    weights = np.maximum(weights, 0.0)
    total = float(np.sum(weights))
    if total <= 0:
        return float("nan")
    theta = 2.0*np.pi*coords/L
    z = np.sum(weights*np.exp(1j*theta)) / total
    return float((np.angle(z) % (2.0*np.pi))*L/(2.0*np.pi))


def center2d(A: np.ndarray, xvals: np.ndarray, yvals: np.ndarray, L: float) -> tuple[float, float]:
    W = np.maximum(A, 0.0)
    wx = np.sum(W, axis=0)
    wy = np.sum(W, axis=1)
    return circular_mean_1d(wx, xvals, L), circular_mean_1d(wy, yvals, L)


def source_field(
    test_type: str,
    t: float,
    X: np.ndarray,
    Y: np.ndarray,
    L: float,
    sigma: float,
    sigma_parallel: float,
    sigma_perp: float,
    speed: float,
) -> tuple[np.ndarray, float]:
    """
    Returns source field and nominal orientation angle for shape.
    Round/crossing orientation angle is NaN because no single source axis exists.
    """
    if test_type == "round_blob":
        theta = np.deg2rad(45.0)
        vx, vy = speed*np.cos(theta), speed*np.sin(theta)
        return gaussian_round(X, Y, (0.18 + vx*t) % L, (0.22 + vy*t) % L, sigma, L), np.nan

    if test_type == "elongated_blob":
        theta = np.deg2rad(45.0)
        vx, vy = speed*np.cos(theta), speed*np.sin(theta)
        return gaussian_elongated(X, Y, (0.18 + vx*t) % L, (0.22 + vy*t) % L,
                                  sigma_parallel, sigma_perp, theta, L), theta

    if test_type == "rotated_elongated_blob":
        theta = np.deg2rad(120.0)
        vx, vy = speed*np.cos(theta), speed*np.sin(theta)
        return gaussian_elongated(X, Y, (0.18 + vx*t) % L, (0.22 + vy*t) % L,
                                  sigma_parallel, sigma_perp, theta, L), theta

    if test_type == "crossing_blobs":
        v = speed/np.sqrt(2.0)
        s1 = gaussian_round(X, Y, (0.18 + v*t) % L, (0.22 + v*t) % L, sigma, L)
        s2 = gaussian_round(X, Y, (0.82 - v*t) % L, (0.22 + v*t) % L, sigma, L)
        return s1 + s2, np.nan

    raise ValueError(test_type)


def shape_anisotropy(A: np.ndarray, X: np.ndarray, Y: np.ndarray, xvals: np.ndarray, yvals: np.ndarray, L: float) -> float:
    W = np.maximum(A, 0.0)
    total = float(np.sum(W))
    if total <= 0:
        return float("nan")
    cx, cy = center2d(A, xvals, yvals, L)
    dxs = periodic_delta(X, cx, L)
    dys = periodic_delta(Y, cy, L)
    Cxx = float(np.sum(W*dxs*dxs) / total)
    Cyy = float(np.sum(W*dys*dys) / total)
    Cxy = float(np.sum(W*dxs*dys) / total)
    tr = Cxx + Cyy
    disc = np.sqrt((Cxx - Cyy)**2 + 4.0*Cxy*Cxy)
    if tr <= 0:
        return float("nan")
    return float(disc/tr)


def angular_multipoles(
    field: np.ndarray,
    X: np.ndarray,
    Y: np.ndarray,
    xvals: np.ndarray,
    yvals: np.ndarray,
    L: float,
    nbins: int = 72,
    mmax: int = 6,
) -> dict:
    """
    Angular Fourier decomposition of field around its positive-weighted centroid.
    Returns integrated powers P_m and global complex coefficients C_m.

    P_m uses radial annuli:
        a0(r) = mean(field)
        a_m(r) = 2 mean(field cos mθ)
        b_m(r) = 2 mean(field sin mθ)
        P_m ≈ sum_bins n_bin * (a_m^2 + b_m^2)
    """
    cx, cy = center2d(field, xvals, yvals, L)
    dxs = periodic_delta(X, cx, L)
    dys = periodic_delta(Y, cy, L)
    R = np.sqrt(dxs*dxs + dys*dys)
    TH = np.arctan2(dys, dxs)

    # Restrict to region with meaningful signal to reduce far-field numerical floor.
    fmax = float(np.max(np.abs(field)))
    mask_signal = np.abs(field) > max(1e-12, 1e-4*fmax)

    rmax = float(np.max(R[mask_signal])) if np.any(mask_signal) else float(np.max(R))
    bins = np.linspace(0.0, rmax + 1e-12, nbins + 1)
    inds = np.digitize(R.ravel(), bins) - 1
    inds = np.clip(inds, 0, nbins - 1)

    flat_f = field.ravel()
    flat_th = TH.ravel()
    flat_mask = mask_signal.ravel()

    P = {m: 0.0 for m in range(mmax + 1)}
    radial_rows = []

    for b in range(nbins):
        mask = (inds == b) & flat_mask
        n = int(np.sum(mask))
        if n < 12:
            continue
        vals = flat_f[mask]
        th = flat_th[mask]
        a0 = float(np.mean(vals))
        P[0] += n * a0*a0
        row = {
            "r_bin": b,
            "r_mid": 0.5*(bins[b] + bins[b+1]),
            "n_cells": n,
            "a0": a0,
        }
        for m in range(1, mmax + 1):
            a = float(2.0*np.mean(vals*np.cos(m*th)))
            bb = float(2.0*np.mean(vals*np.sin(m*th)))
            amp = float(np.sqrt(a*a + bb*bb))
            P[m] += n * amp*amp
            row[f"a{m}"] = a
            row[f"b{m}"] = bb
            row[f"A{m}"] = amp
        radial_rows.append(row)

    total = sum(P.values()) + 1e-30

    # Global complex coefficients. Useful for phase/orientation sanity.
    # Use positive field as weight to emphasize residual geometry.
    W = np.maximum(field, 0.0)
    C = {}
    for m in range(mmax + 1):
        if m == 0:
            C[m] = complex(np.sum(W), 0.0)
        else:
            C[m] = complex(np.sum(W*np.exp(1j*m*TH)))

    # m=2 orientation: because quadrupole is π-periodic, angle is modulo π.
    phase2 = float((0.5*np.angle(C[2])) % np.pi) if mmax >= 2 else float("nan")

    result = {
        "cx": cx,
        "cy": cy,
        "P_total": total,
        "phase2_rad": phase2,
        "phase2_deg": float(np.degrees(phase2)) if np.isfinite(phase2) else float("nan"),
        "radial_rows": radial_rows,
    }
    for m in range(mmax + 1):
        result[f"P{m}"] = float(P[m])
        result[f"frac_P{m}"] = float(P[m] / total)
    result["P2_over_P0"] = float(P[2] / (P[0] + 1e-30)) if mmax >= 2 else float("nan")
    result["P2_over_P1"] = float(P[2] / (P[1] + 1e-30)) if mmax >= 2 else float("nan")
    return result


def run_case(
    test_type: str,
    tau: float,
    D: float,
    X: np.ndarray,
    Y: np.ndarray,
    xvals: np.ndarray,
    yvals: np.ndarray,
    L: float,
    dx: float,
    dt: float,
    steps: int,
    sigma: float,
    sigma_parallel: float,
    sigma_perp: float,
    speed: float,
    sample_every: int,
    nbins: int,
    mmax: int,
) -> tuple[dict, list[dict], dict]:
    Lam = np.zeros_like(X)
    T_total = dt*steps
    warmup = 0.35*T_total
    snapshot_step = int(0.62*steps)

    scalar_force_rms = []
    tensor_force_rms = []
    tensor_to_scalar = []
    Q_rms = []
    anis = []
    fracP = {m: [] for m in range(mmax + 1)}
    P2_over_P0 = []
    P2_over_P1 = []
    phase2 = []
    radial_rows_all = []
    snapshot = {}

    nominal_angle = np.nan

    for n in range(steps):
        t = n*dt
        S, nominal_angle = source_field(test_type, t, X, Y, L, sigma, sigma_parallel, sigma_perp, speed)
        Lam += dt*(S - Lam/tau + D*laplacian(Lam, dx))

        if n % sample_every == 0 and t > warmup:
            dLdx, dLdy = gradient(Lam, dx)
            _, _, _, fQx, fQy, Qnorm = tensor_Q_and_force(Lam, dx)
            scalar = rms_vec(-dLdx, -dLdy)
            tensor = rms_vec(fQx, fQy)

            scalar_force_rms.append(scalar)
            tensor_force_rms.append(tensor)
            tensor_to_scalar.append(tensor/scalar if scalar > 0 else np.nan)
            Q_rms.append(rms_scalar(Qnorm))
            anis.append(shape_anisotropy(Lam, X, Y, xvals, yvals, L))

            mp = angular_multipoles(Lam, X, Y, xvals, yvals, L, nbins=nbins, mmax=mmax)
            for m in range(mmax + 1):
                fracP[m].append(mp[f"frac_P{m}"])
            P2_over_P0.append(mp["P2_over_P0"])
            P2_over_P1.append(mp["P2_over_P1"])
            phase2.append(mp["phase2_rad"])

            for rr in mp["radial_rows"]:
                rr2 = dict(rr)
                rr2.update({"test_type": test_type, "tau_lag": tau, "D_lag": D, "t": t})
                radial_rows_all.append(rr2)

        if n == snapshot_step:
            mp = angular_multipoles(Lam, X, Y, xvals, yvals, L, nbins=nbins, mmax=mmax)
            _, _, _, fQx, fQy, Qnorm = tensor_Q_and_force(Lam, dx)
            snapshot = {
                "t": t,
                "S": S.copy(),
                "Lambda": Lam.copy(),
                "Qnorm": Qnorm.copy(),
                "phase2_rad": mp["phase2_rad"],
                "phase2_deg": mp["phase2_deg"],
                "radial_rows": mp["radial_rows"],
            }

    row = {
        "test_type": test_type,
        "tau_lag": tau,
        "D_lag": D,
        "nominal_angle_deg": float(np.degrees(nominal_angle)) if np.isfinite(nominal_angle) else np.nan,
        "mean_scalar_force_rms": float(np.nanmean(scalar_force_rms)),
        "mean_tensor_force_rms": float(np.nanmean(tensor_force_rms)),
        "mean_tensor_to_scalar_ratio": float(np.nanmean(tensor_to_scalar)),
        "mean_Q_rms": float(np.nanmean(Q_rms)),
        "mean_shape_anisotropy": float(np.nanmean(anis)),
        "mean_P2_over_P0": float(np.nanmean(P2_over_P0)),
        "mean_P2_over_P1": float(np.nanmean(P2_over_P1)),
        "mean_phase2_rad": float(np.angle(np.nanmean(np.exp(1j*2*np.asarray(phase2)))) / 2.0 % np.pi) if len(phase2) else np.nan,
        "mean_phase2_deg": np.nan,
    }
    row["mean_phase2_deg"] = float(np.degrees(row["mean_phase2_rad"])) if np.isfinite(row["mean_phase2_rad"]) else np.nan

    for m in range(mmax + 1):
        row[f"mean_frac_P{m}"] = float(np.nanmean(fracP[m]))

    return row, radial_rows_all, snapshot


def save_snapshot_panel(path: Path, snap: dict, test_type: str, tau: float, D: float, dpi: int) -> None:
    radial = pd.DataFrame(snap["radial_rows"])
    fig, axes = plt.subplots(1, 4, figsize=(17.0, 4.2), constrained_layout=True)

    im0 = axes[0].imshow(snap["S"], origin="lower", extent=[0, 1, 0, 1])
    axes[0].set_title("instant demand S")
    fig.colorbar(im0, ax=axes[0], fraction=0.046)

    im1 = axes[1].imshow(snap["Lambda"], origin="lower", extent=[0, 1, 0, 1])
    axes[1].set_title("lag residual Lambda")
    fig.colorbar(im1, ax=axes[1], fraction=0.046)

    im2 = axes[2].imshow(snap["Qnorm"], origin="lower", extent=[0, 1, 0, 1])
    axes[2].set_title("tensor magnitude |Q|")
    fig.colorbar(im2, ax=axes[2], fraction=0.046)

    if not radial.empty:
        axes[3].plot(radial["r_mid"], radial["a0"].abs(), label="|m=0|")
        for m in [1, 2, 3, 4]:
            col = f"A{m}"
            if col in radial:
                axes[3].plot(radial["r_mid"], radial[col], label=f"A{m}")
        axes[3].set_yscale("log")
        axes[3].legend(fontsize=8)
    axes[3].set_title("angular mode amplitudes")
    axes[3].set_xlabel("radius")
    axes[3].set_ylabel("amplitude")

    for ax in axes[:3]:
        ax.set_xlabel("x")
        ax.set_ylabel("y")

    fig.suptitle(f"V11.1D {test_type}, tau={tau:g}, D={D:g}, phase2={snap['phase2_deg']:.1f}°")
    plt.savefig(path, dpi=dpi)
    plt.close(fig)


def circular_phase_delta_deg(a_deg: float, b_deg: float) -> float:
    """Quadrupole orientation has 180 degree periodicity."""
    d = ((a_deg - b_deg + 90.0) % 180.0) - 90.0
    return float(d)


def main() -> None:
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    N, L = args.N, args.L
    xvals = np.linspace(0, L, N, endpoint=False)
    yvals = np.linspace(0, L, N, endpoint=False)
    X, Y = np.meshgrid(xvals, yvals)
    dx = L/N

    taus = [0.005, 0.015, 0.04, 0.08, 0.16]
    D_values = [2.5e-4]
    test_types = ["round_blob", "elongated_blob", "rotated_elongated_blob", "crossing_blobs"]

    summary_rows = []
    radial_rows = []
    snapshots = {}

    for D in D_values:
        for tau in taus:
            for tt in test_types:
                row, rad, snap = run_case(
                    test_type=tt,
                    tau=tau,
                    D=D,
                    X=X,
                    Y=Y,
                    xvals=xvals,
                    yvals=yvals,
                    L=L,
                    dx=dx,
                    dt=args.dt,
                    steps=args.steps,
                    sigma=args.sigma,
                    sigma_parallel=args.sigma_parallel,
                    sigma_perp=args.sigma_perp,
                    speed=args.speed,
                    sample_every=args.sample_every,
                    nbins=args.nbins,
                    mmax=args.mmax,
                )
                summary_rows.append(row)
                radial_rows.extend(rad)
                if tau in (0.04, 0.16):
                    snapshots[(tt, tau, D)] = snap

    summary = pd.DataFrame(summary_rows)
    radial_df = pd.DataFrame(radial_rows)

    # Compare to round baseline at matched tau,D.
    round_ref = summary[summary["test_type"] == "round_blob"][
        ["tau_lag", "D_lag", "mean_tensor_to_scalar_ratio", "mean_frac_P2", "mean_P2_over_P0", "mean_shape_anisotropy"]
    ].rename(columns={
        "mean_tensor_to_scalar_ratio": "round_tensor_to_scalar_ratio",
        "mean_frac_P2": "round_frac_P2",
        "mean_P2_over_P0": "round_P2_over_P0",
        "mean_shape_anisotropy": "round_shape_anisotropy",
    })

    merged = summary.merge(round_ref, on=["tau_lag", "D_lag"], how="left")
    merged["tensor_to_scalar_vs_round"] = merged["mean_tensor_to_scalar_ratio"] / (merged["round_tensor_to_scalar_ratio"] + 1e-30)
    merged["frac_P2_vs_round"] = merged["mean_frac_P2"] / (merged["round_frac_P2"] + 1e-30)
    merged["P2_over_P0_vs_round"] = merged["mean_P2_over_P0"] / (merged["round_P2_over_P0"] + 1e-30)
    merged["anisotropy_vs_round"] = merged["mean_shape_anisotropy"] / (merged["round_shape_anisotropy"] + 1e-30)

    # Verdict at largest tau.
    gate_tau = 0.16
    gate = merged[(merged["tau_lag"] == gate_tau) & (merged["D_lag"] == 2.5e-4)].copy()
    gate["status_tensor_scalar"] = np.where(
        gate["test_type"].eq("round_blob"),
        "control",
        np.where(gate["tensor_to_scalar_vs_round"] > 1.05, "pass", "check")
    )
    gate["status_quadrupole_P2"] = np.where(
        gate["test_type"].eq("round_blob"),
        "control",
        np.where(gate["frac_P2_vs_round"] > 1.25, "pass", "check")
    )

    # Rotational sanity between elongated and rotated elongated.
    try:
        e = gate[gate["test_type"] == "elongated_blob"].iloc[0]
        r = gate[gate["test_type"] == "rotated_elongated_blob"].iloc[0]
        p2_rel_diff = abs(e["mean_frac_P2"] - r["mean_frac_P2"]) / max(abs(e["mean_frac_P2"]), abs(r["mean_frac_P2"]), 1e-30)
        ratio_rel_diff = abs(e["mean_tensor_to_scalar_ratio"] - r["mean_tensor_to_scalar_ratio"]) / max(abs(e["mean_tensor_to_scalar_ratio"]), abs(r["mean_tensor_to_scalar_ratio"]), 1e-30)
        phase_delta = circular_phase_delta_deg(float(r["mean_phase2_deg"]), float(e["mean_phase2_deg"]))
    except Exception:
        p2_rel_diff, ratio_rel_diff, phase_delta = np.nan, np.nan, np.nan

    gate["elongated_rotated_P2_rel_diff_global"] = p2_rel_diff
    gate["elongated_rotated_tensor_ratio_rel_diff_global"] = ratio_rel_diff
    gate["rotated_minus_elongated_phase2_delta_deg_global"] = phase_delta
    gate["status_rotational_magnitude"] = "pass" if (np.isfinite(p2_rel_diff) and p2_rel_diff < 0.15 and ratio_rel_diff < 0.15) else "check"

    # Save CSVs.
    summary_path = outdir / "v11_1d_multipole_tensor_summary.csv"
    merged_path = outdir / "v11_1d_multipole_tensor_with_round_reference.csv"
    radial_path = outdir / "v11_1d_radial_mode_profiles.csv"
    gate_path = outdir / "v11_1d_multipole_tensor_gate_verdict.csv"
    summary.to_csv(summary_path, index=False)
    merged.to_csv(merged_path, index=False)
    radial_df.to_csv(radial_path, index=False)
    gate.to_csv(gate_path, index=False)

    print("\nV11.1D gate verdict at tau=0.16:")
    print(gate.to_string(index=False))

    # Plots.
    # 1. Tensor/scalar ratio relative to round.
    plt.figure(figsize=(9, 5.8))
    for tt in test_types:
        sub = merged[merged["test_type"] == tt].sort_values("tau_lag")
        plt.plot(sub["tau_lag"], sub["tensor_to_scalar_vs_round"], marker="o", label=tt)
    plt.axhline(1.0, linestyle="--")
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("(tensor/scalar) / round")
    plt.title("V11.1D tensor-to-scalar loading relative to round")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_ratio_round = outdir / "v11_1d_tensor_scalar_vs_round.png"
    plt.savefig(p_ratio_round, dpi=args.dpi)
    plt.close()

    # 2. Quadrupole fraction vs tau.
    plt.figure(figsize=(9, 5.8))
    for tt in test_types:
        sub = merged[merged["test_type"] == tt].sort_values("tau_lag")
        plt.plot(sub["tau_lag"], sub["mean_frac_P2"], marker="o", label=tt)
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("mean quadrupole power fraction P2/P_total")
    plt.title("V11.1D angular quadrupole content")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_p2frac = outdir / "v11_1d_quadrupole_fraction_vs_tau.png"
    plt.savefig(p_p2frac, dpi=args.dpi)
    plt.close()

    # 3. Quadrupole fraction relative to round.
    plt.figure(figsize=(9, 5.8))
    for tt in test_types:
        sub = merged[merged["test_type"] == tt].sort_values("tau_lag")
        plt.plot(sub["tau_lag"], sub["frac_P2_vs_round"], marker="o", label=tt)
    plt.axhline(1.0, linestyle="--")
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("P2 fraction / round P2 fraction")
    plt.title("V11.1D quadrupole content relative to round")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_p2round = outdir / "v11_1d_quadrupole_vs_round.png"
    plt.savefig(p_p2round, dpi=args.dpi)
    plt.close()

    # 4. P0/P1/P2 fractions.
    plt.figure(figsize=(9, 5.8))
    for tt in test_types:
        sub = merged[merged["test_type"] == tt].sort_values("tau_lag")
        plt.plot(sub["tau_lag"], sub["mean_frac_P0"], marker="o", linestyle="-", label=f"{tt} P0")
        plt.plot(sub["tau_lag"], sub["mean_frac_P1"], marker="s", linestyle="--", label=f"{tt} P1")
        plt.plot(sub["tau_lag"], sub["mean_frac_P2"], marker="^", linestyle=":", label=f"{tt} P2")
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("mode power fraction")
    plt.title("V11.1D monopole/dipole/quadrupole fractions")
    plt.legend(fontsize=6, ncol=2)
    plt.tight_layout()
    p_modes = outdir / "v11_1d_mode_fractions_p0_p1_p2.png"
    plt.savefig(p_modes, dpi=args.dpi)
    plt.close()

    # 5. m=2 phase.
    plt.figure(figsize=(9, 5.8))
    for tt in ["elongated_blob", "rotated_elongated_blob"]:
        sub = merged[merged["test_type"] == tt].sort_values("tau_lag")
        plt.plot(sub["tau_lag"], sub["mean_phase2_deg"], marker="o", label=tt)
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("m=2 orientation phase [deg, modulo 180]")
    plt.title("V11.1D quadrupole phase rotation sanity")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_phase = outdir / "v11_1d_quadrupole_phase_vs_tau.png"
    plt.savefig(p_phase, dpi=args.dpi)
    plt.close()

    # 6. Shape anisotropy
    plt.figure(figsize=(9, 5.8))
    for tt in test_types:
        sub = merged[merged["test_type"] == tt].sort_values("tau_lag")
        plt.plot(sub["tau_lag"], sub["mean_shape_anisotropy"], marker="o", label=tt)
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("shape anisotropy of Lambda")
    plt.title("V11.1D residual anisotropy")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_anis = outdir / "v11_1d_residual_anisotropy.png"
    plt.savefig(p_anis, dpi=args.dpi)
    plt.close()

    # Snapshot panels.
    snap_paths = []
    for (tt, tau, D), snap in snapshots.items():
        p = outdir / f"v11_1d_snapshot_{tt}_tau_{tau:g}.png"
        save_snapshot_panel(p, snap, tt, tau, D, args.dpi)
        snap_paths.append(p)

    print("\nSaved files:")
    for p in [
        summary_path, merged_path, radial_path, gate_path,
        p_ratio_round, p_p2frac, p_p2round, p_modes, p_phase, p_anis
    ] + snap_paths:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
