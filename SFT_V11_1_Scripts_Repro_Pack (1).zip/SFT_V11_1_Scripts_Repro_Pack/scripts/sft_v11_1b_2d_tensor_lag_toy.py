#!/usr/bin/env python3
"""
SFT V11.1B — 2D Tensor Lag Mini-Toy

Purpose
-------
Extend the V11.1B 2D scalar lag residual toy by computing the trace-free
Hessian tensor of the lag residual:

    Q_ij = d_i d_j Lambda - (1/2) delta_ij Laplacian(Lambda)      [2D]

and its divergence:

    f_i^tensor = d_j Q_ij

This is the simplest 2D tensor/shear proxy for the V11.1B -> V11.7 bridge.

Scalar residual:
    dLambda/dt = S(x,y,t) - Lambda/tau + D * Laplacian(Lambda)

Scalar lag force:
    f_scalar = -grad Lambda

Tensor diagnostics:
    Q_rms
    |div Q|_rms
    tensor_to_scalar_force_ratio
    shape anisotropy of Lambda from second moments

Tests:
    1. round_blob
    2. elongated_blob
    3. rotated_elongated_blob
    4. crossing_blobs

Main gate:
    Tensor response should activate more strongly for elongated/crossing
    residuals than for round residuals.

Run:
    python sft_v11_1b_2d_tensor_lag_toy.py
or:
    python sft_v11_1b_2d_tensor_lag_toy.py --N 160 --steps 1800 --outdir ./v11_1b_tensor_output
"""

from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--N", type=int, default=128, help="Grid size NxN.")
    p.add_argument("--L", type=float, default=1.0, help="Periodic box size.")
    p.add_argument("--dt", type=float, default=5.0e-4, help="Time step.")
    p.add_argument("--steps", type=int, default=1600, help="Number of time steps.")
    p.add_argument("--sigma", type=float, default=0.055, help="Round Gaussian pulse width.")
    p.add_argument("--sigma_parallel", type=float, default=0.095, help="Elongated Gaussian width along orientation.")
    p.add_argument("--sigma_perp", type=float, default=0.040, help="Elongated Gaussian width perpendicular to orientation.")
    p.add_argument("--speed", type=float, default=0.42, help="Pulse speed.")
    p.add_argument("--outdir", type=str, default="sft_v11_1b_2d_tensor_lag_toy_output")
    p.add_argument("--dpi", type=int, default=170)
    return p.parse_args()


def periodic_delta(a: np.ndarray, b: float, L: float) -> np.ndarray:
    return ((a - b + 0.5 * L) % L) - 0.5 * L


def gaussian_round(X: np.ndarray, Y: np.ndarray, xc: float, yc: float, sigma: float, L: float) -> np.ndarray:
    dx = periodic_delta(X, xc, L)
    dy = periodic_delta(Y, yc, L)
    return np.exp(-0.5 * (dx * dx + dy * dy) / (sigma * sigma))


def gaussian_elongated(
    X: np.ndarray, Y: np.ndarray, xc: float, yc: float,
    sigma_parallel: float, sigma_perp: float, theta: float, L: float
) -> np.ndarray:
    dx = periodic_delta(X, xc, L)
    dy = periodic_delta(Y, yc, L)
    c, s = np.cos(theta), np.sin(theta)
    u = c * dx + s * dy
    v = -s * dx + c * dy
    return np.exp(-0.5 * ((u/sigma_parallel)**2 + (v/sigma_perp)**2))


def laplacian(A: np.ndarray, dx: float) -> np.ndarray:
    return (
        np.roll(A, 1, axis=0) + np.roll(A, -1, axis=0)
        + np.roll(A, 1, axis=1) + np.roll(A, -1, axis=1)
        - 4.0 * A
    ) / (dx * dx)


def gradient(A: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray]:
    dAdx = (np.roll(A, -1, axis=1) - np.roll(A, 1, axis=1)) / (2.0 * dx)
    dAdy = (np.roll(A, -1, axis=0) - np.roll(A, 1, axis=0)) / (2.0 * dx)
    return dAdx, dAdy


def second_derivatives(A: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    Axx = (np.roll(A, -1, axis=1) - 2*A + np.roll(A, 1, axis=1)) / (dx*dx)
    Ayy = (np.roll(A, -1, axis=0) - 2*A + np.roll(A, 1, axis=0)) / (dx*dx)
    Axy = (
        np.roll(np.roll(A, -1, axis=0), -1, axis=1)
        - np.roll(np.roll(A, -1, axis=0), 1, axis=1)
        - np.roll(np.roll(A, 1, axis=0), -1, axis=1)
        + np.roll(np.roll(A, 1, axis=0), 1, axis=1)
    ) / (4.0 * dx * dx)
    lap = Axx + Ayy
    return Axx, Ayy, Axy, lap


def tensor_Q_and_force(Lam: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    Lxx, Lyy, Lxy, lap = second_derivatives(Lam, dx)

    # 2D trace-free Hessian
    Qxx = Lxx - 0.5 * lap
    Qyy = Lyy - 0.5 * lap
    Qxy = Lxy

    # f_i = d_j Q_ij
    dQxx_dx, dQxx_dy = gradient(Qxx, dx)
    dQxy_dx, dQxy_dy = gradient(Qxy, dx)
    dQyy_dx, dQyy_dy = gradient(Qyy, dx)

    fQx = dQxx_dx + dQxy_dy
    fQy = dQxy_dx + dQyy_dy

    Qnorm = np.sqrt(Qxx*Qxx + Qyy*Qyy + 2.0*Qxy*Qxy)
    return Qxx, Qyy, Qxy, fQx, fQy, Qnorm


def circular_mean_1d(weights: np.ndarray, coords: np.ndarray, L: float) -> float:
    weights = np.maximum(weights, 0.0)
    total = float(np.sum(weights))
    if total <= 0:
        return float("nan")
    theta = 2.0 * np.pi * coords / L
    z = np.sum(weights * np.exp(1j * theta)) / total
    return float((np.angle(z) % (2.0 * np.pi)) * L / (2.0 * np.pi))


def center2d(A: np.ndarray, xvals: np.ndarray, yvals: np.ndarray, L: float) -> tuple[float, float]:
    wx = np.sum(np.maximum(A, 0.0), axis=0)
    wy = np.sum(np.maximum(A, 0.0), axis=1)
    return circular_mean_1d(wx, xvals, L), circular_mean_1d(wy, yvals, L)


def signed_periodic_offset(a: np.ndarray | float, b: float, L: float) -> np.ndarray | float:
    return ((a - b + 0.5 * L) % L) - 0.5 * L


def shape_anisotropy(A: np.ndarray, X: np.ndarray, Y: np.ndarray, xvals: np.ndarray, yvals: np.ndarray, L: float) -> float:
    W = np.maximum(A, 0.0)
    total = float(np.sum(W))
    if total <= 0:
        return float("nan")
    cx, cy = center2d(A, xvals, yvals, L)
    dxs = signed_periodic_offset(X, cx, L)
    dys = signed_periodic_offset(Y, cy, L)
    Cxx = float(np.sum(W * dxs * dxs) / total)
    Cyy = float(np.sum(W * dys * dys) / total)
    Cxy = float(np.sum(W * dxs * dys) / total)
    tr = Cxx + Cyy
    disc = np.sqrt((Cxx - Cyy)**2 + 4*Cxy*Cxy)
    if tr <= 0:
        return float("nan")
    return float(disc / tr)  # 0 round, ->1 line-like


def corr2(A: np.ndarray, B: np.ndarray) -> float:
    a, b = A.ravel(), B.ravel()
    if np.std(a) <= 0 or np.std(b) <= 0:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def source_field(
    test_type: str, t: float, X: np.ndarray, Y: np.ndarray, L: float,
    sigma: float, sigma_parallel: float, sigma_perp: float, speed: float
) -> np.ndarray:
    if test_type == "round_blob":
        theta = np.deg2rad(45.0)
        vx, vy = speed*np.cos(theta), speed*np.sin(theta)
        xc = (0.18 + vx*t) % L
        yc = (0.22 + vy*t) % L
        return gaussian_round(X, Y, xc, yc, sigma, L)

    if test_type == "elongated_blob":
        theta = np.deg2rad(45.0)
        vx, vy = speed*np.cos(theta), speed*np.sin(theta)
        xc = (0.18 + vx*t) % L
        yc = (0.22 + vy*t) % L
        return gaussian_elongated(X, Y, xc, yc, sigma_parallel, sigma_perp, theta, L)

    if test_type == "rotated_elongated_blob":
        theta = np.deg2rad(120.0)
        vx, vy = speed*np.cos(theta), speed*np.sin(theta)
        xc = (0.18 + vx*t) % L
        yc = (0.22 + vy*t) % L
        return gaussian_elongated(X, Y, xc, yc, sigma_parallel, sigma_perp, theta, L)

    if test_type == "crossing_blobs":
        v = speed/np.sqrt(2.0)
        s1 = gaussian_round(X, Y, (0.18 + v*t) % L, (0.22 + v*t) % L, sigma, L)
        s2 = gaussian_round(X, Y, (0.82 - v*t) % L, (0.22 + v*t) % L, sigma, L)
        return s1 + s2

    raise ValueError(test_type)


def run_case(
    test_type: str, tau: float, D: float,
    X: np.ndarray, Y: np.ndarray, xvals: np.ndarray, yvals: np.ndarray,
    L: float, dx: float, dt: float, steps: int,
    sigma: float, sigma_parallel: float, sigma_perp: float, speed: float,
) -> tuple[dict, dict]:
    Lam = np.zeros_like(X)
    T_total = dt*steps
    warmup = 0.35*T_total
    snapshot_step = int(0.62*steps)
    snapshot = {}

    scalar_force_rms = []
    tensor_force_rms = []
    Q_rms = []
    ratio = []
    anis = []
    corr = []

    for n in range(steps):
        t = n*dt
        S = source_field(test_type, t, X, Y, L, sigma, sigma_parallel, sigma_perp, speed)
        Lam += dt*(S - Lam/tau + D*laplacian(Lam, dx))

        if n % 20 == 0 and t > warmup:
            dLdx, dLdy = gradient(Lam, dx)
            fSx, fSy = -dLdx, -dLdy
            _, _, _, fQx, fQy, Qnorm = tensor_Q_and_force(Lam, dx)

            scalar = float(np.sqrt(np.mean(fSx*fSx + fSy*fSy)))
            tensor = float(np.sqrt(np.mean(fQx*fQx + fQy*fQy)))
            qval = float(np.sqrt(np.mean(Qnorm*Qnorm)))

            scalar_force_rms.append(scalar)
            tensor_force_rms.append(tensor)
            Q_rms.append(qval)
            ratio.append(tensor/scalar if scalar > 0 else np.nan)
            anis.append(shape_anisotropy(Lam, X, Y, xvals, yvals, L))
            corr.append(corr2(S, Lam))

        if n == snapshot_step:
            dLdx, dLdy = gradient(Lam, dx)
            Qxx, Qyy, Qxy, fQx, fQy, Qnorm = tensor_Q_and_force(Lam, dx)
            snapshot = {
                "t": t,
                "S": S.copy(),
                "Lambda": Lam.copy(),
                "Qnorm": Qnorm.copy(),
                "f_scalar_x": (-dLdx).copy(),
                "f_scalar_y": (-dLdy).copy(),
                "f_tensor_x": fQx.copy(),
                "f_tensor_y": fQy.copy(),
            }

    row = {
        "test_type": test_type,
        "tau_lag": tau,
        "D_lag": D,
        "mean_scalar_force_rms": float(np.nanmean(scalar_force_rms)),
        "mean_tensor_force_rms": float(np.nanmean(tensor_force_rms)),
        "mean_Q_rms": float(np.nanmean(Q_rms)),
        "mean_tensor_to_scalar_force_ratio": float(np.nanmean(ratio)),
        "mean_shape_anisotropy": float(np.nanmean(anis)),
        "mean_shape_correlation_S_Lambda": float(np.nanmean(corr)),
    }
    return row, snapshot


def save_tensor_snapshot(path: Path, X: np.ndarray, Y: np.ndarray, snap: dict, title: str, dpi: int) -> None:
    stride = max(1, X.shape[0]//24)

    fig, axes = plt.subplots(1, 4, figsize=(17, 4.2), constrained_layout=True)

    im0 = axes[0].imshow(snap["S"], origin="lower", extent=[0, 1, 0, 1])
    axes[0].set_title("instant demand S")
    fig.colorbar(im0, ax=axes[0], fraction=0.046)

    im1 = axes[1].imshow(snap["Lambda"], origin="lower", extent=[0, 1, 0, 1])
    axes[1].set_title("lag residual Lambda")
    fig.colorbar(im1, ax=axes[1], fraction=0.046)

    im2 = axes[2].imshow(snap["Qnorm"], origin="lower", extent=[0, 1, 0, 1])
    axes[2].set_title("tensor magnitude |Q|")
    fig.colorbar(im2, ax=axes[2], fraction=0.046)

    axes[3].imshow(snap["Qnorm"], origin="lower", extent=[0, 1, 0, 1], alpha=0.75)
    axes[3].quiver(
        X[::stride, ::stride], Y[::stride, ::stride],
        snap["f_tensor_x"][::stride, ::stride], snap["f_tensor_y"][::stride, ::stride],
        angles="xy", scale_units="xy", scale=None, width=0.003
    )
    axes[3].set_title("div Q tensor-force proxy")

    for ax in axes:
        ax.set_xlabel("x")
        ax.set_ylabel("y")

    fig.suptitle(title)
    plt.savefig(path, dpi=dpi)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    N, L = args.N, args.L
    xvals = np.linspace(0, L, N, endpoint=False)
    yvals = np.linspace(0, L, N, endpoint=False)
    X, Y = np.meshgrid(xvals, yvals)
    dx = L/N

    taus = [0.005, 0.015, 0.04, 0.08, 0.16]
    D_values = [0.0, 2.5e-4, 1.0e-3]
    test_types = ["round_blob", "elongated_blob", "rotated_elongated_blob", "crossing_blobs"]

    rows = []
    snapshots = {}

    for test_type in test_types:
        for D in D_values:
            for tau in taus:
                row, snap = run_case(
                    test_type=test_type, tau=tau, D=D,
                    X=X, Y=Y, xvals=xvals, yvals=yvals,
                    L=L, dx=dx, dt=args.dt, steps=args.steps,
                    sigma=args.sigma, sigma_parallel=args.sigma_parallel,
                    sigma_perp=args.sigma_perp, speed=args.speed,
                )
                rows.append(row)
                if D == 2.5e-4 and tau in (0.04, 0.16):
                    snapshots[(test_type, tau)] = snap

    summary = pd.DataFrame(rows)

    # Activation ratios: compare each test against round_blob at same tau,D.
    comp_rows = []
    for D in D_values:
        for tau in taus:
            base = summary[(summary.test_type=="round_blob") & (summary.D_lag==D) & (summary.tau_lag==tau)].iloc[0]
            for tt in ["elongated_blob", "rotated_elongated_blob", "crossing_blobs"]:
                r = summary[(summary.test_type==tt) & (summary.D_lag==D) & (summary.tau_lag==tau)].iloc[0]
                comp_rows.append({
                    "test_type": tt,
                    "tau_lag": tau,
                    "D_lag": D,
                    "tensor_force_rms_vs_round": float(r.mean_tensor_force_rms / base.mean_tensor_force_rms),
                    "Q_rms_vs_round": float(r.mean_Q_rms / base.mean_Q_rms),
                    "anisotropy_vs_round": float(r.mean_shape_anisotropy / base.mean_shape_anisotropy) if base.mean_shape_anisotropy > 0 else np.nan,
                    "tensor_to_scalar_ratio_vs_round": float(r.mean_tensor_to_scalar_force_ratio / base.mean_tensor_to_scalar_force_ratio),
                })

    comparison = pd.DataFrame(comp_rows)

    # Status gate for D=2.5e-4, tau=0.16.
    gate = comparison[(comparison.D_lag==2.5e-4) & (comparison.tau_lag==0.16)].copy()
    gate["status_tensor_activation"] = np.where(
        (gate["tensor_force_rms_vs_round"] > 1.10) | (gate["Q_rms_vs_round"] > 1.10) | (gate["anisotropy_vs_round"] > 1.25),
        "pass",
        "check"
    )

    summary_path = outdir / "v11_1b_2d_tensor_lag_summary.csv"
    comp_path = outdir / "v11_1b_2d_tensor_lag_activation_vs_round.csv"
    gate_path = outdir / "v11_1b_2d_tensor_lag_gate_verdict.csv"
    summary.to_csv(summary_path, index=False)
    comparison.to_csv(comp_path, index=False)
    gate.to_csv(gate_path, index=False)

    print("\nV11.1B 2D tensor lag summary:")
    print(summary.sort_values(["test_type", "D_lag", "tau_lag"]).to_string(index=False))
    print("\nTensor activation gate at D=2.5e-4, tau=0.16:")
    print(gate.to_string(index=False))

    # Plots
    # 1. Tensor force RMS vs tau
    plt.figure(figsize=(8.8, 5.8))
    for tt in test_types:
        sub = summary[(summary.test_type==tt) & (summary.D_lag==2.5e-4)].sort_values("tau_lag")
        plt.plot(sub.tau_lag, sub.mean_tensor_force_rms, marker="o", label=tt)
    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("RMS |div Q|")
    plt.title("V11.1B 2D tensor-force activation")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_tensor = outdir / "v11_1b_2d_tensor_force_rms_vs_tau.png"
    plt.savefig(p_tensor, dpi=args.dpi)
    plt.close()

    # 2. Tensor/scalar ratio
    plt.figure(figsize=(8.8, 5.8))
    for tt in test_types:
        sub = summary[(summary.test_type==tt) & (summary.D_lag==2.5e-4)].sort_values("tau_lag")
        plt.plot(sub.tau_lag, sub.mean_tensor_to_scalar_force_ratio, marker="o", label=tt)
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("RMS |div Q| / RMS |grad Lambda|")
    plt.title("V11.1B tensor-to-scalar force ratio")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_ratio = outdir / "v11_1b_2d_tensor_to_scalar_ratio_vs_tau.png"
    plt.savefig(p_ratio, dpi=args.dpi)
    plt.close()

    # 3. Shape anisotropy
    plt.figure(figsize=(8.8, 5.8))
    for tt in test_types:
        sub = summary[(summary.test_type==tt) & (summary.D_lag==2.5e-4)].sort_values("tau_lag")
        plt.plot(sub.tau_lag, sub.mean_shape_anisotropy, marker="o", label=tt)
    plt.xscale("log")
    plt.xlabel("lag settlement time tau")
    plt.ylabel("shape anisotropy of Lambda")
    plt.title("V11.1B residual anisotropy")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_anis = outdir / "v11_1b_2d_shape_anisotropy_vs_tau.png"
    plt.savefig(p_anis, dpi=args.dpi)
    plt.close()

    # 4. Activation vs round
    plot_gate = comparison[(comparison.D_lag==2.5e-4) & (comparison.tau_lag==0.16)].copy()
    labels = plot_gate.test_type.to_list()
    xind = np.arange(len(labels))
    width = 0.35
    plt.figure(figsize=(8.8, 5.8))
    plt.bar(xind - width/2, plot_gate.tensor_force_rms_vs_round, width, label="tensor force vs round")
    plt.bar(xind + width/2, plot_gate.anisotropy_vs_round, width, label="anisotropy vs round")
    plt.axhline(1.0, linestyle="--")
    plt.xticks(xind, labels, rotation=20, ha="right")
    plt.ylabel("ratio to round_blob")
    plt.title("V11.1B tensor activation relative to round residual, tau=0.16")
    plt.legend(fontsize=8)
    plt.tight_layout()
    p_act = outdir / "v11_1b_2d_tensor_activation_vs_round.png"
    plt.savefig(p_act, dpi=args.dpi)
    plt.close()

    # Snapshots
    snap_paths = []
    for (tt, tau), snap in snapshots.items():
        p = outdir / f"v11_1b_2d_tensor_snapshot_{tt}_tau_{tau:g}.png"
        save_tensor_snapshot(
            p, X, Y, snap,
            title=f"V11.1B 2D tensor {tt}, tau={tau:g}, D=2.5e-4, t={snap['t']:.3f}",
            dpi=args.dpi,
        )
        snap_paths.append(p)

    print("\nSaved files:")
    for p in [summary_path, comp_path, gate_path, p_tensor, p_ratio, p_anis, p_act] + snap_paths:
        print(p)
    print(outdir)


if __name__ == "__main__":
    main()
